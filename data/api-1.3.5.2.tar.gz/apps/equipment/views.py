from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import status, viewsets, generics
from rest_framework.views import APIView
from django.db import connection
from django.core import serializers


# Create your views here.

class GetListManifestDataByCondition(APIView):
    """ Response for the All  """
    def post(self, request):
        conditionParam = request.data['validatorStr']     
        with connection.cursor() as cursor:
            # cursor.execute("call get_list_manifest_data_by_condition(%s)", ([conditionParam]))             
            cursor.execute("call get_ref_list_by_name(%s)", ([conditionParam]))             
            row = dictfetchall(cursor)
        return Response(row)   





def dictfetchall(cursor):
    """ Common method for Return all rows from a cursor as a dictionary """
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
        ]

