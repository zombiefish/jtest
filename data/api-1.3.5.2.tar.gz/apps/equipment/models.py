from datetime import datetime
from django.db import models
from apps.person.models import Person
from apps.reflist.models import RefListDetail

from apps.common_utils.views.sofvieModelFields import(
    SofvieCharField,
    SofvieIntegerField,
    SofvieTextField
)
class EquipmentType(models.Model):
    poe_id = models.AutoField(db_column='poe_id', primary_key=True)
    poe_equip_description = SofvieIntegerField(blank=False, null=False)
    poe_tag_type = SofvieIntegerField(blank=False, null=False)
    poe_enable = models.BooleanField(default=True)
    poe_created_date = models.DateTimeField(auto_now_add=True)
    poe_created_by_per = models.ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='poe_created_by')
    poe_modified_date = models.DateTimeField(auto_now=True, blank=True, null=True)
    poe_modified_by_per = models.ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='poe_modified_by',
                                     blank=True, null=True)
    poe_enote = SofvieCharField(max_length=200, blank=True, null=True)
    
    class Meta:
        db_table = 'preop_equipment'


class PreopEquipmentType (models.Model):
    pet_id = models.AutoField(primary_key=True)
    pet_equipment_identifier = SofvieCharField(max_length=200, blank=False, null=False, db_column='pet_equipment_identifier')
    pet_poe_id = models.ForeignKey(EquipmentType, models.DO_NOTHING,
                                           blank=False, null=False,
                                           db_column='pet_poe_id')
    
    pet_created_by_per_id = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           db_column='pet_created_by_per_id',
                                           related_name='PetCreatedBy')
    pet_modified_by_per_id = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           db_column='pet_modified_by_per_id',
                                           related_name='PetModifiedBy')
    pet_created_date = models.DateTimeField(models.DO_NOTHING, blank=True, null=True,
                                                db_column='pet_created_date')
    pet_modified_date = models.DateTimeField(models.DO_NOTHING, blank=True, null=True,
                                                db_column='pet_modified_date')
    pet_enote = SofvieCharField(max_length=200, blank=True, null=True)
    pet_enable = models.BooleanField(default=True, db_column='pet_enable')
    
    class Meta:
        db_table = 'preop_equipment_type'


class PreopCheckpointType(models.Model):
    pct_id = models.AutoField(primary_key=True)
    pct_field_label = SofvieIntegerField(blank=True, null=True)
    pct_created_date = models.DateTimeField(auto_now_add=True)
    pct_created_by_per = models.ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='pct_created_by')
    pct_modified_date = models.DateTimeField(auto_now=True, blank=True, null=True)
    pct_modified_by_per = models.ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='pct_modified_by',
                                     blank=True, null=True)
    pct_enable = models.BooleanField(default=True)
    pct_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = 'preop_checkpoint_type'

    def __str__(self):
        return self.pct_field_label


class EquipmentQuestions(models.Model):
    poq_id= models.AutoField(db_column='poq_id', primary_key=True)
    poq_pct_id = models.ForeignKey(PreopCheckpointType, models.DO_NOTHING,
                                           blank=False, null=False,
                                           db_column='poq_pct_id',
                                           related_name='poqpct_id', default=True)
    poq_preop_identifier = SofvieCharField(blank=True, null=True, max_length=200)
    poq_preop_questionmode_id = SofvieIntegerField(blank=True, null=True)
    poq_preop_question = SofvieIntegerField(blank=False, null=False)
    poq_tag_type = SofvieIntegerField(blank=False, null= False)
    poq_created_date = models.DateTimeField(blank=True, null=True,
                                        default=datetime.now)
    poq_created_by_per_id = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           db_column='poq_created_by_per_id',
                                           related_name='QuestionCreatedBy')
    poq_modified_date = models.DateTimeField(blank=True, null=True)
    poq_modified_by_per_id = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           db_column='poq_modified_by_per_id',
                                           related_name='QuestionModifiedBy')
    poq_sort_order = SofvieIntegerField(blank=True, null=True)
    poq_archived_date = models.DateTimeField(blank=True, null=True, db_column='poq_archived_date')
    poq_archived_by_per = models.ForeignKey(Person, models.DO_NOTHING, blank=True, null=True, 
                                            related_name='poq_archived_by', db_column='poq_archived_by_per_id')
    poq_enable = models.BooleanField(default=True)
    poq_enote = SofvieCharField(max_length=200, blank=True, null=True, db_column='poq_enote')

    class Meta:
        db_table = 'preop_question'


class Equipment(models.Model):
    peq_id = models.AutoField(primary_key=True) # PreOpEquipID
    peq_pet_id = models.ForeignKey(PreopEquipmentType, models.DO_NOTHING, 
                                                blank=True, null=True,
                                                db_column='peq_pet_id',
                                                related_name='equipment')
    peq_created_date = models.DateTimeField(models.DO_NOTHING, blank=True, null=True,
                                                db_column='peq_created_date',
                                                default=datetime.now)
    peq_created_by_per_id = models.ForeignKey(Person, models.DO_NOTHING,
                                                blank=True, null=True,
                                                db_column='peq_created_by_per_id')
    peq_modified_date = models.DateTimeField(models.DO_NOTHING, blank=True, null=True,
                                                db_column='peq_modified_date',
                                                default=datetime.now)
    peq_modified_by_per_id = models.ForeignKey(Person, models.DO_NOTHING,
                                                blank=True, null=True,
                                                db_column='peq_modified_by_per_id',
                                                related_name='EquipmentModifiedBy')

    peq_sort_order = SofvieIntegerField(blank=True, null=True)
    peq_poq_id = models.ForeignKey(EquipmentQuestions,
                                                 models.DO_NOTHING, blank=True,
                                                 null=True,
                                                 db_column='peq_poq_id',
                                                 related_name='EquipmentPreOpQuestionID')
    peq_archived_date = models.DateTimeField(blank=True, null=True, db_column='peq_archived_date')
    peq_archived_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                                blank=True, null=True,
                                                db_column='peq_archived_by_per_id',
                                                related_name='EquipmentArchivedBy')

    peq_enable = SofvieIntegerField(default=1, db_column='peq_enable', blank=False, null=False)
    peq_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = 'preop_equipment_question'


class PreopEquipmentMeasure(models.Model):
    pem_id = models.AutoField(primary_key=True)
    pem_pet_id = models.ForeignKey(PreopEquipmentType, models.DO_NOTHING, 
                                                blank=True, null=True,
                                                db_column='pem_pet_id',
                                                related_name='equipment_pet_id')
    pem_rld_measure_id = models.ForeignKey(RefListDetail, models.DO_NOTHING,
                                           blank=False, null=False,
                                           db_column='pem_rld_measure_id',
                                           related_name='PemMeasureRldId')
    pem_created_by_per_id = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           db_column='pem_created_by_per_id',
                                           related_name='PemCreatedBy')
    pem_modifier_by_per_id = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           db_column='pem_modifier_by_per_id',
                                           related_name='PemModifiedBy')
    pem_created_date = models.DateTimeField(models.DO_NOTHING, blank=True, null=True,
                                                db_column='pem_created_date')
    pem_modified_date = models.DateTimeField(models.DO_NOTHING, blank=True, null=True,
                                                db_column='pem_modified_date')
    pem_enote = SofvieCharField(max_length=200, blank=True, null=True)
    pem_enable = models.BooleanField(default=True, db_column='pem_enable')

    class Meta:
        db_table = 'preop_equipment_measure'

class PreopEquipmentSiteJob(models.Model):
    psj_id = models.AutoField(primary_key=True)
    psj_pet_id = models.ForeignKey(PreopEquipmentType, models.DO_NOTHING,
                                   blank=True, null=True,
                                   db_column='psj_pet_id', related_name="psj_pet")
    psj_rld_site_id = models.ForeignKey(RefListDetail, models.DO_NOTHING,
                                           blank=False, null=False,
                                           db_column='psj_rld_site_id', related_name="psj_ref_site")
    psj_rld_job_id = models.ForeignKey(RefListDetail, models.DO_NOTHING,
                                           blank=False, null=False,
                                           db_column='psj_rld_job_id', related_name="psj_ref_job")
    psj_created_by_per_id = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           db_column='psj_created_by_per_id', related_name="psj_created_by_per")
    psj_modified_by_per_id = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           db_column='psj_modified_by_per_id', related_name="psj_modified_by_per")
    psj_created_date = models.DateTimeField(models.DO_NOTHING, blank=True, null=True,
                                                db_column='psj_created_date')
    psj_modified_date = models.DateTimeField(models.DO_NOTHING, blank=True, null=True,
                                                db_column='psj_modified_date')
    psj_enote = SofvieCharField(max_length=500, blank=True, null=True)
    psj_enable = models.BooleanField(default=True, db_column='psj_enable')
    class Meta:
        db_table = 'preop_equipment_site_job'