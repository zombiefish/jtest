from django.urls import path


from apps.equipment.api.views.add_equipment import AddEquipmentWithQuestions
from apps.equipment.api.views.delete_checkpoints import DeleteCheckpoints
from apps.equipment.api.views.delete_equipment import DeleteEquipmentQuestions
from apps.equipment.api.views.get_full_equipment_list import GetFullEquipmentList
from apps.equipment.api.views.get_preop_equipment_site_job import ListAllEquipmentSiteJob
from apps.equipment.api.views.inserting_equipment_with_questions import \
    InsertQuestion
from apps.equipment.api.views.list_equipment import ListAllEquipment
from apps.equipment.api.views.list_equipment_summary import ListAllEquipmentSummary
from apps.equipment.api.views.list_preop_equipment import GetPreopEquipmentList
from apps.equipment.api.views.list_questions import ListQuestions, \
    ListEquipmentQuestions
from apps.equipment.api.views.insert_equipment_type import InsertEquipmentType
from apps.equipment.api.views.list_equipment_type import ListEquipmentType
from apps.equipment.api.views.list_questions import ListAllQuestions
from apps.equipment.api.views.update_equipment import UpdateEquipmentQuestions
from apps.equipment.api.views.update_equipment_type import UpdateEquipmentType
from apps.equipment.api.views.update_question import UpdateQuestion
from apps.equipment.api.views.preop_bulk_edit import PreopBulkEdit
from apps.equipment.api.views.get_preop_measure_type import ListPreOpMeasureType
from apps.equipment.api.views.get_checkpoint_type import GetItemType

urlpatterns = [
    path('list-all-equipment/', ListAllEquipment.as_view()),
    path('list-all-equipment-summary/<str:lang>/', ListAllEquipmentSummary.as_view()),
    path('add-equipment-type/', InsertEquipmentType.as_view()),
    path('update-equipment-type/', UpdateEquipmentType.as_view()),
    path('list-equipment-type/', ListEquipmentType.as_view()),
    path('list-all-questions/', ListAllQuestions.as_view()),
    path('equipment-questions/', ListQuestions.as_view()),
    path('list-equipment-questions/', ListEquipmentQuestions.as_view()),
    path('insert-question/', InsertQuestion.as_view()),
    path('add-equipment/', AddEquipmentWithQuestions.as_view()),
    path('update-equipment/', UpdateEquipmentQuestions.as_view()),
    path('remove-equipment/', DeleteEquipmentQuestions.as_view()),
    path('update-question/', UpdateQuestion.as_view()),
    path('delete-checkpoint/', DeleteCheckpoints.as_view()),
    path('preop-bulk-edit/', PreopBulkEdit.as_view()),
    path('get-list-preop-measuretype/',ListPreOpMeasureType.as_view()),
    path('get-checkpoint-item-type/',GetItemType.as_view()),
    path('get-preop-equipment-list/<str:mode>/',GetPreopEquipmentList.as_view()),
    path('get-list-all-equipment-site-job/',ListAllEquipmentSiteJob.as_view()),
    path('get-full-equipment-list/',GetFullEquipmentList.as_view()),
]
