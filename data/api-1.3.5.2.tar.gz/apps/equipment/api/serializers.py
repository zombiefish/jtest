from rest_framework import serializers

from apps.employee.models import Employee
from apps.language.models import LanguageTranslation
from apps.person.api.views import EmployeeSerializer
from apps.equipment.models import  EquipmentType, EquipmentQuestions, Equipment, PreopCheckpointType
from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile

class GetAllEquipmentTypes(serializers.ModelSerializer):
    class Meta:
        model = EquipmentType
        fields = [
            'poe_id',
            'poe_equip_description',
            'poe_tag_type',
        ]


class GetAllEquipment(serializers.ModelSerializer):
    class Meta:
        model = Equipment
        fields = [
            'peq_id',
            'peq_created_date',
            'peq_modified_date',
            'peq_modified_by_per_id',
            'peq_sort_order',
            'peq_poq_id',
            'peq_pet_id'
        ]


class GetAllQuestionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = EquipmentQuestions
        fields = [    
            'poq_id',
            'poq_preop_identifier',
            'poq_preop_questionmode_id',
            'poq_preop_question',
            'poq_created_date',
            'poq_modified_date',
            'poq_modified_by_per_id',
            'poq_tag_type',
            'poq_sort_order',
            'poq_pct_id'
            # 'preop_questions',
        ]

class PreopFieldTypeSerializer(serializers.ModelSerializer):
    pct_field_label = serializers.SerializerMethodField()

    class Meta:
        model = PreopCheckpointType
        fields = '__all__'

    def get_pct_field_label(self, instance):
        person = self.context['request'].user.user_per_id
        lng_name = UserProfile.objects.get(upr_per= person).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)
        return LanguageTranslation.objects.filter(ltr_tag=instance.pct_field_label, ltr_tag_type=1, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]

