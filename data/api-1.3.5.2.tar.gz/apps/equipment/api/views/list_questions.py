from django.db.models import Prefetch, Count, F
from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import status, viewsets, generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from django.db import connection
from django.core import serializers
from apps.common_utils.views.validate_permission import RolePermission
from apps.equipment.models import EquipmentQuestions, Equipment, EquipmentType
from apps.equipment.api.serializers import GetAllQuestionsSerializer

from apps.incident_management.api.utlity_function import dictfetchall
# Create your views here.
from apps.language.models import Language, LanguageTranslation
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile


class ListQuestions(APIView):
    """ Response for the All  """
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)

    def post(self, request):
        equipment_identifier = request.data['EquipmentID']
        equipment_id = request.data['EquipmentType']
        queryset = Equipment.objects.values().filter(
            EquipmentPreOpEquipmentID=equipment_id, EquipmentIdentifier=equipment_identifier, peqenable=1).distinct().order_by('SortOrder')
        return Response(queryset)


class ListAllQuestions(APIView):
    """ Get a list of all of the Questions  """
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)

    
    def get(self, request):
        person_id = self.request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per_id=person_id).upr_language
        lng_id = Language.objects.get(lng_name=lng_name).lng_id
        queryset = EquipmentQuestions.objects.filter(poq_enable=True).order_by('poq_sort_order')
        serializer_class = GetAllQuestionsSerializer(queryset, many=True)

        ids = set()
        tags_type = set()

        for i in serializer_class.data:
            tag = i['poq_preop_question']
            tag_type = i['poq_tag_type']
            ids.add(tag)
            tags_type.add(tag_type)

        main_trans = LanguageTranslation.objects.filter(
            ltr_tag__in=ids, ltr_tag_type__in=tags_type, ltr_lng_id=lng_id
        ).values('ltr_text', 'ltr_tag_type', 'ltr_tag',)
        final_dic = {}
        final_trans_dic = {}

        main_trans_languages = LanguageTranslation.objects.filter(ltr_tag__in=ids, ltr_tag_type__in=tags_type,
                                                   ).values('ltr_text', 'ltr_tag', 'ltr_lng_id', 'ltr_tag_type', 'ltr_translated')


        for t in main_trans:
            final_dic[t['ltr_tag']] = t['ltr_text']


        for t in main_trans_languages:
            trans = {
                "ltr_lng_id": t['ltr_lng_id'],
                "ltr_text": t['ltr_text'],
                "ltr_translated": t['ltr_translated']
            }
            if str(t['ltr_tag_type']) + str(t['ltr_tag']) in final_trans_dic:
                final_trans_dic[str(t['ltr_tag_type']) + str(t['ltr_tag'])].append(trans)
            else:
                final_trans_dic[str(t['ltr_tag_type']) + str(t['ltr_tag'])] = []
                final_trans_dic[str(t['ltr_tag_type']) + str(t['ltr_tag'])].append(trans)

        for q in serializer_class.data:
            final_lang_key = str(q['poq_tag_type']) + str(q['poq_preop_question'])
            # setdefault will set a value if it is not available, we can use .get as value and return default None
            q['preop_questions'] = final_trans_dic.setdefault(final_lang_key, 'N/A')
            q['poq_preop_question'] = final_dic.setdefault(q['poq_preop_question'], 'N/A')

        questionList = sorted(serializer_class.data, key=lambda d: d['poq_preop_question']) 
        return Response(questionList)


class ListEquipmentQuestions(APIView):
    """ Get all Questions for a particular Type of Equipment  """
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        equipment_id =  request.data['EquipmentType']

        with connection.cursor() as cursor:
            cursor.execute("call get_list_equipment_questions(%s)", (equipment_id,))
            results = dictfetchall(cursor)

        return Response(results)
