from rest_framework.response import Response
from rest_framework.views import APIView
from django.db import connection
from apps.common_utils.views.validate_permission import RolePermission
from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from rest_framework import status


# Create your views here.

class ListAllEquipmentSiteJob(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageLineup.value,)

    def get(self,request ):
        person = self.request.user.user_per_id_id
        try:
            lng_name = UserProfile.objects.get(upr_per_id=person).upr_language
            with connection.cursor() as cursor:
                cursor.execute("call get_all_site_job_equipment_list(%s)", (lng_name,))
                row_data = dictfetchall(cursor)
                return Response(row_data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"message": f"Failed to load the get_all_site_job_equipment_list list. {e}"}, status=status.HTTP_400_BAD_REQUEST)
