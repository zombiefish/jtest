from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import status, viewsets, generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from django.db import connection
from django.core import serializers
from apps.common_utils.views.validate_permission import RolePermission
from apps.equipment.api.serializers import GetAllEquipment
from django.db.models import Max, Count
from apps.equipment.models import Equipment, EquipmentType

from apps.incident_management.api.utlity_function import dictfetchall
from apps.language.models import Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile


# Create your views here.

class ListAllEquipmentSummary(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageLineup.value,)

    def get(self, request, lang):
        person = self.request.user.user_per_id_id
        try:

            lng_name = UserProfile.objects.get(upr_per_id=person).upr_language
            lang_id = Language.objects.get(lng_name=lng_name).lng_id
            with connection.cursor() as cursor:
                cursor.execute("call get_list_equipment_summary(%s)", (lang_id,))
                row_data = dictfetchall(cursor)
                return Response(row_data, status=status.HTTP_200_OK)
            
        except Exception as e:
            return Response({"message": f"Failed to load the list. {e}"}, status=status.HTTP_400_BAD_REQUEST)
