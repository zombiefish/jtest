from django.shortcuts import render
from django.db.models import Prefetch, F, Subquery, OuterRef
from rest_framework.response import Response
from rest_framework import status, viewsets, generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from django.db import connection
from django.core import serializers

from apps.common_utils.views.get_translations import get_translation
from apps.common_utils.views.validate_permission import RolePermission
from apps.equipment.api.serializers import GetAllEquipment
from django.db.models import Max, Count
from apps.equipment.models import Equipment, EquipmentType, PreopEquipmentMeasure
from apps.reflist.models import RefListDetail

from apps.incident_management.api.utlity_function import dictfetchall

# Create your views here.
from apps.language.models import LanguageTranslation, Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile


class ListPreOpMeasureType(APIView):
    """ Response for the All  """
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)

    def get(self, request):  
        person_id = self.request.user.user_per_id_id 
        lng_name = UserProfile.objects.get(upr_per_id=person_id).upr_language
        lng_id = Language.objects.get(lng_name=lng_name).lng_id  
        get_measure_type = RefListDetail.objects.filter(rld_rlh=89, rld_enable=1).values('rld_id','rld_name','rld_tag_type')
        
        get_measure_type = get_measure_type.annotate(
                measure_unit = Subquery(
                    LanguageTranslation.objects.filter(ltr_tag=OuterRef('rld_name'), ltr_tag_type = OuterRef('rld_tag_type'), ltr_lng = lng_id).values('ltr_text')[:1]
                )
            ).values('rld_id','measure_unit')
        return Response(get_measure_type)
