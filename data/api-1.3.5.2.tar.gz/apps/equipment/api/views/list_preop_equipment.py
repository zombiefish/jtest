from rest_framework.views import APIView
from rest_framework.response import Response
from django.db import connection
from apps import equipment
from apps.common_utils.views.validate_permission import RolePermission
from apps.incident_management.api.utlity_function import dictfetchall
from apps.language.models import Language, LanguageTranslation
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile


class GetPreopEquipmentList(APIView): 
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)
    """ Response for the All  """
    def get(self, request, mode):         
        person_id = self.request.user.user_per_id_id  
        self.lng_name = UserProfile.objects.get(upr_per_id=person_id).upr_language
        self.lng_id = Language.objects.get(lng_name = self.lng_name).lng_id

        equipment_list = get_equipment_list(self, mode)
                      
        return Response(equipment_list)


def get_equipment_list(self, mode):
    inactive_label = LanguageTranslation.objects.get(ltr_tag = 3793, ltr_tag_type = 1, ltr_lng_id = self.lng_id).ltr_text

    with connection.cursor() as cursor:
        cursor.execute("call get_preop_equipment_list(%s, %s)", ([self.lng_name], [mode]))
        equipment_list = dictfetchall(cursor)

    if mode == 'all':
        equipment_list = map(lambda obj: add_inactive(obj), equipment_list)

    def add_inactive(obj):
        if obj['status_flag'] == 0:
            obj['poe_equip_description']   = f"{obj['poe_equip_description']} ({inactive_label})"
        return obj

    return equipment_list