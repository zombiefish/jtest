from django.db import connection
import uuid

from django.forms import model_to_dict
from rest_framework import status
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.equipment.models import EquipmentQuestions, Equipment, PreopCheckpointType
from apps.language.api.views.helper_function_add_translation import helperAddTranslation
from apps.language.models import LanguageTranslation, Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile

class UpdateQuestion(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)


    def post(self, request):
        person_id = self.request.user.user_per_id
        lng_name = UserProfile.objects.get(upr_per_id=person_id).upr_language
        lng_id = Language.objects.get(lng_name=lng_name).lng_id
        preop_question_id = request.data.pop('preop_question_id')
        preop_question_tag = request.data.pop('preop_question_tag', None)
        preop_question_identifier = str(uuid.uuid4())
        preop_question_type = request.data.pop('preop_question_type')
        preop_questions = request.data.pop('preop_questions')
        poq_pct_id = request.data.pop('poq_pct_id')
        PreOpQuestion = helperAddTranslation(self, preop_questions)


        # Hard coded sort order does not effect anything. so we are keeping as.

        get_questions = EquipmentQuestions.objects.get(poq_id=preop_question_id)
        get_questions.poq_enable = False
        get_questions.save()

        previous_question_id = get_questions.poq_id

        poq_pct = PreopCheckpointType.objects.get(pct_id=poq_pct_id)

        update_question = EquipmentQuestions.objects.create(poq_preop_identifier=preop_question_identifier, poq_preop_questionmode_id=preop_question_type,
        poq_preop_question=PreOpQuestion, poq_tag_type=2, poq_sort_order=3020, poq_created_by_per_id=person_id, poq_pct_id=poq_pct)
        
        update_questionslookup_ids = Equipment.objects.filter(peq_poq_id=previous_question_id).update(
            peq_poq_id=update_question.poq_id
        )

        return Response({"Received Data": request.data, "ID": update_question.poq_id},
                        status=status.HTTP_201_CREATED)
