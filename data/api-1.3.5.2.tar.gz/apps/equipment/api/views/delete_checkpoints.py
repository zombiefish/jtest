from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.equipment.models import EquipmentType, EquipmentQuestions, Equipment
from apps.person.models import Person
from django.db import transaction

from datetime import datetime

from apps.sofvie_user_authorization.api.permissions import SofviePermission, \
    SofvieBasePermissionMixin

datetime.now()


class DeleteCheckpoints(APIView, SofvieBasePermissionMixin):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.ArchiveSubmissions.value, RolePermission.CanManageEquipmentPreops.value)

    @transaction.atomic()
    def post(self, request):
        person_id = self.request.user.user_per_id_id

        question_id = request.data['PreOpQuestionID']        

        EquipmentQuestions.objects.filter(
            poq_id=question_id,
        ).update(
            poq_enable=False,
            poq_modified_by_per_id=person_id,
            poq_archived_date=datetime.now(),
            poq_archived_by_per_id=person_id
        )

        Equipment.objects.filter(
            peq_poq_id=question_id,
        ).update(
            peq_enable=False,
            peq_modified_by_per_id=person_id,
            peq_archived_date=datetime.now(),
            peq_archived_by_per_id=person_id
        )


        return Response({"message": f"Equipment question deleted successfully {question_id}"})
