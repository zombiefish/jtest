from django.db import connection
from rest_framework import status
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.equipment.models import Equipment, EquipmentType
from apps.language.api.views.helper_function_add_translation import helperAddTranslation
from apps.person.models import Person

from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class InsertEquipmentType(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)

    # parser_classes = [JSONParser]

    def post(self, request):
        personID = self.request.user.user_per_id_id
        equipment_type_names = request.data['equipment_type_names']
        equip_desc = helperAddTranslation(self, equipment_type_names)
        addEquipmentType = EquipmentType.objects.create(
            poe_equip_description=equip_desc,
            poe_tag_type = 2)
        addEquipmentType.save()
        return Response({"Received Data": request.data,
                         "ID": addEquipmentType.poe_id},
                        status=status.HTTP_201_CREATED)
