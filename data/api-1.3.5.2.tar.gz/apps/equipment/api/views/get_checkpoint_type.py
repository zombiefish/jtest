from rest_framework.generics import ListCreateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.equipment.api.serializers import PreopFieldTypeSerializer
from apps.equipment.models import PreopCheckpointType
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class GetItemType(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)

    def get(self, request):
        queryset = PreopCheckpointType.objects.all()
        serializer_class = PreopFieldTypeSerializer(queryset, context={'request': request}, many=True)

        return Response(serializer_class.data)
