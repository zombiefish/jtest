from django.db import connection
from django.forms import model_to_dict
from rest_framework import status
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.equipment.models import Equipment, EquipmentType, EquipmentQuestions, PreopEquipmentType
from apps.language.api.views.helper_function_add_translation import helperAddTranslation
from apps.person.models import Person

from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class UpdateEquipmentType(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)

    # parser_classes = [JSONParser]

    def post(self, request):
        personID = self.request.user.user_per_id
        preop_equipment_type_id = request.data.pop('preop_equipment_id')
        equipment_type_names = request.data.pop('equipment_type_names')

        # set record enable to false
        get_preop_equipment_type = EquipmentType.objects.get(poe_id=preop_equipment_type_id)
        get_preop_equipment_type.poe_enable = False
        get_preop_equipment_type.save() 
        
        old_preop_equipment_type_poe_id = get_preop_equipment_type.poe_id

        # Insert EquipmentType - get new translations then create new record for 'EquipmentType'
        equip_desc = helperAddTranslation(self, equipment_type_names)
        new_equipmentType_poe_id = EquipmentType.objects.create(poe_equip_description=equip_desc, poe_tag_type=2, poe_created_by_per=personID)

        # update PreopEquipmentType record update with new 'poe_id'
        PreopEquipmentType.objects.filter(pet_poe_id=old_preop_equipment_type_poe_id).update(
            pet_poe_id=new_equipmentType_poe_id.poe_id
        )

        return Response({"Received Data": request.data,
                         "ID": new_equipmentType_poe_id.poe_id},
                        status=status.HTTP_201_CREATED)


     