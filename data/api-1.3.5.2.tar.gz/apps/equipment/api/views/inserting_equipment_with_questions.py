from django.db import connection
import uuid
from rest_framework import status
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.equipment.models import EquipmentQuestions,PreopCheckpointType
from apps.language.api.views.helper_function_add_translation import helperAddTranslation
from apps.language.models import LanguageTranslation, Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile


class InsertEquipmentWithQuestions(APIView):
    permission_classes = [SofviePermission]
    parser_classes = [JSONParser]

    def post(self, request):
        modified_by = self.request.user.user_per_id_id
        preop_question_type = request.data['preop_question_type']
        preop_questions = request.data['preop_questions']
        with connection.cursor() as cursor:
            cursor.execute("call add_questions_by_equipment_type("
                           "%s,%s,%s)", (preop_question_type, preop_questions,
                                         modified_by,))

        return Response({"data received": request.data},
                        status=status.HTTP_201_CREATED)
        
class InsertQuestion(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)

    def post(self, request):
        person_id = self.request.user.user_per_id_id

        preop_question_type = request.data.pop('preop_question_type')
        poq_pct_id = request.data.pop('poq_pct_id')
        preop_questions = request.data.pop('preop_questions')
        preop_question_tag = str(uuid.uuid4())
        PreOpQuestion = helperAddTranslation(self, preop_questions)
        poq_pct = PreopCheckpointType.objects.get(pct_id=poq_pct_id)

        # Hard coded sort order does not effect anything. so we are keeping as.
        addCheckpoint = EquipmentQuestions.objects.create(poq_preop_identifier=preop_question_tag, poq_preop_questionmode_id=preop_question_type,
                                                          poq_preop_question=PreOpQuestion,poq_tag_type=2, 
                                                          poq_sort_order=3020, poq_pct_id=poq_pct)

        addCheckpoint.save()
        return Response({"Received Data": request.data, "ID": addCheckpoint.poq_id},
                         status=status.HTTP_201_CREATED)