from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.equipment.models import EquipmentType, EquipmentQuestions, Equipment, PreopEquipmentType
from apps.person.models import Person
from django.db import transaction

from datetime import datetime

from apps.sofvie_user_authorization.api.permissions import SofviePermission, \
    SofvieBasePermissionMixin

class DeleteEquipmentQuestions(APIView, SofvieBasePermissionMixin):    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.ArchiveSubmissions.value, RolePermission.CanManageEquipmentPreops.value)

    def post(self, request):
        person_id = self.request.user.user_per_id_id

        try:

            equipment_id = request.data['EquipmentID']
            equipment_type = request.data['EquipmentType']        
            peq_pet_id = request.data['peq_pet_id']

            entries = Equipment.objects.filter(
                peq_pet_id = peq_pet_id
            ).update(
                peq_enable = False,
                peq_archived_date = datetime.now(),
                peq_archived_by_per_id = person_id            
            )

            PreopEquipmentType.objects.filter(pet_id=peq_pet_id).update(
                pet_enable=False,
                pet_modified_date=datetime.now(),
                pet_modified_by_per_id=person_id
            )
        
            return Response({"message": f"Equipment Identifier-> {equipment_id} "
                                        f"and Equipment Type-> {equipment_type}"
                                        f"and peq_pet_id -> {peq_pet_id}"
                                        f" removed successfully"})
        except Exception as e:
            return Response({"message": "archive failed"},
                            status=status.HTTP_400_BAD_REQUEST)
