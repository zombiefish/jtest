from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db import connection

from apps.incident_management.api.utlity_function import dictfetchall
from apps.language.models import Language
from apps.user_settings_profile.models import UserProfile


class GetFullEquipmentList(APIView):

    def get(self, request):
        try:
            self.person_instance = self.request.user.user_per_id
            self.language = UserProfile.objects.get(upr_per = self.person_instance).upr_language
            self.lng_id = Language.objects.get(lng_name = self.language).lng_id

            full_equipment_list = get_full_equipment_list(self.lng_id)            

            return Response(full_equipment_list, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({"messgae": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        

def get_full_equipment_list(lng_id, mode = 'all'):

    with connection.cursor() as cursor:
        cursor.execute("call rpt_get_full_equipment_list(%s)", ([lng_id]))
        full_equipment_list = dictfetchall(cursor)   

    
    if mode == 'allactive':
        active_full_equipment_list = [equipment for equipment in full_equipment_list if equipment['pet_enable'] == True]
        return active_full_equipment_list

    return full_equipment_list
