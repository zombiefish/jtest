from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import status, viewsets, generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from django.db import connection
from django.core import serializers

from apps.common_utils.views.get_translations import get_translation
from apps.common_utils.views.validate_permission import RolePermission
from apps.equipment.api.serializers import GetAllEquipment
from django.db.models import Max, Count
from apps.equipment.models import Equipment, PreopEquipmentMeasure, PreopEquipmentSiteJob
from apps.reflist.models import RefListDetail

from apps.incident_management.api.utlity_function import dictfetchall

# Create your views here.
from apps.language.models import LanguageTranslation, Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from django.db.models import Prefetch

class ListAllEquipment(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)

    def get(self, request):
        person_id = self.request.user.user_per_id_id

        lng_name = UserProfile.objects.get(upr_per_id=person_id).upr_language
        lng_id = Language.objects.get(lng_name=lng_name).lng_id

        queryset = Equipment.objects.filter(
            peq_pet_id__isnull=False, peq_enable=True, peq_pet_id__pet_enable=True).annotate(
            question_count=Count('peq_poq_id'),
            last_modified_date=Max('peq_modified_date'),
            last_modified_first_name=Max('peq_modified_by_per_id__per_first_name'),
            last_modified_last_name=Max('peq_modified_by_per_id__per_last_name'),
            equipment_desc=Max('peq_pet_id__pet_poe_id__poe_equip_description'),
            poe_tag_type=Max('peq_pet_id__pet_poe_id__poe_tag_type'),
            last_modified_by=Max('peq_modified_by_per_id')
            ).values('peq_pet_id__pet_equipment_identifier',
                    'peq_pet_id__pet_poe_id',
                    'peq_poq_id',
                    'peq_poq_id__poq_preop_question', 
                    'peq_sort_order', 
                    'peq_poq_id__poq_tag_type',
                    'equipment_desc',
                    'poe_tag_type',
                    'last_modified_first_name',
                    'last_modified_last_name',
                    'last_modified_date',
                    'peq_poq_id__poq_pct_id',
                    'peq_pet_id').order_by('peq_pet_id__pet_equipment_identifier',)

        queryset_measure = PreopEquipmentMeasure.objects.filter(
            pem_pet_id__pet_equipment_identifier__isnull=False, pem_enable=True
            ).prefetch_related(
                Prefetch('pem_rld_measure_id_id',
                    RefListDetail.objects.filter().only(
                        'rld_tag_type'))
            ).values('pem_pet_id__pet_poe_id',
                    'pem_pet_id__pet_equipment_identifier',
                    'pem_rld_measure_id')
        
        queryset_site_job = PreopEquipmentSiteJob.objects.filter(
            psj_enable=True
        ).values("psj_pet_id","psj_rld_site_id","psj_rld_job_id")

        # need to send in sort order preop questions
        # in this object send the sort order as well preop_questions:[{}]
        ids = set()
        tags_type = set()

        for i in queryset:
            tag = i['equipment_desc']
            tag_type = i['poe_tag_type']

            ids.add(tag)
            tags_type.add(tag_type)

            tag = i['peq_poq_id__poq_preop_question']
            tag_type = i['peq_poq_id__poq_tag_type']

            ids.add(tag)
            tags_type.add(tag_type)

        temp = LanguageTranslation.objects.filter(ltr_tag__in=ids, ltr_tag_type__in=tags_type, ltr_lng_id=lng_id
                                                  ).values('ltr_text', 'ltr_tag_type', 'ltr_tag')
        final_dic = {}

        for t in temp:
            final_dic[str(t['ltr_tag_type']) + str(t['ltr_tag'])] = t['ltr_text']

        for q in queryset:
            # setdefault will set a value if it is not available, we can use .get as value and return default None
            preop_question_key = str(q['peq_poq_id__poq_tag_type']) + str(q['peq_poq_id__poq_preop_question'])
            equip_desc_key = str(q['poe_tag_type']) + str(q['equipment_desc'])

            q['peq_poq_id__poq_preop_question'] = final_dic.setdefault(preop_question_key, 'N/A')
            q['equipment_desc'] = final_dic.setdefault(equip_desc_key, 'N/A')

        out_put_data=[queryset,queryset_measure,queryset_site_job]

        return Response(out_put_data)
