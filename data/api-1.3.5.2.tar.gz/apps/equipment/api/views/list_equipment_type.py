from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import status, viewsets, generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from django.db import connection
from django.core import serializers
from apps.common_utils.views.validate_permission import RolePermission
from apps.equipment.models import Equipment, EquipmentType, EquipmentQuestions
from apps.language.models import Language, LanguageTranslation
from apps.person.models import Person

from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission
# Create your views here.
from apps.user_settings_profile.models import UserProfile


class ListEquipmentType(APIView):
    """ Get a Let of all of the Equipment types  """
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)
    def get(self, request):
        person_id = self.request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per_id=person_id).upr_language
        lng_id = Language.objects.get(lng_name=lng_name).lng_id

        queryset = EquipmentType.objects.filter(poe_enable=True).values('poe_id', 'poe_equip_description', 'poe_tag_type').order_by('poe_equip_description')

        ids = set()
        tags_type = set()

        for i in queryset:
            tag = i['poe_equip_description']
            tag_type = i['poe_tag_type']

            ids.add(tag)
            tags_type.add(tag_type)

        temp = LanguageTranslation.objects.filter(
            ltr_tag__in=ids, ltr_tag_type__in=tags_type, ltr_lng_id=lng_id).values(
            'ltr_text', 'ltr_tag_type', 'ltr_tag', 'ltr_lng_id', 'ltr_translated')

        final_dic = {}
        final_trans_dic = {}

        main_trans_languages = LanguageTranslation.objects.filter(ltr_tag__in=ids, ltr_tag_type__in=tags_type,
                                                                  ).values('ltr_text', 'ltr_tag', 'ltr_lng_id', 'ltr_tag_type', 'ltr_translated')
        for t in temp:
            final_dic[str(t['ltr_tag_type']) + str(t['ltr_tag'])] = t['ltr_text']

        for t in main_trans_languages:
            trans = {
                "ltr_lng_id": t['ltr_lng_id'],
                "ltr_text": t['ltr_text'],
                "ltr_translated": t['ltr_translated']
            }
            if str(t['ltr_tag_type']) + str(t['ltr_tag']) in final_trans_dic:
                final_trans_dic[str(t['ltr_tag_type']) + str(t['ltr_tag'])].append(trans)
            else:
                final_trans_dic[str(t['ltr_tag_type']) + str(t['ltr_tag'])] = []
                final_trans_dic[str(t['ltr_tag_type']) + str(t['ltr_tag'])].append(trans)

        for q in queryset:
            final_lang_key = str(q['poe_tag_type']) + str(q['poe_equip_description'])
            # setdefault will set a value if it is not available, we can use .get as value and return default None
            # q['EquipmentPreOpQuestionID__PreOpQuestion'] = final_dic.setdefault(q['EquipmentPreOpQuestionID__PreOpQuestion'], 'N/A')
            q['equipment_descriptions'] = final_trans_dic.setdefault(final_lang_key, 'N/A')
            q['EquipDesc'] = final_dic.setdefault(final_lang_key, 'N/A')
            # q['equipment_descriptions'] = temp

        return Response(queryset)





