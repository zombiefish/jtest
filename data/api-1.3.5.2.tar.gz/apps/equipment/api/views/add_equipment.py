from rest_framework import status
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.equipment.models import Equipment, EquipmentType, EquipmentQuestions, PreopEquipmentMeasure, PreopEquipmentSiteJob, PreopEquipmentType
from apps.person.models import Person
from apps.reflist.models import RefListDetail

from datetime import datetime

from apps.sofvie_user_authorization.api.permissions import SofviePermission


class AddEquipmentWithQuestions(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)
    parser_classes = [JSONParser]

    def post(self, request):
        person_id = self.request.user.user_per_id_id

        equipment_identifier = request.data['EquipmentID']
        equipment_type_poe_id = request.data['EquipmentType']
        questions = request.data['questions']
        measures = request.data['pem_measure_rld_id']
        equip_site = request.data['equipment_site']
        equip_jobs = request.data['equipment_jobs']

        equipment_type_id = EquipmentType.objects.get(poe_id=equipment_type_poe_id)
        person = Person.objects.get(per_id=person_id)

        # insert into PreopEquipmentType
        preop_equip_type_id = PreopEquipmentType.objects.create(pet_equipment_identifier=equipment_identifier,
                                                   pet_poe_id=equipment_type_id,
                                                   pet_created_by_per_id=person,
                                                   pet_created_date=datetime.now())
      
        # preop_equipment_type_pet_id = PreopEquipmentType.objects.get(pet_poe_id=equipment_type_poe_id)
        for question in questions:
            pre_op_question = EquipmentQuestions.objects.get(poq_id=question['ID'])
            Equipment.objects.create(
                peq_pet_id=preop_equip_type_id,
                peq_poq_id=pre_op_question,
                peq_created_by_per_id=person,
                peq_created_date=datetime.now(),
                peq_sort_order=question['SortOrder']
            )

        if measures:    
            for measure in measures:
                measue_unit = RefListDetail.objects.get(rld_id=measure)
                PreopEquipmentMeasure.objects.create(
                    pem_pet_id = preop_equip_type_id,
                    pem_rld_measure_id=measue_unit,
                    pem_created_by_per_id=person,
                    pem_created_date=datetime.now()
                )
        
        # create records into preop_equipment_site_job table
        if equip_site:
            site_rld = RefListDetail.objects.get(rld_id=equip_site)
            if site_rld and equip_jobs: 
                rld_jobs = RefListDetail.objects.filter(rld_id__in=equip_jobs)
                PreopEquipmentSiteJob.objects.bulk_create([PreopEquipmentSiteJob(
                        psj_pet_id = preop_equip_type_id,
                        psj_rld_site_id = site_rld,
                        psj_rld_job_id = rld_job,
                        psj_created_by_per_id = person,
                        psj_created_date = datetime.now()
                ) for rld_job in rld_jobs])
            else:
                PreopEquipmentSiteJob.objects.create(
                psj_pet_id = preop_equip_type_id,
                psj_rld_site_id = site_rld,
                psj_rld_job_id = None,
                psj_created_by_per_id = person,
                psj_created_date = datetime.now()
            )
        else:
            PreopEquipmentSiteJob.objects.create(
                psj_pet_id = preop_equip_type_id,
                psj_rld_site_id = None,
                psj_rld_job_id = None,
                psj_created_by_per_id = person,
                psj_created_date = datetime.now()
            )

        return Response({"received _data": request.data,"pet_id":preop_equip_type_id.pet_id,
                         "Status Code": status.HTTP_201_CREATED})
