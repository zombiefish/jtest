from django.db import connection
from django.forms import model_to_dict
from rest_framework import status
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.equipment.models import Equipment, EquipmentType, EquipmentQuestions, PreopEquipmentType
from apps.language.api.views.helper_function_add_translation import helperAddTranslation
from apps.person.models import Person
from django.db.models import Q

from apps.incident_management.api.utlity_function import dictfetchall
import itertools

from apps.sofvie_user_authorization.api.permissions import SofviePermission

class PreopBulkEdit(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)

    # parser_classes = [JSONParser]

    def post(self, request):
        equipmentIds = self.request.data['EquipmentIDs']

        questionsAdd = self.request.data['PreOpQuestionIDs_Add']
        questionsRemove = self.request.data['PreOpQuestionIDs_Remove']
        equipment_types = {i['PreOpEquipmentID']:
                EquipmentType.objects.get(poe_id=i['PreOpEquipmentID'],) for i in equipmentIds
                    }

        add_questions = {}
        remove_questions = {}
        
        for equipments in equipmentIds:
            equipmentId, equipmentIdentifier = equipments['PreOpEquipmentID'], equipments['EquipmentIdentifier']
            equipmentType = equipment_types[equipmentId]

            # Add
            for addId in questionsAdd:

                if addId in add_questions.keys():
                    question = add_questions[addId]
                else:

                    question = EquipmentQuestions.objects.get(poq_id=addId)
                    add_questions[addId] = question
                equip_object = Equipment.objects.filter(
                    peq_pet_id__pet_poe_id=equipmentType,
                    peq_poq_id=question,
                    peq_pet_id__pet_equipment_identifier=equipmentIdentifier,
                )
                equip_pet = PreopEquipmentType.objects.get(
                    pet_poe_id=equipmentType,
                    pet_equipment_identifier=equipmentIdentifier,
                )

                if not equip_object.exists():
                    Equipment.objects.create(
                        peq_pet_id=equip_pet,
                        peq_poq_id=question,
                        peq_enable=1
                    )
                elif not equip_object[0].peq_enable:
                    equip_object.update(peq_enable=1)
                    for i in equip_object:
                        i.save()

                    equip_object = Equipment.objects.filter(
                        peq_pet_id__pet_poe_id=equipmentType,
                        peq_poq_id=question,
                        peq_pet_id__pet_equipment_identifier=equipmentIdentifier,
                    )

            # Remove 
            for removeId in questionsRemove:
                if removeId in remove_questions.keys():
                    question = remove_questions[removeId]
                else:
                    question = EquipmentQuestions.objects.get(poq_id = removeId)
                    remove_questions[removeId] = question

                try:
                    equip_object = Equipment.objects.get(
                        peq_pet_id__pet_poe_id=equipmentType,
                        peq_poq_id=question,
                        peq_pet_id__pet_equipment_identifier=equipmentIdentifier,
                        peq_enable=1
                    )
                    equip_object.peq_enable = 0
                    equip_object.save()
                except:
                    # this object doesn't exist
                    pass

        return Response("ok")