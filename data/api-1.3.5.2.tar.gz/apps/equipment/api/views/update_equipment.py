import json
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.equipment.models import EquipmentType, EquipmentQuestions, Equipment, PreopEquipmentMeasure, PreopEquipmentSiteJob, PreopEquipmentType
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from django.db import transaction

from datetime import datetime

from apps.sofvie_user_authorization.api.permissions import SofviePermission

class UpdateEquipmentQuestions(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageEquipmentPreops.value,)

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        try:            
            questions = request.data['questions']            
            preop_equip_type = request.data['peq_pet_id']
            equipment_site = request.data.get('equipment_site',[])
            equipment_jobs = request.data.get('equipment_jobs',[])
            pem_rld_measure_ids = request.data.get('pem_measure_rld_id',[])

            
            originalCreatedBy = Equipment.objects.filter(peq_pet_id=preop_equip_type).first().peq_created_by_per_id
            originalCreatedDate = Equipment.objects.filter(peq_pet_id=preop_equip_type).first().peq_created_date


            Equipment.objects.filter(peq_pet_id=preop_equip_type).update(peq_enable=False)

            person = Person.objects.get(per_id=person_id)         
            preop_equip_type_id = PreopEquipmentType.objects.get(pet_id=preop_equip_type)

            
            for question in questions:
                pre_op_question = EquipmentQuestions.objects.get(poq_id=question['ID'])

                entry = Equipment(
                    peq_pet_id=preop_equip_type_id,
                    peq_poq_id=pre_op_question,
                    peq_created_date=originalCreatedDate,
                    peq_modified_date=datetime.now(),
                    peq_created_by_per_id=originalCreatedBy,
                    peq_modified_by_per_id=person,
                    peq_sort_order=question['SortOrder']
                )
                entry.save()

            get_measure_units=PreopEquipmentMeasure.objects.filter(pem_pet_id=preop_equip_type_id)

            existing_unit_list=[]
            for unit in get_measure_units:
                rld_id_value=getattr(getattr(unit, 'pem_rld_measure_id'),'rld_id')
                if rld_id_value not in pem_rld_measure_ids:
                    unit.delete()
                else:
                    if rld_id_value in existing_unit_list:
                        unit.delete()
                    else:
                        existing_unit_list.append(rld_id_value)
            
            get_measure_units.update(pem_modifier_by_per_id=person,pem_modified_date=datetime.now())

            for pem_rld_measure_id in pem_rld_measure_ids:

                if pem_rld_measure_id not in existing_unit_list:
                    measure_unit=RefListDetail.objects.get(rld_id=pem_rld_measure_id)
                    entry = PreopEquipmentMeasure(
                        pem_pet_id=preop_equip_type_id,
                        pem_rld_measure_id=measure_unit,
                        pem_created_by_per_id=person,
                        pem_created_date=datetime.now()
                    )
                    entry.save()
            

            qs = Equipment.objects.filter(peq_pet_id=preop_equip_type, peq_enable=True).values_list("peq_poq_id",flat=True)


            # *********************  update site jobs table - disable and create new records ****************************
            equipment_site_jobs=PreopEquipmentSiteJob.objects.filter(psj_pet_id=preop_equip_type,psj_enable=True).values("psj_pet_id","psj_rld_site_id","psj_rld_job_id")
            rec_pet=PreopEquipmentType.objects.get(pet_id=preop_equip_type)
            is_new_site=False

            # Validate the site change or not 
            # If site changed then disable all the records

            # equipment_site_jobs is empty,means treat it as fresh entry
            if not equipment_site_jobs:
                is_new_site=True
            else:
                # disable the records first,then set flag as "New Entry"
                equip_sj=equipment_site_jobs.first()
                if equip_sj["psj_rld_site_id"]!=equipment_site:
                    PreopSiteJobOperation('UPDATE',equipment_site_jobs,None,None,person,rec_pet)
                    is_new_site=True

            # ********************* New Site/Job ********************************************
            # payload with new site,so need to insert all records
            if is_new_site:
                # validate payload site is empty or not
                if equipment_site:
                    site_rld = RefListDetail.objects.get(rld_id=equipment_site)
                    # validate payload jobs empty or not
                    if equipment_jobs:
                        for job_rld_id in equipment_jobs:
                            job_rld = RefListDetail.objects.get(rld_id=job_rld_id)
                            PreopSiteJobOperation('CREATE',None,site_rld,job_rld,person,rec_pet)
                    else:
                        # if payload job is empty,then create a record with payload site and job as null
                        PreopSiteJobOperation('CREATE',None,site_rld,None,person,rec_pet)
                else:
                    # if payload site is empty,then create a record with site and job as null
                    PreopSiteJobOperation('CREATE',None,None,None,person,rec_pet)

            # ********************* Edit/Update Site and Job ********************************
            # If not with new site,then need to check the jobs are new or not
            if not is_new_site:
                preop_psj_job_list = []
                # do the operation if only when payload equipmentSite is not empty
                if equipment_site:
                    site_rld = RefListDetail.objects.get(rld_id=equipment_site)

                    for psj in list(equipment_site_jobs):
                        if psj['psj_rld_job_id']:
                            preop_psj_job_list.append(psj['psj_rld_job_id'])

                    if preop_psj_job_list:
                        to_disable_records = list(set(preop_psj_job_list).difference(equipment_jobs))
                        to_insert_new_records = list(set(equipment_jobs).difference(preop_psj_job_list))
                        common_id_to_update =list( set(preop_psj_job_list).intersection(set(equipment_jobs)))

                        # Disable the records not available in payload
                        if to_disable_records:
                            for job_id in to_disable_records:
                                job_rld = RefListDetail.objects.get(rld_id=job_id)
                                PreopEquipmentSiteJob.objects.filter(psj_pet_id = preop_equip_type,psj_enable =True,psj_rld_job_id=job_rld).update(
                                    psj_enable= False,
                                    psj_modified_date=datetime.now(),
                                    psj_modified_by_per_id = person
                                )

                        # Insert new jobs from the payload
                        if to_insert_new_records:
                            for job_rld_id in to_insert_new_records:
                                job_rld = RefListDetail.objects.get(rld_id=job_rld_id)
                                PreopSiteJobOperation('CREATE',None,site_rld,job_rld,person,rec_pet)
                        
                        # updating existing record with modified date and per_id 
                        if common_id_to_update:
                            for job_id in common_id_to_update:
                                job_rld = RefListDetail.objects.get(rld_id=job_id)
                                PreopEquipmentSiteJob.objects.filter(psj_pet_id = preop_equip_type,psj_enable =True,psj_rld_job_id=job_rld).update(
                                    psj_modified_date=datetime.now(),
                                    psj_modified_by_per_id = person
                                )

                        # if there is no records new records and common records not available
                        if not to_insert_new_records and not common_id_to_update:
                            PreopSiteJobOperation('CREATE',None,site_rld,None,person,rec_pet)
                    else:
                        # disable all other records,because of job is null in db
                        if equipment_site_jobs:
                            PreopSiteJobOperation('UPDATE',equipment_site_jobs,None,None,person,rec_pet)

                        for job_rld_id in equipment_jobs:
                            job_rld = RefListDetail.objects.get(rld_id=job_rld_id)
                            # create fresh records
                            PreopSiteJobOperation('CREATE',None,site_rld,job_rld,person,rec_pet)
            
            transaction.commit()
            return Response(
                {"received_data": qs,"status":
                    f"data updated successfully with code-> {status.HTTP_200_OK}"})
        
        except Exception as e:
            return Response({"message": f"Failed to update equipment. {e}"}, status=status.HTTP_400_BAD_REQUEST)

     

def PreopSiteJobOperation(perform_operation,qs_equipment_site_jobs,sites,jobs,person,pet):
    if perform_operation == 'UPDATE':
        qs_equipment_site_jobs.update(
            psj_enable= False,
            psj_modified_date=datetime.now(),
            psj_modified_by_per_id = person
        )
    elif perform_operation == 'CREATE':
        PreopEquipmentSiteJob.objects.create(
            psj_pet_id = pet,
            psj_rld_site_id = sites,
            psj_rld_job_id = jobs,
            psj_created_by_per_id = person,
            psj_created_date = datetime.now()
        ) 
