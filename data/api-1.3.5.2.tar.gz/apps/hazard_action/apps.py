from django.apps import AppConfig


class HazardActionConfig(AppConfig):
    name = 'apps.hazard_action'
