from django.db import models

from apps.general_action.models import Submissionheader, Formdescription
from apps.person.models import Person
from apps.form.models import Formcategories
from django.utils import timezone
from apps.common_utils.views.sofvieModelFields import SofvieCharField, SofvieIntegerField, SofvieTextField
from django.db.models import (
    Model,
    AutoField,
    IntegerField,
    CharField,
    DateTimeField,
    ForeignKey,
    ManyToManyField,
    BooleanField,
    TextField,
    DateField,
    SlugField,
    DecimalField, F, Value
)

from apps.reflist.models import RefListDetail


class Submissionhap(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)
    submissionheaderid = models.ForeignKey(Submissionheader, models.DO_NOTHING,
                                           db_column='SubmissionHeaderID',
                                           related_name='submission_hap'
                                           )  # Field name made lowercase.
    hazard_type = SofvieIntegerField(blank=True, null=True,
                                   db_index=True)
    hazard_identification = SofvieIntegerField(blank=True,
                                             null=True, db_index=True)
    hazard_description = SofvieTextField(blank=True, null=True)
    potential_risk = SofvieIntegerField(blank=True, null=True)
    immediate_action_required_and_performed = models.BooleanField(blank=True,
                                                               null=True,
                                                                  default=False)

    immediate_action_taken = SofvieTextField(blank=True, null=True)
    immediate_action_type = SofvieIntegerField(blank=True, null=True, db_index=True)
    further_action_required = models.BooleanField(blank=True, null=True,
                                                  default=False)
    recommended_action = SofvieTextField(blank=True, null=True)
    action_type = SofvieIntegerField(blank=True, null=True,
                                   db_index=True)
    action_by_who = SofvieTextField(blank=True, null=True)
    action_by_when = models.DateField(blank=True, null=True, db_index=True)
    action_status = SofvieCharField(max_length=200, blank=True, null=True,
                                     db_index=True)
    sha_is_group_action = models.BooleanField(default=False)
    action_complete_by_who = SofvieTextField(blank=True, null=True
                                              )
    action_completed_date = models.DateField(blank=True, null=True
                                             )
    completed_action_taken = SofvieTextField(blank=True, null=True)

    completed_action_type = SofvieIntegerField(blank=True,null=True, db_index=True)
    
    hazard_identification_score = SofvieIntegerField(blank=True, null=True,
                                                      db_index=True)
    potential_risk_score = SofvieIntegerField(blank=True, null=True,
                                               db_index=True)
    immediate_action_score = SofvieIntegerField(blank=True, null=True,
                                                 db_index=True)
    completed_action_score = SofvieIntegerField(blank=True, null=True,
                                                 db_index=True)
    is_native_system = models.BooleanField(blank=True, null=True,
                                           default=False)

    sha_created_date = models.DateTimeField(auto_now=True, blank=True, null=True)
    sha_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='sha_created_by_per')
    sha_modified_date = models.DateTimeField(auto_now=True, blank=True, null=True)
    sha_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='sha_modified_by_per')
    sha_archived_date = models.DateTimeField(blank=True, null=True)
    sha_archived_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='sha_archived_by_per')                                            
    sha_enable = models.BooleanField(default=True)
    sha_enote = SofvieTextField(blank=True, null=True)

    class Meta:

        db_table = 'SubmissionHAP'

    # def __str__(self):
    #     return self.sha_created_by_per.full_name


    def only_enable_haa_attachment(self):
        return Submissionhapattachments.objects.filter(submissionhapid=self,
                                                                haa_enable=1)





class Submissiondetails(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)
    submissionheaderid = models.ForeignKey(Submissionheader, models.DO_NOTHING,
                                           db_column='SubmissionHeaderID',
                                           related_name='submission_detail'
                                           )
    details = SofvieTextField(db_column='Details')

    class Meta:
        db_table = 'SubmissionDetails'


class Formfielddescription(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)
    formdescriptionid = models.ForeignKey(Formdescription, models.DO_NOTHING,
                                          db_column='FormDescriptionID',
                                          related_name='form_field_description'
                                          )
    xpath = SofvieTextField(db_column='XPath')
    fieldkey = SofvieCharField(db_column='fieldKey', max_length=100,
                                db_index=True)
    fieldname = SofvieIntegerField(db_column='fieldName')
    fieldtype = SofvieCharField(db_column='fieldType', max_length=50,
                                 db_index=True)
    fieldvaluetype = SofvieCharField(db_column='fieldValueType',
                                      max_length=50, db_index=True)
    fieldorder = SofvieIntegerField(db_column='FieldOrder', db_index=True)
    sectionname = SofvieIntegerField(db_column='SectionName', 
                                   blank=True, null=True, db_index=True)
    fieldnameoverride = SofvieTextField(db_column='FieldNameOverride',
                                         blank=True, null=True)
    fieldvisibleoverride = SofvieTextField(db_column='FieldVisibleOverride',
                                            blank=True, null=True)
    fieldwidthoverride = models.SmallIntegerField(
        db_column='FieldWidthOverride', blank=True, null=True, db_index=True)
    allowmultiple = SofvieTextField(db_column='AllowMultiple', blank=True,
                                     null=True)
    formsubid = SofvieIntegerField(db_column='FormSubID', blank=True,
                                    null=True, db_index=True)

    class Meta:
        db_table = 'FormFieldDescription'


class Formsub(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)
    subformkey = SofvieCharField(db_column='SubformKey', unique=True,max_length=200, db_index=True)
    sortorder = models.DecimalField(db_column='SortOrder', max_digits=7,
                                    decimal_places=2, blank=True, null=True,
                                    db_index=True)
    formcategoryid = models.ForeignKey(Formcategories, models.DO_NOTHING,
                                       db_column='FormCategoryId',
                                       blank=True, null=True,
                                       related_name='form_sub')

    class Meta:
        db_table = 'FormSub'


class Formsubdescription(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)
    formdescriptionid = models.ForeignKey(Formdescription, models.DO_NOTHING,
                                          db_column='FormDescriptionID',
                                          related_name='form_sub_description'
                                          )
    subformname = SofvieIntegerField(db_column='SubformName', db_index=True)
    subformkey = models.ForeignKey(Formsub, models.DO_NOTHING,
                                   db_column='SubformKey',
                                   blank=True, null=True,
                                   related_name='form_sub_description_subform')

    class Meta:
        db_table = 'FormSubDescription'


class SubmissiondetailsExplodeSection(models.Model):
    id = models.BigAutoField(db_column='ID', primary_key=True)
    formsubdescriptionid = models.ForeignKey(Formsubdescription,
                                             models.DO_NOTHING,
                                             db_column='FormSubDescriptionID',
                                             related_name='submission_detail_explode_section')

    submissiondetailsid = models.BigIntegerField(db_column='SubmissionDetailsID', db_index=True)
    sectionnumber = SofvieIntegerField(db_column='SectionNumber', db_index=True)

    class Meta:
        db_table = 'SubmissionDetails_Explode_Section'


class SubmissiondetailsExplode(models.Model):
    id = models.BigAutoField(db_column='ID', primary_key=True)
    submissiondetailid = models.ForeignKey(Submissiondetails, models.DO_NOTHING,
                                           db_column='SubmissionDetailID',
                                           related_name='submission_detail_explode'
                                           )
    formfielddescriptionid = models.ForeignKey(Formfielddescription,
                                               models.DO_NOTHING,
                                               db_column='FormFieldDescriptionID',
                                               related_name='submission_detail_explode_formfielddescriptionid')  # Field name made lowercase.
    value = SofvieTextField(db_column='Value', blank=True, null=True)
    # value = models.ForeignKey(Person, db_column='Value', to_field='per_id', null=True, on_delete=models.SET_NULL, db_constraint=False)
    sde_image_timestamp = models.DateTimeField(blank=True, null=True,
        db_index=True)
    explode_section = models.ForeignKey(SubmissiondetailsExplodeSection,
                                        models.DO_NOTHING,
                                        db_column='Explode_Section_ID',
                                        blank=True, null=True,
                                        related_name='explode_section')

    class Meta:
        db_table = 'SubmissionDetails_Explode'

    def __str__(self):
        return self.value

class SubmissionActionReOpenAudit(models.Model):
    sar_id = models.BigAutoField(db_column='sar_id', primary_key=True)
    sar_action_id = SofvieIntegerField(blank=True, null=True, db_index=True)
    sar_action_type = SofvieTextField(blank=True, null=True)
    sar_reopened_by = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='sar_reopened_by')    
    sar_record = SofvieTextField(blank=True, null=True)
    sar_created_date = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    sar_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='sar_created_by_per')
    sar_modified_date = models.DateTimeField(blank=True, null=True)
    sar_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='sar_modified_by_per')
    sar_enable = models.BooleanField(default=True)
    sar_enote = SofvieTextField(blank=True, null=True)
    class Meta:
        db_table = 'submission_action_reopen_audit'


class SubmissionHazardActionPerson(Model):
    hap_id = AutoField(primary_key=True)
    hap_sha = ForeignKey(Submissionhap,
                                on_delete=models.DO_NOTHING,
                                related_name='hap_sha_id')
    hap_per = ForeignKey(Person, on_delete=models.DO_NOTHING,
                                related_name='hap_per_id')
    hap_created_date = DateTimeField(auto_now_add=True)
    hap_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING,
                                    related_name='hap_created_by')
    hap_modified_date = DateTimeField(blank=True, null=True)
    hap_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING,
                                     related_name='hap_modified_by', blank=True,
                                     null=True)
    hap_archived_date = DateTimeField(blank=True, null=True)
    hap_archived_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, blank=True,
                                     null=True,
                                     related_name='hap_archived_by')
    hap_enable = BooleanField(default=True)
    hap_enote = SofvieCharField(max_length=255, blank=True, null=True)


    class Meta:
        db_table = 'submission_hazard_action_person'

    def __int__(self):
        return f"{self.hap_sha} - {self.hap_per.full_name}"



class SubmissionHazardActionCompletion(Model):
    hac_id = AutoField(primary_key=True)
    hac_sha = ForeignKey(Submissionhap, on_delete=models.DO_NOTHING,
                         related_name='hac_sha_id')
    hac_action_is_complete = BooleanField(default=False)
    hac_rld_completed_action_type = ForeignKey(RefListDetail,
                                               on_delete=models.DO_NOTHING,
                                               related_name='hac_rld_completed_action_type_id', blank = True, null = True
                                               )
    hac_completed_action_score = SofvieIntegerField(blank = True, null = True)
    hac_completed_action_date = DateField(blank=True, null=True)
    hac_completed_action_taken = SofvieTextField(blank = True, null = True)
    hac_created_date = DateTimeField(auto_now_add=True)
    hac_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING,
                                    related_name='hac_created_by')
    hac_modified_date = DateTimeField(blank=True, null=True)
    hac_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING,
                                     related_name='hac_modified_by', blank=True,
                                     null=True)
    hac_archived_date = DateTimeField(blank=True, null=True)
    hac_archived_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, blank=True,
                                     null=True,
                                     related_name='hac_archived_by')
    hac_enable = BooleanField(default=True)
    hac_enote = SofvieCharField(max_length=255, blank=True, null=True)


    class Meta:
        db_table = 'submission_hazard_action_completion'


class SubmissionHazardActionCompletedPerson(Model):
    hcp_id = AutoField(primary_key=True)
    hcp_hac = ForeignKey(SubmissionHazardActionCompletion,
                         on_delete=models.DO_NOTHING,
                         related_name='hcp_hac_id')
    hcp_per = ForeignKey(Person, on_delete=models.DO_NOTHING,
                         related_name='hcp_per_id')
    # hcp_action_type = SofvieCharField(max_length=20)
    hcp_created_date = DateTimeField(auto_now_add=True)
    hcp_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING,
                                    related_name='hcp_created_by')
    hcp_modified_date = DateTimeField(blank=True, null=True)
    hcp_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING,
                             related_name='hcp_modified_by', blank=True,
                                     null=True)
    hcp_archived_date = DateTimeField(blank=True, null=True)
    hcp_archived_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, blank=True,
                                     null=True,
                                     related_name='hcp_archived_by')
    hcp_enable = BooleanField(default=True)
    hcp_enote = SofvieCharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'submission_hazard_action_completed_person'

    def __int__(self):
        return f"{self.hcp_hac} - {self.hcp.per.full_name}"


class Submissionhapattachments(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)
    submissionhapid = models.ForeignKey(Submissionhap, models.DO_NOTHING,
                                        db_column='SubmissionHAPID',
                                        related_name='attachments'
                                        )
    attachmentfilename = SofvieCharField(db_column='AttachmentFileName',max_length=200, db_index=True)
    attachmentcomment = SofvieTextField(db_column='AttachmentComment',null=True)
    attachmenttype = SofvieCharField(db_column='AttachmentType',max_length=20, db_index=True,null=True)
    haa_image_timestamp = models.DateTimeField(blank=True, null=True,
        db_index=True)
    isimage = models.BooleanField(db_column='IsImage',
                                  default=True)
    haa_hac = ForeignKey(SubmissionHazardActionCompletion,
                         on_delete=models.DO_NOTHING, related_name='haa_hac_id',
                         null=True, blank=True)
    haa_created_date = models.DateTimeField(auto_now=True, blank=True, \
                                                                 null=True)
    haa_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='haa_created_by_per')
    haa_modified_date = models.DateTimeField(auto_now=True,blank=True,
                                             null=True)
    haa_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='haa_modified_by_per')
    haa_enable = models.BooleanField(default=True)
    haa_enote = SofvieTextField(blank=True, null=True,db_index=True)

    class Meta:

        db_table = 'SubmissionHAPAttachments'