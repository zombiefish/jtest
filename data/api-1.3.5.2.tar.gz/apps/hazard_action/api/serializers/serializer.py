from rest_framework import serializers
from apps.comments.models import Comments

from apps.general_action.models import Submissionheader, Formdescription, \
    Reports
from apps.hazard_action.models import Submissionhapattachments, Submissionhap, \
    SubmissiondetailsExplode, SubmissionHazardActionPerson

from apps.reflist.models import RefListDetail
from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile
from apps.person.models import Person

# for create new Submission Hap record

# distribution 18001
# FormDescriptionID = 1351
# create an entry in the submissionheader table with unique GUUID
# Grab the submissionHeaderID
# Create an entry in submissiondetail table
# Grab the Submissiondetailid
# Create entry submissiondetailsexplode table
# To make each entry for distrubtion list in the explode table
# create entry submissionHAP table
# Create entry in submissionHeader with SubmittedBy_SupervisorID with person id


class GetHazardActionAttachmentsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Submissionhapattachments
        fields = [
            'id',
            'attachmentfilename',
            'attachmenttype',
            'haa_image_timestamp',
            'haa_created_by_per',
            'haa_modified_by_per',
            'haa_enable'
        ] 

    def to_representation(self, instance):
        representation = super().to_representation(instance)       
        try:            
            comment = Comments.objects.filter(com_reference_id=instance.id, com_cmt=5, com_enable=True).values('com_id', 'com_comment').first()
            representation['com_id'] = comment['com_id']
            representation['com_comment'] = comment['com_comment']
        except:            
            representation['com_id'] = None
            representation['com_comment'] = None
        return representation


class GetHazardActionSerializer(serializers.ModelSerializer):
    attachments = GetHazardActionAttachmentsSerializer(read_only=True,
                                           many=True,
                                           source='only_enable_haa_attachment')

    distribution = serializers.SerializerMethodField()
    action_type_ltr_text = serializers.SerializerMethodField()
    hazard_type_ltr_text = serializers.SerializerMethodField()
    hazard_identification_ltr_text = serializers.SerializerMethodField()
    potential_risk_ltr_text = serializers.SerializerMethodField()
    immediate_action_type_ltr_text = serializers.SerializerMethodField()
    completed_action_type_ltr_text = serializers.SerializerMethodField()

    class Meta:
        model = Submissionhap
        fields = [
            'id',
            'submissionheaderid',
            'hazard_type',
            'hazard_type_ltr_text',
            'hazard_identification',
            'hazard_identification_ltr_text',
            'hazard_description',
            'potential_risk',
            'potential_risk_ltr_text',
            'immediate_action_taken',
            'immediate_action_required_and_performed',
            'further_action_required',
            'recommended_action',
            'immediate_action_type',
            'immediate_action_type_ltr_text',
            'action_type',
            'action_type_ltr_text',
            'action_complete_by_who',
            'action_completed_date',
            'action_by_when',
            'action_status',
            'completed_action_taken',
            'completed_action_type',
            'completed_action_type_ltr_text',
            'hazard_identification_score',
            'potential_risk_score',
            'immediate_action_score',
            'completed_action_score',
            'sha_modified_by_per',
            'sha_modified_date',
            'attachments',
            'distribution',
            'sha_is_group_action',
        ]

    def to_representation(self, instance):
        ret = super().to_representation(instance)

        if not self.context.get('remove_extra_data'):
            ret['HeaderDate'] = instance.submissionheaderid.headerdate
            ret['Site'] = instance.submissionheaderid.site
        try:
            person = self.context['request'].user.user_per_id
            lng_name = UserProfile.objects.get(upr_per= person).upr_language
            lng_id = Language.objects.get(lng_name = lng_name)
            get_ref_list = RefListDetail.objects.get(rld_id = instance.submissionheaderid.site)
            ret['Site_ltr_text'] = LanguageTranslation.objects.filter(ltr_tag=get_ref_list.rld_name, ltr_tag_type=get_ref_list.rld_tag_type, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
        except:
            ret['Site_ltr_text'] = instance.submissionheaderid.site

        ret['JobNumber'] = instance.submissionheaderid.jobnumber
        try:
            person = self.context['request'].user.user_per_id
            lng_name = UserProfile.objects.get(upr_per= person).upr_language
            lng_id = Language.objects.get(lng_name = lng_name)
            get_ref_list = RefListDetail.objects.get(rld_id = instance.submissionheaderid.jobnumber)
            ret['JobNumber_ltr_text'] = '(' + get_ref_list.rld_code + ') - ' + LanguageTranslation.objects.filter(ltr_tag=get_ref_list.rld_name, ltr_tag_type=get_ref_list.rld_tag_type, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
        except:
            ret['JobNumber_ltr_text'] = instance.submissionheaderid.jobnumber

        ret['SiteLevel'] = instance.submissionheaderid.sitelevel
        try:
            person = self.context['request'].user.user_per_id
            lng_name = UserProfile.objects.get(upr_per= person).upr_language
            lng_id = Language.objects.get(lng_name = lng_name)
            get_ref_list = RefListDetail.objects.get(rld_id = instance.submissionheaderid.sitelevel)
            ret['SiteLevel_ltr_text'] = LanguageTranslation.objects.filter(ltr_tag=get_ref_list.rld_name, ltr_tag_type=get_ref_list.rld_tag_type, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
        except:
            ret['SiteLevel_ltr_text'] = instance.submissionheaderid.sitelevel

        ret['Workplace'] = instance.submissionheaderid.workplace
        ret['Supervisor'] = instance.submissionheaderid.supervisor
        ret['Supervisor_full_name'] = Person.objects.get(pk=instance.submissionheaderid.supervisor).full_name

        ret['action_by_who'] = SubmissionHazardActionPerson.objects.filter(
            hap_sha_id = instance.id,
            hap_enable = True
        ).values_list('hap_per_id', flat = True)

        ret['action_by_who_full_name'] = [Person.objects.get(pk=person).full_name for person in ret['action_by_who']]

        ret['ReportURL'] = getattr(instance, 'report_url', None)

        return ret


    def get_distribution(self, obj):
        if self.context.get('remove_extra_data'):
            return None
        queryset = SubmissiondetailsExplode.objects.filter(
            submissiondetailid__submissionheaderid__id=
            obj.submissionheaderid_id).filter(
            # This hardcoded 'Distribution' ltr_tag = 166
            formfielddescriptionid__sectionname=166).values_list(
            'value', flat=True
        )
        # print('This is distribution list query', queryset.query)
        return queryset

    def get_action_type_ltr_text(self, instance):

        if instance.action_type:
            try:
                person = self.context['request'].user.user_per_id
                lng_name = UserProfile.objects.get(upr_per= person).upr_language
                lng_id = Language.objects.get(lng_name = lng_name)
                get_ref_list = RefListDetail.objects.get(rld_id = instance.action_type)
                return LanguageTranslation.objects.filter(ltr_tag=get_ref_list.rld_name, ltr_tag_type=get_ref_list.rld_tag_type, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
            except:
                return instance.action_type
        else:
            return ''
    def get_hazard_type_ltr_text(self, instance):

        if instance.hazard_type:
            try:
                person = self.context['request'].user.user_per_id
                lng_name = UserProfile.objects.get(upr_per= person).upr_language
                lng_id = Language.objects.get(lng_name = lng_name)
                get_ref_list = RefListDetail.objects.get(rld_id = instance.hazard_type)
                return LanguageTranslation.objects.filter(ltr_tag=get_ref_list.rld_name, ltr_tag_type=get_ref_list.rld_tag_type, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
            except:
                return instance.hazard_type
        else:
            return ''

    def get_hazard_identification_ltr_text(self, instance):

        if instance.hazard_identification:
            try:
                person = self.context['request'].user.user_per_id
                lng_name = UserProfile.objects.get(upr_per= person).upr_language
                lng_id = Language.objects.get(lng_name = lng_name)
                get_ref_list = RefListDetail.objects.get(rld_id = instance.hazard_identification)
                return LanguageTranslation.objects.filter(ltr_tag=get_ref_list.rld_name, ltr_tag_type=get_ref_list.rld_tag_type, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
            except:
                return instance.hazard_identification
        else:
            return ''

    def get_potential_risk_ltr_text(self, instance):

        if instance.potential_risk:
            try:
                person = self.context['request'].user.user_per_id
                lng_name = UserProfile.objects.get(upr_per= person).upr_language
                lng_id = Language.objects.get(lng_name = lng_name)
                get_ref_list = RefListDetail.objects.get(rld_id = instance.potential_risk)
                return LanguageTranslation.objects.filter(ltr_tag=get_ref_list.rld_name, ltr_tag_type=get_ref_list.rld_tag_type, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
            except:
                return instance.potential_risk
        else:
            return ''

    def get_immediate_action_type_ltr_text(self, instance):

        if instance.immediate_action_type:
            try:
                person = self.context['request'].user.user_per_id
                lng_name = UserProfile.objects.get(upr_per= person).upr_language
                lng_id = Language.objects.get(lng_name = lng_name)
                get_ref_list = RefListDetail.objects.get(rld_id = instance.immediate_action_type)
                return LanguageTranslation.objects.filter(ltr_tag=get_ref_list.rld_name, ltr_tag_type=get_ref_list.rld_tag_type, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
            except:
                return instance.immediate_action_type
        else:
            return ''

    def get_completed_action_type_ltr_text(self, instance):

        if instance.completed_action_type:
            try:
                person = self.context['request'].user.user_per_id
                lng_name = UserProfile.objects.get(upr_per= person).upr_language
                lng_id = Language.objects.get(lng_name = lng_name)
                get_ref_list = RefListDetail.objects.get(rld_id = instance.completed_action_type)
                return LanguageTranslation.objects.filter(ltr_tag=get_ref_list.rld_name, ltr_tag_type=get_ref_list.rld_tag_type, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
            except:
                return instance.completed_action_type
        else:
            return ''


class GetAllHazardActionSerializerTest(serializers.ModelSerializer):
    attachments = GetHazardActionAttachmentsSerializer(many=True,
                                                       read_only=True)
    class Meta:
        model = Submissionhap
        fields = [
            'id',
            'submissionheaderid',
            'hazard_type',
            'hazard_identification',
            'hazard_description',
            'potential_risk',
            'immediate_action_taken',
            'immediate_action_required_and_performed',
            'further_action_required',
            'recommended_action',
            'immediate_action_type',
            'action_type',
            'action_complete_by_who',
            'action_completed_date',
            'action_by_when',
            'action_by_who',
            'action_status',
            'completed_action_taken',
            'completed_action_type',
            'hazard_identification_score',
            'hazard_identification_score',
            'potential_risk_score',
            'immediate_action_score',
            'completed_action_score',
            'attachments'

        ]