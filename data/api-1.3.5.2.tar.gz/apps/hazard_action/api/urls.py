from django.urls import path

from apps.hazard_action.api.views.add_hazard_action_attachments import \
    AddHazardActionAttachments
from apps.hazard_action.api.views.archive_hazard_action import \
    ArchiveHazardAction
from apps.hazard_action.api.views.create_hazard_action import CreateHazardAction
from apps.hazard_action.api.views.get_detail_single_hazard_action import \
    GetSingleHazardAction
from apps.hazard_action.api.views.get_hazard_action import GetHazardAction
from apps.hazard_action.api.views.update_hazard_action import UpdateHazardAction
from apps.hazard_action.api.views.remove_hazard_action_attachment import \
    RemoveHazardActionAttachment
from apps.hazard_action.api.views.reopen_action_items import ReopenActionItem
from apps.hazard_action.api.views.get_hazard_action_attachments import \
     GetHazardActionAttachment
from apps.hazard_action.api.views.complete_hazard_action import CompleteHazardAction

urlpatterns = [
    path('get-hazard-actions/', GetHazardAction.as_view()),
    path('create-hazard-action/', CreateHazardAction.as_view()),
    path('update-hazard-action/', UpdateHazardAction.as_view()),
    path('get-detail-single-hazard-action/', GetSingleHazardAction.as_view()),
    path('add-hazard-action-attachments/', AddHazardActionAttachments.as_view()),
    path('remove-hazard-action-attachment/',
         RemoveHazardActionAttachment.as_view()),
    path('archive-hazard-actions/', ArchiveHazardAction.as_view()),
    path('reopen-action-item/',ReopenActionItem.as_view()),
    path('get-hazard-action-attachment/', GetHazardActionAttachment.as_view()),
    path('complete-hazard-action/', CompleteHazardAction.as_view())
]