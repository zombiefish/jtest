from django.db import connection
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.incident_management.api.utlity_function import dictfetchall
from django.conf import settings
import os, mimetypes, base64
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from rest_framework.permissions import IsAuthenticated

class GetHazardActionAttachment(APIView):

    permission_classes = [IsAuthenticated, SofviePermission] 

    def get(self, request):
        
        person_id = self.request.user.user_per_id_id

        with connection.cursor() as cursor:
            cursor.execute("CALL get_hazard_action_attachments_with_comments(%s,%s)", (person_id,0))

            attachment_data_by_me = dictfetchall(cursor)
            bind_attachment_data(attachment_data_by_me)

        with connection.cursor() as cursor:
            cursor.execute("CALL get_hazard_action_attachments_with_comments(%s,%s)", (0,person_id))

            attachment_data_for_me = dictfetchall(cursor)
            bind_attachment_data(attachment_data_for_me)

        rtn = {'for_me': attachment_data_for_me, 'by_me': attachment_data_by_me}


        return Response(rtn)

def bind_attachment_data(attachment_data): 
    image_folder = settings.HAZARD_ACTION_DIR 
    print(image_folder)
    for attachment in attachment_data:
            filepath = os.path.join(os.path.join(image_folder),attachment["filename"])
            encoded_string = ""
            try:                  
                with open(filepath, "rb") as file: 
                    mime_type = mimetypes.MimeTypes().guess_type(filepath)[0]
                    encoded_string = base64.b64encode(file.read())
                    encoded_string = encoded_string.decode('utf-8')
                    encoded_string = f"data:{mime_type};base64,{encoded_string}"
            except Exception:
                pass
                
            attachment['data']= encoded_string
