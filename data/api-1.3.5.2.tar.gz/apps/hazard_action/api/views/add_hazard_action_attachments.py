from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from apps.hazard_action.models import SubmissionHazardActionCompletion

from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.common_utils.views.add_attachment import save_the_file
class AddHazardActionAttachments(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):
        person_id = self.request.user.user_per_id_id

        submission_hap_id = request.POST['submission_hap_id']        
        submission_hap_file = request.FILES.getlist('submission_hap_file')
        submission_hap_type = request.POST['submission_hap_type']
        haa_image_timestamp = request.POST['haa_image_timestamp']    
        haa_hac = None   

        try:
            
            if submission_hap_type == 'FOLLOWUP':
                '''
                if submission_hap_type = FOLLOWUP and submission_hap_id already completed - add hac_id to Submissionhapattachments
                '''
                # get count of no of complete submissions for action
                submission_complete_count = SubmissionHazardActionCompletion.objects.filter(
                    hac_sha_id = submission_hap_id, 
                    hac_enable = True
                ).count()
                
                haa_hac = SubmissionHazardActionCompletion.objects.filter(
                    hac_sha_id = submission_hap_id,
                    hac_created_by_per = person_id,
                    hac_enable = True
                ).latest('hac_id')

                if submission_complete_count > 1:
                    submission_hap_type = None
            
            data_args = {
                "app": "Hazard_Action",
                "person_id": person_id,
                "id": submission_hap_id,
                "files": submission_hap_file,
                "attachment_type": submission_hap_type,
                "image_timestamp": haa_image_timestamp,
                "only_image": True,
                "haa_hac": haa_hac
            }

            response = save_the_file(data_args)      

            return Response({"message": response})        
        
        
        except Exception as e:
            return Response({"Message": f"Failed to upload attachment. {e}"}, status= status.HTTP_400_BAD_REQUEST)