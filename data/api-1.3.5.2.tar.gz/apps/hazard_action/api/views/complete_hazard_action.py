from datetime import datetime

from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status

from django.core.mail import EmailMultiAlternatives
from django.db import transaction
from django.db.models import Subquery, OuterRef
from django.template.loader import get_template
from django.conf import settings
from decouple import config
from django.utils.safestring import mark_safe
from apps.common_utils.views.common_global_functions import ltr_subquery

from apps.common_utils.views.get_translations import get_translation
from apps.common_utils.views.validate_permission import RolePermission
from apps.general_action.models import Reports, Submissionheader
from apps.hazard_action.models import SubmissionHazardActionCompletedPerson, SubmissionHazardActionCompletion, SubmissionHazardActionPerson, Submissionhap
from apps.language.models import Language, LanguageTranslation
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user.models import User
from apps.user_settings_profile.models import UserProfile

class CompleteHazardAction(APIView):
    
    permission_classes = [SofviePermission]


    """ Request to update followup """

    def validate_permission(self, request):

        sofviePermission = SofviePermission()
        self.permission_attrs = (RolePermission.CanCloseAllActions.value,)

        can_close_all_actions = sofviePermission.has_permission(request,self)

        if not can_close_all_actions:
            created_by = self.sha_instance.sha_created_by_per_id
            assigned_to = SubmissionHazardActionPerson.objects.filter(
                hap_enable = True,
                hap_sha = self.sha_instance
            ).values_list('hap_per_id', flat = True)

            if created_by == self.person_instance.per_id or self.person_instance.per_id in assigned_to:
                return True
        
        return can_close_all_actions



    @transaction.atomic
    def post(self, request,*args, **kwargs):

        '''
        Sample payload from front end
        {
            "action_complete_by_who": [
                12,
                234,
                2345,
                43
            ],
            "action_completed_date": "2022-11-01",
            "completed_action_taken": "4548975t48312",
            "completed_action_type": 12435,
            "submission_hap_id": 14
        }
        '''

        try:
            self.sha_complete_data = request.data
            self.submission_hap_id = self.sha_complete_data.pop("submission_hap_id", None)
            self.sha_instance = Submissionhap.objects.get(pk = self.submission_hap_id)
            self.person_instance = self.request.user.user_per_id

            valid_permission = self.validate_permission(request)
            if not valid_permission:
                return Response(status=status.HTTP_403_FORBIDDEN)
            
            self.person_email = User.objects.get(user_per_id=self.person_instance.per_id).email


            self.action_complete_by_who = self.sha_complete_data.pop("action_complete_by_who", [])
            self.action_completed_date = self.sha_complete_data.pop("action_completed_date", None)
            self.completed_action_taken = self.sha_complete_data.pop("completed_action_taken", None)
            self.completed_action_type = self.sha_complete_data.pop("completed_action_type", None)
            self.completed_action_score = self.sha_complete_data.pop("completed_action_score", None)

            if self.sha_instance.action_status.lower() != 'complete':
                # i.e., completing action for firs time - by different people through offline.
                # add data to main table SubmissionHAP - 
                # if already completed directly add data to new tables 

                # code to add data to SubmissionHAP table - remove after splitting tables
                insert_to_submissionhap(self)
            
            # add records to new tables submission_hazard_action_completion
            self.sha_completion = insert_to_submission_hazard_action_completion(self)
            
            # add a record for each person in submission_hazard_action_completed_person table
            self.shac_person = insert_to_submission_hazard_action_completed_person(self)          

            # send emails 
            lng_name = UserProfile.objects.get(upr_per = self.person_instance).upr_language
            self.lng_id = Language.objects.get(lng_name=lng_name).lng_id
            ltr_ids = [166, 4255, 4256, 4257, 4258, 4259, 4260, 4261, 4262, 3606, 3607, 3608, 8468, 9158, 2026, 17, 15, 2028, 3601,2001, 1952, 9167]
            self.email_translations = get_translation(ltr_ids, self.lng_id)

            self.action_completed_by_full_name = [person.full_name for person in Person.objects.filter(per_id__in = self.action_complete_by_who)]

            self.action_type = get_action_type(self) 

            self.action_type = self.action_type[0] if self.action_type else None

            self.email_list = get_email_list_ha(self)

            self.form_id = get_form_id(self)

            self.report_name = Reports.objects.get(singleformreportid=self.form_id)

            complete_action_send_email_ha(self)

            return Response({
                "submission_hap_id":self.sha_instance.id, 
                "message": "Successfully Complted Hazard Action"},
                status= status.HTTP_200_OK
            )

        except Exception as e:
            return Response(
                {"message": f"{str(e)}"},
                status = status.HTTP_400_BAD_REQUEST
            )        

@transaction.atomic
def insert_to_submissionhap(self):
    '''
    update  below fields in SubmissionHAP table for selected record - submission_hap_id
    action_status
    action_complete_by_who
    action_completed_date
    completed_action_taken
    completed_action_type
    '''
    # add first record in action_complete_by_who list 
    action_complete_by_who = self.action_complete_by_who[0] if self.action_complete_by_who else None


    # set action_status to complete
    Submissionhap.objects.filter(
        id = self.sha_instance.id
    ).update(
        action_status = 'Complete',
        action_completed_date = self.action_completed_date,
        completed_action_taken = self.completed_action_taken,
        completed_action_type = self.completed_action_type,
        completed_action_score = self.completed_action_score,
        action_complete_by_who = action_complete_by_who,
        sha_modified_date = datetime.now(),
        sha_modified_by_per = self.person_instance,
    )


@transaction.atomic
def insert_to_submission_hazard_action_completion(self):
    
    sha_completion_data = {
        "hac_sha_id" : self.submission_hap_id,
        "hac_action_is_complete" : True,
        "hac_rld_completed_action_type_id" : self.completed_action_type,
        "hac_completed_action_date" : self.action_completed_date,
        "hac_completed_action_taken" : self.completed_action_taken,
        "hac_completed_action_score" : self.completed_action_score,
        "hac_created_by_per": self.person_instance
    }

    sha_completion = SubmissionHazardActionCompletion.objects.create(**sha_completion_data)

    return sha_completion

@transaction.atomic
def insert_to_submission_hazard_action_completed_person(self):
    bulk_shac_person = [
        SubmissionHazardActionCompletedPerson(
            hcp_hac = self.sha_completion,
            hcp_per_id = person,
            hcp_created_by_per = self.person_instance
        ) for person in self.action_complete_by_who
    ]

    shac_person = SubmissionHazardActionCompletedPerson.objects.bulk_create(bulk_shac_person)

    return shac_person

def get_action_type(self):
    return RefListDetail.objects.filter(
        rld_id = self.completed_action_type
    ).annotate(
        action_type = ltr_subquery(self, 'rld_name', 'rld_tag_type')
    ).values_list('action_type', flat = True)

def get_form_id(self):
    return Submissionheader.objects.filter(
        id=self.sha_instance.submissionheaderid_id
    ).select_related(
        "submission_header",
        "form_description"
    ).values(
        'formdescriptionid__formid__formid'
    ).first()['formdescriptionid__formid__formid']

def get_email_list_ha(self):

    # email_list =distinct( dist_list + creator + assignee + complete list - submitted by )

    sha = Submissionhap.objects.filter(
        id=self.sha_instance.id
    )       

    distribution_email_list = sha.values_list(
        'submissionheaderid__submission_detail__submission_detail_explode__value',
        flat = True
    )
    creator_email_list = sha.values_list(
        'sha_created_by_per__users__email',
        flat = True
    )

    assignee_email_list = get_ha_assignee_email_list(self)

    completed_by_email_list = get_ha_completed_by_email_list(self)

    email_list = list(distribution_email_list)+list(creator_email_list)+list(assignee_email_list)+list(completed_by_email_list)

    email_list = list(set(email_list).difference([self.person_email]))

    return email_list


def get_ha_assignee_email_list(self):
    return SubmissionHazardActionPerson.objects.filter(
        hap_sha_id = self.sha_instance.id,
        hap_enable = True
    ).values_list(
        'hap_per__users__email',
        flat = True
    )


def get_ha_completed_by_email_list(self):

    return SubmissionHazardActionCompletedPerson.objects.filter(
        hcp_hac__hac_sha_id = self.sha_instance.id,
        hcp_hac__hac_enable = True,
        hcp_enable = True
    ).values_list(
        'hcp_per__users__email',
        flat = True
    )

def complete_action_send_email_ha(self):

    # send email for each person in self.action_completed_by
    persons_str = ','.join(self.action_completed_by_full_name)

    dict = { 
            'completed_by': persons_str,
            'action_type': self.action_type,
            'action_taken': mark_safe(self.sha_instance.completed_action_taken),
            'completed_on': self.sha_instance.action_completed_date,
            'report_link': f"{config('EMAIL_REPORT_URL')}{self.report_name.reporturl}/{self.sha_instance.submissionheaderid}?lang={self.lng_id}",
            'domain_app': config('FRONTEND_HOST_NAME'),
            'email_body': self.email_translations[9167],
            'data': self.email_translations
        }
    
    subject = self.email_translations[2026]
    from_email = settings.DEFAULT_FROM_EMAIL_ADMIN
    email_list = self.email_list

    text_content = 'This is an important message.'
    html_content = get_template(
        "general_action/close_action.html").render(dict)
    msg = EmailMultiAlternatives(subject, text_content, from_email, email_list)
    msg.attach_alternative(html_content, "text/html")
    msg.send()