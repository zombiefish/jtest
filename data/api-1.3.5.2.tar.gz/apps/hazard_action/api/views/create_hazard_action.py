import uuid
from datetime import datetime

from decouple import config
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.db import transaction, connection

from django.template.loader import get_template
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.comments.api.views.add_comment import add_comment
from apps.common_utils.views.add_attachment import save_the_file
from apps.common_utils.views.common_global_functions import get_user_email

from apps.common_utils.views.get_translations import get_translation
from apps.general_action.api.serializers.serializer import \
    SubmissiondetailsExplode
# from apps.general_action.api.views.create_general_action import send_email
from apps.general_action.models import Submissionheader, Reports
from apps.hazard_action.models import Submissiondetails, Submissionhap, SubmissionHazardActionPerson, SubmissionHazardActionCompletion, SubmissionHazardActionCompletedPerson
from apps.language.models import Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user.models import User
from apps.user_settings_profile.models import UserProfile
from django.core.files.base import ContentFile
import base64



class CreateHazardAction(APIView):
    permission_classes = [SofviePermission]

    @transaction.atomic
    def post(self, request):

        self.person_instance = self.request.user.user_per_id 

        hazard_action_data = request.data        

        insert_hazard_action(self, hazard_action_data)

        return Response({"ID": self.submitted_action_ids,
                         "Message": "Record Added Successfully"})


def insert_hazard_action(self, hazard_action_data,submission_header_latest=None, insert_attachments = False):

    self.FORM_DESCRIPTION_ID = 1305
    self.FORM_FIELD_DESCRIPTION_ID=18001
    self.immediate_action = False
    self.incidentid = hazard_action_data.pop('incidentid', None)

    self.submission_header_latest = submission_header_latest
    self.insert_attachments = insert_attachments
    
    # get email translations
    lng_name = UserProfile.objects.get(upr_per_id=self.person_instance).upr_language
    self.lng_id = Language.objects.get(lng_name=lng_name).lng_id
    ltr_ids = [166, 4255, 4256, 4257, 4258, 4259, 4260, 4261, 4262, 3606, 3607, 3608, 8469, 1952, 1903, 1298, 1305, 1999,9522 ]
    self.email_translations = get_translation(ltr_ids, self.lng_id)

    self.action_by_who = hazard_action_data.pop('action_by_who', [])
    self.group_action = hazard_action_data.pop("sha_is_group_action", False)
    self.attachments = hazard_action_data.pop('attachments', [])

    self.distribution = hazard_action_data.pop('distribution', [])
    assignee_email_list = []
    if hazard_action_data['further_action_required']:
        assignee_email_list = [get_user_email(User, person) for person in self.action_by_who]
    creator_email = get_user_email(User, self.person_instance.per_id)
    self.email_list = list(set(self.distribution + assignee_email_list))
    if creator_email in self.email_list:
        self.email_list.remove(creator_email)
    
    hazard_action_data['action_status'] = 'Incomplete'
    if 'immediate_action_required_and_performed' in hazard_action_data and hazard_action_data['immediate_action_required_and_performed'] and 'further_action_required' in hazard_action_data and  not(hazard_action_data['further_action_required']):
        self.immediate_action = True
        hazard_action_data['action_status'] = 'Complete'
        
    
    self.ha_submission_header_data = {
        "formdescriptionid_id" : self.FORM_DESCRIPTION_ID,
        "headerdate": hazard_action_data.pop('HeaderDate', ''),
        "site" : hazard_action_data.pop('Site', None),
        "jobnumber" : hazard_action_data.pop('JobNumber', None),
        "sitelevel" : str(hazard_action_data.pop('SiteLevel', '')),
        "workplace" : hazard_action_data.pop('Workplace', ''),
        "supervisor" : str(hazard_action_data.pop('Supervisor', '')),
        "submittedby_supervisorid" : self.person_instance,
        "formcreationdate": datetime.now(),
        "formsubmissiondate": datetime.now(),
    }

    self.submitted_action_ids = []
    if self.group_action:
        
        submission_header_latest, action = create_hazard_action(self, hazard_action_data)

        self.submitted_action_ids.append(action.pk)
        # bulk object to insert to hazard action person
        bulk_object = [SubmissionHazardActionPerson(
                        hap_sha = action,
                        hap_per_id=per,
                        hap_created_by_per =self.person_instance                        
                    )for per in self.action_by_who]
        SubmissionHazardActionPerson.objects.bulk_create(bulk_object)

        # for group action, send one email to each person in email list for one submission 
        send_email(self, submission_header_latest)

    else:    
        '''
            # create hazard action - 
            # insert to SubmissionHazardActionPerson - a record for each person in self.action_by_who with new sga_id created for each person i.e., action
            # send one email to each person for all submissions.
        '''
        if self.immediate_action:
            # when immediate action is performed and no further action required, create hazard action directly.
            # as self.action_by_who is empty
            submission_header_latest, action = create_hazard_action(self, hazard_action_data)
            
            self.submitted_action_ids.append(action.pk)
        else:
            for each_person in self.action_by_who:
                hazard_action_data['action_by_who'] = each_person
                
                submission_header_latest, action = create_hazard_action(self, hazard_action_data)
                
                self.submitted_action_ids.append(action.pk)

                # add record to SubmissionHazardActionPerson for each_person
                SubmissionHazardActionPerson.objects.create(
                    hap_sha = action,
                    hap_per_id=each_person,
                    hap_created_by_per =self.person_instance 
                )

        # for individual action, send one email to each person in email list for all submissions
        send_email(self)

    return self.submitted_action_ids

def create_submission_hap_payload(self, hazard_action_data):
    self.submission_hap_payload ={
        'hazard_type': hazard_action_data["hazard_type"],
        'hazard_identification': hazard_action_data["hazard_identification"],
        'hazard_description': hazard_action_data["hazard_description"],
        'potential_risk': hazard_action_data["potential_risk"],
        'immediate_action_required_and_performed': hazard_action_data["immediate_action_required_and_performed"],
        'immediate_action_taken': hazard_action_data["immediate_action_taken"],
        'further_action_required': hazard_action_data["further_action_required"],
        'recommended_action': hazard_action_data["recommended_action"],
        'immediate_action_type': hazard_action_data["immediate_action_type"],
        'sha_is_group_action': self.group_action,
        'action_status': hazard_action_data["action_status"],
        'action_type': hazard_action_data["action_type"],        
        'action_by_when': hazard_action_data["action_by_when"],        
        'hazard_identification_score': hazard_action_data["hazard_identification_score"],
        'potential_risk_score': hazard_action_data["potential_risk_score"],
        'immediate_action_score': hazard_action_data["immediate_action_score"],
        'sha_created_date': datetime.now(),
        'sha_created_by_per': self.person_instance,
    }

@transaction.atomic
def create_hazard_action(self, hazard_action_data):

    '''
        # create hazard action - 
        # insert to submission header - 
        # insert to submision details - 
        # insert to submission detail explode - 
        # insert to submission_general_action - 
        # insert attachments if there are any - 
    '''
    create_submission_hap_payload(self, hazard_action_data)   

    sha_instance = self.submission_header_latest

    # Create entry in the submissionheader table with with formdescriptionid
    if not self.submission_header_latest:
        self.ha_submission_header_data['submissionid'] = str(uuid.uuid4()).upper()
        sha_instance = Submissionheader.objects.create(
            **self.ha_submission_header_data
        )

        submission_details_latest = Submissiondetails.objects.create(
            submissionheaderid_id=sha_instance.id
        )

        # bulk create distribution in SubmissiondetailsExplode
        bulk_object = [SubmissiondetailsExplode(
                        submissiondetailid_id = submission_details_latest.id,
                        formfielddescriptionid_id=self.FORM_FIELD_DESCRIPTION_ID,
                        value=value,
                        explode_section=None,
                    )for value in self.distribution]
        SubmissiondetailsExplode.objects.bulk_create(bulk_object)

    self.submission_hap_payload['submissionheaderid'] = sha_instance

    if hasattr(self, 'incidentid') and self.incidentid:
        with connection.cursor() as cursor:
            cursor.execute("call add_action_into_incident(%s, %s)", (self.incidentid, sha_instance.id))

    if self.immediate_action:
        self.submission_hap_payload['completed_action_taken'] = self.submission_hap_payload['immediate_action_taken']
        self.submission_hap_payload['completed_action_type'] = self.submission_hap_payload['immediate_action_type']
        self.submission_hap_payload['completed_action_score'] = self.submission_hap_payload['immediate_action_score']
        self.submission_hap_payload['action_completed_date'] = datetime.now()
        self.submission_hap_payload['action_complete_by_who'] = self.person_instance.per_id

    action = Submissionhap.objects.create(**self.submission_hap_payload)

    if self.immediate_action:
        # when immediate action is performed and no further action required, consider action is completed
        # and action is completed by action submitted person. 

        shac = SubmissionHazardActionCompletion.objects.create(
            hac_sha = action,
            hac_action_is_complete = True,
            hac_rld_completed_action_type_id = self.submission_hap_payload['immediate_action_type'],
            hac_completed_action_taken = self.submission_hap_payload['immediate_action_taken'],
            hac_completed_action_score = self.submission_hap_payload['immediate_action_score'],
            hac_completed_action_date = datetime.now(),
            hac_created_date = datetime.now(),
            hac_created_by_per = self.person_instance
        )

        SubmissionHazardActionCompletedPerson.objects.create(
            hcp_hac = shac,
            hcp_per = self.person_instance,
            hcp_created_date = datetime.now(),
            hcp_created_by_per = self.person_instance
        )

    if self.insert_attachments:
        insert_hazard_action_attachments(self, action)
        
    return self.submission_header_latest, action

def send_email(self, submission_header_latest = None):
    self.report_name = Reports.objects.get(singleformreportid=131042)
    report_link = f"{config('EMAIL_REPORT_URL')}{self.report_name.reporturl}/{submission_header_latest.id}?lang={self.lng_id}" if submission_header_latest else ''

    dict = {'report_link': report_link,
            'domain_app': config('FRONTEND_HOST_NAME'),
            'data': self.email_translations,
            'form_name': self.email_translations[1999],
            'created_date': datetime.today().date(),
            'created_by': self.person_instance.full_name,
            'group_action' : self.group_action
            }

    subject, from_email, email_list = self.email_translations[8469], \
                                        settings.DEFAULT_FROM_EMAIL_ADMIN, \
                                        self.email_list
    text_content = 'This is an important message.'
    html_content = get_template(
        "hazard_action/report_link_email.html").render(dict)
    msg = EmailMultiAlternatives(subject, text_content, from_email,
                                    email_list)
    msg.attach_alternative(html_content, "text/html")
    msg.send()

def insert_hazard_action_attachments(self, action):
    haa_files = []
    for attachment in self.attachments:
        format, imgstr = attachment['att_file_url'].split(';base64,')
        ext = format.split('/')[-1]
        haa_file = ContentFile(base64.b64decode(imgstr),
                                    name=attachment['att_file_name'] + '_' + datetime.now(
                                    ).strftime('%Y%m-%d%H-%M%S' + '.') + ext)

        haa_files.append(haa_file)

        person_id = self.person_instance.per_id
        data_args = {
            "app": "Hazard_Action",
            "person_id": person_id,
            "id": str(action.id),
            "files": haa_files,
            "attachment_type": 'INITIAL',
            "image_timestamp": attachment['att_timestamp'],
            "only_image": True,
            "haa_hac" :None
        }

        response = save_the_file(data_args)

        com_reference_id = response["Successfull Files"]["ids"][0]
        # adding comments
        add_comment(com_cmt_id=5, com_reference_id = com_reference_id, com_comment = attachment['att_comment'], person_id = person_id)
