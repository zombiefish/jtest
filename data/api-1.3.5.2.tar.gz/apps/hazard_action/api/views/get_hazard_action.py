
from django.db.models import Subquery, F, Q, OuterRef, Value, CharField
from django.db.models.functions import Concat

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.general_action.models import Formdescription, Reports
from apps.hazard_action.api.serializers.serializer import \
    GetHazardActionSerializer
from apps.hazard_action.models import SubmissionHazardActionCompletedPerson, Submissionhap, SubmissiondetailsExplode, SubmissionHazardActionPerson

# Get the data from submitted_by_supervisorID column from Submission Header
# Table to display in the response Created By Me filter

#helper function for site - user visibility filter
from apps.employee.helper_function_user_visibility import helperEmployeeSites, helperEmployeeJobs
from apps.employee.models import EmployeeSite, EmployeeJob
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from apps.language.models import Language, LanguageTranslation

class GetHazardAction(APIView):
    permission_classes = [SofviePermission]
    

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        filter = request.data['filter']
        status = request.data['status']
        sites, data_user_visibility = helperEmployeeSites(self, person_id)
        per_sites = [site['rld_id'] for site in sites]
        get_jobs, data_user_visibility = helperEmployeeJobs(self, person_id)
        per_jobs = [job['rld_id'] for job in get_jobs]
        form_desc = Formdescription.objects.get(pk=1305)
        queryset = Submissionhap.objects.select_related(
            'submissionheaderid',
        ).prefetch_related("hap_sha_id").exclude(
            submissionheaderid__isarchived = 1
        ).annotate(
            report_url=Subquery(
                Reports.objects.filter(
                    singleformreportid=form_desc.formid_id
                ).values('reporturl')[:1]
            )
        )

        site_filters = []
        job_filters = []
        assigned_to_filter = [Q(hap_sha_id__hap_per_id = person_id)]
        if data_user_visibility !='all':
            site_filters = [Q(submissionheaderid__site__in=per_sites)]
            job_filters = [Q(submissionheaderid__jobnumber__in=per_jobs)]

        site_filters_user = []
        job_filters_user = []
        if data_user_visibility !='all':
            site_filters_user = [Q(submissionheaderid__site__in=per_sites) | Q(submissionheaderid__submittedby_supervisorid=person_id)]
            job_filters_user = [Q(submissionheaderid__jobnumber__in=per_jobs) | Q(submissionheaderid__submittedby_supervisorid=person_id)]

        
        if filter == 'Site' and status == 'Incomplete':
            get_profile_sites = EmployeeSite.objects.filter(
                esi_emp__emp_per_id=person_id,
                esi_enable=True
                ).values_list('esi_sit_id__rld_id', flat=True)

            get_profile_jobs = EmployeeJob.objects.filter(
                ejo_emp__emp_per_id = person_id,
                ejo_enable=True
                ).values_list('ejo_job_id__rld_id', flat=True)

            if data_user_visibility =='custom':

                site_list = list(set(get_profile_sites) & set(per_sites))
                site_filters = [Q(submissionheaderid__site__in=site_list)]
                job_filters = []
                if get_profile_jobs:
                    job_list = list(set(per_jobs) & set(get_profile_jobs))
                    job_filters = [Q(submissionheaderid__jobnumber__in=job_list)]
                elif per_jobs:
                    job_filters = [Q(submissionheaderid__jobnumber__in=per_jobs)]

                queryset = queryset.filter(
                        *site_filters,
                        *job_filters,
                        sha_enable=1,
                        further_action_required = True,
                        action_status='Incomplete')

            else:
                site_filters = [Q(submissionheaderid__site__in=get_profile_sites)]
                job_filters = []
                if get_profile_jobs and data_user_visibility=='profile':
                    job_filters = [Q(submissionheaderid__jobnumber__in=get_profile_jobs)]
                queryset = queryset.filter(
                        *site_filters,
                        *job_filters,
                        sha_enable=1,
                        further_action_required = True,
                        action_status='Incomplete')
            

        elif filter == 'Site' and status == 'All':
            queryset = queryset.filter(
                    *site_filters,
                    *job_filters,
                    sha_enable=1)

        elif filter == 'Assigned To Me' and status == 'Incomplete':
            queryset = queryset.filter(
                *site_filters_user,
                *job_filters_user,
                *assigned_to_filter,
                sha_enable=1,
                further_action_required = True,
                action_status='Incomplete')            

        elif filter == 'Assigned To Me' and status == 'All':
            queryset = queryset.filter(
                *site_filters_user,
                *job_filters_user,
                *assigned_to_filter, sha_enable=1,
            )

        elif filter == 'All' and status == 'Incomplete':

            queryset = queryset.filter(
                *site_filters_user,
                *job_filters_user,
                sha_enable=1,
                further_action_required = True,
                action_status='Incomplete')
            
        elif filter == 'All' and status == 'All':
            queryset = queryset.filter(
                *site_filters_user,
                *job_filters_user,
                sha_enable=1)

        elif filter == 'Created By Me' and status == 'Incomplete':
            queryset = queryset.filter(
                *site_filters_user,
                *job_filters_user,
                further_action_required = True,
                submissionheaderid__submittedby_supervisorid=person_id,
                sha_enable=1, action_status='Incomplete'
            )            

        elif filter == 'Created By Me' and status == 'All':
            queryset = queryset.filter(
                *site_filters_user,
                *job_filters_user,
                submissionheaderid__submittedby_supervisorid=person_id,
                sha_enable=1
            )

        elif filter == 'Completed By Me':
            queryset = queryset.filter(
                *site_filters_user,
                *job_filters_user,
                action_complete_by_who=person_id, sha_enable=1,
                action_status='COMPLETE')
    
        elif filter == 'Deactivation' and status == 'Incomplete':
            per_id = request.data['user_id']
            assigned_to_filter = [Q(hap_sha_id__hap_per_id = per_id)]
            queryset = queryset.filter(
                *site_filters_user,
                *job_filters_user,
                *assigned_to_filter,
                sha_enable=1,
                further_action_required = True,
                action_status='Incomplete'
                )
                
        elif filter == 'homepage':
            # get incomplete actions for the given sites and jobs if matched with user's data visibility
            selected_data = request.data.get('actions_payload')
            selected_sites = selected_data["sites"].split(',')
            selected_jobs = selected_data["jobs"].split(',')

            selected_sites = list(map(int, selected_sites))
            selected_jobs = list(map(int, selected_jobs))

            homepage_sites_list = list(set(selected_sites).intersection(per_sites))
            homepage_jobs_list = list(set(selected_jobs).intersection(per_jobs))
            
            homepage_sites_filter = [Q(submissionheaderid__site__in=homepage_sites_list)]
            homepage_jobs_filter = [Q(submissionheaderid__jobnumber__in=homepage_jobs_list)]

            queryset = queryset.filter(
                *homepage_sites_filter,
                *homepage_jobs_filter,
                sha_enable = 1,
                action_status = 'Incomplete'
            )

        if request.data.get('detail'):
            obj = queryset.get(pk=request.data['hap_id'])
            data = GetHazardActionSerializer(obj, context={'request': request}).data

        else:
            queryset = queryset.annotate(
                Workplace=F('submissionheaderid__workplace'),
                HeaderDate=F('submissionheaderid__headerdate'),
                submitted_date=F('submissionheaderid__formsubmissiondate'),
                submitted_by=F('submissionheaderid__submittedby_supervisorid'),
                Supervisor=F('submissionheaderid__supervisor'),
                tag_rld_id_site=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('submissionheaderid__site')).values('rld_name')[:1]
                ),
                tagtype_rld_id_site=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('submissionheaderid__site')).values('rld_tag_type')[:1]
                ),
                tag_rld_id_site_level=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('submissionheaderid__sitelevel')).values('rld_name')[:1]
                ),
                tagtype_rld_id_site_level=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('submissionheaderid__sitelevel')).values('rld_tag_type')[:1]
                ),
                tag_rld_id_jobnumber=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('submissionheaderid__jobnumber')).values('rld_name')[:1]
                ),
                tagtype_rld_id_jobnumber=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('submissionheaderid__jobnumber')).values('rld_tag_type')[:1]
                ),
                tag_rld_id_action_type=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('action_type')).values('rld_name')[:1]
                ),
                tagtype_rld_id_action_type=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('action_type')).values('rld_tag_type')[:1]
                ),
                tag_rld_id_immediate_action_type=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('immediate_action_type')).values('rld_name')[:1]
                ),
                tagtype_rld_id_immediate_action_type=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('immediate_action_type')).values('rld_tag_type')[:1]
                ),
                tag_rld_id_completed_action_type=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('completed_action_type')).values('rld_name')[:1]
                ),
                tagtype_rld_id_completed_action_type=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('completed_action_type')).values('rld_tag_type')[:1]
                ),
                tag_rld_id_immediate_potential_risk=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('potential_risk')).values('rld_name')[:1]
                ),
                tagtype_rld_id_immediate_potential_risk=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('potential_risk')).values('rld_tag_type')[:1]
                ),
                tag_rld_id_immediate_hazard_type=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('hazard_type')).values('rld_name')[:1]
                ),
                tagtype_rld_id_immediate_hazard_type=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('hazard_type')).values('rld_tag_type')[:1]
                ),
                tag_rld_id_immediate_hazard_identification=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('hazard_identification')).values('rld_name')[:1]
                ),
                tagtype_rld_id_immediate_hazard_identification=Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('hazard_identification')).values('rld_tag_type')[:1]
                )
            )
            
            data = queryset.values('id',
                                   'submissionheaderid',
                                   'hazard_description',
                                   'immediate_action_taken',
                                   'immediate_action_required_and_performed',
                                   'further_action_required',
                                   'recommended_action',
                                   'action_completed_date',
                                   'action_by_when',
                                   'action_status',
                                   'completed_action_taken',
                                   'hazard_identification_score',
                                   'potential_risk_score',
                                   'immediate_action_score',
                                   'completed_action_score',
                                   'tag_rld_id_site',
                                   'Workplace',
                                   'submitted_date',
                                   'HeaderDate',
                                   'submitted_by',
                                   'tag_rld_id_jobnumber',
                                   'tag_rld_id_site_level',
                                   'Supervisor',
                                   'tagtype_rld_id_site',
                                   'tagtype_rld_id_jobnumber',
                                   'tagtype_rld_id_site_level',
                                   'tag_rld_id_action_type',
                                   'tagtype_rld_id_action_type',
                                   'tag_rld_id_immediate_action_type',
                                   'tagtype_rld_id_immediate_action_type',
                                   'tag_rld_id_completed_action_type',
                                   'tagtype_rld_id_completed_action_type',
                                   'tag_rld_id_immediate_potential_risk',
                                   'tagtype_rld_id_immediate_potential_risk',
                                   'tag_rld_id_immediate_hazard_type',
                                   'tagtype_rld_id_immediate_hazard_type',
                                   'tag_rld_id_immediate_hazard_identification',
                                   'tagtype_rld_id_immediate_hazard_identification'
                                   )

            lng_name = UserProfile.objects.get(upr_per=person_id).upr_language
            lng_id = Language.objects.get(lng_name=lng_name)
            
            data = data.annotate(
                name_site=Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_site'), ltr_tag_type = OuterRef('tagtype_rld_id_site'), ltr_lng=lng_id).values('ltr_text')[:1]
                            ),
                name_job_number=Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_jobnumber'), ltr_tag_type = OuterRef('tagtype_rld_id_jobnumber'),ltr_lng=lng_id).values('ltr_text')[:1]
                            ),
                name_level=Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_site_level'), ltr_tag_type = OuterRef('tagtype_rld_id_site_level'),ltr_lng=lng_id).values('ltr_text')[:1]
                            ),
                action_type=Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_action_type'), ltr_tag_type = OuterRef('tagtype_rld_id_action_type'),ltr_lng=lng_id).values('ltr_text')[:1]
                            ),
                immediate_action_type=Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_immediate_action_type'), ltr_tag_type = OuterRef('tagtype_rld_id_immediate_action_type'),ltr_lng=lng_id).values('ltr_text')[:1]
                            ),
                completed_action_type=Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_completed_action_type'), ltr_tag_type = OuterRef('tagtype_rld_id_completed_action_type'),ltr_lng=lng_id).values('ltr_text')[:1]
                            ),
                potential_risk=Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_immediate_potential_risk'), ltr_tag_type = OuterRef('tagtype_rld_id_immediate_potential_risk'),ltr_lng=lng_id).values('ltr_text')[:1]
                            ),
                hazard_type=Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_immediate_hazard_type'), ltr_tag_type = OuterRef('tagtype_rld_id_immediate_hazard_type'),ltr_lng=lng_id).values('ltr_text')[:1]
                            ),
                hazard_identification=Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_immediate_hazard_identification'), ltr_tag_type = OuterRef('tagtype_rld_id_immediate_hazard_identification'),ltr_lng=lng_id).values('ltr_text')[:1]
                            )
                            
            ).values(
                    'id',
                    'submissionheaderid_id',
                    'hazard_type',
                    'hazard_identification',
                    'hazard_description',
                    'potential_risk',
                    'immediate_action_taken',
                    'immediate_action_required_and_performed',
                    'further_action_required',
                    'recommended_action',
                    'immediate_action_type',
                    'action_type',
                    'action_completed_date',
                    'action_by_when',
                    'action_status',
                    'completed_action_taken',
                    'completed_action_type',
                    'hazard_identification_score',
                    'potential_risk_score',
                    'immediate_action_score',
                    'completed_action_score',
                    'Workplace',
                    'submitted_date',
                    'HeaderDate',
                    'submitted_by',
                    'Supervisor',
                    'name_site',
                    'name_job_number',
                    'name_level',                    
                ).distinct()

        list_submission_id = [item['submissionheaderid_id'] for item in data]

        list_sha_ids = data.values_list('id', flat = True)

        list_distribution_emails = list(SubmissiondetailsExplode.objects.filter(
            submissiondetailid__submissionheaderid__id__in=list_submission_id).filter(
            formfielddescriptionid__sectionname=166).values('submissiondetailid__submissionheaderid__id','value'))

        list_assigned_to_per_ids = SubmissionHazardActionPerson.objects.filter(
                hap_sha_id__in = list_sha_ids,
                hap_enable = True
            ).annotate(
                full_name  = Concat("hap_per__per_last_name", Value(", "), "hap_per__per_first_name", output_field=CharField())
            ).values('hap_sha_id', 'hap_per_id', "full_name")

        list_action_complete_by_who = SubmissionHazardActionCompletedPerson.objects.filter(
            hcp_hac__hac_sha_id__in = list_sha_ids,
            hcp_enable = True
        ).annotate(
                full_name  = Concat("hcp_per__per_last_name", Value(", "), "hcp_per__per_first_name", output_field=CharField())
        ).values('hcp_per_id', 'hcp_hac__hac_sha_id', "full_name")
        
        for item in data:            
            item['distribution_emails'] = [dist['value'] for dist in list_distribution_emails if dist['submissiondetailid__submissionheaderid__id'] == item['submissionheaderid_id']]

            item['action_by_who_per_id'] = [each['hap_per_id'] for each in list_assigned_to_per_ids if each['hap_sha_id'] == item['id']]
            item['action_by_who'] = '; '.join([each['full_name'] for each in list_assigned_to_per_ids if each['hap_sha_id'] == item['id']])
            item['action_complete_by_who'] = '; '.join([each['full_name'] for each in list_action_complete_by_who if each['hcp_hac__hac_sha_id'] == item['id']])
        return Response({"OutPut": data})
