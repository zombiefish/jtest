from datetime import datetime
from django.db.models import Subquery, F, Q, OuterRef
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.dlm.models import DecisionLog, DecisionLogGeneralAction, DecisionLogHazardAction
from apps.general_action.models import SubmissionGeneralAction, SubmissionGeneralActionAttachment, SubmissionGeneralActionCompletedPerson, SubmissionGeneralActionCompletion
from apps.hazard_action.models import SubmissionActionReOpenAudit, SubmissionHazardActionCompletedPerson, SubmissionHazardActionCompletion, Submissionhap, Submissionhapattachments
from apps.incident_management.models import Incidents,  Incidentsubmissions, Incident_Signoffs
from apps.llm.models import LessonLearnedGeneralAction, LessonLearnedHazardAction
from apps.person.models import Person
from apps.rmm_bowtie.models import RmmBowtieGeneralAction, RmmBowtieHazardAction
from apps.rmm_jra.models import RmmJraGeneralAction, RmmJraHazardAction
from apps.rmm_ora.models import RmmOraGeneralAction, RmmOraHazardAction
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from django.db.models import Prefetch, F, Q
from apps.rmm_pra.models import RmmPraGeneralAction, RmmPraHazardAction

from django.core import serializers

class ReopenActionItem(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        payload_data = request.data

        hazNotReopenArray = []
        genNotReopenArray = []
        # 1. Need to check any action has a parent and its status 
        # - not need to chcek the DLM and LLM because it not required to complete status for sign off
            # Hazard Action Tables - rmm_bowtie_hazard_action, rmm_ora_hazard_action, rmm_jra_hazard_action, rmm_pra_hazard_action)
        # 2. if there push to 'not reopen ids' array
        # 3. else reopen action

        if payload_data['action_type'] == 'HAP':
            for actionId in payload_data['action_ids']:
                hap = Submissionhap.objects.filter((Q(action_status = 'Complete') | Q(action_status = 'COMPLETE')), id = actionId)
                if hap:
                    # bowtie
                    bowtieValidate = RmmBowtieHazardAction.objects.filter(
                        Q(rmm_bha_bow__rmm_bow_state = 'active') |  Q(rmm_bha_bow__rmm_bow_state = 'expired') , 
                        rmm_bha_sha_id = actionId
                    )
                    # ora
                    oraValidate = RmmOraHazardAction.objects.filter(
                        Q(rmm_oha_ora__rmm_ora_state = 'active') | Q(rmm_oha_ora__rmm_ora_state = 'expired'),
                        rmm_oha_sha_id = actionId
                    )

                    # pra
                    praValidate = RmmPraHazardAction.objects.filter(
                        Q(rmm_pha_pra__rmm_pra_state = 'active') | Q(rmm_pha_pra__rmm_pra_state = 'expired'),
                        rmm_pha_sha_id = actionId
                    ) 

                    # Jra
                    jraValidate = RmmJraHazardAction.objects.filter(
                        Q(rmm_jha_jra__rmm_jra_state = 'active') | Q(rmm_jha_jra__rmm_jra_state = 'expired'),
                        rmm_jha_sha_id = actionId
                    ) 

                    #incidents  # hap id > submissionheader > incidentsubmissions > incident id
                    hapInstance = Submissionhap.objects.filter(
                        id = actionId
                    ).values('submissionheaderid')

                    incidentInstance = Incidentsubmissions.objects.filter(
                        submissionheaderid = hapInstance[0]['submissionheaderid']
                    ).values('incidentid')

                    if incidentInstance:
                        count_incidents_signed_off = Incident_Signoffs.objects.filter(
                            iso_incident_id = incidentInstance[0]['incidentid'],
                            iso_enable = True,
                            iso_per__isnull = True
                        ).count() 

                        total_count_incidents_signed_off = Incident_Signoffs.objects.filter(
                            iso_incident_id = incidentInstance[0]['incidentid'],
                            iso_enable = True
                        ).count()

                        incidentInstance = False if count_incidents_signed_off != total_count_incidents_signed_off else True
                    
                    # if any of this variables is not empty then, don't reopen this action because this action has a parent and that is in closed status
                    if bowtieValidate or oraValidate or praValidate or jraValidate or incidentInstance:
                        hazNotReopenArray.append(actionId) # not reopen this action
                    else:
                        # Call reopen action
                        reOpenAction(payload_data['action_type'], actionId, person_id)
            return Response({"Message": "HAP Action Reopened", "payload_data": payload_data, "notReopenedArray": hazNotReopenArray})

        elif payload_data['action_type']  == 'GAP':
            for actionId in payload_data['action_ids']:
                gap = SubmissionGeneralAction.objects.filter(sga_id=actionId, sga_action_is_complete=1)
                if gap:
                    # For general action not need to validate any parents are closed or signed off, it can reopen any time.
                    # Call reopen action
                    reOpenAction(payload_data['action_type'], actionId, person_id)
                else:
                    genNotReopenArray.append(actionId)
            return Response({"Message": "GAP Action Reopened", "payload_data": payload_data, "notReopenedArray": genNotReopenArray})

# pull the action record and then insert into SubmissionActionReOpenAudit
# clear the columns in action record as reopen virtually
def reOpenAction(actionType, actionID, person_id):

    if actionType == 'HAP':
        # creating the hap record to JSON
        submissionHapRecord_json = serializers.serialize("json", Submissionhap.objects.filter(id = actionID))
        # insert into the action audit table
        SubmissionActionReOpenAudit.objects.create(
            sar_action_id=actionID,
            sar_action_type='HAP',
            sar_record=submissionHapRecord_json,
            sar_created_by_per_id = person_id,
            sar_enable = 1
        )

        Submissionhap.objects.filter(id = actionID).update(
            action_status = 'Incomplete',
            action_complete_by_who = None,
            action_completed_date  = None,
            completed_action_taken = None,
            completed_action_type = None,
            hazard_identification_score = None,
            potential_risk_score = None,
            immediate_action_score = None,
            sha_modified_date = datetime.now(),
            sha_modified_by_per_id =person_id
        )

        # deleting the attachments
        Submissionhapattachments.objects.filter(submissionhapid = actionID, attachmenttype ='FOLLOWUP').update(
            haa_enable=0,
            haa_modified_date = datetime.now(),
            haa_modified_by_per_id = person_id
        )

        # disable the records SubmissionHazardActionCompletedPerson and SubmissionHazardActionCompletion
        SubmissionHazardActionCompletedPerson.objects.filter(hcp_hac__hac_sha_id = actionID, hcp_enable=1).update(
            hcp_enable = 0,
            hcp_modified_date = datetime.now(),
            hcp_modified_by_per_id = person_id
        )

        SubmissionHazardActionCompletion.objects.filter(hac_sha_id = actionID, hac_enable=1).update(
            hac_enable =0,
            hac_modified_date= datetime.now(),
            hac_modified_by_per_id = person_id
        )


    if actionType == 'GAP':
        # creating the hap record to JSON
        submissionGapRecord_json = serializers.serialize("json", SubmissionGeneralAction.objects.filter(sga_id = actionID))
        # insert into the action audit table
        SubmissionActionReOpenAudit.objects.create(
            sar_action_id = actionID,
            sar_action_type = 'GAP',
            sar_record = submissionGapRecord_json,
            sar_created_by_per_id = person_id,
            sar_enable = 1
        )
        # updating the general action  record 
        SubmissionGeneralAction.objects.filter(sga_id = actionID).update(
            sga_action_is_complete = 0,
            sga_completed_action_by_who_per = None,
            sga_completed_action_date  = None,
            sga_completed_action_taken = None,
            sga_completed_action_type_rld_id = None,
            sga_modified_date = datetime.now(),
            sga_modified_by_per_id =person_id
        )
        # deleting the attachments
        SubmissionGeneralActionAttachment.objects.filter(gaa_sga_id=actionID, gaa_type='FOLLOWUP').update(
            gaa_enable = 0,
            gaa_modified_date = datetime.now(),
            gaa_modified_by_per_id = person_id
        )

        # reopening the GAP - disable the records that SubmissionGeneralActionCompletion and SubmissionGeneralActionCompletedPerson 
        # table, it's acts as revert the transactions and keep the history for audit.

        # disable SubmissionGeneralActionCompletion
        SubmissionGeneralActionCompletion.objects.filter(gac_sga_id=actionID, gac_enable=1).update(
            gac_enable=0,
            gac_modified_date=datetime.now(),
            gac_modified_by_per_id=person_id
        )

        #disable SubmissionGeneralActionCompletedPerson
        SubmissionGeneralActionCompletedPerson.objects.filter(gcp_gac__gac_sga_id = actionID, gcp_enable = 1 ).update(
            gcp_enable = 0,
            gcp_modified_date = datetime.now(),
            gcp_modified_by_per_id = person_id
        )


