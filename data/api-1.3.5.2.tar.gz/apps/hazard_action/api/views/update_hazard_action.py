from decouple import config
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from datetime import datetime
from django.db import transaction

from apps.common_utils.views.get_translations import get_translation
from apps.general_action.models import Submissionheader, Reports
from apps.hazard_action.api.serializers.serializer import \
    GetHazardActionSerializer
from apps.hazard_action.models import SubmissionHazardActionCompletedPerson, SubmissionHazardActionCompletion, SubmissionHazardActionPerson, Submissionhap
from apps.language.models import Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user.models import User
from apps.user_settings_profile.models import UserProfile


class UpdateHazardAction(APIView):
    permission_classes = [SofviePermission]

    @transaction.atomic
    def post(self, request, *args, **kwargs):       

        self.person_instance = self.request.user.user_per_id        
        self.person_email = User.objects.get(user_per_id=self.person_instance.per_id).email
        self.payload_data = request.data

        self.REPORT_FORM_ID = 131042

        self.immediate_action = False

        try:
            self.sha_id = self.payload_data.pop('ID', '')
            self.submission_header_id = self.payload_data.pop("submissionheaderid", None)
            self.sha_instance = Submissionhap.objects.get(id=self.sha_id)

            # check action_status, if completed let user know. 
            # Mostly to avoid editing through endpoint call directly from 3rd party application like postman
            if self.sha_instance.action_status.lower() == 'complete':
                return Response({"message": "This hazard action is already completed"}, status = status.HTTP_400_BAD_REQUEST)
            
            # update SubmissionHeader table.
            update_submission_header(self)

            # update SubmissionHAP table and submission_hazard_action_person
            update_hazard_action(self)      

            #  send emails
            # email list = distinct( new assignees - updated by)
            if self.further_action_required == True:

                lng_name = UserProfile.objects.get(upr_per=self.person_instance).upr_language
                self.lng_id = Language.objects.get(lng_name=lng_name).lng_id
                ltr_ids = [166, 4255, 4256, 4257, 4258, 4259, 4260, 4261, 4262, 3606, 3607, 3608, 8469, 1952, 1903, 1298, 1305, 1999]
                self.email_translations = get_translation(ltr_ids, self.lng_id)

                self.report_name = Reports.objects.get(singleformreportid=self.REPORT_FORM_ID)
                
                self.email_list = get_email_list(self)
                send_emails(self)
                
            return Response({"Message": f"Successfully update hazard action {self.submission_header_id}"}, status = status.HTTP_200_OK)
        except Exception as e:
            return Response({"Message": f"Failed to Update Hazard action. {e}"}, status = status.HTTP_400_BAD_REQUEST)


@transaction.atomic
def update_submission_header(self):
    header_date = self.payload_data.pop('HeaderDate', None)

    try:
        # check to see if the header date is a proper date
        datetime.strptime(header_date, '%Y-%m-%dT%HH:%M')
    except ValueError:
        # if not a proper date then use today's date
        header_date = f"{datetime.now():%Y-%m-%dT%H:%M}"

    self.sha_header_update_payload = {
        "headerdate" : header_date,
        "site": self.payload_data.pop('Site', None),
        "jobnumber" : self.payload_data.pop('JobNumber', None),
        "sitelevel" : self.payload_data.pop('SiteLevel', None),
        "workplace" : self.payload_data.pop('Workplace', None), 
        "supervisor": self.payload_data.pop('Supervisor', None),   
    }

    Submissionheader.objects.filter(
        id = self.submission_header_id
    ).update(**self.sha_header_update_payload)

    return

@transaction.atomic
def update_hazard_action(self):

    """
    - prepare payload to update Submissionhap
    - if further action not required - set action status to False
    - if action_by_who has two or more values set sha_is_group_action True
        if action_by_who has one value set sha_is_group_action False
    - if group_action add action_by_who per ids in submission_heazard_action_person table only.
        if not add in both SubmnissionHAP and submission_heazard_action_person
    """

    sha_update_payload = prepare_sha_update_payload(self)

    self.action_by_who = self.payload_data.pop('action_by_who', [])
    if self.action_by_who is None:
        self.action_by_who = []
    action_by_who_len = len(self.action_by_who)
    sha_update_payload['action_by_who'] = None

    if action_by_who_len == 1:
        sha_update_payload['action_by_who'] = self.action_by_who[0]
    
    if self.sha_instance.sha_is_group_action == False and action_by_who_len > 1:
        sha_update_payload['sha_is_group_action'] = True

    if self.immediate_action:
        sha_update_payload['completed_action_taken'] = sha_update_payload['immediate_action_taken']
        sha_update_payload['completed_action_type'] = sha_update_payload['immediate_action_type']
        sha_update_payload['completed_action_score'] = sha_update_payload['immediate_action_score']
        sha_update_payload['action_completed_date'] = datetime.now()
        sha_update_payload['action_complete_by_who'] = self.person_instance.per_id
    
    # update SubmissionHAP table
    Submissionhap.objects.filter(
        id = self.sha_instance.id
    ).update(
        **sha_update_payload
    )

    if self.immediate_action:
        # when immediate action is performed and no further action required, consider action is completed
        # and action is completed by action submitted person. 

        shac = SubmissionHazardActionCompletion.objects.create(
            hac_sha = self.sha_instance,
            hac_action_is_complete = True,
            hac_rld_completed_action_type_id = sha_update_payload['immediate_action_type'],
            hac_completed_action_taken = sha_update_payload['immediate_action_taken'],
            hac_completed_action_score = sha_update_payload['immediate_action_score'],
            hac_completed_action_date = datetime.now(),
            hac_created_date = datetime.now(),
            hac_created_by_per = self.person_instance
        )

        SubmissionHazardActionCompletedPerson.objects.create(
            hcp_hac = shac,
            hcp_per = self.person_instance,
            hcp_created_date = datetime.now(),
            hcp_created_by_per = self.person_instance
        )

        # mark hap_enable to 0 if there are any records against the sha 

        SubmissionHazardActionPerson.objects.filter(
            hap_sha = self.sha_instance,
            hap_enable = True
        ).update(
            hap_enable = False,
            hap_modified_by_per = self.person_instance,
            hap_modified_date = datetime.now()
        )
    
    # update action_by_who in submission_hazard_action_person table

    update_action_by_who(self)

    return

def prepare_sha_update_payload(self):

    self.immediate_action_required_and_performed = self.payload_data['immediate_action_required_and_performed']
    self.further_action_required = self.payload_data['further_action_required']
    sha_update_payload = {}
    if self.immediate_action_required_and_performed == True and self.further_action_required == False:
        sha_update_payload['action_status'] = 'Complete'
        self.immediate_action = True

    sha_update_payload['hazard_type'] = self.payload_data.pop('hazard_type', None)
    sha_update_payload['hazard_identification'] = self.payload_data.pop('hazard_identification', None)
    sha_update_payload['hazard_description'] = self.payload_data.pop('hazard_description', None)
    sha_update_payload['potential_risk'] = self.payload_data.pop('potential_risk', None)
    sha_update_payload['immediate_action_required_and_performed'] = self.payload_data.pop('immediate_action_required_and_performed', None)
    sha_update_payload['immediate_action_taken'] = self.payload_data.pop('immediate_action_taken', None)
    sha_update_payload['immediate_action_type'] = self.payload_data.pop('immediate_action_type', None)
    sha_update_payload['further_action_required'] = self.payload_data.pop('further_action_required', None)
    sha_update_payload['recommended_action'] = self.payload_data.pop('recommended_action', None)
    sha_update_payload['action_type'] = self.payload_data.pop('action_type', None)
    sha_update_payload['action_by_when'] = self.payload_data.pop('action_by_when', None)
    sha_update_payload['hazard_identification_score'] = self.payload_data.pop('hazard_identification_score', None)
    sha_update_payload['potential_risk_score'] = self.payload_data.pop('potential_risk_score', None)
    sha_update_payload['immediate_action_score'] = self.payload_data.pop('immediate_action_score', None)
    sha_update_payload['sha_modified_date'] = datetime.now()
    sha_update_payload['sha_modified_by_per'] = self.person_instance

    return sha_update_payload

@transaction.atomic
def update_action_by_who(self):

    """
    - get existing per_ids
    - compare and list misisng per ids and new per_ids
    - set hap_enable = False to missing per ids
    - create new entries for each per_id with self.sha_instance in submission_hazard_action_person

    """

    existing_per_ids = SubmissionHazardActionPerson.objects.filter(
        hap_sha = self.sha_instance,
        hap_enable = True
    ).values_list('hap_per_id', flat = True)

    missing_per_ids = list(set(existing_per_ids).difference(self.action_by_who))
    new_per_ids = list(set(self.action_by_who).difference(existing_per_ids))

    # set hap_enable = False to missing_per_ids 
    SubmissionHazardActionPerson.objects.filter(
        hap_per_id__in = missing_per_ids
    ).update(
        hap_modified_date = datetime.now(),
        hap_modified_by_per = self.person_instance,
        hap_enable = False
    )

    # add new records for new_per_ids (bulk_create)
    bulk_create_payload = [
        SubmissionHazardActionPerson(
            hap_per_id = person,
            hap_created_by_per = self.person_instance,
            hap_sha = self.sha_instance
        ) for person in new_per_ids
    ]

    SubmissionHazardActionPerson.objects.bulk_create(bulk_create_payload)

    self.new_assignee_email_list = User.objects.filter(
        user_per_id__in = new_per_ids
    ).values_list('email', flat = True)


    return


def get_email_list(self):
    # email list = distinct( new assignees - updated by)
    return list(set(self.new_assignee_email_list).difference([self.person_email]))

def send_emails(self):
    report_link = f"{config('EMAIL_REPORT_URL')}{self.report_name.reporturl}/{self.sha_instance.submissionheaderid}?lang={self.lng_id}"

    dict = {
        'report_link': report_link,
        'domain_app': config('FRONTEND_HOST_NAME'),
        'data': self.email_translations,
        'form_name': self.email_translations[1999],
        'created_date': datetime.today().date(),
        'created_by': self.person_instance.full_name
    }
    
    subject = self.email_translations[8469]
    from_email = settings.DEFAULT_FROM_EMAIL_ADMIN
    email_list = self.email_list

    text_content = 'This is an important message.'
    html_content = get_template("hazard_action/report_link_email.html").render(dict)
    msg = EmailMultiAlternatives(subject, text_content, from_email,email_list)
    msg.attach_alternative(html_content, "text/html")
    msg.send()

    return

"""
Expected payload:
{
    "ID": 18666,
    "submissionheaderid": 158734,
    "HeaderDate": "2023-02-01T12:00",
    "Site": 3320,
    "JobNumber": 4248,
    "SiteLevel": 4693,
    "Workplace": "test",
    "Supervisor": 2008,    
    "hazard_type": 1251,
    "hazard_identification": 3270,
    "hazard_description": "asdf",
    "potential_risk": 3136,
    "immediate_action_required_and_performed": true,
    "immediate_action_taken": "adfs",
    "immediate_action_type": 1124,
    "further_action_required": true,
    "recommended_action": "adsf",
    "action_by_who": [
        2094,
        123,
        456,
        788,
        90
    ],
    "action_type": 3262,
    "action_by_when": "2023-02-28",
    "hazard_identification_score": 4,
    "potential_risk_score": 10,
    "immediate_action_score": 3
}        
"""