from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.hazard_action.api.serializers.serializer import \
    GetHazardActionSerializer
from apps.hazard_action.models import Submissionhap
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class GetSingleHazardAction(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):
        payload_data = request.data

        hap_id = payload_data.pop('hap_id', '')
        ha_qs = Submissionhap.objects.get(id=hap_id)

        ha_serializer = GetHazardActionSerializer(ha_qs, context={'request': request}, many=False)

        return Response({"OutPut": ha_serializer.data})