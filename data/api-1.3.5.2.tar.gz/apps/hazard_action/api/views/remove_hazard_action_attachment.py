from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.comments.api.helper_functions.delete_comment import delete_comment
from apps.comments.models import Comments

from apps.hazard_action.api.serializers.serializer import \
    GetHazardActionAttachmentsSerializer
from apps.hazard_action.models import Submissionhapattachments
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class RemoveHazardActionAttachment(APIView):
    permission_classes = [SofviePermission]

    def post(self, request, *args, **kwargs):
        person_id = self.request.user.user_per_id_id
        payload_data = request.data

        haa_id = payload_data.pop('haa_id', '')
        haa_qs = Submissionhapattachments.objects.get(id=haa_id)
       
        ids = []
        ids.append(haa_id)
        print(f"this is haa_id {ids}")
        delete_comment(Comments, ids)
        haa_serializer = GetHazardActionAttachmentsSerializer(haa_qs,
                                        data=payload_data, partial=True)

        if haa_serializer.is_valid():
            haa_serializer.instance.haa_modified_by_per_id = person_id
            haa_serializer.instance.haa_enable = False

            haa_serializer.save()   

        return Response({"Message": "Hazard Action image deleted "
                                    "successfully"})