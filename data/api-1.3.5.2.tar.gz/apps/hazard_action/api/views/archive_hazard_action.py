from django.db import transaction
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from datetime import datetime
from django.db.models import Count

from apps.common_utils.views.validate_permission import RolePermission
from apps.general_action.models import Submissionheader
from apps.hazard_action.models import Submissionhap
from apps.sofvie_user_authorization.api.permissions import SofviePermission

 
class ArchiveHazardAction(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.ArchiveSubmissions.value,)

    @transaction.atomic
    def post(self, request):
        
        try:
            person = self.request.user.user_per_id
            HAZARD_REPORT_FORM_ID = 131042

            # get all submission hap id's from payload into a list
            submission_hap_ids = [hap_id['submission_hap_id'] for hap_id in request.data]

            # get all submission header ids with parent form as hazard report

            sh_ids = Submissionhap.objects.filter(
                id__in=submission_hap_ids,
                submissionheaderid__formdescriptionid__formid = HAZARD_REPORT_FORM_ID
            ).values_list('submissionheaderid', flat = True)

            # check if header has two child forms.. 
            single_child_shd_ids = list(Submissionhap.objects.values_list(
                'submissionheaderid', flat = True
            ).annotate(
                header_count = Count('submissionheaderid')
            ).filter(
                submissionheaderid__in = sh_ids,        
                sha_enable = True,
                header_count = 1
            ))

            # update sha_enable to False for all submission_hap_ids in Submissionhap at once. 
            archve_submissionHap = Submissionhap.objects.filter(
                    id__in=submission_hap_ids
                ).update(
                    sha_enable=False,
                    sha_archived_date = datetime.now(),
                    sha_archived_by_per = person
                )
            
            # update isarchived in Submissionheader model for sh_ids
            if single_child_shd_ids:
                arhive_submission_header = Submissionheader.objects.filter(
                    id__in = single_child_shd_ids
                ).update(
                    isarchived = True,
                    archiveddate = datetime.now(),
                    archived_by_per = person
                )
            
            return Response({"Data": f"Data Archived successfully {request.data}"}, status = status.HTTP_200_OK)
        except Exception as e:
            return Response({"Data": f"Failed to archive. \n{e}"}, status=status.HTTP_400_BAD_REQUEST)
