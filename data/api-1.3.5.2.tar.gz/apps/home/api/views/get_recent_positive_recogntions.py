from django.db.models import Subquery, F, Q, OuterRef
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.home.api.views.common_functions_home_page import filter_with_jobs, verify_sites_jobs
from apps.language.models import Language
from apps.recognition.models import SubmissionPositiveRecognitionPerson
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from django.db import connection
from apps.incident_management.api.utlity_function import dictfetchall
from datetime import datetime
from rest_framework import status

class GetRecentPositiveRecognitions(APIView):
    permission_classes = [SofviePermission]
    

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per=person_id).upr_language
        lng_id = Language.objects.get(lng_name=lng_name).lng_id
        self.site_ids = request.data.pop('sites', [])
        self.job_ids = request.data.pop('jobs', [])

        output_payload = {
            "OutPut" : []
        }

        try:
            verify_sites_jobs(self, person_id)
            
            with connection.cursor() as cursor:
                cursor.execute("call get_home_positive_recognitions_by_sites(%s,%s)", (self.sites, lng_id))
                self.data = dictfetchall(cursor)
                recent_pids = filter_with_jobs(self)
            output_payload['OutPut'] = recent_pids
            return Response(output_payload, status=status.HTTP_200_OK)
        
        except Exception as e:
            output_payload['message'] = str(e)
            return Response(output_payload, status = status.HTTP_400_BAD_REQUEST)