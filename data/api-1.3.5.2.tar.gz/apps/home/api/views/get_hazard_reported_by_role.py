from django.db.models import Subquery, F, Q, OuterRef
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.language.models import Language
from apps.recognition.models import SubmissionPositiveRecognitionPerson
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from django.db import connection
from apps.incident_management.api.utlity_function import dictfetchall
from apps.home.api.views.common_functions_home_page import verify_sites_jobs
from datetime import datetime
import pandas as pd

class GetHazardReportedByRole(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):

        person_id = self.request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per=person_id).upr_language
        lng_id = Language.objects.get(lng_name=lng_name).lng_id
        self.site_ids = request.data.get('selected_site_ids', [])
        startDate = request.data['startDate']
        endDate = request.data['endDate']

        verify_sites_jobs(self, person_id, include_jobs= False)

        immediate_actions_only = {
            "roles": [],
            "total": []
        }

        further_actions = {
            "roles": [],
            "total": []
        }

        with connection.cursor() as cursor:
            cursor.execute("call get_hazard_reported_by_role_by_site(%s,%s,%s,%s)",(self.sites, startDate, endDate, lng_id),)
            df = pd.DataFrame(dictfetchall(cursor))
            if not df.empty:
                df_immediate = df.query("action_required_type == 'IMMEDIATE'")
                df_follow_up = df.query("action_required_type == 'FOLLOWUP'")
                immediate_actions_only['roles'] = df_immediate['role_name'].tolist()
                immediate_actions_only['total'] = df_immediate['total'].tolist()

                further_actions['roles'] = df_follow_up['role_name'].tolist()
                further_actions['total'] = df_follow_up['total'].tolist()
        return Response({"immediate_actions_only": immediate_actions_only, "further_actions": further_actions})