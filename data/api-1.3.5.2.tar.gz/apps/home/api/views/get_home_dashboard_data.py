import pandas as pd
from django.db.models import Subquery, F, Q, OuterRef
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.language.models import Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from django.db import connection
from apps.incident_management.api.utlity_function import dictfetchall
from datetime import datetime, timedelta
from apps.target.models import Supervisortargets
from apps.common_utils.views.get_translations import get_translation

class GetDashboardDataForHomePage(APIView):
    permission_classes = [SofviePermission]

    def get_target_supervisor_count(self, cursor, person_id, start_of_month, end_of_month, form_id, target):
        cursor.execute(f'call get_target_supervisor_count(%s,%s,%s,%s)',([person_id],[start_of_month],[end_of_month],[form_id]))
        rowData = dictfetchall(cursor)
        count = rowData[0]['count']
        todo = target - count
        if count >= target:
            todo = 0
        return todo

    def get(self, request):

        person_id = self.request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per=person_id).upr_language
        lng_obj = Language.objects.get(lng_name=lng_name)
        lng_id = lng_obj.lng_id

        '''
        The output consists of each line displayed in the homepage dashboard
        The key 'line' is the actual translated line displayed
        The key 'clickable' tells wheather the line is clickable or not
        The key 'navigateTo' tells the page the line is supposed to take the user to if required
        '''

        output = {
            "line1": {
                "line": None,
                "clickable": False,
                "navigateTo": None
            },
            "line2": {
                "line": None,
                "clickable": False,
                "navigateTo": None
            },
            "line3": {
                "line": None,
                "clickable": False,
                "navigateTo": None
            },
            "line4": {
                "line": None,
                "clickable": False,
                "navigateTo": None
            }
        }

        todayDate = datetime.now()
        start_of_month = todayDate.strftime("%Y-%m-01")
        next_month = todayDate.replace(day=28) + timedelta(days=4)
        end_of_month = next_month - timedelta(days=next_month.day)
        end_of_month = end_of_month.strftime("%Y-%m-%d")

        ltr_ids = [9455, 9456, 9457, 9458, 9459, 9460, 1067, 979, 1033, 1421, 1344, 9461, 9466]
        get_trans = get_translation(ltr_ids, lng_obj)

        target_frequency = None
        targets_ever_assigned = False

        # Checking if the the user has any Targets assigned
        if Supervisortargets.objects.filter(
            sta_per_id = person_id,
            sta_enable = True).exists():
            targets_ever_assigned = True

        with connection.cursor() as cursor:
            # get actions data for home page dashboard data
            cursor.execute(f'call get_home_dashboard_actions_data(%s,%s)',([lng_id], [person_id]))  
            open_actions_insight = dictfetchall(cursor)[0]
            
            # get documents data for home page dashboard data
            cursor.execute(f'call get_home_dashboard_documents_data(%s,%s)',([lng_id], [person_id]))  
            open_documents_insight = dictfetchall(cursor)[0]

            # get incidents data for home page dashboard data
            cursor.execute(f'call get_home_dashboard_incidents_data(%s,%s)',([lng_id], [person_id]))
            open_incidents_insight = dictfetchall(cursor)[0]
            
            # get targets data for home page dashboard data
            cursor.execute(f'call get_target_frequency(%s)',([person_id]))  
            target_frequency = dictfetchall(cursor)
            
            '''
            The sentences to be displayed are dynamic and is based on the user data for each type 
            ie actions, documents, incidents and targets.
            The sentence_type tells what type it is.
            1 -> actions
            2 -> documents
            3 -> incidents
            4 -> targets
            The sentence_type_count helps to determine the combinations of each sentence_type
            Example: If the user has only pending actions and documents, then 
            sentence_type would be '12'
            If the sentence_type_count is 0, then the user is all caught up with actions, documents, incidents or targets assigned hence the sentence_type_count is initialized to -1

            The translated lines will contain the placeholders like item1 to be replaced with the actual value corresponding to it
            '''
            sentence_type = ''
            sentence_type_count = -1
            if open_actions_insight['actions_ever_assigned_flag'] or open_documents_insight['doc_ever_assigned_flag'] or open_incidents_insight['incidents_ever_assigned_flag'] or targets_ever_assigned:
                sentence_type_count = 0
                if open_actions_insight['actions_ever_assigned_flag'] and not open_actions_insight['translation_type'] == '0':
                    open_actions_insight = open_actions_insight['translation_type'].replace('N1', str(open_actions_insight['total'])).replace('N2', str(open_actions_insight['due_total'])).replace('N3', str(open_actions_insight['overdue_total']))
                    sentence_type = '1'
                    sentence_type_count += 1
                if open_documents_insight['doc_ever_assigned_flag'] and not open_documents_insight['translation_type'] == '0':
                    open_documents_insight = open_documents_insight['translation_type'].replace('N1', str(open_documents_insight['total'])).replace('N2', str(open_documents_insight['due_total'])).replace('N3', str(open_documents_insight['overdue_total']))
                    sentence_type = f'{sentence_type}2'
                    sentence_type_count += 1
                if open_incidents_insight['incidents_ever_assigned_flag'] and not open_incidents_insight['translation_type'] == '0':
                    open_incidents_insight = open_incidents_insight['translation_type'].replace('N1', str(open_incidents_insight['total'])).replace('N2', str(open_incidents_insight['date_bucket_total'])).replace('N3', str(open_incidents_insight['date_bucket_type']))
                    sentence_type = f'{sentence_type}3'
                    sentence_type_count += 1
                if targets_ever_assigned:
                    df_target_frequency = pd.DataFrame(target_frequency)
                    if not df_target_frequency.empty:
                        df_target_frequency['todo'] = df_target_frequency.apply(lambda x: self.get_target_supervisor_count(cursor, person_id, start_of_month, end_of_month, x.form_id, x.target), axis = 1)
                        total = df_target_frequency['target'].sum()
                        total_todo = df_target_frequency['todo'].sum()
                        completed = 100 - (total_todo*100/total)
                        if not completed == 100:
                            sentence_type = f'{sentence_type}4'
                            sentence_type_count += 1
                            open_targets_insight = get_trans[9455].replace('N1', str(round(completed)))
                
            else:
                output['line1']['line'] = get_trans[9456].replace('item1', f"{get_trans[1067]}, {get_trans[1344]}, {get_trans[979]} {get_trans[9466]} {get_trans[1033]}")

            if sentence_type_count == 0:
                output['line1']['line'] = get_trans[9457]
                output['line2']['line'] = get_trans[9458].replace('item1', f"{get_trans[1067]}, {get_trans[1344]}, {get_trans[979]} {get_trans[9466]} {get_trans[1033]}")
            elif sentence_type_count == 1:
                output['line1']['line'] = get_trans[9459]
                output['line2']['line'] = f"{get_trans[9460]} {get_trans[9458].lower()}"
                output['line1']['clickable'] = True
                if sentence_type == '1':
                    output['line1']['line'] = f"{output['line1']['line']} {open_actions_insight}"
                    output['line2']['line'] = output['line2']['line'].replace("item1", f"{get_trans[1344]}, {get_trans[979]} {get_trans[9466]} {get_trans[1033]}")
                    output['line1']['navigateTo'] = "actions"
                elif sentence_type == '2':
                    output['line1']['line'] = f"{output['line1']['line']} {open_documents_insight}"
                    output['line2']['line'] = output['line2']['line'].replace("item1", f"{get_trans[1067]}, {get_trans[979]} {get_trans[9466]} {get_trans[1033]}")
                    output['line1']['navigateTo'] = "documents"
                elif sentence_type == '3':
                    output['line1']['line'] = f"{output['line1']['line']} {open_incidents_insight}"
                    output['line2']['line'] = output['line2']['line'].replace("item1", f"{get_trans[1067]}, {get_trans[1344]} {get_trans[9466]} {get_trans[1033]}")
                    output['line1']['navigateTo'] = "incidents"
                elif sentence_type == '4':
                    output['line1']['line'] = f"{output['line1']['line']} {open_targets_insight}"
                    output['line2']['line'] = output['line2']['line'].replace("item1", f"{get_trans[1067]}, {get_trans[1344]} {get_trans[9466]} {get_trans[979]}")
                    output['line1']['navigateTo'] = "targets"
            elif sentence_type_count == 2:
                output['line1']['line'] = f"{get_trans[1421]}, "
                output['line1']['clickable'] = True
                output['line2']['line'] = f"{get_trans[9466].capitalize()} "
                output['line2']['clickable'] = True
                output['line3']['line'] = f"{get_trans[9460]} {get_trans[9458].lower()}"
                if sentence_type == '12':
                    output['line1']['line'] = f"{output['line1']['line']} {open_actions_insight.lower()}"
                    output['line2']['line'] = f"{output['line2']['line']} {open_documents_insight.lower()}"
                    output['line3']['line'] = output['line3']['line'].replace("item1", f"{get_trans[979]} {get_trans[9466]} {get_trans[1033]}")
                    output['line1']['navigateTo'] = "actions"
                    output['line2']['navigateTo'] = "documents"
                elif sentence_type == '13':
                    output['line1']['line'] = f"{output['line1']['line']} {open_actions_insight.lower()}"
                    output['line2']['line'] = f"{output['line2']['line']} {open_incidents_insight.lower()}"
                    output['line3']['line'] = output['line3']['line'].replace("item1", f"{get_trans[1344]} {get_trans[9466]} {get_trans[1033]}")
                    output['line1']['navigateTo'] = "actions"
                    output['line2']['navigateTo'] = "incidents"
                elif sentence_type == '14':
                    output['line1']['line'] = f"{output['line1']['line']} {open_actions_insight.lower()}"
                    output['line2']['line'] = f"{output['line2']['line']} {open_targets_insight.lower()}"
                    output['line3']['line'] = output['line3']['line'].replace("item1", f"{get_trans[1344]} {get_trans[9466]} {get_trans[979]}")
                    output['line1']['navigateTo'] = "actions"
                    output['line2']['navigateTo'] = "targets"
                elif sentence_type == '23':
                    output['line1']['line'] = f"{output['line1']['line']} {open_documents_insight.lower()}"
                    output['line2']['line'] = f"{output['line2']['line']} {open_incidents_insight.lower()}"
                    output['line3']['line'] = output['line3']['line'].replace("item1", f"{get_trans[1067]} {get_trans[9466]} {get_trans[1033]}")
                    output['line1']['navigateTo'] = "documents"
                    output['line2']['navigateTo'] = "incidents"
                elif sentence_type == '24':
                    output['line1']['line'] = f"{output['line1']['line']} {open_documents_insight.lower()}"
                    output['line2']['line'] = f"{output['line2']['line']} {open_targets_insight.lower()}"
                    output['line3']['line'] = output['line3']['line'].replace("item1", f"{get_trans[1067]} {get_trans[9466]} {get_trans[979]}")
                    output['line1']['navigateTo'] = "documents"
                    output['line2']['navigateTo'] = "targets"
                elif sentence_type == '34':
                    output['line1']['line'] = f"{output['line1']['line']} {open_incidents_insight.lower()}"
                    output['line2']['line'] = f"{output['line2']['line']} {open_targets_insight.lower()}"
                    output['line3']['line'] = output['line3']['line'].replace("item1", f"{get_trans[1067]} {get_trans[9466]} {get_trans[1344]}")
                    output['line1']['navigateTo'] = "incidents"
                    output['line2']['navigateTo'] = "targets"
            elif sentence_type_count == 3:
                output['line1']['line']  = f"{get_trans[1421]}, "
                output['line3']['line']  = f"{get_trans[9466].capitalize()} "
                output['line4']['line']  = f"{get_trans[9458]}"
                output['line1']['clickable'] = True
                output['line2']['clickable'] = True
                output['line3']['clickable'] = True
                if sentence_type == '123':
                    output['line1']['line'] = f"{output['line1']['line']} {open_actions_insight.lower()}"
                    output['line2']['line'] = f"{open_documents_insight}"
                    output['line3']['line'] = f"{output['line3']['line']} {open_incidents_insight.lower()}"
                    output['line4']['line'] = output['line4']['line'].replace("item1", f"{get_trans[1033]}")
                    output['line1']['navigateTo'] = "actions"
                    output['line2']['navigateTo'] = "documents"
                    output['line3']['navigateTo'] = "incidents"
                elif sentence_type == '134':
                    output['line1']['line'] = f"{output['line1']['line']} {open_actions_insight.lower()}"
                    output['line2']['line'] = f"{open_incidents_insight}"
                    output['line3']['line'] = f"{output['line3']['line']} {open_targets_insight.lower()}"
                    output['line4']['line'] = output['line4']['line'].replace("item1", f"{get_trans[1344]}")
                    output['line1']['navigateTo'] = "actions"
                    output['line2']['navigateTo'] = "incidents"
                    output['line3']['navigateTo'] = "targets"
                elif sentence_type == '124':
                    output['line1']['line'] = f"{output['line1']['line']} {open_actions_insight.lower()}"
                    output['line2']['line'] = f"{open_documents_insight}"
                    output['line3']['line'] = f"{output['line3']['line']} {open_targets_insight.lower()}"
                    output['line4']['line'] = output['line4']['line'].replace("item1", f"{get_trans[979]}")
                    output['line1']['navigateTo'] = "actions"
                    output['line2']['navigateTo'] = "documents"
                    output['line3']['navigateTo'] = "targets"
                elif sentence_type == '234':
                    output['line1']['line'] = f"{output['line1']['line']} {open_documents_insight.lower()}"
                    output['line2']['line'] = f"{open_incidents_insight}"
                    output['line3']['line'] = f"{output['line3']['line']} {open_targets_insight.lower()}"
                    output['line4']['line'] = output['line4']['line'].replace("item1", f"{get_trans[1067]}")
                    output['line1']['navigateTo'] = "documents"
                    output['line2']['navigateTo'] = "incidents"
                    output['line3']['navigateTo'] = "targets"
            elif sentence_type_count == 4:
                output['line1']['line'] = f"{get_trans[1421]}, {open_actions_insight.lower()}" 
                output['line2']['line'] = f"{get_trans[9461]} {open_documents_insight.lower()}"
                output['line3']['line'] = open_incidents_insight
                output['line4']['line'] = open_targets_insight
                output['line1']['navigateTo'] = "actions"
                output['line2']['navigateTo'] = "documents"
                output['line3']['navigateTo'] = "incidents"
                output['line4']['navigateTo'] = "targets"
                output['line1']['clickable'] = True
                output['line2']['clickable'] = True
                output['line3']['clickable'] = True
                output['line4']['clickable'] = True     
            
        return Response({"output": output})