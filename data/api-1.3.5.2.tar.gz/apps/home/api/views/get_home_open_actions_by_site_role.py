from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from apps.home.api.views.common_functions_home_page import filter_with_jobs, verify_sites_jobs
from apps.language.models import Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from django.db import connection
from apps.incident_management.api.utlity_function import dictfetchall


class GetHomeActionsBySiteDateRole(APIView):
    permission_classes = [SofviePermission]    

    def post(self, request):

        self.site_ids = request.data.pop('sites', [])
        self.job_ids = request.data.pop('jobs', [])
        role_id = request.data.pop('role_id', '')
        start_date = request.data.pop('start_date', '')
        end_date = request.data.pop('end_date', '')

        output_payload = {
            "action_role_details" : [],
            "open_action_role_count" : 0,
            "role": role_id            
        }

        try:

            person_id = self.request.user.user_per_id_id
            lng_name = UserProfile.objects.get(upr_per=person_id).upr_language
            lng_id = Language.objects.get(lng_name=lng_name).lng_id
            
            verify_sites_jobs(self, person_id)

            with connection.cursor() as cursor:
                cursor.execute("call get_home_actions_by_roles(%s,%s,%s,%s,%s)", (self.sites,role_id, start_date, end_date, lng_id))
                self.data = dictfetchall(cursor)
                open_action_role_count = len(self.data)
            
            actions_by_roles = filter_with_jobs(self)

            output_payload['action_role_details'] = actions_by_roles
            output_payload['open_action_role_count'] = open_action_role_count
            output_payload['role'] = role_id

            return Response(output_payload, status=status.HTTP_200_OK)
        
        except Exception as e:
            output_payload['message'] = str(e)
            return Response(output_payload, status = status.HTTP_400_BAD_REQUEST)