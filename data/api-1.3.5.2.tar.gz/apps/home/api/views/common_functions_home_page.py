import pandas as pd
from apps.employee.helper_function_user_visibility import helperEmployeeJobs, helperEmployeeSites


def verify_sites_jobs(self, person_id, include_jobs = True):
    # check if site_ids from input payload are in users data visibility

    per_sites, data_user_visibility = helperEmployeeSites(self, person_id)
    user_sites = list(map(lambda e: e['rld_id'], per_sites))
    homepage_sites_list = list(set(self.site_ids).intersection(user_sites))
    self.sites =  ','.join(str(x) for x in homepage_sites_list)

    if include_jobs:
        per_jobs, data_user_visibility = helperEmployeeJobs(self, person_id)
        user_jobs = list(map(lambda e: e['rld_id'], per_jobs))
        if self.job_ids:
            self.job_ids = list(map(int, self.job_ids.split(',')))
        homepage_jobs_list = list(set(self.job_ids).intersection(user_jobs))
        self.jobs =  ','.join(str(x) for x in homepage_jobs_list)

    


def filter_with_jobs(self):

    return_data = []
    job_list = self.jobs.split(',')
    df = pd.DataFrame(self.data)
    if not df.empty:
        df['job'] = df['job'].astype(str)
        df = df.query("job in @job_list", inplace=False)
        return_data = df.to_dict(orient='records')
    return return_data