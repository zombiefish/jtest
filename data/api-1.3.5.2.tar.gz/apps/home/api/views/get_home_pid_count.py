from django.db.models import Subquery, F, Q, OuterRef
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.language.models import Language
from apps.recognition.models import SubmissionPositiveRecognitionPerson
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from django.db import connection
from apps.incident_management.api.utlity_function import dictfetchall
from datetime import datetime

class GetHomePidCountBySiteDate(APIView):
    permission_classes = [SofviePermission]
    

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per=person_id).upr_language
        lng_id = Language.objects.get(lng_name=lng_name).lng_id
        site_ids = request.data['sites_ids']
        start_date = request.data['start_date']
        end_date = request.data['end_date']

        sites =  ','.join(str(x) for x in site_ids)
        with connection.cursor() as cursor:
            cursor.execute("call get_home_positive_recognitions_count_by_site(%s,%s,%s,%s)", (sites, lng_id, start_date, end_date))
            pid_counts = dictfetchall(cursor)
        return Response({"OutPut": pid_counts})