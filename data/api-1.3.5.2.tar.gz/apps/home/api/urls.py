from django.urls import path
from apps.home.api.views.get_home_open_actions_by_site import GetHomeOpenActionsBySite
from apps.home.api.views.get_home_open_actions_by_site_role import GetHomeActionsBySiteDateRole
from apps.home.api.views.get_home_pid_count import GetHomePidCountBySiteDate
from apps.home.api.views.get_recent_positive_recogntions import GetRecentPositiveRecognitions
from apps.home.api.views.get_hazard_reported_by_role import GetHazardReportedByRole
from apps.home.api.views.get_home_dashboard_data import GetDashboardDataForHomePage
from apps.home.api.views.get_home_incidents_by_site import GetHomeOpenIncidentsBySite


urlpatterns = [
    path('get-home-pid-data-by-site/', GetRecentPositiveRecognitions.as_view()),
    path('get-home-pid-count-by-site-date/', GetHomePidCountBySiteDate.as_view()),    
    path('get-hazard-reported-by-role/', GetHazardReportedByRole.as_view()),
    path('get-home-incidents-by-site/', GetHomeOpenIncidentsBySite.as_view()),
    path('get-home-open-actions-by-site/', GetHomeOpenActionsBySite.as_view()),
    path('get-home-dashboard_data/', GetDashboardDataForHomePage.as_view()),
    path('get-home-open-actions-by-site-role/', GetHomeActionsBySiteDateRole.as_view()),
]