from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from apps.language.models import Language
from django.db import connection
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.incident_management.api.utlity_function import dictfetchall


class GetLikesByPositiveRecognitionById(APIView):
    permission_classes = [SofviePermission]
    parser_classes = [JSONParser]

    def post(self, request):
        recognition_id = request.data['recognition_id']        
        person = request.user.user_per_id
        language = UserProfile.objects.get(upr_per = person).upr_language
        lng_id = Language.objects.get(lng_name = language).lng_id   
        likes_data = get_likes_by_pid(recognition_id, lng_id, person)

        return Response(likes_data)

def get_likes_by_pid(recognition_id, lng_id, person):
    with connection.cursor() as cursor:
        cursor.execute("call get_likes_by_positive_recognition_id(%s, %s)", ([recognition_id, lng_id]))
        row = dictfetchall(cursor)
    return row
       
