import json
# from datetime import time, datetime
import datetime

from django.db.models import Prefetch, Q
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
import pandas as pd
from rest_framework import serializers

from apps.employee.models import Employee, EmployeeSite
from apps.general_action.models import Submissionheader
from apps.hap.api.serializers.serializers import \
    HapSubmissionCountByTypeAndYearSerializer
from apps.hazard_action.models import Submissionhap
from apps.person.models import Person
from apps.language.models import LanguageTranslation, Language
from apps.recognition.models import SubmissionPositiveRecognition, \
    SubmissionPositiveRecognitionPerson
from apps.rmm_ora.api.date_filter_utils import date_filter
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from apps.reflist.models import RefListDetail
class PidCountBySite(APIView):
    permission_classes = [SofviePermission]

    def post(self, request, format=None, *args, **kwargs):
        start_date = request.data['start_date']
        end_date = request.data['end_date']

        person=self.request.user.user_per_id_id
        lng_name=UserProfile.objects.get(upr_per_id=person).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)

        filter_is_archived = [Q(submissionheader__isarchived__isnull = True) | Q(submissionheader__isarchived = 0)]        

        recognition_query = SubmissionPositiveRecognition.objects.select_related(
            'submissionheader'
        ).filter(
            *filter_is_archived,            
            submissionheader__formsubmissiondate__range=date_filter(start_date, end_date),
            spr_enable = True
        ).prefetch_related(
            Prefetch('submission_positive_recognition',
                     SubmissionPositiveRecognitionPerson.objects.only(
                         'recognitionof'))).values(
            'id',
            'submissionheader__site',
            'submissionheader__formsubmissiondate',
            'submission_positive_recognition__recognitionof',
        )

        recogn_df = pd.DataFrame(recognition_query)                   

        site_ref_list_detail = RefListDetail.objects.filter(
            rld_rlh_id=1,
            rld_enable=1,
        ).values('rld_id',  'rld_name', 'rld_tag_type')

        ref_list_detail_df = pd.DataFrame(site_ref_list_detail)

        site_rld_tags = site_ref_list_detail.values_list('rld_name')
        

        translate_df = pd.DataFrame(LanguageTranslation.objects.filter(
            ltr_lng=lng_id,
            ltr_enable=1,
            ltr_tag__in = site_rld_tags
        ).values('ltr_tag',  'ltr_text', 'ltr_tag_type'))
        

        ## DATA CLEANING - START
        if len(recogn_df) > 1:            

            recognition_count = pd.DataFrame(
                recogn_df.groupby(['submissionheader__site', 'submission_positive_recognition__recognitionof']).size(),
                columns=['recogn_count']).reset_index()

            
            person_count_df = pd.DataFrame(
                recognition_count.groupby('submissionheader__site').size(),
                columns=['person_count']).reset_index()
            
            recognition_count_df = recognition_count.groupby('submissionheader__site')['recogn_count'].sum().reset_index()           
            

            site_df = pd.merge(recognition_count_df, person_count_df,
                               right_on='submissionheader__site',
                               left_on='submissionheader__site', how='left')           

            site_df['avg_count'] = site_df['recogn_count'] / site_df['person_count']
            

            site_df = site_df.sort_values(by=['avg_count'], ascending=False)
            site_df.rename({'recogn_count': 'Count of Recognitions',
                            'avg_count': 'Avg # of Recognitions per Person'},
                           axis=1, inplace=True)
            site_df = site_df.fillna(0)
            site_df['Avg # of Recognitions per Person'] = site_df['Avg # of Recognitions per Person'].apply(lambda x: int(0.5 + x))

            # Format the dataframe as per Plotly requirement:
            site_df = pd.merge(site_df, ref_list_detail_df, how='left', left_on=['submissionheader__site'], right_on=['rld_id'])            

            site_df = pd.merge(site_df, translate_df, how='left', left_on=['rld_name', 'rld_tag_type'], right_on=['ltr_tag', 'ltr_tag_type'])            
            site_df = site_df[site_df['ltr_text'].notna()]    

            site_df = site_df.sort_values(by=['ltr_text'], ascending=True)

            response_json = {
                "x_axis": site_df['ltr_text'].values,
                "y_axis": [site_df['Count of Recognitions'].values,
                           site_df['Avg # of Recognitions per Person'].values]
            }


        else:
            return Response(f"No Data to Show")

        return Response(response_json)
