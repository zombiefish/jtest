import os
import uuid
from datetime import datetime
from decouple import config

from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.db import transaction
from django.template.loader import get_template
from rest_framework import status, decorators, viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import parsers
from rest_framework.views import APIView

# importing required models
from apps.common_utils.views.get_translations import get_translation
from apps.general_action.models import Submissionheader, Reports
from apps.hazard_action.models import Submissiondetails, Submissionhap
from apps.language.models import Language
from apps.recognition.models import SubmissionPositiveRecognition, SubmissionPositiveRecognitionPerson
from apps.person.models import Person

from apps.general_action.api.serializers.serializer import SubmissiondetailsExplode
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from apps.recognition.api.views.email_notification import send_email_positive_recognition
from apps.hazard_action.api.views.create_hazard_action import get_user_email
from django.core.files.base import ContentFile
import base64
from apps.common_utils.views.add_attachment import save_the_file
from apps.comments.api.views.add_comment import add_comment
from apps.user.models import User


class AddPositiveID(APIView):
    permission_classes = [SofviePermission]
    
    @transaction.atomic
    def post(self, request):
        person_id = self.request.user.user_per_id_id
        person_instance = Person.objects.get(per_id=person_id)        
        
        positive_id_data = request.data

        email_list = positive_id_data.pop('Distribution', '')
        for recognitionof in positive_id_data['RecognitionOf']:
            get_email = get_user_email(User, recognitionof)
            email_list.append(get_email)        

        submission_header_latest, action = insert_positive_recognition(self, positive_id_data, person_instance)

        send_email_positive_recognition(submission_header_latest, email_list, person_instance)

        return Response({"ID": action.pk,
                         "Message": "Record Added Successfully"})


@transaction.atomic
def insert_positive_recognition(self, positive_id_data, person_instance,submission_header_latest=None,insert_attachments=False):
    header_date = positive_id_data.pop('HeaderDate', '')
    site = positive_id_data.pop('Site', '')
    job_number = positive_id_data.pop('JobNumber', '')
    site_level = positive_id_data.pop('SiteLevel', '')
    work_place = positive_id_data.pop('Workplace', '')
    supervisor = positive_id_data.pop('Supervisor', '')
    recognitionof = positive_id_data.pop('RecognitionOf', '')        
    distribution =  positive_id_data.pop('Distribution', '')
    recognition_type = positive_id_data.pop('RecognitionType', '')
    event_description = positive_id_data.pop('EventDescription', '')
    was_recognition_given = positive_id_data.pop('WasRecognitionGiven', '')
    recognition_given_type = positive_id_data.pop('RecognitionGivenType', '')
    attachments = positive_id_data.pop('attachments', '')


    # Create entry in the Submission Header table - formdescriptionid = 1352
    if not submission_header_latest:
        submission_header_latest = Submissionheader.objects.create(
            formdescriptionid_id=1292,
            submissionid=str(uuid.uuid4()).upper(),
            headerdate=header_date,
            site=site,
            jobnumber=job_number,
            sitelevel=str(site_level),
            workplace=work_place,
            supervisor=str(supervisor),
            # submittedby_supervisorid=person_id,
            submittedby_supervisorid=person_instance,
            formcreationdate=datetime.now(),
            formsubmissiondate=datetime.now(),
        )
        submission_header_latest.save()
    

    # Create entry in the Submission Details table
    submission_details_record = Submissiondetails.objects.create(
        submissionheaderid_id=submission_header_latest.id
    )
    submission_details_record.save()        

    # Create Entry in Submission Details Explode table 
    for value in distribution:
        explode = SubmissiondetailsExplode.objects.create(
            submissiondetailid_id=submission_details_record.id,
            formfielddescriptionid_id=15525,
            value=value,
            explode_section=None,
        )
        explode.save()

    # submission_positive_recognition_id = submission_positive_recognition_record.id
    positive_id_data['submissionheader'] = submission_header_latest
    positive_id_data['spr_enable'] = 1
    positive_id_data['RecognitionType'] = recognition_type
    positive_id_data['EventDescription'] = event_description
    positive_id_data['WasRecognitionGiven'] = was_recognition_given
    positive_id_data['RecognitionGivenType'] = str(recognition_given_type)
    action = SubmissionPositiveRecognition.objects.create(**positive_id_data)
    action.save()
    
    # Create Entry into SubmissionPositiveRecognitionPerson table 
    for r_value in recognitionof:   
        r_person_instance=Person.objects.get(per_id=r_value)
        submission_positive_recognition_record=SubmissionPositiveRecognitionPerson.objects.create(
            submissionpositiverecognition_id=action.id,
            recognitionof=r_person_instance)
        submission_positive_recognition_record.save()

    if insert_attachments:

        pid_files = []
        for attachment in attachments:
            format, imgstr = attachment['att_file_url'].split(';base64,')
            ext = format.split('/')[-1]
            pid_file = ContentFile(base64.b64decode(imgstr),
                                     name=attachment['att_file_name'] + '_' + datetime.now(
                                     ).strftime('%Y%m-%d%H-%M%S' + '.') + ext)

            pid_files.append(pid_file)

            person_id = self.request.user.user_per_id_id
            data_args = {
                "app": "Positive_Recognition",
                "person_id": person_id,
                "id": action.id,
                "files": pid_files,
                "attachment_type": 'INITIAL',
                "image_timestamp": attachment['att_timestamp'],
                "only_image": True
            }

            response = save_the_file(data_args)

            com_reference_id = response["Successfull Files"]["ids"][0]

            # adding comments
            add_comment(com_cmt_id=6, com_reference_id = com_reference_id, com_comment = attachment['att_comment'], person_id = person_id)


    return submission_header_latest, action
    
    #Sending Email Starting 166071
    # send email for new pid
def send_email_positive_recognition(submission_header_latest, email_list, person_instance):
    # send distribution email
    lng_name = UserProfile.objects.get(upr_per_id=person_instance).upr_language
    lng_id = Language.objects.get(lng_name=lng_name).lng_id
    ltr_ids = [166, 4255, 4256, 4257, 4258, 4259, 4260, 4261, 4262, 3606, 3607, 3608, 8471, 751, 1952,1903, 1298, 1305]
    get_trans = get_translation(ltr_ids, lng_id)
    report_name = Reports.objects.get(singleformreportid=166071)
    
    dict = {'report_link': f"{config('EMAIL_REPORT_URL')}/{report_name.reporturl}/{submission_header_latest.id}?lang={lng_id}",
            'domain_app': config('FRONTEND_HOST_NAME'),
            'data': get_trans,
            'form_name': get_trans[751],
            'created_date': datetime.today().date(),
            'created_by': person_instance.full_name
            }

    subject, from_email, email_list = get_trans[8471], \
                                        settings.DEFAULT_FROM_EMAIL_ADMIN, \
                                        email_list
    text_content = 'This is an important message.'
    html_content = get_template(
        "general_action/general_action_report_link_email.html").render(dict)
    msg = EmailMultiAlternatives(subject, text_content, from_email,
                                    email_list)
    msg.attach_alternative(html_content, "text/html")
    msg.send()
