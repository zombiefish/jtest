from django.db import transaction
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models.expressions import F, OuterRef, Subquery, Value
from django.db.models.functions.text import Concat
from django.db.models import Count, Q
from itertools import groupby
from rest_framework import status

from apps.comments.models import Comments
from apps.recognition.models import CommentLike, SubmissionPositiveRecognitionPerson
from apps.reflist.models import RefListDetail
from apps.recognition.api.views.email_notification import send_email_positive_recognition
from apps.sofvie_user_authorization.api.permissions import SofviePermission

class AddCommentLike(APIView):
    permission_classes = [SofviePermission]

    @transaction.atomic
    def post(self, request):
        person_id = request.user.user_per_id_id
        com_id = request.data['com_id']

        try:            

            position_rld_id = RefListDetail.objects.prefetch_related(
                'employees_pos'
            ).filter(employees_pos__emp_per_id = person_id).values_list('rld_id', flat=True)

            position_rld_id = position_rld_id[0] if list(position_rld_id) else None

            get_liked_persons = CommentLike.objects.filter(
                clk_com_id = com_id,
                clk_enable = True
            ).values_list('clk_created_by_per_id', flat = True)

            if person_id in get_liked_persons:
                return Response({'message': 'You have already liked this comment'}, status=status.HTTP_400_BAD_REQUEST)

            CommentLike.objects.create(
                clk_com_id = com_id,
                clk_cmt_id = 11, #hard_coded
                clk_created_by_per_id = person_id,
                clk_position_id = position_rld_id
            )

            pid = Comments.objects.get(com_id = com_id, com_enable=True).com_reference_id
            
            pid_persons = SubmissionPositiveRecognitionPerson.objects.filter(
                submissionpositiverecognition_id = pid
            ).values_list('recognitionof', flat=True)

            if person_id not in pid_persons:
                send_email_positive_recognition(self, 'new_like_on_comment', pid= pid, com_id = com_id)            

            return Response({'status':'success'}, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({'status':'fail', 'message':str(e)}, status=status.HTTP_400_BAD_REQUEST)
