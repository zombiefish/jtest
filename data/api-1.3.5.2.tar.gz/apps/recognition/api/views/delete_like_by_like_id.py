from django.db import connection
from rest_framework import status
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.sofvie_user_authorization.api.permissions import SofviePermission


class DeleteLikeByLikeId(APIView):
    permission_classes = [SofviePermission]
    parser_classes = [JSONParser]

    def post(self, request):
        like_id = request.data['like_id']

        with connection.cursor() as cursor:
            cursor.execute('call delete_like_by_like_id(%s)', [like_id])
            # row = dictfetchall(cursor)
            return Response("Object Deleted", status=status.HTTP_200_OK)