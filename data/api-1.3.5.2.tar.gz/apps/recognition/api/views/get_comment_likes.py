from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models.expressions import F, OuterRef, Subquery, Value
from django.db.models.functions.text import Concat
from django.db.models import Count, Q, CharField
from itertools import groupby
from rest_framework import status
from apps.language.models import Language, LanguageTranslation

from apps.recognition.models import CommentLike
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile

class GetCommentLikes(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):
        person_id = request.user.user_per_id_id
        com_id = request.data['com_id']
        
        lng_name = UserProfile.objects.get(upr_per = person_id).upr_language
        lng_id = Language.objects.get(lng_name = lng_name).lng_id

        get_comment_likes = get_comment_likes_by_com_id(com_id, lng_id, person_id)

        return Response({'list_comment_likes':get_comment_likes})


def get_comment_likes_by_com_id(com_id, lng_id, person_id):

    likes_list = CommentLike.objects.filter(
        clk_com_id = com_id,
        clk_cmt_id = 11, #hard_coded
        clk_enable = True
    ).annotate(
        liked_by = Concat('clk_created_by_per_id__per_last_name', Value(', '), 'clk_created_by_per_id__per_first_name', Value(' '), 'clk_created_by_per_id__per_middle_name', output_field=CharField(),)            ,
        position_tag  = Subquery(RefListDetail.objects.filter(
            rld_id = OuterRef('clk_position_id')
        ).values('rld_name')[:1]),
        position_tag_type = Subquery(RefListDetail.objects.filter(
            rld_id = OuterRef('clk_position_id')
        ).values('rld_tag_type')[:1]),
        created_date = F('clk_created_date')
    ).values(
        'liked_by',
        'position_tag',
        'position_tag_type',
        'created_date'
    )

    likes_list = likes_list.annotate(
        position = Subquery(LanguageTranslation.objects.filter(
            ltr_tag_type = OuterRef('position_tag_type'),
            ltr_tag = OuterRef('position_tag'),
            ltr_lng_id = lng_id
        ).values('ltr_text')[:1])
    ).values(
        'liked_by',
        'position',
        'created_date'
    )

    return likes_list

