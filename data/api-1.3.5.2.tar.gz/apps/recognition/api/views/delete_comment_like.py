from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models.expressions import F, OuterRef, Subquery, Value
from django.db.models.functions.text import Concat
from django.db.models import Count, Q
from itertools import groupby
from rest_framework import status
from datetime import datetime

from apps.recognition.models import CommentLike
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission

class DeleteCommentLike(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):
        person_id = request.user.user_per_id_id
        clk_com_id = request.data['clk_com_id']

        try:
            CommentLike.objects.filter(
                clk_com_id = clk_com_id,
                clk_created_by_per_id = person_id,
                clk_enable = True,
                clk_cmt_id = 11, #hard_coded                
            ).update(
                clk_enable = False,
                clk_modified_by_per_id = person_id,
                clk_modified_date = datetime.now()        
            )
            return Response({'status':'success'})           
        except Exception as e:
            return Response({'status':'fail', 'message':str(e)}, status=status.HTTP_400_BAD_REQUEST)
