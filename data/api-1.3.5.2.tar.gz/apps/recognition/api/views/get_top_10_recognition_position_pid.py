import datetime
import json

from django.db.models import Sum, Count, Max, F, Prefetch, Subquery, OuterRef
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response
import pandas as pd

from apps.employee.models import Employee
from apps.hazard_action.models import Submissionhap
from apps.person.models import Person
from apps.recognition.models import SubmissionPositiveRecognition, \
    SubmissionPositiveRecognitionPerson
from apps.reflist.models import RefListDetail
from apps.rmm_ora.api.date_filter_utils import date_filter
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.user_settings_profile.models import UserProfile
from apps.language.models import Language, LanguageTranslation
from django.db.models.functions import Substr


def employee_position_name(person_id, queryset_result, *args, **kwargs):
    # Creating empty dict object for map
    person_position_map = dict()
    # Loop and collect the IDS from SubmissionPositiveRecognitionPerson
    ids = [dictionary['submission_positive_recognition__recognitionof'] for
           dictionary in queryset_result]
    # Loop through in Employee object and match with IDS from
    # SubmissionPositiveRecognitionPerson table
    for emp_per_id, emp_pos_id in Employee.objects.filter(
            emp_per_id__in=ids).values_list(
            'emp_per_id', 'emp_pos_id'):
        # append emp_per_id into dict person_position_map and map to emp_pos_id
        person_position_map[emp_per_id] = emp_pos_id
    # Create dict object from reflistdetail table by filtering
    # dict person_position_map values and grab the name of the position

    lng_name = UserProfile.objects.get(upr_per=person_id).upr_language 
    lng_id = Language.objects.get(lng_name=lng_name)     
    position_name = dict(RefListDetail.objects.filter(
        rld_id__in=person_position_map.values()).annotate(pos_name=Subquery(LanguageTranslation.objects.filter(ltr_tag=OuterRef('rld_name'), ltr_tag_type=OuterRef('rld_tag_type'),  ltr_lng = lng_id).values('ltr_text')[:1]),
                        ).values_list('rld_id', 'pos_name'))

    # create empty list of result
    result = []
    # loop through the queryset
    for entry in queryset_result:
        # assign new_entry to entry
        new_entry = entry
        # grab the id from main queryset
        index_id = entry['submission_positive_recognition__recognitionof']
        # append new entry in the value list of the query
        # grab the position_name object and match the index_id

        if index_id:
            new_entry['employee_position'] = position_name.get(
                person_position_map.get(int(index_id)))
            result.append(new_entry)
    return result

class GetTop10RecognitionPosition(APIView):
    permission_classes = [SofviePermission]

    def post(self, request, *args, **kwargs):
        person_id = self.request.user.user_per_id_id
        start_date = request.data['start_date']
        end_date = request.data['end_date']
        first_queryset = SubmissionPositiveRecognition.objects.select_related(
            'submissionheader',
        ).filter(
            submissionheader__isarchived=None,
            submissionheader__formsubmissiondate__range=date_filter(
                start_date, end_date),
            spr_enable = True
        ).prefetch_related(
            Prefetch('submission_positive_recognition',
                     SubmissionPositiveRecognitionPerson.objects.only(
                         'recognitionof'))).values(
            'id',
            'RecognitionType',
            'EventDescription',
            'submissionheader__id',
            'submission_positive_recognition__recognitionof',
        )

        result_of_first_queryset = employee_position_name(person_id,first_queryset)

        # converting payload date into date object
        date_time_obj_start_date = datetime.datetime.strptime(start_date,
                                                              '%Y-%m-%d')
        date_time_obj_end_date = datetime.datetime.strptime(end_date,
                                                            '%Y-%m-%d')
        # Assigning new date object to new variables
        start_date = date_time_obj_start_date.date()
        end_date = date_time_obj_end_date.date()

        # Converting new dates into days
        my_delta = end_date - start_date

        # Calculating the past date
        previous_date_conversion = datetime.timedelta(days=my_delta.days)
        # Assigning past date to a new variable
        new_start_date = start_date - previous_date_conversion

        # Converting dates into string for database query
        format_start_date = datetime.datetime.strftime(new_start_date,
                                                       '%Y-%m-%d')
        start_date = datetime.datetime.strftime(start_date,
                                                '%Y-%m-%d')
        second_queryset = SubmissionPositiveRecognition.objects.select_related(
            'submissionheader',
        ).filter(
            submissionheader__isarchived=None,
            submissionheader__formsubmissiondate__range=date_filter(
                format_start_date, start_date),
            spr_enable = True
        ).prefetch_related(
            Prefetch('submission_positive_recognition',
                     SubmissionPositiveRecognitionPerson.objects.only(
                         'recognitionof'))).values(
            'id',
            'RecognitionType',
            'EventDescription',
            'submissionheader__id',
            'submission_positive_recognition__recognitionof',
        )

        result_of_second_queryset = employee_position_name(person_id, second_queryset)

        if len(result_of_first_queryset) and len(result_of_second_queryset) > 1:
            df1 = pd.DataFrame(result_of_first_queryset)
            df2 = pd.DataFrame(result_of_second_queryset)
        else:
            trend_df = []
            for i in range(1, 11):
                trend_df.append({
                    'keyword': 'No Data To Show',
                    'hazard_count_previous': 0,
                    'hazard_count_current': 0,
                    'hazard_trend_diff': 0,
                    'hazard_value': 0,
                    'trend': 'neutral',
                    'hazard_trend2': 'neutral'
                })
            return Response(trend_df)

        def calc_trend_direction(val):
            if val > 0:
                return 'up'
            elif val < 0:
                return 'down'
            else:
                return 'neutral'

        def calc_trend(df1, df2, field, top_n=10):
            # Calculate trend
            trend_df = pd.merge(df1, df2, how='left', on=field)
            trend_df['hazard_trend_diff'] = trend_df['count_x'] - trend_df[
                'count_y']
            trend_df['hazard_trend2'] = trend_df['hazard_trend_diff'].apply(
                calc_trend_direction)
            trend_df = trend_df.fillna(0).copy()
            trend_df['hazard_trend_diff'] = trend_df['count_x'] - trend_df[
                'count_y']
            trend_df['trend'] = trend_df['hazard_trend_diff'].apply(
                calc_trend_direction)
            trend_df['count_x'] = trend_df['count_x'].astype('int')
            trend_df['count_y'] = trend_df['count_y'].astype('int')
            trend_df['hazard_trend_diff'] = trend_df[
                'hazard_trend_diff'].astype('int')
            trend_df.rename(columns={
                'count_y': 'hazard_count_previous',
                'count_x': 'hazard_count_current',
                field: 'keyword'
            }, inplace=True)

            # Sort by "current" count of keywords
            trend_df = trend_df.sort_values(by=['hazard_count_current'],
                                            ascending=False)
            while len(trend_df) < 10:
                trend_df = pd.concat([trend_df, pd.DataFrame({
                    'keyword': 'No Data To Show',
                    'hazard_count_previous': 0,
                    'hazard_count_current': 0,
                    'hazard_trend_diff': 0,
                    'hazard_value': 0,
                    'trend': 'neutral',
                    'hazard_trend2': 'neutral'
                }, index={0})], ignore_index=True)
            trend_df['id'] = range(1, len(trend_df) + 1)

            # Send only Top N
            return trend_df.head(top_n)

        # Variables
        payload_columns = ['id', 'keyword', 'trend',
                           'hazard_trend_diff', 'hazard_count_previous',
                           'hazard_count_current']

        # Group By and count
        df1_grouped = df1.groupby(['employee_position']).size().reset_index()
        df2_grouped = df2.groupby(['employee_position']).size().reset_index()
        df1_grouped.rename(columns={'Unnamed: 0': 'count', 0: 'count'},
                           inplace=True)
        df2_grouped.rename(columns={'Unnamed: 0': 'count', 0: 'count'},
                           inplace=True)

        # Calculate trend
        trend_df = calc_trend(df1=df1_grouped, df2=df2_grouped,
                              field='employee_position')
        trend_json = json.loads(trend_df[payload_columns].to_json(
            orient='records'))

        return Response(trend_json)

