from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.db import transaction
from rest_framework.permissions import IsAuthenticated
from django.db.models import Count
from datetime import datetime
from apps.general_action.models import Submissionheader

from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.common_utils.views.validate_permission import RolePermission
from apps.recognition.models import SubmissionPositiveRecognition

class ArchivePositiveRecognition(APIView):
    permission_classes = [IsAuthenticated ,SofviePermission]
    permission_attrs = (RolePermission.ArchiveSubmissions.value,)

    @transaction.atomic
    def post(self, request):

        try:
            person = self.request.user.user_per_id_id
            PR_FORM_ID = 166071
            pr_ids = request.data['pr_ids']           

            # get parent submission ids if parent is positive recognition
            sh_ids = SubmissionPositiveRecognition.objects.filter(
                id__in=pr_ids,
                submissionheader__formdescriptionid__formid = PR_FORM_ID
            ).values_list('submissionheader', flat = True)

            # check if header has two child forms.. 
            single_child_shd_ids = list(SubmissionPositiveRecognition.objects.values_list(
                'submissionheader', flat = True
            ).annotate(
                header_count = Count('submissionheader')
            ).filter(
                submissionheader__in = sh_ids,        
                spr_enable = True,
                header_count = 1
            ))

            SubmissionPositiveRecognition.objects.filter(
                id__in = pr_ids
            ).update(
                spr_enable = False,
                spr_archived_by_per_id = person,
                spr_archived_date = datetime.now()
            )

            # update isarchived in Submissionheader model for sh_ids
            if single_child_shd_ids:
                arhive_submission_header = Submissionheader.objects.filter(
                    id__in = single_child_shd_ids
                ).update(
                    isarchived = True,
                    archiveddate = datetime.now(),
                    archived_by_per_id = person
                )

            return Response(
                {"message": "Submission positive recognitions archived successfully"},
                status = status.HTTP_200_OK
            )
        
        except Exception as e:
            return Response(
                {"message":f"Failed to archive SubmissionPositiveRecognition.\n {e}"}, 
                status= status.HTTP_400_BAD_REQUEST
            )