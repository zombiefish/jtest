from django.db import connection
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.incident_management.api.utlity_function import dictfetchall

from datetime import datetime
from apps.language.models import Language
import pandas as pd
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.user_settings_profile.models import UserProfile
from apps.recognition.models import SubmissionPositiveRecognitionLike



class GetPositiveIdList(APIView):
    permission_classes = [SofviePermission]
    parser_classes = [JSONParser]
    """ Response for the All  """

    def post(self, request):
        request_user = self.request.user
        per = request_user.user_per_id
        person = per.per_id
        
        jobs = request.data['Jobs']
        supervisors = request.data['Supervisors']
        start_date = request.data['StartDate']
        end_date = request.data['EndDate']        

        _commaSep_job_Ids = ','.join(
            [str(elem) for elem in jobs])
 
        _commaSep_supervisors_Ids = ','.join(
            [str(elem) for elem in supervisors])
   
        with connection.cursor() as cursor:
            cursor.execute(
                "call get_positive_id_list(%s,%s,%s,%s,%s,@error_msg)",
                (person, _commaSep_supervisors_Ids, _commaSep_job_Ids,
                  start_date, end_date,))            
            positive_id_data = dictfetchall(cursor)
            cursor.execute('select @error_msg')           

            # get like count for each SubmissionPositiveRecognitionID
            positive_id_data = get_pid_likes_count(positive_id_data, person)            
            

            # get comment count for each SubmissionPositiveRecognitionID
            positive_id_data = get_pid_comments_count(positive_id_data, person)            

        return Response(positive_id_data)


class GetHazardsPositiveIDRatio(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):       
        
        jobs_list = request.data['Jobs']
        supervisors_list = request.data['Supervisors']
        start_date = request.data['StartDate']
        end_date = request.data['EndDate']

        person_id = self.request.user.user_per_id
        language_name = UserProfile.objects.get(upr_per = person_id).upr_language
        lang_id = Language.objects.get(lng_name = language_name).lng_id        

        jobs = ','.join(map(str,jobs_list))
        supervisors = ','.join(map(str, supervisors_list))

        with connection.cursor() as cursor:
            # get recognition_ all counts and hazards _ all count to return all supervisors vs jobs ratio
            recognition_query_all = "call get_recognition_count_by_type(%s,%s,%s)"
            hazards_query_all = 'call get_hazard_count_by_date(%s,%s);'
            cursor.execute(recognition_query_all, (lang_id, start_date, end_date))
            recognition_count = dictfetchall(cursor)
            cursor.execute(hazards_query_all, (start_date, end_date))
            hazards_count = dictfetchall(cursor)

            # get recognition_ filteered counts and hazards _ filteered count to get ration of filters for jobs and supervisors
            filtered_recognition_query = "call get_filtered_recognition_count_by_type(%s,%s,%s,%s,%s);"
            filtered_hazards_query = 'call get_filtered_hazard_count_by_type(%s,%s,%s,%s);'

            cursor.execute(filtered_recognition_query, (lang_id, start_date, end_date, jobs, supervisors))
            filtered_recognition_count = dictfetchall(cursor)
            cursor.execute(filtered_hazards_query,(start_date, end_date, jobs, supervisors))
            filtered_hazards_count = dictfetchall(cursor)
            
            # if hazards_count is less than 0 - set it to 0. just to make sure it is not negative number.
            hazard_count = hazards_count[0]['hazard_count'] if hazards_count[0]['hazard_count'] > 0 else 0
            filtered_hazard_count = filtered_hazards_count[0]['hazard_count'] if filtered_hazards_count[0]['hazard_count'] > 0 else 0

            # calculate total and ratio. 
            all_total_recognition_count = sum(each['recognition_count'] for each in recognition_count)
            all_ratio =round(all_total_recognition_count/hazard_count,2) if hazard_count != 0 else 0

            filtered_total_recognition_count = sum(each['recognition_count'] for each in filtered_recognition_count)
            filtered_ratio =round(filtered_total_recognition_count/filtered_hazard_count,2) if filtered_hazard_count != 0 else 0

        return Response({
            "all_total_recognition_count": all_total_recognition_count,
            "all_ratio":all_ratio,
            "recognition_count":recognition_count,
            'filtered_recognition_count':filtered_recognition_count, 
            "hazards_count":hazard_count, # hazard_count is 0 if no hazards
            'filtered_hazards_count':filtered_hazard_count, # filtered_hazard_count is 0 if no hazards
            'filtered_total_recognition_count': filtered_total_recognition_count,
            'filtered_ratio': filtered_ratio
            })



def get_pid_likes_count(positive_id_data, person):
    with connection.cursor() as cursor:

        like_query = 'call get_pid_likes_count()'
        cursor.execute(like_query)   
        like_count = dictfetchall(cursor)            

        # use pandas dataframe and queries to loop through positive id list and add like_count to list using pandas query
        like_count_df = pd.DataFrame(like_count)
        like_count_df.fillna('', inplace=True)

        for positive_rec in positive_id_data:
            if like_count_df.empty:
                positive_rec['likeCount'] = 0
                positive_rec['liked_by_per'] = False
                positive_rec['signed_by'] = []

            else:
                # prl_recognition_of_person_id = positive_rec['RecognitionOf']                
                pid = positive_rec['pid_id']                    
                like_count_query = like_count_df.query('SubmissionPositiveRecognitionID == @pid').to_dict(orient='records')
                positive_rec['likeCount'] = like_count_query[0]['like_count'] if len(like_count_query) > 0 else 0                
                positive_rec['liked_by_per'] = True if len(like_count_query) > 0 and str(person) in like_count_query[0]['signed_by'].split(',') and len(like_count_query) > 0 else False
                positive_rec['signed_by'] = like_count_query[0]['signed_by'].split(',') if len(like_count_query) > 0 else []
                if positive_rec['liked_by_per']:
                    positive_rec['mylikeid']=SubmissionPositiveRecognitionLike.objects.filter(SubmissionPositiveRecognitionID=like_count_query[0]['SubmissionPositiveRecognitionID'],SigningAccount=person).first().id 


    return positive_id_data

def get_pid_comments_count(positive_id_data, person):  
    with connection.cursor() as cursor:

        comment_query = "call get_pid_comments_count();"
        cursor.execute(comment_query)

        comment_count = dictfetchall(cursor)

        comment_count_df = pd.DataFrame(comment_count)
        comment_count_df.fillna('', inplace=True)

        for positive_rec in positive_id_data:
            if comment_count_df.empty:
                positive_rec['commentCount'] = 0
                positive_rec['comment_per_id'] = []
            else:
                pid = positive_rec['pid_id']                    
                comment_count_query = comment_count_df.query('com_reference_id == @pid').to_dict(orient='records')
                positive_rec['commentCount'] = comment_count_query[0]['comment_count'] if len(comment_count_query) > 0 else 0                      
                positive_rec['comment_by_per'] = True if len(comment_count_query) > 0 and str(person) in comment_count_query[0]['comment_per_id'].split(',') else False                    

    return positive_id_data