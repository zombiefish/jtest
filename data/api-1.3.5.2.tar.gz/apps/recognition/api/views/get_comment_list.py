from django.db import connection
import pandas as pd
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models.expressions import F, OuterRef, Subquery, Value
from django.db.models.functions.text import Concat
from django.db.models import Count, Q, CharField
from itertools import groupby

from apps.comments.models import Comments
from apps.equipment.views import dictfetchall
from apps.recognition.api.views.get_comment_likes import get_comment_likes_by_com_id
from apps.reflist.models import RefListDetail
from apps.language.models import Language, LanguageTranslation
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile

class GetCommentList(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):
        person_id = request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per = person_id).upr_language
        lng_id = Language.objects.get(lng_name = lng_name).lng_id


        '''
        input payload :
        {
            "submission_pid": 1244
        }
        '''
        submission_pid = request.data['submission_pid']

        get_comments_list = get_comments_list_by_submission_pid(submission_pid, lng_id, person_id)
        return Response({'list_comments':get_comments_list})


def get_comments_list_by_submission_pid(submission_pid, lng_id, person_id):
    list_comments = Comments.objects.filter(
        com_reference_id = submission_pid,
        com_cmt_id = 11, #hard_coded
        com_enable = True,
    ).annotate(
        position_tag  = Subquery(RefListDetail.objects.filter(
            rld_id = OuterRef('com_position_id')
        ).values('rld_name')[:1]),
        position_tag_type = Subquery(RefListDetail.objects.filter(
            rld_id = OuterRef('com_position_id')
        ).values('rld_tag_type')[:1]),
        created_by = Concat('com_created_by_per_id__per_last_name', Value(', '
                                                                          ''), 'com_created_by_per_id__per_first_name', Value(' '), 'com_created_by_per_id__per_middle_name', output_field=CharField())
    ).values(
        'com_id',
        'com_comment',
        'created_by',
        'com_created_by_per_id',
        'position_tag',
        'position_tag_type',
        'com_created_date'            
    )

    list_comments = list_comments.annotate(
        position = Subquery(LanguageTranslation.objects.filter(
            ltr_tag_type = OuterRef('position_tag_type'),
            ltr_tag = OuterRef('position_tag'),
            ltr_lng_id = lng_id
        ).values('ltr_text')[:1])            
    ).values(
        'com_id',
        'com_comment',
        'created_by',
        'com_created_by_per_id',
        'position',
        'com_created_date'
    ).order_by('-com_created_date')
    

    comment_ids = list(list_comments.values_list('com_id', flat=True))
    comment_ids = ','.join(map(str, comment_ids)) if comment_ids else 'null'

    with connection.cursor() as cursor:

        like_query = """
                        SELECT
                            COUNT(1) as like_count,
                            clk_com_id,
                            GROUP_CONCAT(DISTINCT clk_created_by_per_id) AS liked_by
                        FROM comment_like
                        WHERE clk_cmt_id = 11
                        AND clk_com_id IN ("""+comment_ids+""")
                        AND clk_enable = 1
                        GROUP BY clk_com_id;
                    """

        cursor.execute(like_query)         

        like_count = dictfetchall(cursor)                        

        # get likes for each comment_id from comment_likes table
        # group by comment_id and count the number of likes        

        likes_count_df = pd.DataFrame(like_count)
        likes_count_df.fillna('', inplace=True)

        for comment in list_comments:
            if likes_count_df.empty:
                comment['likes_count'] = 0
                comment['liked_by_per'] = False
            else:
                com_id = comment['com_id']                                                
                likes_count_query = likes_count_df.query('clk_com_id == @com_id').to_dict(orient='records')
                comment['likes_count'] = likes_count_query[0]['like_count'] if len(likes_count_query) > 0 else 0                      
                comment['liked_by_per'] = True if len(likes_count_query) > 0 and str(person_id) in likes_count_query[0]['liked_by'].split(',') else False
                comment['likes'] = get_comment_likes_by_com_id(comment['com_id'], lng_id, person_id)

    return list_comments    


        






        