import json
# from datetime import time, datetime
import datetime

from django.db.models import Prefetch
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
import pandas as pd
from django.core import serializers

from apps.general_action.models import Submissionheader
from apps.hap.api.serializers.serializers import \
    HapSubmissionCountByTypeAndYearSerializer
from apps.hazard_action.models import Submissionhap
from apps.recognition.models import SubmissionPositiveRecognitionPerson, \
    SubmissionPositiveRecognition
from apps.rmm_ora.api.date_filter_utils import date_filter
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class PidCountByMonthAndYear(APIView):
    permission_classes = [SofviePermission]

    def post(self, request, format=None, *args, **kwargs):
        start_date = request.data['start_date']
        end_date = request.data['end_date']

        queryset = SubmissionPositiveRecognition.objects.select_related(
            'SubmissionHeader',
        ).filter(
            submissionheader__isarchived=None,
            submissionheader__formsubmissiondate__range=date_filter(
                start_date, end_date),
            spr_enable = True
        ).values(
            'id',
            'RecognitionType',
            'EventDescription',
            'submissionheader__formsubmissiondate',

        )  # [:10]

        # print(f"this is queryset {queryset}")
        if len(queryset) > 1:
            df = pd.DataFrame(queryset)
        else:
            return Response(f"No Data to Show")

        df1 = df.fillna('')

        # Data cleaning
        df1['pid_year'] = df1[
            'submissionheader__formsubmissiondate'].apply(
            lambda x: x.year)
        df1['pid_month'] = df1[
            'submissionheader__formsubmissiondate'].apply(
            lambda x: x.month)

        # Data Transformation
        df2 = df1[['pid_month', 'pid_year']].groupby(
            ['pid_month', 'pid_year']).agg('size').reset_index()
        df2.rename(columns={0: 'pid_value'}, inplace=True)
        df2 = df2[df2.pid_month != 'nan'].copy()
        df2 = df2[df2.pid_month != ''].copy()
        df2 = df2.sort_values(by=['pid_year'], ascending=True)
        monthNamesLong = ["January", "February", "March", "April", "May",
                          "June", "July", "August", "September", "October",
                          "November", "December"]
        response_payload = []

        for i, r in df2.iterrows():
            response_payload.append({
                'pid_year': str(r["pid_year"]),  # Year
                'pid_month_num': str(r["pid_month"]),
                "pid_month_name": monthNamesLong[r["pid_month"] - 1],
                "pid_count": r["pid_value"]
            })
        return Response(response_payload)
