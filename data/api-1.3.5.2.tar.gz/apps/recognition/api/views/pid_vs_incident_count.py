import pandas as pd
from django.db.models import Prefetch
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.incident_management.models import Incidentsubmissions
from apps.recognition.models import SubmissionPositiveRecognition, \
    SubmissionPositiveRecognitionPerson
from apps.rmm_ora.api.date_filter_utils import date_filter
from apps.sofvie_user_authorization.api.permissions import SofviePermission


def transform_df(df, dateField, idField, countField):
    # Extract month-year from submission date
    df['date'] = pd.to_datetime(df[dateField]).dt.to_period('M')

    # Group by and count occurences
    df_tmp = df[['date', idField]].groupby(['date']).agg(
        {idField: 'count'}).reset_index().sort_values(['date'])

    df_tmp['date_txt'] = df_tmp['date'].apply(str)

    # Rename columns
    df_tmp.rename(columns={
        'date': 'date_original',
        'date_txt': 'date',
        'id': countField
    }, inplace=True)

    return df_tmp


class PidVsIncidentCount(APIView):
    permission_classes = [SofviePermission]

    def post(self, request, format=None, *args, **kwargs):
        start_date = request.data['start_date']
        end_date = request.data['end_date']

        queryset = Incidentsubmissions.objects.select_related(
                                        'incidentid',
                                        'submissionheaderid').filter(
            submissionheaderid__isarchived=None,
            submissionheaderid__formsubmissiondate__range=date_filter(
                start_date, end_date)
            # many to many relation
        ).values(
            'id',
            'incidentid__id',
            'submissionheaderid__id',
            'submissionheaderid__formsubmissiondate',
        )

        queryset2 = SubmissionPositiveRecognition.objects.select_related(
            'submissionheader',
        ).filter(
            submissionheader__isarchived=None,
            submissionheader__formsubmissiondate__range=date_filter(
                start_date, end_date),
            spr_enable = True
            # many to many relation
        ).prefetch_related(
            Prefetch('submission_positive_recognition',
                     SubmissionPositiveRecognitionPerson.objects.only(
                         'recognitionof'))).values(
            'id',
            'RecognitionType',
            'EventDescription',
            'submissionheader__id',
            'submissionheader__site',
            'submission_positive_recognition__recognitionof',
            'submissionheader__formsubmissiondate',
        )

        # print(f"this is queryset {queryset}")
        # print(f"this is queryset {len(queryset)}")
        # print(f"this is queryset {queryset.query}")

        if len(queryset) > 1 and len(queryset2) > 1:
            df1 = pd.DataFrame(queryset)
            df2 = pd.DataFrame(queryset2)

            ## Data Transformation

        else:
            return Response(f"No Data to Show")
        payload_columns = ['date', 'incident_count', 'pid_count']
        df1_transformed = transform_df(df=df1,
                                       dateField='submissionheaderid__formsubmissiondate',
                                       idField='id',
                                       countField='incident_count')
        df2_transformed = transform_df(df=df2,
                                       dateField='submissionheader__formsubmissiondate',
                                       idField='id', countField='pid_count')
        # Merge incident and pid counts
        response_df = pd.merge(df1_transformed, df2_transformed, how='left',
                               on=['date'])
        ### DROPPING NAN ROWS: ###
        response_df = response_df.dropna()

        response_df['pid_count'] = response_df['pid_count'].astype(int)
        response_df['incident_count'] = response_df['incident_count'].astype(int)

        # Response payload as per documentation:
        # response_json = response_df[payload_columns].to_json(
        #     orient='records')
        # print(f"this is response_json {response_json}")

        # df.to_csv('incident.csv')
        # df2.to_csv('pid.csv')
        # Response payload as per Plotly requirements:
        response_plotly_json = {
            'x_axis': response_df['date'].tolist(),
            'y_axis': [response_df['incident_count'].tolist(), response_df[
                'pid_count'].tolist()]
            #'y_incident_count': response_df['incident_count'].tolist(),
            #'y_pid_count': response_df['pid_count'].tolist()
        }
        # response_plotly_json

        # df1 = df.fillna('')
        #

        # return Response({"query1": queryset, "query2": queryset2})
        return Response(response_plotly_json)


"""
#%%
## Libraries
import pandas as pd
import numpy as np
import json

## Functions
def transform_df(df, dateField, idField, countField):
    # Extract month-year from submission date
    df['date'] = pd.to_datetime(df[dateField]).dt.to_period('M')

    # Group by and count occurences
    df_tmp = df[['date',idField]].groupby(['date']).agg({idField:'count'}).reset_index().sort_values(['date'])        

    df_tmp['date_txt'] = df_tmp['date'].apply(str)
    
    # Rename columns
    df_tmp.rename(columns={
        'date': 'date_original',
        'date_txt': 'date',
        'id': countField
    }, inplace=True)

    return df_tmp

## Variables
payload_columns = ['date','incident_count', 'pid_count']

## Execution

# Read the Hazards dataset
df1 = pd.read_csv('incident.csv')
df2 = pd.read_csv('pid.csv')

## Data Transformation
df1_transformed = transform_df(df=df1, dateField='submissionheaderid__formsubmissiondate', idField='id', countField='incident_count')
df2_transformed = transform_df(df=df2, dateField='submissionheader__formsubmissiondate', idField='id', countField='pid_count')

# Merge incident and pid counts
response_df = pd.merge(df1_transformed, df2_transformed, how='left', on=['date'])

# Response payload as per documentation:
response_json = response_df[payload_columns].to_json(orient='records')

# Response payload as per Plotly requirements:
response_plotly_json = {
    'x':response_df['date'].tolist(),
    'y_incident_count':response_df['incident_count'].tolist(),
    'y_pid_count':response_df['pid_count'].tolist()
}
response_plotly_json

#%%


"""