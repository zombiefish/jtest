import datetime
import json

from django.db.models import Sum, Count, Max, F, Prefetch
from nltk import ngrams
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response
import pandas as pd
import numpy as np

from apps.hazard_action.models import Submissionhap
from apps.recognition.models import SubmissionPositiveRecognition, \
    SubmissionPositiveRecognitionPerson
from apps.rmm_ora.api.date_filter_utils import date_filter
import spacy
from collections import Counter
from nltk.corpus import stopwords
from wordcloud import WordCloud, STOPWORDS
from textblob import TextBlob
import re

from apps.sofvie_user_authorization.api.permissions import SofviePermission


class GetTop10TwoWordPidThemes(APIView):
    permission_classes = [SofviePermission]

    def post(self, request, *args, **kwargs):
        start_date = request.data['start_date']
        end_date = request.data['end_date']
        first_queryset = SubmissionPositiveRecognition.objects.select_related(
            'submissionheader',
            ).filter(
            submissionheader__isarchived=None,
            submissionheader__formsubmissiondate__range=date_filter(
                start_date, end_date),
            spr_enable = True
        ).prefetch_related(
                        Prefetch('submission_positive_recognition',
                        SubmissionPositiveRecognitionPerson.objects.only(
                            'recognitionof'))).values(
            'id',
            'RecognitionType',
            'EventDescription',
            'submissionheader__id',
            'submission_positive_recognition__recognitionof',
        )

        """
        1. First dataset giving us 90 days data with start date and end date
        2. Second dataset we need start_date from the first dataset
        3. Create a formula to get the previous 90 days 
        4. Convert those days to previous start_date and end_date
        """
        # converting payload date into date object
        date_time_obj_start_date = datetime.datetime.strptime(start_date,
                                                              '%Y-%m-%d')
        date_time_obj_end_date = datetime.datetime.strptime(end_date,
                                                            '%Y-%m-%d')
        # Assigning new date object to new variables
        start_date = date_time_obj_start_date.date()
        end_date = date_time_obj_end_date.date()



        # Converting new dates into days
        my_delta = end_date - start_date

        # Calculating the past date
        previous_date_conversion = datetime.timedelta(days=my_delta.days)
        # Assigning past date to a new variable
        new_start_date = start_date - previous_date_conversion

        # Converting dates into string for database query
        format_start_date = datetime.datetime.strftime(new_start_date,
                                   '%Y-%m-%d')
        start_date = datetime.datetime.strftime(start_date,
                                                       '%Y-%m-%d')

        second_queryset = SubmissionPositiveRecognition.objects.select_related(
            'submissionheader',
        ).filter(
            submissionheader__isarchived=None,
            submissionheader__formsubmissiondate__range=date_filter(
                format_start_date, start_date),
            spr_enable = True
        ).prefetch_related(
            Prefetch('submission_positive_recognition',
                     SubmissionPositiveRecognitionPerson.objects.only(
                         'recognitionof'))).values(
            'id',
            'RecognitionType',
            'EventDescription',
            'submissionheader__id',
            'submission_positive_recognition__recognitionof',
        )

        if len(first_queryset) and len(second_queryset) > 1:
            first_df = pd.DataFrame(first_queryset)
            second_df = pd.DataFrame(second_queryset)
        else:
            trend_df = []
            for i in range(1, 11):
                trend_df.append({
                    'keyword': 'No Data To Show',
                    'hazard_count_previous': 0,
                    'hazard_count_current': 0,
                    'hazard_trend_diff': 0,
                    'hazard_value': 0,
                    'trend': 'neutral',
                    'hazard_trend2': 'neutral'
                })
            return Response(trend_df)

        def count_grams(doc, max_grams=3, extra_stop_words=[]):
            '''Count the number of words and ngrams in a spacy.Doc

            Parameters
            ----------
            doc : spacy.Doc
                The Doc object you wish to perform ngram analysis on
            max_grams : int, optional
                The maximum number of ngrams to create. For example if 3 it will count
                words, bi-grams, and tri-grams. By default 3.
            extra_stop_words : list
                Additional stop words to remove in addition from spacy.Token.is_stop

            Returns
            -------
            pandas.DataFrame
                A dataframe with the word count for each gram and word.

            Examples
            --------
            # >>> import spacy
            # >>> from rpc_nlp import count_grams
            # >>> nlp = spacy.load('en_core_web_sm')
            # >>> doc = nlp('Testing counting test ngrams. Counting test is on!')
            # >>> count_grams(doc, 2).head()
            # >>> count_grams(doc, 1).head()
            '''
            words = [t for t in doc if
                     t.is_stop is False and t.is_alpha is True]
            words = [t for t in words if t.text.lower() not in extra_stop_words]
            words = [t.lemma_.lower() for t in words]
            grams = []
            for i in range(2, max_grams + 1):
                gram_i = ngrams(words, i)
                for g in gram_i:
                    grams.append(' '.join(g))
            freq = Counter(words + grams)
            freq = pd.DataFrame.from_dict(freq, orient='index').reset_index()
            if freq.shape == (0, 1):
                freq = pd.DataFrame(columns=['text', 'count'])
            else:
                freq.columns = ['text', 'count']
            freq = freq.query('count >= 3')
            freq = freq.sort_values(by='count', ascending=False).reset_index(
                drop=True)
            freq['length_text'] = freq.loc[:, 'text'].apply(
                lambda x: len(str(x).split()))
            return freq

        def count_noun_chunks(doc):
            """Count the number of noun chunks in a spacy.Doc

            Parameters
            ----------
            doc : spacy.Doc
                The Doc object you wish to perform ngram analysis on

            Returns
            -------
            pandas.DataFrame
                A dataframe with counts for each chunk.
            """
            chunks = [chunk.lemma_.lower() for chunk in doc.noun_chunks]
            freq = Counter(chunks)
            freq = pd.DataFrame.from_dict(freq, orient='index').reset_index()
            if freq.shape == (0, 1):
                freq = pd.DataFrame(columns=['text', 'count'])
            else:
                freq.columns = ['text', 'count']
            freq = freq.query('count >= 3')
            freq = freq.sort_values(by='count', ascending=False).reset_index(
                drop=True)
            freq['length_text'] = freq.loc[:, 'text'].apply(
                lambda x: len(str(x).split()))
            return freq

        def nlp_meta(x, max_grams, text_cols, nlp):
            """Perform all nlp analysis.

            Parameters
            ----------
            x : pandas.DataFrame
                The dataframe to perform the nlp analysis on.
            text_cols : list
                A list of the column names to perform the NLP analysis on
            nlp : spacy.lang.en.English
                A spacy model (e.g. nlp = spacy.load('en_core_web_sm'))

            Returns
            -------
            pandas.DataFrame
                DataFrame with topic counts for each topic.
            """
            df = x.copy()
            df[text_cols] = df[text_cols].fillna('')
            df['text'] = df[text_cols]
            doc_list = [doc for doc in nlp.pipe(df['text'].to_list())]
            # ngram analysis
            stop_words = []
            df['ngrams'] = [count_grams(doc, max_grams, stop_words) for doc in
                            doc_list]
            # noun chunks analysis
            df['noun_chunks'] = [count_noun_chunks(doc) for doc in doc_list]
            return df

        def clean_word_clouds(clouds):
            """Combine and summarize word cloud data.

            Parameters
            ----------
            clouds : list
                A list of dataframes with columns: ['text', 'count', 'length_text']

            Returns
            -------
            pandas.DataFrame
                A concatenad and summarized list of word counts.
            """
            if len(clouds) == 0:
                return None
            word_cloud = pd.concat(clouds).reset_index(drop=True)
            word_cloud = word_cloud.groupby(['text', 'length_text'])[
                'count'].sum()
            word_cloud = word_cloud.sort_values(ascending=False)
            word_cloud = word_cloud.to_frame().reset_index()
            return word_cloud

        def get_sentiment(text):
            blob = TextBlob(text)
            return blob.sentiment.polarity

        def calc_trend_direction(val):
            if val > 0:
                return 'up'
            elif val < 0:
                return 'down'
            else:
                return 'neutral'

        def calc_trend(first_df, second_df, field, top_n=10):
            # Calculate trend
            trend_df = pd.merge(first_df, second_df, how='left', on=field)
            trend_df['trend_diff'] = trend_df['count_x'] - trend_df[
                'count_y']
            trend_df['trend2'] = trend_df['trend_diff'].apply(
                calc_trend_direction)
            trend_df = trend_df.fillna(0).copy()
            trend_df['trend_diff'] = trend_df['count_x'] - trend_df[
                'count_y']
            trend_df['trend'] = trend_df['trend_diff'].apply(
                calc_trend_direction)
            trend_df['count_x'] = trend_df['count_x'].astype('int')
            trend_df['count_y'] = trend_df['count_y'].astype('int')
            trend_df['trend_diff'] = trend_df[
                'trend_diff'].astype('int')
            trend_df.rename(columns={
                'count_y': 'count_previous',
                'count_x': 'count_current',
                field: 'keyword'
            }, inplace=True)

            # Sort by "current" count of keywords
            trend_df = trend_df.sort_values(by=['count_current'],
                                            ascending=False)
            trend_df['id'] = range(1, len(trend_df) + 1)

            # Send only Top N
            return trend_df.head(top_n)
        """
        'RecognitionType',
        'EventDescription',
        """
        def build_wordcloud_df(df, n_gram):
            # Data Transformation
            df.dropna(subset=['EventDescription'], inplace=True)
            df['sentiment'] = df['EventDescription'].apply(
                get_sentiment)
            
            hazard_desc = df[
                ['RecognitionType', 'EventDescription','sentiment']]

            hazard_desc_type = hazard_desc.groupby(['RecognitionType']).agg(
                {'EventDescription': lambda x: x.str.cat(sep=' '),
                 'sentiment': 'mean'})
            # Build word cloud
            word_cloud = nlp_meta(hazard_desc_type, n_gram,
                                  'EventDescription',
                                  nlp)  # This line takes some time to execute
            word_cloud_ngrams = clean_word_clouds(
                word_cloud['ngrams'].to_list())
            word_cloud_df = word_cloud_ngrams[
                word_cloud_ngrams['length_text'] == n_gram]

            del word_cloud_df['length_text']

            while len(word_cloud_df) < 10:
                word_cloud_df = pd.concat([word_cloud_df, pd.DataFrame({
                    'text': 'No Data To Show',
                    'count': 0
                }, index={0})], ignore_index=True)

            return word_cloud_df

        # Variables
        np.zeros((51466, 4, 96), dtype='uint8')
        nlp = spacy.load('en_core_web_sm', disable=['ner'])
        payload_columns = ['id', 'keyword', 'trend',
                           'trend2', 'trend_diff',
                           'count_previous', 'count_current']

        # Execution

        # Build wordcloud for one word theme
        current_n1_df = build_wordcloud_df(df=first_df, n_gram=2)
        previous_n1_df = build_wordcloud_df(df=second_df, n_gram=2)

        # Calculate trend
        trend_df = calc_trend(first_df=current_n1_df, second_df=previous_n1_df,
                              field='text')
        trend_json = json.loads(trend_df[payload_columns].to_json(
            orient='records'))

        # Response payload as per documentation:

        return Response(trend_json)