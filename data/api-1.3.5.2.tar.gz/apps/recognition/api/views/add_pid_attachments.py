from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.add_attachment import save_the_file
from apps.sofvie_user_authorization.api.permissions import SofviePermission

class AddPIDAttachment(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):
        person_id = self.request.user.user_per_id_id

        submission_positive_recognition_id = request.data['SubmissionPositiveRecognitionID']
        files = request.FILES.getlist('filename')
        spa_image_timestamp = request.data['spa_image_timestamp']

        data_args = {
            "app": "Positive_Recognition",
            "person_id": person_id,
            "id": submission_positive_recognition_id,
            "files": files,
            "image_timestamp": spa_image_timestamp,
            "only_image": True
        }

        response = save_the_file(data_args)  

        return Response({"message": "Ok", "response":response})
