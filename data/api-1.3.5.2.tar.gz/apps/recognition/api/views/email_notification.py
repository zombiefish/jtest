from datetime import datetime
from django.template.loader import get_template
from django.core.mail import EmailMultiAlternatives
from django.conf import settings
from django.db.models.expressions import F, Value
from django.db.models import CharField
from django.db.models.functions.text import Concat
from apps.comments.models import Comments

from apps.recognition.models import SubmissionPositiveRecognition, SubmissionPositiveRecognitionPerson
from apps.reflist.models import RefListDetail
from apps.user.models import User
from apps.user_settings_profile.models import UserProfile
from apps.common_utils.views.get_translations import get_translation
from apps.language.models import Language, LanguageTranslation


def send_email_positive_recognition(self, type_of_email, pid = None, com_id = None):    

    person_id = self.request.user.user_per_id    
    email_list = []  
    per_id_list = []    

    lng_name = UserProfile.objects.get(upr_per_id=person_id).upr_language
    lng_id = Language.objects.get(lng_name=lng_name)
    ltr_ids = [124, 3601, 2095, 4241, 4242, 1054, 1298, 1349, 143, 4243, 4244, 4245, 4246, 4247, 3606, 3607, 3608, 993, 
                8926, 8927, 8929, 3597, 8923,8924, 8925, 8450, 8932, 8933, 8934, 8935, 8928, 8930, 3915, 8860, 1952]
    final_trans = get_translation(ltr_ids, lng_id)

    recognition_type = SubmissionPositiveRecognition.objects.filter(
            id=pid,
            spr_enable = True
        ).annotate(
            Date = F('submissionheader__formsubmissiondate'),
            Created_By = Concat('submissionheader__submittedby_supervisorid__per_last_name', Value(', '), 'submissionheader__submittedby_supervisorid__per_first_name', output_field=CharField()),            
        ).values(
            'RecognitionType',
            'Date',
            'Created_By',
        )
    
    if len(recognition_type) == 1:   
        
        data = {}
        if type_of_email == 'new_pid' or type_of_email == 'new_like' or type_of_email == 'new_comment':
            per_id_list = SubmissionPositiveRecognitionPerson.objects.filter(
                submissionpositiverecognition__id = pid,
            ).values_list('recognitionof', flat=True)           

        else:
            per_id_list = Comments.objects.filter(com_id=com_id, com_enable=True).values_list('com_created_by_per', flat=True)        
        
        data = {       
                'type_of_email': type_of_email,
                'type': get_recognition_type_name(recognition_type[0]['RecognitionType'], lng_id),
                'created_by': person_id.full_name,
                'date': datetime.now(),     
                'comment': None,               
                'translate': final_trans
                }
        if type_of_email == 'new_comment' or type_of_email == 'new_like_on_comment':
            comment = Comments.objects.get(com_id = com_id, com_enable=True).com_comment            
            data['comment'] = comment

        users_list = User.objects.filter(user_per_id__in = per_id_list).values('user_per_id__per_first_name','email')        

        for user in users_list:
            data['user'] = user['user_per_id__per_first_name']

            from_email = settings.DEFAULT_FROM_EMAIL_ADMIN
            email_list = [user['email']]
            subject = final_trans[3597] if type_of_email == 'new_pid'\
                 else final_trans[8923] if type_of_email == 'new_like'\
                 else final_trans[8924] if type_of_email == 'new_comment'\
                 else final_trans[8925]

            text_content = final_trans[8450]
            html_content = get_template(
                "positive_recognition_email.html").render(data)
            msg = EmailMultiAlternatives(subject, text_content, from_email,
                                        email_list)
            msg.attach_alternative(html_content, "text/html")
            msg.send()

def get_recognition_type_name(type_id, lng_id):

    rld_name = RefListDetail.objects.filter(rld_id = type_id).values('rld_name', 'rld_tag_type')
    recognition_type_name = None
    if len(rld_name) == 1:
        recognition_type_name = LanguageTranslation.objects.filter(
            ltr_tag = rld_name[0]['rld_name'],
            ltr_tag_type = rld_name[0]['rld_tag_type'],
            ltr_lng = lng_id,
            ltr_enable = True
        ).values_list('ltr_text', flat=True)[0]

    return recognition_type_name