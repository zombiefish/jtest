from django.db import connection, transaction
from rest_framework import status
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.recognition.api.views.email_notification import send_email_positive_recognition
from apps.recognition.models import SubmissionPositiveRecognitionLike, SubmissionPositiveRecognition, SubmissionPositiveRecognitionPerson
from apps.employee.models import Employee
from django.db.models import F
from datetime import datetime
from pytz import timezone

from apps.sofvie_user_authorization.api.permissions import SofviePermission

class AddLike(APIView):
    permission_classes = [SofviePermission]
    parser_classes = [JSONParser]
    
    @transaction.atomic
    def post(self, request):
        submission_pid = request.data['submission_pid']
        signing_time = datetime.now()
        signing_account_id = self.request.user.user_per_id_id
        signing_name = self.request.user.user_per_id.full_name

        try:
            existing_like=SubmissionPositiveRecognitionLike.objects.get(
                SubmissionPositiveRecognitionID=submission_pid,SigningAccount=signing_account_id).id  
            return Response({
                    "Received data": request.data, 
                    "Message": "Object already exist"
                    },status=status.HTTP_400_BAD_REQUEST) 

        except SubmissionPositiveRecognitionLike.DoesNotExist:
            try:  
                # get logged in user position from Employee table
                emp_position = Employee.objects.filter(
                    emp_per_id = signing_account_id
                ).values_list('emp_pos', flat = True)[0]   

                add_like = SubmissionPositiveRecognitionLike.objects.create(
                    SubmissionPositiveRecognitionID_id = submission_pid,
                    SigningAccount = signing_account_id,
                    SigningName = signing_name,
                    SigningTimestamp = signing_time,    
                    prl_position = emp_position
                )

                # get list of per_ids for whom Positive recognition is given, recognitionof field from SubmissionPositiveRecognitionPerson
                get_all_pid_persons = SubmissionPositiveRecognitionPerson.objects.filter(
                    submissionpositiverecognition = submission_pid
                ).values_list('recognitionof', flat=True)

                
                
                return Response({
                    "like_id" : add_like.pk,
                    "Received data": request.data, 
                    "Message": "Object created successfully"
                    },status=status.HTTP_201_CREATED)
            
            except Exception as e:
                return Response({
                    "Received data": request.data, 
                    "Message":"Object creation failed"
                    },status=status.HTTP_400_BAD_REQUEST)




