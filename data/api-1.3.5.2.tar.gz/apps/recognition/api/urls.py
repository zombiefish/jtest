from django.urls import path
from apps.recognition import views
from apps.recognition.api.views.add_like import AddLike
from apps.recognition.api.views.archive_positive_recognition import ArchivePositiveRecognition
from apps.recognition.api.views.delete_like_by_like_id import DeleteLikeByLikeId
from apps.recognition.api.views.get_likes_by_positive_recognition_id import  GetLikesByPositiveRecognitionById
from apps.recognition.api.views.add_positive_id import AddPositiveID
from apps.recognition.api.views.add_pid_attachments import AddPIDAttachment

from apps.recognition.api.views.get_positive_id_stats import GetHazardsPositiveIDRatio, GetPositiveIdList
from apps.recognition.api.views.pid_count_by_month_and_year import \
    PidCountByMonthAndYear
from apps.recognition.api.views.get_top_10_one_word_theme_pid import \
    GetTop10OneWordPidThemes
from apps.recognition.api.views.get_top_10_recognition_position_pid import \
    GetTop10RecognitionPosition
from apps.recognition.api.views.get_top_10_two_word_theme_pid import \
    GetTop10TwoWordPidThemes
from apps.recognition.api.views.pid_count_by_site import PidCountBySite
from apps.recognition.api.views.pid_vs_incident_count import PidVsIncidentCount
from apps.recognition.api.views.get_comment_list import GetCommentList
from apps.recognition.api.views.get_comment_likes import GetCommentLikes
from apps.recognition.api.views.add_comment_like import AddCommentLike
from apps.recognition.api.views.delete_comment_like import DeleteCommentLike

urlpatterns = [
    # path('user-recognition/', GetUserRecognition.as_view()),
    path('get-likes-by-positive-recognition-id/',
         GetLikesByPositiveRecognitionById.as_view()),
    path('delete-likes-by-like-id/', DeleteLikeByLikeId.as_view()),
    path('add-likes/', AddLike.as_view()),
    path('get-recognition-list/', GetPositiveIdList.as_view()),    
    path('add-positive-id/', AddPositiveID.as_view()),
    path('add-positive-id-attachments/', AddPIDAttachment.as_view()),
    path('pid-count-by-month-and-year/', PidCountByMonthAndYear.as_view()),
    path('get-top-10-one-word-theme-pid/', GetTop10OneWordPidThemes.as_view()),
    path('get-top-10-two-word-theme-pid/', GetTop10TwoWordPidThemes.as_view()),
    path('get-top-10-recognition-position-pid/',
         GetTop10RecognitionPosition.as_view()),
    path('pid-count-by-site/', PidCountBySite.as_view()),
    path('pid-vs-incident-count/', PidVsIncidentCount.as_view()),
    path('get-positive-hazard-ratio/', GetHazardsPositiveIDRatio.as_view()),
    path('get-comment-list/', GetCommentList.as_view()),
    path('get-comment-likes/', GetCommentLikes.as_view()),
    path('add-comment-like/', AddCommentLike.as_view()),    
    path('delete-comment-like/', DeleteCommentLike.as_view()),
    path('archive-positive-recognition/', ArchivePositiveRecognition.as_view()),
]