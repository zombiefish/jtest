from django.db import models

from django.db import connection

from apps.general_action.models import Submissionheader, Formdescription
from apps.person.models import Person
from apps.comments.models import Comments, CommentsTable
from apps.reflist.models import RefListDetail
from apps.common_utils.views.sofvieModelFields import SofvieIntegerField, SofvieCharField, SofvieTextField




class SubmissionPositiveRecognition(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)
    submissionheader = models.ForeignKey(Submissionheader, models.DO_NOTHING,
                                         default=True,
                                         related_name='SubmissionHeader',
                                         db_column='SubmissionHeaderID')
    RecognitionType = SofvieIntegerField(blank=True, null=True)
    EventDescription = SofvieTextField(blank=True, null=True)
    WasRecognitionGiven = models.BooleanField(default=True)
    RecognitionGivenType = SofvieCharField(max_length=64)
    spr_archived_by_per =models.ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='spr_archive_person', blank = True, null = True)
    spr_archived_date = models.DateTimeField(blank = True, null = True)
    spr_enable = models.BooleanField(default = True)
    spr_enote = SofvieCharField(blank = True, null = True)
    class Meta:
        db_table = 'SubmissionPositiveRecognition'


class SubmissionPositiveRecognitionAttachments(models.Model):
    id = models.AutoField(primary_key=True, db_column='ID')
    submissionpositiverecognition = models.ForeignKey(
        SubmissionPositiveRecognition, models.DO_NOTHING,
        related_name='SubmissionPositiveRecognitionAttachments_SubmissionPositiveRecognitionID',
        db_column='SubmissionPositiveRecognitionID', default=True)
    AttachmentFileName = SofvieCharField(max_length=200, null=True)
    AttachmentComment = SofvieTextField(blank=True, null=True)
    spa_image_timestamp = models.DateTimeField(blank=True, null=True)

    class Meta:
        db_table = 'SubmissionPositiveRecognitionAttachments'


class SubmissionPositiveRecognitionLike(models.Model):
    id = models.AutoField(primary_key=True)
    SubmissionPositiveRecognitionID = models.ForeignKey(
        SubmissionPositiveRecognition, models.DO_NOTHING,db_column='SubmissionPositiveRecognitionID',
        related_name='SubmissionPositiveRecognitionLike_SubmissionPositiveRecognitionID')
    SigningAccount = SofvieCharField(max_length=100)
    SigningName = SofvieCharField(max_length=200)
    SigningTimestamp = models.DateTimeField(blank=True, null=True)
    prl_recognition_of_person_id = SofvieIntegerField(blank=True, null=True)
    prl_position = SofvieIntegerField(blank=True, null=True)

    class Meta:
        db_table = 'SubmissionPositiveRecognitionLike'


class SubmissionPositiveRecognitionPerson(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)    
    recognitionof = models.ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='recognitionof', db_column='RecognitionOf' ,blank=True, null=True)

       
    submissionpositiverecognition = models.ForeignKey(
        SubmissionPositiveRecognition, models.DO_NOTHING,
        related_name='submission_positive_recognition',
        db_column='SubmissionPositiveRecognitionID', default=True)    

    class Meta:
        db_table = 'SubmissionPositiveRecognitionPerson'

class CommentLike(models.Model):
    clk_id = models.AutoField(primary_key=True)
    clk_com = models.ForeignKey(Comments, on_delete=models.DO_NOTHING, related_name='CommentLike_ClkComId')
    clk_cmt = models.ForeignKey(CommentsTable, on_delete=models.DO_NOTHING, related_name='CommentLike_ClkCmtId')
    clk_position = models.ForeignKey(RefListDetail, blank=True, null=True, on_delete=models.DO_NOTHING, related_name='CommentLike_ClkPosition')
    clk_created_by_per = models.ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='CommentLike_ClkCreatedByPerId')
    clk_created_date = models.DateTimeField(auto_now_add=True)
    clk_modified_by_per = models.ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='CommentLike_ClkModifiedByPerId', blank=True, null=True)
    clk_modified_date = models.DateTimeField(blank=True, null=True)
    clk_enable = models.BooleanField(default=True)
    clk_enote = SofvieTextField(blank=True, null=True)
    
    class Meta:
        db_table = 'comment_like'
