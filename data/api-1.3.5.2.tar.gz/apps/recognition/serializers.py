from rest_framework import serializers
from apps.recognition.models import SubmissionPositiveRecognition


# class RecognitionSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Recognition
#         fields = '__all__'

class SubmissionPositiveRecognitionSerializer(serializers.ModelSerializer):
    class Meta:
        model = SubmissionPositiveRecognition
        fields = '__all__'

