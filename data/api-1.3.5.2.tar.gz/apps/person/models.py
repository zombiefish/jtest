from django.db import models
from django.core.exceptions import ValidationError

# Create your models here.
# from apps.user.models import User
#
# User = get_user_model()
# from apps.user.models import User
from apps.address.models import AddressPhone
from apps.common_utils.views.sofvieModelFields import SofvieCharField, SofvieIntegerField, SofvieEmailField, SofvieTextField




class Person(models.Model):
    GENDER_CHOICES = (
        (688, 688),
        (6454, 6454),
        (8610, 8610),
        (None, None)
    )
    per_id = models.AutoField(primary_key=True)
    per_first_name = SofvieCharField(max_length=200, blank=False, null=False)    
    per_middle_name = SofvieCharField(max_length=200, blank= True, null=True)    
    per_last_name = SofvieCharField(max_length=200, blank=False, null=False)       
    per_dob = models.DateField(blank=True, null=True)
    per_sin = SofvieCharField(max_length=200, blank=True, null=True)    
    per_gender = SofvieCharField(max_length=255, blank=True, null=True)
    # per_gender = SofvieIntegerField(blank=True, default=None, choices = GENDER_CHOICES)
    per_created_date = models.DateTimeField(auto_now_add=True)
    per_created_by_per_id = models.ForeignKey('self',
                                              on_delete=models.DO_NOTHING,
                                              related_name='user_created_by',
                                              db_column='per_created_by_per_id',)
    per_modified_date = models.DateTimeField(auto_now=True)
    per_modified_by_per_id = models.ForeignKey('self', null=True,
                                               db_column='per_modified_by_per_id',
                                               on_delete=models.DO_NOTHING,
                                               related_name='user_modified_by',)
    per_enable = models.BooleanField(default=True)
    per_enote = SofvieTextField(blank=True, null=True)
    per_norcat_id = SofvieCharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'person'
        ordering = ['-per_first_name']

    # def __str__(self):
    #     return f"{self.per_first_name}, {self.per_last_name}"    

    @property
    def full_name(self):
        if self.per_middle_name:
            return f"{self.per_last_name}, {self.per_first_name} {self.per_middle_name}"
        else:
            return f"{self.per_last_name}, {self.per_first_name}"

    @classmethod
    def check_person_exists(self, data):
        person_query = Person.objects.filter(
            per_first_name = data['per_first_name'],
            per_last_name = data['per_last_name'],
            per_middle_name = data['per_middle_name'],
        )
        if person_query.exists():
            if person_query[0].per_middle_name:
                return False, "full_name_exists,{}".format(person_query[0].per_enable)        
            return False, "middle_name_required,{}".format(person_query[0].per_enable)
        return True, 'Create Person'

    @classmethod
    def check_person_exists_for_update(self, data):
        """"
        This function validates  all the attributs of this serialzier class

        Returns:
            Returns all the validate data
        """
        person_updated = data['per_id']
        person_query = Person.objects.filter(
            per_first_name = data['per_first_name'],
            per_last_name = data['per_last_name'],
            per_middle_name = data['per_middle_name']
        )


        '''
        get middle name counts of all records with same fname and lname excluding for user updating      

        middle name is required for user, only if there is a duplication of all fname, mname, and lname.

        if middle_name_count is one less than total count of users with same fname, lname i.e., newly updated user can be allowed without middle name

        '''
        if person_query.exists():
            if person_query[0].per_id==person_updated:
                return True, 'Update Person'  
            if person_query[0].per_middle_name:
                return False, "full_name_exists,{}".format(person_query[0].per_enable)        
            return False, "middle_name_required,{}".format(person_query[0].per_enable)
        return True, 'Update Person'
        


class PersonEmergencyContact(models.Model):
    pec_id = models.AutoField(primary_key=True)
    pec_per = models.ForeignKey(Person, on_delete=models.DO_NOTHING,
                                related_name='emergency_contacts', blank=True,
                                null=True)
    pec_first_name = SofvieCharField(max_length=200, blank=True, null=True)
    pec_last_name = SofvieCharField(max_length=200, blank=True, null=True)
    pec_relationship = SofvieCharField(max_length=200, blank=True, null=True)    
    pec_home_phone = SofvieCharField(max_length=200, blank=True,null=True)
    pec_work_phone = SofvieCharField(max_length=200, blank=True,null=True)
    pec_mobile_phone = SofvieCharField(max_length=200, blank=True,null=True)
    pec_email = SofvieEmailField(max_length=100, blank=True,null=True)
    pec_created_date = models.DateTimeField(auto_now=True, blank=True,null=True)
    pec_created_by_per = models.ForeignKey(Person,on_delete=models.DO_NOTHING,related_name='pec_created_by',blank=True,null=True)
    pec_modified_date = models.DateTimeField(blank=True, null=True)
    pec_modified_by_per = models.ForeignKey(Person,
                                            on_delete=models.DO_NOTHING,
                                            related_name='pec_modified_by',
                                            blank=True,
                                            null=True)
    pec_enable = models.BooleanField(default=True, blank=True,
                                     null=True)
    pec_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'person_emergency_contact'

    def __str__(self):
        return self.pec_first_name
