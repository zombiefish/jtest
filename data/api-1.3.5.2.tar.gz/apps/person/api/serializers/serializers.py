from rest_framework import serializers

from apps.person.models import Person, PersonEmergencyContact
from apps.user.models import User


class EmergencyContactSerializer(serializers.ModelSerializer):
    class Meta:
        model = PersonEmergencyContact
        fields = [
            'pec_id',
            'pec_per',
            'pec_first_name',
            'pec_last_name',
            'pec_relationship',
            'pec_mobile_phone',
            'pec_work_phone',
            'pec_home_phone',
            'pec_email'
        ]

class PersonDetailSerailizer(serializers.ModelSerializer):
    # users = UserDetailSerailizer(many=True)
    # emergency_contacts = PersonEmergencyContact(many=True, read_only=True)

    class Meta:
        model = Person
        fields = ['per_id', 'per_first_name',
                  'per_last_name', 'per_gender',
                  'per_dob', 'per_sin', 'per_enable',
                  'users', 'full_name'
                  ]
