import uuid
from datetime import datetime

from django.db.models import Prefetch, Q
from django.utils import timezone
from rest_framework import serializers, status
from rest_framework.exceptions import ValidationError
from rest_framework.generics import get_object_or_404
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db import transaction
from apps.address.models import Address
from apps.address.models import (
    AddressCountry,
    AddressProvState,
    AddressType
)
from apps.address.models import AddressPhone
from apps.address.models import AddressPhoneType
from apps.common_utils.views.get_translations import get_translation
from apps.employee.models import Employee, EmployeeJob
# Create Employee serializer to get the response in get List
from apps.employee.models import EmployeeSite
from apps.language.models import Language
from apps.person.models import Person, PersonEmergencyContact
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import \
    SofviePermission
from apps.sofvie_user_authorization.models import AuthRoleSofvie, \
    AuthUserRoleMappingSofive
from apps.target.api.views.delete_target import delete_target
from apps.target.models import Supervisortargets
from apps.user.api import EemployeeDetailSerialzer, RolePermission, \
    EmergencyContactSerializer
from apps.user.models import User
from apps.user_settings_profile.models import UserProfile
from apps.pass_reset.api.views import pw_check
from rest_framework.permissions import IsAuthenticated
from apps.user.api.helper_functions.sofvie_keycloak_helper_functions import addUserToKeycloak, \
    resetPasswordInKeycloak, removeUserFromKeycloak, updateUserInKeycloak, executeActionsEmail


class EmployeeSiteSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeSite
        fields = ['esi_id', 'esi_sit']


class EmployeeSerializer(serializers.ModelSerializer):
    # employee_sites is a related name from Employee table
    class Meta:
        model = Employee
        fields = ['emp_id', 'emp_employee_number', 'emp_enable']

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        ref_sites = instance.employee_sites.values_list('esi_sit', flat=True)
        ret['ref_sites'] = ref_sites
        return ret


class AddressTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AddressType
        fields = ['aty_id', 'aty_code', 'aty_description']


class AddressCountrySerializer(serializers.ModelSerializer):
    class Meta:
        model = AddressCountry
        fields = ['ctr_id', 'ctr_code', 'ctr_description']


class AddressProvStateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AddressProvState
        fields = ['prv_id', 'prv_code', 'prv_description']


class PhoneTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AddressPhoneType
        fields = ['pty_id', 'pty_code', 'pty_description']


class PhoneSerialzer(serializers.ModelSerializer):
    pho_pty = PhoneTypeSerializer(many=False)

    class Meta:
        model = AddressPhone
        fields = ['pho_id', 'pho_number', 'pho_pty']


class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = ['add_id', 'add_postal_code', 'add_line_1', 'add_city',
                  'add_prv', 'add_ctr',
                  'add_aty']


class RoleOutputListSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuthRoleSofvie
        fields = ['aro_id', 'aro_name', 'aro_tag_type']


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id',
                  'email',
                  'is_active',
                  'roles',
                  'receive_signup_email']


class PersonSerializer(serializers.ModelSerializer):
    users = UserSerializer(many=True)  # Foreign Key Relationship to get List
    addresses = AddressSerializer(many=True)  # Foreign Key Relationship to get List
    address_phones = PhoneSerialzer(many=True)  # Foreign Key Relationship to get List
    employees = EmployeeSerializer(many=True)  # Foreign Key Relationship to get List

    class Meta:
        model = Person
        fields = ['per_id', 'per_first_name', 'per_middle_name', 'per_last_name', 'users',
                  'addresses', 'address_phones', 'employees']


class AddressPhoneSerializer(serializers.Serializer):
    pho_id = serializers.IntegerField()
    pho_number = serializers.CharField(max_length=155, allow_blank=True, allow_null=True, required=False, default="")


class EmployeeSiteDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeSite
        fields = ['esi_sit']


class EmployeeJobUpdateOutputSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeJob
        fields = ['ejo_job']


# Create user serializer to get the email address and validate
class UserOutputSerializer(serializers.ModelSerializer):
    roles = RoleOutputListSerializer(many=True)

    class Meta:
        model = User
        fields = ['email','roles', 'id', 'is_active']


class PersonOutputSerializer(serializers.ModelSerializer):
    # add useroutputserialzier to personoutputserializer
    # for update the information and validation
    users = UserOutputSerializer(many=True)
    # Reuse the EmmployeeDetailSerializer from create user api
    employees = EemployeeDetailSerialzer(many=True)
    addresses = AddressSerializer(many=True)
    emergency_contact = EmergencyContactSerializer(
        source='emergency_contacts', many=True)

    class Meta:
        model = Person
        fields = ['per_first_name', 'per_middle_name',
                  'per_last_name', 'per_id', 'per_enable', 'per_sin',
                  'per_gender', 'per_modified_by_per_id',
                  'per_dob', 'users', 'employees', 'address_phones',
                  'addresses', 'emergency_contact']

    def to_representation(self, instance):
        ret = super().to_representation(instance)

        ret['address_phones'] = instance.address_phones.values(
            'pho_id',
            'pho_number',
            'pho_pty__pty_code',
            'pho_pty__pty_id',
            'pho_pty__pty_description'
        )
        return ret


class EmployeeUpdateSerializer(serializers.Serializer):
    emp_id = serializers.IntegerField(required=True)
    emp_pos_id = serializers.IntegerField(required=False)
    emp_enable = serializers.BooleanField(required=False)
    emp_employee_number = serializers.CharField(required=False,
                                                allow_null=True,
                                                allow_blank=True)
    employee_sites = serializers.ListField(required=False,
                                           child=serializers.IntegerField(
                                               required=False))
    employee_jobs = serializers.ListField(required=False,
                                          child=serializers.IntegerField(
                                              required=False))
    emp_data_visibility = serializers.CharField(max_length=11)

    def validate_emp_data_visibility(self, val='profile'):
        return val

        # def validate_emp_pos_id(self, value):


    def validate_emp_pos_id(self, value=0):
        try:
            if (value == 0):
                # return value
                return None
            RefListDetail.objects.get(rld_id=value)
            return value
        except RefListDetail.DoesNotExist:
            raise ValidationError(
                f"We could not find RefListDetail object with {value}"
                f" in our database")


class UserUpdateSerializer(serializers.Serializer):
    """
    reset_account_locked and activate are mutually exclusive
    if account is locked and need to reset send true
    if account is not locked and need to lock send false
    other wise do not send any key value

    and Same with activate
    if you really want to operate activate and deactivate just send true
    for activating  and false for deactivating otherwise do not send any key value
    """
    # create the serializer to update user email with exisiting email or new
    # email
    email = serializers.EmailField(max_length=255, allow_null=True, required=False)
    # Reset Password
    reset_password = serializers.BooleanField(default=False)
    # Deactivate User Account
    is_active = serializers.BooleanField(default=True)
    roles = serializers.ListField(required=False,
                                  child=serializers.IntegerField(
                                      required=False))
    activation_type = serializers.ChoiceField(
        choices=User.ACTIVATION_TYPE_CHOICES, default=User.EMAIL)
    password = serializers.CharField(required=False, allow_null=True,
                                     allow_blank=True)
    confirm_password = serializers.CharField(required=False, allow_null=True,
                                             allow_blank=True)


class AddressUpdateSerializer(serializers.Serializer):
    add_id = serializers.IntegerField(required=False)
    add_line_1 = serializers.CharField(max_length=255, required=False,
                                       allow_null=True, allow_blank=True)
    add_postal_code = serializers.CharField(max_length=255, required=False,
                                            allow_null=True, allow_blank=True)
    aty_id = serializers.IntegerField(required=False, allow_null=True)
    add_city = serializers.CharField(max_length=255, required=False,
                                     allow_null=True)
    prv_id = serializers.IntegerField(required=False,
                                      allow_null=True)  # AddressProvState
    ctr_id = serializers.IntegerField(required=False, allow_null=True)

    def validate(self, attrs):
        aty_id = attrs.get('aty_id', None)
        add_city = attrs.get('add_city', None)
        prv_id = attrs.get('prv_id', None)
        ctr_id = attrs.get('ctr_id', None)
        if ctr_id:
            if not AddressCountry.objects.filter(ctr_id=ctr_id,
                                                 ctr_enable=True).exists():
                raise ValidationError(
                    {"ctr_id": f"We can not find ctr_id {ctr_id} in our db"})
        else:
            attrs.pop('ctr_id', None)

        if prv_id and ctr_id:
            if not AddressProvState.objects.filter(prv_id=prv_id,
                                                   prv_ctr_id=ctr_id,
                                                   prv_enable=True).exists():
                raise ValidationError(
                    {"prv_id": f"We can not find prv_id {prv_id} in our db"})
        else:
            attrs.pop('prv_id', None)
        
        if aty_id:
            if not AddressType.objects.filter(aty_id=aty_id,
                                              aty_enable=True).exists():
                raise ValidationError(
                    {"aty_id": f"We can not find aty_id {aty_id} in our db"})
        else:
            attrs.pop('aty_id', None)
        if not attrs.get('add_line_1'):
            attrs.pop('add_line_1', None)
        if not attrs.get('add_postal_code'):
            attrs.pop('add_postal_code', None)
        return attrs


class UserProfileSerializer(serializers.Serializer):
    upr_language = serializers.CharField(required=False, allow_null=True, allow_blank=True)


# create serializer for person detail for update
class PersonUpdateSerializer(serializers.Serializer):
    per_first_name = serializers.CharField(max_length=255, required=False)
    per_middle_name = serializers.CharField(max_length=255, allow_blank=True, allow_null=True, required=False)
    per_last_name = serializers.CharField(max_length=255, required=False)
    per_dob = serializers.DateField(required=False, allow_null=True)
    per_gender = serializers.CharField(allow_null=True, allow_blank=True, required=False)
    per_sin = serializers.CharField(max_length=255, required=False)
    per_enable = serializers.BooleanField(required=False)
    per_modified_by_per_id = serializers.IntegerField(required=False,
                                                      allow_null=True,
                                                      )
    user = UserUpdateSerializer(many=False, required=False)
    per_employee = serializers.CharField(max_length=255, required=False)
    employee = EmployeeUpdateSerializer(many=False, required=False)
    # per_address = serializers.CharField(max_length=255, required=False)
    address_phone = AddressPhoneSerializer(many=False, required=False)
    address = AddressUpdateSerializer(many=False, required=False)
    emergency_contact = EmergencyContactSerializer(required=False, allow_null=True)
    user_profile = UserProfileSerializer(many=False, required=False)

    per_id = serializers.IntegerField()


# In listapiview just use queryset and serializer_class to  quickly get the data


class EmployeeSiteOutputListSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeSite
        fields = ['esi_id', 'esi_sit']


class EmployeeJobOutputListSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeJob
        fields = ['ejo_id', 'ejo_job']


class AddressOutputListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = ['add_id',
                  'add_line_1',
                  'add_postal_code',
                  'add_city',
                  'add_ctr',
                  'add_prv',
                  'add_aty']


class AddressPhoneOutputListSerializer(serializers.ModelSerializer):
    class Meta:
        model = AddressPhone
        fields = ['pho_id', 'pho_number', 'pho_pty_id']


class UserProfileOutputListSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = ['upr_per', 'upr_language']


class PersonOutputListSerializer(serializers.ModelSerializer):
    # add useroutputserialzier to personoutputserializer
    # for update the information and validation
    # Create user serializer to get the email address and validate

    class UserOutputListSerializer(serializers.ModelSerializer):
        class Meta:
            model = User
            fields = [
                'email',
                'activation_type',
                # 'sofvie_auth_user_role_mappings', #just for reference and
                'id',
                'is_active',
                'last_login'
            ]

        def to_representation(self, instance):
            ret = super().to_representation(instance)
            # roles is 'sofvie_auth_role_mappings its not user.roles actually
            ret['roles'] = [r.aur_aro_id_id for r in
                            instance.sofvie_auth_user_role_mappings.all()]
            return ret

    class EmployeeOutputListSerializer(serializers.ModelSerializer):
        class Meta:
            model = Employee
            fields = ['emp_id', 'emp_employee_number', 'emp_pos_id',
                      'emp_enable', 'emp_data_visibility']

        def to_representation(self, instance):
            ret = super().to_representation(instance)
            try:
                ret['employee_sites'] = [e.esi_sit_id for e in instance.employee_sites.all()]
            except:
                ret['employee_sites'] = []
            try:
                ret['employee_jobs'] = [e.ejo_job_id for e
                                        in instance.employee_jobs.all()]
            except:
                ret['employee_jobs'] = []

            return ret

    class EmergencyContactSerializer(serializers.ModelSerializer):
        class Meta:
            model = PersonEmergencyContact
            fields = [
                'pec_id',
                'pec_per',
                'pec_first_name',
                'pec_last_name',
                'pec_relationship',
                'pec_mobile_phone',
                'pec_work_phone',
                'pec_home_phone',
                'pec_email',
            ]

    users = UserOutputListSerializer(many=True)
    employees = EmployeeOutputListSerializer(many=True)
    emergency_contacts = EmergencyContactSerializer(many=True)
    upr_per_id = UserProfileOutputListSerializer(many=True)

    class Meta:
        model = Person
        fields = [
            'per_first_name',
            'per_middle_name',
            'per_last_name',
            'per_dob',
            'per_sin',
            'per_gender',
            'per_enote',
            'per_id',
            'per_enable',
            'users',
            'employees',
            'emergency_contacts',
            'per_modified_by_per_id',
            'per_modified_date',
            'upr_per_id'
        ]

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        address_phone = instance.address_phones.all()
        ret['address_phone'] = AddressPhoneOutputListSerializer(address_phone[0] if address_phone else None).data

        address = list(instance.addresses.all())
        ret['address'] = AddressOutputListSerializer(address[-1] if address else None).data
        ret['per_created_by_per'] = instance.per_created_by_per_id.full_name
        if instance.per_modified_by_per_id:

            ret['per_modified_by_per'] = instance.per_modified_by_per_id.full_name
        else:
            ret['per_modified_by_per'] = None

        return ret
    
class PersonListApi(APIView):
    
    
    permission_classes = [IsAuthenticated, SofviePermission]
    permission_attrs = (RolePermission.CanViewUsers.value,)
    
    serializer_class = PersonOutputListSerializer

    def post(self, request):
        person_id = self.request.user.user_per_id

        status = request.data['status'] if 'status' in request.data and request.data['status'] else 3885

        # get translations for the status [Active, Inactive, All]
        language = UserProfile.objects.get(upr_per_id=person_id).upr_language
        lng_id = Language.objects.get(lng_name=language).lng_id
        
        master_filter = []        
        status_filter = []
        # If user select it will bring per_enable=True, emp_enable=True
        if status == 3885: # User
            status_filter = [Q(users__is_active=True)]
            master_filter = [Q(per_id=1) | Q(per_first_name="Master")]
        # If user select it will bring per_enable=False, emp_enable=True
        elif status == 190: # Employee
            status_filter = [Q(employees__emp_enable=True), Q(users__is_active=False)]
            master_filter = [Q(per_id=1) | Q(per_first_name="Master")]
        # If user select it will bring per_enable=False, emp_enable=False
        elif status == 3793: # Inactive
            status_filter = [Q(users__is_active=False), Q(employees__emp_enable=False)]
            master_filter = [Q(per_id=1) | Q(per_first_name="Master")]
        else:
            master_filter = [Q(per_id=1) | Q(per_first_name="Master")]

        res = PersonOutputListSerializer(Person.objects.exclude(*master_filter).filter(*status_filter
            ).prefetch_related('employees','upr_per_id',  Prefetch(
                'employees__employee_sites', EmployeeSite.objects.filter(
                    esi_enable=True, esi_sit__rld_enable=True,)),
                            'employees__employee_sites__esi_sit',
                            Prefetch('employees__employee_jobs', EmployeeJob.objects.filter(ejo_enable=True)),
                            'users',
                                Prefetch('users__sofvie_auth_user_role_mappings',
                                        AuthUserRoleMappingSofive.objects.filter(aur_enable=True)),
                            'users__sofvie_auth_user_role_mappings__aur_aro_id',
                            'address_phones', 'addresses',
                                        Prefetch(
                'emergency_contacts',
                PersonEmergencyContact.objects.filter(pec_enable=True),
            ),
            'emergency_contacts__pec_per',
                            ).select_related(
                'per_created_by_per_id', 'per_modified_by_per_id'
            ).order_by(
                '-per_id'), many=True).data
        return Response(res)




class PersonUpdateApi(APIView):
    # send data with post request with per_id
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageUsers.value, RolePermission.CanUpdateAccounts.value,)
    all_permissions = False

    @transaction.atomic
    def post(self, request, per_id):
        created_by = request.user.user_per_id
        modified_by = request.user.user_per_id
        send_new_activation_email = False
        send_reset_password_email = False
        add_new_user_with_new_email = False
        reset_password_in_keycloak = False
        # get the person or not found
        person = get_object_or_404(Person, per_id=per_id)
        # serialize and save into serializer variable all person response data

        # valid the serializer data and through any exception if data is not
        pho_per_id = request.data.get('per_id')

        pho_id = request.data.get('address_phone', {}).get('pho_id', 0)

        pho_number = request.data.get('address_phone', {}).get('pho_number')
        if not pho_id:
            obj = AddressPhone.objects.create(pho_per_id=pho_per_id,
                                              pho_number=pho_number,
                                              pho_pty_id=1,
                                              pho_created_by_per=created_by)

            request.data['address_phone']['pho_id'] = obj.pho_id

        serializer = PersonUpdateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        _status, message = person.check_person_exists_for_update(data=request.data)
        if _status:

            serializer.is_valid(raise_exception=True)
            # Pop the email from serializer data variable
            user_data = serializer.validated_data.pop('user', None)

            employee_data = serializer.validated_data.pop('employee', None)

            address_phone_data = serializer.validated_data.pop('address_phone',
                                                               {})
            emergency_contact = serializer.validated_data.pop(
                'emergency_contact', None)

            if emergency_contact is not None and all((value is None or value =='') for value in emergency_contact.values()):
                emergency_contact = None
            
            current_contact = PersonEmergencyContact.objects.filter(pec_per_id = per_id, pec_enable = True)

            different = False

            

            if emergency_contact is not None and current_contact.exists():
                different = any([emergency_contact[key] != getattr(current_contact.first(), key) 
                    for key in emergency_contact.keys()])
            elif not current_contact.exists():
                different = True
                
            if emergency_contact is None:
                disable_employee_emergency_contact(self, per_id)
            elif different == True:
                disable_employee_emergency_contact(self, per_id)
                emergency_contact.update({'pec_enable': True})
                emergency_contact['pec_email'] = emergency_contact['pec_email'].lower() if emergency_contact['pec_email'] else emergency_contact['pec_email']
                emergency_contact['pec_modified_by_per'] = modified_by
                PersonEmergencyContact.objects.create(pec_per_id=per_id,
                                                      pec_created_by_per=created_by,
                                                      **emergency_contact)
            else:
                pass

            address_data = serializer.validated_data.pop('address', {})

            userProfile = serializer.validated_data.pop('user_profile', None)
            # get all the person data
            person.per_first_name = serializer.validated_data.get('per_first_name', person.per_first_name)
            person.per_middle_name = serializer.validated_data.get('per_middle_name', person.per_middle_name)
            person.per_last_name = serializer.validated_data.get('per_last_name',
                                                                 person.per_last_name)
            person.per_dob = serializer.data.get('per_dob',
                                                 person.per_dob)
            person.per_gender = serializer.validated_data.get('per_gender',
                                                              person.per_gender)
            person.per_enable = serializer.validated_data.get('per_enable',
                                                              person.per_enable)
            person.per_modified_by_per_id = modified_by
            person.per_modified_date = datetime.now()
            # save the person into database
            person.save()

            # update user table
            # validate the user_data which contain person email
            if user_data:
                password = user_data.pop('password', None)
                confirm_password = user_data.pop('confirm_password', None)
                reset_password_check = user_data.pop('reset_password', False)
                activation_type = user_data.pop('activation_type', False)
                activate_account = user_data.pop('is_active', False)                 
                
                if not activate_account:
                    # if account is not active - delete all targets assigned for that account
                    open_targets_per = Supervisortargets.objects.filter(
                        supervisorid = str(person.per_id),
                        effectiveend__isnull = True,
                        sta_enable = True
                    )                    
                    deleting_reason = "User Deactivated"
                    for open_target in open_targets_per:                        
                        delete_target(self, open_target, modified_by, datetime.now().date(), 'direct', deleting_reason)

                roles = user_data.pop('roles', False)
                # if email is true store in email variable
                email = user_data.get('email', None)
                # Double check the password here.
                # if the password passes the check then proceed.
                pwd = pw_check()
                valid = True
                if password !=None and confirm_password != None and password==confirm_password: 
                    valid = pwd.validatePW(password)
                    if not valid or password!=confirm_password:
                        raise ValidationError({"The password did not meet the minimum requirements."})
                try:
                    user = User.objects.filter(user_per_id=per_id).get()
                    current_existing_email = user.email
                    if email and (email != user.email):

                        if user.email == None or user.email == "":
                            add_new_user_with_new_email = True
                        if User.objects.filter(email=email):
                            # if email already assign to per then raise
                            # validation error with message in exception
                            raise ValidationError(
                                {'email': f"{email} already Exist in db"})
                        user.email = email
                    user.modified_by_per_id = modified_by

                    if roles:  # new roles

                        # determine if there are new items.  Add if necessary.
                        current = user.sofvie_auth_user_role_mappings.filter(aur_enable=True).values_list('aur_aro_id', flat=True)
                        new_role = [role_id for role_id in roles if role_id not in current] 
                        new_roles = [AuthUserRoleMappingSofive( aur_aro_id = AuthRoleSofvie.objects.get(aro_id=item), aur_user_id = user, aur_created_by_per_id = created_by
                        ) for item in new_role]
                        AuthUserRoleMappingSofive.objects.bulk_create(new_roles)

                        # determine if there are removed items.  Disable if necessary.
                        current = user.sofvie_auth_user_role_mappings.filter(aur_enable=True).values_list('aur_aro_id', flat=True)
                        removed_items = [role for role in current  if role not in roles]
                        user.sofvie_auth_user_role_mappings.filter(aur_aro_id__in = removed_items).update(aur_enable = False,  
                            aur_modified_date = datetime.now(),
                            aur_modified_by_per_id = user.modified_by_per_id
                        )

                    existing_activation_status = user.is_active
                    user.is_active = activate_account
                    created_activation_type = user.activation_type
                    if created_activation_type == user.LATER and reset_password_check and activation_type==user.EMAIL:
                        send_new_activation_email = True
                        user.user_per_id.per_enable = True
                        user.user_per_id.save()
                        user.activation_type = user.EMAIL
                    elif (created_activation_type == user.LATER or not existing_activation_status) and not reset_password_check and activate_account:
                        send_new_activation_email = True
                        user.user_per_id.per_enable = True
                        user.user_per_id.save()
                        user.activation_type = user.EMAIL
                    elif not created_activation_type == user.LATER \
                        and reset_password_check and activation_type==user.EMAIL and not add_new_user_with_new_email:
                        send_reset_password_email = True
                    elif user.activation_type!=user.MANUAL and user_data.get(
                            'activation_type')==user.MANUAL or password:
                        if not password:
                            raise ValidationError({"password": "This field is "
                                                            "required."})
                        if not confirm_password:
                            raise ValidationError(
                                {"confirm_password": "This field is "
                                                    "required."})
                        if not password == confirm_password:
                            raise ValidationError(
                                "password and confirm did not match.")
                           
                        user.set_password(password)
                        user.activation_type = user.MANUAL
                        user.user_per_id.per_enable = True
                        user.user_per_id.save()
                        # Manual Reset Password in keycloak
                        reset_password_in_keycloak = True
                        send_new_activation_email = False
                    user.save()

                except User.DoesNotExist as e:
                    raise ValidationError({f"We could not find user for that "
                                        f"person with per_id {per_id}"})
               
            if address_phone_data:
                address_phone_qs = AddressPhone.objects.filter(
                    pho_per=person,
                    pho_id=address_phone_data['pho_id'])

                if address_phone_qs:
                    address_phone = address_phone_qs.get()
                    address_phone.pho_number = address_phone_data.get('pho_number', address_phone.pho_number)
                    address_phone.save()
                else:
                    raise ValidationError({"address_phone": f"We could not find "
                                                            f"address phone_number with given pho_id"})

            if employee_data:

                try:
                    employee = Employee.objects.filter(emp_per_id=per_id).get(
                        emp_id=employee_data['emp_id'])

                    employee_number_serialize_data = employee_data.get(
                        'emp_employee_number')
                    employee_enable_serialize_data = employee_data.get(
                        'emp_enable')

                    if employee_number_serialize_data and \
                            employee_number_serialize_data != employee \
                            .emp_employee_number:
                        if Employee.objects.filter(
                                emp_employee_number=employee_number_serialize_data
                        ).exists():
                            raise ValidationError({
                                "emp_employee_number": f"Employee number "
                                                       f"{employee_number_serialize_data} "
                                                       f"already exist in our database"})

                    # if employee_number_serialize_data is "":
                    if employee_number_serialize_data == "":
                        employee.emp_employee_number = None
                    else:
                        employee.emp_employee_number = employee_data.get(
                            'emp_employee_number', employee.emp_employee_number)

                    employee.emp_pos_id = employee_data.get('emp_pos_id',
                                                            employee.emp_pos_id)
                    employee.emp_enable = employee_data.get('emp_enable',
                                                            employee.emp_enable)
                    employee.emp_data_visibility = employee_data.get('emp_data_visibility', employee.emp_data_visibility)
                    employee.emp_modified_by_per_id = modified_by
                    employee.emp_modified_date = datetime.now()
                    employee.save()

                    if not employee_data.get('emp_enable',employee.emp_enable):
                        user.user_per_id.per_enable = False
                        user.is_active = False
                        user.user_per_id.save()

                    if user.email:
                        if add_new_user_with_new_email:
                            addUserToKeycloak(user, userProfile['upr_language'])
                        else:
                            if current_existing_email:
                                updateUserInKeycloak(user, current_existing_email, userProfile['upr_language'])
                    
                    if send_new_activation_email:
                        executeActionsEmail(user.id, ["VERIFY_EMAIL","UPDATE_PASSWORD"])
                    if send_reset_password_email:
                        executeActionsEmail(user.id, ["UPDATE_PASSWORD"])
                    if reset_password_in_keycloak:
                        resetPasswordInKeycloak(user.id, password)

                    esi_sit_list = employee_data.get('employee_sites', [])
                    ejo_job_list = employee_data.get('employee_jobs', [])

                    manage_employee_sites(self, employee, esi_sit_list, created_by)
                    manage_employee_jobs(self, employee, ejo_job_list, created_by)

                except Employee.DoesNotExist:
                    raise ValidationError({'employee': f"We can not find employee "
                                                       f"with emp_id "
                                                       f"{employee_data['emp_id']}"})
            if address_data:
                try:
                    address = Address.objects.get(
                        add_id=address_data.get('add_id'), add_per=person)
                    if address_data.get('aty_id'):
                        address.add_aty_id = address_data.get('aty_id')
                    else:
                        address.add_aty_id = ""
                    if address_data.get('add_city'):
                        address.add_city = address_data.get('add_city')
                    else:
                        address.add_city = ""
                    if address_data.get('ctr_id'):
                        address.add_ctr_id = address_data.get('ctr_id')
                    else:
                        address.add_ctr_id = ""
                    if address_data.get('prv_id'):
                        address.add_prv_id = address_data.get('prv_id')
                    else:
                        address.add_prv_id = ""
                    if address_data.get('add_postal_code'):
                        address.add_postal_code = address_data.get('add_postal_code')
                    else:
                        address.add_postal_code = ""
                    if address_data.get('add_line_1'):
                        address.add_line_1 = address_data.get('add_line_1')
                    else:
                        address.add_line_1 = ""
                    address.save()
                except Address.DoesNotExist:

                    aty_id = address_data.pop('aty_id', {})
                    prv_id = address_data.pop('prv_id', None)
                    ctr_id = address_data.pop('ctr_id', None)
                    Address.objects.create(
                        add_per=person,
                        add_created_by_per=created_by,
                        add_modified_by_per=modified_by,
                        add_aty_id=aty_id,
                        add_prv_id=prv_id,
                        add_ctr_id=ctr_id,
                        **address_data
                    )

            if userProfile:
                try:
                    user_profile = UserProfile.objects.get(upr_per=person)
                    user_profile.upr_language = userProfile['upr_language']
                    user_profile.save()
                except UserProfile.DoesNotExist:
                    system_setting_language = Language.objects.get(lng_default=True)
                    UserProfile.objects.create(
                        upr_per=person,
                        upr_language=system_setting_language.lng_name,
                        upr_created_by_per=created_by,
                    )

            data = PersonOutputSerializer(person).data
            # Return the response from data variable with the status code 200
            return Response(data, status=status.HTTP_200_OK)
        else:
            return Response({"message": message, "status": _status})


def manage_employee_sites(self, employee, site_list, per_id):

    # determine if there are new items.  Add if necessary.  
    current_sites = employee.employee_sites.filter(esi_enable=True).values_list('esi_sit_id', flat=True)
    new_sites = [site for site in site_list if site not in current_sites] 

    new_employee_sites = [EmployeeSite(esi_sit=RefListDetail.objects.get(rld_id=new_site),
            esi_emp=employee,
            esi_created_by_per=per_id,
            esi_modified_by_per=per_id    
    )    for new_site in new_sites]

    EmployeeSite.objects.bulk_create(new_employee_sites)

    # determine if there are removed items.  Disable if necessary.
    removed = [sit_id for sit_id in current_sites if sit_id not in site_list]

    if removed:
        EmployeeSite.objects.filter(esi_emp=employee, esi_sit_id__in=removed).update(esi_enable=False,
        esi_modified_by_per = per_id,
        esi_modified_date = datetime.now()
    )
       

def manage_employee_jobs(self, employee, job_list, per_id):
    
    # determine if there are new items.  Add if necessary.
    current_jobs = employee.employee_jobs.filter(ejo_enable=True).values_list('ejo_job_id', flat=True)
    new_jobs = [job for job in job_list if job not in current_jobs ] 
    new_employee_jobs = [EmployeeJob(ejo_job=RefListDetail.objects.get(rld_id=new_job),
            ejo_emp=employee,
            ejo_created_by_per = per_id
    )    for new_job in new_jobs]

    EmployeeJob.objects.bulk_create(new_employee_jobs)

    # determine if there are removed items.  Disable if necessary.
    removed = [job_id for job_id in current_jobs if job_id not in job_list]

    if removed:
        EmployeeJob.objects.filter(ejo_emp=employee, ejo_job_id__in=removed).update(
            ejo_enable=False, 
            ejo_modified_by_per = per_id, 
            ejo_modified_date= datetime.now()
        )
       
def disable_employee_emergency_contact(self, per_id):
    PersonEmergencyContact.objects.filter(pec_per_id = per_id, pec_enable = True).update(pec_enable = False, pec_modified_by_per=per_id, pec_modified_date = datetime.now())