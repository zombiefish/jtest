
from django.urls import path
from . import views

urlpatterns = [
    path('persons/', views.PersonListApi.as_view()),
    path('persons/<int:per_id>/update/', views.PersonUpdateApi.as_view())
]