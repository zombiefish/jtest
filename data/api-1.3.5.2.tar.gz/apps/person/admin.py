from django.contrib import admin

from .models import (Person, PersonEmergencyContact
    # Address, AddressType,

                     )

# Register your models here.

admin.site.register(Person)
admin.site.register(PersonEmergencyContact)
# admin.site.register(Address)
# admin.site.register(AddressType)
