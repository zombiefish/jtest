from django.test import TestCase

# Create your tests here.
# Create your tests here.
from apps.employee.models import Employee
from apps.person.models import Person
from apps.user.models import User


class MinimalUserCreationTest(TestCase):

    def setUp(self):
        person_valid_data = {
            'per_first_name': "John",
            'per_last_name': "Doe",
            'per_gender': "Male",
            'per_dob': "10-25-1990",
            "per_created_by_per_id_id": 1,
            "per_modified_by_per_id_id": 1
        }
        user_valid_data = {
            'email': "webdeveloper@magtechpro.com",

        }

        employee_valid_data = {
            'emp_pos': 'welder'
        }
        person = Person.objects.create(**person_valid_data
                                       )
        user = User.objects.create(
            user_per_id=person,
            created_by_per_id=person,
            modified_by_per_id=person,
            **user_valid_data
        )
        # employee = Employee.objects.create(**employee_valid_data)

    def test_person_created(self):
        person = Person.objects.count()
        self.assertEqual(1, person)

    def test_person_gender(self):
        person = Person.objects.first()
        self.assertEqual('Male', person.per_gender)

    def test_person_data(self):
        person = Person.objects.first()
        self.assertEqual('John', person.per_first_name)

    def test_person_full_name(self):
        person = Person.objects.first()
        self.assertEqual('John Doe', person.full_name)

    def test_get_user(self):
        user = User.objects.get(user_per_id=1)
        self.assertEqual(1, user.user_per_id.per_id)

    def test_user_email(self):
        user = User.objects.get(user_per_id=1)
        self.assertEqual('webdeveloper@magtechpro.com', user.email)

    # def test_employee(self):
    #     employee = Employee.objects.get(emp_pos='welder')
    #     self.assertEqual('welder', employee.emp_pos_id)





