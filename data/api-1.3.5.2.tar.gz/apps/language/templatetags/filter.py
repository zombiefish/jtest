from django import template
import json

register = template.Library()

@register.filter(name = 'translate_custom_tags')
def translate_custom_tags(value, language):
    file_name = r'apps\locales\translation_'+language+'.json'
    with open(file_name, encoding='utf-8') as data_json:
        data = json.load(data_json)
    try:
        value = data[value]
    except KeyError:
        pass
    return value