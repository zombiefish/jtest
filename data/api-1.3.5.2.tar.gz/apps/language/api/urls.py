from django.urls import path
from apps.language.api.views.translate_files import CreateTranslateFiles
from apps.language.api.views.get_translation_list import GetTranslationList,UpdateTranslations
from apps.language.api.views.language_settings import GetAdminLanguageSettings,UpdateAdminLanguageSettings,GetDefaultLanguage,GetLanguageList
from apps.language.api.views.helper_function_add_translation import AddTranslation



urlpatterns = [
    path('create-translate-files/', CreateTranslateFiles.as_view()),
    path('get_translation_list/<str:filters>/', GetTranslationList.as_view()),
    path('get_language_settings/', GetAdminLanguageSettings.as_view()),
    path('get_default_language/', GetDefaultLanguage.as_view()),
    path('update_language_settings/', UpdateAdminLanguageSettings.as_view()),
    path('update_translation/', UpdateTranslations.as_view()),
    # path('add-translation/', AddTranslation.as_view()),
    path('get-language-list/', GetLanguageList.as_view())
    
]