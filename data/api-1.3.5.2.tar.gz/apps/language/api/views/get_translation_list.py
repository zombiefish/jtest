from itertools import chain

import pandas as pd
from django.db import connection
from django.db.models import Subquery, OuterRef, Q
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.equipment.models import EquipmentType, EquipmentQuestions
from apps.equipment.models import PreopEquipmentMeasure
from apps.form_builder.models import FormBuilderItem, FormBuilderCategory, FormBuilder
from apps.language.models import Language, LanguageTranslation
from apps.reflist.models import RefListDetail, RefListHeader
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.sofvie_user_authorization.models import AuthRoleSofvie
from apps.user_settings_profile.models import UserProfile


class GetTranslationList(APIView):
    permission_classes =  [SofviePermission]
    permission_attrs = (RolePermission.CanViewInternationalization.value,)
    """ Sample Output
        {
            "languages": [
                {
                    "lng_id": 1,
                    "lng_name": "en",
                    "lng_description_text": "English"
                },
                {
                    "lng_id": 2,
                    "lng_name": "fr",
                    "lng_description_text": "French"
                }
            ],
            "tags": [
                {
                    "ltr_tag": "1111",
                    "lng_en": "Test English",
                    "lng_fr": "Test French",
                    "lng_es": "Test Spanish"
                }
            ]
        }
    """
    def get(self, request, filters):
        person = request.user.user_per_id
        user_language = UserProfile.objects.get(upr_per = person).upr_language
        lang_id = Language.objects.get(lng_name = user_language)
        # Get Selected Languages
        selectedLanguages = Language.objects.filter(lng_enable=True, lng_selected = True).values_list('lng_id', flat= True)
        
        languages = Language.objects.filter(
            lng_enable=True, lng_selected = True
        ).annotate(
            lng_description_text = Subquery(LanguageTranslation.objects.filter(
                ltr_tag = OuterRef('lng_description'),
                ltr_lng_id = lang_id,
                ltr_tag_type = 1
                ).values('ltr_text')[:1]
            )
        ).values(
            "lng_id","lng_name","lng_description_text"
        )
        
        exclude_tags_q, disabledFormReflistsHeaderIds = get_excluded_tags()

        if filters == 'All Values':
            filter_tags = LanguageTranslation.objects.filter(
                ltr_lng_id__in=selectedLanguages,
                ltr_tag_type = 2,
                ltr_enable = True
            ).exclude(*exclude_tags_q).values_list('ltr_tag', flat=True)
            q_tags = [Q(ltr_tag__in=filter_tags)]
        elif filters == "Equipment Pre-Op Values":
            #Get all tag type 2 tags from PreOpEquipment
            filter_tags = EquipmentType.objects.filter(
                poe_tag_type = 2
            ).values_list('poe_equip_description', flat = True)
            #Get all tag type 2 tags from PreOpQuestions
            sec_filter_tags = EquipmentQuestions.objects.filter(
                poq_tag_type = 2
            ).values_list('poq_preop_question', flat = True)
            filter_tags = list(chain(filter_tags,sec_filter_tags))           
            q_tags = [Q(ltr_tag__in=filter_tags)]
        elif filters == 'Values Missing Translations':            
            # Filter ltr_translated = False
            filter_tags = LanguageTranslation.objects.filter(
                ltr_lng_id__in=selectedLanguages,
                ltr_tag_type = 2,
                ltr_enable = True,
                ltr_translated = False
            ).exclude(*exclude_tags_q).values_list('ltr_tag', flat=True)
            q_tags = [Q(ltr_tag__in=filter_tags)]
        elif filters == 'List Values':
            # Get all tag type 2 tags from Reflist
            filter_tags_name = RefListDetail.objects.filter(
                rld_tag_type=2,
                rld_enable=True,
                rld_deleted=False
            ).exclude(rld_rlh_id__in=disabledFormReflistsHeaderIds).values_list('rld_name', flat=True)
            
            filter_tags_description = RefListDetail.objects.filter(
                rld_tag_type=2,
                rld_enable=True,
                rld_deleted=False,
                rld_description__isnull=False
            ).exclude(rld_rlh_id__in=disabledFormReflistsHeaderIds).values_list('rld_description', flat=True)
            
            filter_tags = list(filter(None,list(chain(filter_tags_name,filter_tags_description))))
            
            q_tags = [Q(ltr_tag__in=filter_tags)]
        elif filters == 'Training Record Values':
            # Get all tag type 2 tags from Reflist for rld_rlh_id = 51
            filter_tags = RefListDetail.objects.filter(
                rld_tag_type=2,
                rld_rlh_id =51,
                rld_enable=True,
                rld_deleted=False 
            ).values_list('rld_name', flat=True)
            q_tags = [Q(ltr_tag__in=filter_tags)]
        elif filters == 'Role Definition Values':
            # Get all tag type 2 tags from Reflist for rld_rlh_id = 51
            filter_tags = AuthRoleSofvie.objects.filter(
                aro_tag_type=2,
                aro_enable=True
            ).values_list('aro_name', flat=True)
            q_tags = [Q(ltr_tag__in=filter_tags)]

        ltr_tags = LanguageTranslation.objects.filter(
            ltr_lng_id__in=selectedLanguages,
            ltr_tag_type = 2,
            ltr_enable = True,
            *q_tags
        ).exclude(ltr_text = "").values('ltr_tag','ltr_text','ltr_lng__lng_name','ltr_translated')

        tags = []
        if ltr_tags:
            df_ltr_tag = pd.DataFrame(ltr_tags)

            # To find duplicated rows based on tag and language for tag type 2 (Please do not remove the below 2 lines)
            # duplicate = df_ltr_tag[df_ltr_tag.duplicated(['ltr_tag', 'ltr_lng__lng_name'])]
            # pivot_data = df_ltr_tag.pivot(index='ltr_tag',columns='ltr_lng__lng_name',values='ltr_text')            
            pivot_data = df_ltr_tag.pivot_table(index='ltr_tag',columns='ltr_lng__lng_name',values='ltr_text', aggfunc=lambda x: ' '.join(x))
            pivot_data = pivot_data.fillna('')
            tags = pivot_data.reset_index().to_dict(orient='records')
              
        return Response({"languages":languages, "tags": tags,"translated":ltr_tags})

class UpdateTranslations(APIView):
    permission_classes =  [SofviePermission]
    permission_attrs = (RolePermission.CanViewInternationalization.value,)
    
    def post(self, request):
        payload = request.data
        tag_query = LanguageTranslation.objects.filter(
            ltr_tag_type=2,
            ltr_tag=payload['ltr_tag']
        )
        for trans in payload['translations']:
            tag_query = LanguageTranslation.objects.filter(
                ltr_tag_type=2,
                ltr_tag=payload['ltr_tag'],
                ltr_lng_id=trans['ltr_lng_id']
            ).update(ltr_text=trans['ltr_text'],ltr_translated=trans['ltr_translated'])
        return Response({"trans_request":request.data, "message": "success"})


def get_excluded_tags():
    disabledFormReflistsHeaderIds = []

    with connection.cursor() as cursor:
        cursor.execute("call get_disabled_form_ref_lists()")
        disabledFormReflistsHeaderIds = [row[0] for row in cursor.fetchall()]
    filter_tags = []
    exclude_tags_q = []
    q_tags = []
    exclude_tags = []

    exclude_tags_rld_name = RefListDetail.objects.filter(
            rld_tag_type=2,
            rld_rlh_id__in=disabledFormReflistsHeaderIds
        ).values_list('rld_name', flat=True)
    
    exclude_tags_rld_description = RefListDetail.objects.filter(
            rld_tag_type=2,
            rld_rlh_id__in=disabledFormReflistsHeaderIds
        ).values_list('rld_description', flat=True)

    disabled_ref_list_header_Id = RefListHeader.objects.filter(
        rlh_tag_type = 2,
        rlh_enable = False
    ).values_list("rlh_id", flat = True)

    disabled_ref_list_header_name = RefListHeader.objects.filter(
        rlh_tag_type = 2,
        rlh_enable = False
    ).values_list("rlh_display_name", flat = True)   

    disabled_ref_list_header_description = RefListHeader.objects.filter(
        rlh_tag_type = 2,
        rlh_enable = False,
        rlh_description__isnull = False
    ).values_list("rlh_description", flat = True)

    disabled_ref_list_detail_name = RefListDetail.objects.filter(
        rld_tag_type = 2,
        rld_enable = False,
        rld_deleted = True,
    ).values_list("rld_name", flat = True)

    disabled_ref_list_detail_description = RefListDetail.objects.filter(
        rld_tag_type = 2,
        rld_enable = False,
        rld_deleted = True,
        rld_description__isnull = False
    ).values_list("rld_description", flat = True)

    disabled_ref_list_detail_header_name = RefListDetail.objects.filter(
        rld_tag_type = 2,
        rld_enable = True,
        rld_deleted = False,
        rld_rlh_id__in = disabled_ref_list_header_Id
    ).values_list("rld_name", flat = True)

    disabled_ref_list_detail_header_description = RefListDetail.objects.filter(
        rld_tag_type = 2,
        rld_enable = True,
        rld_deleted = False,
        rld_description__isnull = False,
        rld_rlh_id__in = disabled_ref_list_header_Id
    ).values_list("rld_description", flat = True)

    disabled_role_name = AuthRoleSofvie.objects.filter(
            aro_tag_type=2,
            aro_enable=False
    ).values_list('aro_name', flat=True)

    disabled_FormBuilderItems = FormBuilderItem.objects.filter(
            fbi_tag_type=2,
            fbi_enable=False
    ).values_list('fbi_field_label', flat=True)

    disabled_form_builder_categories = FormBuilderCategory.objects.filter(
            fbc_tag_type=2,
            fbc_enable=False
    ).values_list('fbc_name', flat=True)

    disabled_form_builder_name = FormBuilder.objects.filter(
            fob_tag_type=2,
            fob_enable=False
    ).values_list('fob_name', flat=True)

    disabled_form_builder_description = FormBuilder.objects.filter(
            fob_tag_type=2,
            fob_enable=False
    ).values_list('fob_description', flat=True)

    disabled_preOp_equip_type = EquipmentType.objects.filter(
            poe_tag_type=2,
            poe_enable=False
    ).values_list('poe_equip_description', flat=True)

    disabled_preOp_questions = EquipmentQuestions.objects.filter(
            poq_tag_type=2,
            poq_enable=False
    ).values_list('poq_preop_question', flat=True)

    disabled_preOp_measure_types = PreopEquipmentMeasure.objects.filter(
            pem_enable=False
    ).values_list('pem_rld_measure_id', flat=True)



    exclude_tags_duplicate = list(chain(
        exclude_tags_rld_name,
        exclude_tags_rld_description,
        disabled_ref_list_header_name,
        disabled_ref_list_header_description,
        disabled_ref_list_detail_name,
        disabled_ref_list_detail_description,
        disabled_ref_list_detail_header_name,
        disabled_ref_list_detail_header_description,
        disabled_role_name,
        disabled_FormBuilderItems,
        disabled_form_builder_categories,
        disabled_form_builder_name,
        disabled_form_builder_description,
        disabled_preOp_equip_type,
        disabled_preOp_questions,
        disabled_preOp_measure_types
    ))

    exclude_tags_set = set(exclude_tags_duplicate)
    exclude_tags = list(filter(None,list(exclude_tags_set)))

    exclude_tags_q = [Q(ltr_tag__in=exclude_tags)]

    disabledFormReflistsHeaderIds = list(chain(disabledFormReflistsHeaderIds,disabled_ref_list_header_Id))
    return exclude_tags_q, disabledFormReflistsHeaderIds