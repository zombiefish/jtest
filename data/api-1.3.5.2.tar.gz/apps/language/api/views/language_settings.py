from apps.common_utils.views.validate_permission import RolePermission
from apps.language.api.views.get_translation_list import get_excluded_tags
from apps.language.models import Language, LanguageTranslation
from django.forms.models import model_to_dict
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView
from django.db.models import Subquery, OuterRef, Q
from django.db.models.functions import Substr
from apps.reflist.models import RefListDetail
from apps.equipment.models import EquipmentType, EquipmentQuestions
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.sofvie_user_authorization.models import AuthRoleSofvie
from itertools import chain
import pandas as pd
from apps.user_settings_profile.models import UserProfile

class GetAdminLanguageSettings(APIView):
    permission_classes =  [IsAuthenticated]
    """
        {
            "lng_id": 1,
            "lng_name": "en",
            "lng_description_text": "English",
            "lng_default": 1,
            "lng_selected": 1
        },
        {
            "lng_id": 2,
            "lng_name": "fr",
            "lng_description_text": "French",
            "lng_default": 0,
            "lng_selected": 1
        }
    ]
    """
    def get(self, request):
        person = request.user.user_per_id
        user_language = UserProfile.objects.get(upr_per = person).upr_language
        lang_id = Language.objects.get(lng_name = user_language)
        availableLanguages = Language.objects.filter(lng_enable=True).values_list('lng_id', flat= True)    
        exclude_tags_q, disabledFormReflistsHeaderIds = get_excluded_tags()
        missingTrans_obj = LanguageTranslation.objects.exclude(
            *exclude_tags_q
        ).filter(
            ltr_tag_type = 2,
            ltr_enable = True,
            ltr_translated = False
        )
        missingTrans = {}
        for lang in availableLanguages:            
            missingTrans[lang] = missingTrans_obj.filter(ltr_lng_id = lang).count()
        # return Response({"languages":languages,"missingTrans":missingTrans})
        return Response({"missingTrans":missingTrans, "availableLanguages":availableLanguages})

class GetDefaultLanguage(APIView):
    # used before user login - no authentication required
    def get(self,request):
        language = Language.objects.get(lng_default = 1, lng_enable=1).lng_name
        return Response({"def_lang":language})

class UpdateAdminLanguageSettings(APIView):
    permission_classes =  [SofviePermission]
    permission_attrs = (RolePermission.CanManageAdvancedSettings.value,)

    """
    {
        "lng_default": 1,
        "selected": [1],
    }
    """

    def post(self, request):
        reset_lang = Language.objects.all().update(lng_default=False,lng_selected=False)
        default_lang = Language.objects.get(lng_id=request.data['lng_default']).lng_name
        disabled_langs = Language.objects.exclude(lng_id__in=request.data['selected']).values_list('lng_name',flat=True)
        
        update_sel = Language.objects.filter(
            lng_id__in = request.data['selected']
        ).update(lng_selected=True)
        update_def = Language.objects.filter(
            lng_id = request.data['lng_default']
        ).update(lng_default=True,lng_selected=True)

        
        update_upr_lang = UserProfile.objects.filter(
            upr_language__in=disabled_langs
        ).update(upr_language=default_lang)

        return Response({"Output":request.data,"message":"success"})


class GetLanguageList(APIView):
    # used across adminstration 
    permission_classes =  [SofviePermission]  
    permission_attrs = (RolePermission.AccessAdministration.value,)
    def get(self, request):
        person = request.user.user_per_id
        user_language = UserProfile.objects.get(upr_per = person).upr_language
        lang_id = Language.objects.get(lng_name = user_language)        
        languages = Language.objects.filter(
            lng_enable=True
        ).annotate(
            lng_description_text=Subquery(LanguageTranslation.objects.filter(
                ltr_tag = OuterRef('lng_description'),
                ltr_lng_id = lang_id,
                ltr_tag_type = 1
                ).values('ltr_text')[:1]
            )
        ).values(
            "lng_id",
            "lng_name",
            "lng_description_text",
            "lng_default",
            "lng_selected"
        )

        return Response({"languages":languages})

