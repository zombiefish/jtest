from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.language.models import Language, LanguageCategoryType, LanguageTranslation
from django.conf import settings
import os
import textwrap
from io import BytesIO
import json

from apps.sofvie_user_authorization.api.permissions import SofviePermission

class CreateTranslateFiles(APIView):
    permission_classes = [SofviePermission]
    
    def get(self, request):

        languages = Language.objects.all().values_list('lng_name', flat=True)
        
        for language in languages:
            queryset = LanguageTranslation.objects.filter(
                ltr_lng__lng_name=language, ltr_tag_type=1
            ).values()
            
            translation_data = "{\n"
            for row in queryset:                
                text = row['ltr_text'].replace('"', '\\"')
                text = text.replace('\r\n', '<br>')
                translation_data += f'"{row["ltr_tag"]}" : "{text}",\n'
            translation_data = translation_data[:-2]
            translation_data += "\n}"
            f = open(os.path.join(settings.HAZARD_ACTION_DIR,'documents_attachments',"translation_"+language+".json"), "w", encoding="utf-8")
            f.write(translation_data)
            f.close()
        return Response("OK")

