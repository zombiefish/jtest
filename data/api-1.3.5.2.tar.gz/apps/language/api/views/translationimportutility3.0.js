// Translations import utility.
// The purpose of this utility is to automate the importation of 
// translation data from text files and insert the data into the database.
// This utility will do the following:
// It will add translations to existing languages.
// It will expect a comma delimited file.
// Each row will contain a new translation.
// The first column will be English
// The second column will be French
// It will add a new tag for each English / French translation in the file.
// Do not use this utility to add a new language.


let ENGLISH = 1
let FRENCH = 2
let SPANNISH = 3
let languages = [ENGLISH, FRENCH, SPANNISH]

let max_tag_s = -1
let max_tag_c = -1
let dups = []
let allGaps = []
var mysql = require('mysql');
var fs = require('fs');
var csv = require('csv-parser')

//select column_name , ',' from information_schema.COLUMNS where TABLE_NAME = 'language_translation'
let languageFieldList = "ltr_tag,ltr_lng_id,ltr_text,ltr_created_date,ltr_created_by_per_id,ltr_enable,ltr_enote,ltr_tag_type,ltr_translated"
//let languageFieldList = "ltr_tag,ltr_lng_id,ltr_text,ltr_lca_id,ltr_created_date,ltr_created_by_per_id,ltr_enable,ltr_enote"

function getConnection(){
  return mysql.createConnection({
    host: "192.168.0.40",
    user: "sofvie_app",
    password: "5ET2Dura",
    database: "sofvie_dev"
  });
}

function importData(fileName){
  fs.createReadStream(fileName)
  .pipe(csv())
  .on('data', (row) => {
    row.english = row.english.replace(/'/g,`''`)
    row.french = row.french.replace(/'/g,`''`)
    exportD(row).then(()=>{})
  })
  .on('end', () => {
    console.log('CSV file successfully processed');
  });
}

function isRowDuplicate(row){
  if(dups.includes(row.english.trim().toUpperCase())){
    return true
  }
  dups.push(row.english.trim().toUpperCase())
  return false
}

async function exportD(row){

  await exportData(row)

}

function exportData(row){
  return new Promise(()=>{

    if(isRowDuplicate(row)=== false ){

      let val = row.tagtype
      getNextTag(val).then((t) =>{

        let sql1 = ''
        let sql2 = ''
        let valuesListEn = ""
        let valuesListFr = ""

        valuesListEn = t.toString() + `,` + ENGLISH + `, '` + row.english.trim().replace('\t','') + `', '2021-06-15 15:10', 1, 1, '','`+ val + `',1`
        valuesListFr = t.toString() + `,` + FRENCH  + `, '` + row.french.trim().replace('\t','')  + `', '2021-06-15 15:10', 1, 1, '','`+ val + `',1`

        //Generate sql query here.
        sql1 += `INSERT INTO language_translation(` + languageFieldList + `) VALUES (`+ valuesListEn + `);\n` // statement for the English translation.
        sql2 += `INSERT INTO language_translation(` + languageFieldList + `) VALUES (`+ valuesListFr + `);\n` // statement for the French translation.
        
        fs.appendFile("log.txt", sql1, 'utf8', (err)=>{
          if (err) throw err
        })
        fs.appendFile("log.txt", sql2, 'utf8',  (err)=>{
          if (err) throw err
        })
      })
       
    }
  })
}

async function getAvailableTags() {
  let mt = await findTheGaps()
  return mt
}
function findTheGaps(){
  return new Promise(resolve =>{
    let con = getConnection()
    let sql = "SELECT ltr_tag + 1 as next_tag , 'x'  as tag_type FROM language_translation lto "
    sql += "WHERE NOT EXISTS (SELECT null FROM language_translation lti WHERE lti.ltr_tag = lto.ltr_tag +1 )"
    sql += "GROUP BY next_tag UNION "
    sql += "SELECT DISTINCT t.ltr_tag as next_tag , 1 as tag_type FROM language_translation t WHERE t.ltr_tag_type = 2 AND t.ltr_lng_id = 1 and ltr_tag not in "
    sql += "(SELECT ltr_tag from language_translation WHERE ltr_tag_type = 1)"
    sql += "UNION SELECT DISTINCT t.ltr_tag as next_tag , 2 as tag_type FROM language_translation t WHERE t.ltr_tag_type = 1 AND t.ltr_lng_id = 1  and ltr_tag not in "
    sql += "(SELECT ltr_tag from language_translation WHERE ltr_tag_type = 2)"
    sql += "ORDER BY next_tag desc;"

    con.query(sql, (err, result) =>{
      if(err) throw err
      for(r of result){
        let res = {}
        res.type = r.tag_type
        res.tag = r.next_tag
        allGaps.push(res)
      }
      con.end()
      resolve(true)
    })
  })
}

function getMaxTag(source){
  return new Promise(resolve =>{
    let con = getConnection()
    let sql = "SELECT MAX(ltr_tag) + 1 as maxtag FROM language_translation WHERE ltr_lng_id = 1 and ltr_tag_type='" + source + "'"
    
    con.query(sql,(err, result) => {
      if (err) throw err;
      if(result[0].maxtag===null){
        maxTag = 1
      } else {
        maxTag =  result[0].maxtag
      }
      con.end()
      resolve(maxTag)
    }) 
 
  })
  
}

async function getMaxTagID (source) {
  let mt = await getMaxTag(source)
  if(source == 'c'){
    max_tag_c = mt
  } else {
    max_tag_s = mt
  }
  return mt
}
 
const StartImport = () => {
  getEnglishWords().then(res =>{
    getAvailableTags().then(res =>{
      //console.log(allGaps)
      importData("june23242021.csv")
      // importData("one.csv")
      // for(g of allGaps){
      //   console.log(g)
      // }

       // // test code.
      // console.log(allGaps)
      // for(let c=0;c<6000;c++){
      //   // console.log(c)
      //   getNextT('s').then(()=>{
      //     console.log("M T", max_tag_s)
      //   })
      // }
     

    })
  })
 
}
async function getNextTag(trans_type){

  let rtrn = await getNextT(trans_type)

  return rtrn
}
function getNextT(trans_type){

  return new Promise(resolve =>{

     
    if(allGaps.length > 0){
      for(let l =allGaps.length-1;l>=0;l--){
        let g = allGaps[l]
        if(g.type == trans_type || g.type =='x'){
          allGaps.splice(l,1)
          if(trans_type =='s'){
            max_tag_s = g.tag
          } else {
            max_tag_c = g.tag
          }
      
          resolve(g.tag) 
          return
        }
      }
      
      if( max_tag_s == -1 && trans_type == 's' ){
        console.log("TRY HERE")
        getMaxTagID(trans_type).then((t) =>{
          max_tag_s = t
          resolve(max_tag_s)
          return
        })
      } else if( max_tag_c == -1 && trans_type == 'c' ){  
        console.log("HERE@")
        getMaxTagID(trans_type).then((t) =>{
          max_tag_c = t
          resolve(max_tag_c)
          return
        })
        console.log("I THink I am here also")
      } else {
        console.log("Do I get here?")
        let temp 
        if(trans_type =='s'){
          console.log("TAG TYPE S")
          max_tag_s += 1
          temp = max_tag_s
          console.log("THIS IS TEMP:",temp)
        } else {
          max_tag_c += 1
          temp = max_tag_c
        }

        resolve(temp)
        return

      }
    
    } else {

      if( max_tag_s == -1 && trans_type == 's' ){
        // console.log("Getting max tag abc")
        getMaxTagID(trans_type).then((t) =>{
          max_tag_s = t
           
          resolve(max_tag_s)
          return
        })
      } else if( max_tag_c == -1 && trans_type == 'c' ){  
        getMaxTagID(trans_type).then((t) =>{
          max_tag_c = t
          resolve(max_tag_c)
          return
        })
  
      } else {
        let temp 
        if(trans_type =='s'){
          max_tag_s += 1
          temp = max_tag_s
        } else {
          max_tag_c += 1
          temp = max_tag_s
        }
        resolve(temp)
        return
         
      }
    }
  })
}

async function getEnglishWords(){
  let words = await getAllEnglishWords()
  return words
}

function getAllEnglishWords(){
  return new Promise(resolve => { 
    let con = getConnection()
    let sql = "SELECT UPPER(ltr_text) as eng from language_translation where ltr_lng_id = 1 order by ltr_text"
    dups = []
    con.query(sql,(err, result) => {
      if (err) throw err;

      for (r of result){
        dups.push(r.eng)
      }
      con.end()
      resolve(true)
     }) 
  })
}

StartImport()
