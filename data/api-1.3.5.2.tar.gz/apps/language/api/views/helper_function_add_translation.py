from django.db.models import Max
from numpy import not_equal
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.language.models import Language, LanguageTranslation
from apps.sofvie_user_authorization.api.permissions import SofviePermission

class AddTranslation(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewInternationalization.value,)
    def post(self, request):
        person = request.user.user_per_id #person object
        '''
        input payload: 
        {
            'ltr_lng_id' : 1,
            'ltr_text' : 'sample',
            'ltr_tag_type' :1
        }
        '''
        payload = request.data
        tag_type = payload.pop('ltr_tag_type') 
        tagNumber = helperAddTranslation(self, [payload], tag_type)
        return Response({'tag number': tagNumber})

def helperAddTranslation(self, data, tag_type = 2, *args, **kwargs):

    # data = {
    #     "preop_question_type": 1,
    #     "preop_questions": [
    #         {
    #             "ltr_lng_id": 1,
    #             "ltr_text": "Rana question one"
    #         },
    #         {
    #             "ltr_lng_id": 2,
    #             "ltr_text": "Rana qu unno French"
    #         }
    #     ]
    # }
    '''
    sample input data : 
        [
            {
                "ltr_lng_id": 1,
                "ltr_text": "hello"
            },
            {
                "ltr_lng_id": 2,
                "ltr_text": "hello French"
            },
            {
                "ltr_lng_id": 3,
                "ltr_text": "hello Spanish"
            }
        ]
    '''
    person = self.request.user.user_per_id   
    # add ltr_translated tag to data - True

    for each in data:
        each['ltr_translated'] = True
    # Get default language selected (for client)
    defaultLanguage = Language.objects.get(lng_enable=True, lng_default=True).lng_id

    selectedLanguages = Language.objects.filter(lng_enable=True).values_list('lng_id', flat=True)    

    inputLanguages = [each['ltr_lng_id'] for each in data]

    missingLanguages = list(set(selectedLanguages).difference(inputLanguages))    
    
    # prepare new payload data including the missing language
    if missingLanguages:
        # get default ltr text 
        defaultText = ''
        for each in data:            
            if each['ltr_lng_id'] == defaultLanguage:
                defaultText = each['ltr_text']
        for each in missingLanguages:
            temp = {}
            temp['ltr_lng_id'] = each
            temp['ltr_text'] = defaultText
            temp['ltr_translated'] = False
            data.append(temp.copy())
    
    latestTagNumber = LanguageTranslation.objects.filter(
        ltr_tag_type = tag_type
    ).aggregate(Max('ltr_tag'))
    latestTagNumber = latestTagNumber['ltr_tag__max'] if latestTagNumber['ltr_tag__max'] else 0
    nextTagNumber = latestTagNumber + 1  
    
    # insert data to language translation table    
    LanguageTranslation.objects.bulk_create([LanguageTranslation(
                                                ltr_tag=nextTagNumber, 
                                                ltr_tag_type = tag_type,
                                                ltr_lng_id =  each['ltr_lng_id'],
                                                ltr_text =  each['ltr_text'],
                                                ltr_translated = each['ltr_translated'],
                                                ltr_created_by_per = person)
                                                for each in data])
    return nextTagNumber