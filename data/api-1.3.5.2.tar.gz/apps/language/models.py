from django.db import models
from apps.common_utils.views.sofvieModelFields import SofvieCharField, SofvieIntegerField, SofvieTextField

from apps.person.models import Person


class Language(models.Model):
    lng_id = models.AutoField(primary_key=True)
    lng_name = SofvieCharField(max_length=100)
    lng_description = SofvieCharField(max_length=200)
    lng_default = models.BooleanField(default=False)
    lng_selected = models.BooleanField(default=False)
    lng_created_date = models.DateTimeField(auto_now_add=True)

    lng_created_by_per = models.ForeignKey(Person, on_delete = models.DO_NOTHING,   
                                           related_name='lng_person_created_by')
    lng_modified_date = models.DateTimeField(auto_now=True, blank=True,
                                            null=True)
    lng_modified_by_per = models.ForeignKey(Person, on_delete = models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='lng_person_modified_by')
    lng_enable = models.BooleanField(default=True)
    lng_enote = SofvieTextField(blank=True, null=True)

    class Meta:

        db_table = 'language'

class LanguageCategoryType(models.Model):
    lca_id = models.AutoField(primary_key=True)
    lca_filename = SofvieCharField(max_length=255)
    lca_created_date = models.DateTimeField(auto_now_add=True)

    lca_created_by_per = models.ForeignKey(Person, on_delete = models.DO_NOTHING,
                                          
                                           related_name='lca_person_created_by')
    lca_modified_date = models.DateTimeField(auto_now=True, blank=True,
                                            null=True)
    lca_modified_by_per = models.ForeignKey(Person, on_delete = models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='lca_person_modified_by')
    lca_enable = models.BooleanField(default=True)
    lca_enote = SofvieTextField(blank=True, null=True)

    class Meta:

        db_table = 'language_category_type'

class LanguageTranslation(models.Model):
    ltr_id = models.AutoField(primary_key=True)
    ltr_lng = models.ForeignKey(Language, on_delete=models.DO_NOTHING, related_name='ltr_lng_id')
    ltr_tag = SofvieIntegerField()
    ltr_text = SofvieTextField(allowed_tags=['b','i','a'])
    ltr_tag_type = SofvieIntegerField(blank=False, null=False)
    ltr_translated = models.BooleanField(default=True)
    ltr_created_date = models.DateTimeField(auto_now_add=True)  
    ltr_created_by_per = models.ForeignKey(Person, on_delete = models.DO_NOTHING,
                                           
                                           related_name='ltr_person_created_by')
    ltr_modified_date = models.DateTimeField(auto_now=True, blank=True,
                                            null=True)
    ltr_modified_by_per = models.ForeignKey(Person, on_delete = models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='ltr_person_modified_by')
    ltr_enable = models.BooleanField(default=True)
    ltr_enote = SofvieTextField(blank=True, null=True)

    class Meta:

        db_table = 'language_translation'
