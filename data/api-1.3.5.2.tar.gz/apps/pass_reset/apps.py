from django.apps import AppConfig


class PassResetConfig(AppConfig):
    name = 'apps.pass_reset'
