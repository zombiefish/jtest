class pw_check:
    def checkLengthIdeal(self,pw):
        if len(pw) >=12:
            return True
        return False

    def checkLength(self,pw):
        if len(pw) >= 8:
            return True
        return False

    def containsLowerCase(self,pw):
        for letter in range(0, len(pw)):
            if ord(pw[letter]) >= 97 and ord(pw[letter]) <= 122:
                return True
        return False

    def containsUpperCase(self,pw):
        for letter in range(0, len(pw)):
            if ord(pw[letter]) >= 65 and ord(pw[letter]) <= 90:
                return True
        return False

    def containsNumeric(self,pw):
        for letter in range(0, len(pw)):
            if ord(pw[letter]) >= 48 and ord(pw[letter]) <= 57:
                return True
        return False

    def containsSpecialCharacters(self,pw):
        characters =  ["!",'"',"#","$","%","&","'","(",")","*","+",",","-",".","/",":",";","<","=",">","?","@","[","\",","]","^","_","`","{","|","}","~"]

        for special in range(0, len(characters)):
            if pw.find(characters[special]) > -1:
                return True
        return False

    def validatePW(self, pw):
        leng = self.checkLength(pw) or self.checkLengthIdeal(pw)
        lower = self.containsLowerCase(pw)
        upper = self.containsUpperCase(pw)
        num = self.containsNumeric(pw)
        special = self.containsSpecialCharacters(pw)

        return leng and lower and upper and num and special

        
