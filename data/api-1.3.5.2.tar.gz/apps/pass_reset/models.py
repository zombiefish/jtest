from django.db import models
from apps.common_utils.views.sofvieModelFields import SofvieCharField
from apps.person.models import Person

