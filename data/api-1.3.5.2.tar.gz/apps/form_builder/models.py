import datetime

from django.db import models
from django.db.models import (
    Model,
    ForeignKey,
    AutoField,
    DateTimeField,
    BooleanField,
)
from apps.form.models import Formcategories
from apps.reflist.models import RefListHeader
from django_extensions.db.fields import AutoSlugField

from apps.common_utils.views.sofvieModelFields import (
    SofvieCharField,
    SofvieIntegerField,
    SofvieTextField
)
from apps.general_action.models import Submissionheader
from apps.person.models import Person
from apps.custom_list.models import CustomListHeader

class FormBuilderCategory(Model):
    fbc_id = AutoField(primary_key=True)
    fbc_name = SofvieIntegerField(blank=False, null=False)
    fbc_tag_type = SofvieIntegerField(blank=False, null=False)
    fbc_slug = AutoSlugField(max_length=255, populate_from=["fbc_name"],
                             help_text="A label for fbc_name config.")
    fbc_created_date = DateTimeField(auto_now_add=True)
    fbc_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='fbc_created_by')
    fbc_modified_date = DateTimeField(auto_now=True, blank=True, null=True)
    fbc_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='fbc_modified_by',
                                     blank=True, null=True)
    fbc_enable = BooleanField(default=True)
    fbc_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = 'form_builder_category'

    def __str__(self):
        return self.fbc_name


class FormBuilder(Model):
    fob_id = AutoField(primary_key=True)
    fob_fbc = ForeignKey(FormBuilderCategory, on_delete=models.DO_NOTHING,
                         related_name='formbuilder', null = True, blank = True)
    fob_fca = ForeignKey(Formcategories, on_delete=models.DO_NOTHING,
                         related_name='pre_defined_form_category', null = True, blank = True)
    fob_name = SofvieIntegerField(blank=False, null=False)
    fob_slug = AutoSlugField(max_length=255, populate_from=['fob_name'],
                             help_text="A label for fob_name config.", )
    fob_description = SofvieIntegerField(blank=False, null=False)
    fob_tag_type = SofvieIntegerField(blank=False, null=False)

    fob_created_date = DateTimeField(auto_now_add=True)
    fob_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING,
                                    related_name='fob_created_by')
    fob_modified_date = DateTimeField(auto_now=False, blank=True, null=True)
    fob_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING,
                                     related_name='fob_modified_by',
                                     blank=True, null=True)
    fob_archived_date = DateTimeField(blank=True, null=True)
    fob_archived_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING,
                                     related_name='fob_archived_by',
                                     blank=True, null=True)
    fob_enable = BooleanField(default=True)
    fob_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = 'form_builder'

    def __str__(self):
        return self.fob_created_by_per.full_name


class FormFieldType(Model):
    fft_id = AutoField(primary_key=True)
    fft_field_label = SofvieIntegerField(blank=True, null=True)
    fft_category = SofvieIntegerField(blank=False, null=False, default=1)
    fft_required = BooleanField(default=False)
    fft_additional_info = BooleanField(default=False)
    fft_created_date = DateTimeField(auto_now_add=True)
    fft_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='fft_created_by')
    fft_modified_date = DateTimeField(auto_now=True, blank=True, null=True)
    fft_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='fft_modified_by',
                                     blank=True, null=True)
    fft_enable = BooleanField(default=True)
    fft_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = 'form_field_type'

    def __str__(self):
        return self.fft_field_label

class RefListOther(Model):
    flo_id = AutoField(primary_key=True)
    flo_descirption = SofvieCharField(max_length=200, blank=True, null=True)
    flo_created_date = DateTimeField(auto_now_add=True)
    flo_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='flo_created_by')
    flo_modified_date = DateTimeField(auto_now=True, blank=True, null=True)
    flo_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='flo_modified_by',
                                     blank=True, null=True)
    flo_enable = BooleanField(default=True)
    flo_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = 'ref_list_other'

class FormBuilderItem(Model):
    fbi_id = AutoField(primary_key=True)
    fbi_fob = ForeignKey(FormBuilder, on_delete=models.DO_NOTHING, related_name='items')
    fbi_fft = ForeignKey(FormFieldType, on_delete=models.DO_NOTHING, related_name='fbi_field_type')
    fbi_field_label = SofvieIntegerField(blank=False, null=False)
    fbi_tag_type = SofvieIntegerField(blank=False, null=False)
    fbi_sort = SofvieIntegerField()
    fbi_list_type_rlh = ForeignKey(RefListHeader, on_delete=models.DO_NOTHING, blank=False, null=True, related_name='fbi_list_type_rlh_id')
    fbi_list_type_clh = ForeignKey(CustomListHeader, on_delete=models.DO_NOTHING, blank=False, null=True, related_name='fbi_list_type_clh_id')
    fbi_list_type_flo = ForeignKey(RefListOther, on_delete=models.DO_NOTHING, blank=False, null=True, related_name='fbi_list_type_flo_id')
    fbi_required = BooleanField(default=True)
    fbi_additional_info_label = SofvieIntegerField(blank=True, null=True)
    fbi_additional_info_tag_type = SofvieIntegerField(blank=True, null=True)
    fbi_additional_info_type = SofvieIntegerField(blank=True, null=True)
    fbi_additional_info_required = SofvieIntegerField(blank=False, null=False, default=0)
    fbi_created_date = DateTimeField(auto_now_add=True)
    fbi_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='fbi_created_by')
    fbi_modified_date = DateTimeField(auto_now=False, blank=True, null=True)
    fbi_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='fbi_modified_by',
                                     blank=True, null=True)
    fbi_archived_date = DateTimeField(blank=True, null=True)
    fbi_archived_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='fbi_archived_by',
                                     blank=True, null=True)

    fbi_enable = BooleanField(default=True)
    fbi_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = 'form_builder_item'
        ordering = ['fbi_sort']


# Mobile transaction models
class CustomFormMaster(Model):
    cfm_id = AutoField(primary_key=True)
    cfm_submission_header = ForeignKey(Submissionheader, on_delete=models.DO_NOTHING,
                                       related_name='cfm_submission_header')
    cfm_fob = ForeignKey(FormBuilder, on_delete=models.DO_NOTHING, related_name='cfm_fob')
    cfm_created_date = DateTimeField(auto_now_add=True)
    cfm_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='cfm_created_by')
    cfm_modified_date = DateTimeField(auto_now=True, blank=True, null=True)
    cfm_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='cfm_modified_by',
                                     blank=True, null=True)
    cfm_enable = BooleanField(default=True)
    cfm_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = 'custom_form_master'


class CustomFormDetail(Model):
    cfd_id = AutoField(primary_key=True)
    cfd_cfm = ForeignKey(CustomFormMaster, on_delete=models.DO_NOTHING, related_name='cfd_cfm')
    cfd_fbi = ForeignKey(FormBuilderItem, on_delete=models.DO_NOTHING, related_name='cfd_fbi')
    cfd_created_date = DateTimeField(auto_now_add=True)
    cfd_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='cfd_created_by')
    cfd_modified_date = DateTimeField(auto_now=True, blank=True, null=True)
    cfd_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='cfd_modified_by',
                                     blank=True, null=True)
    cfd_enable = BooleanField(default=True)
    cfd_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = 'custom_form_detail'


class CustomFormAttachment(Model):
    cfa_id = AutoField(primary_key=True)
    cfa_cfm = ForeignKey(CustomFormMaster, on_delete=models.DO_NOTHING, null=True, blank=True, related_name='cfa_custom_form')
    cfa_cfd = ForeignKey(CustomFormDetail, on_delete=models.DO_NOTHING,null=True, blank=True, related_name ='cfa_custom_form_detail_id')
    cfa_filename = SofvieCharField(max_length=200, blank=True, null=True)
    cfa_element_name = SofvieCharField(max_length=200, blank=True, null=True)
    cfa_picture_date = DateTimeField(blank=True, null=True)
    cfa_created_date = DateTimeField(auto_now_add=True)
    cfa_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='cfa_created_by')
    cfa_modified_date = DateTimeField(auto_now=True, blank=True, null=True)
    cfa_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='cfa_modified_by',
                                     blank=True, null=True)
    cfa_enable = BooleanField(default=True)
    cfa_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = 'custom_form_attachment'

class CustomFormDetailValue(Model):
    cdv_id = AutoField(primary_key=True)
    cdv_cfd = ForeignKey(CustomFormDetail, on_delete=models.DO_NOTHING, related_name='cdv_custom_form_detail')
    cdv_value = SofvieTextField()
    cdv_additional_info = BooleanField(default=False)
    cdv_created_date = DateTimeField(auto_now_add=True)
    cdv_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='cdv_created_by')
    cdv_modified_date = DateTimeField(auto_now=True, blank=True, null=True)
    cdv_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='cdv_modified_by',
                                     blank=True, null=True)
    cdv_enable = BooleanField(default=True)
    cdv_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = 'custom_form_detail_value'