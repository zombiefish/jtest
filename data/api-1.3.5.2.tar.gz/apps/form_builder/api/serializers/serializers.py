from rest_framework import serializers

from rest_framework import serializers
from rest_framework.fields import SerializerMethodField
from rest_framework.serializers import (
    ModelSerializer,
    HyperlinkedIdentityField,
)

from django.db.models import Q

from apps.form_builder.models import (
    FormBuilderCategory,
    FormBuilder,
    FormFieldType,
    FormBuilderItem,
    CustomFormMaster,
)
from apps.language.models import LanguageTranslation, Language
from apps.person.models import Person
from apps.user_settings_profile.models import UserProfile


class FormFieldTypeSerializer(ModelSerializer):
    fft_field_label = serializers.SerializerMethodField()
    fft_category = serializers.SerializerMethodField()

    class Meta:
        model = FormFieldType
        fields = '__all__'

    def get_fft_field_label(self, instance):
        person = self.context['request'].user.user_per_id
        lng_name = UserProfile.objects.get(upr_per= person).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)
        return LanguageTranslation.objects.filter(ltr_tag=instance.fft_field_label, ltr_tag_type=1, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]

    def get_fft_category(self, instance):
        person = self.context['request'].user.user_per_id
        lng_name = UserProfile.objects.get(upr_per= person).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)

        if instance.fft_category == 1:
            fft_category_tran = LanguageTranslation.objects.filter(ltr_tag=9144, ltr_tag_type=1, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
        else:
            fft_category_tran = LanguageTranslation.objects.filter(ltr_tag=9145, ltr_tag_type=1, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]

        return fft_category_tran


class FormBuilderItemSerializer(ModelSerializer):
    fbi_id = serializers.IntegerField(required=False, allow_null=True)
    fbi_fob_id = serializers.IntegerField(required=False, allow_null=True)
    fbi_created_by_per_id = serializers.IntegerField(required=False,
                                                     allow_null=True)
    fbi_modified_by_per_id = serializers.IntegerField(required=False,
                                                      allow_null=True)

    class Meta:
        model = FormBuilderItem
        fields = (
            'fbi_id',
            'fbi_fob_id',
            'fbi_fft',
            'fbi_field_label',
            'fbi_tag_type',
            'fbi_sort',
            'fbi_list_type_rlh_id',
            'fbi_list_type_clh_id',
            'fbi_list_type_flo_id',
            'fbi_required',
            'fbi_additional_info_label',
            'fbi_additional_info_tag_type',
            'fbi_additional_info_type',
            'fbi_additional_info_required',
            'fbi_created_date',
            'fbi_created_by_per_id',
            'fbi_modified_date',
            'fbi_modified_by_per_id',
            'fbi_enable',
        )

class SingleFormBuilderSerializer(ModelSerializer):
    fob_created_by_per_id = serializers.IntegerField(required=False,
                                                     allow_null=True)
    fob_modified_by_per_id = serializers.IntegerField(required=False,
                                                      allow_null=True)

    items = SerializerMethodField(source='get_items')

    class Meta:
        model = FormBuilder
        fields = ('fob_id', 'fob_fbc', 'fob_fca','fob_name', 'fob_slug', 'fob_tag_type',
                  'fob_description', 'fob_created_by_per_id',
                  'fob_modified_date',
                  'fob_created_date', 'fob_modified_by_per_id', 'items')
    
    def __init__(self, *args, **kwargs):
        
        person = kwargs["context"].get("request").user.user_per_id        
        lang_name = UserProfile.objects.get(upr_per=person).upr_language
        self.lang_id = Language.objects.get(lng_name=lang_name).lng_id
        
        super(SingleFormBuilderSerializer, self).__init__(*args, **kwargs)

    def to_representation(self, instance):
        ret = super().to_representation(instance)      
     
        try:
            if instance.fob_fbc:
                ltr_tag_filter = [Q(ltr_tag = instance.fob_fbc.fbc_name), Q(ltr_tag_type = 2)]
                ret['type'] = 'Custom Categories'
            elif instance.fob_fca:
                ltr_tag_filter = [Q(ltr_tag = instance.fob_fca.category), Q(ltr_tag_type = 1)]
                ret['type'] = 'Pre-Defined Categories'

            ret['fob_category_name'] =  LanguageTranslation.objects.filter(
                    *ltr_tag_filter,
                    ltr_lng = self.lang_id).values_list('ltr_text', flat= True)[0]
        except Exception as e:
            if instance.fob_fbc:
                ret['fob_category_name'] = instance.fob_fbc.fbc_name
            elif instance.fob_fca:
                ret['fob_category_name'] = instance.fob_fca.category
            
        return ret

    def get_items(self, obj):
        return FormBuilderItemSerializer(obj.items.filter(
            fbi_enable=True), many=True, read_only=True,
            context={"items": obj}).data


class FormBuilderSerializer(ModelSerializer):
    fob_created_by_per_id = serializers.IntegerField(required=False, allow_null=True)
    fob_modified_by_per_id = serializers.IntegerField(required=False, allow_null=True)

    items = FormBuilderItemSerializer(many=True)
    class Meta:
        model = FormBuilder
        fields = ('fob_id', 'fob_fbc', 'fob_name', 'fob_slug', 'fob_tag_type',
                  'fob_description', 'fob_created_by_per_id',
                  'fob_modified_date',
                  'fob_created_date', 'fob_modified_by_per_id', 'items')
    
    def __init__(self, *args, **kwargs):
        
        person = kwargs["context"].get("request").user.user_per_id        
        lang_name = UserProfile.objects.get(upr_per=person).upr_language
        self.lang_id = Language.objects.get(lng_name=lang_name).lng_id
        
        super(FormBuilderSerializer, self).__init__(*args, **kwargs)

    def to_representation(self, instance):
        ret = super().to_representation(instance)       

        ret['fob_name_tag_id'] = instance.fob_name
        ret['fob_description_tag_id'] = instance.fob_description

        try:
            ret['fob_name'] =  LanguageTranslation.objects.filter(
                ltr_tag = instance.fob_name,
                ltr_tag_type = 2,
                ltr_lng = self.lang_id).values_list('ltr_text', flat= True)[0]
        except:
            ret['fob_name'] = instance.fob_name
        
        try:
            ret['fob_description'] =  LanguageTranslation.objects.filter(
                ltr_tag = instance.fob_description,
                ltr_tag_type = 2,
                ltr_lng = self.lang_id).values_list('ltr_text', flat= True)[0]
        except:
            ret['fob_description'] = instance.fob_description

        try:
            ret['fob_category_name'] =  LanguageTranslation.objects.filter(
                ltr_tag = instance.fob_fbc.fbc_name,
                ltr_tag_type = 2,
                ltr_lng = self.lang_id).values_list('ltr_text', flat= True)[0]
        except:
            ret['fob_category_name'] = instance.fob_fbc.fbc_name
        return ret

    def create(self, validated_data):
        request_user = self.context['request'].user.user_per_id_id
        items = validated_data.pop('items')
        form_builder = FormBuilder.objects.create(**validated_data)

        for item in items:
            FormBuilderItem.objects.create(**item,
                                         fbi_created_by_per_id=request_user,
                                         fbi_modified_date=None,
                                         fbi_modified_by_per_id=None,
                                         fbi_fob_id=form_builder.fob_id
                                         )
        return form_builder

    def update(self, instance, validated_data):
        request_user = self.context['request'].user.user_per_id_id
      
        instance.fob_name = validated_data.get('fob_name', instance.fob_name)
        instance.fob_description = validated_data.get('fob_description',
                                                      instance.fob_name)
        instance.fob_fbc = validated_data.get('fob_fbc', instance.fob_fbc)
        instance.fob_enable = validated_data.get('fob_enable', instance.fob_enable)
        instance.fob_modified_by_per_id = request_user
        instance.save()

        return instance


class FormBuilderCategorySerializer(ModelSerializer):
    fbc_created_by_per_id = serializers.IntegerField(read_only=True)
    fbc_modified_by_per_id = serializers.IntegerField(read_only=True)
    fbc_names = serializers.SerializerMethodField()
    fbc_name = serializers.SerializerMethodField()

    url = HyperlinkedIdentityField(
        lookup_field="fbc_slug",
        view_name="form-builder-category-detail",
    )

    
    def __init__(self, *args, **kwargs):
        
        person = kwargs["context"].get("request").user.user_per_id
        
        lang_name = UserProfile.objects.get(upr_per=person).upr_language
        self.lang_id = Language.objects.get(lng_name=lang_name).lng_id
        self.selected_languages = Language.objects.filter(lng_selected = True).values_list("lng_id", flat=True)
        
        super(FormBuilderCategorySerializer, self).__init__(*args, **kwargs)

    def get_fbc_names(self, instance):
        
        fbc_names_queryset = LanguageTranslation.objects.filter(
            ltr_lng_id__in = self.selected_languages,
            ltr_tag = instance.fbc_name,
            ltr_tag_type = 2
        ).values(
            "ltr_lng_id",
            "ltr_text",
            "ltr_translated"
        )
        return fbc_names_queryset

    def get_fbc_name(self, instance):        
        try:
            fbc_names_queryset = LanguageTranslation.objects.filter(
                ltr_lng_id = self.lang_id,
                ltr_tag = instance.fbc_name,
                ltr_tag_type = 2
            ).values_list(           
                "ltr_text", flat=True           
            )[0]
        except:
            fbc_names_queryset = []
        
        return fbc_names_queryset


    class Meta:
        model = FormBuilderCategory
        fields = ('fbc_id', 'url', 'fbc_name',
                  'fbc_slug', 'fbc_created_by_per_id',
                  'fbc_modified_by_per_id', 'fbc_enable',
                  'fbc_names','fbc_tag_type'
                  )
    

# Mobile get list serializer

class GetFormBuilderSubmissionByDateSerializer(ModelSerializer):

    class Meta:
        model = CustomFormMaster
        fields = (
            'cfm_id',
            'cfm_submission_header',
            'cfm_fob'
        )
    
    def __init__(self, *args, **kwargs):
        
        person = kwargs["context"].get("request").user.user_per_id
        
        lang_name = UserProfile.objects.get(upr_per=person).upr_language
        self.lang_id = Language.objects.get(lng_name=lang_name).lng_id
        
        super(GetFormBuilderSubmissionByDateSerializer, self).__init__(*args, **kwargs)

    def to_representation(self, instance):
        ret = super().to_representation(instance)

        try:           
            ret['cfm_fob'] = LanguageTranslation.objects.filter(
                ltr_tag = instance.cfm_fob.fob_name,
                ltr_tag_type = 2,
                ltr_lng = self.lang_id
            ).values_list('ltr_text', flat= True)[0]
            ret['category_name'] = LanguageTranslation.objects.filter(
                ltr_tag = instance.cfm_fob.fob_fbc.fbc_name,
                ltr_tag_type = 2,
                ltr_lng = self.lang_id
            ).values_list('ltr_text', flat= True)[0]
        except FormBuilder.DoesNotExist:
            ret['cfm_fob'] = None
        except FormBuilderCategory.DoesNotExist:
            ret['category_name'] = None
        
        return ret
