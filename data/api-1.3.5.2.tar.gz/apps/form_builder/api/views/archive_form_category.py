from datetime import datetime
from rest_framework.views import APIView
from rest_framework import status
from rest_framework.response import Response

from apps.form_builder.models import FormBuilderCategory
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.common_utils.views.validate_permission import RolePermission

class ArchiveFormCategory(APIView):

    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value, RolePermission.CanManageCustomForms.value,)

    def delete(self, request, fbc_id):
        try:
            self.person_instance = self.request.user.user_per_id

            fbc_instance = FormBuilderCategory.objects.get(pk=fbc_id)

            fbc_instance.fbc_enable = False
            fbc_instance.fbc_modified_by_per = self.person_instance
            fbc_instance.fbc_modified_date = datetime.now()
            
            fbc_instance.save()
            
            return Response({"Message": "Successfully archived form category."}, status= status.HTTP_200_OK)
        except Exception as e:
            return Response({"Message": "Failed to archive form category. {e}"}, status= status.HTTP_400_BAD_REQUEST)

