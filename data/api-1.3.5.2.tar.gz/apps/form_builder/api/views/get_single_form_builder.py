from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status


from apps.common_utils.views.validate_permission import RolePermission
from apps.form_builder.api.serializers.serializers import SingleFormBuilderSerializer
from apps.form_builder.models import FormBuilder
from apps.language.models import LanguageTranslation,Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile

class GetSingleFormBuilder(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value, RolePermission.CanManageCustomForms.value,)

    def post(self, request, fob_slug):

        person = self.request.user.user_per_id_id
        user_language = UserProfile.objects.get(upr_per = person).upr_language
        lang_id = Language.objects.get(lng_name = user_language)

        try:
            queryset = FormBuilder.objects.get(fob_slug=fob_slug)
        except FormBuilder.DoesNotExist:
            return Response("FormBuilder does not exist.", status = status.HTTP_400_BAD_REQUEST)

        serializer_class = SingleFormBuilderSerializer(queryset,context={'request': request})

       
        # loading the languages 
        all_language_trans = LanguageTranslation.objects.all() 
        
        final_queryset = serializer_class.data

        fob_name_tag_id = [serializer_class.data['fob_name']]
        fob_names_lang = all_language_trans.filter(ltr_tag__in=fob_name_tag_id, ltr_tag_type=2).values('ltr_lng_id','ltr_text', 'ltr_translated')
        fob_descriptions_tag_id = [serializer_class.data['fob_description']]
        fob_descriptions_lang = all_language_trans.filter(ltr_tag__in=fob_descriptions_tag_id, ltr_tag_type=2).values('ltr_lng_id','ltr_text', 'ltr_translated')
        final_queryset["fob_descriptions"] = fob_descriptions_lang
        final_queryset["fob_names"] = fob_names_lang
        try:
            final_queryset["fob_name"] = all_language_trans.filter(ltr_tag__in=fob_name_tag_id, ltr_tag_type=2).values_list('ltr_text', flat= True)[0]
        except:
            final_queryset["fob_name"] = fob_name_tag_id
        try:
            final_queryset["fob_description"] = all_language_trans.filter(ltr_tag__in=fob_descriptions_tag_id, ltr_tag_type=2).values_list('ltr_text', flat= True)[0]
        except:
            final_queryset["fob_description"] = fob_descriptions_tag_id

      
        for dict_itm in final_queryset['items']:

            fbi_field_label = [dict_itm['fbi_field_label']]
            fbi_tag_type = dict_itm['fbi_tag_type']
            try:
                dict_itm['fbi_field_label'] = all_language_trans.filter(ltr_tag__in=fbi_field_label, ltr_tag_type=fbi_tag_type, ltr_lng_id = lang_id).values_list('ltr_text', flat= True)[0]
            except:
                dict_itm['fbi_field_label'] = fbi_field_label

            fbi_field_label_lang = all_language_trans.filter(ltr_tag__in=fbi_field_label, ltr_tag_type=fbi_tag_type).values('ltr_lng_id','ltr_text', 'ltr_translated')
            dict_itm['fbi_field_labels'] = fbi_field_label_lang

            fbi_additional_info_label = dict_itm['fbi_additional_info_label']
            if fbi_additional_info_label:
                fbi_additional_info_tag_type = dict_itm['fbi_additional_info_tag_type']
                try:
                    dict_itm['fbi_additional_info_label'] = all_language_trans.filter(ltr_tag=fbi_additional_info_label, ltr_tag_type=fbi_additional_info_tag_type, ltr_lng_id = lang_id).values_list('ltr_text', flat= True)[0]
                except:
                    dict_itm['fbi_additional_info_label'] = fbi_additional_info_label

                fbi_additional_info_label_lang = all_language_trans.filter(ltr_tag=fbi_additional_info_label, ltr_tag_type=fbi_additional_info_tag_type).values('ltr_lng_id','ltr_text', 'ltr_translated')
                dict_itm['fbi_additional_info_labels'] = fbi_additional_info_label_lang
            else:
                dict_itm['fbi_additional_info_label'] = ''
                dict_itm['fbi_additional_info_labels'] = []

        return Response(final_queryset)
