from apps.common_utils.views.validate_permission import RolePermission
from apps.form_builder.api.serializers.serializers import FormBuilderSerializer
from apps.form_builder.models import FormBuilder, FormBuilderItem
from apps.language.models import LanguageTranslation
from django.db.models import Prefetch, query
from django.db.models import Prefetch
from django.db import connection
import json

from rest_framework.generics import (
    RetrieveUpdateAPIView,
)
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile
from apps.incident_management.api.utlity_function import dictfetchall

class ListFormBuilder(APIView):

    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value,)

    def get(self, request):

        person = self.request.user.user_per_id_id
        user_language = UserProfile.objects.get(upr_per=person).upr_language
        lang_id = Language.objects.get(lng_name=user_language)

        with connection.cursor() as cursor:
            cursor.execute("call get_all_custom_form_info(%s)", (lang_id.lng_id,))
            row = dictfetchall(cursor)

        json_data = json.loads(row[0]['jsontxt'])
        return Response(json_data)
        