from datetime import datetime
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.form_builder.models import FormBuilderItem, FormBuilder
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class UpdateFormBuilderItemSort(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value, RolePermission.CanManageCustomForms.value,)

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        data = request.data.pop("form_builder_item_sort", None)
        # get value to update the Modified Fields from the From End
        update_modified = request.data.pop("updateModified", None)
        incoming_fob_id = request.data.pop("fob_id", None)
        ids = []

        for d in data:
            ids.append(d['fbi_id'])

        data = sorted(data, key=lambda k: k['fbi_id'])

        obj = FormBuilderItem.objects.filter(fbi_id__in=ids).order_by('fbi_id')

        objs = []
        # When we need to assign two variable in the loop please get the queryset in order_by. Otherwise it will
        # give you wrong result.
        for o, d in zip(obj, data):
            o.fbi_sort = d['fbi_sort']
            o.fbi_modified_by_per_id = person_id
            objs.append(o)

        FormBuilderItem.objects.bulk_update(objs, ['fbi_sort'])

        # Update Modified Fields if update_modified is True
        if update_modified is True:
            update_modified_by = FormBuilder.objects.get(fob_id=incoming_fob_id)
            update_modified_by.fob_modified_by_per_id = person_id
            update_modified_by.fob_modified_date = datetime.now()
            update_modified_by.save()

        return Response(data)
