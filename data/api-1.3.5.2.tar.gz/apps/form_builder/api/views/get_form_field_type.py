from rest_framework.response import Response
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.form_builder.api.serializers.serializers import FormFieldTypeSerializer
from apps.form_builder.models import FormFieldType
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class GetFormFieldType(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value,)

    def get(self, request):
        queryset = FormFieldType.objects.all()
        serializer_class = FormFieldTypeSerializer(queryset, context={'request': request}, many=True)

        # Order alphabetically
        data = sorted(serializer_class.data, key=lambda d: (d['fft_category'], d['fft_field_label']))

        return Response(data)
