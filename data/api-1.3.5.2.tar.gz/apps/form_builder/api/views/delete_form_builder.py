from datetime import datetime
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.form_builder.models import FormBuilder, FormBuilderItem
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.sofvie_user_authorization.models import AuthRoleFormMappingSofvie
from apps.target.models import Supervisortargets
from apps.target.api.views.target_comment import addTargetComment

class DeleteFormBuilder(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value, RolePermission.ArchiveSubmissions.value,)

    def post(self, request):
        modified_by = self.request.user.user_per_id_id
        payload_data = request.data
        fob_slug = []

        for i in payload_data:
            fob_slug.append(i)

        FormBuilder.objects.filter(fob_slug__in=fob_slug).update(
            fob_enable=False,
            fob_archived_date=datetime.now(),
            fob_archived_by_per_id=modified_by
        )

        # remove form-access permissions for the deleted custom forms
        AuthRoleFormMappingSofvie.objects.filter(arf_fob__fob_slug__in=fob_slug).update(
            arf_enable=False,
            arf_modified_date=datetime.now(),
            arf_modified_by_per_id_id=modified_by
        )

        # remove the targets that had this Custom Form
        fob_ids = []
        fob_id_query = FormBuilder.objects.filter(fob_slug__in=fob_slug)
        for id in fob_id_query:
            fob_ids.append(id.fob_id)
            
        Supervisortargets.objects.filter(sta_fob__in=fob_ids).update(
            effectiveend=datetime.now(),
            sta_modified_date=datetime.now(),
            sta_modified_by_per=modified_by,
            sta_enable=0
        )
        # add the Comments for the removed targets

        for ids in fob_ids:
            addTargetComment(self, None, ids, modified_by, '1060',  '8696')
            addTargetComment(self, None, ids, modified_by, '3915',  '9477')

        return Response("Content delete successfully")


class DeleteFormBuilderItem(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value, RolePermission.ArchiveSubmissions.value,)

    def post(self, request):
        modified_by = self.request.user.user_per_id_id
        # get value to update the Modified Fields from the From End
        update_modified = request.data.pop("updateModified", None)
        fbi_id = request.data.pop('fbi_id')

        FormBuilderItem.objects.filter(fbi_id=fbi_id).update(
            fbi_enable=False,
            fbi_archived_date=datetime.now(),
            fbi_archived_by_per_id=modified_by
        )

        fbi_fob_id = FormBuilderItem.objects.get(fbi_id=fbi_id).fbi_fob_id
        form_builder_items = FormBuilderItem.objects.filter(fbi_fob_id=fbi_fob_id, fbi_enable=1).values('fbi_id').order_by('fbi_sort')

        count = 1
        for item in form_builder_items:
            FormBuilderItem.objects.filter(fbi_id=item['fbi_id']).update(fbi_sort=count)
            count = count + 1

        # Update Modified Fields if update_modified is True
        if update_modified is True:
            update_modified_by = FormBuilder.objects.get(fob_id=fbi_fob_id)
            update_modified_by.fob_modified_by_per_id = modified_by
            update_modified_by.fob_modified_date = datetime.now()
            update_modified_by.save()

        return Response(f"checklist item - {fbi_id} delete successfully")
