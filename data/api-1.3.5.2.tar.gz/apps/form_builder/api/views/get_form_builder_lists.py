from rest_framework.response import Response
from rest_framework.response import Response
from rest_framework.views import APIView

from django.db.models import Prefetch, F, Subquery, OuterRef, Q

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.reflist.models import RefListDetail, RefListHeader
from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile

from apps.form_builder.models import RefListOther
from apps.custom_list.models import CustomListHeader


class GetFormBuilderLists(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value,)

    def get(self, request):
        person = request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per_id=person).upr_language
        lng_id = Language.objects.get(lng_name=lng_name)

        # Ref Lists
        exclude_rlh_ids = RefListHeader.objects.filter(rlh_enable=1).exclude(rlh_parent_header_rlh_id=None).values(
            "rlh_parent_header_rlh_id"
        ).distinct()

        rlh_queryset = RefListHeader.objects.filter(rlh_parent_header_rlh_id=None, rlh_enable=1).exclude(rlh_id__in=exclude_rlh_ids).values(
            "rlh_id",
            "rlh_display_name"
        )

        rlh_queryset = rlh_queryset.annotate(
            display_name = Subquery(
                LanguageTranslation.objects.filter(ltr_tag=OuterRef('rlh_display_name'), ltr_tag_type=1, ltr_lng=lng_id).values('ltr_text')[:1]
            )
        ).order_by('display_name')

        # Non Ref Lists
        flo_queryset = RefListOther.objects.filter(flo_enable=1).values(
            "flo_id",
            "flo_descirption"
        ).annotate(
            flo_display_name = Subquery(
                LanguageTranslation.objects.filter(ltr_tag=OuterRef('flo_descirption'), ltr_tag_type=1, ltr_lng=lng_id).values('ltr_text')[:1]
            )
        ).values("flo_id", "flo_display_name").order_by('flo_display_name')

        clh_queryset = CustomListHeader.objects.filter(clh_enable=1).values(
            "clh_id",
            "clh_display_name"
        )

        clh_queryset = clh_queryset.annotate(
            display_name = Subquery(
                LanguageTranslation.objects.filter(ltr_tag=OuterRef('clh_display_name'), ltr_tag_type=2, ltr_lng=lng_id).values('ltr_text')[:1]
            )
        ).order_by('display_name')

        list_tran = LanguageTranslation.objects.filter(ltr_tag=1031, ltr_tag_type=1, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
        custom_list_tran = "Custom Lists" #LanguageTranslation.objects.filter(ltr_tag=1031, ltr_tag_type=1, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]

        #list_type 
        # 0 - ref list
        # 1 - other list
        # 2 - custom list

        list_data = []
        for rlh in rlh_queryset:
            list_data.append({
                "id": rlh['rlh_id'],
                "display_name": rlh['display_name'],
                "list_type": 0,
                "list_category": list_tran,
            })

        for flo in flo_queryset:
            list_data.append({
                "id": flo['flo_id'],
                "display_name": flo['flo_display_name'],
                "list_type": 1,
                "list_category": list_tran,
            })

        for clh in clh_queryset:
            list_data.append({
                "id": clh['clh_id'],
                "display_name": clh['display_name'],
                "list_type": 2,
                "list_category": custom_list_tran,
            })        

        # Order alphabetically
        list_data = sorted(list_data, key=lambda d: d['display_name'])

        return Response(list_data)
