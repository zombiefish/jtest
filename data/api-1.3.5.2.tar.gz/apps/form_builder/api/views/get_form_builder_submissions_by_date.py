from rest_framework.response import Response
from django.db.models import Q
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.employee.helper_function_user_visibility import helperEmployeeJobs, helperEmployeeSites
from apps.form_builder.api.serializers.serializers import GetFormBuilderSubmissionByDateSerializer
from apps.form_builder.models import CustomFormMaster
from apps.rmm_ora.api.date_filter_utils import full_date_filter
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.sofvie_user_authorization.models import AuthRoleFormMappingSofvie


class GetFormBuilderSubmissionByDate(APIView):
    
    permission_classes = [SofviePermission]

    def post(self, request):
        person_id = request.user.user_per_id        
        get_sites, data_user_visibility = helperEmployeeSites(self, person_id)
        get_jobs, data_user_visibility = helperEmployeeJobs(self, person_id)

        # check custom forms user can access
        allowed_custom_form_ids = getCustomFormIDs(self, person_id)

        site_list = [site['rld_id'] for site in get_sites]
        job_list = [job['rld_id'] for job in get_jobs]

        start_date = request.data['start_date']
        end_date = request.data['end_date']

        site_filters = []
        job_filters = []
        if data_user_visibility != 'all':
            site_filters = [Q(cfm_submission_header__site__in=site_list)]
            job_filters = [Q(cfm_submission_header__jobnumber__in=job_list)]

        queryset = CustomFormMaster.objects.select_related(
            'cfm_submission_header', 
            'cfm_fob',
            'cfm_fob__fob_fbc'
        ).filter(
            *site_filters,
            *job_filters,
            cfm_submission_header__formsubmissiondate__range=full_date_filter(start_date, end_date),
            cfm_fob_id__in = allowed_custom_form_ids
        )        

        serializer_class = GetFormBuilderSubmissionByDateSerializer(queryset, many=True, context={'request': request})

        return Response(serializer_class.data)


def getCustomFormIDs(self, person_id):
    allowed_form_ids = AuthRoleFormMappingSofvie.objects.prefetch_related(
        'arf_aro__sofvie_auth_user_role_mappings'
    ).filter(
        arf_enable = True,
        arf_fob__isnull = False,
        arf_aro__sofvie_auth_user_role_mappings__aur_user_id__user_per_id = person_id
    ).values_list(
        'arf_fob_id'
    )
    
    return allowed_form_ids
