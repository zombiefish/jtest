from datetime import datetime
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.form_builder.models import FormBuilderItem, FormBuilder
from apps.language.api.views.helper_function_add_translation import helperAddTranslation
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class UpdateFormBuilderItem(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value, RolePermission.CanManageCustomForms.value,)

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        fbi_id = request.data.get("fbi_id", None)
        fbi_fft = request.data.get("fbi_fft", None)
        fbi_list_type_rlh_id = request.data.get("fbi_list_type_rlh_id",None)
        fbi_list_type_clh_id = request.data.get("fbi_list_type_clh_id",None)
        fbi_list_type_flo_id = request.data.get("fbi_list_type_flo_id",None)
        fbi_required = request.data.get("fbi_required")
        fbi_additional_info_labels = request.data.get("fbi_additional_info_labels")
        fbi_additional_info_type = request.data.get("fbi_additional_info_type")
        fbi_additional_info_required = request.data.get("fbi_additional_info_required")

        # get value to update the Modified Fields from the From End
        update_modified = request.data.pop("updateModified", None)
        fbi_field_labels = request.data.pop('fbi_field_labels')
        try:
            queryset = FormBuilderItem.objects.get(fbi_id=fbi_id)
        except FormBuilderItem.DoesNotExist:
            return Response("FormBuilder Item does not exist.")
        queryset.fbi_enable = False
        queryset.save()
        fbi_field_labels = helperAddTranslation(self, fbi_field_labels)
        additional_info_labels = helperAddTranslation(self, fbi_additional_info_labels)
        update_form_builder_item = FormBuilderItem.objects.create(
            fbi_fft_id=fbi_fft,
            fbi_fob_id=queryset.fbi_fob_id,
            fbi_field_label=fbi_field_labels,
            fbi_sort=queryset.fbi_sort,
            fbi_tag_type=2,
            fbi_created_by_per_id=person_id,
            fbi_list_type_rlh_id = fbi_list_type_rlh_id,
            fbi_list_type_clh_id = fbi_list_type_clh_id,
            fbi_list_type_flo_id = fbi_list_type_flo_id,
            fbi_required = fbi_required,
            fbi_additional_info_label = additional_info_labels,
            fbi_additional_info_tag_type = 2,
            fbi_additional_info_type=fbi_additional_info_type,
            fbi_additional_info_required = fbi_additional_info_required,
        )

        # Update Modified Fields if update_modified is True
        if update_modified is True:
            update_modified_by = FormBuilder.objects.get(fob_id=queryset.fbi_fob_id)
            update_modified_by.fob_modified_by_per_id = person_id
            update_modified_by.fob_modified_date = datetime.now()
            update_modified_by.save()

        return Response({"new_form_builder_item_id": update_form_builder_item.fbi_id})