from rest_framework import serializers, status
from rest_framework.generics import (
    RetrieveAPIView, ListCreateAPIView, RetrieveUpdateAPIView,
)
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.form_builder.api.serializers.serializers import FormBuilderCategorySerializer
from apps.form_builder.models import FormBuilderCategory, FormBuilder
from apps.person.models import Person
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.language.api.views.helper_function_add_translation import helperAddTranslation
from django.forms.models import model_to_dict


class DetailFormBuilderCategory(RetrieveUpdateAPIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value, RolePermission.CanManageCustomForms.value,)
    queryset = FormBuilderCategory.objects.all()
    serializer_class = FormBuilderCategorySerializer
    lookup_field = "fbc_slug"

class UpdateFormBuilderCategory(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value, RolePermission.CanManageCustomForms.value,)
    
    def post(self, request, *args, **kwargs):
        modified_by = self.request.user.user_per_id_id
        created_by = request.user.user_per_id_id
        fbc_name = request.data.pop('fbc_name')
        fbc_names = request.data.pop('fbc_names')
        fbc_name = helperAddTranslation(self, fbc_names)
        request.data["fbc_name"] = fbc_name
        request.data["fbc_tag_type"] = 2
        request.data["fbc_created_by_per_id"] = created_by
        queryset = FormBuilderCategory.objects.filter(fbc_id=request.data["fbc_id"]).update(
            fbc_modified_by_per_id = modified_by,
            fbc_enable = False
        )
        old_fbc_id = request.data.pop("fbc_id")
        queryset = FormBuilderCategory.objects.create(**request.data)
        chcklist_queryset = FormBuilder.objects.filter(fob_fbc_id=old_fbc_id).update(fob_fbc_id=queryset.fbc_id)
        return Response({"message": "Record Updated Successfully"})

class ListFormBuilderCategory(ListCreateAPIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value,)

    queryset = FormBuilderCategory.objects.filter(fbc_enable=True).order_by('fbc_name')
    serializer_class = FormBuilderCategorySerializer

    def post(self, request, *args, **kwargs):

        sofviePermission = SofviePermission()
        self.permission_attrs = (RolePermission.CanManageCustomForms.value,)

        CanManageCustomForms = sofviePermission.has_permission(request,self)

        if CanManageCustomForms:
            created_by = request.user.user_per_id_id
            fbc_names = request.data.pop("fbc_names")
            fbc_name = helperAddTranslation(self, fbc_names)
            request.data["fbc_name"] = fbc_name
            request.data["fbc_tag_type"] = 2
            request.data["fbc_created_by_per_id"] = created_by
            queryset = FormBuilderCategory.objects.create(**request.data)
            Output = model_to_dict(queryset)
            return Response({"Output":Output, "Status":status.HTTP_201_CREATED})
        return Response({"message": "You don't have permission to create checklist category"}, status=status.HTTP_403_FORBIDDEN)

        
    
