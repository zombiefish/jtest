from datetime import datetime
from django.db import transaction
from django.db.models.aggregates import Max
from django.forms.models import model_to_dict
from rest_framework.response import Response
from rest_framework.status import HTTP_201_CREATED
from rest_framework.views import APIView

from apps.form_builder.models import FormBuilder, FormBuilderItem
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.common_utils.views.validate_permission import RolePermission

from apps.language.api.views.helper_function_add_translation import helperAddTranslation
from apps.sofvie_user_authorization.models import AuthRoleFormMappingSofvie

class CreateFormBuilder(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value, RolePermission.CanManageCustomForms.value,)

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        created_by = self.request.user.user_per_id_id
        form_category_id = request.data.pop('form_category_id')
        form_category_type = request.data.pop('form_category_type')
        fob_names = request.data.pop('fob_names')
        fob_descriptions = request.data.pop('fob_descriptions')
        fob_name = helperAddTranslation(self, fob_names)
        fob_description = helperAddTranslation(self, fob_descriptions)

        fob_fca_id = None
        fob_fbc_id = None
        if form_category_type == 'Pre-Defined-Categories':
            fob_fca_id = form_category_id
        elif form_category_type == 'Custom-Categories':
            fob_fbc_id = form_category_id

        form_builder_obj = FormBuilder.objects.create(
            fob_fbc_id=fob_fbc_id,
            fob_fca_id = fob_fca_id,
            fob_name=fob_name,
            fob_tag_type=2,
            fob_description=fob_description,
            fob_created_by_per_id=created_by,
            fob_modified_date=None
        )

        # add form-access permission for ADMIN in AuthRoleFormMappingSofvie
        AuthRoleFormMappingSofvie.objects.create(
            arf_aro_id = 8,
            arf_fob = form_builder_obj,
            arf_created_date = datetime.now(),
            arf_created_by_per_id_id = created_by,
        )

        Output = model_to_dict(form_builder_obj)
        Output["fob_slug"] = FormBuilder.objects.get(fob_id=Output['fob_id']).fob_slug
        return Response({"Output": Output, "Status": HTTP_201_CREATED})   


class CreateFormBuilderItem(APIView):
        
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value, RolePermission.CanManageCustomForms.value,)

    def post(self, request, *args, **kwargs):
        created_by = self.request.user.user_per_id_id
        # get value to update the Modified Fields from the From End
        update_modified = request.data.pop("updateModified", None)
        fbi_fob_id = request.data.pop('fbi_fob_id')
        fbi_fft = request.data.pop('fbi_fft')

        field_label = request.data.pop('fbi_field_labels')
        field_label_tag = helperAddTranslation(self, field_label)
        request.data["fbi_field_label"] = field_label

        fbi_list_type_rlh = request.data.pop('fbi_list_type_rlh_id')
        fbi_list_type_clh_id = request.data.pop('fbi_list_type_clh_id')
        fbi_list_type_flo_id = request.data.pop('fbi_list_type_flo_id')
        fbi_required = request.data.pop('fbi_required')
        fbi_additional_info_required = request.data.pop('fbi_additional_info_required')

        fbi_additional_info_type = request.data.pop('fbi_additional_info_type')
        additional_labels = request.data.pop('fbi_additional_info_labels')

        additional_labels_tag = helperAddTranslation(self, additional_labels)

        dict_fbi = FormBuilderItem.objects.filter(fbi_fob_id=fbi_fob_id, fbi_enable=1)
        max_fbi_sort = dict_fbi.aggregate(Max('fbi_sort'))
        if max_fbi_sort['fbi_sort__max'] is None:
            max_fbi_sort['fbi_sort__max'] = 0
        fbi_sort = max_fbi_sort['fbi_sort__max'] + 1
        FormBuilderItem.objects.create(
            fbi_fft_id = fbi_fft,
            fbi_fob_id = fbi_fob_id,
            fbi_sort=fbi_sort,
            fbi_field_label=field_label_tag,
            fbi_created_by_per_id=created_by,
            fbi_modified_date=None,
            fbi_tag_type=2,
            fbi_additional_info_label = additional_labels_tag,
            fbi_additional_info_tag_type=2,
            fbi_list_type_rlh_id = fbi_list_type_rlh,
            fbi_list_type_clh_id = fbi_list_type_clh_id,
            fbi_list_type_flo_id = fbi_list_type_flo_id,
            fbi_required=fbi_required,
            fbi_additional_info_required=fbi_additional_info_required,
            fbi_additional_info_type=fbi_additional_info_type,
        )
        # Update Modified Fields if update_modified is True
        if update_modified is True:
            update_modified_by = FormBuilder.objects.get(fob_id=fbi_fob_id)
            update_modified_by.fob_modified_by_per_id = created_by
            update_modified_by.fob_modified_date = datetime.now()
            update_modified_by.save()

        return Response({"Status": HTTP_201_CREATED})

