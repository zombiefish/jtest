from datetime import datetime
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status

from apps.common_utils.views.validate_permission import RolePermission
from apps.form_builder.models import FormBuilder
from apps.language.api.views.helper_function_add_translation import helperAddTranslation
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class UpdateFormBuilder(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewCustomForms.value, RolePermission.CanManageCustomForms.value,)

    def post(self, request, fob_slug):
        person_id = self.request.user.user_per_id_id
        try:
            fob_fbc = request.data['fob_fbc']
            fob_names = request.data.pop('fob_names')
            fob_descriptions = request.data.pop('fob_descriptions')

            form_category_id = request.data.pop('form_category_id')
            form_category_type = request.data.pop('form_category_type')

            fob_fca_id = None
            fob_fbc_id = None
            if form_category_type == 'Pre-Defined-Categories':
                fob_fca_id = form_category_id
            elif form_category_type == 'Custom-Categories':
                fob_fbc_id = form_category_id

            existing_form_builder = FormBuilder.objects.get(fob_slug=fob_slug)

            fob_names_tag = helperAddTranslation(self, fob_names)
            fob_descriptions_tag = helperAddTranslation(self, fob_descriptions)

            FormBuilder.objects.filter(
                fob_enable = True,
                fob_id = existing_form_builder.fob_id
            ).update(
                fob_fbc_id = fob_fbc_id,
                fob_fca_id = fob_fca_id,
                fob_name = fob_names_tag,
                fob_slug = fob_names_tag,
                fob_description = fob_descriptions_tag,
                fob_modified_by_per_id=person_id,
                fob_modified_date=datetime.now()
            )

            new_slug = FormBuilder.objects.get(pk=existing_form_builder.fob_id).fob_slug

            return Response({"new_slug": new_slug}, status= status.HTTP_200_OK)
        except Exception as e:
            return Response({"message": f"Failed to update form builder.\n {e}"}, status=status.HTTP_400_BAD_REQUEST)

        
