from django.urls import path

from apps.form_builder.api.views.archive_form_category import ArchiveFormCategory
from apps.form_builder.api.views.create_form_builder import CreateFormBuilder, CreateFormBuilderItem
from apps.form_builder.api.views.delete_form_builder import DeleteFormBuilder, DeleteFormBuilderItem
from apps.form_builder.api.views.get_form_builder_submissions_by_date import GetFormBuilderSubmissionByDate
from apps.form_builder.api.views.get_form_field_type import GetFormFieldType
from apps.form_builder.api.views.get_single_form_builder import GetSingleFormBuilder
from apps.form_builder.api.views.list_form_builder import ListFormBuilder
from apps.form_builder.api.views.list_create_form_builder_category import DetailFormBuilderCategory, UpdateFormBuilderCategory, ListFormBuilderCategory

from apps.form_builder.api.views.update_form_builder import UpdateFormBuilder
from apps.form_builder.api.views.update_form_builder_item import UpdateFormBuilderItem
from apps.form_builder.api.views.update_form_builder_item_sort import UpdateFormBuilderItemSort

from apps.form_builder.api.views.get_form_builder_lists import GetFormBuilderLists

urlpatterns = [
    path("list-create-form-builder-category/", ListFormBuilderCategory.as_view(), name="form-builder-category-list"),

    path("update-form-builder-category/<str:fbc_slug>/", DetailFormBuilderCategory.as_view(), name="form-builder-category-detail"),
    path("update-form-builder-category/", UpdateFormBuilderCategory.as_view(), name="update-form-builder-category"),
    path("list-form-builder/", ListFormBuilder.as_view(), name="form-builder-list"),
    path("get-form-field-type/", GetFormFieldType.as_view(), name="form-field-type-list"),
    path("create-form-builder/", CreateFormBuilder.as_view(), name="create-form-builder-list"),
    path("get-single-form-builder/<str:fob_slug>/", GetSingleFormBuilder.as_view(), name="single-form-builder"),
    path("update-form-builder/<str:fob_slug>/", UpdateFormBuilder.as_view(), name="update-form-builder"),
    path("update-form-builder-item/", UpdateFormBuilderItem.as_view()),
    path("update-form-builder-item-sort/", UpdateFormBuilderItemSort.as_view()),

    path("delete-form-builder/", DeleteFormBuilder.as_view(), name="delete-form-builder"),
    path("get-form-builder-submission-by-date/", GetFormBuilderSubmissionByDate.as_view(), name="get-form-builder-submission-by-date"),

    path("create-form-builder-item/", CreateFormBuilderItem.as_view(), name="create-form-builder-list"),
    path("delete-form-builder-item/", DeleteFormBuilderItem.as_view(), name="delete-form-builder-item"),

    path("get-form-builder-lists/", GetFormBuilderLists.as_view()),
    path("archive-form-category/<int:fbc_id>/", ArchiveFormCategory.as_view()),

]