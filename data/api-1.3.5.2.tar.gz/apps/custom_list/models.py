from django.db import models

from apps.person.models import Person
from apps.common_utils.views.sofvieModelFields import SofvieCharField, SofvieIntegerField, SofvieTextField


class CustomListHeader(models.Model):
    clh_id = models.AutoField(primary_key=True)
    clh_display_name = SofvieIntegerField(blank=True, null=True)
    clh_description = SofvieIntegerField(blank=True, null=True)
    clh_created_date = models.DateTimeField(blank=True, null=True)
    clh_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='clh_created_by_per')
    clh_modified_date = models.DateTimeField(blank=True, null=True)
    clh_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='clh_modified_by_per')
    clh_enable = models.BooleanField(default=True)
    clh_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'custom_list_header'

class CustomListDetail(models.Model):
    cld_id = models.AutoField(primary_key=True)
    cld_clh = models.ForeignKey(CustomListHeader, models.DO_NOTHING, 
                                            blank=True, null=True,
                                            related_name='cld_clh')
    cld_name = SofvieIntegerField(blank=True, null=True)
    cld_created_date = models.DateTimeField(blank=True, null=True)
    cld_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='cld_created_by_per')
    cld_modified_date = models.DateTimeField(blank=True, null=True)
    cld_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='cld_modified_by_per')
    cld_enable = models.BooleanField(default=True)
    cld_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'custom_list_detail'