from django.apps import AppConfig


class CustomListConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.custom_list'
