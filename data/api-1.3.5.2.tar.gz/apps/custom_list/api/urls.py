from django.urls import path

from apps.custom_list.api.views.get_custom_lists import GetCustomLists
from apps.custom_list.api.views.get_custom_list_header import GetCustomListHeader
from apps.custom_list.api.views.get_custom_list_detail import GetCustomListDetail
from apps.custom_list.api.views.create_custom_list_header import CreateCustomListHeader
from apps.custom_list.api.views.create_custom_list_detail import CreateCustomListDetail
from apps.custom_list.api.views.update_custom_list_header import UpdateCustomListHeader
from apps.custom_list.api.views.update_custom_list_detail import UpdateCustomListDetail
from apps.custom_list.api.views.check_if_custom_list_is_being_used import CheckIfCustomListIsBeingUsed
from apps.custom_list.api.views.archive_custom_lists import ArchiveCustomLists
from apps.custom_list.api.views.remove_custom_list_detail import RemoveCustomListDetail

urlpatterns = [
    path("get-custom-lists/", GetCustomLists.as_view(), name="get-custom-lists"),
    path("get-custom-list-header/", GetCustomListHeader.as_view(), name="get-custom-list-header"),
    path("get-custom-list-detail/", GetCustomListDetail.as_view(), name="get-custom-list-detail"),
    path("create-custom-list-header/", CreateCustomListHeader.as_view(), name="create-custom-list-header"),
    path("create-custom-list-detail/", CreateCustomListDetail.as_view(), name="create-custom-list-detail"),
    path("update-custom-list-header/", UpdateCustomListHeader.as_view(), name="update-custom-list-header"),
    path("update-custom-list-detail/", UpdateCustomListDetail.as_view(), name="update-custom-list-header"),
    path("check-if-custom-list-is-being-used/", CheckIfCustomListIsBeingUsed.as_view(), name="check-if-custom-list-is-being-used"),
    path("archive-custom-lists/", ArchiveCustomLists.as_view(), name="archive-custom-lists"),
    path("remove-custom-list-detail/", RemoveCustomListDetail.as_view(), name="remove-custom-list-detail"),
]