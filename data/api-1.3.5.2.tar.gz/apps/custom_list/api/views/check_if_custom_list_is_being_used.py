from pickle import TRUE
from rest_framework.response import Response
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status

from django.db.models import Prefetch, F, Subquery, OuterRef, Q, Value, CharField, Case, When
from django.db.models.functions import Concat

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.custom_list.models import CustomListHeader, CustomListDetail
from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile

from apps.form_builder.models import FormBuilderItem

class CheckIfCustomListIsBeingUsed(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.ArchiveSubmissions.value,)

    def post(self, request):

        person = self.request.user.user_per_id
        lng_name = UserProfile.objects.get(upr_per_id= person).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)

        try:
            clh_ids = request.data['clh_ids']
        except:
            clh_ids = None
        
        try:
            cld_id = request.data['cld_id']
        except:
            cld_id = None

        data = None

        if clh_ids:
            data = FormBuilderItem.objects.filter(fbi_list_type_clh__in=clh_ids, fbi_enable=True).annotate(
                custom_form_name = Subquery(LanguageTranslation.objects.filter(ltr_tag=OuterRef('fbi_fob__fob_name'), ltr_tag_type=2, ltr_lng=lng_id).values('ltr_text')[:1])
            ).values_list("custom_form_name", flat=True).distinct().order_by()

            if data:
                return Response({"custom_form_names": data}, status=status.HTTP_200_OK)
            else:
                return Response("Custom Lists Not Being Used", status=status.HTTP_200_OK)
        elif cld_id:

            clh_id = CustomListDetail.objects.get(cld_id=cld_id, cld_enable=True).cld_clh_id

            data = FormBuilderItem.objects.filter(fbi_list_type_clh=clh_id, fbi_enable=True).annotate(
                custom_form_name = Subquery(LanguageTranslation.objects.filter(ltr_tag=OuterRef('fbi_fob__fob_name'), ltr_tag_type=2, ltr_lng=lng_id).values('ltr_text')[:1])
            ).values_list("custom_form_name", flat=True).distinct().order_by()

            if data:
                return Response({"custom_form_names": data}, status=status.HTTP_200_OK)
            else:
                return Response("Custom List Detail Not Being Used", status=status.HTTP_200_OK)

        return Response("Invalid payload", status=status.HTTP_400_BAD_REQUEST)

        