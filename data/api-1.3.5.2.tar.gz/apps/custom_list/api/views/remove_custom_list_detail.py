from datetime import datetime
from rest_framework.response import Response
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status

from django.db.models import Prefetch, F, Subquery, OuterRef, Q, Value, CharField, Case, When
from django.db.models.functions import Concat

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.custom_list.models import CustomListHeader, CustomListDetail
from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile

from apps.form_builder.models import FormBuilderItem

class RemoveCustomListDetail(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.ArchiveSubmissions.value,)

    def post(self, request):

        person = self.request.user.user_per_id

        cld_id = request.data['cld_id']

        if cld_id:
            CustomListDetail.objects.filter(cld_id=cld_id, cld_enable=True).update(
                cld_enable = False,
                cld_modified_date = datetime.now(),
                cld_modified_by_per = person
            )

            return Response("Custom List Detail Deleted Successfully", status=status.HTTP_200_OK)

        return Response("Invalid payload", status=status.HTTP_400_BAD_REQUEST)

        