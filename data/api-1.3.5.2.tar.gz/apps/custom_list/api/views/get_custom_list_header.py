from rest_framework.response import Response
from rest_framework.response import Response
from rest_framework.views import APIView

from django.db.models import Prefetch, F, Subquery, OuterRef, Q

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.custom_list.models import CustomListHeader
from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile

class GetCustomListHeader(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageCustomLists.value,)

    def post(self, request):

        clh_id = request.data['clh_id']
        
        data = CustomListHeader.objects.filter(clh_id=clh_id, clh_enable=True).values(
            'clh_id',
            'clh_display_name',
            'clh_description'
        ).first()
        
        data['clh_display_names'] = LanguageTranslation.objects.filter(
            ltr_tag = data['clh_display_name'],
            ltr_tag_type = 2
        ).values(
            'ltr_lng_id',
            'ltr_text',
            'ltr_translated'
        )

        data['clh_descriptions'] = LanguageTranslation.objects.filter(
            ltr_tag = data['clh_description'],
            ltr_tag_type = 2
        ).values(
            'ltr_lng_id',
            'ltr_text',
            'ltr_translated'
        )

        del data['clh_display_name']
        del data['clh_description']

        return Response(data)