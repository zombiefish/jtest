from rest_framework.response import Response
from rest_framework.response import Response
from rest_framework.views import APIView

from django.db.models import Prefetch, F, Subquery, OuterRef, Q

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.custom_list.models import CustomListDetail
from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile

class GetCustomListDetail(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageCustomLists.value,)

    def post(self, request):

        cld_clh_id = request.data['cld_clh_id']
        
        data = CustomListDetail.objects.filter(cld_clh_id=cld_clh_id, cld_enable=True).values(
            'cld_id',
            'cld_name',
        )
        
        for item in data:
            item['cld_names'] = LanguageTranslation.objects.filter(
                ltr_tag = item['cld_name'],
                ltr_tag_type = 2
            ).values(
                'ltr_lng_id',
                'ltr_text',
                'ltr_translated'
            )

            del item['cld_name']

        return Response(data)