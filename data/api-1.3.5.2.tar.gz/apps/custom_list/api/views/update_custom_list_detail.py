from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.custom_list.models import CustomListDetail, CustomListHeader
from apps.custom_list.api.views.create_custom_list_detail import add_custom_list_detail

from datetime import datetime

class UpdateCustomListDetail(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageCustomLists.value,)

    def post(self, request):

        person = self.request.user.user_per_id
        payloadData = request.data

        old_cld_id = payloadData.pop('cld_id')


        soft_delete = CustomListDetail.objects.filter(cld_id = old_cld_id).update(cld_enable = 0, cld_modified_date = datetime.now(), cld_modified_by_per = person)            

        originalCreatedDetail = CustomListDetail.objects.filter(cld_id = old_cld_id).values('cld_clh','cld_created_by_per', 'cld_created_date').first()
        originalCreatedHeader = CustomListHeader.objects.filter(clh_id = originalCreatedDetail['cld_clh']).values('clh_id','clh_created_by_per', 'clh_created_date').first()
        payloadData["cld_clh_id"]=originalCreatedDetail['cld_clh']

        # add new list detail
        addCustomListD = add_custom_list_detail(self, payloadData)
        new_cld_id = addCustomListD.cld_id

        # update header created & modified
        CustomListHeader.objects.filter(clh_id = originalCreatedHeader['clh_id']).update(
            clh_created_by_per = originalCreatedHeader['clh_created_by_per'],
            clh_created_date = originalCreatedHeader['clh_created_date'], 
            clh_modified_by_per = person, 
            clh_modified_date = datetime.now()
        )

        # update detail : header id & modified information
        CustomListDetail.objects.filter(cld_id = new_cld_id).update(
            cld_id = new_cld_id,
            cld_created_by_per = originalCreatedDetail['cld_created_by_per'],
            cld_created_date =  originalCreatedDetail['cld_created_date'],
            cld_modified_by_per = person, 
            cld_modified_date = datetime.now()
        )


        return Response({"cld_id": new_cld_id})
