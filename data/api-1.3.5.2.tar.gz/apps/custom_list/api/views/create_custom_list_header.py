from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.custom_list.models import CustomListHeader
from apps.language.api.views.helper_function_add_translation import helperAddTranslation

from datetime import datetime

class CreateCustomListHeader(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageCustomLists.value,)

    def post(self, request):

        person = self.request.user.user_per_id
        payloadData = request.data

        CustomListH = add_custom_list_header(self, payloadData)

        # update header created
        CustomListHeader.objects.filter(clh_id = CustomListH.clh_id).update(
            clh_created_by_per = person,
            clh_created_date =  datetime.now()
        )

        return Response({"clh_id": CustomListH.clh_id})

def add_custom_list_header(self, payloadData):

    clh_names = payloadData.pop('clh_display_names')
    # call helper function to add translation and get tag number
    if clh_names:
        clh_name = helperAddTranslation(self, clh_names)
        payloadData['clh_display_name'] = clh_name # add clh_name tags into payloadData

    # get clh_descriptions
    clh_descriptions = payloadData.pop('clh_descriptions')
    # call helper function to add translation and get tag number
    if clh_descriptions:
        clh_description = helperAddTranslation(self, clh_descriptions)
        payloadData['clh_description'] = clh_description # add rld_description tags into payloadData

    add_clh = CustomListHeader.objects.create(**payloadData)
    return add_clh