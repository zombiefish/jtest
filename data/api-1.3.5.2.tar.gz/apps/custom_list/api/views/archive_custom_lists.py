from datetime import datetime
from rest_framework.response import Response
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status

from django.db.models import Prefetch, F, Subquery, OuterRef, Q, Value, CharField, Case, When
from django.db.models.functions import Concat

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.custom_list.models import CustomListHeader, CustomListDetail
from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile

from apps.form_builder.models import FormBuilderItem

class ArchiveCustomLists(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.ArchiveSubmissions.value,)

    def post(self, request):

        person = self.request.user.user_per_id

        clh_ids = request.data['clh_ids']

        if clh_ids:
            CustomListHeader.objects.filter(clh_id__in=clh_ids, clh_enable=True).update(
                clh_enable = False,
                clh_modified_date = datetime.now(),
                clh_modified_by_per = person
            )

            CustomListDetail.objects.filter(cld_clh_id__in=clh_ids, cld_enable=True).update(
                cld_enable = False,
                cld_modified_date = datetime.now(),
                cld_modified_by_per = person
            )

            FormBuilderItem.objects.filter(fbi_list_type_clh__in=clh_ids, fbi_enable=True).update(
                fbi_enable = False,
                fbi_modified_date = datetime.now(),
                fbi_modified_by_per = person
            )

            return Response("Custom Lists Deleted Successfully", status=status.HTTP_200_OK)

        return Response("Invalid payload", status=status.HTTP_400_BAD_REQUEST)

        