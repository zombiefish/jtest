from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.custom_list.models import CustomListDetail, CustomListHeader
from apps.language.api.views.helper_function_add_translation import helperAddTranslation

from datetime import datetime

class UpdateCustomListHeader(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageCustomLists.value,)

    def post(self, request):

        person = self.request.user.user_per_id
        payloadData = request.data
        clh_names = payloadData.pop('clh_display_names')
        clh_id = payloadData.pop('clh_id')

        # call helper function to add translation and get tag number
        if clh_names:
            clh_name = helperAddTranslation(self, clh_names)
            payloadData['clh_display_name'] = clh_name # add clh_name tags into payloadData

        # get clh_descriptions
        clh_descriptions = payloadData.pop('clh_descriptions')
        # call helper function to add translation and get tag number
        if clh_descriptions:
            clh_description = helperAddTranslation(self, clh_descriptions)
            payloadData['clh_description'] = clh_description # add rld_description tags into payloadData


        # update header created & modified
        CustomListHeader.objects.filter(clh_id=clh_id).update(
            clh_display_name = payloadData['clh_display_name'],
            clh_description = payloadData['clh_description'],
            clh_modified_by_per = person, 
            clh_modified_date = datetime.now()
        )

        # update detail : header id & modified information
        CustomListDetail.objects.filter(cld_clh_id = clh_id).update(
            cld_clh_id = clh_id,
            cld_modified_by_per = person, 
            cld_modified_date = datetime.now()
        )


        return Response({"clh_id": clh_id})
