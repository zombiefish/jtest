from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.custom_list.models import CustomListDetail, CustomListHeader
from apps.language.api.views.helper_function_add_translation import helperAddTranslation

from datetime import datetime

class CreateCustomListDetail(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageCustomLists.value,)

    def post(self, request):

        person = self.request.user.user_per_id
        payloadData = request.data

        CustomListD = add_custom_list_detail(self, payloadData)

        # update detail created
        CustomListDetail.objects.filter(cld_id = CustomListD.cld_id).update(
            cld_created_by_per = person,
            cld_created_date =  datetime.now()
        )

        # update header modified
        CustomListHeader.objects.filter(clh_id = CustomListD.cld_clh_id).update(
            clh_modified_by_per = person, 
            clh_modified_date = datetime.now()
        )

        return Response({"cld_id": CustomListD.cld_id})

def add_custom_list_detail(self, payloadData):
        cld_names = payloadData.pop('cld_names')
        # call helper function to add translation and get tag number
        if cld_names:
            cld_name = helperAddTranslation(self, cld_names)
            payloadData['cld_name'] = cld_name # add cld_name tags into payloadData

        add_cld = CustomListDetail.objects.create(**payloadData)
        return add_cld

