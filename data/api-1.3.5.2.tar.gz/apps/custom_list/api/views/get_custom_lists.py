from rest_framework.response import Response
from rest_framework.response import Response
from rest_framework.views import APIView

from django.db.models import Prefetch, F, Subquery, OuterRef, Q, Value, CharField, Case, When
from django.db.models.functions import Concat

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.custom_list.models import CustomListHeader
from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile

class GetCustomLists(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageBasicLists.value,)

    def get(self, request):

        person = self.request.user.user_per_id
        lng_name = UserProfile.objects.get(upr_per_id= person).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)   
        
        data = CustomListHeader.objects.filter(clh_enable=True).annotate(
            clh_display_name_tag = F('clh_display_name'),
            clh_description_tag = F('clh_description'),
        ).values(
            'clh_display_name_tag',
            'clh_description_tag',
        ).annotate(
            clh_display_name = Subquery(LanguageTranslation.objects.filter(ltr_tag = OuterRef('clh_display_name_tag'), ltr_tag_type = 2, ltr_lng = lng_id).values('ltr_text')[:1]),
            clh_description = Subquery(LanguageTranslation.objects.filter(ltr_tag = OuterRef('clh_description_tag'), ltr_tag_type = 2, ltr_lng = lng_id).values('ltr_text')[:1]),
            clh_created_by_per = Case(When(clh_created_by_per=None, then='clh_created_by_per'), default=Concat('clh_created_by_per__per_last_name', Value(', '), 'clh_created_by_per__per_first_name', output_field = CharField()), output_field = CharField()),
            clh_modified_by_per = Case(When(clh_modified_by_per=None, then='clh_modified_by_per'), default=Concat('clh_modified_by_per__per_last_name', Value(', '), 'clh_modified_by_per__per_first_name', output_field = CharField()), output_field = CharField())
        ).values(
            'clh_id',
            'clh_display_name',
            'clh_description' ,
            'clh_created_date',
            'clh_created_by_per',
            'clh_modified_date',
            'clh_modified_by_per'
        )

        return Response(data)