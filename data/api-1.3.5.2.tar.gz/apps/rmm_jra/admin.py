from django.contrib import admin

# Register your models here.
from apps.rmm_jra.models import *

admin.site.register(RmmJraMaster)
admin.site.register(RmmJraParticipant)
admin.site.register(RmmJraApprover)
admin.site.register(RmmJraGeneralAction)
admin.site.register(RmmJraHazardAction)
admin.site.register(RmmJraStepCategory)
admin.site.register(RmmJraThreat)
admin.site.register(RmmJraTags)
admin.site.register(RmmJraPraThreat)


