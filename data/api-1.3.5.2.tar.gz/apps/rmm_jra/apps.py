from django.apps import AppConfig


class RmmJraConfig(AppConfig):
    name = 'apps.rmm_jra'
