from django.urls import path

from apps.rmm_jra.api.views.jra_get_list import RmmJraGetList
from apps.rmm_jra.api.views.jra_insert import RmmJraInsert
from apps.rmm_jra.api.views.jra_archive import RmmJraArchive
from apps.rmm_jra.api.views.jra_insert_general_action import RmmAddJraGeneralAction
from apps.rmm_jra.api.views.jra_insert_hazard_action import RmmAddJraHazardAction
from apps.rmm_jra.api.views.jra_insert_mobile import InsertJRAMobile
from apps.rmm_jra.api.views.jra_sign import RmmJraSignDocument
from apps.rmm_jra.api.views.jra_get_detail import RmmJraGetDetail
from apps.rmm_jra.api.views.jra_update import RmmJraUpdate
from apps.rmm_jra.api.views.jra_pra_title_list import RmmJraGetPraTitleList
from apps.rmm_jra.api.views.jra_pra_threat_list import RmmJraGetPraThreatList
from apps.rmm_jra.api.views.jra_copy import RmmJraCopy
from apps.rmm_jra.api.views.jra_get_gaha_detail import RmmJraGetGaHaDetail
from apps.rmm_jra.api.views.jra_bluelines import RmmJraBluelines
from apps.rmm_jra.api.views.jra_review import RmmJraReviewAPI
from apps.rmm_jra.api.views.jra_get_active_pra_sites import RmmJraGetActivePraSites

urlpatterns = [
    path('jra-get-list/', RmmJraGetList.as_view()),
    path('jra-insert/', RmmJraInsert.as_view()),
    path('jra-archive/', RmmJraArchive.as_view()),
    path('jra-insert-general-action/', RmmAddJraGeneralAction.as_view()),
    path('jra-insert-hazard-action/', RmmAddJraHazardAction.as_view()),
    path('jra-sign/', RmmJraSignDocument.as_view()),
    path('jra-get-detail/<int:pk>/', RmmJraGetDetail.as_view()),
    path('jra-update/<int:pk>/', RmmJraUpdate.as_view()),
    path('jra-pra-title-list/', RmmJraGetPraTitleList.as_view()),
    # path('jra-pra-threat-list/<int:rmm_pra_id>/', RmmJraGetPraThreatList.as_view()),
    path('jra-pra-threat-list/', RmmJraGetPraThreatList.as_view()),
    path('jra-copy-revision/<int:pk>/<str:mode>/', RmmJraCopy.as_view()),
    path('jra-get-gaha-detail/<int:pk>/', RmmJraGetGaHaDetail.as_view()),
    path('jra-bluelines/', RmmJraBluelines.as_view()),
    path('jra-review/<int:pk>/', RmmJraReviewAPI.as_view()),
    path('jra-get-active-pra-sites/', RmmJraGetActivePraSites.as_view()),
    path('jra-insert-mobile/', InsertJRAMobile.as_view())

] 