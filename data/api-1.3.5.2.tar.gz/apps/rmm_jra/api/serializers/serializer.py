from datetime import datetime

from django.db import transaction, IntegrityError
from django.db.models import Max
from django.db.models import Subquery, OuterRef
from django.db.models import Value, CharField
from django.db.models.functions import Concat
from django.forms import model_to_dict
from rest_framework import serializers
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import SAFE_METHODS
from rest_framework.relations import StringRelatedField
from rest_framework.serializers import ModelSerializer

from apps.dl.models import DocumentLock
from apps.language.models import LanguageTranslation, Language
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.rmm_jra.models import RmmJraMaster, RmmJraParticipant, RmmJraApprover, RmmJraStepCategory, \
    RmmJraThreat, RmmJraTags, RmmJraGeneralAction, RmmJraHazardAction, RmmJraPraThreat
from apps.rmm_pra.models import RmmPraThreat
from apps.user_settings_profile.models import UserProfile


class RmmJraPraThreatSerializer(ModelSerializer):
    class Meta:
        model = RmmJraPraThreat
        fields = (
            "rmm_jpt_id",
            "rmm_jpt_jra",
            "rmm_jpt_pth"
        )


class RmmJraParticipantSerializer(ModelSerializer):
    class Meta:
        model = RmmJraParticipant
        fields = (
            "rmm_jrp_id",
            "rmm_jrp_jra",
            "rmm_jrp_per",
        )


class RmmJraApproverSerializer(ModelSerializer):
    rmm_jap_per = StringRelatedField()

    class Meta:
        model = RmmJraApprover
        fields = (
            "rmm_jap_id",
            "rmm_jap_approved",
            "rmm_jap_per",
        )


class RmmJraTagSerializer(ModelSerializer):
    class Meta:
        model = RmmJraTags
        fields = (
            'rmm_jta_id',
            'rmm_jta_tag_name',
            'tag',
            'rmm_jta_blueline',
            'rmm_jta_jth',
            'rmm_jta_parent_tag_name',
            'rmm_jta_enable'
        )
        extra_kwargs = {
            "rmm_jta_jth": {"read_only": True},
            "rmm_jta_parent_tag_name": {"read_only": True},
            "rmm_jta_id": {"required": False, "allow_null": True, "read_only": False}
        }


class RmmJraThreatSerializer(ModelSerializer):
    control_measures = RmmJraTagSerializer(many=True, write_only=True)
    additional_control_measures = RmmJraTagSerializer(many=True, write_only=True)

    def validate_tag(self, value):
        if getattr(self.context["view"], "action", "") == "update":
            data = []
            for item in value:
                if item.get("rmm_jta_id"):
                    try:
                        # Its for validation tag data aginst existing tag instance.
                        ser = RmmJraTagSerializer(RmmJraTags.objects.get(rmm_jta_id=item["rmm_jta_id"]), data=item, context=self.context, partial=True)
                        ser.is_valid(raise_exception=True)
                        data.append(ser.validated_data)
                    except RmmJraTags.DoesNotExist:
                        raise ValidationError({"tag": f"tag id {item['rmm_jta_id']} {item['tag']} name does not exists"})
                else:
                    # creating the tag upon updating
                    ser = RmmJraTagSerializer(data=item, context=self.context)
                    ser.is_valid(raise_exception=True)
                    data.append(ser.validated_data)
            return data
        else:
            # creating the tag on insert
            ser = RmmJraTagSerializer(data=value, many=True)
            ser.is_valid(raise_exception=True)
            return ser.validated_data

    def validate_control_measures(self, value):
        return self.validate_tag(value)

    def validate_additional_control_measures(self, value):
        return self.validate_tag(value)

    class Meta:
        model = RmmJraThreat
        fields = (
            'rmm_jth_id',
            'rmm_jth_jsc',
            'rmm_jth_threat',
            'rmm_jth_outcome',
            'rmm_jth_severity_category',
            'rmm_jth_likelyhood_preliminary',
            'rmm_jth_severity_preliminary',
            'rmm_jth_preliminary_risk',
            'rmm_jth_risk_alara_preliminary',
            'rmm_jth_likelyhood_residual',
            'rmm_jth_severity_residual',
            'rmm_jth_residual_risk',
            'rmm_jth_risk_alara_residual',
            'rmm_jth_enable',
            # tags
            'control_measures',
            'additional_control_measures'
        )

        extra_kwargs = {
            "rmm_jth_jsc": {"read_only": True},
            "rmm_jth_id": {"required": False, "allow_null": True, "read_only": False},
            "rmm_jth_modified_by_per": {"read_only": True}
        }

    def create_tag(self, tag, parent, instance, person):
        tag["rmm_jta_jth"] = instance
        tag["rmm_jta_created_by_per"] = person
        tag["rmm_jta_parent_tag_name"] = parent
        try:
            self.tag_ser.create(tag)
        except IntegrityError:
            raise ValidationError({"tag": f"tag {tag['tag']} already exists."})

    def create(self, validated_data, *args, **kwargs):
        person = self.context["request"].user.user_per_id
        control_measures = validated_data.pop("control_measures")
        additional_control_measures = validated_data.pop("additional_control_measures")
        tag_ser = RmmJraTagSerializer(context=self.context)

        instance = super(RmmJraThreatSerializer, self).create(validated_data, *args, **kwargs)

        def create_tag(tag, parent):
            tag["rmm_jta_jth"] = instance
            tag["rmm_jta_created_by_per"] = person
            tag["rmm_jta_parent_tag_name"] = parent
            tag_ser.create(tag)

        for tag in control_measures:
            create_tag(tag, "control_measures")
        for tag in additional_control_measures:
            create_tag(tag, "additional_control_measures")
        return instance

    def update(self, instance, validated_data, *args, **kwargs):
        person = self.context["request"].user.user_per_id

        control_measures = validated_data.pop('control_measures')
        additional_control_measures = validated_data.pop('additional_control_measures')

        self.tag_ser = RmmJraTagSerializer(context=self.context)
        instance = super(RmmJraThreatSerializer, self).update(instance, validated_data, *args, **kwargs)

        deleted_tags = []
        for tag in control_measures:
            # tag_ids.append(tag.get("rmm_ota_id", 0))
            if not tag.get("rmm_jta_enable", False) and tag.get("rmm_jta_id"):
                deleted_tags.append(tag["rmm_jta_id"])
            elif not tag.get("rmm_jta_id"):
                self.create_tag(tag, "control_measures", instance, person)
        for tag in additional_control_measures:
            # tag_ids.append(tag.get("rmm_ota_id", 0))
            if not tag.get("rmm_jta_enable", False) and tag.get("rmm_jta_id"):
                deleted_tags.append(tag["rmm_jta_id"])
            elif not tag.get("rmm_jta_id"):
                self.create_tag(tag, "additional_control_measures", instance, person)
        RmmJraTags.objects.filter(rmm_jta_id__in=deleted_tags).update(rmm_jta_enable=False, rmm_jta_modified_by_per=person, rmm_jta_modified_date=datetime.now())


class RmmJraStepCategoriesSerializer(ModelSerializer):
    threats = RmmJraThreatSerializer(many=True)

    class Meta:
        model = RmmJraStepCategory
        fields = (
            'rmm_jsc_id',
            'rmm_jsc_step',
            'rmm_jsc_sort',
            'rmm_jsc_enable',
            'threats'
        )
        extra_kwargs = {
            "rmm_jsc_id": {"required": False, "allow_null": True, "read_only": False},
            "rmm_jsc_modified_by_per": {"read_only": True}
        }

    def create(self, validated_data, *args, **kwargs):
        threats = validated_data.pop("threats")
        person = self.context["request"].user.user_per_id
        instance = super(RmmJraStepCategoriesSerializer, self).create(validated_data, *args, **kwargs)
        for threat in threats:
            threat["rmm_jth_jsc"] = instance
            threat["rmm_jth_created_by_per"] = person
            RmmJraThreatSerializer(context=self.context).create(threat)
        return ("OK")
        return instance

    def update(self, instance, validated_data, *args, **kwargs):
        threats = validated_data.pop("threats")
        person = self.context["request"].user.user_per_id
        instance = super(RmmJraStepCategoriesSerializer, self).update(instance, validated_data, *args, **kwargs)

        deleted_threats = []
        for threat in threats:
            if threat.get("rmm_jth_id"):
                threat["rmm_jth_jsc"] = instance
                threat["rmm_jth_modified_by_per"] = person
                threat["rmm_jth_modified_date"] = datetime.now()
                threat_instance = RmmJraThreat.objects.get(rmm_jth_id=threat["rmm_jth_id"])
                RmmJraThreatSerializer(context=self.context).update(threat_instance, threat)
            elif not threat.get("rmm_jth_enable", True):
                deleted_threats.append(threat["rmm_jth_id"])
            else:
                threat["rmm_jth_jsc"] = instance
                threat["rmm_jth_created_by_per"] = person
                RmmJraThreatSerializer(context=self.context).create(threat)
        RmmJraThreat.objects.filter(rmm_jth_id__in=deleted_threats).update(rmm_jth_enable=False, rmm_jth_modified_by_per=person, rmm_jth_modified_date=datetime.now())
        return instance


class RmmJraMasterSerializer(ModelSerializer):
    # rmm_jra_created_by_per = StringRelatedField()
    rmm_jra_created_by_per = serializers.SerializerMethodField()
    rmm_jra_created_by_per_id = serializers.SerializerMethodField()
    reviewers = serializers.SerializerMethodField()
    dlo_enable = serializers.SerializerMethodField()   

    class Meta:
        model = RmmJraMaster
        fields = (
            "rmm_jra_id",
            "rmm_jra_document_number",
            "rmm_jra_doc_version_number",
            "rmm_jra_title",
            "rmm_jra_scope",
            "rmm_jra_site",
            "rmm_jra_job",
            "rmm_jra_pra",
            "rmm_jra_date",
            "rmm_jra_workplace",
            "rmm_jra_expiry_date",
            "rmm_jra_other_participants",
            "rmm_jra_state",
            "rmm_jra_executive_summary",
            "rmm_jra_created_date",
            "rmm_jra_created_by_per",
            "rmm_jra_created_by_per_id",
            "reviewers",
            "dlo_enable",
        )
        extra_kwargs = {
            "rmm_jra_document_number": {"read_only": True}
        }

    def __init__(self, *args, **kwargs):
        person = kwargs["context"].get("request").user.user_per_id
        lang_name = UserProfile.objects.get(upr_per=person).upr_language
        self.lang_id = Language.objects.get(lng_name=lang_name).lng_id
        self.read_actions = kwargs["context"]['read_actions'] if 'read_actions' in kwargs["context"] else True

        if kwargs["context"].get("request").method in SAFE_METHODS or kwargs["context"].get("read"):
            self.copy_revision = kwargs["context"]['read'] if 'read' in kwargs["context"] else False
            self.fields['approvers'] = serializers.SerializerMethodField('get_approvers')
            self.fields['participants'] = serializers.SerializerMethodField('get_participants')
            self.fields['applicable_line_items'] = serializers.SerializerMethodField('get_applicable_line_items')
            self.fields['rmm_jra_site'] = serializers.SerializerMethodField()
            self.fields['rmm_jra_job'] = serializers.SerializerMethodField()
        else:
            self.fields['approvers'] = serializers.PrimaryKeyRelatedField(many=True, queryset=Person.objects.all())
            self.fields["participants"] = serializers.PrimaryKeyRelatedField(many=True, queryset=Person.objects.all())
            # if field name is not present on model then make it write only
            self.fields['applicable_line_items'] = serializers.PrimaryKeyRelatedField(many=True, queryset=RmmPraThreat.objects.all(), write_only=True)
            self.fields["step_categories"] = RmmJraStepCategoriesSerializer(many=True)

        if getattr(kwargs["context"]['view'], "action", "") == "retrieve":
            self.fields['step_categories'] = serializers.SerializerMethodField()
        
        if self.read_actions:
            self.fields['general_actions'] = serializers.SerializerMethodField()
            self.fields['hazard_actions'] = serializers.SerializerMethodField()
        super(RmmJraMasterSerializer, self).__init__(*args, **kwargs)

    def get_approvers(self, obj):
        return obj.approvers.filter(
            rmm_jap_enable=True
        ).annotate(
            full_name=Concat(
                "rmm_jap_per__per_first_name", Value(" "),
                "rmm_jap_per__per_last_name", output_field=CharField()
            )
        ).values('rmm_jap_id', "full_name", "rmm_jap_per", "rmm_jap_approved_date", "rmm_jap_approved")

    def get_participants(self, obj):
        return obj.participants.filter(rmm_jrp_enable=True).values_list("rmm_jrp_per", flat=True)

    def get_applicable_line_items(self, obj):
        pra_threats = obj.pra_threat.filter(rmm_jpt_enable=True).values_list('rmm_jpt_pth_id', flat=True)
        return pra_threats

    def get_step_categories(self, obj):
        data = []
        for step in obj.step_categories.filter(rmm_jsc_enable=True):
            row = model_to_dict(step)
            row["threats"] = []
            for index, ev in enumerate(step.threats.filter(rmm_jth_enable=True)):
                row["threats"].append(model_to_dict(ev))
                row["threats"][index]["control_measures"] = []
                row["threats"][index]["additional_control_measures"] = []
                for tag in ev.tags.filter(rmm_jta_enable=True):
                    row["threats"][index][tag.rmm_jta_parent_tag_name].append(model_to_dict(tag))
            data.append(row)
        return data

    def get_general_actions(self, obj):
        person = self.context['request'].user.user_per_id
        return obj.get_sga_and_attachments(person)

    def get_hazard_actions(self, obj):
        person = self.context['request'].user.user_per_id
        return obj.get_ha_and_attachments(person)

    def get_reviewers(self, obj):
        get_ref_list = obj.rmm_jre_jra_master.annotate(
            tag=Subquery(RefListDetail.objects.filter(rld_id=OuterRef('rmm_jre_position')).values('rld_name')[:1]),
            tag_type=Subquery(RefListDetail.objects.filter(rld_id=OuterRef('rmm_jre_position')).values('rld_tag_type')[:1])
        ).values()
        get_trans = get_ref_list.annotate(
            rmm_jre_position_name=Subquery(
                LanguageTranslation.objects.filter(
                    ltr_tag=OuterRef('tag'), 
                    ltr_tag_type=OuterRef('tag_type'), 
                    ltr_lng_id=self.lang_id
                ).values('ltr_text')[:1]
            )
        ).values(
            "rmm_jre_per_id",
            "rmm_jre_position_name",
            "rmm_jre_created_date",
        )
        return get_trans

    def get_rmm_jra_created_by_per(self, obj):
        return obj.rmm_jra_created_by_per.full_name

    def get_rmm_jra_created_by_per_id(self, obj):
        return obj.rmm_jra_created_by_per.per_id

    def get_dlo_enable(self, obj):
        doc_lock = DocumentLock.objects.filter(
            dlo_document_id=obj.rmm_jra_id, dlo_dlt_id=2).annotate(
            dlo_person=Concat(
                "dlo_per__per_last_name", Value(", "),
                "dlo_per__per_first_name", output_field=CharField()
            )
        ).values('dlo_document_id', 'dlo_person', 'dlo_enable')
        return doc_lock
    
    """
    below function would return rmm_jra_site_id which is ref list detail id of the site selected
    if request is for AG grid - function returns rld_id if rld_enable = 1 and rld_name translated  if rld_enable = 0 i.e, deleted
    and if rmm is in draft state return None
    if request is for copy/revision, returns rld_id i.e, rmm_jra_site_id
    """
    def get_rmm_jra_site(self, obj):  
        if self.copy_revision == 'copy_revision':
            return  obj.rmm_jra_site_id

        if obj.rmm_jra_site:
            if obj.rmm_jra_site.rld_enable == False and obj.rmm_jra_state == 'draft':
                return None            
            elif obj.rmm_jra_site.rld_enable == False:
                rld_code = ''
                if obj.rmm_jra_site.rld_code:
                    rld_code = '('+ obj.rmm_jra_site.rld_code +') '
                return rld_code + LanguageTranslation.objects.get(
                    ltr_lng_id = self.lang_id,
                    ltr_tag = obj.rmm_jra_site.rld_name,
                    ltr_tag_type = obj.rmm_jra_site.rld_tag_type
                ).ltr_text
            else:
                return obj.rmm_jra_site_id
        return None
    """
    below function would return rmm_jra_job_id which is ref list detail id of the site selected
    if request is for AG grid - function returns rld_id if rld_enable = 1 and rld_name translated  if rld_enable = 0 i.e, deleted
    and if rmm is in draft state return None
    if request is for copy/revision, returns rld_id i.e, rmm_jra_job_id
    """
    def get_rmm_jra_job(self, obj):
        if self.copy_revision == 'copy_revision':
            return  obj.rmm_jra_job_id
        if obj.rmm_jra_job:
            if obj.rmm_jra_job.rld_enable == False and obj.rmm_jra_state == 'draft':
                return None            
            elif obj.rmm_jra_job.rld_enable == False:
                return obj.rmm_jra_job.rld_code
            else:
                return obj.rmm_jra_job_id
        return None
    

    @transaction.atomic
    def create(self, validated_data, *args, **kwargs):
        request_user = self.context['request'].user
        person_id = request_user.user_per_id
        instance = create_jra(self, validated_data, person_id, self.context['request'], *args, **kwargs)

        return instance

    @transaction.atomic
    def update(self, instance, validated_data, *args, **kwargs):
        person = self.context['request'].user.user_per_id
        participants = validated_data.pop('participants')
        approvers = validated_data.pop('approvers')
        pra_threats = validated_data.pop('applicable_line_items')
        step_categories = validated_data.pop('step_categories')

        validated_data['rmm_jra_modified_by_per'] = person
        validated_data['rmm_jra_modified_date'] = datetime.now()

        instance = super(RmmJraMasterSerializer, self).update(instance, validated_data, *args, **kwargs)

        participant_mod_kwargs = {
            "rmm_jrp_modified_date": None
        }
        approver_mod_kwargs = {
            "rmm_jap_submitted_date": None
        }
        pra_threats_mod_kwargs = {
            'rmm_jpt_modified_date': None
        }
        if instance.rmm_jra_state == 'active':
            participant_mod_kwargs = {
                "rmm_jrp_submitted_by_per": person
            }
            approver_mod_kwargs = {
                "rmm_jap_submitted_by_per": person
            }
            pra_threats_mod_kwargs = {
                'rmm_jpt_modified_date': person
            }

        # ---------updating participants--------

        # collecting the existing participant ID
        participants_ids = [p.per_id for p in participants]
        # filtering the participant object base on enable = True as a list of IDS
        extisiting_participants = instance.participants.filter(rmm_jrp_enable=True).values_list("rmm_jrp_per", flat=True)
        # looping to track the deleted participant
        deleted_participants = [p for p in extisiting_participants if p not in participants_ids]
        new_participants = [p for p in participants_ids if p not in extisiting_participants]

        RmmJraParticipant.objects.filter(rmm_jrp_per_id__in=deleted_participants).update(rmm_jrp_enable=False, rmm_jrp_modified_date=datetime.now(), rmm_jrp_modified_by_per_id=person)
        RmmJraParticipant.objects.bulk_create([RmmJraParticipant(rmm_jrp_jra=instance, rmm_jrp_per_id=p, rmm_jrp_created_by_per=person,
                                                                 **participant_mod_kwargs) for p in new_participants])

        # ----------updating approvers------------

        approvers_ids = [a.per_id for a in approvers]
        extisiting_approvers = instance.approvers.filter(rmm_jap_enable=True).values_list("rmm_jap_per", flat=True)
        deleted_approvers = [p for p in extisiting_approvers if p not in approvers_ids]
        new_approvers = [p for p in approvers_ids if p not in extisiting_approvers]

        RmmJraApprover.objects.filter(rmm_jap_per_id__in=deleted_approvers).update(rmm_jap_enable=False, rmm_jap_modified_date=datetime.now(), rmm_jap_modified_by_per=person)
        RmmJraApprover.objects.bulk_create([RmmJraApprover(rmm_jap_jra=instance, rmm_jap_per_id=a, rmm_jap_created_by_per=person,
                                                           **approver_mod_kwargs) for a in new_approvers])

        # -----------updating applicable line items / pra threats in jra-------------

        pra_threat_ids = []

        for each in pra_threats:
            if isinstance(each, RmmPraThreat):
                pra_threat_ids.append(each.rmm_pth_id)
            else:
                pra_threat_ids.append(each)

        existing_pts = instance.pra_threat.filter(rmm_jpt_enable=True).values_list('rmm_jpt_pth_id', flat=True)
        deleted_pts = [pt for pt in existing_pts if pt not in pra_threat_ids]
        new_pts = [pt for pt in pra_threat_ids if pt not in existing_pts]

        RmmJraPraThreat.objects.filter(rmm_jpt_pth_id__in=deleted_pts).update(rmm_jpt_enable=False,
                                                                              rmm_jpt_modified_date=datetime.now(),
                                                                              rmm_jpt_modified_by_per=person)

        RmmJraPraThreat.objects.bulk_create([RmmJraPraThreat(rmm_jpt_jra=instance, rmm_jpt_pth_id=pt, rmm_jpt_created_by_per=person, **pra_threats_mod_kwargs) for pt in new_pts])

        # -----------updating element categories ---------

        deleted_step_categories = []
        for step_category in step_categories:
            if not step_category.get("rmm_jsc_enable", False):
                deleted_step_categories.append(step_category["rmm_jsc_id"])
            elif step_category.get("rmm_jsc_id", None):
                step_category["rmm_jsc_modified_by_per"] = person
                step_category["rmm_jsc_modified_date"] = datetime.now()
                step_category_instance = RmmJraStepCategory.objects.get(rmm_jsc_id=step_category["rmm_jsc_id"])
                RmmJraStepCategoriesSerializer(context=self.context).update(step_category_instance, step_category)
            else:
                step_category["rmm_jsc_jra"] = instance
                step_category["rmm_jsc_created_by_per"] = person
                RmmJraStepCategoriesSerializer(context=self.context).create(step_category)
            RmmJraStepCategory.objects.filter(rmm_jsc_id__in=deleted_step_categories).update(rmm_jsc_enable=False, rmm_jsc_modified_by_per=person, rmm_jsc_modified_date=datetime.now())

        return instance

@transaction.atomic
def create_jra(self, validated_data, person_id, request, *args, **kwargs):
    participants = validated_data.pop('participants')
    approvers = validated_data.pop('approvers')
    pra_threats = validated_data.pop('applicable_line_items', None)
    step_categories = validated_data.pop('step_categories')
    validated_data['rmm_jra_created_by_per'] = person_id
    if not validated_data.get("rmm_jra_document_number"):
        newDocNumber = 1
        lastDocNumber = RmmJraMaster.objects.aggregate(Max('rmm_jra_document_number'))
        if (lastDocNumber["rmm_jra_document_number__max"] is not None):
            newDocNumber = lastDocNumber["rmm_jra_document_number__max"] + 1
        validated_data["rmm_jra_document_number"] = newDocNumber
    validated_data["rmm_jra_doc_version_number"] = validated_data.get("rmm_jra_doc_version_number") or 1

    # instance = super(RmmJraMasterSerializer, self).create(validated_data, *args, **kwargs)
    instance = RmmJraMaster.objects.create(**validated_data)

    participant_mod_kwargs = {
        "rmm_jrp_modified_date": None
    }
    approver_mod_kwargs = {
        "rmm_jap_submitted_date": None
    }
    pra_threats_mod_kwargs = {
        'rmm_jpt_modified_date': None
    }
    if instance.rmm_jra_state == 'active':
        participant_mod_kwargs = {
            "rmm_jrp_submitted_by_per": person_id
        }
        approver_mod_kwargs = {
            "rmm_jap_submitted_by_per": person_id
        }
        pra_threats_mod_kwargs = {
            'rmm_jpt_modified_date': person_id
        }

    RmmJraParticipant.objects.bulk_create([RmmJraParticipant(rmm_jrp_jra=instance, rmm_jrp_per_id=getattr(p, "per_id", p), rmm_jrp_created_by_per=person_id,
                                                                **participant_mod_kwargs) for p in participants])

    RmmJraApprover.objects.bulk_create([RmmJraApprover(rmm_jap_jra=instance, rmm_jap_per_id=getattr(a, "per_id", a), rmm_jap_created_by_per=person_id,
                                                        **approver_mod_kwargs) for a in approvers])

    new_pra_threats = []
    for threat in pra_threats:
        if isinstance(threat, RmmPraThreat):
            new_pra_threats.append(threat.rmm_pth_id)
    if new_pra_threats:
        pra_threats = new_pra_threats

    RmmJraPraThreat.objects.bulk_create([RmmJraPraThreat(
        rmm_jpt_jra=instance,
        rmm_jpt_pth_id=pt,
        rmm_jpt_created_by_per=person_id,
        **pra_threats_mod_kwargs) for pt in pra_threats])

    for step_category in step_categories:
        step_category["rmm_jsc_jra"] = instance
        step_category["rmm_jsc_created_by_per"] = person_id
        RmmJraStepCategoriesSerializer(context={'request': request}).create(step_category)
    
    return instance