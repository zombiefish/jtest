from django.db.models import Prefetch
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, RetrieveAPIView
from rest_framework.generics import ListCreateAPIView
from apps.common_utils.views.validate_permission import RolePermission

# from apps.rmm_ora.api.serializers.serializer import RmmOraMasterSerializer
from apps.rmm_jra.api.serializers.serializer import RmmJraMasterSerializer
from apps.rmm_jra.models import RmmJraMaster, RmmJraApprover
from apps.sofvie_user_authorization.api.permissions import SofviePermission





class RmmJraGetGaHaDetail(RetrieveAPIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageJRA.value,)
    serializer_class = RmmJraMasterSerializer
    action = "list"
    queryset = RmmJraMaster.objects.filter(rmm_jra_enable=True)

    def retrieve(self, request, *args, **kwargs):
        person_id = self.request.user.user_per_id
        obj = self.get_object()
        return Response({"general_actions":obj.get_sga_and_attachments(person_id), "hazard_actions": obj.get_ha_and_attachments(person_id)})

    # this is the response
