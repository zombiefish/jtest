from datetime import datetime
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.attachments.models import RmmAttachments
from apps.comments.models import Comments
from apps.common_utils.views.validate_permission import RolePermission
from apps.rmm_jra.models import RmmJraMaster, RmmJraHazardAction, RmmJraGeneralAction
from django.db import transaction
from apps.hazard_action.models import Submissionhap
from apps.general_action.models import SubmissionGeneralAction, Submissionheader
from apps.sofvie_user_authorization.api.permissions import SofviePermission                         


class RmmJraArchive(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewJRA.value,)

    @transaction.atomic
    def post(self, request):
        person_id = self.request.user.user_per_id_id        
        payload_data = request.data

        jra_ids = []

        for rmm_jra in payload_data:
            jra_ids.append(rmm_jra['rmm_jra_id'])      
        

        permission = SofviePermission()        
        self.permission_attrs = (RolePermission.ArchiveSubmissions.value,)
        hasPermission = permission.has_permission(request, self)

        archive = None
        if not hasPermission:

            own_draft_jra_ids = RmmJraMaster.objects.filter(
                rmm_jra_id__in=jra_ids,
                rmm_jra_created_by_per_id = person_id,
                rmm_jra_state = 'draft'
            ).values_list('rmm_jra_id', flat=True)

            if own_draft_jra_ids:                
                # archive only own_draft_jra_ids 
                archive = archive_jra(self, own_draft_jra_ids, person_id)                

                archive_message = 'Archived own draft submissions successfully'
            else:
                return Response(' You are not allowed to archive this submission')
        else:
            # archive all submissions
            archive = archive_jra(self, jra_ids, person_id)
            archive_message = 'Archived successfully'

        
        if archive == True:
            return Response({'message': archive_message}, status= status.HTTP_200_OK)
        else:
            return Response({'message': f'Archive failed. \n {archive}'}, status= status.HTTP_400_BAD_REQUEST)

@transaction.atomic
def archive_jra(self, jra_ids, person_id):
    try:
        # Archive JRA
        RmmJraMaster.objects.filter(rmm_jra_id__in=jra_ids).update(
            rmm_jra_enable=False, 
            rmm_jra_modified_by_per_id=person_id,
            rmm_jra_archived_date = datetime.now(),
            rmm_jra_archived_by_per_id = person_id
        )

        # Archive child - general action
        RmmJraGeneralAction.objects.filter(
            rmm_jga_jra__in=jra_ids
        ).update(
            rmm_jga_enable=False, 
            rmm_jga_modified_by_per_id=person_id,
            rmm_jga_modified_date = datetime.now()
        )       


        # Archive submission general action associated with JRA
        SubmissionGeneralAction.objects.filter(
            rmm_jga_sga_id__rmm_jga_jra__in=jra_ids
        ).update(
            sga_enable=False, 
            sga_modified_by_per_id=person_id,
            sga_modified_date = datetime.now(),
            sga_archived_date = datetime.now(),
            sga_archived_by_per_id = person_id
        )

        # Archive general actions in SubmissionHeader

        ga_sh_ids = SubmissionGeneralAction.objects.filter(
            rmm_jga_sga_id__rmm_jga_jra__in=jra_ids
        ).values_list('sga_submission_header_id', flat= True)

        Submissionheader.objects.filter(
            id__in = ga_sh_ids
        ).update(
            isarchived=True,
            archiveddate=datetime.now(),
            archived_by_per=person_id
        )

        # Archive - child - Hazard Action
        RmmJraHazardAction.objects.filter(
            rmm_jha_jra__in=jra_ids
        ).update(
            rmm_jha_enable= False, 
            rmm_jha_modified_by_per_id=person_id,
            rmm_jha_modified_date = datetime.now()
        )        

        # Archive Submission hap associated with JRA
        Submissionhap.objects.filter(
            rmm_jha_sha_id__rmm_jha_jra__in=jra_ids
        ).update(
            sha_enable= False, 
            sha_modified_by_per_id=person_id,
            sha_modified_date = datetime.now(),
            sha_archived_date = datetime.now(),
            sha_archived_by_per_id = person_id
        )

        # Archive hazard actions in SubmissionHeader

        ha_sh_ids = Submissionhap.objects.filter(
            rmm_jha_sha_id__rmm_jha_jra__in=jra_ids
        ).values_list(
            'submissionheaderid_id', flat= True
        )

        Submissionheader.objects.filter(
            id__in = ha_sh_ids
        ).update(
            isarchived=True,
            archiveddate=datetime.now(),
            archived_by_per=person_id
        )
        


        rmmAttachment_instances=RmmAttachments.objects.filter(rat_rmm_id__in=jra_ids, rat_enable=True).values()
        for rmmAttachment_instance in rmmAttachment_instances:
            Comments.objects.filter(com_reference_id=rmmAttachment_instance['rat_id'],com_cmt_id=rmmAttachment_instance['rat_mod_id'],com_enable=True).update(com_enable=False, com_modified_date= datetime.now(),com_modified_by_per_id=person_id)

        RmmAttachments.objects.filter(rat_rmm_id__in=jra_ids).update(rat_enable=False, rat_modified_date = datetime.now(),rat_modified_by_per_id=person_id)
        
        return True
    except Exception as e:        
        return e
