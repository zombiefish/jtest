from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.generics import CreateAPIView
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView

from django.db.models import Q, F
from django.db.models import Max
from apps.common_utils.views.validate_permission import RolePermission

# from apps.rmm_jra.api.serializers.serializer import RmmJraGetPraTitleSerializer
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user.models import User
from apps.person.models import Person
from apps.rmm_jra.models import RmmJraMaster
from apps.rmm_pra.models import RmmPraElementCategory, RmmPraThreat, RmmPraTags
from apps.rmm_pra.api.serializers.serializer import RmmPraElementCategoriesSerializer
from apps.rmm_ora.models import RmmOraTags

class RmmJraBluelines(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):

        payload = request.data

        """
        {
            "rmm_pra_id" : 1,
            "rmm_pec_id": [1,2,3,4]
        }
        """
        ora_filter = []
        pra_filter = []
        if payload['rmm_pec_id'] and payload['rmm_pra_id']:
            pra_filter = [Q(rmm_pta_pth__rmm_pth_pec__in=payload['rmm_pec_id']) ]
            ora_filter = [Q(rmm_ota_oev__rmm_oev_oec__rmm_oec_ora__rmm_pra_ora_id__rmm_pra_id=payload['rmm_pra_id'])]     

        pra_bluelines = RmmPraTags.objects.order_by(
        ).filter(            
            *pra_filter,
            rmm_pta_pth__rmm_pth_enable = True,
            rmm_pta_enable = True                                                             
        ).annotate(
            event = F('rmm_pta_pth__rmm_pth_threat'),
            rmm_pec_id = F('rmm_pta_pth__rmm_pth_pec'),
        ).values(
            'rmm_pec_id',
            'tag', 
            'event'
        )

        ora_bluelines = RmmOraTags.objects.order_by(
        ).filter(
            *ora_filter,
            rmm_ota_enable = True,
            rmm_ota_oev__rmm_oev_enable = True,
            rmm_ota_oev__rmm_oev_oec__rmm_oec_enable = True
        ).annotate(
            event=F('rmm_ota_oev__rmm_oev_major_unwanted_event'),            
            rmm_pra_id=F("rmm_ota_oev__rmm_oev_oec__rmm_oec_ora__rmm_pra_ora_id__rmm_pra_id"),
        ).values(
            'tag', 
            'event',
            'rmm_pra_id',
        )      
        
        return Response({"rmm_pra_bluelines": pra_bluelines, "rmm_ora_bluelines": ora_bluelines})