from django.db import transaction
from django.db.models import Max

from rest_framework.exceptions import ValidationError
from rest_framework.response import Response

from rest_framework.generics import CreateAPIView
from apps.attachments.models import RmmAttachments
from apps.comments.models import Comments
from apps.common_utils.views.validate_permission import RolePermission

from apps.rmm_jra.api.serializers.serializer import RmmJraMasterSerializer
from apps.rmm_jra.models import RmmJraMaster
from apps.rmm_pra.models import RmmPraThreat
from apps.sofvie_user_authorization.api.permissions import SofviePermission

class RmmJraCopy(CreateAPIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageJRA.value,)
    serializer_class = RmmJraMasterSerializer
    action = "retrieve"
    def get_queryset(self):
        return RmmJraMaster.objects.all()

    @transaction.atomic
    def create(self, request, pk, mode, *args, **kwargs):
        instance = self.get_object()
        context = self.get_serializer_context()
        context["read"] = 'copy_revision'
        context["read_actions"] = False

        serializer = RmmJraMasterSerializer(instance, context=context)

        data = serializer.data

        rmm_attachments= RmmAttachments.objects.filter(rat_rmm_id=data['rmm_jra_id'], rat_enable=True).values()

        del data['rmm_jra_id']
        if data["rmm_jra_state"]=="expired":
            data["rmm_jra_expiry_date"] = None
        del data['dlo_enable']
        del data['reviewers']

        data['approvers'] = [a["rmm_jap_per"] for a in data["approvers"]]
        data['applicable_line_items'] = [RmmPraThreat.objects.get(rmm_pth_id=pt) for pt in data['applicable_line_items']]
        if mode=="copy":
            del data["rmm_jra_document_number"]
            data["rmm_jra_doc_version_number"] = 1
            data["rmm_jra_state"] = 'draft'

        elif mode=="revision":
            if instance.rmm_jra_state == "draft":
                raise ValidationError("Can't make revsision from draft document")
            else:
                draft_exists = RmmJraMaster.objects.filter(rmm_jra_document_number=instance.rmm_jra_document_number, rmm_jra_enable=True, rmm_jra_state='draft').exists()
                if draft_exists:
                    raise ValidationError("draft version of this document already exists")
                instance.save()     
            max_version_number = RmmJraMaster.objects.filter(rmm_jra_document_number=instance.rmm_jra_document_number).aggregate(Max("rmm_jra_doc_version_number"))
            data["rmm_jra_doc_version_number"] = max_version_number["rmm_jra_doc_version_number__max"] + 1
            data["rmm_jra_state"] = 'draft'            
        else:
            raise ValidationError({"mode":"Invalid mode. Only allowed mode is copy/revision."})

        data["rmm_jra_site_id"] = data["rmm_jra_site"]
        data["rmm_jra_pra_id"] = data["rmm_jra_pra"]
        data['rmm_jra_job_id'] = data['rmm_jra_job']
        data["rmm_jra_created_by_per_id"] = request.user.user_per_id_id
        data["rmm_jra_created_by_per"] = request.user.user_per_id.full_name        
        del data["rmm_jra_site"]
        del data["rmm_jra_pra"]
        del data['rmm_jra_job']

        for index, ev_c in enumerate(data["step_categories"]):
            del data["step_categories"][index]["rmm_jsc_id"]
            del data["step_categories"][index]["rmm_jsc_modified_by_per"]
            data["step_categories"][index]["rmm_jsc_step"] = data["step_categories"][index].pop("rmm_jsc_step")

            for e_index, ev in enumerate(data["step_categories"][index]["threats"]):

                data["step_categories"][index]["threats"][e_index]["rmm_jth_likelyhood_preliminary_id"] = data["step_categories"][index]["threats"][
                    e_index].pop("rmm_jth_likelyhood_preliminary")
                data["step_categories"][index]["threats"][e_index]["rmm_jth_severity_preliminary_id"] = data["step_categories"][index]["threats"][
                    e_index].pop("rmm_jth_severity_preliminary")
                data["step_categories"][index]["threats"][e_index]["rmm_jth_likelyhood_residual_id"] = data["step_categories"][index]["threats"][
                    e_index].pop("rmm_jth_likelyhood_residual")
                data["step_categories"][index]["threats"][e_index]["rmm_jth_severity_residual_id"] = data["step_categories"][index]["threats"][
                    e_index].pop("rmm_jth_severity_residual")
                del data["step_categories"][index]["threats"][e_index]["rmm_jth_id"]
                del data["step_categories"][index]["threats"][e_index]["rmm_jth_modified_by_per"]
                for t_index, o in enumerate(data["step_categories"][index]["threats"][e_index]["control_measures"]):
                    del data["step_categories"][index]["threats"][e_index]["control_measures"][t_index]["rmm_jta_id"]
                for t_index, o in enumerate(data["step_categories"][index]["threats"][e_index]["additional_control_measures"]):
                    del data["step_categories"][index]["threats"][e_index]["additional_control_measures"][t_index]["rmm_jta_id"]

        instance = serializer.create(data)        

        for rmm_attachment in rmm_attachments:            
            new_rmm_attachment = {}
            new_rmm_attachment["rat_id"] = None
            new_rmm_attachment['rat_rmm_id'] = instance.rmm_jra_id
            new_rmm_attachment['rat_mod_id'] = rmm_attachment["rat_mod_id"]
            new_rmm_attachment['rat_file_name'] = rmm_attachment["rat_file_name"]
            new_rmm_attachment['rat_created_by_per'] = request.user.user_per_id
            attachments_instance=RmmAttachments.objects.create(**new_rmm_attachment)
            copy_revision_comments(rmm_attachment['rat_id'],attachments_instance.rat_id,rmm_attachment["rat_mod_id"])
        return Response({"Message": "Document copied.", "new_doc_id": instance.rmm_jra_id})

def copy_revision_comments(reference_id, new_reference_id,mod_id):
    '''
    get comments for reference id matching com_reference_id
    create new entries for all the comments
    '''
    comments = Comments.objects.filter(
        com_cmt_id=mod_id, 
        com_reference_id = reference_id,
        com_enable = True
    ).values()

    new_comments_obj = []
    for comment in comments:
        new_comment= {}
        new_comment['com_id'] = None
        new_comment['com_cmt_id'] = mod_id  
        new_comment['com_reference_id'] = new_reference_id
        new_comment['com_comment'] = comment['com_comment']
        new_comment['com_created_by_per_id'] = comment['com_created_by_per_id']
        new_comment['com_created_date'] = comment['com_created_date']
        new_comment['com_enable'] = comment['com_enable']
        new_comments_obj.append(Comments(**new_comment))
    Comments.objects.bulk_create(new_comments_obj)  




