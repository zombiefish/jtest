from apps.common_utils.views.validate_permission import RolePermission
from apps.employee.models import Employee
from rest_framework.generics import CreateAPIView
from rest_framework.status import HTTP_404_NOT_FOUND
from rest_framework.response import Response

from apps.rmm_jra.models import RmmJraMaster, RmmJraReview
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class RmmJraReviewAPI(CreateAPIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewJRA.value,)
    
    def create(self, request, pk, *args, **kwargs):
        try:
            obj = RmmJraMaster.objects.get(rmm_jra_id=pk)
        except:
            return Response(status=HTTP_404_NOT_FOUND)
        
        person = request.user.user_per_id
        position = Employee.objects.get(emp_per = person).emp_pos_id

        rmm_jra_id = request.data['rmm_jra_id']

        rmm_jre = RmmJraReview.objects.filter(
            rmm_jre_jra_id=rmm_jra_id, rmm_jre_per_id=request.user.user_per_id, rmm_jre_enable=True).first()

        if rmm_jre:
            return Response({"message": "Already reviewed"})
        else:
            RmmJraReview.objects.create(
                rmm_jre_jra=obj,
                rmm_jre_per=request.user.user_per_id,
                rmm_jre_created_by_per=request.user.user_per_id,
                rmm_jre_modified_by_per=request.user.user_per_id,
                rmm_jre_position = position
            )
            return Response({"message": "Reviewed successfully"})
