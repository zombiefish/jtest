from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.generics import CreateAPIView
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView

from django.db.models import Q
from django.db.models import Max
from apps.common_utils.views.validate_permission import RolePermission

# from apps.rmm_jra.api.serializers.serializer import RmmJraGetPraTitleSerializer
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user.models import User
from apps.person.models import Person
from apps.rmm_jra.models import RmmJraMaster
from apps.rmm_pra.models import RmmPraMaster
from apps.rmm_pra.api.serializers.serializer import RmmPraMasterSerializer


class RmmJraGetPraTitleList(APIView):
    # pass
    permission_classes = [SofviePermission]

    def get(self, request):

        queryset = RmmPraMaster.objects.filter(rmm_pra_enable=True, rmm_pra_state='active').values('rmm_pra_id', 'rmm_pra_title').order_by("rmm_pra_title")        
        # serializer = RmmJraGetPraTitleSerializer(queryset, many=True)
        return Response({"data":queryset})
