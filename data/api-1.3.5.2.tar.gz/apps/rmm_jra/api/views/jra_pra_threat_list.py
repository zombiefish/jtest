from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.generics import CreateAPIView
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView

from django.db.models import Q, F
from django.db.models import Max
from apps.common_utils.views.validate_permission import RolePermission
from apps.language.models import Language

# from apps.rmm_jra.api.serializers.serializer import RmmJraGetPraTitleSerializer
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user.models import User
from apps.person.models import Person
from apps.rmm_jra.models import RmmJraMaster
from apps.rmm_pra.models import RmmPraElementCategory
from apps.rmm_pra.api.serializers.serializer import RmmPraElementCategoriesSerializer

from operator import itemgetter

from apps.user_settings_profile.models import UserProfile


class RmmJraGetPraThreatList(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):

        payload = request.data

        rmm_pra_id = []

        if payload['rmm_pra_id']:
            rmm_pra_id = [Q(rmm_pec_pra=payload['rmm_pra_id']), ]
       
        queryset = RmmPraElementCategory.objects.filter(
            *rmm_pra_id, 
            rmm_pec_enable=True
        ).annotate(
            rmm_pra_id = F('rmm_pec_pra__rmm_pra_id')
        ).values(
            'rmm_pec_id',
            'rmm_pec_element',
            'rmm_pra_id'
        )

        return Response({"data":queryset})
