from datetime import datetime
import uuid
from django.db.models import Max
from django.db import transaction
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.general_action.api.views.create_general_action import insert_general_action, send_email
from apps.hazard_action.api.views.create_hazard_action import get_user_email, insert_hazard_action
from apps.rmm_jra.api.serializers.serializer import create_jra
from apps.general_action.models import SubmissionGeneralAction
from apps.rmm_jra.api.views.jra_insert_general_action import bulk_create_jra_general_action
from apps.rmm_jra.api.views.jra_insert_hazard_action import bulk_create_jra_hazard_action
from apps.rmm_jra.models import RmmJraMaster
from apps.user.models import User
from apps.hazard_action.models import Submissionhap

def create_object(obj, *args, **kwargs):
    obj.objects.create(
        **kwargs
    )


class InsertJRAMobile(APIView):
    permission_classes = [IsAuthenticated]

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        person_id = self.request.user.user_per_id
        self.person_instance = person_id

        payload_data = request.data

        jra_data = payload_data.pop('jra_data', None)
        jra_general_actions = payload_data.pop('jra_general_actions', None)
        jra_hazard_actions = payload_data.pop('jra_hazard_actions', None)

        instance = create_jra(self, jra_data, person_id, request, *args, **kwargs)


        for general_action in jra_general_actions:
            general_action.pop('completed_action_score')

            is_group = general_action.pop('is_group','0')
            general_action['sga_is_group_action'] = bool(int(is_group))

            general_action['attachments'], general_action = generate_attachments(general_action, 'general_action')
            
            insert_general_action(self, general_action, insert_attachments=True)

            self.jra_id = instance.pk
            self.sga_ids = self.submitted_action_ids

            bulk_create_jra_general_action(self)

        for hazard_action in jra_hazard_actions:
           
            hazard_action['attachments'], hazard_action = generate_attachments(hazard_action, 'hazard_action')

            is_group = hazard_action.pop('is_group','0')
            hazard_action['sha_is_group_action'] = bool(int(is_group))

            insert_hazard_action(self, hazard_action, insert_attachments=True)

            self.jra_id = instance.pk
            self.sha_ids = self.submitted_action_ids

            bulk_create_jra_hazard_action(self)

        return Response({"OK": str(instance)})


def generate_attachments(action_data, type):
    if type == 'general_action':
        image_keys = [key for key in action_data if 'general_action_images' in key]
    elif type == 'hazard_action':
        image_keys = [key for key in action_data if 'hazard_attachment' in key]


    attachments_list = []

    for key in image_keys:
        temp = {
            "att_file_name": None,
            "att_file_url": None,
            "att_timestamp": None,
            "att_comment": None
        }
        if '_comment' in key:
            action_data.pop(key)
            continue
        temp['att_file_url'] = action_data[key]
        temp['att_comment'] = action_data[key+'_comment']
        temp['att_file_name'] = str(uuid.uuid4())
        temp_stamp_str = key.split('.')[0].replace('JRA','')
        temp['att_timestamp'] = temp_stamp_str
        attachments_list.append(temp)

        action_data.pop(key)
    return attachments_list, action_data





'''
{
    "jra_data": 
    {
        "rmm_jra_id": null,
        "rmm_jra_document_number": null,
        "rmm_jra_doc_version_number": null,
        "rmm_jra_title": "add new jra",
        "rmm_jra_scope": "scope",
        "rmm_jra_expiry_date": "2022-06-28",
        "rmm_jra_site_id": 6255,
        "rmm_jra_job_id": 5433,
        "rmm_jra_workplace": "423",
        "rmm_jra_pra": null,
        "rmm_jra_other_participants": "ae",
        "rmm_jra_state": "draft",
        "rmm_jra_date": "2022-06-06",
        "participants": [
            1790
        ],
        "approvers": [
            6
        ],
        "step_categories": [
            {
                "rmm_jsc_step": "asdf",
                "rmm_jsc_id": null,
                "rmm_jsc_sort": 1,
                "rmm_jsc_enable": true,
                "threats": [
                    {
                        "rmm_jth_id": null,
                        "rmm_jth_jsc": 482,
                        "rmm_jth_threat": "qewrwe",
                        "rmm_jth_outcome": "rqwerewq",
                        "rmm_jth_severity_category": null,
                        "rmm_jth_likelyhood_preliminary_id": 4981,
                        "rmm_jth_severity_preliminary_id": 4986,
                        "rmm_jth_preliminary_risk": 3627,
                        "rmm_jth_risk_alara_preliminary": 1,
                        "rmm_jth_likelyhood_residual": null,
                        "rmm_jth_severity_residual": null,
                        "rmm_jth_residual_risk": null,
                        "rmm_jth_risk_alara_residual": null,
                        "rmm_jth_created_by_per": 1729,
                        "rmm_jth_modified_date": null,
                        "rmm_jth_modified_by_per": null,
                        "rmm_jth_enable": true,
                        "rmm_jth_enote": null,
                        "control_measures": [
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": 1487,
                                "rmm_jta_parent_tag_name": "control_measures",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_blueline": false,
                                "rmm_jta_created_by_per": 1729,
                                "rmm_jta_modified_date": null,
                                "rmm_jta_modified_by_per": null,
                                "rmm_jta_enable": true,
                                "rmm_jta_enote": null,
                                "tag": "reqwrewr\\"
                            },
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": 1487,
                                "rmm_jta_parent_tag_name": "control_measures",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_blueline": false,
                                "rmm_jta_created_by_per": 1729,
                                "rmm_jta_modified_date": null,
                                "rmm_jta_modified_by_per": null,
                                "rmm_jta_enable": true,
                                "rmm_jta_enote": null,
                                "tag": "qqewreqw"
                            },
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": 1487,
                                "rmm_jta_parent_tag_name": "control_measures",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_blueline": false,
                                "rmm_jta_created_by_per": 1729,
                                "rmm_jta_modified_date": null,
                                "rmm_jta_modified_by_per": null,
                                "rmm_jta_enable": true,
                                "rmm_jta_enote": null,
                                "tag": "rewqrqwer"
                            },
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": 1487,
                                "rmm_jta_parent_tag_name": "control_measures",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_blueline": false,
                                "rmm_jta_created_by_per": 1729,
                                "rmm_jta_modified_date": null,
                                "rmm_jta_modified_by_per": null,
                                "rmm_jta_enable": true,
                                "rmm_jta_enote": null,
                                "tag": "ewqrqewr"
                            }
                        ],
                        "additional_control_measures": []
                    },
                    {
                        "rmm_jth_id": null,
                        "rmm_jth_jsc": null,
                        "rmm_jth_threat": "new threat",
                        "rmm_jth_outcome": "threat new",
                        "rmm_jth_severity_category": null,
                        "rmm_jth_likelyhood_preliminary_id": 4981,
                        "rmm_jth_severity_preliminary_id": 4986,
                        "rmm_jth_preliminary_risk": "3627",
                        "rmm_jth_risk_alara_preliminary": 0,
                        "rmm_jth_likelyhood_residual_id": 4981,
                        "rmm_jth_severity_residual_id": 4986,
                        "rmm_jth_residual_risk": "3627",
                        "rmm_jth_risk_alara_residual": 1,
                        "rmm_jth_created_by_per": null,
                        "rmm_jth_modified_date": null,
                        "rmm_jth_modified_by_per": null,
                        "rmm_jth_enable": true,
                        "rmm_jth_enote": null,
                        "control_measures": [
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": null,
                                "tag": "1243",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_enable": true
                            },
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": null,
                                "tag": "42314123",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_enable": true
                            },
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": null,
                                "tag": "42314321",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_enable": true
                            },
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": null,
                                "tag": "321321",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_enable": true
                            }
                        ],
                        "additional_control_measures": [
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": null,
                                "tag": "acq",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_blueline": false,
                                "rmm_jta_enable": true
                            },
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": null,
                                "tag": "adsf",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_blueline": false,
                                "rmm_jta_enable": true
                            },
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": null,
                                "tag": "dfasdfdas",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_blueline": false,
                                "rmm_jta_enable": true
                            },
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": null,
                                "tag": "fsadfsad",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_blueline": false,
                                "rmm_jta_enable": true
                            },
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": null,
                                "tag": "fdsf",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_blueline": false,
                                "rmm_jta_enable": true
                            },
                            {
                                "rmm_jta_id": null,
                                "rmm_jta_jth": null,
                                "tag": "sadf",
                                "rmm_jta_tag_name": null,
                                "rmm_jta_blueline": false,
                                "rmm_jta_enable": true
                            }
                        ]
                    }
                ]
            }
        ],
        "rmm_jra_executive_summary": null,
        "rmm_jra_submitted_date": null,
        "applicable_line_items": []
    },
    "jra_general_actions":[{
    }],
    "jra_hazard_actions": [{}]
}

'''
