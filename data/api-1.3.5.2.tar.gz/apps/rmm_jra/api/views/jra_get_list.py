from django.db.models import Prefetch, F, Q
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.rmm_jra.api.serializers.serializer import RmmJraMasterSerializer
from apps.rmm_jra.models import RmmJraMaster, RmmJraApprover
from apps.rmm_ora.api.date_filter_utils import date_filter
from apps.employee.helper_function_user_visibility import helperEmployeeJobs, helperEmployeeSites
from apps.sofvie_user_authorization.api.permissions import SofviePermission




class RmmJraGetList(ListAPIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewJRA.value,RolePermission.CanViewIncidents.value)
    all_permissions = False
    serializer_class = RmmJraMasterSerializer

    def get_queryset(self):
        start_date = self.request.data['start_date']
        end_date = self.request.data['end_date']

        person_id = self.request.user.user_per_id        
        get_sites, data_user_visibility = helperEmployeeSites(self, person_id)
        get_jobs, data_user_visibility = helperEmployeeJobs(self, person_id)

        site_list = [site['rld_id'] for site in get_sites]
        job_list = [job['rld_id'] for job in get_jobs]


        site_filters = []
        job_filters = []
        if data_user_visibility !='all':
            site_filters = [Q(rmm_jra_site__in=site_list) | Q(rmm_jra_site__isnull=True) | Q(rmm_jra_created_by_per=person_id)]
            job_filters = [Q(rmm_jra_job__in=job_list) | Q(rmm_jra_job__isnull=True) | Q(rmm_jra_created_by_per=person_id)]

        queryset = RmmJraMaster.objects.filter(                        
                        *site_filters,
                        *job_filters,
                        rmm_jra_enable=True,
                        rmm_jra_created_date__range=(date_filter(start_date, end_date))
                        ).prefetch_related(
            Prefetch('approvers', RmmJraApprover.objects.all().select_related('rmm_jap_per')),
            'participants', 'rmm_jre_jra_master')
        return queryset

    def get_serializer_context(self):
        context = super(RmmJraGetList, self).get_serializer_context()
        context["read"] = True
        return context

    def post(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)
