from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from rest_framework.generics import CreateAPIView
from rest_framework.views import APIView

from django.db import transaction
from apps.common_utils.views.validate_permission import RolePermission
from apps.rmm_jra.models import RmmJraHazardAction
from apps.sofvie_user_authorization.api.permissions import SofviePermission

class RmmAddJraHazardAction(CreateAPIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageJRA.value,)

    def post(self, request, *args, **kwargs):

        try:

            self.person_instance = self.request.user.user_per_id
            self.jra_id = request.data.pop('rmm_jha_jra', None)
            self.sha_ids = request.data.pop('rmm_jha_sha', [])

            bulk_create_jra_hazard_action(self)

            return Response({"Message": "Successfully added hazard action to selected JRA."}, status=status.HTTP_200_OK)

        except Exception as e:

            return Response({"Message": f"Failed to add hazard action to selected JRA. {e}"}, status=status.HTTP_400_BAD_REQUEST)


@transaction.atomic
def bulk_create_jra_hazard_action(self):
    
    bulk_create_object = [RmmJraHazardAction(
        rmm_jha_jra_id = self.jra_id,
        rmm_jha_created_by_per = self.person_instance,
        rmm_jha_sha_id = sha_id
    ) for sha_id in self.sha_ids]
    
    RmmJraHazardAction.objects.bulk_create(bulk_create_object)