from django.utils import timezone
from datetime import timedelta
from apps.common_utils.views.get_translations import get_translation
from apps.common_utils.views.validate_permission import RolePermission
from apps.language.models import Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.generics import CreateAPIView
from rest_framework.views import APIView

from django.db.models import Q
from django.db.models import Max

from django.utils.safestring import mark_safe


from apps.rmm_jra.api.serializers.serializer import RmmJraMasterSerializer, RmmJraApproverSerializer

from apps.reflist.models import RefListDetail
from apps.user.models import User
from apps.person.models import Person
from apps.employee.models import Employee
from apps.rmm_jra.models import RmmJraMaster, RmmJraApprover
from datetime import datetime
from django.template.loader import get_template
from django.core.mail import EmailMultiAlternatives
from django.conf import settings
from django.db import transaction



class RmmJraSignDocument(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageJRA.value,)
    
    @transaction.atomic
    def post(self, request):
        
        person_id = self.request.user.user_per_id_id
        payload_data = request.data       
        
        #check if person signing first time or updating the sign
        person_sign = RmmJraApprover.objects.get(rmm_jap_jra=payload_data['rmm_jra_id'], rmm_jap_per=person_id, rmm_jap_enable=True)
        position = Employee.objects.get(emp_per = person_id).emp_pos_id 

        #updating rmm_jra_approver
        RmmJraApprover.objects.filter(rmm_jap_jra=payload_data['rmm_jra_id'], rmm_jap_per=person_id, rmm_jap_enable=True).update(
            rmm_jap_approved=True,
            rmm_jap_per_position= position,
            rmm_jap_approved_date = datetime.now()
        )

        #checking all approvers signed                
        rmmApproverObject = RmmJraApprover.objects.filter(rmm_jap_jra=payload_data['rmm_jra_id'],rmm_jap_enable=True)

        approvedList = [approver.rmm_jap_approved for approver in rmmApproverObject if approver.rmm_jap_approved==True]
        notApprovedList = [approver.rmm_jap_approved for approver in rmmApproverObject if approver.rmm_jap_approved==False]


        #updating rmm_jra_state
        jra_instance = RmmJraMaster.objects.get(rmm_jra_id=payload_data['rmm_jra_id'])
        state = "review"
        if len(notApprovedList)==0:
            # print('turning doc to active-___')
            #runs when last approver signed the PRA document. 
            state = "active"
            #update other versions of this document to expired if there are any
            RmmJraMaster.objects.filter(rmm_jra_document_number=jra_instance.rmm_jra_document_number, rmm_jra_enable=True).update(rmm_jra_state="expired",rmm_jra_expiry_date = timezone.now().date() - timedelta(days=1))
        if state=='active' and jra_instance.rmm_jra_expiry_date <= datetime.now().date():
            state = 'expired'
        
        jra_instance.rmm_jra_state = state
        jra_instance.rmm_jra_executive_summary = payload_data['rmm_jra_executive_summary']   
        jra_instance.save()

        # RmmJraMaster.objects.filter(rmm_jra_id=payload_data['rmm_jra_id']).update(
        #     rmm_jra_state=state,
        #     rmm_jra_executive_summary=payload_data['rmm_jra_executive_summary']
        # )

        #sending email to approvers
        rmmJraObject = RmmJraMaster.objects.get(rmm_jra_id=payload_data['rmm_jra_id']) 
        
        if len(approvedList)==1 and rmmJraObject.rmm_jra_state=='review' and person_sign.rmm_jap_approved==False:
            #send email to remaining approvers
            approvers_email_list = [approver.rmm_jap_per for approver in rmmApproverObject  if approver.rmm_jap_approved==False]
            rmm_created_by = User.objects.get(user_per_id=rmmJraObject.rmm_jra_created_by_per)
            lng_name = UserProfile.objects.get(upr_per_id=person_id).upr_language
            lng_id = Language.objects.get(lng_name=lng_name)            
            ltr_ids = [4263, 3601, 4624, 1054, 1298, 1304, 2105, 3703, 4243, 4244, 4265, 4266, 3606, 3607, 3608, 4264, 4267, 4268, 2253, 8450, 8451, 1952]
            get_trans = get_translation(ltr_ids, lng_id)
             
 
            for person in User.objects.filter(user_per_id__in=approvers_email_list):                   

                    email_data = {
                                    'user': person.full_name,
                                    'document_type': get_trans[2253],
                                    'created_by': rmm_created_by.full_name, 
                                    'document_title': mark_safe(rmmJraObject.rmm_jra_title),
                                    'document_scope': mark_safe(rmmJraObject.rmm_jra_scope),
                                    'document_executive_summary': mark_safe(rmmJraObject.rmm_jra_executive_summary),                        
                                    'data': get_trans
                                }
            
                    subject, from_email, email_list = get_trans[4263], \
                                                      settings.DEFAULT_FROM_EMAIL_ADMIN, \
                                                      [person.email]
                    text_content = get_trans[8450]
                    html_content = get_template(
                        "risk_assessment_jra_email_template.html").render(email_data)
                    msg = EmailMultiAlternatives(subject, text_content, from_email,
                                                 email_list)
                    msg.attach_alternative(html_content, "text/html")
                    msg.send()
                    # print('EMAIL SEND SUCCESSFULLY')                    
               
        return Response({"message": "Document Signed", "rmm_jra_state": rmmJraObject.rmm_jra_state})

        """
        {
            "rmm_jra_id": 1234,
            "rmm_jra_executive_summary": "sdfasdfasdf"
        }
        """