from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from rest_framework.generics import CreateAPIView
from django.db import transaction
from apps.common_utils.views.validate_permission import RolePermission

from apps.rmm_jra.models import RmmJraGeneralAction
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class RmmAddJraGeneralAction(CreateAPIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageJRA.value,)
    
    def post(self, request, *args, **kwargs):
    
        try:

            self.person_instance = self.request.user.user_per_id
            self.jra_id = request.data.pop('rmm_jga_jra', None)
            self.sga_ids = request.data.pop('rmm_jga_sga', [])

            bulk_create_jra_general_action(self)

            return Response({"Message": "Successfully added general action to selected JRA."}, status=status.HTTP_200_OK)

        except Exception as e:

            return Response({"Message": f"Failed to add general action to selected JRA. {e}"}, status=status.HTTP_400_BAD_REQUEST)


@transaction.atomic
def bulk_create_jra_general_action(self):

    bulk_create_object = [RmmJraGeneralAction(
        rmm_jga_jra_id = self.jra_id,
        rmm_jga_created_by_per = self.person_instance,
        rmm_jga_sga_id = sga_id
    ) for sga_id in self.sga_ids]
    
    RmmJraGeneralAction.objects.bulk_create(bulk_create_object)


