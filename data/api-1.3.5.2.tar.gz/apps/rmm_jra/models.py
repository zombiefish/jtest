from decimal import Decimal
from datetime import date
from django.db import models
from django.db.models import (
    Model,
    AutoField,
    IntegerField,
    CharField,
    DateTimeField,
    ForeignKey,
    ManyToManyField,
    BooleanField,
    TextField,
    DateField,
    DecimalField,
    F, Value, Subquery, OuterRef
)

# Create your models here.
from django.utils import timezone
from django.db.models.functions import Concat, Substr
from apps.common_utils.views.common_global_functions import modify_ga_data, modify_ha_data
from apps.common_utils.views.sofvieModelFields import SofvieCharField, SofvieIntegerField, SofvieTextField
from apps.general_action.models import SubmissionGeneralAction, SubmissionGeneralActionAttachment
from apps.hazard_action.models import Submissionhap, Submissionhapattachments
from apps.person.models import Person
from apps.rmm_pra.models import RmmPraMaster, RmmPraThreat
from apps.reflist.models import RefListDetail
from apps.user_settings_profile.models import UserProfile
from apps.language.models import LanguageTranslation, Language

"doc-0000001"
"doc-0000002"
"doc-0000002.1"

# Generating the document number

def get_doc_serial(document_number=None):
    if document_number:
        document_number = Decimal(document_number)
        document_number += Decimal("0.1")
        return document_number
    try:
        last_obj = RmmJraMaster.objects.all().latest('rmm_ora_created_date')
        document_number = int(last_obj.rmm_ora_document_number)
        document_number += 1
        return document_number
    except RmmJraMaster.DoesNotExist:
        return "1"

class RmmJraMaster(Model):
    rmm_jra_id = AutoField(primary_key=True)
    rmm_jra_document_number = SofvieIntegerField(help_text="Unique document number.",null=True)
    rmm_jra_doc_version_number = SofvieIntegerField(help_text="DocumentRevisionNumber",null=True)
    rmm_jra_title = SofvieCharField(max_length=70, db_index=True, blank=True, null=True)
    rmm_jra_scope = SofvieTextField(blank=True, null=True)
    rmm_jra_date = DateField(blank=True, null=True)
    rmm_jra_expiry_date = DateField(blank=True, null=True)
    rmm_jra_site = ForeignKey(RefListDetail, blank=True, null=True,
                              related_name='rmm_jra_site_id',
                              on_delete=models.DO_NOTHING,
                              help_text="ForeignKey from ref_list_detail Table")
    rmm_jra_job = ForeignKey(RefListDetail, blank=True, null=True,
                              related_name='rmm_jra_job_id',
                              on_delete=models.DO_NOTHING,
                              help_text="ForeignKey from ref_list_detail Table")
    rmm_jra_workplace = SofvieCharField(max_length=255, blank=True, null=True) 
    rmm_jra_other_participants = SofvieCharField(max_length=255, blank=True, null=True)
    rmm_jra_state = SofvieCharField(max_length=31, default='draft')
    rmm_jra_pra = ForeignKey(RmmPraMaster, blank=True, null=True,
                              related_name='rmm_jra_pra_id',
                              on_delete=models.DO_NOTHING,
                              help_text="Get PRA ID from rmm_pra")
    rmm_jra_executive_summary = SofvieTextField(blank=True, null=True)    
    rmm_jra_submitted_date = DateTimeField(blank=True, null=True)
    rmm_jra_created_date = DateTimeField(auto_now_add=True)
    rmm_jra_created_by_per = ForeignKey(Person, blank=False, null=False,
                                        related_name='rmm_jra_created_by_per_id',
                                        on_delete=models.DO_NOTHING,
                                        help_text="ForeignKey from person "
                                                  "Table")
    rmm_jra_modified_date = DateTimeField(blank=True, null=True) # make sure it will null BM
    rmm_jra_modified_by_per = ForeignKey(Person, blank=True, null=True,
                                         related_name='rmm_jra_modified_by_per_id',
                                         on_delete=models.DO_NOTHING,
                                         help_text="ForeignKey from person "
                                                   "Table")
    rmm_jra_archived_date = DateTimeField(blank=True, null=True)
    rmm_jra_archived_by_per = ForeignKey(Person, blank=True, null=True,
                                            related_name='rmm_jra_archived_by_per_id',
                                            on_delete=models.DO_NOTHING,
                                            help_text='Foreign key from person table/Person model')                                                   
    rmm_jra_enable = BooleanField(default=True)
    rmm_jra_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_jra'
        verbose_name = 'Job Risk Assessment'
        
    def only_mandatory_reviewers(self):
        return RmmJraApprover.objects.filter(rmm_jap_jra = self.rmm_jra_id, rmm_jap_enable=1)
    
    def only_mandatory_participants(self):
        return RmmJraParticipant.objects.filter(rmm_jrp_jra = self.rmm_jra_id, rmm_jrp_enable=1)    
   
    def __str__(self):
        return self.rmm_jra_created_by_per.full_name
    

    def get_sga_and_attachments(self, person_id):
        obj = self
        ga_data = obj.general_actions.filter(rmm_jga_enable=True, rmm_jga_sga_id__sga_enable=True).annotate(
            sga_recommended_action=F("rmm_jga_sga_id__sga_recommended_action"),
            sga_action_by_when=F("rmm_jga_sga_id__sga_action_by_when"),
            sga_action_is_complete=F("rmm_jga_sga_id__sga_action_is_complete"),
            sga_id=F("rmm_jga_sga_id__sga_id"),
            sga_submission_header=F("rmm_jga_sga_id__sga_submission_header"),
            job = F('rmm_jga_sga_id__sga_submission_header__jobnumber'),
            level = F('rmm_jga_sga_id__sga_submission_header__sitelevel'),
            workplace = F('rmm_jga_sga_id__sga_submission_header__workplace'),
            supervisor = F('rmm_jga_sga_id__sga_submission_header__supervisor'),
            tag_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('rmm_jga_sga_id__sga_submission_header__site')).values('rld_name')[:1]
                ),
            tagtype_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('rmm_jga_sga_id__sga_submission_header__site')).values('rld_tag_type')[:1]
                ),  
            sga_action_type_rld_id=F("rmm_jga_sga_id__sga_action_type_rld_id"),
            sga_completed_action_type_rld_id=F("rmm_jga_sga_id__sga_completed_action_type_rld_id"),
            sga_completed_action_date=F("rmm_jga_sga_id__sga_completed_action_date"),
            sga_completed_action_taken=F("rmm_jga_sga_id__sga_completed_action_taken"),
            sga_created_date=F("rmm_jga_sga_id__sga_created_date"),
            sga_created_by_per=F("rmm_jga_sga_id__sga_created_by_per"),
            sga_modified_date=F("rmm_jga_sga_id__sga_modified_date"),
            sga_modified_by_per=F("rmm_jga_sga_id__sga_modified_by_per"),
            sga_enable=F("rmm_jga_sga_id__sga_enable")).values()
        lng_name = UserProfile.objects.get(upr_per= person_id).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)
        ga_data = ga_data.annotate(
            site = Subquery(
                        LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_site'),ltr_tag_type=OuterRef('tagtype_rld_id_site'), ltr_lng = lng_id).values('ltr_text')[:1]
                    ),
        )

        ga_data = modify_ga_data(ga_data)

        return ga_data

    def get_ha_and_attachments(self, person_id):
        obj = self
        ha_data = obj.hazard_actions.filter(rmm_jha_enable=True, rmm_jha_sha_id__sha_enable=True).annotate(
            id=F("rmm_jha_sha_id__id"),
            submissionheaderid=F("rmm_jha_sha_id__submissionheaderid"),
            tag_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('rmm_jha_sha_id__submissionheaderid__site')).values('rld_name')[:1]
                ),
            tagtype_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('rmm_jha_sha_id__submissionheaderid__site')).values('rld_tag_type')[:1]
                ),
            hazard_type=F("rmm_jha_sha_id__hazard_type"),
            hazard_identification=F("rmm_jha_sha_id__hazard_identification"),
            hazard_description=F("rmm_jha_sha_id__hazard_description"),
            potential_risk=F("rmm_jha_sha_id__potential_risk"),
            immediate_action_required_and_performed=F("rmm_jha_sha_id__immediate_action_required_and_performed"),
            immediate_action_taken=F("rmm_jha_sha_id__immediate_action_taken"),
            immediate_action_type=F("rmm_jha_sha_id__immediate_action_type"),
            further_action_required=F("rmm_jha_sha_id__further_action_required"),
            recommended_action=F("rmm_jha_sha_id__recommended_action"),
            action_type=F("rmm_jha_sha_id__action_type"),
            action_by_when=F("rmm_jha_sha_id__action_by_when"),
            action_completed_date=F("rmm_jha_sha_id__action_completed_date"),
            completed_action_taken=F("rmm_jha_sha_id__completed_action_taken"),
            completed_action_type=F("rmm_jha_sha_id__completed_action_type"),
            hazard_identification_score=F("rmm_jha_sha_id__hazard_identification_score"),
            potential_risk_score=F("rmm_jha_sha_id__potential_risk_score"),
            immediate_action_score=F("rmm_jha_sha_id__immediate_action_score"),
            completed_action_score=F("rmm_jha_sha_id__completed_action_score"),
            is_native_system=F("rmm_jha_sha_id__is_native_system"),
            created_by=F("rmm_jha_sha_id__sha_created_by_per"),
            sha_created_date=F("rmm_jha_sha_id__sha_created_date"),
            sha_created_by_per=F("rmm_jha_sha_id__sha_created_by_per"),
            sha_modified_date=F("rmm_jha_sha_id__sha_modified_date"),
            sha_modified_by_per=F("rmm_jha_sha_id__sha_modified_by_per"),
            sha_enable=F("rmm_jha_sha_id__sha_enable"), ).values()
        lng_name = UserProfile.objects.get(upr_per= person_id).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)
        ha_data = ha_data.annotate(
            site = Subquery(LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_site'),ltr_tag_type=OuterRef('tagtype_rld_id_site'), ltr_lng = lng_id).values('ltr_text')[:1]),
            created_by=Subquery(Person.objects.filter(per_id=OuterRef('sha_created_by_per')).annotate(created_by = Concat('per_last_name',Value(', '), 'per_first_name',output_field = CharField())).values('created_by')[:1])
        )

        ha_data = modify_ha_data(ha_data)

        return ha_data

class RmmJraParticipant(Model):
    rmm_jrp_id = AutoField(primary_key=True)
    rmm_jrp_jra = ForeignKey(RmmJraMaster, blank=False, null=False, 
                             on_delete=models.DO_NOTHING,
                             related_name='participants')
    rmm_jrp_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
                             related_name='rmm_jrp_per_id',
                             help_text="ForeignKey from person/employee Table")
    rmm_jrp_created_date = DateTimeField("Created Date", auto_now_add=True)
    rmm_jrp_created_by_per = ForeignKey(Person, blank=False, null=False, on_delete=models.DO_NOTHING,
                                        related_name='rmm_jrp_created_by_per_id',
                                        help_text="ForeignKey from person Table")
    rmm_jrp_submitted_by_per = ForeignKey(Person, blank=True, null=True,
                                          on_delete=models.DO_NOTHING,
                                          related_name='rmm_jrp_submitted_by_per_id',
                                          help_text="ForeignKey from person Table")
    rmm_jrp_submitted_date = DateTimeField(blank=True, null=True)
    rmm_jrp_modified_date = DateTimeField(blank=True, null=True)
    rmm_jrp_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
                                         related_name='rmm_jrp_modified_by_per_id',
                                         help_text="ForeignKey from person "
                                                   "Table")
    rmm_jrp_enable = BooleanField(default=True)
    rmm_jrp_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_jra_participant'
        # get_latest_by = 'rmm_orp_submitted_date'
        # ordering = ['-rmm_orp_submitted_date', 'rmm_orp_submitted_by_per']
        verbose_name = 'Participant'

    def __str__(self):
        return self.rmm_jra_created_by_per.full_name

class RmmJraApprover(Model):
    rmm_jap_id = AutoField(primary_key=True)
    rmm_jap_jra = ForeignKey(RmmJraMaster, blank=False, null=False, on_delete=models.DO_NOTHING,
                             related_name='approvers',
                             help_text='Foreignkey from rmm_jra table')
    rmm_jap_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
                             related_name='rmm_jap_per_id',
                             help_text='Foreignkey from person/employee table')
    rmm_jap_per_position = SofvieIntegerField(null=True, blank=True)
    rmm_jap_approved = BooleanField(default=False)
    rmm_jap_approved_date = DateTimeField("Approved date", blank=True, null=True)
    rmm_jap_submitted_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
                                          related_name='rmm_jap_submitted_by_per_id',
                                          help_text='Foreignkey from person '
                                                    'table')
    rmm_jap_submitted_date = DateTimeField("Submitted date", blank=True, null=True,)
    rmm_jap_created_date = DateTimeField(auto_now_add=True)
    rmm_jap_created_by_per = ForeignKey(Person, blank=False, null=False, on_delete=models.DO_NOTHING,
                                        related_name='rmm_jap_created_by_per_id')
    rmm_jap_modified_date = DateTimeField(blank=True, null=True)
    rmm_jap_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
                                         related_name='rmm_jap_modified_by_per_id',
                                         help_text='Foreignkey from person '
                                                   'table')
    rmm_jap_enable = BooleanField(default=True)
    rmm_jap_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_jra_approver'
        # get_latest_by = 'rmm_oap_submitted_date'
        # ordering = ['-rmm_oap_submitted_date']
        verbose_name = 'Approver'

    def __str__(self):
        return self.rmm_jap_per.full_name

class RmmJraGeneralAction(Model):
    rmm_jga_id = AutoField(primary_key=True)
    rmm_jga_jra = ForeignKey(RmmJraMaster, on_delete=models.DO_NOTHING,
                             related_name='general_actions',
                             help_text='Primary key from rmm_ora '
                                       'table/RmmOraMaster model'
                             )
    rmm_jga_sga = ForeignKey(SubmissionGeneralAction,
                                on_delete=models.DO_NOTHING,
                                related_name='rmm_jga_sga_id',
                                help_text='Primary key from submission_general_action table/SubmissionGeneralAction model',
                                blank=True, null=True
                             )
    rmm_jga_created_date = DateTimeField(auto_now_add=True)
    rmm_jga_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, 
                                           related_name='rmm_jga_created_by_per_id', 
                                           help_text='Primary key from person '
                                                                                                                                                       'table/Person model')
    rmm_jga_modified_date = DateTimeField(blank=True, null=True)
    rmm_jga_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, 
                                            related_name='rmm_jga_modified_by_per_id',
                                         help_text='Primary key from person table/Person model')
    rmm_jga_enable = BooleanField(default=True)
    rmm_jga_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_jra_general_action'
        verbose_name = 'General Action'

    # def __str__(self):
    #     return self.rmm_jga_sga

class RmmJraHazardAction(Model):
    rmm_jha_id = AutoField(primary_key=True)
    rmm_jha_jra = ForeignKey(RmmJraMaster, on_delete=models.DO_NOTHING, 
                                related_name='hazard_actions',
                                help_text='Primary key from rmm_ora table/RmmOraMaster model')
    rmm_jha_sha = ForeignKey(Submissionhap, on_delete=models.DO_NOTHING, blank=True, null=True,
                                related_name='rmm_jha_sha_id', 
                                help_text='Primary key from SubmissionHap table/Submissionhap model')
    rmm_jha_created_date = DateTimeField(auto_now_add=True)
    rmm_jha_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, 
                                           related_name='rmm_jha_created_by_per_id', 
                                           help_text='Primary key from person table/Person model')
    rmm_jha_modified_date = DateTimeField(blank=True, null=True)
    rmm_jha_modified_by_per = ForeignKey(Person, blank=True, null=True, 
                                            on_delete=models.DO_NOTHING, 
                                            related_name='rmm_jha_modified_by_per_id',
                                            help_text='Primary key from person table/Person model')
    rmm_jha_enable = BooleanField(default=True)
    rmm_jha_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_jra_hazard_action'
        verbose_name = 'Hazard Action'

    def __str__(self):
        return self.rmm_jha_created_by_per.full_name

class RmmJraStepCategory(Model):
    rmm_jsc_id = AutoField(primary_key=True)
    rmm_jsc_jra = ForeignKey(RmmJraMaster, blank=False, null=False, 
                             on_delete=models.DO_NOTHING, 
                             related_name='step_categories', 
                             help_text='Primary key from rmm_jra table/RmmJraMaster model')
    rmm_jsc_step = SofvieCharField(max_length=255, blank=True, null=True)
    rmm_jsc_sort = SofvieIntegerField()    
    rmm_jsc_created_date = DateTimeField(auto_now_add=True)
    rmm_jsc_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, 
                                        related_name='rmm_jsc_created_by_per_id', 
                                        help_text='Primary key from person table/Person model')
    rmm_jsc_modified_date = DateTimeField(blank=True, null=True)
    rmm_jsc_modified_by_per = ForeignKey(Person, blank=True, null=True, 
                                         on_delete=models.DO_NOTHING, 
                                         related_name='rmm_jsc_modified_by_per_id',
                                         help_text='Primary key from person table/person model')
    rmm_jsc_enable = BooleanField(default=True)
    rmm_jsc_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_jra_step_category'
        ordering = ['rmm_jsc_sort']

        verbose_name = 'StepCategory'

    def __str__(self):
        return str(self.rmm_jsc_step)

class RmmJraThreat(Model):
    rmm_jth_id = AutoField(primary_key=True)
    rmm_jth_jsc = ForeignKey(RmmJraStepCategory, 
                             on_delete=models.DO_NOTHING, 
                             related_name='threats', 
                             help_text='Primary key from rmm_jra_step_category table/RmmJraStepCategory model')
    rmm_jth_threat = SofvieTextField(blank=True, null=True)
    rmm_jth_outcome = SofvieTextField(blank=True, null=True)
    rmm_jth_severity_category = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, blank=True, null=True,
                                              related_name='rmm_jth_severity_category_id', 
                                              help_text='Primary key from ref_list_detail table/RefListDetail model')
        
    rmm_jth_likelyhood_preliminary = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,blank=True, null=True,
                                                related_name='rmm_jth_likelyhood_preliminary_id',
                                                help_text='Primary key from ref_list_detail table/RefListDetail model')

    rmm_jth_severity_preliminary = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,blank=True, null=True,
                                              related_name='rmm_jth_severity_preliminary_id', 
                                              help_text='Primary key from ref_list_detail table/RefListDetail model')

    # rmm_jth_preliminary_risk = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, null= True,
    #                                       related_name='rmm_jth_preliminary_risk_id', 
    #                                       help_text='Primary key from ref_list_detail table/RefListDetail model')
    rmm_jth_preliminary_risk = SofvieIntegerField(blank=True, null=True)
    rmm_jth_risk_alara_preliminary = BooleanField(default=False, blank=True, null=True)
    rmm_jth_likelyhood_residual = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, blank=True, null=True,
                                             related_name='rmm_jth_likelyhood_residual_id', 
                                             help_text='Primary key from ref_list_detail table/RefListDetail model')

    rmm_jth_severity_residual = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, blank=True, null=True,
                                            related_name='rmm_jth_serverity_residual_id', 
                                            help_text='Primary key from ref_list_detail table/RefListDetail model')

    # rmm_jth_residual_risk = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,
    #                                    related_name='rmm_jth_residual_risk_id', 
    #                                    help_text='Primary key from ref_list_detail table/RefListDetail model')

    rmm_jth_residual_risk = SofvieIntegerField(blank=True, null=True)

    rmm_jth_risk_alara_residual = BooleanField(default=False, blank=True, null=True)
    rmm_jth_created_date = DateTimeField(auto_now_add=True)
    rmm_jth_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, 
                                        related_name='rmm_jth_created_by_per_id', 
                                        help_text='Primary key from person table/Person model')
    rmm_jth_modified_date = DateTimeField(blank=True, null=True)
    rmm_jth_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, 
                                         related_name='rmm_jth_modified_by_per_id',
                                         help_text='Primary key from person table/Person model')
    rmm_jth_enable = BooleanField(default=True)
    rmm_jth_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_jra_threat'
        # get_latest_by = 'rmm_oev_created_date'
        # ordering = ['-rmm_oev_created_date', 'rmm_oev_major_unwanted_event']
        verbose_name = 'RMM JRA Threat'

    def __str__(self):
        return f"{self.rmm_jth_threat}: created on {self.rmm_jth_created_date} by {self.rmm_jth_created_by_per.full_name}"

class RmmJraTags(Model):
    rmm_jta_id = AutoField(primary_key=True)
    rmm_jta_jth = ForeignKey(RmmJraThreat, on_delete=models.DO_NOTHING, 
                                related_name='tags', 
                                help_text='Primary key from rmm_jth table/RmmJRAEvent model')

    rmm_jta_parent_tag_name = SofvieCharField(max_length=30, blank=True, null=True)
    rmm_jta_tag_name = SofvieCharField(max_length=31, blank=True, null=True)
    rmm_jta_blueline = BooleanField(default=False)
    rmm_jta_created_date = DateTimeField(auto_now_add=True)
    rmm_jta_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, 
                                        related_name='rmm_jta_created_by_per_id',
                                        help_text='Primary key from person table/Person model')
    rmm_jta_modified_date = DateTimeField(blank=True, null=True)
    rmm_jta_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, 
                                         related_name='rmm_jta_modified_by_per_id',
                                         help_text='Primary key from person table/Person model')
    rmm_jta_enable = BooleanField(default=True)
    rmm_jta_enote = SofvieTextField(blank=True, null=True)
    #rmm_ota_parent_tag_name = SofvieCharField(max_length=200)
    
    #tag field - payload from front end
    tag = SofvieCharField(max_length=5000, blank=True, null=True)

    class Meta:
        db_table = 'rmm_jra_tags'
        # get_latest_by = 'rmm_ota_created_date'
        # ordering = ['-rmm_ota_created_date', 'rmm_ota_tag_name']
        verbose_name = 'JRA Tags'

    def __str__(self):
        return self.rmm_jta_tag_name

class RmmJraPraThreat(Model):
    rmm_jpt_id = AutoField(primary_key=True)
    rmm_jpt_jra = ForeignKey(RmmJraMaster, blank=False, null=False, on_delete=models.DO_NOTHING,
                             related_name='pra_threat',
                             help_text='Foreignkey from rmm_jra table')
    rmm_jpt_pth = ForeignKey(RmmPraThreat, blank=False, null=False, on_delete=models.DO_NOTHING,
                             related_name='rmm_jpt_pth_id',
                             help_text='Foreignkey from PRA Threat table')

    rmm_jpt_created_date = DateTimeField(auto_now_add=True)
    rmm_jpt_created_by_per = ForeignKey(Person, blank=False, null=False, on_delete=models.DO_NOTHING,
                                        related_name='rmm_jpt_created_by_per_id')
    rmm_jpt_modified_date = DateTimeField(blank=True, null=True)
    rmm_jpt_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
                                         related_name='rmm_jpt_modified_by_per_id',
                                         help_text='Foreignkey from person '
                                                   'table')
    rmm_jpt_enable = BooleanField(default=True)
    rmm_jpt_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_jra_pra_threat'
        # get_latest_by = 'rmm_oap_submitted_date'
        # ordering = ['-rmm_oap_submitted_date']
        verbose_name = 'JRA PRA Threat'

    def __str__(self):
        return self.rmm_jpt_created_by_per.full_name

class RmmJraReview(Model):
    rmm_jre_id = AutoField(primary_key=True)
    rmm_jre_jra = ForeignKey(RmmJraMaster, on_delete=models.DO_NOTHING, related_name='rmm_jre_jra_master', help_text='Primary key from RmmJraMaster table')
    rmm_jre_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rmm_jre_person',
                             help_text='Primary key from Person table')
    rmm_jre_created_date = DateTimeField(auto_now_add=True)
    rmm_jre_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING,
                                        related_name='rmm_jre_created_by_per',
                                        help_text='Primary key from person table/Person model')
    rmm_jre_modified_date = DateTimeField(blank=True, null=True)
    rmm_jre_modified_by_per = ForeignKey(Person, blank=True, null=True,
                                         on_delete=models.DO_NOTHING, related_name='rmm_jre_modified_by_per',
                                         help_text='Primary key from person table/Person model')
    rmm_jre_enable = BooleanField(default=True)
    rmm_jre_enote = SofvieTextField(blank=True, null=True)
    rmm_jre_position = SofvieIntegerField(null=True, blank=True)

 

    class Meta:
        db_table = 'rmm_jra_review'
        verbose_name = 'JRA Review'