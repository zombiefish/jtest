from django.apps import AppConfig


class FormConfig(AppConfig):
    name = 'apps.form'

    
