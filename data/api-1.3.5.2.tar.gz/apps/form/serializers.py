from rest_framework import serializers
from apps.form.models import form_section, field_data, FormFieldDescription
# from apps.form.models import Person


# class SectionSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = section
#         fields = ('id',
#             'section_name',
#             'section_order',            
#         )


# class Field_dataSerializer(serializers.ModelSerializer):
#     section = SectionSerializer(required=True)
#     class Meta:
#         model = field_data
#         fields = (    
#             'id',
#             'section',
#             'order',
#             'name',
#             'display',
#             'visible',
#             'fieldType',
#             'width'
#         )   
     


# class Field_dataSerializer(serializers.ModelSerializer):
   
#     class Meta:
#         model = field_data
#         fields = (    
#             'id',
#             # 'section',
#             'order',
#             'name',
#             'display',
#             'visible',
#             'fieldType',
#             'width'
#         )  



# class SectionSerializer(serializers.ModelSerializer):
#     field_data = Field_dataSerializer(required=True)
#     class Meta:
#         model = section
#         fields = ('id',
#             'section_name',
#             'section_order',
                      
#         )
 
# class FieldDat_Serializer(serializers.ModelSerializer):
   
#     class Meta:
#         model = field_data
#         fields = [              
#             'order',
#             'name'         
#         ]



# class SectionDat_Serializer(serializers.ModelSerializer):
#     fieldst = FieldDat_Serializer(many = True, read_only=True) 
#     class Meta:
#         model = section
#         fields = [
#             'section_name',
#             'section_order',
#             'fieldst',        
#         ]
              
class FieldDat_Serializer(serializers.ModelSerializer):
    class Meta:
        model = field_data
        fields = '__all__'

class SectionDat_Serializer(serializers.ModelSerializer):
    #field_data = FieldDat_Serializer() 

    class Meta:
        model = form_section
        fields = '__all__'

class FormFieldDescription_Serializer(serializers.ModelSerializer):
    #field_data = FieldDat_Serializer() 

    class Meta:
        model = FormFieldDescription
        fields = '__all__'

# class PersonSerializer(serializers.ModelSerializer):
#     #field_data = FieldDat_Serializer() 

#     class Meta:
#         model = Person
#         # fields = '__all__'

#         fields = ['name','job','quote']   
        