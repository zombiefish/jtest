from django.urls import path
from apps.form import views
from apps.form.views import GetHapsFromFormID


urlpatterns = [     
    path('get-all-top-forms/<str:mode>/', views.GetAllTopForm.as_view()),
    path('get-form-description-by-id/', views.GetFormDescriptionByID.as_view()),
    path('get-form-fields-by-id/', views.GetFormFieldsByID.as_view()),
    path('get-submissions-by-userid-frmdescid/', views.GetSubmissionsByUserIDFrmDescID.as_view()),
    path('get-submissions-by-userid-frmdescid-preop/', views.GetSubmissionsByUserIDFrmDescIDPreop.as_view()),
    path('get-haps-by-frmdescid-preop/', views.GetHapsFromFormID.as_view()),
    path('get-form-category/', views.GetListFormCategory.as_view()),
    path('get-form-category-formbuilder/', views.GetListFormCategoryFormBuilder.as_view()),
    path('get-custom-form-name/', views.GetCustomFormName.as_view()),
] 

