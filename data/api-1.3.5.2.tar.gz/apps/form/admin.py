from django.contrib import admin
# from .models import form_section, field_data
#
# admin.site.register(form_section)
# admin.site.register(field_data)
# admin.site.register(Person)

# Register your models here.
