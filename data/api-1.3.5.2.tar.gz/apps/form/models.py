from django.db import models

# Create your models here.



class Formcategories(models.Model):
    id = models.AutoField(primary_key=True)
    category = models.IntegerField()
    sortorder = models.DecimalField(db_column='SortOrder', max_digits=7,
                                    decimal_places=2, blank=True,
                                    null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'FormCategories'

class Form(models.Model):
    formid = models.IntegerField(db_column='FormID',
                                 primary_key=True)  # Field name made lowercase.
    sortorder = models.DecimalField(db_column='SortOrder', max_digits=7,
                                    decimal_places=2, blank=True,
                                    null=True)  # Field name made lowercase.
    formcategoryid = models.ForeignKey(Formcategories, models.DO_NOTHING,
                                       db_column='FormCategoryId', blank=True,
                                       null=True, related_name='form_category')  # Field name made lowercase.
    frm_enable = models.BooleanField(default=True)

    class Meta:
        db_table = 'Form'


class Mobileforms(models.Model):
    mobileformid = models.AutoField(db_column='MobileFormID',
                                    primary_key=True)  # Field name made lowercase.
    mobileformname = models.IntegerField(db_column='MobileFormName',
                                      blank=True,
                                      null=True)  # Field name made lowercase.
    deleteddate = models.DateTimeField(db_column='DeletedDate', blank=True,
                                       null=True)  # Field name made lowercase.
    formid = models.ForeignKey(Form, models.DO_NOTHING,
                               db_column='FormID',
                               blank=True,
                               null=True, related_name='form_id')  # Field name made lowercase.
    formurl = models.CharField(db_column='FormURL', max_length=255, blank=True,
                               null=True)  # Field name made lowercase.
    mfo_created_date = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    mfo_created_by_per_id = models.ForeignKey('person.Person',
                                              models.DO_NOTHING,
                                              db_column='mfo_created_by_per_id',
                                              related_name='sofvie_form_created',
                                              blank=True, null=True)
    mfo_modified_date = models.DateTimeField(auto_now_add=True,blank=True, null=True)
    mfo_modified_by_per_id = models.ForeignKey('person.Person',
                                               models.DO_NOTHING,
                                               db_column='mfo_modified_by_per_id',
                                               related_name='sofvie_form_modified',
                                               blank=True, null=True)
    mfo_enable = models.BooleanField(default=True)
    mfo_enote = models.CharField(max_length=255, blank=True, null=True)
    

    class Meta:
        managed = True
        db_table = 'MobileForms'

