import json

import pandas as pd
from django.db import connection
from django.db.models import Prefetch, Q, F, Case, When, Value, CharField, Count, DateField, Subquery, OuterRef, IntegerField
from django.db.models.functions import Concat, Cast
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status

# Create your views here.
from apps.common_utils.views.validate_permission import GetRestrictedFormID, RolePermission
from apps.employee.helper_function_user_visibility import helperEmployeeJobs, helperEmployeeSites
from apps.form.models import Mobileforms
from apps.form_builder.api.views.get_form_builder_submissions_by_date import getCustomFormIDs
from apps.form_builder.models import CustomFormMaster, FormBuilder, FormBuilderCategory
from apps.general_action.models import Formdescription, Reports, SubmissionSignoff, Submissionheader, PreopSubmissionHeader
from apps.hazard_action.models import SubmissiondetailsExplode
from apps.incident_management.api.utlity_function import dictfetchall
from apps.rmm_ora.api.date_filter_utils import full_date_filter
from apps.user_settings_profile.models import UserProfile
from apps.language.models import Language, LanguageTranslation
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.wafs.api.helper_functions.wafs_form_handling_engine import getIncidentStatusBySHIDs



class GetCustomFormName(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def post(self, request):
        person_instance = self.request.user.user_per_id
        user_lang = UserProfile.objects.get(upr_per=person_instance).upr_language
        lang_id = Language.objects.get(lng_name = user_lang)
        id = request.data['fob_id']

        activeFormData = FormBuilder.objects.filter(fob_id = id).annotate(
            active_form = Subquery(LanguageTranslation.objects.filter(
                    ltr_tag=OuterRef('fob_name'),
                    ltr_tag_type = OuterRef('fob_tag_type'),
                    ltr_lng_id = lang_id
                ).values("ltr_text")[:1]
            )).values('active_form')
        return Response(activeFormData)

class GetAllTopForm(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)
    """ Response for the All top forms """

    def get(self, request, mode):
        person_instance = self.request.user.user_per_id
        user_lang = UserProfile.objects.get(upr_per=person_instance).upr_language
        lng_id = Language.objects.get(lng_name = user_lang).lng_id

        form_list = get_all_form_list(lng_id, mode)

        return Response(form_list)

def get_all_form_list(lng_id, mode):

    with connection.cursor() as cursor:
        cursor.execute("call get_all_top_forms(%s, %s)", ([lng_id], [mode]))
        #send mode to sp and send lng_id instead of lng_name - - - 
        form_list = dictfetchall(cursor)
    
    if mode == 'all':
        # get additional forms when mode = all - line up and Employee Departure
        form_list = additional_forms(form_list, lng_id)
        form_list = map(lambda obj: add_inactive(obj), form_list)

    inactive_label = LanguageTranslation.objects.get(ltr_tag = 3793, ltr_tag_type = 1, ltr_lng_id = lng_id).ltr_text

    def add_inactive(obj):
        if obj['status_flag'] == 0:
            obj['FormName']   = f"{obj['FormName']} ({inactive_label})"
        return obj
    
    return form_list

def additional_forms(form_list, lng_id):
    # additioanl form ids to include employee departure and lineup in selection
    from apps.form.models import Mobileforms
    mobile_form_ids = list(Mobileforms.objects.exclude(
                formid__isnull = True
            ).values_list('formid', flat = True))
    additional_form_ids = Reports.objects.exclude(
        Q(singleformreportid__in = mobile_form_ids) | Q(singleformreportid = 131200)
    ).annotate(
        FormID = F('singleformreportid'),
        status_flag = F('rpt_enable'),
        FormName = Subquery(
            LanguageTranslation.objects.filter(
                ltr_tag = OuterRef('reportname'),
                ltr_tag_type = 1,
                ltr_lng = lng_id
            ).values('ltr_text')[:1]
        )        
    ).exclude(
        FormID__isnull = True,        
    ).filter(
        rpt_enable = True
    ).values('FormID','status_flag', 'FormName')
        
    form_list = form_list + list(additional_form_ids)
    
    return form_list


class GetFormDescriptionByID(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)
    """ Return the execution SP to get a list of form description """

    def post(self, request):
        formDescID = request.data['id']
        person_instance = self.request.user.user_per_id
        user_lang = UserProfile.objects.get(upr_per = person_instance).upr_language
        with connection.cursor() as cursor:
            cursor.execute("CALL get_form_description_by_id(%s, %s)", ([formDescID], [user_lang]))
            row = dictfetchall(cursor)
        return Response(row)


class GetFormFieldsByID(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)
    """ Return the execution SP to get a list of form fields """

    def post(self, request):
        formDescID = request.data['id']
        person_instance = self.request.user.user_per_id
        user_lang = UserProfile.objects.get(upr_per= person_instance).upr_language
        with connection.cursor() as cursor:
            cursor.execute(
                "CALL get_form_field_list_by_form_description_id(%s,%s)",
                ([formDescID], [user_lang]))
            row = dictfetchall(cursor)
        return Response(row)


class GetSubmissionsByUserIDFrmDescIDPreop(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)
    """ Return the execution SP to get a list of Preop data """

    def post(self, request):
        person_id = request.user.user_per_id
        get_sites, data_user_visibility = helperEmployeeSites(self, person_id)
        get_jobs, data_user_visibility = helperEmployeeJobs(self, person_id)

        site_list = [site['rld_id'] for site in get_sites]
        job_list = [job['rld_id'] for job in get_jobs]

        start_date = request.data['start_date']
        end_date = request.data['end_date']
        

        site_filters = []
        job_filters = []
        if data_user_visibility != 'all':
            site_filters = [Q(psh_submissionheader_id__site__in=site_list)]
            job_filters = [Q(psh_submissionheader_id__jobnumber__in=job_list)]
        user_lang = UserProfile.objects.get(upr_per = person_id).upr_language
        lang_id = Language.objects.get(lng_name = user_lang)
        queryset = PreopSubmissionHeader.objects.filter(
            *site_filters,
            *job_filters,
            psh_submissionheader_id__formsubmissiondate__range=full_date_filter(start_date, end_date),
            preop_submission_header_value__psv_preop_question_identifier='machine_number',
        ).annotate(
            EquipDesc=Subquery(LanguageTranslation.objects.filter(
                ltr_tag = OuterRef('psh_pet_id__pet_poe_id__poe_equip_description'),
                ltr_tag_type = OuterRef('psh_pet_id__pet_poe_id__poe_tag_type'),
                ltr_lng = lang_id
            ).values('ltr_text')[:1]),
            comments=F("preop_submission_header_value__psv_value")
        ).prefetch_related(
            "preop_submission_header_value"
        ).values(
            "psh_pet_id__pet_equipment_identifier",
            "psh_submissionheader_id",
            "EquipDesc",
            "comments"
        )

        return Response(queryset)


class GetSubmissionsByUserIDFrmDescID(APIView):
    permission_classes = [SofviePermission]
    """ Return the execution SP to get a list of form fields by permission """

    def get_submission_list_by_user_and_form_description_id(self, data_visibility_type, formDescID, start_date,
                                                            end_date, permission_access, userId, site_list, job_list, allowed_shids= None):
        filters = {}
        if permission_access == 0:
            filters['submittedby_supervisorid'] = userId

        site_filters = []
        job_filters = []
        if data_visibility_type != 'all':
            site_filters = [Q(site__in=site_list) | Q(submittedby_supervisorid=userId)]
            job_filters = [Q(jobnumber__in=job_list) | Q(submittedby_supervisorid=userId)]
        
        shids_filter = []
        if allowed_shids != None:
            shids_filter = [Q(id__in = allowed_shids)]

        formId = Formdescription.objects.filter(id=formDescID)
        formList = Formdescription.objects.filter(formid=formId[0].formid).values_list('id')
        user_lang = UserProfile.objects.get(upr_per = userId).upr_language
        lang_id = Language.objects.get(lng_name = user_lang).lng_id
        data = Submissionheader.objects.filter(
            Q(isarchived__isnull=True) | Q(isarchived=False),
            *site_filters,
            *job_filters,
            *shids_filter,
            formdescriptionid__in=formList,
            formsubmissiondate__range=full_date_filter(start_date, end_date),
            **filters,            
        ).annotate(
            ID=F('id'),
            SubmissionId=F('submissionid'),
            Duration=Case(
                When(duration=0, then=Value('0 minutes')),
                When(duration=15, then=Value('15 minutes')),
                When(duration=45, then=Value('45 minutes')),
                When(duration=60, then=Value('1 Hour')),
                When(duration=90, then=Value('1.5 Hours')),
                When(duration=120, then=Value('2 Hours')),
                When(duration=180, then=Value('3 Hours')),
                When(duration=240, then=Value('Over 3 Hours')),
                default=Value(''),
                output_field=CharField()
            ),
            FormCreationDate=F('formcreationdate'),
            FormSubmissionDate=F('formsubmissiondate'),
            signoffCount=Count('submission_signoff'),
            HeaderDate=Cast('headerdate', DateField()),
            JobNumber=Subquery(RefListDetail.objects.filter(rld_id=OuterRef('jobnumber')).values('rld_code')[:1]),
            Site_tag=Subquery(RefListDetail.objects.filter(rld_id=OuterRef('site')).values('rld_name')[:1]),
            SiteLevel_tag=Subquery(RefListDetail.objects.filter(rld_id=OuterRef('sitelevel')).values('rld_name')[:1]),
            Site_tagtype=Subquery(RefListDetail.objects.filter(rld_id=OuterRef('site')).values('rld_tag_type')[:1]),
            SiteLevel_tagtype=Subquery(RefListDetail.objects.filter(rld_id=OuterRef('sitelevel')).values('rld_tag_type')[:1]),
            Workplace=F('workplace'),
            HeaderSupervisor=F('supervisor'),
            SubmittedBy=Concat(
                "submittedby_supervisorid__per_last_name", Value(", "),
                "submittedby_supervisorid__per_first_name",
                output_field=CharField(),)

        ).prefetch_related(
            'submission_detail',
            Prefetch('submission_detail__submission_detail_explode'),
            'submission_signoff',
        ).values(
            'ID',
            'FormCreationDate',
            'FormSubmissionDate',
            'HeaderDate',
            'Site_tag',
            'Site_tagtype',
            'JobNumber',
            'SiteLevel_tag',
            'SiteLevel_tagtype',
            'Workplace',
            'HeaderSupervisor',
            'Duration',
            'signoffCount',
            'SubmissionId',
            'SubmittedBy'
        ).order_by('-formsubmissiondate')

        translate_data = data.annotate(
            Site = Subquery(LanguageTranslation.objects.filter(
                    ltr_tag=OuterRef('Site_tag'),
                    ltr_tag_type = OuterRef('Site_tagtype'),
                    ltr_lng_id = lang_id
                ).values("ltr_text")[:1]
            ),
            SiteLevel = Subquery(LanguageTranslation.objects.filter(
                    ltr_tag=OuterRef('SiteLevel_tag'),
                    ltr_tag_type =OuterRef('SiteLevel_tagtype'),
                    ltr_lng_id = lang_id
                ).values("ltr_text")[:1]
            )
        ).values(
            'ID',
            'FormCreationDate',
            'FormSubmissionDate',
            'HeaderDate',
            'Site',
            'JobNumber',
            'SiteLevel',
            'Workplace',
            'HeaderSupervisor',
            'Duration',
            'signoffCount',
            'SubmissionId',
            'SubmittedBy'
        )

        submission_header_ids = []
        for each in data:
            if each['ID'] not in submission_header_ids:
                submission_header_ids.append(each['ID'])

        get_signoffs = SubmissionSignoff.objects.filter(SubmissionHeaderID__in=submission_header_ids).values(
            'SubmissionHeaderID_id', 'SigningAccount', 'ID')

        signed_list = [each['SubmissionHeaderID_id'] for each in get_signoffs if each['SigningAccount'] == str(userId)]

        submission_incident_status = {}
        # Fetching the Incident status for forms Preliminary Incident and Investigation
        if formDescID in ['1338','1329']:
            submission_incident_status = getIncidentStatusBySHIDs(submission_header_ids)
        for each in translate_data:
            if each['ID'] in signed_list:
                each['MySignoffID'] = 1
            else:
                each['MySignoffID'] = 0
            if each['ID'] in list(submission_incident_status.keys()):
                each["IncidentSignedOffStatus"] = submission_incident_status[each['ID']]
            else:
                each["IncidentSignedOffStatus"] = "NA"
        if submission_header_ids:
            exclude_field_keys = ['site','level', 'job_number']
            get_explode_data = SubmissiondetailsExplode.objects.filter(
                submissiondetailid__submissionheaderid__in=submission_header_ids,
            ).exclude(formfielddescriptionid__fieldkey__in=exclude_field_keys).annotate(
                fieldname = Subquery(LanguageTranslation.objects.filter(
                    ltr_tag=OuterRef('formfielddescriptionid__fieldname'),
                    ltr_tag_type = 1,
                    ltr_lng_id = 1
                ).values("ltr_text")[:1])
            ).values(
                'submissiondetailid__submissionheaderid',
                'value',
                'fieldname',
                'formfielddescriptionid__fieldtype',
                'formfielddescriptionid__fieldkey'
            )

            df = pd.DataFrame(get_explode_data)
            if len(df) > 0 and int(formDescID) == 1415:
                df = df.apply(lambda x: self.translateValue(x, lang_id), axis=1)
            if len(df) > 0:
                df = (df.groupby(['submissiondetailid__submissionheaderid', 'fieldname'])
                    .agg({'value': lambda x: "; ".join(filter(None, x))}).reset_index())

                ppdict = {n: grp.loc[n].to_dict('index')
                    for n, grp in
                    df.set_index(['submissiondetailid__submissionheaderid', 'fieldname']).groupby(
                        level='submissiondetailid__submissionheaderid')}

                final_output = json.loads(json.dumps(ppdict, indent=2))
            else:
                final_output = {}
            
            for each in translate_data:
                if str(each['ID']) in list(final_output.keys()):
                    field_key_data = final_output[str(each['ID'])]
                    for key, value in field_key_data.items():  
                        value = value['value']
                        field_key_data[key] = value
                    each.update(field_key_data)

            return translate_data
        else:
            return translate_data

    def translateValue(self, row, lang_id):
        if row['formfielddescriptionid__fieldtype'] == 'GlobalListPicker' and not row['formfielddescriptionid__fieldkey'] in ['distribution', 'Report_Distribution1', 'equipment_id'] and row['value']:
            row['value'] = RefListDetail.objects.filter(
                rld_id = row['value']
            ).annotate(
                rld_name_text = Subquery(LanguageTranslation.objects.filter(
                    ltr_tag=OuterRef('rld_name'),
                    ltr_tag_type = OuterRef('rld_tag_type'),
                    ltr_lng_id = lang_id
                ).values("ltr_text")[:1])
            ).values_list("rld_name_text", flat = True)[0]
        return row

    def get_submission_list_by_user_and_form_description_id_custom(self, data_visibility_type, formDescID, start_date,
                                                            end_date, permission_access, userId, site_list, job_list, allowed_shids= None):
        filters = {}
        if permission_access == 0:
            filters['submittedby_supervisorid'] = userId

        site_filters = []
        job_filters = []
        if data_visibility_type != 'all':
            site_filters = [Q(site__in=site_list) | Q(submittedby_supervisorid=userId)]
            job_filters = [Q(jobnumber__in=job_list) | Q(submittedby_supervisorid=userId)]
        
        shids_filter = []
        if allowed_shids != None:
            shids_filter = [Q(id__in = allowed_shids)]

       
        submissionHeaderIds = CustomFormMaster.objects.filter(cfm_fob_id = int(formDescID)).values_list('cfm_submission_header_id', flat=True)
        user_lang = UserProfile.objects.get(upr_per = userId).upr_language
        lang_id = Language.objects.get(lng_name = user_lang).lng_id
        data = Submissionheader.objects.filter(
            Q(isarchived__isnull=True) | Q(isarchived=False),
            *site_filters,
            *job_filters,
            *shids_filter,
            id__in = submissionHeaderIds,
            formdescriptionid=1403,
            formsubmissiondate__range=full_date_filter(start_date, end_date),
            **filters,            
        ).annotate(
            ID=F('id'),
            SubmissionId=F('submissionid'),
            Duration=Case(
                When(duration=0, then=Value('0 minutes')),
                When(duration=15, then=Value('15 minutes')),
                When(duration=45, then=Value('45 minutes')),
                When(duration=60, then=Value('1 Hour')),
                When(duration=90, then=Value('1.5 Hours')),
                When(duration=120, then=Value('2 Hours')),
                When(duration=180, then=Value('3 Hours')),
                When(duration=240, then=Value('Over 3 Hours')),
                default=Value(''),
                output_field=CharField()
            ),
            FormCreationDate=F('formcreationdate'),
            FormSubmissionDate=F('formsubmissiondate'),
            signoffCount=Count('submission_signoff'),
            HeaderDate=Cast('headerdate', DateField()),
            JobNumber=Subquery(RefListDetail.objects.filter(rld_id=OuterRef('jobnumber')).values('rld_code')[:1]),
            Site_tag=Subquery(RefListDetail.objects.filter(rld_id=OuterRef('site')).values('rld_name')[:1]),
            SiteLevel_tag=Subquery(RefListDetail.objects.filter(rld_id=OuterRef('sitelevel')).values('rld_name')[:1]),
            Site_tagtype=Subquery(RefListDetail.objects.filter(rld_id=OuterRef('site')).values('rld_tag_type')[:1]),
            SiteLevel_tagtype=Subquery(RefListDetail.objects.filter(rld_id=OuterRef('sitelevel')).values('rld_tag_type')[:1]),
            Workplace=F('workplace'),
            HeaderSupervisor=F('supervisor'),
            SubmittedBy=Concat(
                "submittedby_supervisorid__per_last_name", Value(", "),
                "submittedby_supervisorid__per_first_name",
                output_field=CharField(),)

        ).prefetch_related(
            'submission_detail',
            Prefetch('submission_detail__submission_detail_explode'),
            'submission_signoff',
        ).values(
            'ID',
            'FormCreationDate',
            'FormSubmissionDate',
            'HeaderDate',
            'Site_tag',
            'Site_tagtype',
            'JobNumber',
            'SiteLevel_tag',
            'SiteLevel_tagtype',
            'Workplace',
            'HeaderSupervisor',
            'Duration',
            'signoffCount',
            'SubmissionId',
            'SubmittedBy'
        ).order_by('-formsubmissiondate')

        translate_data = data.annotate(
            Site = Subquery(LanguageTranslation.objects.filter(
                    ltr_tag=OuterRef('Site_tag'),
                    ltr_tag_type = OuterRef('Site_tagtype'),
                    ltr_lng_id = lang_id
                ).values("ltr_text")[:1]
            ),
            SiteLevel = Subquery(LanguageTranslation.objects.filter(
                    ltr_tag=OuterRef('SiteLevel_tag'),
                    ltr_tag_type =OuterRef('SiteLevel_tagtype'),
                    ltr_lng_id = lang_id
                ).values("ltr_text")[:1]
            )
        ).values(
            'ID',
            'FormCreationDate',
            'FormSubmissionDate',
            'HeaderDate',
            'Site',
            'JobNumber',
            'SiteLevel',
            'Workplace',
            'HeaderSupervisor',
            'Duration',
            'signoffCount',
            'SubmissionId',
            'SubmittedBy'
        )

        submission_header_ids = []
        for each in data:
            if each['ID'] not in submission_header_ids:
                submission_header_ids.append(each['ID'])

        get_signoffs = SubmissionSignoff.objects.filter(SubmissionHeaderID__in=submission_header_ids).values(
            'SubmissionHeaderID_id', 'SigningAccount', 'ID')

        signed_list = [each['SubmissionHeaderID_id'] for each in get_signoffs if each['SigningAccount'] == str(userId)]

        submission_incident_status = {}
        # Fetching the Incident status for forms Preliminary Incident and Investigation
        if formDescID in ['1338','1329']:
            submission_incident_status = getIncidentStatusBySHIDs(submission_header_ids)
        for each in translate_data:
            if each['ID'] in signed_list:
                each['MySignoffID'] = 1
            else:
                each['MySignoffID'] = 0
            if each['ID'] in list(submission_incident_status.keys()):
                each["IncidentSignedOffStatus"] = submission_incident_status[each['ID']]
            else:
                each["IncidentSignedOffStatus"] = "NA"
        if submission_header_ids:
            exclude_field_keys = ['site','level', 'job_number']
            get_explode_data = SubmissiondetailsExplode.objects.filter(
                submissiondetailid__submissionheaderid__in=submission_header_ids,
            ).exclude(formfielddescriptionid__fieldkey__in=exclude_field_keys).annotate(
                fieldname = Subquery(LanguageTranslation.objects.filter(
                    ltr_tag=OuterRef('formfielddescriptionid__fieldname'),
                    ltr_tag_type = 1,
                    ltr_lng_id = 1
                ).values("ltr_text")[:1])
            ).values(
                'submissiondetailid__submissionheaderid',
                'value',
                'fieldname'
            )

            df = pd.DataFrame(get_explode_data)
            if len(df) > 0:
                df = (df.groupby(['submissiondetailid__submissionheaderid', 'fieldname'])
                    .agg({'value': lambda x: "; ".join(filter(None, x))}).reset_index())

                ppdict = {n: grp.loc[n].to_dict('index')
                    for n, grp in
                    df.set_index(['submissiondetailid__submissionheaderid', 'fieldname']).groupby(
                        level='submissiondetailid__submissionheaderid')}

                final_output = json.loads(json.dumps(ppdict, indent=2))
            else:
                final_output = {}
            
            for each in translate_data:
                if str(each['ID']) in list(final_output.keys()):
                    field_key_data = final_output[str(each['ID'])]
                    for key, value in field_key_data.items():  
                        value = value['value']
                        field_key_data[key] = value
                    each.update(field_key_data)

            return translate_data
        else:
            return translate_data



    def post(self, request):
        userId = self.request.user.user_per_id_id
        formDescID = request.data['frmdescid']        
        start_date = request.data['start_date']
        end_date = request.data['end_date']
                 
        if len(formDescID.split('-')) > 1:
            form_type = formDescID.split('-')[0]
            formDescID = formDescID.split('-')[1]
        else:
            form_type =  'pre-defined'
        get_sites, data_visibility_type = helperEmployeeSites(self, userId)
        get_jobs, data_visibility_type = helperEmployeeJobs(self, userId)
        site_list = [site['rld_id'] for site in get_sites]
        # site_list = []
        permission_access = 1

        VFL_AUDIT_FORM = [138900] #VFL AUDIT FORMID
        DAILY_LOG = [336724] #DAILY LOG FORM ID
        LINEUP = [888888] #DAILY LOG FORM ID
        INCIDENTFORMS = [224335, 220234] #PRELIMINARY INCIDENT & PRELIMINARY INVESTIGATION
        HUMAN_RESOURCES = [248310, 339913, 248322, 372328, 372318] # HUMAN RESOURCES FORMID

        restricted_form = GetRestrictedFormID(formDescID)
        if restricted_form != [] and form_type == 'pre-defined':            

            if restricted_form[0]['FormID'] in INCIDENTFORMS:  # PRELIMINARY INCIDENT & PRELIMINARY INVESTIGATION
                per = SofviePermission()
                self.permission_attrs = [RolePermission.CanViewOwnIncidentSubmissions.value]
                own_incident_content = per.has_permission(request, self)
                self.permission_attrs = [RolePermission.CanViewAllIncidentSubmissions.value]
                all_incident_content = per.has_permission(request, self)

                job_list = [job['rld_id'] for job in get_jobs]

                if all_incident_content:

                    data = self.get_submission_list_by_user_and_form_description_id(data_visibility_type, formDescID,
                                                                                    start_date, end_date,
                                                                                    permission_access, userId,
                                                                                    site_list, job_list)
                    return Response(data)


                elif own_incident_content:
                    permission_access = 0
                    data = self.get_submission_list_by_user_and_form_description_id(data_visibility_type, formDescID,
                                                                                    start_date, end_date,
                                                                                    permission_access, userId,
                                                                                    site_list, job_list)
                    return Response(data)
                   

                else:
                    return Response({
                        'accessMsg': 'Access denied - You do not have any access'})

            if restricted_form[0]['FormID'] in VFL_AUDIT_FORM:  # VFL Audit Form
                per = SofviePermission()
                self.permission_attrs = [RolePermission.CanViewOwnManagementSubmissions.value]
                own_management_content = per.has_permission(request, self)
                self.permission_attrs = [RolePermission.CanViewAllManagementSubmissions.value]
                all_management_content = per.has_permission(request, self)

                job_list = [job['rld_id'] for job in get_jobs]

                if all_management_content:

                    data = self.get_submission_list_by_user_and_form_description_id(data_visibility_type, formDescID,
                                                                                    start_date, end_date,
                                                                                    permission_access, userId,
                                                                                    site_list, job_list)
                    return Response(data)


                elif own_management_content:
                    permission_access = 0
                    data = self.get_submission_list_by_user_and_form_description_id(data_visibility_type, formDescID,
                                                                                    start_date, end_date,
                                                                                    permission_access, userId,
                                                                                    site_list, job_list)
                    return Response(data)
                   

                else:
                    return Response({
                        'accessMsg': 'Access denied - You do not have any access'})

            if restricted_form[0]['FormID'] in DAILY_LOG:  # 'Daily Log'

                job_list = [job['rld_id'] for job in get_jobs]

                daily_log_per = SofviePermission()
                self.permission_attrs = [
                    RolePermission.CanViewOwnDailyLog.value]
                own_daily_log = daily_log_per.has_permission(request, self)
                self.permission_attrs = [
                    RolePermission.CanViewAllDailyLog.value]
                all_daily_log = daily_log_per.has_permission(request, self)

                if all_daily_log:

                    data = self.get_submission_list_by_user_and_form_description_id(data_visibility_type, formDescID,
                                                                                    start_date, end_date,
                                                                                    permission_access, userId,
                                                                                    site_list, job_list)


                    return Response(data)
                elif own_daily_log:
                    permission_access = 0
                    data = self.get_submission_list_by_user_and_form_description_id(data_visibility_type, formDescID,
                                                                                    start_date, end_date,
                                                                                    permission_access, userId,
                                                                                    site_list, job_list)
                    return Response(data)                    
                else:

                    return Response({
                        'accessMsg': 'Access denied - You do not have any access'})

            if restricted_form[0]['FormID'] in LINEUP:  # 'Lineup'
                job_list = [job['rld_id'] for job in get_jobs]               

                data = self.get_submission_list_by_user_and_form_description_id(data_visibility_type, formDescID, start_date, end_date , permission_access, userId, site_list, job_list)                    
                    

                return Response(data)               


            if restricted_form[0]['FormID'] in HUMAN_RESOURCES: # 'Human Resources'

                hr_per = SofviePermission()
                self.permission_attrs = [
                    RolePermission.ViewOwnHRSubmissions.value]
                own_hr_content = hr_per.has_permission(request, self)
                self.permission_attrs = [
                    RolePermission.ViewAllHRSubmissions.value]
                all_hr_content = hr_per.has_permission(request, self)

                job_list = [job['rld_id'] for job in get_jobs]

                if all_hr_content:

                    data = self.get_submission_list_by_user_and_form_description_id(data_visibility_type, formDescID,
                                                                                    start_date, end_date,
                                                                                    permission_access, userId,
                                                                                    site_list, job_list)
                    return Response(data)                   
                elif own_hr_content:

                    permission_access = 0
                    data = self.get_submission_list_by_user_and_form_description_id(data_visibility_type, formDescID,
                                                                                    start_date, end_date,
                                                                                    permission_access, userId,
                                                                                    site_list, job_list)
                    return Response(data)                    
                else:
                    return Response({'accessMsg': 'Access denied - You do not have any access'})

        elif restricted_form == [] and form_type == 'pre-defined':
            job_list = [job['rld_id'] for job in get_jobs]
            allowed_shids = None  
            data = self.get_submission_list_by_user_and_form_description_id(data_visibility_type, formDescID,
                                                                            start_date, end_date, permission_access,
                                                                            userId, site_list, job_list, allowed_shids)
            return Response(data) 
        
        elif form_type == 'custom':

            job_list = [job['rld_id'] for job in get_jobs]
            
            allowed_shids = None
            if formDescID == '1403':
                allowed_shids = self.get_allowed_submission_headers(userId)                

            data = self.get_submission_list_by_user_and_form_description_id_custom(data_visibility_type, formDescID,
                                                                            start_date, end_date, permission_access,
                                                                            userId, site_list, job_list, allowed_shids)

            return Response(data)            

    def get_allowed_submission_headers(self, person_id):
        allowed_form_builder_ids = getCustomFormIDs(self, person_id)
        allowed_shids = CustomFormMaster.objects.filter(
            cfm_fob_id__in = allowed_form_builder_ids
        ).values_list('cfm_submission_header_id')
        
        return allowed_shids
"""
1. Base on FormDescriptionID find the formID and use that ID for permission
2. Basic permission all (NOTE: nothing is compulsory)
3. They can see all the form but not management, daily log and HR
4. Set the permission so user can see own vfl audit form, daily log, and HR 
    content
5. Set the permission so user can see all vfl audit form, all daily log, 
    and all HR content

"""


class Field:
    def __init__(self, order):
        self.order = order
        # self.fname = fname


class Personst(object):
    Fields = []

    # def __init__(self, SectionName, SectionOrder,Field):
    def load(self, SectionName, SectionOrder, Field):
        self.SectionName = SectionName
        self.SectionOrder = SectionOrder
        obj = Field.__new__(Field)
        self.__dict__.update(Field)


def convert_to_dict(obj):
    """
    A function takes in a custom object and returns a dictionary representation of the object.
    This dict representation includes meta data such as the object's module and class names.
    """
    #  Populate the dictionary with object meta data 
    obj_dict = {
        # "class": obj.__class__.__name__,
        # "module": obj.__module__
    }

    #  Populate the dictionary with object properties
    obj_dict.update(obj.__dict__)

    return obj_dict

class GetHapsFromFormID(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def post(self, request):
        startdate = request.data['start_date']
        enddate = request.data['end_date']
        formid = request.data['form_id']

        with connection.cursor() as cursor:
            cursor.execute("CALL get_hazard_by_form_and_date(%s,%s,%s) ", [formid, startdate, enddate])
            row = dictfetchall(cursor)

        return Response(row)



def get_pre_defined_categories(self):
    pre_defined_categories = Mobileforms.objects.filter(
        mfo_enable = True
    ).exclude(
        formid = 777777
    ).annotate(
        form_tag_id = F('mobileformname'),            
        selected = Value(False),            
        MobileFormName = Subquery(
            LanguageTranslation.objects.filter(
                ltr_tag = OuterRef('mobileformname'),
                ltr_lng = self.lng_id,
                ltr_tag_type = 1,
                ltr_enable = True
            ).values('ltr_text')[:1]
        ),
        category = Subquery(
            LanguageTranslation.objects.filter(
                ltr_tag = OuterRef('formid__formcategoryid__category'),
                ltr_lng = self.lng_id,
                ltr_tag_type = 1,
                ltr_enable = True
            ).values('ltr_text')[:1]
        ),
        FormID = F('formid')
    ).values(
        'mobileformid',
        'MobileFormName',
        'form_tag_id',
        'formurl',
        'FormID',
        'selected',
        'category',
        'formid__formcategoryid'
    ).order_by(
        'formid__formcategoryid__sortorder',
        'category',
        'MobileFormName'
    )

    return pre_defined_categories


def get_custom_categories(self):
    custom_categories = FormBuilder.objects.filter(
        fob_enable = True,
        fob_fca_id__isnull = True,
        fob_fbc__fbc_enable = True
    ).annotate(
        FormID = F('fob_id'),
        MobileFormName = Subquery(
            LanguageTranslation.objects.filter(
                ltr_tag = OuterRef('fob_name'),
                ltr_lng = self.lng_id,
                ltr_tag_type = OuterRef('fob_tag_type'),
                ltr_enable = True
            ).values('ltr_text')[:1]
        ),
        category = Subquery(
            LanguageTranslation.objects.filter(
                ltr_tag = OuterRef('fob_fbc__fbc_name'),
                ltr_lng = self.lng_id,
                ltr_tag_type = OuterRef('fob_fbc__fbc_tag_type'),
                ltr_enable = True
            ).values('ltr_text')[:1]
        ),
        selected = Value(False),
    ).values(
        'FormID',
        'MobileFormName',
        'category',
        'selected',
        'fob_fbc_id'
    )   

    return custom_categories


def get_custom_forms_pre_defined_categories(self):
    custom_forms_pre_defined_categories = FormBuilder.objects.filter(
        fob_enable = True,
        fob_fbc_id__isnull = True
    ).annotate(
        FormID = F('fob_id'),
        MobileFormName = Subquery(
            LanguageTranslation.objects.filter(
                ltr_tag = OuterRef('fob_name'),
                ltr_lng = self.lng_id,
                ltr_tag_type = OuterRef('fob_tag_type'),
                ltr_enable = True
            ).values('ltr_text')[:1]
        ),
        category = Subquery(
            LanguageTranslation.objects.filter(
                ltr_tag = OuterRef('fob_fca__category'),
                ltr_lng = self.lng_id,
                ltr_tag_type = 1,
                ltr_enable = True
            ).values('ltr_text')[:1]
        ),
        selected = Value(False),
        type = Value('custom-predefined_form')
    ).values(
        'FormID',
        'MobileFormName',
        'category',
        'selected',
        'fob_fbc_id',
        'type'
    )

    return custom_forms_pre_defined_categories

def create_category_groups(data):
    category_list = []
    data_df = pd.DataFrame(data).fillna('')
    if not data_df.empty:
        category_group = data_df.groupby('category')
        for category, form_data in category_group:
            temp = {}
            temp['category'] = category
            temp['category_selected'] = False
            if len(form_data.index) > 0:
                temp['form_data'] = form_data.to_dict(orient="records")
            category_list.append(temp.copy())
    return category_list
    

class GetListFormCategory(APIView):
    permission_classes = [SofviePermission]    
    permission_attrs = (RolePermission.CanViewAccess.value,)

    def get(self, request):
        self.person_id = self.request.user.user_per_id_id

        try:
            language = UserProfile.objects.get(upr_per_id=self.person_id).upr_language
            self.lng_id = Language.objects.get(lng_name=language).lng_id       
            

            pre_defined_categories = get_pre_defined_categories(self)
            custom_forms_pre_defined_categories = get_custom_forms_pre_defined_categories(self)

            pre_defined_categories = list(pre_defined_categories) + list(custom_forms_pre_defined_categories)
            pdc = create_category_groups(pre_defined_categories)           
            

            custom_categories = get_custom_categories(self)
            cc = create_category_groups(custom_categories)
            
            form_categories = {
                'pre_defined_categories' : pdc,
                'custom_categories': cc
            }

            return Response(form_categories, status = status.HTTP_200_OK)
        
        except Exception as e:
            return Response({'message': str(e)}, status = status.HTTP_400_BAD_REQUEST)


class GetListFormCategoryFormBuilder(APIView):
    permission_classes = [SofviePermission]    
    permission_attrs = (RolePermission.CanManageCustomForms.value,)

    def get(self, request):

        self.person_id = self.request.user.user_per_id_id
        try:
            language = UserProfile.objects.get(upr_per_id=self.person_id).upr_language
            self.lng_id = Language.objects.get(lng_name=language).lng_id

            pre_defined_categories = get_pre_defined_categories(self)

            pre_defined_categories = pre_defined_categories.annotate(
                type = Value('Pre-Defined Categories'),
                category_id = F('formid__formcategoryid')
            ).values('category_id', 'category', 'type').order_by('category').distinct()

            custom_categories = FormBuilderCategory.objects.filter(        
                fbc_enable = True
            ).annotate(
                category_id = F('fbc_id'),
                category = Subquery(
                    LanguageTranslation.objects.filter(
                        ltr_tag = OuterRef('fbc_name'),
                        ltr_lng = self.lng_id,
                        ltr_tag_type = OuterRef('fbc_tag_type'),
                        ltr_enable = True
                    ).values('ltr_text')[:1]
                ),                
                type = Value('Custom Categories'),
            ).values(
                'category_id',
                'category',
                'type'
            ).order_by('category')

            form_categories = list(pre_defined_categories) + list(custom_categories)
            
            return Response(form_categories, status = status.HTTP_200_OK)
        
        except Exception as e:
            return Response({'message': str(e)}, status = status.HTTP_400_BAD_REQUEST)