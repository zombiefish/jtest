from django.urls import path

from apps.common_utils.views.get_my_sds_token import MYSDSToken
from apps.common_utils.views.send_support_email import SendSupportEmail
from apps.common_utils.views.sofvie_health_check import SofvieHealthCheck

urlpatterns = [
    path('send-support-email/', SendSupportEmail.as_view()),
    path('sofvie-health-check/', SofvieHealthCheck.as_view()),
    path('mysds-token/', MYSDSToken.as_view()),
]