from django.db import models
from django.db.models import (
    Model,
    AutoField,
    DateTimeField,
    ForeignKey,
    BooleanField,
)
from spacy import blank
from apps.common_utils.views.sofvieModelFields import (
    SofvieCharField,
    SofvieIntegerField, SofvieTextField
)
from apps.incident_management.models import Rootcauseanalysis
from apps.loto.models import LockoutTagOutHeader
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.person.models import Person

# Create your models here.
class CommonHeaderData(Model):
    chd_id = AutoField(primary_key=True)
    chd_site = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, related_name='sites', blank = True, null = True)
    chd_job = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, related_name='jobs', blank = True, null = True)
    chd_level = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, related_name='levels', blank = True, null = True)
    chd_workplace = SofvieCharField(max_length=1000, blank = True, null = True)
    chd_archived_date = DateTimeField(blank=True, null=True)
    chd_archived_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='chd_archived_by')
    chd_created_date = DateTimeField(auto_now_add=True)
    chd_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='chd_created_by')
    chd_modified_date = DateTimeField(blank=True, null=True)
    chd_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='chd_modified_by', blank = True, null = True)
    chd_enable = BooleanField(default=True)
    chd_enote = SofvieCharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'common_header_data'

class CommonApprover(Model):
    cap_id = AutoField(primary_key=True)
    cap_lth = ForeignKey(LockoutTagOutHeader, on_delete = models.DO_NOTHING, related_name='loto_approver', blank = True, null = True)
    cap_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='cap_person')
    cap_position = SofvieIntegerField(blank = True, null = True)
    cap_archived_date = DateTimeField(blank=True, null=True)
    cap_is_approved = BooleanField(default=False)
    cap_archived_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='cap_archived_by')
    cap_created_date = DateTimeField(auto_now_add=True)
    cap_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='cap_created_by')
    cap_modified_date = DateTimeField(blank=True, null=True)
    cap_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='cap_modified_by', blank = True, null = True)
    cap_enable = BooleanField(default=True)
    cap_enote = SofvieCharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'common_approver'






class CommonReviewer(Model):
    crw_id = AutoField(primary_key=True)
    crw_lth = ForeignKey(LockoutTagOutHeader, on_delete = models.DO_NOTHING, related_name = 'loto_reviewer', blank = True, null = True)
    crw_rca = ForeignKey(Rootcauseanalysis, on_delete = models.DO_NOTHING, related_name = 'rca_reviewer', blank = True, null = True)
    crw_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='crw_person')   
    crw_position = SofvieIntegerField(blank = True, null = True)
    crw_is_mandatory = BooleanField(default=False)
    crw_is_reviewed = BooleanField(default=False)
    crw_archived_date = DateTimeField(blank=True, null=True)
    crw_archived_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, blank=True, null=True,related_name='crw_archived_by')    
    crw_created_date = DateTimeField(auto_now_add=True)
    crw_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='crw_created_by')
    crw_modified_date = DateTimeField(blank=True, null=True)
    crw_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='crw_modified_by', blank = True, null = True)
    crw_enable = BooleanField(default=True)
    crw_enote = SofvieCharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'common_reviewer'