from rest_framework import serializers
from apps.common_utils.models import CommonApprover, CommonReviewer

from apps.language.models import Language
from apps.reflist.models import RefListDetail
from apps.user_settings_profile.models import UserProfile

class ActiveApproversSerializer(serializers.ListSerializer):
    def to_representation(self, data):
        data = data.filter(cap_enable = True)
        return super(ActiveApproversSerializer, self).to_representation(data)

class CommonApproverSerializer(serializers.ModelSerializer):
    cap_per_full_name = serializers.SerializerMethodField()
    class Meta:
        model = CommonApprover
        list_serializer_class  = ActiveApproversSerializer
        fields = (
            "cap_per_id",
            "cap_is_approved",
            "cap_per_full_name",         
        )
    
    def get_cap_per_full_name(self, obj):
        return obj.cap_per.full_name

class ActiveReviewersSerializer(serializers.ListSerializer):
    def to_representation(self, data):
        data = data.filter(crw_enable = True)
        return super(ActiveReviewersSerializer, self).to_representation(data)


class GetALLCommonReviewersSerializer(serializers.ModelSerializer):
    position_name = serializers.SerializerMethodField()
    reviewer_name = serializers.SerializerMethodField()
    class Meta:
        model = CommonReviewer
        list_serializer_class  = ActiveReviewersSerializer
        fields = (
            "crw_per",
            "position_name",
            "crw_created_date",
            'reviewer_name',
        )
    
    def __init__(self, *args, **kwargs):
        person = kwargs["context"].get("request").user.user_per_id_id
        lang_name = UserProfile.objects.get(upr_per=person).upr_language
        self.lang_id = Language.objects.get(lng_name=lang_name).lng_id

        # new way to get translations on site load getting all translations
        # form tag value as a 'tag_number-tag_type-lang_id'. 
        # search thgrough FullTranslations with the tag_value combination to get text value
        # thus avoiding database calls in each loop for each site/job/level/equipment type
        self.full_translations = kwargs["context"].get("translations")
        super(GetALLCommonReviewersSerializer, self).__init__(*args, **kwargs)
    
    def get_reviewer_name(self, obj):
        return obj.crw_per.full_name
    
    def get_position_name(self, obj):
        position_rld = RefListDetail.objects.filter(
                    rld_id=obj.crw_position).values(
                    'rld_name', 'rld_tag_type')
        try:
            tag_value = f'{position_rld[0]["rld_name"]}-{position_rld[0]["rld_tag_type"]}-{self.lang_id}'
        except: 
            tag_value = ''

        return self.full_translations.get(tag_value, None)

