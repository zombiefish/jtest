import time

import jwt
from decouple import config
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class MYSDSToken(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.MySDS.value,)

    def get(self, request):
        private_key_path = config('MYSDS_PRIVATE_KEY_PATH')
        kid = config('MYSDS_KID')
        with open(private_key_path, 'r') as private:
            private_key = private.read()

        payload = {
            "name": config("MYSDS_CLIENT"),
            "iat": int(time.time()),
            "jti": "b3f5eb4d-4e16-43fe-8a68-baea6bdb34cc",
            "exp": int(time.time()) + 30,
            "aud": config('MYSDS_AUD'),
            "iss": config('MYSDS_ISS'),
            "sub": config("MYSDS_CLIENT")
        }
        encoded = jwt.encode(payload, private_key, algorithm="RS256",
                             headers={'kid': kid})

        return Response({"token": encoded})
