from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.address.models import AddressType


class SofvieHealthCheck(APIView):

    def get(self, request):
        get_data = AddressType.objects.filter(aty_description='Home').values(
            'aty_description').first()

        return Response({"data": get_data, "status": status.HTTP_200_OK})
