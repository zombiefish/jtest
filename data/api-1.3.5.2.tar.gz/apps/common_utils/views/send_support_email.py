from decouple import config
from django.core.mail import EmailMultiAlternatives
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.sofvie_user_authorization.api.permissions import SofviePermission


class SendSupportEmail(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        message = request.data['message']
        subject = request.data['subject']
        name = request.data['name']
        email = request.data['email']
        sendEmail = request.data['sendEmail']
        fromEmail = email
        toEmail = [config('EMAIL_SUPPORT_EMAIL')]
        if (sendEmail):
            toEmail.append(email)
        msg = EmailMultiAlternatives(subject, message, fromEmail,
                                     toEmail)
        msg.send()

        return Response({"subject": subject,
                         "message": message,
                         "email": email,
                         "name": name})
