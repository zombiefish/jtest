from enum import Enum

from django.db import connection

from apps.employee.models import Employee
from apps.incident_management.api.utlity_function import dictfetchall
from apps.language.models import LanguageTranslation
from apps.sofvie_user_authorization.models import AuthPermissionSofvie


def GetRestrictedFormID(formDescID):
    with connection.cursor() as cursor:
        cursor.execute("call get_restricted_form_id(%s)", (formDescID,))
        rows = dictfetchall(cursor)
        return rows


# function helps to handle the person access on the end point
def PersonAccessPermission(self, requestedPermission):
    person_id = self.request.user.user_per_id_id  # person Id
    req_permission = requestedPermission.value  # casting to enum value

    with connection.cursor() as cursor:
        cursor.execute("call get_access_role_permission(%s,%s)",
                       ([person_id], [req_permission]))

        row = cursor.fetchone()
        IsPermits = row
    return IsPermits[0]

RolePermission = Enum('RolePermission',
                      {ap.ape_name.replace(" ", "").replace("-", ""): ap.ape_id for
                       ap in AuthPermissionSofvie.objects.all()})


class PermissionErrorMessage(Enum):
    errMsgCanViewIncidents = 'Access denied - Do not have access to view Incidents'
    errMsgCanSignOffIncident = 'Access denied - Do not have access to sign off'
    errMsgCanManageLessonsLearned = 'Access denied - Do not have access to manage lessons learned'
    errMsgCanViewLessonsLearned = 'Access denied - Do not have access to view lessons learned'



