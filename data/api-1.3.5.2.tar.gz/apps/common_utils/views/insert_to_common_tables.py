from datetime import datetime
from django.db import transaction
from apps.common_utils.models import CommonHeaderData, CommonApprover, CommonReviewer
from apps.employee.models import Employee

@transaction.atomic
def add_to_common_header(self, chd_data):

    if 'chd_site' in chd_data:
        chd_data['chd_site_id'] = chd_data['chd_site']
        del chd_data['chd_site']
    
    if 'chd_job' in chd_data:
        chd_data['chd_job_id'] = chd_data['chd_job']
        del chd_data['chd_job']

    if 'chd_level' in chd_data:
        chd_data['chd_level_id'] = chd_data['chd_level']
        del chd_data['chd_level']
    
    chd_data['chd_created_by_per'] = self.person
    chd_instance = CommonHeaderData.objects.create(
        **chd_data
    )
    return chd_instance

@transaction.atomic
def update_common_header(self, chd_data):

    chd_data['chd_modified_by_per'] = self.person
    chd_data['chd_modified_date'] = datetime.now()
    chd_id = chd_data.pop('chd_id')
    chd_instance = CommonHeaderData.objects.filter(
        chd_id = chd_id
    ).update(
        **chd_data
    )


    return chd_instance

@transaction.atomic
def add_to_common_approver(self, approvers_data):
    if approvers_data:
        bulk_object = []
        if self.MODULE == 'LOTO':
            bulk_object = [CommonApprover(
                cap_lth = self.lth_instance,
                cap_per_id = approver,
                cap_created_by_per = self.person
            )for approver in approvers_data]

        if len(bulk_object) > 0:
            cap_instance = CommonApprover.objects.bulk_create(
                bulk_object
            )
            return cap_instance
        return False

def update_common_approver(self, approvers_data):

    try:
        if self.MODULE == 'LOTO':
            update_loto_approvers(self, approvers_data)
    except Exception as e:
        raise

@transaction.atomic
def add_to_common_reviewer(self, reviewers_data):

    bulk_object = []
    
    instance_object = {}
    if self.MODULE == 'LOTO':
        instance_object['crw_lth'] = self.lth_instance
    
    bulk_object = [CommonReviewer(
        **instance_object,
        crw_per_id = reviewer,
        crw_created_by_per = self.person,
        crw_is_mandatory = True
    )for reviewer in reviewers_data]

    if len(bulk_object) > 0:
        crw_instance = CommonReviewer.objects.bulk_create(
            bulk_object
        )
        return crw_instance
    return False

@transaction.atomic
def update_common_reviewer(self, current_reviewers):

    try:
        if self.MODULE == 'LOTO':
            update_loto_reviewers(self, current_reviewers)
    except Exception as e:
        raise


def update_loto_approvers(self, current_approvers):
    if current_approvers:
        existing_approvers = CommonApprover.objects.filter(
            cap_lth = self.lth_instance,
            cap_enable = True
        ).values_list('cap_per_id', flat = True)

        existing_approvers = list(existing_approvers)

        deleted_approvers = list(set(existing_approvers) - set(current_approvers))   


        CommonApprover.objects.filter(
            cap_enable = True,
            cap_per__in = deleted_approvers,
            cap_lth = self.lth_instance
        ).update(
            cap_enable = False,
            cap_modified_date = datetime.now(),
            cap_modified_by_per = self.person
        )

        new_approvers = list(set(current_approvers) - set(existing_approvers))

        if len(new_approvers) > 0:
            bulk_object = [CommonApprover(
                    cap_lth = self.lth_instance,
                    cap_per_id = approver,
                    cap_created_by_per = self.person
                )for approver in new_approvers]

            CommonApprover.objects.bulk_create(
                bulk_object
            )

def update_loto_reviewers(self, current_reviewers):
    if current_reviewers:
        existing_reviewers = CommonReviewer.objects.filter(
            crw_lth = self.lth_instance,
            crw_enable = True
        ).values_list('crw_per_id', flat = True)

        existing_reviewers = list(existing_reviewers)

        deleted_reviewers = list(set(existing_reviewers) - set(current_reviewers))

        CommonReviewer.objects.filter(
            crw_enable = True,
            crw_lth = self.lth_instance,
            crw_per__in = deleted_reviewers
        ).update(
            crw_enable = False,
            crw_modified_date = datetime.now(),
            crw_modified_by_per = self.person
        )

        new_reviewers = list(set(current_reviewers) - set(existing_reviewers))

        if len(new_reviewers) > 0:
            bulk_object = [CommonReviewer(
                    crw_lth = self.lth_instance,
                    crw_per_id = reviewer,
                    crw_created_by_per = self.person,
                    crw_is_mandatory = True
                )for reviewer in new_reviewers]
        
            CommonReviewer.objects.bulk_create(
                bulk_object
            )



