import time

from apps.loto.models import LockOutTagOutAttachment

ALLOWED_FILE_TYPE_IMAGES = ['image/png', 'image/jpeg',
'image/bmp', 'image/gif', 'image/webp', 'image/x-ms-bmp']

ALLOWED_FILE_TYPE_DOCUMENTS = ['application/pdf', 
'text/plain', 'text/csv', 'application/msword', 
'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 
'application/vnd.ms-excel', 
'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 
'text/rtf',
'application/rtf',
'application/csv',
'application/vnd.ms-powerpoint', 
'application/vnd.openxmlformats-officedocument.presentationml.presentation', 
'text/calendar', 'message/rfc822', 
'application/vnd.openxmlformats-officedocument.presentationml.slideshow',
'application/vnd.oasis.opendocument.text', 
'application/vnd.oasis.opendocument.spreadsheet', 
'application/vnd.oasis.opendocument.presentation']



from django.db import connection
import magic
import base64
import os
import threading
from datetime import datetime
import magic
from rest_framework.exceptions import ValidationError

from django.conf import settings
from django.template.defaultfilters import slugify
from queue import Queue
from apps.dlm.models import DecisionLogAttachment
from apps.drm.models import DocumentReviewManagement, DocumentOfflineAttachment
from apps.employee.models import Employee
from apps.general_action.models import SubmissionGeneralActionAttachment
from apps.hazard_action.models import SubmissiondetailsExplode, Submissionhapattachments
from apps.llm.models import LessonLearnedAttachment
from apps.recognition.models import SubmissionPositiveRecognitionAttachments
from apps.training.models import EmployeeTrainingAttachment
from apps.attachments.models import RmmAttachments
import mimetypes


FILE_PATH = {
    'Hazard_Action': settings.HAZARD_ACTION_DIR,
    'General_Action': settings.GENERAL_ACTION_DIR,
    'Positive_Recognition': settings.HAZARD_ACTION_DIR,
    'Lessons_Learned': settings.LESSONS_LEARNED,
    'Decision_Log': settings.DECISION_LOG,
    'Incident': settings.FILES_DIR,
    'Preliminary_Incident': settings.HAZARD_ACTION_DIR,
    'Training': settings.TRAINING_FILES_DIR,
    'Document_Review_Management': os.path.join(settings.HAZARD_ACTION_DIR, 'documents_attachments'),
    'LOTO': os.path.join(settings.LOTO, 'loto_equipment_attachments')
}

def check_in_memory_mime(in_memory_file):
    mime = magic.from_buffer(in_memory_file.read(), mime=True)
    return mime

def storeLocalfile(filePath, file):    
    try:
        head, tail = os.path.split(filePath)        
        os.makedirs(head)
    except FileExistsError:        
        pass
    with open(filePath, 'wb') as dest:
        for chunk in file.chunks():
            dest.write(chunk)

def storeData(store_data_args): 
    # Inserting attachment data into respective tables
    if store_data_args['app'] == 'Hazard_Action':

        return hazard_action_store_data(store_data_args)        

    elif store_data_args['app'] == 'General_Action':
        return general_action_store_data(store_data_args)

    elif store_data_args['app'] == 'Positive_Recognition':
        return positive_recognition_store_data(store_data_args)
    
    elif store_data_args['app'] == 'Lessons_Learned':
        return lessons_learned_store_data(store_data_args)
    
    elif store_data_args['app'] == 'Decision_Log':
        return decision_log_store_data(store_data_args)

    elif store_data_args['app'] == 'Incident':   
        return incident_store_data(store_data_args)        
    
    elif store_data_args['app'] == 'Preliminary_Incident':
        return preliminary_incident_store_data(store_data_args)

    elif store_data_args['app'] == 'Training':        
          return training_store_data(store_data_args)

    elif store_data_args['app'] == 'Document_Review_Management':
        return document_store_data(store_data_args)

    elif store_data_args['app'] == 'RMM_Attachment':
        return rat_store_data(store_data_args)

    elif store_data_args['app'] == 'LOTO':        
        return loto_store_data(store_data_args)

def save_the_file(store_data_args):
   
    '''
    This function is used to save the file in the server.
    It will check the file type and save the file in the server.    
    '''
    allowed_mimes = ALLOWED_FILE_TYPE_IMAGES if store_data_args['only_image'] else ALLOWED_FILE_TYPE_DOCUMENTS+ALLOWED_FILE_TYPE_IMAGES

    path = FILE_PATH[store_data_args['app']] if store_data_args['app'] in FILE_PATH.keys() else FILE_PATH['Hazard_Action']


    allow_files = []
    rejected_files = []
    attachment_ids = []
    allow_files_original = []
    
    for file in store_data_args['files']:
        mimeType = check_in_memory_mime(file)       

        if str(mimeType) in allowed_mimes:            
            ext = file.name.split('.')[-1]
            original_name = slugify(file.name.split('.')[0])
            timestamp = datetime.now().strftime('%Y%m-%d%H-%M%S')
            filename = "%s_%s.%s" % (original_name, timestamp, ext)
            
            if store_data_args['app'] == 'Training':
                subDirectory = os.path.join(path, 'employee_id_' + store_data_args['etr_emp_id'])            
                if not os.path.exists(subDirectory):
                    os.mkdir(subDirectory)            
                fileDir = os.path.join(path, 'employee_id_' + store_data_args['etr_emp_id'],
                                    'training_id_' + store_data_args['id'])            
                filePath = os.path.join(fileDir, filename)               
                if not os.path.exists(fileDir):
                    os.mkdir(fileDir)  
            elif store_data_args['app'] == 'Incident':
                fileDir = os.path.join(path, store_data_args['incident_number'])
                filePath = os.path.join(fileDir, filename)
                if not os.path.exists(fileDir):
                    os.mkdir(fileDir)                              
            else:
                filePath = os.path.join(path, filename)

            file_args = (filePath, file)

            store_data_args['filename'] = filename
            store_data_args['ext'] = ext


            storeLocalfile(filePath, file)
            result2 = storeData(store_data_args)
            if store_data_args['app'] == 'Document_Review_Management':                     
                if 'file_size_error' in result2 and result2['file_size_error'] is not None:
                    raise ValidationError({"file_size_error": result2['file_size_error']})
            else:
                if type(result2) == list:
                    for each in result2:
                        attachment_ids.append(each)
                else:
                    attachment_ids.append(result2)
            allow_files.append(filename)
            allow_files_original.append(file.name)
           
        else:
            rejected_files.append(file.name)


    response = {
        "Successfull Files": {
            "allowed_files": allow_files,
            "allowed_original":allow_files_original, 
            "ids": attachment_ids 
            },
        "Failed Files :": {
            "rejected_files": rejected_files
            }
        }

    return response

def hazard_action_store_data(store_data_args):
    hap_ids = store_data_args['id'].split(',')
    bulk_create_object = [Submissionhapattachments(
        submissionhapid_id=hap_id,
        haa_hac = store_data_args['haa_hac'],
        attachmentfilename=store_data_args['filename'],
        attachmenttype=store_data_args['attachment_type'],
        haa_image_timestamp = store_data_args['image_timestamp'],
        haa_created_by_per_id=store_data_args['person_id'],
    )for hap_id in hap_ids]

    submission_hap = Submissionhapattachments.objects.bulk_create(bulk_create_object)
    ids = [sha.id for sha in submission_hap]
    return ids


def general_action_store_data(store_data_args):
    gap_ids = store_data_args['id'].split(',')

    bulk_create_object = [SubmissionGeneralActionAttachment(
        gaa_sga_id=gap_id,
        gaa_gac = store_data_args['gaa_gac'],
        gaa_file_name=store_data_args['filename'],
        gaa_type=store_data_args['attachment_type'],
        gaa_image_timestamp = store_data_args['image_timestamp'],
        gaa_created_date=datetime.now(),
        gaa_created_by_per_id=store_data_args['person_id'],
        gaa_enable=1
    ) for gap_id in gap_ids]

    gaa = SubmissionGeneralActionAttachment.objects.bulk_create(bulk_create_object)

    ids = [sga.gaa_id for sga in gaa]

    return ids

def positive_recognition_store_data(store_data_args):
    submission_id=SubmissionPositiveRecognitionAttachments.objects.create(
            submissionpositiverecognition_id=store_data_args['id'],
            AttachmentFileName=store_data_args['filename'],
            AttachmentComment ='',
            spa_image_timestamp = store_data_args['image_timestamp']
        )

    return submission_id.id

def lessons_learned_store_data(store_data_args):
    lessonLearnedAttachment = LessonLearnedAttachment.objects.create(
            lat_llm_id=store_data_args['id'],
            lat_file_name=store_data_args['filename'],
            lat_comment='',
            lat_created_by_per_id=store_data_args['person_id']            
        )

    return lessonLearnedAttachment.lat_id

def incident_store_data(store_data_args):
    with connection.cursor() as cursor:
        cursor.execute("call sp_insert_incident_attachments(""%s,%s,%s,%s,%s)",(
                                                        store_data_args['id'],
                                                        store_data_args['filename'],
                                                        '.'+store_data_args['ext'],
                                                        store_data_args['section'], 
                                                        store_data_args['person_id']
                                                    ))

def decision_log_store_data(store_data_args):
    decisionLogAttachment = DecisionLogAttachment.objects.create(
            dat_dlm_id=store_data_args['id'],
            dat_file_name=store_data_args['filename'],
            dat_comment ='',
            dat_created_by_per_id = store_data_args['person_id']
        )

    return decisionLogAttachment.dat_id
    
def preliminary_incident_store_data(store_data_args):
    submission_id = SubmissiondetailsExplode.objects.create(
            submissiondetailid_id=store_data_args['id'],
            formfielddescriptionid_id=store_data_args['form_field_description_id'],
            value=store_data_args['filename'],
            sde_image_timestamp = store_data_args['image_timestamp']
        )

    return submission_id.id

def training_store_data(store_data_args):
    employeeTrainingAttachment = EmployeeTrainingAttachment.objects.create(
            eta_etr_id=store_data_args['id'],
            eta_attachment_name=store_data_args['filename'],
            eta_attachment_comment=store_data_args['comment'],
            eta_attachment_type=store_data_args['attachment_type'],
            eta_created_date=datetime.now(),
            eta_modified_date=datetime.now(),
            eta_created_by_per_id=store_data_args['person_id'],
            eta_modified_by_per_id=store_data_args['person_id'],
            eta_enable=True
        )

    return employeeTrainingAttachment.eta_id 

def document_store_data(store_data_args):

    document = DocumentReviewManagement.objects.get(drm_id=store_data_args['id'])
    document.drm_attachment_type = store_data_args['attachment_type']
    document.drm_available_offline = store_data_args['available_offline']
    document.drm_modified_by_per_id = store_data_args['person_id']

    filename = store_data_args['filename']    
    filepath = os.path.join(settings.HAZARD_ACTION_DIR, 'documents_attachments', filename)
    with open(filepath, "rb") as file:        
        drm_file_size=int(store_data_args['file_size'])
        if store_data_args['available_offline']:
            mime_type = mimetypes.MimeTypes().guess_type(filepath)[0]
            if drm_file_size > 5000000:                           
                store_data_args['file_size_error'] = "File size is greater than 5MB."
            else:                
                encoded_string = base64.b64encode(file.read())
                encoded_string = encoded_string.decode('utf-8')
                encoded_string = f"data:{mime_type};base64,{encoded_string}"

                document.drm_filename = filename
                document.drm_file_size = drm_file_size
                document.save()

                add_offline_attachment(encoded_string,store_data_args['person_id'], document.drm_id)

        else:
            document.drm_filename = filename
            document.drm_file_size = drm_file_size
            document.save()
            add_offline_attachment(None,store_data_args['person_id'], document.drm_id)

        return store_data_args

def add_offline_attachment(attachment_data, person_id, drm_id):
    """
    One to One relationship should be maintained between document_offline_attachment table and
    document_review_management.
    There should be one record and only one in DOA for each record in DRM.
    """
    try:
        doa_drm_exists = DocumentOfflineAttachment.objects.filter(
            doa_drm_id=drm_id,
            doa_enable=True
        ).exists()

        if doa_drm_exists:
            delete_existing_doa = DocumentOfflineAttachment.objects.filter(
                doa_drm_id=drm_id,
                doa_enable=True
            ).update(
                doa_modified_date = datetime.now(),
                doa_modified_by_per_id = person_id,
                doa_offline_attachment = attachment_data
            )
        else:
            offline_attachment = DocumentOfflineAttachment.objects.create(
                doa_drm_id = drm_id,
                doa_offline_attachment = attachment_data,
                doa_created_by_per_id = person_id,
                doa_enable = 1,
            )
    except Exception as e:
        print('Error in Creating/updating Document Offline Attachemnt in add_attachment.py: ', e)
        return None

def rat_store_data(store_data_args):
    rmmAttachment = RmmAttachments.objects.create(
        rat_rmm_id=store_data_args['rmm_id'],
        rat_mod_id=store_data_args['mod_id'],
        rat_file_name=store_data_args['filename'],
        rat_created_by_per_id=store_data_args['person_id'],
        rat_created_date=datetime.now()
    )
    return rmmAttachment.rat_id


def loto_store_data(store_data_args):
    loto_equipment_attachment = LockOutTagOutAttachment.objects.create(
        lta_lte_id=store_data_args['lta_lte_id'],
        lta_lts_id=store_data_args['lta_lts_id'],
        lta_filename=store_data_args['filename'],
        lta_timestamp=store_data_args['image_timestamp'],
        lta_created_by_per_id=store_data_args['person_id'],
        lta_created_date=datetime.now()
    )
    return loto_equipment_attachment.lta_id
