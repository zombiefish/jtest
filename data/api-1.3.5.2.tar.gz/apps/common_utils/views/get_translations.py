from django.db.models import Q
from apps.language.models import Language, LanguageTranslation
import pandas as pd

def get_translation(ltr_ids, lang, tag_type = 1):
    tagFilter = []
    if len(ltr_ids) > 0:
        tagFilter = [Q(ltr_tag__in=ltr_ids)]

    get_trans = LanguageTranslation.objects.select_related(
        'ltr_lng'
    ).filter(
        *tagFilter,
        ltr_lng=lang,
        ltr_tag_type=tag_type
    ).values(
        'ltr_id',
        'ltr_tag',
        'ltr_text',
    ).order_by('ltr_tag')

    finalTranslations = {}
    for tr in get_trans:
        finalTranslations[tr['ltr_tag']] = tr['ltr_text']

    return finalTranslations

def get_full_translations(lng_id):
    all_trans = LanguageTranslation.objects.filter(ltr_enable=True, ltr_lng_id = lng_id)
    df_trans = pd.DataFrame(all_trans.values())
    df_trans['tag_value'] = df_trans['ltr_tag'].astype(str) +"-"+ df_trans["ltr_tag_type"].astype(str)+"-"+ df_trans["ltr_lng_id"].astype(str)
    return dict(zip(df_trans.tag_value, df_trans.ltr_text))