from apps.admin_settings.models import ClientLogo


def getClientLogo():
    logo = ""
    # check for Client Logo
    logo = ClientLogo.objects.filter(clo_is_sofvie_logo=0, clo_enable=1).values('clo_image')
    # if there is no Client Logo use the Sofvie Logo
    if not logo:
        logo = ClientLogo.objects.filter(clo_is_sofvie_logo=1, clo_enable=1).values('clo_image')
        # if there is no Sofvie Logo Leave the logo Blank
        if not logo:
            logo = ""
    return(logo[0]['clo_image'])