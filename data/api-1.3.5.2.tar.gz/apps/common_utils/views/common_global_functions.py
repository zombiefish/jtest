from django.db.models import Subquery, OuterRef
from apps.employee.models import Employee
from apps.general_action.models import SubmissionGeneralActionAttachment, SubmissionGeneralActionCompletedPerson, SubmissionGeneralActionCompletion, SubmissionGeneralActionPerson
from apps.hazard_action.models import SubmissionHazardActionCompletedPerson, SubmissionHazardActionCompletion, SubmissionHazardActionPerson, Submissionhapattachments
from apps.language.models import LanguageTranslation
from unidecode import unidecode
import re
from django.db.models.functions import Concat
from django.db.models import Value, CharField
from datetime import datetime,timedelta

def get_user_email(obj, user_id):
    get_email = obj.objects.get(user_per_id=user_id).email
    return get_email
    
def ltr_subquery(self, tag, tag_type):
    subquery = Subquery(
        LanguageTranslation.objects.filter(
            ltr_lng = self.lng_id,
            ltr_tag = OuterRef(tag),
            ltr_tag_type = OuterRef(tag_type),
            ltr_enable = True
        ).values('ltr_text')[:1]
    )
    return subquery

def titlekey(title):
    # Use to sort distribution lists.
    # record is passed in, if it contains either key 
    # the list will be sorted by that key.
    
    key = ''
    if 'per_full_name' in title:
        key = 'per_full_name'
    elif 'name' in title:
        key = 'name'

    punct = re.compile(r'[^\w ]')
    s = unidecode(title[key]).lower()
    s = punct.sub('', s)
    w = s.split()

    return w


def modify_ga_data(ga_data):
    for ga in ga_data:
        ga['attachments'] = SubmissionGeneralActionAttachment.objects.filter(gaa_sga=ga['sga_id'], gaa_enable=True).values()

        action_by_who_per = SubmissionGeneralActionPerson.objects.filter(
            gap_sga_id = ga['sga_id'],
            gap_enable = True
        ).annotate(
            full_name = Concat('gap_per__per_first_name', Value(' '), 'gap_per__per_middle_name', Value(','), 'gap_per__per_last_name', output_field=CharField())
        ).values_list('full_name', flat = True)
        ga['sga_action_by_who'] = '; '.join(action_by_who_per)
        ga['sga_action_by_who_per'] = action_by_who_per.values_list('gap_per_id', flat = True)

        gac_ids = SubmissionGeneralActionCompletion.objects.filter(
            gac_sga_id = ga['sga_id'],
            gac_enable = True
        ).values_list('gac_id', flat = True)

        completed_action_by_who_per = SubmissionGeneralActionCompletedPerson.objects.filter(
            gcp_gac_id__in = gac_ids,
            gcp_enable = True
        ).annotate(
            full_name = Concat('gcp_per__per_first_name', Value(' '), 'gcp_per__per_middle_name', Value(','), 'gcp_per__per_last_name', output_field=CharField())
        ).values_list('full_name', flat = True)

        ga['sga_completed_action_by_who'] = '; '.join(completed_action_by_who_per)

        action_complete = SubmissionGeneralActionCompletion.objects.filter(
            gac_sga_id = ga['sga_id'],
            gac_enable = True
        ).exists()

        ga['sga_action_is_complete'] = 0
        if action_complete:
            ga['sga_action_is_complete'] = 1
    
    return ga_data


def modify_ha_data(ha_data):
    for ha in ha_data:
        ha['attachments'] = Submissionhapattachments.objects.filter(submissionhapid=ha["id"], haa_enable=True).values()

        action_by_who_per = SubmissionHazardActionPerson.objects.filter(
            hap_sha_id = ha['id'],
            hap_enable = True
        ).annotate(
            full_name = Concat('hap_per__per_first_name', Value(' '), 'hap_per__per_middle_name', Value(','), 'hap_per__per_last_name', output_field=CharField())
        ).values_list('full_name', flat = True)
        ha['action_by_who'] = '; '.join(action_by_who_per)
        ha['action_by_who_per'] = action_by_who_per.values_list('hap_per_id', flat = True)

        hac_ids = SubmissionHazardActionCompletion.objects.filter(
            hac_sha_id = ha['id'],
            hac_enable = True
        ).values_list('hac_id', flat = True)

        completed_action_by_who_per = SubmissionHazardActionCompletedPerson.objects.filter(
            hcp_hac_id__in = hac_ids,
            hcp_enable = True
        ).annotate(
            full_name = Concat('hcp_per__per_first_name', Value(' '), 'hcp_per__per_middle_name', Value(','), 'hcp_per__per_last_name', output_field=CharField())
        ).values_list('full_name', flat = True)

        ha['action_complete_by_who'] = '; '.join(completed_action_by_who_per)

        action_complete = SubmissionHazardActionCompletion.objects.filter(
            hac_sha_id = ha['id'],
            hac_enable = True
        ).exists()

        ha['action_status'] = 0
        if action_complete:
            ha['action_status'] = 1
    
    return ha_data

def calculateDateIntervals(self):
    todayDate = datetime.now()
    if todayDate.month < 7:
        self.start_of_bi_annual = todayDate.strftime("%Y-01-01")
        self.end_of_bi_annual = todayDate.strftime("%Y-06-30")
    else:
        self.start_of_bi_annual = todayDate.strftime("%Y-07-01")
        self.end_of_bi_annual = todayDate.strftime("%Y-12-31")     
        
    currQuarter = (todayDate.month - 1) / 3 + 1

    quarterDateMonth = 3 * int(currQuarter) + 1
    if quarterDateMonth > 12:
        quarterEndDate = datetime(todayDate.year + 1, 1, 1) + timedelta(days=-1)
    else:
        quarterEndDate = datetime(todayDate.year, 3 * int(currQuarter) + 1, 1)+ timedelta(days=-1)
        
    self.start_of_quarter = datetime(todayDate.year, 3 * int(currQuarter) - 2, 1)
    self.start_of_quarter = self.start_of_quarter.strftime("%Y-%m-%d")
    self.end_of_quarter = quarterEndDate
    self.end_of_quarter = self.end_of_quarter.strftime("%Y-%m-%d")

    next_month = todayDate.replace(day=28) + timedelta(days=4)
    self.start_of_month = todayDate.strftime("%Y-%m-01")
    self.start_of_year = todayDate.strftime("%Y-01-01")
    self.end_of_year = todayDate.strftime("%Y-12-31")
    self.end_of_month = next_month - timedelta(days=next_month.day)
    self.end_of_month = self.end_of_month.strftime("%Y-%m-%d")


# To get the employee position
def get_employee_position(per_id):
    try:
        get_position = Employee.objects.get(emp_per_id=per_id)
        if get_position.emp_pos_id is None:
            return None
        else:
            return get_position.emp_pos_id
    except Employee.DoesNotExist:
        raise Exception('Please provide valid person id')