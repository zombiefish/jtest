from django.db import models
from rest_framework import serializers
from bleach import clean

# global values for escape characters - scope of this is limited to this page
SANITIZE_LIST =['{{', '}}', '${', '$(', '==', '===', '&&', '--', '++', '||', '//', '/*', '*/']

class SofvieCharField(models.CharField):    

    def __init__(self, max_length = 200, min_length = 0, 
                        escape_list = None,
                        allow_list = None,
                        allowed_tags= None, 
                        allowed_attributes= None,
                        allowed_styles= None, 
                        allowed_protocols= None,              
                        strip_tags=None,          
                        strip_comments= None, *args, **kwargs):
        super(SofvieCharField, self).__init__(*args, **kwargs)

        self.max_length = max_length
        self.min_length = min_length        
        self.escape_list = escape_list
        self.allow_list = allow_list

        self.additional_kwargs = get_additional_kwargs(allowed_tags, allowed_attributes, allowed_styles, allowed_protocols, strip_tags, strip_comments)       
    
    def to_python(self, data):       

        if data is None:
            return data
        
        # If user input is not empty, clean it and replace escape characters with empty string        
        data = clean_input(data, escape_list= self.escape_list, additional_kwargs= self.additional_kwargs, allow_list=self.allow_list)
        
        if len(data) not in range(self.min_length, self.max_length+1):            
            raise serializers.ValidationError({f"{self.attname}": f"{self.attname} should not be greater than {self.max_length} characters"})        
    
        return data

class SofvieIntegerField(models.IntegerField):
    def __init__(self, min_value=0, max_value=None,  *args, **kwargs):
        super(SofvieIntegerField, self).__init__(*args, **kwargs)
        self.max_value = max_value
        self.min_value = min_value
    
    def to_python(self, data):        
                
        if self.max_value is not None and data not in range(self.min_value, self.max_value+1):            
            raise serializers.ValidationError({f"{self.attname}": f"{self.attname} should not be greater than {self.max_value}"})        
        return data


class SofvieTextField(models.TextField):    
    
    def __init__(self, escape_list = None,
                        allow_list = None,
                        allowed_tags= None, 
                        allowed_attributes= None,
                        allowed_styles= None, 
                        allowed_protocols= None,              
                        strip_tags= None,          
                        strip_comments= None, *args, **kwargs):
        super(SofvieTextField, self).__init__(*args, **kwargs)  

        self.escape_list = escape_list
        self.allow_list = allow_list

        self.additional_kwargs = get_additional_kwargs(allowed_tags, allowed_attributes, allowed_styles, allowed_protocols, strip_tags, strip_comments)        
    

    def to_python(self, data):  
        
        if data is None:
            return data

        data = clean_input(data, escape_list= self.escape_list, allow_list=self.allow_list, additional_kwargs= self.additional_kwargs)
        return data

class SofvieEmailField(models.EmailField):    
    
    def __init__(self, min_length= 0, max_length = 100, escape_list = None, 
                        allowed_tags= None, 
                        allowed_attributes= None,
                        allowed_styles= None, 
                        allowed_protocols= None,              
                        strip_tags= None,          
                        strip_comments= None, *args, **kwargs):
        super(SofvieEmailField, self).__init__(*args, **kwargs)  

        self.max_length = max_length
        self.min_length = min_length

        self.escape_list = escape_list

        self.additional_kwargs = get_additional_kwargs(allowed_tags, allowed_attributes, allowed_styles, allowed_protocols, strip_tags, strip_comments)
        
    
    def to_python(self,data):                
        if data is None:
            return data
        
        data = clean_input(data, escape_list= self.escape_list, additional_kwargs= self.additional_kwargs)       
        
        # validate user input with min and max length
        if len(data) not in range(self.min_length, self.max_length+1):            
            raise serializers.ValidationError({f"{self.attname}": f"{self.attname} should not be greater than {self.max_length} characters"})        

        return data



def clean_input(input_value, escape_list = None, allow_list= None, additional_kwargs = None, **kwargs):
       
    if additional_kwargs is None:
        additional_kwargs = get_additional_kwargs(allowed_tags = None, allowed_attributes = None, allowed_styles = None, allowed_protocols = None, strip_tags = None, strip_comments = None)
    escape_list = escape_list + SANITIZE_LIST if escape_list is not None else SANITIZE_LIST
    escape_list = list(set(escape_list) - set(allow_list)) if allow_list is not None else escape_list
    clean_value = clean(str(input_value), **additional_kwargs, **kwargs)
    for each in escape_list:
        clean_value = clean_value.replace(each, '')
    return clean_value


def get_additional_kwargs(allowed_tags, allowed_attributes, allowed_styles, allowed_protocols, strip_tags, strip_comments):
    
    additional_kwargs = {}
    additional_kwargs['tags'] = allowed_tags if allowed_tags is not None else []
    additional_kwargs['strip'] = strip_tags if strip_tags is not None else True
    additional_kwargs['attributes'] =  allowed_attributes if allowed_attributes is not None else []
    additional_kwargs['styles'] = allowed_styles if allowed_styles is not None else []
    additional_kwargs['protocols'] = allowed_protocols if allowed_protocols is not None else []
    additional_kwargs['strip_comments'] = strip_comments if strip_comments is not None else True

    return additional_kwargs    