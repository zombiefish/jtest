import urllib

from django import template
from django.conf import settings
import re
import requests
register = template.Library()

'''
FRONTEND_HOST_NAME = 'https://devcore-app.sofvie.com/'
FRONTEND_MOBILE_HOST_NAME = 'https://devcore-mobile.sofvie.com/'
'''


@register.simple_tag(name='environment_mobile')
def environment_mobile():
    domain = settings.FRONTEND_MOBILE_HOST_NAME
    return split_domain(domain)

@register.simple_tag(name='environment_app')
def environment_app():
    domain = settings.FRONTEND_HOST_NAME
    return split_domain(domain)


def split_domain(domain):
    try:
        return re.search('//(.*).sofvie.com', domain).group(1)
    except:
        return domain


@register.simple_tag(name='client_logo')
def client_logo():
    client_url = settings.FRONTEND_HOST_NAME.split('-')[0]
    client_url += '-images.sofvie.com/client_logo/logo.png'
    return client_url



