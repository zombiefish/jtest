from django.apps import AppConfig


class CommonUtilsConfig(AppConfig):
    name = 'apps.common_utils'
