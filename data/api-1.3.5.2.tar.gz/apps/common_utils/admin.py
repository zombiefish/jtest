from django.contrib import admin

# Register your models here.
from apps.common_utils.models import *

admin.register(CommonApprover)
admin.register(CommonHeaderData)
admin.register(CommonReviewer)