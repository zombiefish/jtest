from apps.language.models import Language
from rest_framework.response import Response
from django.db.models.expressions import F, Value
from django.db.models import CharField
from django.db.models.functions.text import Concat
from apps.incident_management.api.utlity_function import dictfetchall
from apps.recognition.api.views.get_comment_likes import get_comment_likes_by_com_id
from apps.recognition.api.views.get_comment_list import get_comments_list_by_submission_pid
from apps.recognition.api.views.get_likes_by_positive_recognition_id import get_likes_by_pid
from apps.recognition.models import SubmissionPositiveRecognitionPerson
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from rest_framework.views import APIView
from django.db import connection
from apps.user_settings_profile.models import UserProfile
from apps.recognition.api.views.get_positive_id_stats import get_pid_comments_count, get_pid_likes_count


class GetDiscipline(APIView):
    permission_classes = [SofviePermission]
    def get(self, request):
        userPerID = self.request.user.user_per_id_id        
        with connection.cursor() as cursor:
            cursor.execute("call get_disciplines_by_employee_id(%s)", ([userPerID]))             
            row = dictfetchall(cursor)
        return Response(row)


class GetReview(APIView):
    permission_classes = [SofviePermission]
    def get(self, request):
        userPerID = self.request.user.user_per_id_id
        with connection.cursor() as cursor:
            cursor.execute("call get_review_list_by_employee_id(%s)", ([userPerID]))             
            row = dictfetchall(cursor)
        return Response(row)


class GetPersonProfile(APIView):
    permission_classes = [SofviePermission]
    """ Response for the Current user profile  """
    def get(self, request, user_lang):
        userId = self.request.user.id
        with connection.cursor() as cursor:
            cursor.execute("call get_person_profile(%s, %s)", ([userId], [user_lang]))             
            row = dictfetchall(cursor)
        return Response(row)   


class GetEmployeeCertification(APIView):
    permission_classes = [SofviePermission]
    """ Response for the All Certifications  """
    def get(self, request, user_lang):
        userPerID = self.request.user.user_per_id_id
        with connection.cursor() as cursor:
            cursor.execute("call get_employee_certification_records(%s, %s)", ([userPerID], [user_lang]))             
            row = dictfetchall(cursor)
        return Response(row)



class GetEmployeeTrainingRecords(APIView):
    permission_classes = [SofviePermission]
    """ Response for the All  """
    def get(self, request, user_lang):
        userPerID = self.request.user.user_per_id_id 
        with connection.cursor() as cursor:
            cursor.execute("call get_employee_training_records(%s, %s)", ([userPerID], [user_lang]))             
            row = dictfetchall(cursor)
        return Response(row)  


class GetPersonPositiveRecognition(APIView):
    permission_classes = [SofviePermission]
    """ Response for the All  """
    def get(self, request):
        person_id = self.request.user.user_per_id_id
        recognition_list_data = get_employee_recognition_list(person_id)
        return Response(recognition_list_data)

def get_employee_recognition_list(person_id):
    recognition_list_data = SubmissionPositiveRecognitionPerson.objects.filter(
        recognitionof = person_id,
        submissionpositiverecognition__spr_enable = True
    ).exclude(
        submissionpositiverecognition__submissionheader__isarchived=True
    ).annotate(
        Submitted_By = Concat('submissionpositiverecognition__submissionheader__submittedby_supervisorid__per_last_name', Value(', '), 
                                'submissionpositiverecognition__submissionheader__submittedby_supervisorid__per_first_name', Value(' '),
                                'submissionpositiverecognition__submissionheader__submittedby_supervisorid__per_middle_name', output_field=CharField(),),
        EventDescription = F('submissionpositiverecognition__EventDescription'),
        pid_id = F('submissionpositiverecognition__id'),
        created_date = F('submissionpositiverecognition__submissionheader__formcreationdate'),
        parent_submission_id = F('submissionpositiverecognition__submissionheader__id'),
        parent_form_description_id = F('submissionpositiverecognition__submissionheader__formdescriptionid'),
    ).values(
        'Submitted_By',
        'EventDescription',
        'pid_id',
        'created_date',
        'parent_submission_id',
        'parent_form_description_id'
    ).order_by('-pid_id')

    recognition_list_data = get_pid_comments_count(recognition_list_data, person_id)
    recognition_list_data = get_pid_likes_count(recognition_list_data, person_id)       

    return recognition_list_data     


class GetPersonPositiveRecognitionMobile(APIView):
    permission_classes = [SofviePermission]

    def get(self, request):
        person_id = self.request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per_id = person_id).upr_language
        lng_id = Language.objects.get(lng_name = lng_name).lng_id
        recognition_list_data = get_employee_recognition_list(person_id)
        for recognition in recognition_list_data:
            recognition['likes'] = get_likes_by_pid(recognition['pid_id'], lng_id, person_id)            
            recognition['comments'] = get_comments_list_by_submission_pid(recognition['pid_id'], lng_id, person_id)
            for comment in recognition['comments']:
                comment['likes'] = get_comment_likes_by_com_id(comment['com_id'], lng_id, person_id)

        return Response(recognition_list_data)

