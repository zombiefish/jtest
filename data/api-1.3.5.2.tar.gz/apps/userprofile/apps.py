from django.apps import AppConfig


class UserprofileConfig(AppConfig):
    name = 'apps.userprofile'
