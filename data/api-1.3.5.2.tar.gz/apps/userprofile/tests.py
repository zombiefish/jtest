import sys
sys.path.append('../')
import unittest
# from django.test import Client
# from utils.testing import CountFields
#
# class UserProfileTest(unittest.TestCase):
#     def setUp(self):
#         # Initialize Client
#         self.client = Client()
#
#     def test_discipline(self):
#         # Issue a POST request.
#         response = self.client.post('/api/userprofile/user-discipline/',{"id":"Leclair, Jacques"})
#         self.assertGreater(len(response.data),2)
#         self.assertEqual(response.status_code, 200)
#         self.assertEqual(CountFields(response.data),12)
