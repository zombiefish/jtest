from django.db import models
from django.db import connection

class Discipline(models.Model):
    id = models.IntegerField(db_column='temp_id', primary_key=True)
    FormID = models.IntegerField(db_column='FormID')
    headerId = models.IntegerField(db_column='ID')
    FormSubmissionDate =  models.DateField(db_column='FormSubmissionDate')
    Supervisor =  models.CharField(db_column='Supervisor', max_length=64)
    Site =  models.CharField(db_column='Site', max_length=64)
    JobNumber =  models.CharField(db_column='JobNumber', max_length=32)
    SiteLevel =  models.CharField(db_column='SiteLevel', max_length=64)
    Workplace =  models.CharField(db_column='Workplace', max_length=64)
    event_type =  models.CharField(db_column='event_type', max_length=1)
    employee_name = models.CharField(db_column='employee_name', max_length=50)
    discipline_violation =  models.CharField(db_column='discipline_violation', max_length=1024)
    class Meta:
        managed = False
        db_table = 'all_disciplines' 

class Review(models.Model):
    id = models.IntegerField(db_column='temp_id', primary_key=True)
    Supervisor =  models.CharField(db_column='Supervisor', max_length=64)
    employee_name = models.CharField(db_column='employee_name', max_length=50)
    Site =  models.CharField(db_column='Site', max_length=64)
    JobNumber =  models.CharField(db_column='JobNumber', max_length=32)
    SiteLevel =  models.CharField(db_column='SiteLevel', max_length=64)
    Workplace =  models.CharField(db_column='Workplace', max_length=64)
    FormSubmissionDate =  models.DateField(db_column='FormSubmissionDate')
    goals_1 =  models.CharField(db_column='goals_1', max_length=1024)
    goals_2 =  models.CharField(db_column='goals_2', max_length=1024)
    goals_3 =  models.CharField(db_column='goals_3', max_length=1024)        
    class Meta:
        managed = False
        db_table = 'all_review' 