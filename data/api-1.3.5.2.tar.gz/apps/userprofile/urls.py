from django.urls import path
from apps.userprofile import views

urlpatterns = [
    path('get-user-discipline/', views.GetDiscipline.as_view()),
    path('get-user-review/', views.GetReview.as_view()),
    path('get-person-profile/<str:user_lang>/', views.GetPersonProfile.as_view()),
    path('get-employee-training-record/<str:user_lang>/', views.GetEmployeeTrainingRecords.as_view()),
    path('get-employee-certification-record/<str:user_lang>/', views.GetEmployeeCertification.as_view()),
    path('get-employee-positive-recognition/', views.GetPersonPositiveRecognition.as_view()),
    path('get-employee-positive-recognition-mobile/', views.GetPersonPositiveRecognitionMobile.as_view()),
]
  