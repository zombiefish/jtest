from django.apps import AppConfig


class WorkHourLogConfig(AppConfig):
    name = 'apps.work_hour_log'
