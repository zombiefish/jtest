from django.db import models
from django.db.models import (
    Model,
    AutoField,
    IntegerField,
    CharField,
    DateTimeField,
    ForeignKey,
    BooleanField,
    DecimalField
)

from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.common_utils.views.sofvieModelFields import SofvieCharField, SofvieIntegerField, SofvieTextField

class workHoursLog(Model):
    whl_id = AutoField(primary_key=True)
    whl_hours_worked = DecimalField(max_digits=15, decimal_places=2, help_text='Enter decimal values')
    whl_site = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, related_name='whl_rld_site_id', blank=True, null=True, help_text='Enter foreign key of ref_list_detail table')
    whl_job = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, related_name='whl_rld_job_id', blank=True, null=True, help_text='Enter foreignkey of ref_list_detail table')
    whl_level_of_detail = IntegerField()
    whl_start_date = DateTimeField()
    whl_end_date = DateTimeField()
    whl_created_date = DateTimeField(auto_now_add=True)
    whl_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='whl_person_id', help_text='Enter foreignkey of person table')
    whl_modified_date = DateTimeField(blank=True, null=True)
    whl_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='whl_modified_person_id', help_text='Enter foreignkey of person table')
    whl_enable = BooleanField(default=True)
    whl_enote = SofvieTextField(null=True, blank=True)

    class Meta:
        db_table = 'work_hours_log'

    def site_name(self):
        tag_name = self.whl_site.rld_name
        tag_type = self.whl_site.rld_tag_type
        return \
            {
            "tag_name": tag_name,
            "tag_type": tag_type
            }
        # person = self.request.user.user_per_id_id
        # user_language = UserProfile.objects.get(upr_per=person).upr_language
        # lang_id = Language.objects.get(lng_name=user_language)
        #
        # return LanguageTranslation.objects.filter(ltr_tag=tag_name, ltr_lng_id=lang_id, ltr_tag_type=tag_type).values('ltr_text')

    def person_full_name(self):
        if not self.whl_modified_by_per:
          return\
              {
                "modified_by": None,
                "created_by": self.whl_created_by_per.full_name
                }
        else:
            return \
                {
                    "modified_by": self.whl_modified_by_per.full_name,
                    "created_by": self.whl_created_by_per.full_name
                }


class RecordableIncidentInjury(Model):
    rii_id = AutoField(primary_key=True)
    rii_rld = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, related_name='rii_rld_type_id', help_text='Enter foreign key of ref_list_detail table')
    rii_type = SofvieIntegerField()
    rii_created_date = DateTimeField(auto_now_add=True)
    rii_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rii_created_person_id', help_text='Enter foreignkey of person table')
    rii_modified_date = DateTimeField(blank=True, null=True)
    rii_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='rii_modified_person_id', help_text='Enter foreignkey of person table')
    rii_enable = BooleanField(default=True)
    rii_enote = SofvieTextField(null=True, blank=True)

    class Meta:
        db_table = 'recordable_incident_injury'


class SystemSettings(Model):
    sys_id = AutoField(primary_key=True)
    sys_setting_type = SofvieIntegerField()
    sys_setting_name = SofvieCharField(max_length=100)
    sys_setting_value = SofvieIntegerField()
    sys_created_date = DateTimeField(auto_now_add=True)
    sys_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='sys_created_person_id', help_text='Enter foreignkey of person table')
    sys_modified_date = DateTimeField(blank=True, null=True)
    sys_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='sys_modified_person_id', help_text='Enter foreignkey of person table', blank=True, null=True)
    sys_enable = BooleanField(default=True)
    sys_enote = SofvieTextField(null=True, blank=True)

    class Meta:
        db_table = 'system_settings'






