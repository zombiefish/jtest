import datetime

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.work_hour_log.api.serializer.serializer import WorkHourLogSerializer
from apps.work_hour_log.models import workHoursLog


class UpdateWorkHoursLog(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageHoursLog.value, RolePermission.CanViewTRIFRManager.value,)

    def put(self, request, whl_id):
        person_id = self.request.user.user_per_id_id

        try:
            work_hour_log = workHoursLog.objects.get(whl_id=whl_id)

            serializer = WorkHourLogSerializer(work_hour_log, data=request.data, context={'request': request})
            request.data['whl_modified_by_per'] = person_id
            request.data['whl_modified_date'] = datetime.datetime.now()
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except workHoursLog.DoesNotExist:
            return Response({'error': f'Work hour log object id: {whl_id} does not exist'}, status=status.HTTP_404_NOT_FOUND)
