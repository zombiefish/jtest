from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.work_hour_log.models import SystemSettings


class GetLevelofDetailSetting(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewTRIFRManager.value,)

    def get(self, request):

        queryset = SystemSettings.objects.filter(sys_setting_type=3).values('sys_setting_value')[0]
        return Response(queryset['sys_setting_value'])