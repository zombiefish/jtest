from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.work_hour_log.models import workHoursLog


class GetLastEndDate(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanAddHoursLog.value, RolePermission.CanViewTRIFRManager.value, RolePermission.CanManageHoursLog.value)

    def get(self, request, *args, **kwargs):
        sys_setting_type = self.request.query_params.get('sys_setting_type', None)
        rld_id = self.request.query_params.get('rld_id', None)
        if sys_setting_type == '3':
            queryset = workHoursLog.objects.filter(whl_level_of_detail=sys_setting_type, whl_enable=True, whl_job=rld_id).values('whl_end_date').order_by('-whl_end_date')[:1]

            return Response(queryset)
        elif sys_setting_type == '2':
            queryset = workHoursLog.objects.filter(whl_level_of_detail=sys_setting_type, whl_enable=True, whl_site=rld_id).values('whl_end_date').order_by('-whl_end_date')[:1]

            return Response(queryset)
        else:
            queryset = workHoursLog.objects.filter(whl_enable=True).values('whl_end_date').order_by('-whl_end_date')[:1]

            return Response(queryset, status=status.HTTP_200_OK)



