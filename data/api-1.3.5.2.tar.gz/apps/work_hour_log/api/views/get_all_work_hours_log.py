from django.db.models import Subquery, F, OuterRef
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.language.models import LanguageTranslation, Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from apps.work_hour_log.models import workHoursLog


class GetAllWorkHoursLog(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewTRIFRManager.value,)

    def get(self, request):
        
        person_id = request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per= person_id).upr_language 
        lng_id = Language.objects.get(lng_name = lng_name)    
        work_hour_log = workHoursLog.objects.filter(whl_enable=True).annotate(
            tag_whl_site = F("whl_site__rld_name"),
            tag_whl_job = F("whl_job__rld_name"),
            tag_type_whl_site = F("whl_site__rld_tag_type"),
            tag_type_whl_job = F("whl_job__rld_tag_type"),
            whl_site_name = Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_whl_site'),ltr_tag_type=OuterRef('tag_type_whl_site'), ltr_lng = lng_id).values('ltr_text')[:1]
                            ),
            whl_job_name = Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_whl_job'),ltr_tag_type=OuterRef('tag_type_whl_job'), ltr_lng = lng_id).values('ltr_text')[:1]
                            ),
        ).values(
            'whl_id',
            'whl_hours_worked',
            'whl_site',
            'whl_job',
            'whl_level_of_detail',
            'whl_start_date',
            'whl_end_date',
            'whl_created_date',
            'whl_created_by_per',
            'whl_modified_date',
            'whl_modified_by_per',
            "whl_site_name",
            "whl_job_name"
        )
        return Response(work_hour_log, status=status.HTTP_200_OK)