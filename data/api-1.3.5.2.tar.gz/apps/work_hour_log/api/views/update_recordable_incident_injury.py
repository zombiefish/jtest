import datetime
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.work_hour_log.models import RecordableIncidentInjury, SystemSettings


class UpdateRecordableIncidentInjury(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageHoursLog.value, RolePermission.CanViewTRIFRManager.value,)

    def put(self, request, rii_type):

        person_id = self.request.user.user_per_id_id
        input_rld_id = request.data.pop('rii_rld_id', None)
        sys_setting_type = request.data.pop('sys_setting_type', None)
        sys_setting_value = request.data['sys_setting_value']
        try:
            existing_ids = list(RecordableIncidentInjury.objects.filter(rii_type=rii_type, rii_enable=True).values_list('rii_rld', flat=True))

            deleted_ids = list(set(existing_ids).difference(set(input_rld_id)))
            new_ids = list(set(input_rld_id).difference(set(existing_ids)))

            disable = RecordableIncidentInjury.objects.filter(rii_rld__in=deleted_ids, rii_type=rii_type).update(
                rii_enable=False,
                rii_modified_by_per_id=person_id,
                rii_modified_date=datetime.datetime.now()
            )
            RecordableIncidentInjury.objects.bulk_create([

                RecordableIncidentInjury(
                    rii_rld_id=n,
                    rii_type=rii_type,
                    rii_created_by_per_id=person_id
                ) for n in new_ids
            ])

            """ When option 'Class' is selected, rii_type = 3 and trifr and trir metrics need not   be updated as well as TRIR INCIDENT OPTION should be updated as 3 (ie Class) otherwise the TRIR INCIDENT OPTION should be updated as 2 (ie Type)

            Also, if rii_type = 3, then TRIR metric also should be updated as per the payload
            otherwise, the TRIFR /TRIR metric should be updated based on the rii type from the payload

            To Summarize,
            rii_type = 1 -> TRIFR and its metric (sys_setting_type = 1)
            rii_type = 2 -> TRIR with 'Type' as the selected option and TRIR metric (sys_setting_type = 2)
                         -> TRIR INCIDENT OPTION = 2
            rii_type = 3 -> TRIR with 'Class' as the selected option and TRIR metric          (sys_setting_type = 2)
                         -> TRIR INCIDENT OPTION = 3

            """

            update_trifr_trir_merics = SystemSettings.objects.filter(sys_setting_type=sys_setting_type, sys_enable=True).update(
                    sys_setting_value=sys_setting_value,
                    sys_modified_date = datetime.datetime.now(),
                    sys_modified_by_per_id = person_id
            )
            if not rii_type == 1:
                update_trir_incident_option = SystemSettings.objects.filter(sys_setting_type=6, sys_enable=True).update(
                    sys_setting_value=rii_type,
                    sys_modified_date = datetime.datetime.now(),
                    sys_modified_by_per_id = person_id
                )

            return Response({"message": "Metric Updated Successfully"}, status=status.HTTP_200_OK)
        except:
            return Response({"message": "Something went wrong"}, status=status.HTTP_400_BAD_REQUEST)
