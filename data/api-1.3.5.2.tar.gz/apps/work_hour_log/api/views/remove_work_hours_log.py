from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.work_hour_log.models import workHoursLog


class RemoveWorkHoursLog(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageHoursLog.value, RolePermission.CanViewTRIFRManager.value,)

    def delete(self, request, whl_id):
        whl_delete = workHoursLog.objects.get(whl_id=whl_id)
        whl_delete.whl_enable = False
        whl_delete.save()

        return Response({"message": "Record Removed Successfully", "whl_id": whl_id})