from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.work_hour_log.api.serializer.serializer import WorkHourLogSerializer
from apps.work_hour_log.models import workHoursLog


class GetSingleWorkHorLog(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewTRIFRManager.value,)

    def get(self, request, whl_id):
        try:
            work_hour_log = workHoursLog.objects.get(whl_id=whl_id)
            serializer = WorkHourLogSerializer(work_hour_log, context={'request': request})
            return Response(serializer.data)
        except workHoursLog.DoesNotExist:
            return Response({'error': 'Work hour log not found'}, status=status.HTTP_404_NOT_FOUND)
