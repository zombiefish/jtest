import datetime

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.work_hour_log.models import SystemSettings


class UpdateLevelofDetailSetting(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageHoursLog.value, RolePermission.CanViewTRIFRManager.value,)

    def put(self, request, sys_setting_value):
        person_id = self.request.user.user_per_id_id
        try:
            queryset = SystemSettings.objects.get(sys_setting_type=3)
            queryset.sys_setting_value = sys_setting_value
            queryset.sys_modified_by_per_id = person_id
            queryset.sys_modified_date = datetime.datetime.now()
            queryset.save()
            return Response({"message": "updated successfully"})

        except SystemSettings.DoesNotExist:
            return Response({'error': f'System setting object id: {sys_setting_value} does not exist'}, status=status.HTTP_404_NOT_FOUND)