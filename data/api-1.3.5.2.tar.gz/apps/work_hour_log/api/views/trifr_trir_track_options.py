import datetime
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.work_hour_log.models import SystemSettings

class GetTrifrTrirTrackOption(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def get(self, request):
        # Get TRIFR and TRIR Track options
        track_options = SystemSettings.objects.filter(sys_setting_type=7, sys_enable=1).values('sys_setting_name', 'sys_setting_value')
        result = {item['sys_setting_name'] : bool(item['sys_setting_value']) for item in track_options}
        return Response({"trifr_track_option": result['TRACK TRIFR'], "trir_track_option": result['TRACK TRIR']})

class UpdateTrifrTrirTrackOption(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def put(self, request, track_type):
        person_id = self.request.user.user_per_id_id
        track = request.data.pop('track', 1)
        try:
            # Get TRIFR and TRIR Track options
            trifr_track_option = SystemSettings.objects.filter(sys_setting_type=7, sys_setting_name=track_type, sys_enable=1).update(
                sys_setting_value =  track,
                sys_modified_date = datetime.datetime.now(),
                sys_modified_by_per_id = person_id
            )
            return Response({"message": "Track option Updated Successfully"}, status=status.HTTP_200_OK)
        except:
            return Response({"message": "Something went wrong"}, status=status.HTTP_400_BAD_REQUEST)

class GetTrirIncidentTypeOption(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def get(self, request):
        # Get TRIR Incident type option
        trir_incident_type_option = SystemSettings.objects.filter(sys_setting_type=6, sys_setting_name='TRIR INCIDENT OPTION', sys_enable=1).values('sys_setting_value')[0]
        return Response({"trir_incident_type_option": trir_incident_type_option['sys_setting_value']}, status=status.HTTP_200_OK)