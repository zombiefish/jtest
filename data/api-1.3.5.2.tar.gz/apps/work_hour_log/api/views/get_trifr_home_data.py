import datetime

import pandas as pd
from django.db import connection
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.work_hour_log.models import RecordableIncidentInjury, workHoursLog, SystemSettings
from apps.home.api.views.common_functions_home_page import verify_sites_jobs

def days_between(d1, d2):
    d1 = datetime.datetime.strptime(d1, "%Y-%m-%d")
    d2 = datetime.datetime.strptime(d2, "%Y-%m-%d")
    return abs((d2 - d1).days)


class GetTrifrHomeData(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def post(self, request):
        """
        req_param can be last_incident, last_injury, trifr_data
        """

        person_id = self.request.user.user_per_id_id
        self.site_ids = request.data.get('selected_site_ids', [])
        req_param = request.data['req_param']
        req_date_range = request.data.get('req_date_range', 'past_year')

        verify_sites_jobs(self, person_id, include_jobs= False)
        site_id_list = self.sites.split(",") if self.sites else [] 

        if req_param == 'last_incident':
            last_incident = None
            days_since_last_incident_sp = 'get_days_since_last_incident_by_site'
            with connection.cursor() as cursor:
                cursor.execute(f'call {days_since_last_incident_sp}(%s)',([self.sites]))
                last_incident = cursor.fetchone()
            if last_incident:
                return Response({"days_since_last_incident_by_site": last_incident[0], "days_since_last_incident_company_wide": last_incident[1]})
            else:
                return Response({"days_since_last_incident_by_site": None, "days_since_last_incident_company_wide": None})

        elif req_param == 'last_injury':
            days_since_last_injury = None
            recordable_incident_injury = RecordableIncidentInjury.objects.filter(rii_type=1, rii_enable=True).values_list('rii_rld', flat=True)
            if recordable_incident_injury:
                recordable_incident_injury_string = ",".join(str(rld_id) for rld_id in recordable_incident_injury)
                # Getting days since last injury using a raw query
                with connection.cursor() as cursor:
                    days_since_last_injury_sp = 'get_days_since_last_injury_by_site'                    
                    cursor.execute(f'call {days_since_last_injury_sp}(%s,%s)', ([recordable_incident_injury_string], [self.sites]))                    
                    days_since_last_injury = cursor.fetchone()
                if days_since_last_injury:
                    return Response({"days_since_last_injury_by_site": days_since_last_injury[0], "days_since_last_injury_company_wide": days_since_last_injury[1]})
            return Response({"days_since_last_injury_by_site": None, "days_since_last_injury_company_wide": None})
        elif req_param == 'trifr_data':
            trifr_final_number = 0
            trir_final_number = 0
            num_of_work_hours = 0
            trir_incident_track_type = 'inc_type'
            rii_type = 2
            trifr_trir_track_option = 'both'
            today = datetime.datetime.now()
            if req_date_range == 'past_year':
                start_date_timestamp = today - datetime.timedelta(days=365)
            else:
                start_date_timestamp = str(today.replace(month = 1, day = 1, hour=0, minute=0, second=0, microsecond=0))
    
            trifr_system_setting = SystemSettings.objects.filter(sys_setting_type=1, sys_enable=1).values('sys_setting_value')[0]
            trir_system_setting = SystemSettings.objects.filter(sys_setting_type=2, sys_enable=1).values('sys_setting_value')[0]
            level_of_detail = SystemSettings.objects.filter(sys_setting_type=3, sys_enable=1).values('sys_setting_value')[0]
            level_of_detail = level_of_detail['sys_setting_value']
            # Get the TRIR Incident Option
            trir_incident_option = SystemSettings.objects.filter(sys_setting_type=6, sys_enable=1).values('sys_setting_value')[0]
            trir_incident_option = trir_incident_option['sys_setting_value']

            if trir_incident_option == 2:
                trir_incident_track_type = 'inc_type'
                rii_type = 2
            elif trir_incident_option == 3:
                trir_incident_track_type = 'inc_class'
                rii_type = 3
            
            recordable_incident_injury = RecordableIncidentInjury.objects.filter(rii_type=1, rii_enable=True).values_list('rii_rld', flat=True)
            if recordable_incident_injury:
                recordable_incident_injury_string = ",".join(str(rld_id) for rld_id in recordable_incident_injury)
            recordable_incident = RecordableIncidentInjury.objects.filter(rii_type=rii_type, rii_enable=True).values_list('rii_rld', flat=True)

            # This query fetches the Incidents with the incident types of RCA and preliminary incident
            row = None
            if level_of_detail == 1:
                get_work_hours_log = workHoursLog.objects.filter(whl_start_date__gte=start_date_timestamp,whl_end_date__lte=today, whl_enable=True).values(
                    'whl_hours_worked',
                    'whl_start_date',
                )
                work_hour_log_df = pd.DataFrame(get_work_hours_log)
                level_of_detail = '1094'
                if work_hour_log_df.empty:
                    return Response({"trir": None, "trifr": None, "level_of_detail": level_of_detail})
                with connection.cursor() as cursor:
                    cursor.execute(f'call get_trifr_trir_analytics_data',)
                    row = dictfetchall(cursor)
            else:
                get_work_hours_log = workHoursLog.objects.filter(whl_start_date__gte=start_date_timestamp,whl_end_date__lte=today,whl_site_id__in=site_id_list, whl_enable=True).values(
                    'whl_hours_worked',
                    'whl_start_date',
                )
                work_hour_log_df = pd.DataFrame(get_work_hours_log)
                level_of_detail = '3836'
                if work_hour_log_df.empty:
                    return Response({"trir": None, "trifr": None, "level_of_detail": level_of_detail})
                with connection.cursor() as cursor:
                    cursor.execute(f'call get_trifr_trir_analytics_data_by_site(%s)', ([self.sites]))
                    row = dictfetchall(cursor)

            df = pd.DataFrame(row).fillna(0)

            if df.empty:
                return Response({"trir": trir_final_number, "trifr": trifr_final_number, "level_of_detail": level_of_detail})

            df = df.query('incident_date >= @start_date_timestamp and incident_date <=@today')

            # Converting the columns 'rca_type_and_class_ids' and 'incident_type_and_class_ids' into integer
            df['rca_type_and_class_ids'] = df['rca_type_and_class_ids'].astype(int)
            df['incident_type_and_class_ids'] = df['incident_type_and_class_ids'].astype(int)

            # Isolating the records with RCA incident type present in Recordable injuries
            trifr_rca_query = df.query('rca_type_and_class_ids in @recordable_incident_injury and incident_track_type=="inc_type"', inplace=False)
            trifr_total = len(trifr_rca_query)
            trifr_without_rca_query = df.query('rca_type_and_class_ids == 0 and incident_track_type=="inc_type"', inplace=False)

            # Isolating the records without RCA  and with incident types of preliminary incident present in Recordable injuries
            if not trifr_without_rca_query.empty:
                trifr_preliminary_query = trifr_without_rca_query.query('incident_type_and_class_ids in @recordable_incident_injury and incident_track_type=="inc_type"', inplace=False)
                trifr_total += len(trifr_preliminary_query)
            
            # Isolating the records with RCA incident type present in Recordable injuries
            trir_rca_query = df.query('rca_type_and_class_ids in @recordable_incident and incident_track_type==@trir_incident_track_type', inplace=False)
            trir_total = len(trir_rca_query)
            trir_without_rca_query = df.query('rca_type_and_class_ids == 0 and incident_track_type==@trir_incident_track_type', inplace=False)

            # Isolating the records without RCA  and with incident types of preliminary incident present in Recordable injuries
            if not trir_without_rca_query.empty:
                trir_preliminary_query = trir_without_rca_query.query('incident_type_and_class_ids in @recordable_incident and incident_track_type==@trir_incident_track_type', inplace=False)
                trir_total += len(trir_preliminary_query)

            if not work_hour_log_df.empty:
                num_of_work_hours = work_hour_log_df['whl_hours_worked'].sum()
                # Added conditions to qualify the data
                trifr_final_number = round(trifr_total * trifr_system_setting['sys_setting_value']/num_of_work_hours, 2) if num_of_work_hours !=0 else None
                trir_final_number = round(trir_total * trir_system_setting['sys_setting_value']/num_of_work_hours, 2) if num_of_work_hours !=0 else None              
                
            return Response({"trir": trir_final_number, "trifr": trifr_final_number, "level_of_detail": level_of_detail})