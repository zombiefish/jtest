import datetime

import pandas as pd
from django.db import connection
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.work_hour_log.models import RecordableIncidentInjury, workHoursLog, SystemSettings


def days_between(d1, d2):
    d1 = datetime.datetime.strptime(d1, "%Y-%m-%d")
    d2 = datetime.datetime.strptime(d2, "%Y-%m-%d")
    return abs((d2 - d1).days)
def daterange(date1, date2):
            for n in range(int ((date2 - date1).days)+1):
                yield date1 + datetime.timedelta(n)

def breakupHours(work_hour_log_df):
    newHours = []
    for index, row in work_hour_log_df.iterrows():            
        start_dt = datetime.datetime.strptime(str(row['whl_start_date']), '%Y-%m-%d %H:%M:%S').date()
        end_dt = datetime.datetime.strptime(str(row['whl_end_date']), '%Y-%m-%d %H:%M:%S').date()
        numDays = (end_dt - start_dt).days
        dayHours = row['whl_hours_worked'] / numDays
        for dt in daterange(start_dt, end_dt):
            newHours.append({
                "whl_hours_worked": dayHours,
                "whl_start_date": dt.strftime("%Y-%m-%d"),
                "whl_end_date": dt.strftime("%Y-%m-%d")
            })
    finalHours = pd.DataFrame(newHours).groupby(['whl_start_date','whl_end_date'])['whl_hours_worked'].sum().reset_index()
    return finalHours
class GetTrifrAnalyticData(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewAnalyticsIncidents.value,)    

    def get(self, request):

        trir_incident_track_type = 'inc_type'
        rii_type = 2

        # Get Track option for TRIFR and TRIR charts
        track_options = SystemSettings.objects.filter(sys_setting_type=7, sys_enable=1).values('sys_setting_name', 'sys_setting_value')
        track_options = {item['sys_setting_name'] : bool(item['sys_setting_value']) for item in track_options}

        # Raw query to get the incident data
        get_trifr_trir_analytics_data_sp = 'get_trifr_trir_analytics_data'

        # Get the metric for trifr
        trifr_system_setting = SystemSettings.objects.filter(sys_setting_type=1, sys_enable=1).values('sys_setting_value')[0]
        # Get the metric for trir
        trir_system_setting = SystemSettings.objects.filter(sys_setting_type=2, sys_enable=1).values('sys_setting_value')[0]
        # Get the TRIR Incident Option
        trir_incident_option = SystemSettings.objects.filter(sys_setting_type=6, sys_enable=1).values('sys_setting_value')[0]
        trir_incident_option = trir_incident_option['sys_setting_value']

        if trir_incident_option == 2:
            trir_incident_track_type = 'inc_type'
            rii_type = 2
        elif trir_incident_option == 3:
            trir_incident_track_type = 'inc_class'
            rii_type = 3
        
        # Execute the raw query for dataframe
        with connection.cursor() as cursor:            
            cursor.execute(f"call {get_trifr_trir_analytics_data_sp}",)            
            row = dictfetchall(cursor)            
            df = pd.DataFrame(row).fillna(0)
        if len(row) > 0:

            df['rca_type_and_class_ids'] = df['rca_type_and_class_ids'].astype(int)
            df['incident_type_and_class_ids'] = df['incident_type_and_class_ids'].astype(int)

            # Get the rld_id for trifr
            recordable_incident_injury = RecordableIncidentInjury.objects.filter(rii_type=1, rii_enable=True).values_list('rii_rld', flat=True)
            # Get the rld_id for trir
            recordable_incident = RecordableIncidentInjury.objects.filter(rii_type=rii_type, rii_enable=True).values_list('rii_rld', flat=True)
            # Get the data work hours log
            hours_date = datetime.datetime.now() - datetime.timedelta(days=365)
            get_work_hours_log = workHoursLog.objects.filter(whl_start_date__gt=hours_date ,whl_enable=True).values(
                'whl_hours_worked',
                'whl_start_date',
                'whl_end_date'
            )
            # Creating dataframe for work hours log
            work_hour_log_df = pd.DataFrame(get_work_hours_log)

            # breakup hours when user entered long hours for multiple days at a time
            work_hour_log_df = breakupHours(work_hour_log_df)

            # Create the object for chart points
            now1 = str(datetime.datetime.now().year) + '-01-01'

            past_year_date = datetime.datetime.now() - datetime.timedelta(days=365)
            past_year_date = str(past_year_date)[:10]

            today = datetime.datetime.now()
            today = str(today)[:10]
            aDate = datetime.datetime.strptime(now1, "%Y-%m-%d")
            today1 = datetime.datetime.strptime(str(today), "%Y-%m-%d")
            threeWeeks = datetime.timedelta(weeks=1)
            final_weeks = abs(today1 - aDate).days // 7
            final_weeks_past_year = 52

            trifr_ytd = []
            trifr_past_year = []

            for w in range(1, final_weeks + 1):
                one_week = datetime.timedelta(weeks=w)
                trifr_ytd.append(
                    {
                        "start_date": now1,
                        "end_date": str(aDate + one_week)[:10],
                        "trifr": 5.5,
                        "trir": 3.5
                    }
                )

            # Adding today's date when the last end date in the list is not today
            if trifr_ytd[-1]['end_date'] != today:
                trifr_ytd.append(
                    {
                        "start_date": now1,
                        "end_date": today,
                        "trifr": 5.5,
                        "trir": 3.5
                    }
                )
            for w in range(1, final_weeks_past_year + 1):
                one_week = datetime.timedelta(weeks=w)
                trifr_past_year.append(
                    {
                        "start_date": past_year_date,
                        "end_date": str(hours_date + one_week)[:10],
                        "trifr": 5.5,
                        "trir": 3.5
                    }
                )

            # Adding today's date when the last end date in the list is not today
            if trifr_past_year[-1]['end_date'] != today:
                trifr_past_year.append(
                    {
                        "start_date": past_year_date,
                        "end_date": today,
                        "trifr": 5.5,
                        "trir": 3.5
                    }
                )

            def calculate_trifr_trir(start_date, end_date, metric=None, incident_value=None, incident_track_type = 'inc_type'):
                trifr_trir_rca_query = df.query('rca_type_and_class_ids in @incident_value and incident_date >=@start_date and incident_date <= @end_date and incident_track_type == @incident_track_type', inplace=False)
                trifr_trir_total = len(trifr_trir_rca_query)
                trifr_trir_without_rca_query = df.query('rca_type_and_class_ids == 0 and incident_date >=@start_date and incident_date <= @end_date and incident_track_type == @incident_track_type', inplace=False)
                
                if not trifr_trir_without_rca_query.empty:
                    trifr_trir_preliminary_query = trifr_trir_without_rca_query.query('incident_type_and_class_ids in @incident_value and incident_date >=@start_date and incident_date <= @end_date and incident_track_type == @incident_track_type', inplace=False)
                    trifr_trir_total += len(trifr_trir_preliminary_query)

                trifr_trir_final_number = 0
                total_hours = 0
                if not work_hour_log_df.empty:
                    # Included whl_end_date in the condition to get the number of hours worked between the date range
                    work_hours = work_hour_log_df.query('whl_start_date >= @start_date and whl_end_date<=@end_date')
                    total_hours = work_hours['whl_hours_worked'].sum()
                # Added the below condition to avoid Division by zero error
                if total_hours>0:
                    trifr_trir_final_number = round(trifr_trir_total * metric['sys_setting_value'] / total_hours, 2)
                return trifr_trir_final_number

            # Create the dataframe for charts point trifr_ytd
            date_range_df = pd.DataFrame(trifr_ytd)

            date_range_df['trifr'] = date_range_df.apply(lambda x: calculate_trifr_trir(x.start_date, x.end_date, trifr_system_setting, recordable_incident_injury, 'inc_type'), axis=1)
            date_range_df['trir'] = date_range_df.apply(lambda x: calculate_trifr_trir(x.start_date, x.end_date, trir_system_setting, recordable_incident, trir_incident_track_type), axis=1)


            # Create the dataframe for charts point past year
            date_range_past_year = pd.DataFrame(trifr_past_year)

            date_range_past_year['trifr'] = date_range_past_year.apply(lambda x: calculate_trifr_trir(x.start_date, x.end_date, trifr_system_setting, recordable_incident_injury, 'inc_type'), axis=1)
            date_range_past_year['trir'] = date_range_past_year.apply(lambda x: calculate_trifr_trir(x.start_date, x.end_date, trir_system_setting, recordable_incident, trir_incident_track_type), axis=1)


            response_plotly_json = []
            response_plotly_json_past_year = []
            response_plotly_json.append({
                "dates": date_range_df['end_date'],
                "y_axis_trifr": date_range_df['trifr'] if track_options['TRACK TRIFR'] else [],
                "y_axis_trir": date_range_df['trir'] if track_options['TRACK TRIR'] else [],

            })

            response_plotly_json_past_year.append({
                "dates": date_range_past_year['end_date'],
                "y_axis_trifr": date_range_past_year['trifr'] if track_options['TRACK TRIFR'] else [],
                "y_axis_trir": date_range_past_year['trir'] if track_options['TRACK TRIR'] else [],
            })

            return Response({"trifr_ytd": response_plotly_json, "trifr_past_year": response_plotly_json_past_year, "trifr_track_option": track_options['TRACK TRIFR'], "trir_track_option": track_options['TRACK TRIR']})


        else:
            return Response({"trifr_ytd": [], "trifr_past_year": [], "trifr_track_option": track_options['TRACK TRIFR'], "trir_track_option": track_options['TRACK TRIR']})