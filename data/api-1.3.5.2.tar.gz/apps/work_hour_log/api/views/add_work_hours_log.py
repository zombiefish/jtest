from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.work_hour_log.api.serializer.serializer import WorkHourLogSerializer


class AddWorkHoursLog(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanAddHoursLog.value, RolePermission.CanViewTRIFRManager.value,)


    def post(self, request):
        person_id = self.request.user.user_per_id_id

        serializer = WorkHourLogSerializer(data=request.data, context={'request': request})

        request.data['whl_created_by_per'] = person_id

        if serializer.is_valid():

            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
