from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.work_hour_log.models import RecordableIncidentInjury, SystemSettings


class GetRecordableIncidentInjury(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewTRIFRManager.value,)

    def get(self, request, rii_type=None):

        try:
            rii = RecordableIncidentInjury.objects.filter(rii_type=rii_type, rii_enable=True).values_list(
                'rii_rld', flat=True
            )
            system_setting = None
            if not rii_type == 3:
                system_setting = SystemSettings.objects.filter(sys_setting_type=rii_type, sys_enable=True).values('sys_setting_value')[0]

            result = {
                'rii_type': rii_type,
                'rii_rld_id': rii,
                'sys_setting_type': rii_type if system_setting else None,
                'sys_setting_value': system_setting['sys_setting_value'] if system_setting else None
            }

            return Response(result, status=status.HTTP_200_OK)
        except IndexError:
            return Response("Object not found", status=status.HTTP_404_NOT_FOUND)
