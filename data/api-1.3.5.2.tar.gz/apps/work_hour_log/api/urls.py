from django.urls import path

from apps.work_hour_log.api.views.add_work_hours_log import AddWorkHoursLog
from apps.work_hour_log.api.views.get_all_work_hours_log import GetAllWorkHoursLog
from apps.work_hour_log.api.views.get_last_end_date import GetLastEndDate
from apps.work_hour_log.api.views.get_level_of_detail_setting import GetLevelofDetailSetting
from apps.work_hour_log.api.views.get_recordable_incident_injury import GetRecordableIncidentInjury
from apps.work_hour_log.api.views.get_single_work_hours_log import GetSingleWorkHorLog
from apps.work_hour_log.api.views.get_trifr_analytics_data import GetTrifrAnalyticData
from apps.work_hour_log.api.views.get_trifr_home_data import GetTrifrHomeData
from apps.work_hour_log.api.views.remove_work_hours_log import RemoveWorkHoursLog
from apps.work_hour_log.api.views.update_level_of_detail_setting import UpdateLevelofDetailSetting
from apps.work_hour_log.api.views.update_recordable_incident_injury import UpdateRecordableIncidentInjury
from apps.work_hour_log.api.views.update_work_hours_log import UpdateWorkHoursLog
from apps.work_hour_log.api.views.trifr_trir_track_options import GetTrifrTrirTrackOption, UpdateTrifrTrirTrackOption, GetTrirIncidentTypeOption

urlpatterns = [
    path('add-work-hours-log/', AddWorkHoursLog.as_view()),
    path('get-all-work-hours-log/', GetAllWorkHoursLog.as_view()),
    path('get-level-of-detail-setting/', GetLevelofDetailSetting.as_view()),
    path('get-recordable-incident-injury/<int:rii_type>/', GetRecordableIncidentInjury.as_view()),
    path('get-single-work-hours-log/<int:whl_id>/', GetSingleWorkHorLog.as_view()),
    path('get-trifr-analytics-data/', GetTrifrAnalyticData.as_view()),
    path('get-trifr-home-data/', GetTrifrHomeData.as_view()),
    path('remove-work-hours-log/<int:whl_id>/', RemoveWorkHoursLog.as_view()),
    path('update-level-of-detail-setting/<int:sys_setting_value>/', UpdateLevelofDetailSetting.as_view()),
    path('update-work-hours-log/<int:whl_id>/', UpdateWorkHoursLog.as_view()),
    path('update-recordable-incident-injury/<int:rii_type>/', UpdateRecordableIncidentInjury.as_view()),
    path('get-last-end-date/', GetLastEndDate.as_view()),
    path('get-trifr-trir-track-option/', GetTrifrTrirTrackOption.as_view()),
    path('get-trir-incident-type-option/', GetTrirIncidentTypeOption.as_view()),
    path('update-trifr-trir-track-option/<str:track_type>/', UpdateTrifrTrirTrackOption.as_view()),
]
