from rest_framework.fields import SerializerMethodField
from rest_framework.serializers import ModelSerializer

from apps.language.models import Language, LanguageTranslation
from apps.reflist.models import RefListDetail
from apps.user_settings_profile.models import UserProfile
from apps.work_hour_log.models import workHoursLog, RecordableIncidentInjury, SystemSettings


class WorkHourLogSerializer(ModelSerializer):
    person_full_name = SerializerMethodField()

    class Meta:
        model = workHoursLog
        fields = (
            'whl_id',
            'whl_hours_worked',
            'whl_site',
            'whl_job',
            'whl_level_of_detail',
            'whl_start_date',
            'whl_end_date',
            'whl_created_date',
            'whl_created_by_per',
            'whl_modified_date',
            'whl_modified_by_per',
            'person_full_name',
        )


    def get_person_full_name(self, obj):
        return obj.person_full_name()


    def to_representation(self, instance):
        ret = super().to_representation(instance)
        person = self.context['request'].user.user_per_id
        ret['whl_site_name'] = None
        ret['whl_job_name'] = None
        lng_name = UserProfile.objects.get(upr_per=person).upr_language
        lng_id = Language.objects.get(lng_name=lng_name)
        if instance.whl_site_id:
            get_ref_list = RefListDetail.objects.get(rld_id=instance.whl_site_id)
            trans = LanguageTranslation.objects.filter(ltr_tag=get_ref_list.rld_name, ltr_tag_type=get_ref_list.rld_tag_type, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
            ret['whl_site_name'] = trans
        if instance.whl_job_id:
            get_ref_list_job = RefListDetail.objects.get(rld_id=instance.whl_job_id)
            trans2 = LanguageTranslation.objects.filter(ltr_tag=get_ref_list_job.rld_name, ltr_tag_type=get_ref_list_job.rld_tag_type, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
            ret['whl_job_name'] = trans2

        return ret


class RecordableIncidentInjurySerializer(ModelSerializer):


    class Meta:
        model = RecordableIncidentInjury
        fields = (
            'rii_id',
            'rii_rld',
            'rii_type',
        )


class GetLevelofDetailSettingSerializer(ModelSerializer):
    class Meta:
        model = SystemSettings
        exclude = ('sys_enote',)


