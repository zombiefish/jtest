from django.apps import AppConfig


class EdlConfig(AppConfig):
    name = 'apps.edl'
