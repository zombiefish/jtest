from django.db import models

from apps.person.models import Person

from apps.common_utils.views.sofvieModelFields import(
    SofvieCharField,
    SofvieIntegerField,
    SofvieEmailField,
    SofvieTextField
)

class ExternalDistributionList(models.Model):
    edl_id = models.AutoField(primary_key=True)
    edl_first_name = SofvieCharField(max_length=200)
    edl_last_name = SofvieCharField(max_length=200)
    edl_email = SofvieEmailField(max_length=100)
    edl_company_name = SofvieCharField(max_length=200, blank=True, null=True)
    edl_created_date = models.DateTimeField(auto_now=True, blank=True,
                                            null=True)
    edl_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='edl_person_created_by')
    edl_modified_date = models.DateTimeField(auto_now=True, blank=True,
                                             null=True)
    edl_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='edl_person_modified_by')
    edl_enable = SofvieIntegerField(default=True)
    edl_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:

        db_table = 'external_distribution_list'
