from rest_framework import serializers

from apps.edl.models import ExternalDistributionList


class GetListExternalDistributionList(serializers.ModelSerializer):
    class Meta:
        model = ExternalDistributionList
        fields = [
            'edl_id',
            'edl_first_name',
            'edl_last_name',
            'edl_company_name',
            'edl_email',
            'edl_modified_date',
            'edl_created_date',
            'edl_created_by_per_id',
            'edl_modified_by_per_id',
            'edl_enable'
        ]