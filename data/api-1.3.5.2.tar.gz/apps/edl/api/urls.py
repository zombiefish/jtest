from django.urls import path

from apps.edl.api.views.create_external_contact import CreateExternalContact
from apps.edl.api.views.delete_external_contact import DeleteExternalContact
from apps.edl.api.views.distribution_list import DistributionList
from apps.edl.api.views.get_external_contact_list import GetExternalContactList
from apps.edl.api.views.update_external_contact import UpdateExternalContact

urlpatterns = [
    path('create-external-contact/', CreateExternalContact.as_view()),
    path('get-external-contact-list/', GetExternalContactList.as_view()),
    path('update-external-contact/', UpdateExternalContact.as_view()),
    path('delete-external-contact/', DeleteExternalContact.as_view()),
    path('get-distribution-list/', DistributionList.as_view()),
]