from rest_framework.generics import UpdateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.edl.api.serializers.serializers import GetListExternalDistributionList
from apps.edl.models import ExternalDistributionList
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.dig.api.views.update_distribution_groups import updateEmail


class UpdateExternalContact(UpdateAPIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageUsers.value,)
    serializer_class = GetListExternalDistributionList
    queryset = ExternalDistributionList.objects.all()

    def get_object(self):
        return self.queryset.get(pk=self.request.data['edl_id'])

    def post(self, request, *args, **kwargs):
        person_id = self.request.user.user_per_id_id
        partial = kwargs.pop('partial', False)

        old_email = self.queryset.get(pk=request.data['edl_id']).edl_email

        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        serializer.instance.edl_modified_by_per_id = person_id
        self.perform_update(serializer)

        updateEmail(old_email, request.data['edl_email'].lower(), person_id)

        return Response({"message": "Record updated successfully"})
