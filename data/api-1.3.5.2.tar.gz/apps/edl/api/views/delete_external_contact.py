from rest_framework.generics import UpdateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.edl.api.serializers.serializers import GetListExternalDistributionList
from apps.edl.models import ExternalDistributionList
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.dig.api.views.update_distribution_groups import disableEmail


class DeleteExternalContact(UpdateAPIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.ArchiveSubmissions.value,)

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        payload = request.data

        for i in payload:
            queryset = ExternalDistributionList.objects.filter(
                edl_id=i['edl_id']
            ).values("edl_email").first()
            
            disableEmail(queryset['edl_email'], person_id)

            ExternalDistributionList.objects.filter(
                edl_id=i['edl_id']
            ).update(edl_enable=0, edl_modified_by_per_id=person_id)

        return Response({"message": "Record deleted successfully"})
