from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.edl.api.serializers.serializers import GetListExternalDistributionList
from apps.edl.models import ExternalDistributionList
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class GetExternalContactList(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewUsers.value,)

    def get(self, request):
        queryset = ExternalDistributionList.objects.filter(edl_enable=1)
        serialize_class = GetListExternalDistributionList(queryset, many=True)

        return Response(serialize_class.data)
