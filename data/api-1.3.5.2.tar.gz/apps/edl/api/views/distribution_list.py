import pandas as pd
from apps.employee.models import Employee
from django.db import connection
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.incident_management.api.utlity_function import dictfetchall
from apps.employee import get_employees
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.common_utils.views.common_global_functions import titlekey

class DistributionList(APIView):
    permission_classes = [SofviePermission]

    def get(self, request):
        per_id = self.request.user.user_per_id_id
        data_visibility_type = Employee.objects.get(emp_per_id = per_id).emp_data_visibility
        employees_list = []        
                   
        with connection.cursor() as cursor:
            final_queryset = cursor.execute("call get_edl_list()")
            external_group_distribution_list = dictfetchall(cursor)
        
        active_users_string = get_employees.active_users('distribution')

        employees_list = get_employees.get_employees_list(self, per_id, active_users_string, data_visibility_type)

        if employees_list:

            # converting to a data frame to rename per_full_name as name and return only name and email columns to match 
            # with the above raw query columns. 
            df = pd.DataFrame(employees_list)
            df = df.fillna(' ')
            df = df.rename(columns={'per_full_name':'name'})
            df = df[['name','email', 'employee_jobs', 'emp_data_visibility']]

            employees_list = df.to_dict(orient='records')
        # concating both raw query dataset and get_employees_list dataset and sorting by name of employee.
        final_list = sorted(employees_list+external_group_distribution_list, key=titlekey)

        return Response({"Employee_list":final_list, "data_visbility": data_visibility_type})