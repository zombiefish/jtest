from apps.reflist.api.views.archive_reflist import ArchiveRefListItems
from django.urls import path, include
from rest_framework import routers

from apps.reflist.views import RefListHeaderViewSet
from apps.reflist.api.views.get_user_site import GetUserSite
from apps.reflist.api.views.get_user_job import GetUserJob
from apps.reflist.api.views.get_ref_list import GetRefListItems
from apps.reflist.api.views.add_ref_list import AddRefListItems
from apps.reflist.api.views.update_ref_list import UpdateRefListItems

# router = routers.DefaultRouter()
# router.register(r'masterlist', RefListHeaderViewSet, basename='masterlist')
# router.register(r'ref-list-detail', RefListDetailListApi.as_view(),
#                 basename='ref-list-detail')


urlpatterns = [

    path('masterlist/', RefListHeaderViewSet.as_view()),
    path('get-user-site/<int:person>/', GetUserSite.as_view()),
    path('get-user-job/<int:person>/', GetUserJob.as_view()),
    path('get-reflist-items/<int:rld_rlh_id>/', GetRefListItems.as_view()),
    path('add-reflist-items/', AddRefListItems.as_view()),
    path('update-reflist-items/', UpdateRefListItems.as_view()),
    path('archive-reflist-items/', ArchiveRefListItems.as_view()),

]