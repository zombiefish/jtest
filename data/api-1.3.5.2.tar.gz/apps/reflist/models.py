from django.db import models
from apps.person.models import Person
from apps.language.models import LanguageTranslation
from apps.common_utils.views.sofvieModelFields import SofvieCharField, SofvieIntegerField, SofvieTextField

class RefListType(models.Model):
    rlt_id = models.AutoField(primary_key=True)
    rlt_name = SofvieCharField(max_length=200)
    rlt_description = SofvieCharField(max_length=255, blank=True, null=True)
    rlt_created_date = models.DateTimeField(blank=True, null=True)
    rlt_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='rlt_created_by_per')
    rlt_modified_date = models.DateTimeField(auto_now=True, blank=True,
                                             null=True)
    rlt_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='rlt_modified_by_per')
    rlt_enable = models.BooleanField(default=True)
    rlt_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'ref_list_type'


class CreatedByModifiedByMixin:
    @property
    def created_by(self):
        return self.rlh_created_by_per.full_name

    @property
    def modified_by(self):
        return self.rlh_modified_by_per.full_name


class RefListHeader(CreatedByModifiedByMixin, models.Model):
    rlh_id = models.AutoField(primary_key=True)
    rlh_rlt = models.ForeignKey('RefListType', models.DO_NOTHING,
                                blank=True,
                                null=True)
    rlh_name = SofvieCharField(max_length=200)
    rlh_display_name = SofvieIntegerField(blank=False,null=False)
    rlh_description = SofvieIntegerField(blank=True, null=True)
    rlh_tag_type = SofvieIntegerField(blank=False, null= False)
    rlh_parent_header_rlh = models.ForeignKey('self',
                                              models.DO_NOTHING, blank=True,
                                              null=True,
                                              related_name='rlh_parent')
    rlh_is_code_required = SofvieIntegerField(blank=True, null=True)
    rlh_is_score_required = SofvieIntegerField(blank=True, null=True)
    rlh_is_name_required = SofvieIntegerField(blank=True, null=True)
    rlh_is_description_required = SofvieIntegerField(blank=True, null=True)
    rlh_is_active_required = SofvieIntegerField(blank=True, null=True)
    rlh_created_date = models.DateTimeField(auto_now=True, blank=True,
                                            null=True)
    rlh_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='rlh_created_by_per')
    rlh_modified_date = models.DateTimeField(auto_now=True,blank=True,
                                             null=True)
    rlh_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='rlh_modified_by_per')
    rlh_enable = models.BooleanField(default=True)
    rlh_enote = SofvieTextField(blank=True, null=True)
    rlh_is_core_list = SofvieIntegerField(default=True, null=True)

    class Meta:
        db_table = 'ref_list_header'

    @property
    def status_message(self):
        if self.rlh_enable:
            return "Ref List is enable"
        else:
            return "Ref List disable"

    def __str__(self):
        return self.rlh_name


class CreatedByModifiedByListDetailMixin:
    @property
    def created_by(self):
        return self.rld_created_by_per.full_name

    @property
    def modified_by(self):
        return self.rld_modified_by_per.full_name


class RefListDetail(CreatedByModifiedByMixin, models.Model):
    rld_id = models.AutoField(primary_key=True)
    rld_rlh = models.ForeignKey('RefListHeader', models.DO_NOTHING,
                                related_name='ref_list_details')              
    rld_code = SofvieCharField(max_length=200, blank=True, null=True)
    rld_score = SofvieIntegerField(blank=True, null=True)
    rld_name = SofvieIntegerField()
    rld_tag_type = SofvieIntegerField(blank=False, null= False)
    rld_description = SofvieIntegerField(default=True)
    rld_parent_detail_rld_id = SofvieIntegerField(blank=True, null=True)
    rld_created_date = models.DateTimeField(auto_now=True,blank=True, null=True)
    rld_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='rld_created_by_per')
    rld_modified_date = models.DateTimeField(auto_now=True, blank=True, \
                                                                  null=True)
    rld_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='rld_modified_by_per')
    rld_enable = SofvieIntegerField(max_value=1)
    rld_enote = models.CharField(max_length=255, blank=True, null=True)
    rld_deleted = SofvieIntegerField(max_value=1)
    rld_is_active = SofvieIntegerField(default=True)
    rld_option = SofvieIntegerField(blank=True, null=True)

    class Meta:
        db_table = 'ref_list_detail'

    # as rld_name is now an integer and cannot return as a string value, no longer using the below string representation function. 
    # def __str__(self):
    #     return self.rld_name


class RefDateUnit(models.Model):
    ref_dun_id = models.AutoField(primary_key= True)
    ref_dun_unit = SofvieCharField(max_length= 11)
    ref_dun_created_date = models.DateTimeField(auto_now_add= True)
    ref_dun_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,related_name='ref_date_unit_created_by_per')
    ref_dun_modified_date = models.DateTimeField(blank=True, null= True)
    ref_dun_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,blank=True, null= True, related_name='ref_date_unit_modified_by_per')
    ref_dun_enable = models.BooleanField(default=True)
    ref_dun_enote = SofvieCharField(max_length=255, blank=True, null= True)

    class Meta:
        db_table = 'ref_date_unit'


class RefDateCategory(models.Model):
    ref_dca_id = models.AutoField(primary_key= True)
    ref_dca_dun = models.ForeignKey(RefDateUnit, models.DO_NOTHING, related_name="ref_date_category_unit", blank= True, null = True)
    ref_dca_category_tag = SofvieCharField(max_length= 11)
    ref_dca_created_date = models.DateTimeField(auto_now_add= True)
    ref_dca_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,related_name='ref_date_category_created_by_per')
    ref_dca_modified_date = models.DateTimeField(blank=True, null= True)
    ref_dca_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,blank=True, null= True, related_name='ref_date_category_modified_by_per')
    ref_dca_enable = models.BooleanField(default=True)
    ref_dca_enote = SofvieCharField(max_length=255, blank=True, null= True)

    class Meta:
        db_table = 'ref_date_category'

class RefDateCategorySchedule(models.Model):
    ref_dcs_id = models.AutoField(primary_key= True)
    ref_dcs_rld = models.ForeignKey(RefListDetail, models.DO_NOTHING, related_name="ref_dcs_reflist_detail")
    ref_dcs_dca = models.ForeignKey(RefDateCategory, models.DO_NOTHING, related_name="ref_dcs_date_category")
    ref_dcs_created_date = models.DateTimeField(auto_now_add= True)
    ref_dcs_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,related_name='ref_date_category_scheudler_created_by_per')
    ref_dcs_modified_date = models.DateTimeField(blank=True, null= True)
    ref_dcs_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,blank=True, null= True, related_name='ref_date_category_schedule_modified_by_per')
    ref_dcs_enable = models.BooleanField(default=True)
    ref_dcs_enote = SofvieCharField(max_length=255, blank=True, null= True)

    class Meta:
        db_table = 'ref_date_category_schedule'


