from django.apps import AppConfig


class ReflistConfig(AppConfig):
    name = 'apps.reflist'
