from django.db import transaction, IntegrityError
from django.db.models import query
from django.db.models.expressions import OuterRef, Subquery
from django.db.models import F
from django.db.models.functions import Substr
from django.shortcuts import get_object_or_404
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.exceptions import ValidationError
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.utils import json
from rest_framework.views import APIView
from django.db import connection
from apps.incident_management.api.utlity_function import dictfetchall
from django.utils import timezone
import datetime

from apps.common_utils.views.validate_permission import PersonAccessPermission, \
    RolePermission
from apps.person.models import Person
from apps.reflist.models import RefListHeader, RefListDetail
from apps.reflist.serializers import RefListHeaderSerializer, \
    RefListDetailSerializer
from apps.sofvie_user_authorization.api.permissions import IsSuperUserAdminUser, \
    SofviePermission

from apps.user.models import User
from apps.language.models import Language, LanguageTranslation
from apps.user_settings_profile.models import UserProfile


class RefListHeaderViewSet(APIView):
    permission_classes = [SofviePermission]

    def get(self, request):
        
        per = SofviePermission()
        self.permission_attrs = [RolePermission.CanManageBasicLists.value]
        basic_list_management = per.has_permission(request, self)
        self.permission_attrs = [RolePermission.CanManageAdvancedLists.value]
        advanced_list_management = per.has_permission(request, self)
                        
        with connection.cursor() as cursor:
            cursor.execute("call get_ref_list_master()")
            row = dictfetchall(cursor)
            main_list = []
            for r in row:
                # print(r['rlh_id'])
                main_list.append(r['rlh_id'])
        
        if advanced_list_management:
            queryset = RefListHeader.objects.filter(rlh_id__in = main_list ,rlh_enable = 1)            
            serializer_class = RefListHeaderSerializer(queryset, many=True)

           
            return Response(serializer_class.data)

        else:
            if basic_list_management:
                queryset = RefListHeader.objects.filter(rlh_rlt=1, rlh_id__in= main_list, rlh_enable = 1)               
                serializer_class = RefListHeaderSerializer(queryset, many=True)                
                return Response(serializer_class.data)
            
            return Response({"Permission": "You do not have permission"})
