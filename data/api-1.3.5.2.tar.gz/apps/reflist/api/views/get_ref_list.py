from apps.action import models
from django.db.models import Prefetch, F, Subquery, OuterRef, CharField, ExpressionList
from django.db.models.functions import Concat, Substr
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, CreateAPIView, ListCreateAPIView, RetrieveAPIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.employee.serializers.serializer import EmployeeCustomSiteJobSerializer
from apps.employee.models import EmployeeCustomSiteJob, Employee, EmployeeSite, EmployeeJob
from apps.person.models import Person
from apps.reflist.models import RefListDetail, RefListHeader
from apps.language.models import LanguageTranslation, Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from apps.reflist.serializers import GetRefListDetailSerializer
from apps.wafs.models import RefListDrillingCalculationValue

class GetRefListItems(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageBasicLists.value,)

    def get(self, request, rld_rlh_id):
        '''
            [
                {
                    "rld_id": 9,
                    "rld_code": null,
                    "rld_score": null,
                    "rld_name": "c1111",
                    "rld_description": null,
                    "rld_parent_detail_rld_id": null,
                    "rld_rlh_id": 9,
                    "rld_enable": 1,
                    "parentdetail_name": null,
                    "rld_names" :
                    [
                        {
                        "ltr_lng_id" : "1",
                        "ltr_text" : "Hello",
                        "ltr_translated" : true
                        },
                        {
                        "ltr_lng_id" : "2",
                        "ltr_text" : "Bonjour",
                        "ltr_translated" : true
                        },
                        {
                        "ltr_lng_id" : "3",
                        "ltr_text" : "Hello",
                        "ltr_translated" : false
                        }
                    ],
                    "rld_descriptions" :
                    [
                        {
                        "ltr_lng_id" : "1",
                        "ltr_text" : "Hello",
                        "ltr_translated" : true
                        },
                        {
                        "ltr_lng_id" : "2",
                        "ltr_text" : "Bonjour",
                        "ltr_translated" : true
                        },

                        {
                        "ltr_lng_id" : "3",
                        "ltr_text" : "Hello",
                        "ltr_translated" : false
                        }
                    ]
                }
            ]

        '''
        
        relist_type = RefListHeader.objects.get(rlh_id=rld_rlh_id).rlh_rlt_id        
        if relist_type == 2:
            self.permission_attrs = (RolePermission.CanManageAdvancedLists.value,)
            permission = SofviePermission()
            check_can_manage_advanced_list_permissions = permission.has_permission(request, self)
            if not check_can_manage_advanced_list_permissions:
                return Response({"detail": "You do not have permission to perform this action."}, status=403)
        rld_dcv_drilling_time_delay_ids = None
        rld_dcv_drilling_code_pmd_ids = None
        rld_dcv_drilling_code_cmd_ids = None
        if rld_rlh_id == 96:
            rld_dcv_drilling_time_delay_ids = RefListDrillingCalculationValue.objects.filter(
                ref_dcv_enable = 1,
                ref_dcv_hours_drilled = 1
            ).values_list('ref_dcv_rld', flat = True)
        if rld_rlh_id == 97:
            rld_dcv_drilling_code_queryset = RefListDrillingCalculationValue.objects.filter(ref_dcv_enable = 1)
            rld_dcv_drilling_code_pmd_ids = rld_dcv_drilling_code_queryset.filter(ref_dcv_production_meters_drilled = 1).values_list('ref_dcv_rld', flat = True)
            rld_dcv_drilling_code_cmd_ids = rld_dcv_drilling_code_queryset.filter(ref_dcv_cable_meters_drilled = 1).values_list('ref_dcv_rld', flat = True)

        queryset = RefListDetail.objects.filter(rld_rlh_id = rld_rlh_id, rld_deleted = 0, rld_enable = 1).values()
        person = self.request.user.user_per_id
        lng_name = UserProfile.objects.get(upr_per_id= person).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)        

        queryset = queryset.annotate(
                        rld_parent_name = Subquery(RefListDetail.objects.filter(rld_id = OuterRef('rld_parent_detail_rld_id')).values('rld_name')[:1]),
                        rld_parent_name_tagtype = Subquery(RefListDetail.objects.filter(rld_id = OuterRef('rld_parent_detail_rld_id')).values('rld_tag_type')[:1])
                ).values()
        
        queryset  =queryset.annotate(
                    parentdetail_name = Subquery(LanguageTranslation.objects.filter(ltr_tag = OuterRef('rld_parent_name'), ltr_tag_type = OuterRef('rld_parent_name_tagtype'), ltr_lng = lng_id).values('ltr_text')[:1])
                ).values(
                    "rld_id",
                    "rld_code",
                    "rld_score",
                    "rld_name",
                    'rld_tag_type',
                    "rld_description",
                    "rld_parent_detail_rld_id",
                    "rld_rlh_id",            
                    "parentdetail_name",
                    "rld_is_active",
                    "rld_option"
                )        

        for each in queryset:
            if rld_rlh_id == 96:
                each['rld_total_hours_drilled'] = 0
                each['rld_total_hours_drilled_changed'] = False
                if rld_dcv_drilling_time_delay_ids and each['rld_id'] in rld_dcv_drilling_time_delay_ids:
                   each['rld_total_hours_drilled'] = 1 
            if rld_rlh_id == 97:
                each['rld_drilling_code_value'] = 'na'
                each['rld_drilling_code_value_changed'] = False
                if rld_dcv_drilling_code_pmd_ids and each['rld_id'] in rld_dcv_drilling_code_pmd_ids:
                   each['rld_drilling_code_value'] = 'ref_dcv_production_meters_drilled'
                elif rld_dcv_drilling_code_cmd_ids and each['rld_id'] in rld_dcv_drilling_code_cmd_ids:
                    each['rld_drilling_code_value'] = 'ref_dcv_cable_meters_drilled'
            each['rld_names'] = []
            if each['rld_name']:            
                each['rld_names'] = LanguageTranslation.objects.filter(
                    ltr_tag = each['rld_name'],
                    ltr_tag_type = each['rld_tag_type']
                ).values('ltr_lng_id', 'ltr_text', 'ltr_translated')
            each['rld_descriptions'] = []
            if each['rld_description']:
                each['rld_descriptions'] = LanguageTranslation.objects.filter(
                    ltr_tag = each['rld_description'],
                    ltr_tag_type = each['rld_tag_type']
                ).values('ltr_lng_id', 'ltr_text', 'ltr_translated')
        
        return Response({'data': queryset})