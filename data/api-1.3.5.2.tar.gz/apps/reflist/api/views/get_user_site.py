from django.db.models import Prefetch, F, Subquery, OuterRef
from django.db.models.functions import Substr
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, CreateAPIView, ListCreateAPIView, RetrieveAPIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.employee.serializers.serializer import EmployeeCustomSiteJobSerializer
from apps.employee.models import EmployeeCustomSiteJob, Employee, EmployeeSite, EmployeeJob
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.language.models import Language, LanguageTranslation
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile



class GetUserSite(APIView):
    # used across mobile - basic permissions

    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def get(self, request, person):
        
        emp_object = Employee.objects.filter(emp_per_id = person).values('emp_id','emp_per_id', 'emp_data_visibility')
        emp_id = emp_object[0]['emp_id']
        data_visibility_type = emp_object[0]['emp_data_visibility']
        lng_name = UserProfile.objects.get(upr_per_id= person).upr_language 
        lng_id = Language.objects.get(lng_name = lng_name)
        
        try:
            if data_visibility_type == 'custom': 

                get_sites = EmployeeCustomSiteJob.objects.select_related('esj_site_rld_id').filter(
                                esj_emp_id=emp_id, 
                                esj_enable=True, 
                                esj_site_rld_id__rld_deleted=False,
                                esj_site_rld_id__rld_enable=True,
                                ).annotate(
                                    rld_id=F("esj_site_rld"),                                    
                                    tag = F('esj_site_rld__rld_name'),
                                    type = F("esj_site_rld__rld_tag_type")
                                ).values('rld_id', 'tag').distinct()                
                get_sites = get_sites.annotate(
                    rld_name = Subquery(
                        LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag'), ltr_tag_type=OuterRef('type'), ltr_lng = lng_id).values('ltr_text')[:1]
                    )
                ).values('rld_id', 'rld_name').distinct().order_by('rld_name')
                
            elif data_visibility_type == 'profile':
                get_sites = EmployeeSite.objects.filter(esi_emp_id=emp_id, esi_enable=True).annotate(
                                        rld_id=F('esi_sit_id'),
                                        tag=F('esi_sit_id__rld_name'),
                                        type = F("esi_sit_id__rld_tag_type")                                        
                                    ).values()                                
                get_sites = get_sites.annotate(
                    rld_name = Subquery(
                        LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag'), ltr_tag_type = OuterRef('type'), ltr_lng = lng_id).values('ltr_text')[:1]
                    )
                ).values('rld_id', 'rld_name').distinct().order_by('rld_name')
            
            elif data_visibility_type == 'all':
                get_sites = RefListDetail.objects.filter(
                    rld_rlh__rlh_name='ref_site', 
                    rld_deleted=False,
                    rld_enable=True,
                    rld_is_active=True
                    ).annotate(
                        tag = F('rld_name')
                    ).values()                  
                
                get_sites = get_sites.annotate(
                    rld_name = Subquery(
                        LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag'), ltr_tag_type = OuterRef('rld_tag_type'), ltr_lng = lng_id).values('ltr_text')[:1]
                    )
                ).values().distinct().order_by('rld_name')


        except Exception as e:
            # print(e)
            return []
        
        return Response({"Sites":get_sites})





