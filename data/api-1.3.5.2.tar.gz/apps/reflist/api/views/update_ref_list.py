from rest_framework.response import Response
from apps import action
from django.db import transaction
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.employee.models import Employee, EmployeeJob, EmployeeSite
from apps.reflist.models import RefListDetail, RefListHeader
from apps.language.api.views.helper_function_add_translation import helperAddTranslation
from apps.reflist.api.views.add_ref_list import add_ref_list
from apps.rmm_ora.models import RmmOraMaster
from apps.rmm_jra.models import RmmJraMaster
from apps.rmm_pra.models import RmmPraMaster
from apps.rmm_bowtie.models import RmmBowtieMaster
from apps.dlm.models import DecisionLog
from apps.llm.models import LessonLearned
from apps.lineup.models import Lineupformheader, Lineupworkersppe
from apps.general_action.models import Submissionheader
from apps.hazard_action.models import Submissionhap
from apps.drm.models import DocumentReviewManagement
from apps.wafs.api.helper_functions.manage_ref_drilling_calculation import updateRefDrillingCalculationValue

from datetime import datetime
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.training.models import EmployeeTraining
class UpdateRefListItems(APIView):    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageBasicLists.value,)

    @transaction.atomic
    def post(self, request):
        '''
            [
                {
                    "rld_id": 9,
                    "rld_rlh_id" : 1,
                    "rld_score": null, 
                    "rld_code": null,
                    "rld_name": "c1111",                    
                    "rld_enable" : true,      
                    "rld_deleted":false,
                    "rld_names": [
                        {
                            "ltr_lng_id": 1,
                            "ltr_text": "Test"
                        },
                        {
                            "ltr_lng_id": 2,
                            "ltr_text": "Test French"
                        }
                    ],
                    "rld_descriptions": [
                        {
                            "ltr_lng_id": 1,
                            "ltr_text": "Test Desc"
                        },
                        {
                            "ltr_lng_id": 2,
                            "ltr_text": "Test Desc French"
                        }
                    ]
                }
            ]
        '''
        payloadData = request.data
        relist_type = RefListDetail.objects.filter(rld_id=payloadData['rld_id']).values_list('rld_rlh__rlh_rlt_id', flat=True).first()        
        if relist_type == 2:
            self.permission_attrs = (RolePermission.CanManageAdvancedLists.value,)
            permission = SofviePermission()
            check_can_manage_advanced_list_permissions = permission.has_permission(request, self)
            if not check_can_manage_advanced_list_permissions:
                return Response({"detail": "You do not have permission to perform this action."}, status=403)
        person = self.request.user.user_per_id        
        # soft delete rld_id 
        payloadData_rld_id = payloadData.pop('rld_id')
        data_changed = payloadData.pop('rld_changed')

        rld_drilling_code_value = payloadData.pop('rld_drilling_code_value', 'na')
        rld_total_hours_drilled = payloadData.pop('rld_total_hours_drilled', 0)

        rld_drilling_code_value_changed = payloadData.pop('rld_drilling_code_value_changed', False)
        rld_total_hours_drilled_changed = payloadData.pop('rld_total_hours_drilled_changed', False)

        hide = payloadData.pop('hide', None)

        if data_changed == False and rld_drilling_code_value_changed == False and rld_total_hours_drilled_changed == False:
            update_reflist_isactive = RefListDetail.objects.filter(rld_id = payloadData_rld_id).update(rld_is_active = payloadData['rld_is_active'] ,rld_modified_date = datetime.now(), rld_modified_by_per = person)

        elif data_changed == False and (rld_drilling_code_value_changed or rld_total_hours_drilled_changed):
            payloadData.pop('rld_descriptions')
            payloadData.pop('rld_names')

            soft_delete = RefListDetail.objects.filter(rld_id = payloadData_rld_id).update(rld_enable=False, rld_is_active = False, rld_deleted = True, rld_modified_date = datetime.now(), rld_modified_by_per = person)

            addRefList = RefListDetail.objects.create(**payloadData)

            # Update ref_list_drilling_calculation_value if rlh_id is 96 or 97
            if addRefList.rld_rlh_id == 96:
                updateRefDrillingCalculationValue(addRefList.rld_id, person, "ref_dcv_hours_drilled" if rld_total_hours_drilled else "no_calculations", payloadData_rld_id)
            elif addRefList.rld_rlh_id == 97:
                updateRefDrillingCalculationValue(addRefList.rld_id, person, rld_drilling_code_value if rld_drilling_code_value != "na" else "no_calculations", payloadData_rld_id)

        elif data_changed == True:

            soft_delete = RefListDetail.objects.filter(rld_id = payloadData_rld_id).update(rld_enable=False, rld_is_active = False, rld_deleted = True, rld_modified_date = datetime.now(), rld_modified_by_per = person)            

            originalCreated = RefListDetail.objects.filter(rld_id = payloadData_rld_id).values('rld_created_by_per_id', 'rld_created_date').first()

            # add new list
            addRefList = add_ref_list(self, payloadData)
            new_rld_id = addRefList.rld_id

            # update fetail created & modified
            RefListDetail.objects.filter(rld_id = new_rld_id).update(
                rld_created_by_per = originalCreated['rld_created_by_per_id'],
                rld_created_date = originalCreated['rld_created_date'], 
                rld_modified_by_per = person, 
                rld_modified_date = datetime.now()
            )

            # update header modified
            RefListHeader.objects.filter(rlh_id = addRefList.rld_rlh_id).update(
                rlh_modified_by_per = person, 
                rlh_modified_date = datetime.now()
            )
            
            # update rld_id for all documents, rmm, actions and line up which are in draft mode or not submitted or not completed. 
            '''
            rmm_ora
            rmm_jra
            rmm_pra
            rmm_bowtie
            lineup - crew 56, PPE 37, Shift 50
            dlm
            llm - 
            General Actions, Hazard Actions - Site, JobNumber, SiteLevel, hazard_type 15, hazard_identification 13, potential_risk 31, action_type
            document type --- drm [55]

            update user site and job in employee_site and employee_job model/table
            '''
            # update child in ref_list_detail
            update_child = RefListDetail.objects.filter(rld_parent_detail_rld_id = payloadData_rld_id).update(rld_parent_detail_rld_id = new_rld_id)

            # for SITE
            if addRefList.rld_rlh_id == 1:        
                update_rmm_ora = RmmOraMaster.objects.filter(rmm_ora_site= payloadData_rld_id, rmm_ora_state = 'draft', rmm_ora_enable = True).update(rmm_ora_site = new_rld_id)
                update_rmm_jra = RmmJraMaster.objects.filter(rmm_jra_site= payloadData_rld_id, rmm_jra_state = 'draft', rmm_jra_enable = True).update(rmm_jra_site = new_rld_id)
                update_rmm_pra = RmmPraMaster.objects.filter(rmm_pra_site= payloadData_rld_id, rmm_pra_state = 'draft', rmm_pra_enable = True).update(rmm_pra_site = new_rld_id)
                update_rmm_bowtie = RmmBowtieMaster.objects.filter(rmm_bow_site= payloadData_rld_id, rmm_bow_state = 'draft', rmm_bow_enable = True).update(rmm_bow_site = new_rld_id)
                update_dlm = DecisionLog.objects.filter(dlm_site_rld = payloadData_rld_id, dlm_is_submitted = 0, dlm_enable = True).update(dlm_site_rld = new_rld_id)
                update_llm = LessonLearned.objects.filter(llm_site_rld = payloadData_rld_id, llm_is_submitted = 0, llm_enable = True).update(llm_site_rld = new_rld_id)
                update_lineup = Lineupformheader.objects.filter(Site = payloadData_rld_id, SubmittedBy__isnull = True).update(Site = new_rld_id)
                actions_shid_list = Submissionhap.objects.filter(submissionheaderid__site = payloadData_rld_id, action_completed_date__isnull = True).values_list('submissionheaderid', flat = True)
                if actions_shid_list:
                    update_actions = Submissionheader.objects.filter(id__in = actions_shid_list).update(site = new_rld_id)
                # update employee_site
                EmployeeSite.objects.filter(esi_sit_id =payloadData_rld_id).update(
                    esi_sit_id = new_rld_id,
                    esi_modified_by_per = person,
                    esi_modified_date = datetime.now()
                )                
            # for JOB
            elif addRefList.rld_rlh_id == 3:            
                update_rmm_jra = RmmJraMaster.objects.filter(rmm_jra_job= payloadData_rld_id, rmm_jra_state = 'draft', rmm_jra_enable = True).update(rmm_jra_job = new_rld_id)
                update_llm = LessonLearned.objects.filter(llm_job_rld = payloadData_rld_id, llm_is_submitted = 0, llm_enable = True).update(llm_job_rld = new_rld_id)
                update_lineup = Lineupformheader.objects.filter(JobNumber = payloadData_rld_id, SubmittedBy__isnull = True).update(JobNumber = new_rld_id)                    
                actions_shid_list = Submissionhap.objects.filter(submissionheaderid__jobnumber = payloadData_rld_id, action_completed_date__isnull = True).values_list('submissionheaderid', flat = True)
                if actions_shid_list:
                    update_actions = Submissionheader.objects.filter(id__in = actions_shid_list).update(jobnumber = new_rld_id)
                # update employee job
                EmployeeJob.objects.filter(ejo_job_id = payloadData_rld_id).update(
                    ejo_job_id = new_rld_id,
                    ejo_modified_by_per = person,
                    ejo_modified_date = datetime.now()
                )
            #for SITE LEVEL
            elif addRefList.rld_rlh_id == 2:
                update_llm = LessonLearned.objects.filter(llm_site_rld = payloadData_rld_id, llm_is_submitted = 0, llm_enable = True).update(llm_site_rld = new_rld_id)
                actions_shid_list = Submissionhap.objects.filter(submissionheaderid__sitelevel = payloadData_rld_id, action_completed_date__isnull = True).values_list('submissionheaderid', flat = True)
                if actions_shid_list:
                    update_actions = Submissionheader.objects.filter(id__in = actions_shid_list).update(sitelevel = new_rld_id)
            #for DOCUMENT TYPES
            elif addRefList.rld_rlh_id == 55:
                update_drm = DocumentReviewManagement.objects.filter(drm_document_type_rld = payloadData_rld_id, drm_is_submitted = 0, drm_enable = True).update(drm_document_type_rld = new_rld_id)
            #for ACTION TYPE
            elif addRefList.rld_rlh_id == 8:
                update_actions = Submissionhap.objects.filter(action_type = payloadData_rld_id, action_completed_date__isnull = True).update(action_type = new_rld_id)
            # for HAZARD TYPE
            elif addRefList.rld_rlh_id == 15:
                update_actions = Submissionhap.objects.filter(hazard_type = payloadData_rld_id, action_completed_date__isnull = True).update(hazard_type = new_rld_id)
            # for HAZARD IDENTIFICATION
            elif addRefList.rld_rlh_id == 13:
                update_actions = Submissionhap.objects.filter(hazard_identification = payloadData_rld_id, action_completed_date__isnull = True).update(hazard_identification = new_rld_id)            
            # for Potential Risk
            elif addRefList.rld_rlh_id == 31:
                update_actions = Submissionhap.objects.filter(potential_risk = payloadData_rld_id, action_completed_date__isnull = True).update(potential_risk = new_rld_id)
            # for CREW
            elif addRefList.rld_rlh_id == 56: 
                update_lineup_crew = Lineupformheader.objects.filter(Crew = payloadData_rld_id, SubmittedBy__isnull = True).update(Crew = new_rld_id)
            # for PPE
            elif addRefList.rld_rlh_id == 37:             
                update_lineup_ppe = Lineupworkersppe.objects.filter(ppeid = payloadData_rld_id).update(ppeid = new_rld_id)        
            # for SHIFT
            elif addRefList.rld_rlh_id == 50: 
                update_lineup_crew = Lineupformheader.objects.filter(Shift = payloadData_rld_id, SubmittedBy__isnull = True).update(Shift = new_rld_id)
            elif addRefList.rld_rlh_id == 29:
                update_employee_position = Employee.objects.filter(emp_pos_id=payloadData_rld_id).update(emp_pos_id=new_rld_id)
            # for Employee Training Code ID
            elif addRefList.rld_rlh_id == 51:
                update_employee_training = EmployeeTraining.objects.filter(etr_training_code_id = payloadData_rld_id).update(etr_training_code_id=new_rld_id)
            # Update ref_list_drilling_calculation_value if rlh_id is 96 or 97
            elif addRefList.rld_rlh_id == 96:
                updateRefDrillingCalculationValue(new_rld_id, person, "ref_dcv_hours_drilled" if rld_total_hours_drilled else "no_calculations", payloadData_rld_id)
            elif addRefList.rld_rlh_id == 97:
                updateRefDrillingCalculationValue(new_rld_id, person, rld_drilling_code_value if rld_drilling_code_value != "na" else "no_calculations", payloadData_rld_id)

        return Response({"Message": "Updated successfully"}) 
        
