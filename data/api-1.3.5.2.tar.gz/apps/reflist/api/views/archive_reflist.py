from django.db.models.expressions import Ref
from django.forms import model_to_dict
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.drm.models import DocumentReviewManagementReviewer
from apps.employee.models import Employee, EmployeeJob, EmployeeSite
from apps.equipment.models import PreopEquipmentSiteJob
from apps.person.models import Person
from apps.reflist.models import RefListDetail, RefListHeader
from apps.language.api.views.helper_function_add_translation import helperAddTranslation
from rest_framework import status
from datetime import datetime
from apps.wafs.api.helper_functions.manage_ref_drilling_calculation import disableReflistValueForDrillingCalculation
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class ArchiveRefListItems(APIView):
        
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageBasicLists.value, RolePermission.ArchiveSubmissions.value,)

    def post(self, request):
        payloadData = request.data
        person = self.request.user.user_per_id

        
        relist_type = RefListDetail.objects.filter(rld_id=payloadData['rld_id']).values_list('rld_rlh__rlh_rlt_id', flat=True).first()        
        if relist_type == 2:
            self.permission_attrs = (RolePermission.CanManageAdvancedLists.value,)
            permission = SofviePermission()
            check_can_manage_advanced_list_permissions = permission.has_permission(request, self)
            if not check_can_manage_advanced_list_permissions:
                return Response({"detail": "You do not have permission to perform this action."}, status=403)

        mode = payloadData['mode']

        if mode == 'warning':
            archive_rld_id = RefListDetail.objects.filter(rld_id=payloadData['rld_id']).update(rld_enable=False, rld_deleted=True, rld_is_active=False, rld_modified_date=datetime.now())

            # archive child data
            archive_childs = RefListDetail.objects.filter(rld_parent_detail_rld_id=payloadData['rld_id']).update(rld_enable=False, rld_deleted=True, rld_is_active=False, rld_modified_date=datetime.now())
            return Response({"Message": "Archived successfully"})

        # archive employee site and jobs
        ref_instance = RefListDetail.objects.get(rld_id=payloadData['rld_id'])
        if ref_instance.rld_rlh_id == 1:
            EmployeeSite.objects.filter(
                esi_sit_id = payloadData['rld_id']                
            ).update(
                esi_enable = False,
                esi_modified_by_per = person,
                esi_modified_date = datetime.now()
            )
            EmployeeJob.objects.filter(
                ejo_job__rld_parent_detail_rld_id = payloadData['rld_id']
            ).update(
                ejo_enable = False,
                ejo_modified_by_per = person,
                ejo_modified_date = datetime.now()
            )

            # disabling the preop equipment record that site is mapped with equipment - SOF-12848
            PreopEquipmentSiteJob.objects.filter(
                psj_rld_site_id=payloadData['rld_id'],
                psj_enable=True
            ).update(
                psj_enable=False,
                psj_modified_date=datetime.now(),
                psj_modified_by_per_id=person
            )


        elif ref_instance.rld_rlh_id == 3:
            EmployeeJob.objects.filter(
                ejo_job_id = payloadData['rld_id']                
            ).update(
                ejo_enable = False,
                ejo_modified_by_per = person,
                ejo_modified_date = datetime.now()
            )
            
            # disabling the preop equipment record that job is mapped with equipment - SOF-12848
            PreopEquipmentSiteJob.objects.filter(
                psj_rld_job_id=payloadData['rld_id'],
                psj_enable=True
            ).update(
                psj_rld_job_id=None,
                psj_modified_date=datetime.now(),
                psj_modified_by_per_id=person
            )
        elif ref_instance.rld_rlh_id == 96 or ref_instance.rld_rlh_id == 97:
            disableReflistValueForDrillingCalculation(payloadData['rld_id'], person)

        position_data = Employee.objects.filter(emp_pos=payloadData['rld_id']).values_list('emp_per', flat=True)

        if position_data:
            person_name = Person.objects.filter(per_id__in=position_data)            
            name = []

            for p in person_name:
                name.append(p.full_name)
           
            return Response({"employees_name": name})
        else:
            archive_rld_id = RefListDetail.objects.filter(rld_id=payloadData['rld_id']).update(rld_enable=False, rld_deleted=True, rld_is_active=False, rld_modified_date=datetime.now())

            # archive child data
            archive_childs = RefListDetail.objects.filter(rld_parent_detail_rld_id=payloadData['rld_id']).update(rld_enable=False, rld_deleted=True, rld_is_active=False, rld_modified_date=datetime.now())
            return Response({"Message": "Archived successfully"})




