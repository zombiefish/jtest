from django.db import transaction
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.reflist.models import RefListDetail, RefListHeader
from apps.language.api.views.helper_function_add_translation import helperAddTranslation
from rest_framework import status
from datetime import datetime
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.wafs.api.helper_functions.manage_ref_drilling_calculation import updateRefDrillingCalculationValue


class AddRefListItems(APIView):    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageBasicLists.value,)

    @transaction.atomic
    def post(self, request):
        person = self.request.user.user_per_id
        '''
            [
                {
                    "rld_rlh_id": 9,
                    "rld_score": null,
                    "rld_code": null,
            #         "validate_code": true,
            #         "validate_name": true,
            #         "validate_score": true,
            #         "validate_description": true,
                    "rld_enable" : true,      
                    "rld_deleted":false,
                    "rld_parent_detail_rld_id": null,
                    "rld_created_by_per_id": null,
                    "rld_modified_by_per_id": null,
                    "rld_names": [
                        {
                            "ltr_lng_id": 1,
                            "ltr_text": "Test"
                        },
                        {
                            "ltr_lng_id": 2,
                            "ltr_text": "Test French"
                        }
                    ],
                    "rld_descriptions": [
                        {
                            "ltr_lng_id": 1,
                            "ltr_text": "Test Desc"
                        },
                        {
                            "ltr_lng_id": 2,
                            "ltr_text": "Test Desc French"
                        }
                    ]
                }
            ]

        {'rld_rlh_id': 9, 
        'rld_score': None, 
        'rld_code': None, 
        'rld_parent_detail_rld_id': None, 
        'rld_name': 'C1111', 
        'rld_description': 'C2222'}       
        '''
        payloadData = request.data
        relist_type = RefListHeader.objects.get(rlh_id=payloadData['rld_rlh_id']).rlh_rlt_id  
        if relist_type == 2:
            self.permission_attrs = (RolePermission.CanManageAdvancedLists.value,)
            permission = SofviePermission()
            check_can_manage_advanced_list_permissions = permission.has_permission(request, self)
            if not check_can_manage_advanced_list_permissions:
                return Response({"detail": "You do not have permission to perform this action."}, status=403)
        if 'rld_changed' in payloadData:
            data_changed = payloadData.pop('rld_changed')

        rld_drilling_code_value = payloadData.pop('rld_drilling_code_value', 0)
        rld_total_hours_drilled = payloadData.pop('rld_total_hours_drilled', 'na')
        addRefList = add_ref_list(self, payloadData)

        # update detail created
        RefListDetail.objects.filter(rld_id = addRefList.rld_id).update(
            rld_created_by_per = person,
            rld_created_date =  datetime.now()
        )

        # update header modified
        RefListHeader.objects.filter(rlh_id = addRefList.rld_rlh_id).update(
            rlh_modified_by_per = person, 
            rlh_modified_date = datetime.now()
        )
        # Update ref_list_drilling_calculation_value if rlh_id is 96 or 97
        if addRefList.rld_rlh_id == 96 and not rld_total_hours_drilled == 0:
            updateRefDrillingCalculationValue(addRefList.rld_id, person, "ref_dcv_hours_drilled")
        elif addRefList.rld_rlh_id == 97 and not rld_drilling_code_value == 'na':
            updateRefDrillingCalculationValue(addRefList.rld_id, person, rld_drilling_code_value)


        return Response({"Message": "Record inserted successfully",
                            "rld_id": addRefList.rld_id,
                            "status": status.HTTP_201_CREATED})

def add_ref_list(self, payloadData):

    # print(' in add ref list ')
    person = self.request.user.user_per_id
    # print(' payload data __ ', payloadData)
    # payloadData.pop('validate_code')        
    # payloadData.pop('validate_name')
    # payloadData.pop('validate_score')
    # payloadData.pop('validate_description')

    # get rld_names
    rld_names = payloadData.pop('rld_names')
    # call helper function to add translation and get tag number
    if rld_names:
        rld_name = helperAddTranslation(self, rld_names)
        payloadData['rld_name'] = rld_name # add rld_name tags into payloadData
        payloadData['rld_tag_type'] = 2 # add rld_tag_type into payloadData 2 = client/user-defined tag
    # get rld_descriptions
    rld_descriptions = payloadData.pop('rld_descriptions')
    # call helper function to add translation and get tag number
    if rld_descriptions:
        rld_description = helperAddTranslation(self, rld_descriptions)
        payloadData['rld_description'] = rld_description # add rld_description tags into payloadData

    addRefList = RefListDetail.objects.create(**payloadData)    
    return addRefList