from django.db.models import Prefetch, F, Subquery, OuterRef
from django.db.models.functions import Concat, Substr
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, CreateAPIView, ListCreateAPIView, RetrieveAPIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.employee.serializers.serializer import EmployeeCustomSiteJobSerializer
from apps.employee.models import EmployeeCustomSiteJob, Employee, EmployeeSite, EmployeeJob
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.language.models import LanguageTranslation, Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile



class GetUserJob(APIView):
    # used across mobile - basic permissions

    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)    

    def get(self, request, person):
        # person = request.user.user_per_id_id
        # person = user
        emp_object = Employee.objects.filter(emp_per_id = person).values('emp_id', 'emp_per_id', 'emp_data_visibility')
        emp_id = emp_object[0]['emp_id']
        data_visibility_type = emp_object[0]['emp_data_visibility']
        lng_name = UserProfile.objects.get(upr_per_id= person).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)

        try:
            if data_visibility_type == 'custom': 
                get_jobs = EmployeeCustomSiteJob.objects.select_related('esj_job_rld_id').filter(
                                esj_emp_id=emp_id, 
                                esj_enable=True, 
                                esj_job_rld_id__rld_deleted=False,
                                esj_job_rld_id__rld_enable=True,
                                ).annotate(
                                    rld_id=F("esj_job_rld"),
                                    rld_code=F("esj_job_rld__rld_code"),
                                    tag = F('esj_job_rld__rld_name'),  
                                    type = F('esj_job_rld__rld_tag_type'),                                           
                                    rld_parent_detail_rld_id=F("esj_job_rld__rld_parent_detail_rld_id"),                                    
                                    rld_is_active = F('esj_job_rld__rld_is_active')
                                    ).values()
                get_jobs = get_jobs.annotate(
                    rld_name = Subquery(
                        LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag'), ltr_tag_type= OuterRef('type'), ltr_lng = lng_id).values('ltr_text')[:1]
                    )
                ).values('rld_id', 'rld_name', 'rld_code', 'rld_parent_detail_rld_id', 'rld_is_active').distinct().order_by('rld_code')                
            elif data_visibility_type == 'profile':

                get_jobs = RefListDetail.objects.filter(
                    rld_rlh_id=3, 
                    rld_deleted=False, 
                    rld_enable = True,                    
                    rld_parent_detail_rld_id__in = Subquery(
                        EmployeeSite.objects.filter(esi_emp_id=emp_id, esi_enable=True).values('esi_sit_id')
                    )).annotate(
                    tag = F('rld_name')
                ).values('rld_id','rld_code', 'tag', 'rld_tag_type', 'rld_parent_detail_rld_id', 'rld_is_active')
                
                get_jobs = get_jobs.annotate(
                    rld_name = Subquery(
                        LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag'), ltr_tag_type = OuterRef('rld_tag_type'), ltr_lng = lng_id).values('ltr_text')[:1]
                    )
                ).values('rld_id','rld_code', 'rld_name', 'rld_parent_detail_rld_id', 'rld_is_active').order_by('rld_code')


                existing_jobs = EmployeeJob.objects.select_related('ejo_job').filter(
                    ejo_emp=emp_id,
                    ejo_enable=True,                    
                ).annotate(
                    rld_id=F('ejo_job_id'),
                    rld_parent_detail_rld_id = F('ejo_job__rld_parent_detail_rld_id'),
                    rld_is_active = F('ejo_job__rld_is_active'),
                    rld_code=F('ejo_job__rld_code'),
                    tag=F('ejo_job__rld_name'),
                    type = F("ejo_job__rld_tag_type")
                    ).values()


                existing_jobs = existing_jobs.annotate(
                    rld_name = Subquery(
                        LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag'), ltr_tag_type = OuterRef('type'), ltr_lng = lng_id).values('ltr_text')[:1]
                    )
                ).values('rld_id','rld_code', 'rld_name', 'rld_parent_detail_rld_id', 'rld_is_active').order_by('rld_code')

                job_id_list = [job['rld_id'] for job in existing_jobs]

                get_jobs=list(get_jobs)
                existing_jobs = list(existing_jobs)
                remove_jobs = []
                for user_job in existing_jobs:
                    for job in get_jobs:
                        if job['rld_parent_detail_rld_id'] == user_job['rld_parent_detail_rld_id']:
                            if job['rld_id'] not in job_id_list:
                                remove_jobs.append(job)
            
                for job in remove_jobs:
                    if job in get_jobs:
                        get_jobs.remove(job)     

            elif data_visibility_type == 'all':
                get_jobs = RefListDetail.objects.filter(
                    rld_rlh__rlh_name='ref_job', 
                    rld_deleted=False,
                    rld_enable=True
                    ).annotate(
                        tag = F('rld_name')
                    ).values()                 
                get_jobs = get_jobs.annotate(
                    rld_name = Subquery(
                        LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag'), ltr_tag_type = OuterRef('rld_tag_type'), ltr_lng = lng_id).values('ltr_text')[:1] 
                    )
                ).values('rld_id','rld_code', 'rld_name', 'rld_parent_detail_rld_id', 'rld_is_active').order_by('rld_code')



        except Exception as e:
            # print(e)
            return []
        
        return Response({"Jobs":get_jobs})





