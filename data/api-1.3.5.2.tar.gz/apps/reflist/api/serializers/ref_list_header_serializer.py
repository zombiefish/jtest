from rest_framework import serializers

from apps.reflist.models import RefListHeader


class UpdateRefListHeaderSerializer(serializers.ModelSerializer):
    class Meta:
        model = RefListHeader
        fields = [
            'rlh_id',
            'rlh_display_name',
            'rlh_tag_type',
            'rlh_description',
            'rlh_modified_date',
            'rlh_modified_by_per_id',
        ]