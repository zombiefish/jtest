from re import search
from django.db.models.expressions import Ref
from rest_framework import serializers

from apps.person.models import Person
from apps.reflist.models import RefListHeader, RefListDetail
from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile


class RefListDetailSerializer(serializers.ModelSerializer):
    parent_name = serializers.SerializerMethodField()

    class Meta:
        model = RefListDetail
        fields = [
            'rld_id',
            'rld_rlh_id',
            'rld_code',
            'rld_score',
            'rld_name',
            'rld_tag_type',
            'rld_description',
            'rld_parent_detail_rld_id',
            'created_by',
            'modified_by',
            'parent_name'
        ]

    def get_parent_name(self, obj):
        return obj.parent_name()


class RefListHeaderSerializer(serializers.ModelSerializer):
    # rlh_created_by_per = serializers.SerializerMethodField()
    rlh_display_names = serializers.SerializerMethodField()
    rlh_descriptions = serializers.SerializerMethodField()

    class Meta:
        model = RefListHeader
        fields = [
            'rlh_id',
            'rlh_rlt',
            'rlh_display_name',
            'rlh_name',
            'rlh_tag_type',
            'rlh_description',
            'rlh_parent_header_rlh_id',
            'rlh_is_code_required',
            'rlh_is_score_required',
            'rlh_is_name_required',
            'rlh_is_description_required',
            'rlh_is_active_required',
            'rlh_is_core_list',
            'rlh_created_date',
            'rlh_modified_date',
            'rlh_enable',
            'rlh_enote',
            'status_message',
            'created_by',
            'modified_by',
            'rlh_display_names',
            'rlh_descriptions',
        ]

    def get_rlh_display_names(self, obj):        
        selected_lng_id = Language.objects.filter(lng_selected = True).values_list('lng_id', flat=True)
        rlh_display_names = LanguageTranslation.objects.filter(ltr_lng_id__in = selected_lng_id, ltr_tag = obj.rlh_display_name, ltr_tag_type=obj.rlh_tag_type).values('ltr_lng_id', 'ltr_text', 'ltr_translated')
        return rlh_display_names
    def get_rlh_descriptions(self, obj):
        selected_lng_id = Language.objects.filter(lng_selected = True).values_list('lng_id', flat=True)
        rlh_descriptions = LanguageTranslation.objects.filter(ltr_lng_id__in = selected_lng_id, ltr_tag = obj.rlh_description, ltr_tag_type=obj.rlh_tag_type).values('ltr_lng_id', 'ltr_text','ltr_translated')
        return rlh_descriptions

    # def rlh_created_by_per(self,instance):
    #     return  instance.rlh_created_by_per.full_name

    # def to_representation(self, instance):
    #     ret = super().to_representation(instance)
    #     # If created_by_per is null always check with try catch block or
    #     # getattr or hasattr method
    #     ret['rlh_created_by_per'] = instance.rlh_created_by_per.full_name
    #     return ret


class GetRefListDetailSerializer(serializers.ModelSerializer):
    parentdetail_name = serializers.SerializerMethodField()
    rld_names = serializers.SerializerMethodField()
    rld_descriptions = serializers.SerializerMethodField()

    
    class Meta:
        model = RefListDetail
        fields = (
            "rld_id",
            "rld_code",
            "rld_score",
            "rld_name",
            "rld_tag_type",
            "rld_description",
            "rld_parent_detail_rld_id",
            "rld_rlh_id",            
            "parentdetail_name",
            "rld_names",
            "rld_descriptions"
        )

    def get_parentdetail_name(self, obj):
        person = self.context['request'].user.user_per_id
        lng_name = UserProfile.objects.get(upr_per_id= person).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)
        parent_name = None
        if obj.rld_parent_detail_rld_id:
            rld_name_query = RefListDetail.objects.get(rld_id = obj.rld_parent_detail_rld_id)
            parent_name = LanguageTranslation.objects.get(ltr_tag = rld_name_query.rld_name, ltr_tag_type = rld_name_query.rld_tag_type, ltr_lng = lng_id).ltr_text

        return parent_name

    def get_rld_names(self, obj):
        return  ''

    def get_rld_descriptions(self, obj):
        return ''
