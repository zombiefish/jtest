from rest_framework.routers import DefaultRouter

from apps.training.api.views.get_full_training_code_list import GetFullTrainingCodeList
from django.urls import path, include
from apps.training.api.views.add_training_attachments import \
    AddTrainingAttachments
from apps.training.api.views.create_training import CreateTrainingRecord
# from apps.training.api.views.get_norcat_training_data import GetNorcatTrainingData
from apps.training.api.views.get_norcat_training_data import GetNorcatData
# from apps.training.api.views.list_employee_training_records import ListAllEmployeeTrainingRecords
from apps.training.api.views.edit_training_record  import EditTrainingRecord
from apps.training.api.views.edit_training_record  import UpdateTrainingAttachments
from apps.training.api.views.edit_training_record  import DeleteTrainingAttachments
from apps.training.api.views.list_training_record_attachments  import ListTrainingRecordAttachments
from apps.training.api.views.training_file_zip import TrainingRecordZip
from apps.training.api.views.views import GetAllEmployeeTrainingRecordList
from apps.training.api.views.training_matrix import EmployeeTrainingMatrix
from apps.training.api.views.archive_training_record import ArchiveTrainingRecord

router = DefaultRouter()
router.register('data', GetNorcatData, basename='norcat-data')

urlpatterns = [
    path('get-all-employee-training-records/',
         GetAllEmployeeTrainingRecordList.as_view()),
    path('create-training-record/',  CreateTrainingRecord.as_view()),
    path('add-training-attachments/',  AddTrainingAttachments.as_view()),
    path('edit-training-record/',  EditTrainingRecord.as_view()),
    path('update-training-attachment-list/',  UpdateTrainingAttachments.as_view()),
    # path('delete-training-attachment-by-id/',  DeleteTrainingAttachments.as_view()), currently not used
    path('zip-training-files/',  TrainingRecordZip.as_view()),
    path('employee-training-matrix/', EmployeeTrainingMatrix.as_view()),
    path('full-training-code-list/<str:rlh_name>/', GetFullTrainingCodeList.as_view()),
    path('list-training-record-attachments/', ListTrainingRecordAttachments.as_view()),
    path('get-norcat-training-data/',include(router.urls)),
    path('archive-training-record/', ArchiveTrainingRecord.as_view())
]