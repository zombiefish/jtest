from rest_framework import serializers

from apps.employee.models import Employee
from apps.person.api.views import EmployeeSerializer
from apps.training.models import EmployeeTraining, EmployeeTrainingAttachment


class GetAllTrainingRecordAttachments(serializers.ModelSerializer):
    class Meta:
        model = EmployeeTrainingAttachment
        fields = [
            'eta_id',
            'eta_etr_id',
            'eta_attachment_name',
            'eta_attachment_type',
            'eta_attachment_comment',
            'eta_enable',
            'eta_created_date'
        ]


class GetAllEmployeeTrainingRecordSerializer(serializers.ModelSerializer):
    attachments = GetAllTrainingRecordAttachments(many=True,  read_only=True)
    emp_per = serializers.SerializerMethodField()

    class Meta:
        model = EmployeeTraining
        fields = [
            'etr_id',
            'emp_per',
            'etr_training_type',
            'etr_training_institution',
            'etr_training_code',
            'etr_completion_date',
            'etr_expiry_date',
            'etr_no_expiry_date',
            'etr_training_status',
            'etr_enable',
            'attachments',
            'etr_modified_date',
            'etr_modified_by_per',
            'etr_is_integrated'
        ]

    def get_emp_per(self, obj):
        return obj.etr_emp.emp_per_id


class TrainingEmployeeSerializer(serializers.ModelSerializer):
    training = GetAllEmployeeTrainingRecordSerializer(many=True, read_only=True)

    class Meta:
        model = Employee
        fields = [
            'emp_per_id',
            'training'
        ]
