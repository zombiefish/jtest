from django.http import HttpResponse
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.employee.models import Employee
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.training.api.serializers import \
    TrainingEmployeeSerializer

# save the file with the employee id to standardize the file

from django.db.models import Prefetch, Count
from apps.training.models import EmployeeTrainingAttachment, EmployeeTraining


class GetAllEmployeeTrainingRecordList(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewTrainingRecords.value,)    

    def post(self, request):

        if request.data['status'] == "active":
            status = True
        elif request.data['status'] == "inactive":
            status = False
        else:
            status = "all"

        if status == "all":
            queryset = Employee.objects.all().annotate(
                training_count=Count('training')).filter(
                training_count__gt=0, training__etr_enable=1).prefetch_related(Prefetch('training',
                                        EmployeeTraining.objects.filter(etr_enable=1)),
                'training', Prefetch('training__attachments',
                                     EmployeeTrainingAttachment.objects.filter(eta_enable=1)))
        else:
            queryset = Employee.objects.filter(emp_enable=status).annotate(
                training_count=Count('training')).filter(
                training_count__gt=0, training__etr_enable=1).prefetch_related(Prefetch('training',
                                        EmployeeTraining.objects.filter(etr_enable=1)),
                'training', Prefetch('training__attachments',
                                     EmployeeTrainingAttachment.objects.filter(eta_enable=1)))
        
        data = TrainingEmployeeSerializer(queryset, many=True).data

        return Response(data)
