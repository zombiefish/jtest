from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import serializers
from rest_framework import status, viewsets, generics

from django.conf import settings
from apps.employee.models import Employee
from apps.training.models import EmployeeTraining
from apps.training.api.serializers import TrainingEmployeeSerializer

from apps.common_utils.views.validate_permission import PersonAccessPermission, RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from datetime import datetime

class ArchiveTrainingRecord(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageTrainingRecords.value,)

    def post(self, request, *args, **kwargs):
        person_id = self.request.user.user_per_id_id
        etr_id = request.data['etr_id']
        
        archive = EmployeeTraining.objects.filter(
            etr_id=etr_id,
        ).update(
            etr_enable=0, 
            etr_modified_by_per=person_id,
            etr_modified_date=datetime.now()
        )

        return Response({'Message': "Archived Successfully"})