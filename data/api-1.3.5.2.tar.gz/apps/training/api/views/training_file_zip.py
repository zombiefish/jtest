import datetime
import os
import tempfile
from io import BytesIO
from zipfile import ZipFile
from django.conf import settings
from django.db.models import Prefetch
from django.http import HttpResponse
from django.template.defaultfilters import slugify
from wsgiref.util import FileWrapper
from django.template.loader import get_template
from django.utils import timezone
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from xhtml2pdf import pisa
from apps.common_utils.views.validate_permission import RolePermission
from apps.employee.models import Employee
from apps.person.models import Person
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.training.models import EmployeeTrainingAttachment, EmployeeTraining
from apps.common_utils.views.get_translations import get_translation
from apps.language.models import Language, LanguageTranslation
from apps.user_settings_profile.models import UserProfile
from django.db.models import Subquery, OuterRef, Q
from django.db.models.functions import Substr


def render_to_pdf(context_dict={}):
    # template = get_template(template_src)
    template = get_template("training_record_report.html")
    html = template.render(context_dict)
    result = BytesIO()
    # pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
    pdf = pisa.pisaDocument(BytesIO(html.encode("UTF-8")), result)
    if not pdf.err:
        return result.getvalue()
    return None
class TrainingRecordZip(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewTrainingRecords.value,)

    def post(self, request):
        # request.data["emp_id"] = 1461
        person_id = self.request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per_id=person_id).upr_language
        lng_id = Language.objects.get(lng_name=lng_name) 
        ltr_ids = [2587, 143, 1260, 1326, 1262, 2589, 1930,1381,1379,1380,8613,1034,1265,1169]
        get_trans = get_translation(ltr_ids, lng_id)
        emp_id = request.data['emp_id']
        emp_ids = emp_id if type(emp_id) == list else [emp_id]
        emp_ids = list(set(emp_ids))
        files = {}
        media_files = {}

        # print(f"this is employee name list {employee_name}")
        for emp_id in emp_ids:
            employee_fileName = get_trans[1265].lower().replace(" ","_") # employee_id
            emp_path = f"{employee_fileName}_{emp_id}"
            per_id = Employee.objects.get(emp_id = emp_id).emp_per_id
            employee_name = Person.objects.get(per_id = per_id)
            emp_path_with_name = f"{employee_name.per_last_name}_" \
                       f"{employee_name.per_first_name}_{emp_id}"
            queryset = EmployeeTraining.objects.filter(
                etr_emp_id=emp_id).prefetch_related(
                Prefetch('attachments',
                         EmployeeTrainingAttachment.objects.filter(
                             eta_enable=True, eta_attachment_type=1)))
            person = Employee.objects.get(emp_id=emp_id)

            context = {"records": [], "person_name": person,
                       "date": timezone.now().date().strftime('%Y-%m-%d'), "data": get_trans}

            for t in queryset:

                media_files.update({
                    os.path.join(emp_path_with_name, emp_path, f"training_id" \
                                                              f"_{t.etr_id}",
                                 at): os.path.join(
                        settings.TRAINING_FILES_DIR,
                        f"employee_id_{t.etr_emp.emp_id}",
                        f"training_id_{t.etr_id}", at)
                    for at in
                    t.attachments.filter(eta_attachment_type=1).values_list('eta_attachment_name',
                                                    flat=True)})

                description_text = LanguageTranslation.objects.filter(
                    ltr_lng_id = lng_id,
                    ltr_tag = t.etr_training_code.rld_name,
                    ltr_tag_type = t.etr_training_code.rld_tag_type
                ).values_list('ltr_text',flat=True)[0]
                training_type_text = LanguageTranslation.objects.filter(
                    ltr_lng_id = lng_id,
                    ltr_tag = t.etr_training_type.rld_name,
                    ltr_tag_type = t.etr_training_type.rld_tag_type
                ).values_list('ltr_text',flat=True)[0]

                

                if t.etr_training_institution:
                    training_institution_text = LanguageTranslation.objects.filter(
                        ltr_lng_id = lng_id,
                        ltr_tag = t.etr_training_institution.rld_name,
                        ltr_tag_type = t.etr_training_institution.rld_tag_type
                    ).values_list('ltr_text',flat=True)[0]
                else:
                    training_institution_text = '  '

                if t.etr_training_status:
                    # etr_training_code_id
                    training_status_text = LanguageTranslation.objects.filter(
                        ltr_lng_id = lng_id,
                        ltr_tag = t.etr_training_status.rld_name,
                        ltr_tag_type = t.etr_training_status.rld_tag_type
                    ).values_list('ltr_text',flat=True)[0]
                else:
                    training_status_text='  '

                
                context["records"].append({
                    "training_code": t.etr_training_code.rld_code,
                    "description": description_text,
                    "institution": training_institution_text,
                    "completion_date": datetime.datetime.strptime(str(t.etr_completion_date),'%Y-%m-%d').strftime('%Y-%m-%d') if t.etr_completion_date else get_trans[1381],
                    "expiry_date": datetime.datetime.strptime(str(t.etr_expiry_date),'%Y-%m-%d').strftime('%Y-%m-%d') if t.etr_expiry_date else get_trans[1381],
                    "training_type": training_type_text,
                    "is_expired" : training_status_text
                })

            filePath = settings.TRAINING_FILES_DIR

            timestamp = datetime.datetime.now().strftime('%Y%m-%d%H-%M%S')

            training_filename = get_trans[1034].lower().replace(" ","-")
            filename = f"" \
                       f"{slugify(employee_name.per_last_name+'_'+ employee_name.per_first_name)}" \
                       f"_{timestamp}-{training_filename}.pdf"

            pdf = render_to_pdf(context)

            temp_dir = tempfile.gettempdir()
            filepath = os.path.join(temp_dir, filename)

            with open(filepath, 'wb+') as dest:
                dest.write(pdf)
            files[os.path.join(emp_path_with_name, emp_path, filename)] = \
                filepath

        zip_file_name = f'training_report_{timestamp}.zip'
        zip_file_path = os.path.join(temp_dir, zip_file_name)

        with ZipFile(zip_file_path, 'w') as zip:
            for filename, filepath in files.items():
                zip.write(filepath, filename)
            for media_file, media_path in media_files.items():
                zip.write(media_path, media_file)


        response = HttpResponse(FileWrapper(open(zip_file_path, 'rb')),
                                content_type='application/zip')
        content = "attachment; filename=%s" % zip_file_name
        response['Content-Disposition'] = content
        return response
