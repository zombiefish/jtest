from django.db.models.fields import CharField
from apps.language.models import Language
from numpy import pi
from apps.employee.models import Employee
from apps.person.models import Person
from datetime import datetime
from typing import List
from django.conf import settings
from django.db.models import F, Value, Q
from django.db.models.expressions import Ref
from django.db.models.functions import Concat
from django.http import HttpResponse, JsonResponse
from django.template.loader import get_template
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.incident_management.api.utlity_function import dictfetchall
from apps.training.models import EmployeeTraining
import pandas as pd
from apps.reflist.models import RefListDetail
import time 
from apps.user_settings_profile.models import UserProfile
from apps.common_utils.views.get_translations import get_translation
import re

class EmployeeTrainingMatrix(APIView):
    

    def post(self, request):

        '''
        In request we receive 
            - list of employee id's
            - list of tarining code's
            {
                "employees": [1464, 1462, 1467],
                "training_code": [3814, 3955]
            }
        
        fetch all the training records (two columns training code and emp_id)         
        '''
        
        list_employees_id = request.data['employees']
        list_training_code = request.data['training_code']       

        employee_training_data = EmployeeTraining.objects.filter(
                etr_training_code__in = list_training_code,
                etr_emp__in = list_employees_id,
                etr_enable=True, 
            ).annotate(
                emp_name = Concat("etr_emp__emp_id", Value('-'),'etr_emp__emp_per__per_last_name', Value(' '), 'etr_emp__emp_per__per_first_name', output_field=CharField()),
                training_code = F('etr_training_code__rld_code'),
            ).values('etr_training_code', 'etr_emp', 'emp_name', 'training_code').exclude(etr_expiry_date__lte=datetime.now()).order_by('etr_emp').distinct()      


        # Prepare matrix for employees doesnt have the selected training matrix.
        '''
        get list of training code and employee id that doesnt result in the above queryset.        
        prepare a null matrix for each training code and employee name with etr_emp as 0 and append the null matrix to main querset data employee_training_data
        '''
        lst_tc = []
        lst_emp = []
        for each in employee_training_data:
            if each['etr_training_code'] not in lst_tc:
                lst_tc.append(each['etr_training_code'])
            if each['etr_emp'] not in lst_emp:
                lst_emp.append(each['etr_emp'])
        
        lst_tc_null = sorted(list(set(list_training_code).difference(lst_tc)))
        lst_emp_null = sorted(list(set(list_employees_id).difference(lst_emp)))

        lst_emp_null_names = Employee.objects.filter(emp_id__in = lst_emp_null).annotate(
            full_name = Concat("emp_id", Value('-'), "emp_per__per_last_name", Value(" "), "emp_per__per_first_name", output_field=CharField())
        ).values('emp_per_id', 'full_name').order_by('emp_per_id') 
        # concatinating emp_id and person name as full name, because, in some cases two userid's got same first name and last name.



        lst_tc_null_names = EmployeeTraining.objects.filter(etr_training_code__in = lst_tc_null).annotate(
            training_code = F('etr_training_code__rld_code'),
        ).values('etr_training_code', 'training_code').order_by('etr_training_code')

        null_matrix = []
        for person in lst_emp_null_names:
            for training in lst_tc_null_names:
                temp_rec = {}
                temp_rec['etr_emp'] = 0
                temp_rec['etr_training_code'] = training['etr_training_code']    
                temp_rec['emp_name'] = person['full_name']
                temp_rec['training_code'] = training['training_code']  
                if temp_rec not in null_matrix:             
                    null_matrix.append(temp_rec.copy())        
        
        employee_training_data = list(employee_training_data)
        for each in null_matrix:
            employee_training_data.append(each)        
        
        training_code_names = []
        person_records = []
        if employee_training_data:
            df = pd.DataFrame(employee_training_data)
            pivot_data = df.pivot_table(index='emp_name', columns = 'training_code', values = 'etr_emp')            
            pivot_data = pivot_data.fillna('')        
            pivot_data = pivot_data.replace(list_employees_id, 'OK')
            pivot_data = pivot_data.replace(0, '')
            training_code_names = [col for col in pivot_data.columns.values]            
            for idx, row in pivot_data.iterrows():
                row_data = [r for r in row] 
                per_name = re.sub('[0-9]*-', '', row.name) #replacing user id in person full name with empty space.           
                row_data.insert(0, per_name)
                person_records.append(row_data)

        person = self.request.user.user_per_id
        language = UserProfile.objects.get(upr_per = person).upr_language
        lng_id = Language.objects.get(lng_name = language)
        ltr_tags = [8333, 8334, 1187] 
        person_records = sorted(person_records, key=lambda x: x[0]) # sort a-z on person_names
        context = {
            'training_codes' : list(training_code_names),
            'person_records' : person_records,
            'colspan' : len(training_code_names)+1,
            'date': datetime.today().strftime('%Y-%m-%d'),
            'language': language,
            'translate' :get_translation(ltr_tags, lng_id)
        }

        return Response(self.get_html(context))    

    def get_html(self, data):
            html = ''                 
            templates = get_template("training_matrix_report.html")
            html = templates.render(data)
            return html