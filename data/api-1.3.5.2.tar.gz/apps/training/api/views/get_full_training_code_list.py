from django.db.models import OuterRef, Subquery
from apps.common_utils.views.validate_permission import RolePermission
from apps.language.models import Language, LanguageTranslation
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from django.db import connection
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.http import JsonResponse
from rest_framework import status
import json
from rest_framework.parsers import JSONParser
from apps.incident_management.api.utlity_function import dictfetchall
from apps.reflist.models import RefListDetail


class GetFullTrainingCodeList(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewTrainingRecords.value,)

    def get(self, request, rlh_name):
        '''
        get all traingcode list from ref list detail table 
        '''
        person = self.request.user.user_per_id
        lng_name = UserProfile.objects.get(upr_per_id= person).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)   

        trainingCodeList = RefListDetail.objects.filter(
            rld_rlh__rlh_name = rlh_name
        ).annotate(
            name = Subquery(LanguageTranslation.objects.filter(
                ltr_tag=OuterRef('rld_name'), 
                ltr_tag_type = OuterRef('rld_tag_type'),
                ltr_lng = lng_id,
                ltr_enable=1).values('ltr_text')[:1]),
            description = Subquery(LanguageTranslation.objects.filter(
                ltr_tag=OuterRef('rld_description'), 
                ltr_tag_type = OuterRef('rld_tag_type'),
                ltr_lng = lng_id,
                ltr_enable=1).values('ltr_text')[:1])
        ).values('rld_id', 'rld_code', 'rld_name', 'name', 'description', 'rld_tag_type', 'rld_option')

        return Response(trainingCodeList)
