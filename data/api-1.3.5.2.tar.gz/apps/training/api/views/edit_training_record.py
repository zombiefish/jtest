from datetime import datetime
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status

from django.conf import settings
from apps.common_utils.views.validate_permission import RolePermission
from apps.employee.models import Employee
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.training.models import EmployeeTraining
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from apps.training.models import EmployeeTrainingAttachment

class EditTrainingRecord(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewTrainingRecords.value,)


    def post(self, request, *args, **kwargs):
        employee_id = request.data['emp_id']
        etr_id = request.data['etr_id']
        etr_training_type_id = request.data['etr_training_type']
        etr_training_institution_id = request.data['etr_training_institution']
        etr_completion_date = request.data['etr_completion_date']
        etr_expiry_date = request.data['etr_expiry_date']
        etr_no_expiry_date = request.data["etr_no_expiry_date"]
        etr_training_status = request.data['etr_training_status']
        etr_training_code_id = request.data['etr_training_code']
        etr_modified_by_per_id = self.request.user.user_per_id_id


        try:
            # update - employee training records
            training_rec = EmployeeTraining.objects.get(pk=etr_id)
            training_rec.etr_training_code_id = etr_training_code_id
            training_rec.employee_id = employee_id
            training_rec.etr_training_type_id = etr_training_type_id
            training_rec.etr_training_institution_id = etr_training_institution_id
            training_rec.etr_completion_date = etr_completion_date
            training_rec.etr_expiry_date = etr_expiry_date
            training_rec.etr_no_expiry_date = etr_no_expiry_date
            training_rec.etr_training_status_id = etr_training_status
            training_rec.etr_modified_by_per_id = etr_modified_by_per_id
            training_rec.etr_modified_date = datetime.now()
            # Updating the edited record
            training_rec.save()

        except Exception as e:
            return Response({'received data': request.data,
                             'Message': "", "Error": str(e), },
                            status=status.HTTP_400_BAD_REQUEST)

        return Response({"received data": request.data, 'Message': "Updated Successfully", "Error": "", },
                        status=status.HTTP_201_CREATED)


class UpdateTrainingAttachments(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewTrainingRecords.value,)

    def post(self, request, *args, **kwargs):

        eta_attachment_payload = request.data        
        try:            
            for attachment_rec in eta_attachment_payload:   
                eta_id = attachment_rec['eta_id']
                eta_etr_id = attachment_rec['eta_etr_id']
                eta_attachment_comment = attachment_rec['eta_attachment_comment']
                eta_enable = attachment_rec['eta_enable']
                # find the attachment record            
                EmployeeTrainingAttachment_rec = EmployeeTrainingAttachment.objects.get(pk=eta_id)
                
                # Set settings
                EmployeeTrainingAttachment_rec.eta_attachment_comment = eta_attachment_comment
                EmployeeTrainingAttachment_rec.eta_enable = eta_enable
                
                # Updating the edited Employee Training Attachment
                EmployeeTrainingAttachment_rec.save()
        except Exception as e:
            return Response({'received data': request.data,
                             'Message': "", "Error": str(e), },
                            status=status.HTTP_400_BAD_REQUEST)

        return Response({"received data": request.data, 'Message': "Updated Successfully", "Error": "", },
                        status=status.HTTP_201_CREATED)


class DeleteTrainingAttachments(APIView):
    permission_classes = [SofviePermission]

    def post(self, request, *args, **kwargs):

        eta_id = request.data['eta_id']
        eta_modified_by_per_id = self.request.user.user_per_id_id       

        try:
            # find the attachment record         
            EmployeeTrainingAttachment_rec = EmployeeTrainingAttachment.objects.get(pk=eta_id)
            EmployeeTrainingAttachment_rec.eta_enable = 0
            EmployeeTrainingAttachment_rec.eta_modified_by_per_id = eta_modified_by_per_id

            # Updating the edited Employee Training Attachment
            EmployeeTrainingAttachment_rec.save()
        except Exception as e:
            return Response({'received data': request.data,
                             'Message': "", "Error": str(e), },
                            status=status.HTTP_400_BAD_REQUEST)

        return Response({"received data": request.data, 'Message': "Deleted Successfully", "Error": "", },
                        status=status.HTTP_201_CREATED)
