from rest_framework.views import APIView


class DeleteAttachment(APIView):
    permission_classes = []