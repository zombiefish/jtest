import json
import requests
from django.db import connection
from rest_framework import viewsets, serializers
from apps.person.models import Person
from apps.training.models import IntegrationTrainingTemp


class NorcatDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = IntegrationTrainingTemp
        fields = '__all__'


highNORCATRec = 0
highExternalRec = 0


class GetNorcatData(viewsets.ModelViewSet):
    serializer_class = NorcatDataSerializer

    def get_queryset(self):
        data = IntegrationTrainingTemp.objects.all().order_by('-id')
        return data

    def _get_norcat_data(self):
        url = "https://sofvie.norcat.org/wss.asmx/getUserTrainingByCompany"
        inner_dictionary = {"pullkey": "5VYPm2mXwfcWLvF"}
        final_dict = {"data": json.dumps(inner_dictionary)}

        api_request = requests.post(url, data=final_dict)

        try:
            api_request.raise_for_status()
            return api_request.json()
        except:
            return None

    def get_function_data(self):
        a = self.save_norcat_data()
        b = self.get_training_code()
        c = self.get_training()

    def save_norcat_data(self):
        global highExternalRec
        global highNORCATRec

        raw_data = self._get_norcat_data()
        if raw_data is not None:
            if raw_data['highExternalRec'] > highExternalRec and raw_data['highNORCATRec'] > highNORCATRec:
                highExternalRec = raw_data['highExternalRec']
                highNORCATRec = raw_data['highNORCATRec']
            else:
                import datetime
                print(f"Time: {datetime.datetime.now()} - NO NEW RECORDS FOUND!!")
                return True
            # try:
            norcat_ids = []
            get_norcat_id = Person.objects.filter(per_norcat_id__isnull=False).values_list('per_norcat_id', flat=True)
            temp = []
            for i in raw_data['profile']:
                if i['NorcatID'] in get_norcat_id:
                    temp.append(i)

            person = Person.objects.filter(per_norcat_id__in=get_norcat_id).prefetch_related(
                "employees"
            ).values_list('employees__emp_employee_number', flat=True)
            batch = []
            for i in temp:
                if len(i['trainingRecords']) > 0:
                    r2 = person.filter(per_norcat_id=i['NorcatID']).values_list('employees__emp_employee_number', flat=True)[0]


                    if r2:
                        training_record_data = i['trainingRecords'][0]
                        result = IntegrationTrainingTemp(
                            int_emp_employee_number=r2,
                            int_training_type_code='training!!',
                            int_training_type_name=training_record_data['CourseName'] if 'CourseName' in training_record_data else None,
                            int_training_code=training_record_data['CourseID'] if 'CourseID' in training_record_data else None,
                            int_training_name=training_record_data['moduleRecord'][0]['Name'] if 'moduleRecord' in training_record_data and training_record_data['moduleRecord'] is not None and len(training_record_data['moduleRecord']) > 0 else None,
                            int_etr_completion_date=training_record_data['TrainingDate'] if 'TrainingDate' in training_record_data else None,
                            int_etr_expiry_date=training_record_data['ExpiryDate'] if 'ExpiryDate' in training_record_data else None,

                        )
                        batch.append(result)
            IntegrationTrainingTemp.objects.bulk_create(batch, batch_size=100)

            return True

    def get_training_code(self):
        with connection.cursor() as cursor:
            cursor.execute("call int_process_training_codes()")
        return True

    def get_training(self):
        with connection.cursor() as cursor:
            cursor.execute("call int_process_training()")
        return True

