import sys
from urllib import request
from decouple import config
from pytz import utc
from django.conf import Settings, settings

from apscheduler.schedulers.background import BackgroundScheduler
from ..views.get_norcat_training_data import GetNorcatData


def start():
    try:
       print('TECHNICA_NORCAT_SCHEDULER_STATUS', settings.TECHNICA_NORCAT_SCHEDULER_STATUS)
    except KeyError:
        print("Tried accessing an environment variable that does not exist")
        sys.exit(1)
    scheduler_run_status = settings.TECHNICA_NORCAT_SCHEDULER_STATUS
    
    if scheduler_run_status == 1:
        print('SCHEDULER - START FOR ', settings.INTEGRATION_INTERVAL_TIME)
        scheduler = BackgroundScheduler({
            'apscheduler.executors.default': {
            'class': 'apscheduler.executors.pool:ThreadPoolExecutor',
            'max_workers': '2'
            },
        },
        daemon=True,
        # timezone=utc

        )
        norcat_data = GetNorcatData()

        
        # scheduler.add_job(norcat_data.save_norcat_data, "interval", seconds=30, id="norcat_001", replace_existing=True)
        scheduler.add_job(norcat_data.get_function_data, "interval", minutes=settings.INTEGRATION_INTERVAL_TIME)

        scheduler.start()
        print('SCHEDULER - RESUME LATER')
    else :
        print('TRAINING RECORDS SYNC - SCHEDULER IS OFF IN STATUS')

