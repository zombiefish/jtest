import datetime

from django.utils import timezone
from rest_framework import serializers
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.employee.models import Employee
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.training.models import EmployeeTraining


class TrainingRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeTraining
        fields = [
            'etr_id',
            'etr_emp_id',
            'etr_training_type_id',
            'etr_training_institution_id',
            'etr_training_code_id',
            'etr_completion_date',
            'etr_expiry_date',
        ]


class CreateTrainingRecord(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageTrainingRecords.value,RolePermission.CanViewTrainingRecords.value,)


    def post(self, request, *args, **kwargs):

        created_by_modified_by = self.request.user.user_per_id_id
        per_id = request.data["emp_per"]
        emp_id = Employee.objects.filter(emp_per_id__in=per_id).values_list('emp_id', flat=True) # getting emp_id from per_id
        request.data["etr_emp"] = per_id[0]
        etr_training_type_id = request.data["etr_training_type"]
        etr_training_institution_id = request.data["etr_training_institution"]
        etr_training_code_id = request.data["etr_training_code"]
        etr_completion_date = request.data["etr_completion_date"]
        etr_expiry_date = request.data["etr_expiry_date"]
        etr_no_expiry_date = request.data["etr_no_expiry_date"]
        etr_training_status_id = request.data["etr_training_status"]

        resObj = []
        try:
            for employeeid in emp_id:              
                instance = EmployeeTraining.objects.filter(
                    etr_emp_id=employeeid, 
                    etr_training_type_id=etr_training_type_id,
                    etr_training_institution_id=etr_training_institution_id,
                    etr_training_code_id=etr_training_code_id,
                    etr_training_status_id = etr_training_status_id,
                    etr_enable=1
                ).first()                

                if instance:
                    # print('instance ---- ', instance.etr_id)
                    # if the record is already existing, soft delete and insert new record
                    queryset = EmployeeTraining.objects.filter(
                        etr_id= instance.etr_id,
                        etr_enable=1
                        ).update(
                            etr_emp_id=employeeid,
                            etr_training_type_id=etr_training_type_id,
                            etr_training_institution_id=etr_training_institution_id,
                            etr_training_code_id=etr_training_code_id,
                            etr_training_status_id = etr_training_status_id,
                            etr_completion_date=etr_completion_date,
                            etr_expiry_date=etr_expiry_date,
                            etr_no_expiry_date=etr_no_expiry_date,
                            etr_enable=1,                            
                            etr_modified_by_per_id=created_by_modified_by,                            
                            etr_modified_date=datetime.datetime.now(),
                            etr_external_source=0,
                            etr_is_integrated=0
                        )
                    resObj.append({"emp_id" : employeeid, "etr_id": instance.etr_id})
                else:
                    employee_training = EmployeeTraining.objects.create(
                        etr_emp_id=employeeid,
                        etr_training_type_id=etr_training_type_id,
                        etr_training_institution_id=etr_training_institution_id,
                        etr_training_code_id=etr_training_code_id,
                        etr_training_status_id = etr_training_status_id,
                        etr_completion_date=etr_completion_date,
                        etr_expiry_date=etr_expiry_date,
                        etr_no_expiry_date=etr_no_expiry_date,
                        etr_enable=1,
                        etr_created_by_per_id=created_by_modified_by,                        
                        etr_created_date=datetime.datetime.now(),          
                        etr_modified_by_per_id=created_by_modified_by,                            
                        etr_modified_date=datetime.datetime.now(),              
                        etr_external_source=0,
                        etr_is_integrated=0
                    )
                    employee_training.save()
                    last_id = EmployeeTraining.objects.last()        
                    resObj.append({"emp_id" : employeeid, "etr_id": last_id.etr_id})
                
            return Response({"requested_data": request.data, "emp_training": resObj}, status=200)
        except Exception as e:
            print("------ Failing to save employee_training ---")
            print(str(e))
            return Response({"message": "Failed to save employee_training"}, status=400)
        # last_id = EmployeeTraining.objects.last()
        # print('this is latest id------', last_id.etr_id)
        # return Response({"requested_data": request.data, "emp_training": resObj})
