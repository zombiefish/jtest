from django.db import connection
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.http import JsonResponse
from rest_framework import status
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user.api import RolePermission
import json
from apps.training.models import EmployeeTrainingAttachment
from rest_framework.parsers import JSONParser
from apps.incident_management.api.utlity_function import dictfetchall
from apps.training.api.serializers import GetAllTrainingRecordAttachments


class ListTrainingRecordAttachments(APIView):
	permission_classes = [SofviePermission]
	permission_attrs = (RolePermission.BasicAccess.value,)

	def post(self, request):
		etr_id = request.data['etr_id']
		trainingCodeList = EmployeeTrainingAttachment.objects.filter(
			eta_etr_id=etr_id, eta_enable=True
		)
		serializer_class = GetAllTrainingRecordAttachments(trainingCodeList, many=True)
		return Response({"attachments": serializer_class.data})
