from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.add_attachment import save_the_file, training_store_data
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.common_utils.views.validate_permission import RolePermission
class AddTrainingAttachments(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageTrainingRecords.value,RolePermission.CanViewTrainingRecords.value,)

    def post(self, request):
        created_by = self.request.user.user_per_id_id
        etr_id = request.POST['etr_id']        
        comment = request.POST['comment']
        eta_type = request.POST['type']
        filename = request.POST['filename']
        etr_emp_id = request.POST['etr_emp']

        
        eta_attachment_files = request.FILES.getlist('attfile')        

        attachment_type = 2 if eta_type == 'link' else 1

        data_args = {
            'app': 'Training',     
            'id': etr_id,       
            'comment': comment,
            'person_id': created_by,
            'attachment_type': attachment_type,
            'filename': filename,
            'etr_emp_id': etr_emp_id,
        }

        if eta_type == 'link':
            data_args['filename'] = filename
            response = training_store_data(data_args)
        
        else:
            data_args['files'] = eta_attachment_files
            data_args['only_image'] = False

            response = save_the_file(data_args)

        return Response(response)
