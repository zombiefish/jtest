from datetime import datetime
from django.conf import settings
from django.db.models import F, Value
from django.db.models.functions import Concat
from django.http import HttpResponse, JsonResponse
from django.template.loader import get_template
from rest_framework import status
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from xhtml2pdf import pisa

from apps.employee.models import Employee
from apps.incident_management.api.utlity_function import dictfetchall
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.training.models import EmployeeTraining


class EmployeeTrainingMatrix(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):

        '''
        In request we receive 
            - list of employee id's
            - list of tarining code's
            {
                "employees": [1464, 1462, 1467],
                "training_code": [3814, 3955]
            }
        
        fetch all the training records (two columns training code and emp_id)

        loop through result set and create a dictionary that match employee - training code
        if matches set bool value to 'OK', if not matches set bool value to ' '        
        '''
        
        data = request.data
        list_employees_id = data['employees']
        list_training_code = data['training_code']
        # print(' list_employees_id__:', list_employees_id)
        # print(' list_training_code__:', list_training_code)        
        etr_data = EmployeeTraining.objects.filter(
                etr_training_code__in = list_training_code,
                etr_emp__in = list_employees_id,
                etr_enable=True, 
            ).annotate(
                emp_name = Concat('etr_emp__emp_per__per_last_name', Value(' '), 'etr_emp__emp_per__per_first_name'),
                training_code = F('etr_training_code__rld_code')
            ).values('etr_training_code', 'etr_emp', 'emp_name', 'training_code').order_by('etr_emp').distinct()
        
        list_person_full_names = Person.objects.filter(
            employees__emp_id__in = list_employees_id
            ).annotate(
                full_name=Concat('per_last_name', Value(' '), 'per_first_name')
            ).prefetch_related('employees').values_list('full_name', flat=True).order_by('per_id')
        list_training_code_names = RefListDetail.objects.filter(
            rld_id__in=list_training_code
            ).values_list('rld_code', flat=True).order_by('rld_id')
        
        employee_training_data = [rec for rec in etr_data if rec['etr_emp'] in list_employees_id]
        avail_codes = [rec['etr_training_code'] for rec in employee_training_data]
        avail_code_names = [rec['training_code'] for rec in employee_training_data]               
        context_list_training_code =[code for code in list_training_code if code in avail_codes]
        context_list_training_code_names =[code_name for code_name in list_training_code_names if code_name in avail_code_names]
        
         
        employee_training_matrix = []
        for emp, person in zip(sorted(list_employees_id), list_person_full_names):
            for code, training in zip(sorted(list_training_code), list_training_code_names):
                temp_rec = {}
                temp_rec['etr_emp'] = emp
                temp_rec['etr_training_code'] = code    
                temp_rec['emp_name'] = person
                temp_rec['training_code'] = training
                if temp_rec in employee_training_data:
                    temp_rec['bool'] = 'OK'
                else:
                    temp_rec['bool'] = ''
                employee_training_matrix.append(temp_rec.copy())
        
        person_records = []
        for emp_id, person in zip(sorted(list_employees_id), list_person_full_names):
            temprec = [rec['bool'] for rec in employee_training_matrix if emp_id == rec['etr_emp']] 
            temprec.insert(0,person)
            # if 'OK' in temprec:
            person_records.append(temprec)

        context = {
            'training_codes' : list(list_training_code_names),
            'person_records' : person_records,
            'colspan' : len(list_training_code_names)+1,
            'date': datetime.today().strftime('%Y-%m-%d')
        }
        
        return Response(self.get_html(context))    

    def get_html(self, data):
            html = ''
            template = get_template("training_matrix_report.html")
            html = template.render(data)
            return html


            # s_original = time.time()
        # list_trc = [] 
        # list_emp = []
        # for each in employee_training_data:
        #     list_trc.append(each['etr_training_code'])
        #     list_emp.append(each['etr_emp'])                
        # tc_null = list(set(list_trc).symmetric_difference(set(list_training_code)))        
        # emp_null = list(set(list_emp).symmetric_difference(set(list_employees_id)))   
        # tc_names_null = RefListDetail.objects.filter(rld_id__in = tc_null).values_list('rld_code', flat = True).order_by('rld_id')
        # emp_names_null = Employee.objects.filter(emp_id__in = emp_null).annotate(
        #         full_name=Concat('emp_per__per_last_name', Value(' '), 'emp_per__per_first_name')
        #     ).values_list('full_name', flat = True).order_by('emp_per_id')
        # null_matrix = []
        # for emp, person in zip(sorted(emp_null), emp_names_null):
        #     temp_rec = {}
        #     temp_rec['etr_emp'] = emp
        #     # temp_rec['etr_training_code'] = None
        #     temp_rec['emp_name'] = person
        #     # temp_rec['training_code'] = None               
        #     null_matrix.append(temp_rec.copy())
        # for code, training in zip(sorted(tc_null), tc_names_null):   
        #     temp_rec = {}
        #     # temp_rec['etr_emp'] = None
        #     temp_rec['etr_training_code'] = code    
        #     # temp_rec['emp_name'] = None
        #     temp_rec['training_code'] = training               
        #     null_matrix.append(temp_rec.copy())
        # e_origios = time.time()
        # print(e_origios-s_original)
        # employee_training_data = list(employee_training_data)
        # for each in null_matrix:
        #     employee_training_data.append(each)


        # from tabulate import tabulate
        # df = pd.DataFrame(employee_training_data)
        # print('Initial \n', tabulate(df.head(20), headers='keys', tablefmt='psql'))

        # # sample_df = 


        # df[['emp_name','training_code']] = df[['emp_name','training_code']].fillna('NA')
        # df = df.drop_duplicates(df['emp_name'] == some_value)
        # # To keep things simple while dropping col and index
        # # print('After fill NA\n', tabulate(df, headers='keys', tablefmt='psql'))

        # # pivot_data = df.pivot(
        # #                 index='emp_name', 
        # #                 columns = 'training_code', 
        # #                 values = 'etr_emp'
        # #                 ).rename_axis(index=None, columns=None)
        
        # # print('Befor drop NA and reset index \n', tabulate(pivot_data, headers='keys', tablefmt='psql'))
        
        # pivot_data = df.pivot(
        #                 index='emp_name', 
        #                 columns = 'training_code', 
        #                 values = 'etr_emp'
        #                 ).rename_axis(index=None, columns=None).drop(columns='NA', index='NA')

        # df[['C','D']] = df[['C','D']].fillna('NA')
        # df = df.drop_duplicates(['C'])
        # df.pivot(index = 'C', columns = 'D', values='B').rename_axis(index=None, columns=None).drop(columns='NA', index='NA')