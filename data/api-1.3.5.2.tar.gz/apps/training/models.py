from django.db import models
from apps.employee.models import Employee
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.common_utils.views.sofvieModelFields import SofvieCharField, SofvieIntegerField, SofvieTextField
class EmployeeTraining(models.Model):
    etr_id = models.AutoField(primary_key=True)
    etr_emp = models.ForeignKey(Employee, on_delete=models.DO_NOTHING,
                                related_name='training')

    etr_training_type = models.ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,
                                          blank=True, null=True, related_name="training_type")

    etr_training_institution = models.ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,
                                                   blank=True, null=True,
                                                 related_name="training_institute")
    etr_training_code = models.ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,
                                            blank=True, null=True, related_name="training_code")
    etr_completion_date = models.DateField(blank=True, null=True)
    etr_expiry_date = models.DateField(blank=True, null=True)
    etr_no_expiry_date = models.BooleanField(default=False)
   
    
    etr_training_status = models.ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,
                                            blank=True, null=True, related_name="training_status")
   
    etr_created_date = models.DateTimeField(auto_now_add=True, blank=False, null=False)
    etr_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=False, null=False,
                                           related_name='etr_created_by_per')
    etr_modified_date = models.DateTimeField(blank=True, null=True)
    etr_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='etr_modified_by_per')
    etr_enable = models.BooleanField()
    etr_enote = SofvieTextField(blank=True, null=True)
    etr_external_source = SofvieIntegerField()
    etr_is_integrated = SofvieIntegerField()

    class Meta:
        db_table = 'employee_training'

    def only_enable_eta_attachment(self):
        return EmployeeTrainingAttachment.objects.filter(eta_etr=self, eta_enable=1)


class EmployeeTrainingAttachment(models.Model):
    eta_id = models.AutoField(primary_key=True)
    eta_etr = models.ForeignKey(EmployeeTraining, models.DO_NOTHING,
                                related_name='attachments')
    eta_attachment_name = SofvieCharField(max_length=200, allow_list=['//'])
    eta_attachment_comment = SofvieCharField(max_length=200, blank=True,
                                              null=True, allow_list=['//'])
    eta_attachment_type = SofvieIntegerField(blank=True,null=True)
    eta_created_date = models.DateTimeField(blank=True, null=True)
    eta_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='eta_created_by_per')
    eta_modified_date = models.DateTimeField(blank=True, null=True)
    eta_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='eta_modified_by_per')
    eta_enable = models.BooleanField()
    eta_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'employee_training_attachment'


class IntegrationTrainingTemp(models.Model):
    id = models.AutoField(primary_key=True)
    int_emp_employee_number = models.CharField(max_length=50)
    int_training_type_code = models.CharField(max_length=50)
    int_training_type_name = models.CharField(max_length=50)
    int_training_type_description = models.TextField()
    int_training_institution_code = models.CharField(max_length=50)
    int_training_institution_name = models.CharField(max_length=50)
    int_training_institution_description = models.TextField()
    int_training_code = models.CharField(max_length=50)
    int_training_name = models.CharField(max_length=50)
    int_training_description = models.TextField()
    int_etr_completion_date = models.DateTimeField()
    int_etr_expiry_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        db_table = 'integration_training_temp'

    def __str__(self):
        return str(self.int_emp_employee_number)

