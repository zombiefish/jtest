from django.apps import AppConfig
import os

class TrainingConfig(AppConfig):
    name = 'apps.training'

    def ready(self):     
        # scheduler starting here
        if os.environ.get('RUN_MAIN', None) != 'true':
            print(f"Starting NORCAT scheduler...")
            from ..training.api.views import norcat_api_updater
            norcat_api_updater.start()
     
