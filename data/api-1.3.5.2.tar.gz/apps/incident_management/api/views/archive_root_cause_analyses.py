from django.db import connection
from rest_framework import status
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class ArchiveRootCauseAnalyses(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.ArchiveSubmissions.value, RolePermission.CanManageIncidents.value)
    parser_classes = [JSONParser]

    def post(self, request):
        

        if 'rootCauseAnalysesId' not in request.data:
            return Response({'error': 'You must provide '
                                      '`rootCauseAnanlysesId`'})
        elif type(request.data['rootCauseAnalysesId']) != list:
            return Response({'error': 'You must provide list'})
        elif len(request.data['rootCauseAnalysesId']) == 0:
            return Response({'error': 'You can not send empty list'})

        root_cause_analyses_id = request.data['rootCauseAnalysesId']

        for rcaid in root_cause_analyses_id:
            try:
                with connection.cursor() as cursor:
                    cursor.execute(
                        "call sp_ArchiveRootCauseAnalyses(%s, @ErrorMsg)",
                        (rcaid,))
                    cursor.execute('select @ErrorMsg')
                    inc = cursor.fetchall()
            except Exception as e:
                print("Exception:"+str(e))

        return Response(status=status.HTTP_200_OK)
