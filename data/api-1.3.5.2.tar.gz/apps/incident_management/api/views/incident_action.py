import os
import uuid

import magic
from decouple import config
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.core.mail import EmailMultiAlternatives
from django.db import connection
from django.template.loader import get_template
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.get_translations import get_translation
from apps.common_utils.views.validate_permission import RolePermission
from apps.general_action.models import Reports, Submissionheader
from apps.hazard_action.models import Submissionhap
from apps.incident_management.api.utlity_function import dictfetchall
from apps.language.models import Language, LanguageTranslation
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user.models import User
from apps.user_settings_profile.models import UserProfile
from django.utils.safestring import mark_safe


# Function from magic library
def check_in_memory_mime(self, in_memory_file):
    mime = magic.from_buffer(in_memory_file.read(), mime=True)
    return mime

# Function responsible to save the file in filesystem
def save_the_file(self, file, submissionUUID, fileext, path=settings.HAZARD_ACTION_DIR):    
    
    fsStore = FileSystemStorage()
    fileDir = os.path.join(path)
    filePath = os.path.join(fileDir, file.name)
   
    renamefilepath =  path  + '/' + submissionUUID + fileext

    if os.path.exists(fileDir) == False:
        os.mkdir(fileDir)

    if os.path.exists(filePath):
        raise Exception(f"file-name collision error: {file.name}")

    try:

        with open(filePath, 'wb') as dest:
            for chunk in file.chunks():
                dest.write(chunk)
        


        os.rename(filePath,renamefilepath)
    except Exception as e:

        return (False, str(e))
    else:
        return (True, filePath)

class GetIncidentActionsByIncidentId(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)
    """ Response for the All actions using incident ID"""

    def post(self, request):

        # Access Role Permission - Atleast the ROLE having "Can Manage Incidents"
        # Isexists = PersonAccessPermission(self, RolePermission.CanManageIncidents)
        # # print(Isexists)
        # if Isexists == 0:
        #     return Response({'accessMsg': 'Access denied - You do not have permission to Manage Incidents'})

        _incidentId = request.data['incidentId']
        with connection.cursor() as cursor:
            cursor.execute(
                "call get_incident_action_by_incident_id(%s)", ([_incidentId]))
            row = dictfetchall(cursor)

        return Response(row)

class CreateHAP(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)

    """ Request to insert/create submission hap record """
    
    # setting the mimetypes
    allowed_mimes = {'application/pdf', 'image/jpg', 'image/png','text/plain',
                     'image/jpeg', 'application/vnd.ms-outlook','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     'application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-excel'}

    def post(self, request,*args, **kwargs):
        person_id = self.request.user.user_per_id_id      
        # print(request)
        incidentId = request.POST['incidentId']
        employeeId = request.POST['per_id']       
        myFile = request.FILES.getlist('myfile')

        hazard_type = request.POST["hazard_type"]
        hazard_identification  = request.POST["hazard_identification"]
        hazard_description = request.POST["hazard_description"]
        potential_risk = request.POST["potential_risk"]
        immediate_action_required_and_performed= 1 if request.POST["immediate_action_required_and_performed"] == 'true' else 0
        immediate_action_taken = request.POST["immediate_action_taken"]
        immediate_action_type = request.POST["immediate_action_type"]
        further_action_required = 1 if request.POST["further_action_required"] == 'true' else 0
        recommended_action = request.POST["recommended_action"]
        action_type = request.POST["action_type"]
        action_by_who = request.POST["action_by_who"]
        action_by_when = request.POST["action_by_when"]        
        # if further_action_required is false i.e, 0, set action_status as Complete else Incomplete.
        action_status = 'Complete' if further_action_required == 0 else 'Incomplete'
        completed_action_score = 0 

        submissionHeaderId = 0
        submission_hap_ID = 0
        hap = {}

        with connection.cursor() as cursor:
            cursor.execute("call sp_InsertHazardReportSubmissionHeader(@submissionHeaderId,%s,%s)", ([employeeId],[incidentId]))
            cursor.execute('select @submissionHeaderId as value')
            submissionHeaderId = cursor.fetchone()[0] # convert tuple or take a single value from the tuple instead of go with full tuple

            hap["submissionheaderid"] = submissionHeaderId

            cursor.execute("call get_ref_potential_loss_rld_name_tag(%s)", (potential_risk,))

            prsr = dictfetchall(cursor)
            if prsr == []:
                hap["potential_risk_score"] = 0
            else:              
                hap["potential_risk_score"] = dict(prsr[0])['score']

            cursor.execute("call get_ref_hazard_identification_rld_name(%s)", (hazard_description,))

            prsr = dictfetchall(cursor)
          
            if prsr == []:
                hap["hazard_identification_score"] = 0               
            else:
                hap["hazard_identification_score"] = dict(prsr[0])['score']

        #     select 'immediateActionScoreResult' Converting this query to SP creates other problems in the application
        #     Need more time to research why it is breaking. It breaks add-attachment endpoint for HAP
            sql ="select rld_score as score  from v_ref_header_detail_list where rlh_name = 'ref_action_type' and rld_name ='"+ immediate_action_type +"' limit 1"
        #     print(f"this is raw sql ref_action_type {sql}")
        #     cursor.execute("call get_ref_action_type_rld_name(%s)", (immediate_action_type,))
            cursor.execute(sql)
            prsr = dictfetchall(cursor)
            if prsr == []:
                hap["immediate_action_score"] = 0
            else:
                hap["immediate_action_score"] = dict(prsr[0])['score']

        # is_native_system
            hap["is_native_system"] = 1
        
        #     immediate_action_required_and_performed
            hap["immediate_action_required_and_performed"] = 1 if immediate_action_required_and_performed == 'true'  else 0

        #     further_action_required
            hap["further_action_required"] = 1 if immediate_action_required_and_performed == 'true'  else 0

            try:
        #         insert into submission hap   
                hazard_identification_score = hap["hazard_identification_score"]
                potential_risk_score = hap["potential_risk_score"]
                immediate_action_score = hap["immediate_action_score"]                
                is_native_system = hap["is_native_system"]

                # _id = ""
                args = (submissionHeaderId,
                        hazard_type ,
                        hazard_identification,
                        hazard_description,
                        potential_risk ,
                        immediate_action_required_and_performed,
                        immediate_action_taken ,
                        immediate_action_type ,
                        further_action_required ,
                        recommended_action ,
                        action_type ,
                        action_by_who ,
                        action_by_when,
                        action_status,
                        hazard_identification_score ,
                        potential_risk_score ,
                        immediate_action_score,
                        completed_action_score ,
                        is_native_system, 
                        person_id)
                proc_name = 'sp_insert_submission_hap'
               
                result_args = cursor.callproc(proc_name, args)               

                returnValue = dictfetchall(cursor)   
                submission_hap_ID = dict(returnValue[0])['ID']     
                hap["submission_hap_ID"] = submission_hap_ID
            except Exception as e:
                print('error - ',str(e))
    
        # file upload

        response_dict = {}
        for tmp in myFile:
            mimeType = check_in_memory_mime(self,tmp)
            fileType = '.' + tmp.name.split('.')[-1].lower()
            if mimeType in self.allowed_mimes:
               
                try:      
                    unq_Id = str(uuid.uuid4())                      
                    ret, fpath = save_the_file(self,tmp, unq_Id,fileType)
                    AttachmentFileName = unq_Id+fileType
                  
                except Exception as err:                    
                    response_dict[AttachmentFileName] = False
                else:
                    if ret:                       
                     
                        with connection.cursor() as cursor:
                            argss = (submission_hap_ID,AttachmentFileName,'','INITIAL',1 )
                            cursor.execute("call sp_insert_submission_hap_attachments("
                                        "%s,%s,%s,%s,%s)",(argss))
                            response_dict[AttachmentFileName] = True
                    else:
                        response_dict[AttachmentFileName] = False
            else:
                response_dict[AttachmentFileName] = "File type is not allowed"

        hap["response_dict"]=response_dict
        return Response(hap)