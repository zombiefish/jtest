from django.db import connection
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView
from django.db.models import Q
from apps.common_utils.views.validate_permission import RolePermission

# from apps.incident_management.models import GetAllPreopsMaster
from apps.general_action.models import Submissionheader

from apps.general_action.models import PreopSubmissionHeader

from django.db.models import Prefetch
from apps.person.models import Person
from apps.sofvie_user_authorization.api.permissions import SofviePermission


def person_fullname(queryset_result, data_key, *args, **kwargs):
    ids = [dictionary[data_key] for
           dictionary in queryset_result]
    person_map = {obj.per_id: obj.full_name for obj in
                  Person.objects.filter(per_id__in=ids)}
    result = []
    for entry in queryset_result:

        new_entry = entry
        if entry[data_key] == 0:
            new_entry['person_name'] = ""
        else:
            if entry[data_key]:
                new_entry['person_name'] = person_map[entry[data_key]]
            else:
                new_entry['person_name'] = ""

        result.append(new_entry)
    return result


class GetAllPreops(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewIncidents.value,)

    def get(self, request):
        queryset = PreopSubmissionHeader.objects.select_related(
            "preop_submission_header").filter(Q(psh_submissionheader_id__isarchived=False) | Q(psh_submissionheader_id__isarchived__isnull=True)).select_related(
            "equipment_psh_pet_id").values(
            "psh_pet_id__pet_equipment_identifier",
            "psh_submissionheader_id",
            "psh_submissionheader_id__submittedby_supervisorid",
            "psh_submissionheader_id__formsubmissiondate",
        ).order_by("-psh_submissionheader_id__formsubmissiondate")
        result_of_first_queryset = person_fullname(queryset, 'psh_submissionheader_id__submittedby_supervisorid')

        return Response(result_of_first_queryset)


class GetAllPretasks(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewIncidents.value,)

    def get(self, request):
        queryset = Submissionheader.objects.filter(Q(isarchived=False) |  Q(isarchived__isnull=True), formdescriptionid=1392).values(
            'id', 'formsubmissiondate', 'workplace', 'submittedby_supervisorid'
        ).order_by("-formsubmissiondate")
        result_of_first_queryset = person_fullname(queryset, 'submittedby_supervisorid')
                
        return Response(result_of_first_queryset)
