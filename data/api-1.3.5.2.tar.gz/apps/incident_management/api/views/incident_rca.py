from django.db import connection
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from django.db.models.functions import Concat
from django.db.models import Value, Subquery, OuterRef, CharField, F
from rest_framework.parsers import JSONParser
from apps.common_utils.models import CommonReviewer
from apps.common_utils.views.common_global_functions import get_employee_position, ltr_subquery
from apps.common_utils.views.validate_permission import RolePermission
from apps.incident_management.api.utlity_function import dictfetchall
from apps.language.models import Language, LanguageTranslation
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from apps.employee.models import  Employee
from apps.incident_management.api.views.incidents_helper_function import update_incident

def ValidateRCA(item):
    if  item['PreliminaryType'] == '' or item['PotentialLoss'] == '' or item['ActualType'] == '' or item['IncidentType'] == '' or item['EventDetails'] == '' or  item['InvestigationFindings'] == '' :
        return False
    
    if item['EmployeesInvolved'] == '':
        return False

    if len(item['Causes']) == 0:
        return False
    
    if len(item['Causes']) > 0:
        # // If there are any basic/immediate causes, they will be the first element in the list.
        selCause = item['Causes'][0]      
        if selCause['BasicCauseCategory'] == '' or selCause['BasicCauseType'] == '' or selCause['ImmediateCauseType'] == '' or selCause['ImmediateCause'] == '':
            return False

    return True


class GetIncidentRCAByIncidentId(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)
    """ Response for the All  """
    def post(self, request):
        _incidentId = request.data['incidentId']
        person_id = self.request.user.user_per_id_id
        _lang = UserProfile.objects.get(upr_per=person_id).upr_language
    
        with connection.cursor() as cursor:
            cursor.execute("CALL get_root_cause_analysis_by_incident_id(%s,%s,%s)", ([_incidentId], [_lang], [person_id]))
            row = dictfetchall(cursor)
            for item in row:
                with connection.cursor() as cursor:
                    _RootCauseAnalysisID = int(item['ID'])
                    cursor.execute("CALL get_rca_causes_by_rca_id(%s,%s)", ([_RootCauseAnalysisID], [_lang]))
                    submission = dictfetchall(cursor)
                    item["Causes"] = submission
                    item["status"] = 'complete' if ValidateRCA(item) else 'incomplete'
        return Response(row)

class GetRootCauseAnalysisEdit_RootCauseId(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)
    parser_classes = [JSONParser]
    """ Response for the All  """
    def post(self, request):
        _rootCauseId = request.data['rootCauseId']
        rcaForm ={}

        with connection.cursor() as cursor:

            cursor.execute("call get_root_cause_id(%s)", (_rootCauseId,))

            rca = dictfetchall(cursor)
            if rca == []:
                rcaForm["root_cause_analysis"] ={}
            else:
                rcaForm["root_cause_analysis"] = dict(rca[0])

            cursor.execute("call get_root_cause_analysis_id(%s)", (_rootCauseId,))
            emp_invs = dictfetchall(cursor)
            employees_involved = []
           

            if emp_invs == []:
                rcaForm["employees_involved"] = {}
            else:
                try: 
                    employees_involved = list(map(lambda x : x['EmployeeID'], emp_invs))
                    rcaForm["employees_involved"] = employees_involved
                except Exception as e:
                    print('error - ',str(e))
                

            cursor.execute("call get_root_cause_analysis_immediate_cause(%s)", (_rootCauseId,))
            immediate_causes = dictfetchall(cursor)
            if immediate_causes == []:
                rcaForm["immediate_causes"] = {}
            else:
                rcaForm["immediate_causes"] = immediate_causes


            cursor.execute("call get_root_cause_analysis_basic_cause(%s)", (_rootCauseId,))
            basic_causes = dictfetchall(cursor)
            if basic_causes == []:
                rcaForm["basic_causes"] = {}
            else:
                rcaForm["basic_causes"] = basic_causes
          
        return Response(rcaForm)


class UpsertRootCauseAnalysis(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)
    """ Request to insert-update into four different table for the rca  """
    def post(self, request):
        if 'root_cause_analysis' not in request.data:
            return Response({'error': 'Must pass the `root_cause_analysis`'},
                            status=status.HTTP_400_BAD_REQUEST)


        # parse the json request object
        root_cause_analysis = request.data['root_cause_analysis']
        employees_involved = request.data['employees_involved']
        employees_involved = employees_involved if employees_involved else []
        immediate_causes = request.data['immediate_causes']
        basic_causes = request.data['basic_causes']

        request_user = self.request.user
        person = request_user.user_per_id
        
        
        # # declare and assign to the variables
        _IncidentID = root_cause_analysis['IncidentID']
        _PreliminaryTypeID =  root_cause_analysis['PreliminaryTypeID']
        _PotentialLossID = root_cause_analysis['PotentialLossID']
        _ActualTypeID = root_cause_analysis['ActualTypeID']
        _IncidentTypeID = root_cause_analysis['IncidentTypeID']
        _PreliminaryIncidentTypeDetailID = root_cause_analysis['PreliminaryIncidentTypeDetailID']
        _PreliminaryIncidentTypeCategoryID = root_cause_analysis['PreliminaryIncidentTypeCategoryID']
        _ActualIncidentTypeCategoryID = root_cause_analysis['ActualIncidentTypeCategoryID']
        _ActualIncidentTypeDetailID = root_cause_analysis['ActualIncidentTypeDetailID']
        _EventDetails = root_cause_analysis['EventDetails']
        _InvestigationFindings = root_cause_analysis['InvestigationFindings']
        _SubmissionDate = root_cause_analysis['SubmissionDate']
        _SubmittedBy = root_cause_analysis['SubmittedBy']
        _LastUpdated = root_cause_analysis['LastUpdated']

        _LastUpdatedBy = person.per_id
        
        ID = root_cause_analysis['ID']
        ErrorMsg = ""

        cursor = connection.cursor()
        # # Insert into root cause analysis
        try:
            with connection.cursor() as cursor:
                if str(ID) == 'None':
                    args = (_IncidentID,_PreliminaryTypeID,_PotentialLossID,_ActualTypeID,_IncidentTypeID,_PreliminaryIncidentTypeDetailID,
                            _PreliminaryIncidentTypeCategoryID,_ActualIncidentTypeCategoryID,_ActualIncidentTypeDetailID,_EventDetails,
                            _InvestigationFindings,_SubmissionDate,_SubmittedBy)
                    result_args = cursor.execute('call sp_InsertRootCauseAnalysis(@ID,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,@ErrorMsg)', (args))
                    cursor.execute('select @ID as value')
                    ID = cursor.fetchone()[0] # convert tuple or take a single value from the tuple instead of go with full tuple
                else:
                    args = (ID,_IncidentID,_PreliminaryTypeID,_PotentialLossID,_ActualTypeID,_IncidentTypeID,_PreliminaryIncidentTypeDetailID,
                            _PreliminaryIncidentTypeCategoryID,_ActualIncidentTypeCategoryID,_ActualIncidentTypeDetailID,_EventDetails,
                            _InvestigationFindings,_SubmittedBy,_LastUpdated,_LastUpdatedBy)
                    result_args = cursor.execute('call sp_UpdateRootCauseAnalysis(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,@ErrorMsg)', (args))
                    cursor.execute('select @ErrorMsg as value')
                    ErrorMsg = cursor.fetchone()
        except Exception as e:
            print('error - ',str(e))

        rootCauseAnalysisID = ID
        employeeIDs = ','.join(str(emp_id) for emp_id in employees_involved)
        try:
            # employees involved for root cause analysis
            with connection.cursor() as cursor:
                cursor.execute( "CALL sp_UpsertEmployeesInvolvedForRootCauseAnalysis(%s,%s)", ([rootCauseAnalysisID],[employeeIDs]))
        except Exception as e:
            print('error - ',str(e))

        # Save immediate causes -- sp_UpsertImmediateCausesForRootCauseAnalysis
        
        if immediate_causes:
            ic = []
            for imCauses in immediate_causes:
                try:
                    _rca_ImmediateCauseID = imCauses['ID']
                    _CauseType = imCauses['CauseType']
                    _Cause = imCauses['Cause']
                    _Comments = imCauses['Comments']

                    with connection.cursor() as cursor:
                        cursor.execute("call sp_UpsertImmediateCausesForRootCauseAnalysis(@rca_id,%s,%s,%s,%s,%s)", (_rca_ImmediateCauseID, rootCauseAnalysisID, _CauseType, _Cause, _Comments))
                        cursor.execute('select @rca_id as value')
                        ic_ID = cursor.fetchone()[0]
                        ic.append(ic_ID)
                except Exception as e:
                    print('error - ',str(e))


        # Save basic causes -- sp_UpsertBasicCauseForRootCauseAnalysis
        if basic_causes:
            bc = []
            for bCauses in basic_causes:
                try:
                    _rca_BasicCauseID = bCauses['ID']
                    _CauseCategory = bCauses['CauseCategory']
                    _CauseType = bCauses['CauseType']
                    _Cause = bCauses['Cause']
                    _Comments = bCauses['Comments']

                    with connection.cursor() as cursor:
                        cursor.execute("call sp_UpsertBasicCauseForRootCauseAnalysis(@rca_id,%s,%s,%s,%s,%s,%s)",
                                    (_rca_BasicCauseID,rootCauseAnalysisID,_CauseType,_CauseCategory,_Cause,_Comments))
                        cursor.execute('select @rca_id as value')
                        bc_ID = cursor.fetchone()[0]
                        bc.append(bc_ID)
                except Exception as e:
                    print('error - ',str(e))
        if _IncidentID:
            update_incident(_IncidentID, person.per_id)       
        return Response({'Received data': request.data,"rca_id": rootCauseAnalysisID,"ic":ic,"bc":bc}, status=status.HTTP_200_OK)


class GetRcaReviewersList(APIView):

    def get(self, request, rca_id):
        
        self.person_instance = self.request.user.user_per_id
        self.lng_name = UserProfile.objects.get(upr_per = self.person_instance).upr_language
        self.lng_id = Language.objects.get(lng_name = self.lng_name).lng_id

        rca_reviwers_list = CommonReviewer.objects.filter(
            crw_rca_id = rca_id,
            crw_enable = True
        ).annotate(
            name = Concat('crw_per__per_last_name', Value(', '), 'crw_per__per_first_name', Value(' '), 'crw_per__per_middle_name', output_field= CharField()),
            position_tag = Subquery(
                RefListDetail.objects.filter(
                    rld_id = OuterRef('crw_position')                    
                ).values('rld_name')[:1]
            ),
            position_tag_type = Subquery(
                RefListDetail.objects.filter(
                    rld_id = OuterRef('crw_position')                    
                ).values('rld_tag_type')[:1]
            )            
        ).values(
            'name',
            'position_tag',
            'position_tag_type'
        )

        rca_reviwers_list = rca_reviwers_list.annotate(
            pos = ltr_subquery(self, 'position_tag', 'position_tag_type'),
            reviewed_date = F('crw_created_date')
        ).values(
            'name',
            'pos',
            'reviewed_date'
        )
        
        return Response(rca_reviwers_list)
class ReviewRootCauseAnalysis(APIView):
    
    permission_classes = [SofviePermission]

    def post(self, request):

        try:

            self.person_instance = self.request.user.user_per_id
            self.rca_id = request.data.pop('rca_id', None)

            if self.rca_id:
                self.person_position = get_employee_position(self.person_instance.per_id)

                # check if selected Incident Analysis is already reviewed
                check_existing_review = CommonReviewer.objects.filter(
                    crw_rca_id=self.rca_id,
                    crw_per=self.person_instance, 
                    crw_is_reviewed=True,
                    crw_enable = True
                ).exists()

                if not check_existing_review:
                    CommonReviewer.objects.create(   
                        crw_rca_id=self.rca_id,
                        crw_per=self.person_instance,
                        crw_position=self.person_position,
                        crw_is_reviewed=True,
                        crw_created_by_per=self.person_instance
                    )

                return Response({"message": "Successfully reviewed selected Incidnet Analysis"}, status= status.HTTP_201_CREATED)
            else:
                raise Exception('No incident Analysis is selected')
            
        except Exception as e:
            return Response({"message": f"{str(e)}"}, status= status.HTTP_400_BAD_REQUEST)
