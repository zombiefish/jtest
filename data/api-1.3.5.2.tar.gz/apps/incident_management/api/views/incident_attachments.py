from datetime import datetime
from django.db import connection
import os
from django.template.defaultfilters import slugify
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.incident_management.api.utlity_function import dictfetchall
from django.conf import settings
from apps.common_utils.views.validate_permission import RolePermission, \
    PersonAccessPermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.incident_management.api.views.incidents_helper_function import update_incident

class GetIncidentAttachments(APIView):    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewIncidents.value,)
    """ Getting Submission attachments for Incidents  """ 

    def post(self, request):
        _incidentId = request.data['incidentId']
        with connection.cursor() as cursor:
            cursor.execute(
                "select * from IncidentAttachments where IncidentID = %s",
                ([_incidentId]))
            row = dictfetchall(cursor)
        return Response(row)


class DeleteIncidentAttachments(APIView):    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)
    """ Deleting a Submission Attachment  """

    def post(self, request):
        # Access Role Permission - Atleast the ROLE having "Can Manage Incidents"
        # IsAccessPermits = PersonAccessPermission(self,
        #                                          RolePermission.CanManageIncidents)
        # if IsAccessPermits == 0:
        #     return Response({
        #                         'accessMsg': 'Access denied - Do not have access to manage incidents'})

        _id = request.data['id']
        # print(_id)
        with connection.cursor() as cursor:
            cursor.execute(
                "call get_incident_attachment_filename(%s)",([_id]))
            rec = dictfetchall(cursor)
            path = settings.FILES_DIR
            fileDir = os.path.join(path, rec[0]['IncidentNumber'])
            filePath = os.path.join(fileDir, rec[0]['FileName'])
            if os.path.exists(filePath):
                os.remove(filePath)
            else:
                print("The file does not exist")

        with connection.cursor() as cursor:
            cursor.execute("call delete_incident_attachments(%s)", ([_id]))
        return Response("Deleted")


class RenameIncidentAttachments(APIView):    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)
    """ Getting Submission attachments for Incidents  """

    def post(self, request):
        # Access Role Permission - Atleast the ROLE having "Can Manage Incidents"
        # Isexists = PersonAccessPermission(self,
        #                                   RolePermission.CanManageIncidents)
        # # print(Isexists)
        # if Isexists == 0:
        #     return Response({
        #                         'accessMsg': 'Access denied - do not have access to manage incidents'})
        person = self.request.user.user_per_id
        incidentNumber = request.data['IncidentNumber']
        attId = request.data['ID']
        incidentId = request.data['IncidentID']
        newFileName = request.data['rawFileName']
        splt = newFileName.split('.')
        fileType = splt[-1].lower()
        newFileName = splt[0]
        original_name = slugify(splt[0])
        timestamp = datetime.now().strftime('%Y%m-%d%H-%M%S')
        newFileName = f"{original_name}_{timestamp}.{fileType}"

        path = settings.FILES_DIR
        fileDir = os.path.join(path, incidentNumber)
        oldFile = os.path.join(fileDir, request.data['FileName'])
        newFile = os.path.join(fileDir, newFileName)
        os.rename(oldFile, newFile)
        with connection.cursor() as cursor:
            cursor.execute("call rename_incident_attachment(%s,%s)",
                           ([attId], [newFileName]))
        if incidentId:
            update_incident(incidentId, person.per_id)
        return Response("Success")
