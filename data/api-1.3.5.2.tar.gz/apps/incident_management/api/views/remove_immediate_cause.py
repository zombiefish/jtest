from django.db import connection
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class RemoveImmediateCause(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)
    parser_classes = [JSONParser]

    def post(self, request):
        primary_id = request.data['primary_id']

        if type(request.data['primary_id']) != int:
            return Response({'error': 'Please provide int `primary_id`'})
        ErrorMsg = ''
        args = [primary_id, ErrorMsg]

        with connection.cursor() as cursor:
            cursor.callproc('sp_removeRootCauseAnalysis_ImmediateCause',
                            args, )

        return Response('Done')
