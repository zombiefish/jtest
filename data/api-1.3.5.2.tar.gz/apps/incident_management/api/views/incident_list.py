from datetime import datetime

from django.db import connection
from rest_framework.parsers import JSONParser
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.user_settings_profile.models import UserProfile
from apps.language.models import Language
from apps.common_utils.views.validate_permission import RolePermission
from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission, \
    SofvieBasePermissionMixin
from apps.employee.models import  Employee
from apps.employee.helper_function_user_visibility import helperEmployeeJobs, helperEmployeeSites

class IncidentListView(APIView, SofvieBasePermissionMixin):    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewIncidents.value,)

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        person_instance = self.request.user.user_per_id
        user_lang = UserProfile.objects.get(upr_per = person_instance).upr_language
        lang_id = Language.objects.get(lng_name=user_lang).lng_id
        emp_object = Employee.objects.filter(emp_per_id = person_id).values('emp_per_id', 'emp_data_visibility')
        data_visibility_type = emp_object[0]['emp_data_visibility']

        filterSelected = request.data['filter']
        with connection.cursor() as cursor:

            if filterSelected == 'Person':
                # displays open incidents and created by the current user since the beginning of time

                # start date
                startDate = '2000-01-01'
                endDate = datetime.now().strftime('%Y-%m-%d')
                cursor.execute("call get_incident_list_by_person(%s,%s,%s,%s)"
                               , (startDate,
                                  endDate,
                                  person_id, user_lang,))

            elif filterSelected == 'Site':
                # displays the open incidents filter by person's sites
                startDate = '2000-01-01'
                endDate = datetime.now().strftime('%Y-%m-%d')

                if data_visibility_type != 'all':
                    cursor.execute("call get_incident_list_by_person_site(%s,%s,%s,%s)"
                                , (startDate,
                                    endDate,
                                    person_id,user_lang,))
                else:
                    cursor.execute("call get_incident_list_by_person_site_all(%s,%s,%s,%s)"
                                , (startDate,
                                    endDate,
                                    person_id,user_lang,))
                    
                    
                count = cursor.rowcount

            elif filterSelected == 'Company':
                # displays the open incidents filter by person's sites
                startDate = '2000-01-01'
                endDate = datetime.now().strftime('%Y-%m-%d')
                cursor.execute("call get_incident_list_by_company_date(%s,%s,%s,%s)"
                               , (startDate,
                                  endDate,
                                  person_id,user_lang,))
                count = cursor.rowcount
            
            elif filterSelected == 'homepage':
                # displays the open incidents filter for redirect from homepage

                get_jobs, data_user_visibility = helperEmployeeJobs(self, person_id)
                per_jobs = [job['rld_id'] for job in get_jobs] 
                
                get_sites, data_user_visibility = helperEmployeeSites(self, person_id)
                per_sites = [site['rld_id'] for site in get_sites]

                sites = request.data.get('site_ids', '')
                jobs = request.data.get('job_ids', '')

                selected_site_ids = list(map(int, sites.split(",")))
                selected_job_ids = list(map(int, jobs.split(",")))

                selected_site_ids = list(set(selected_site_ids).intersection(per_sites))
                selected_job_ids = list(set(selected_job_ids).intersection(per_jobs))

                selected_site_ids = ",".join(str(site) for site in selected_site_ids)
                selected_job_ids = ",".join(str(job) for job in selected_job_ids)

                cursor.execute("call get_open_incident_list_for_homepage_redirect(%s,%s,%s)", (selected_site_ids,selected_job_ids,lang_id))                    
                count = cursor.rowcount
            else:

                # display as normal - no date or person restrictions
                cursor.execute("call get_incident_list_by_date(%s,%s,%s,%s)"
                               , (request.data['startDate'],
                                  request.data['endDate'], person_id, user_lang) ,)
                count = cursor.rowcount

            row = dictfetchall(cursor)

            for item in row:
                with connection.cursor() as cursor:
                    id = item['ID']
                    cursor.execute("call get_incident_list_by_incident_id(%s)", (id,))
                    allRows = dictfetchall(cursor)
                    submissions = []
                    for eachRow in allRows:
                        with connection.cursor() as cursor:

                            SubmissionHeaderID = eachRow['SubmissionHeaderID']
                            cursor.execute("call get_incident_list_by_submission_header_id(%s)", (SubmissionHeaderID,))
                            submission = dictfetchall(cursor)
                            for formDetail in submission:
                                with connection.cursor() as cursor:
                                    FormDescriptionID = formDetail[
                                        'FormDescriptionID']
                                    cursor.execute("call get_incident_list_by_form_description_id(%s)", (FormDescriptionID,))
                                    form = dictfetchall(cursor)

                            submission[0]["IncidentNumber"] = item[
                                "IncidentNumber"]
                            submission[0]["FormName"] = form[0]["FormName"]
                            submission[0]["FormID"] = form[0]["FormID"]
                            submissions.append(submission[0])
                    item["submissions"] = submissions
        return Response({"count": len(row), "data": row})


class GetIncidentFormSubmissionsByHeaderIds(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewIncidents.value,)
    parser_classes = [JSONParser]
    """ Response for the All  """

    def post(self, request):

        formDescriptionId = request.data['formId']
        person_instance = self.request.user.user_per_id
        user_lang = UserProfile.objects.get(upr_per = person_instance).upr_language
        submissionHeaderIds = request.data['submissionIds']
        per_Id = self.request.user.user_per_id_id

        commaSep_SubHdr_Ids = ','.join(
            [str(elem) for elem in submissionHeaderIds])
        with connection.cursor() as cursor:
            cursor.execute(
                "call get_incident_form_submissions_by_headerids(%s,%s,%s,%s)",
                ([formDescriptionId], [commaSep_SubHdr_Ids], [per_Id], [user_lang]))
            row = dictfetchall(cursor)
        return Response(row)
