from urllib import response
from django.db import connection
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Prefetch, F, Subquery, OuterRef
from django.db.models.functions import Substr
from apps.incident_management.api.utlity_function import dictfetchall
from apps.common_utils.views.validate_permission import PersonAccessPermission, RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission, \
    SofvieBasePermissionMixin

from apps.general_action.models import Formdescription, SubmissionSignoff, Submissionheader, Reports
from apps.employee.helper_function_user_visibility import helperEmployeeSites, helperEmployeeJobs
from django.db.models import Prefetch, Q, F, Case, When, Value, CharField, Count, functions, Subquery
from django.db.models.functions import Concat
from apps.incident_management.models import Incidentsubmissions


class IncidentsCountByHeaderId(APIView, SofvieBasePermissionMixin):    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.ArchiveSubmissions.value,)
    def post(self, request):
        sub_ids = request.data
        incident_count = 0
        archive_ids = []
        not_archive_ids = []

        for subid in sub_ids:
            incidents_exists = Incidentsubmissions.objects.filter(submissionheaderid = subid).values("id")
            if incidents_exists:
                incident_count = Incidentsubmissions.objects.filter(
                incidentid__id__in=Subquery(Incidentsubmissions.objects.filter(submissionheaderid = subid).values("incidentid")),
                submissionheaderid__formdescriptionid__in=[1331, 1338, 1329]).count()
                if(incident_count>1):
                    archive_ids.append(subid)
                else:
                    not_archive_ids.append(subid)
            else:
                archive_ids.append(subid)

        return Response({"archive_ids":archive_ids, "not_archive_ids":not_archive_ids})