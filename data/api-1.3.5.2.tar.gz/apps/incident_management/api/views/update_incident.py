from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from datetime import datetime

from apps.incident_management.api.utlity_function import dictfetchall
from apps.common_utils.views.validate_permission import RolePermission
from apps.incident_management.models import Incident_Signoffs, Incidents, Incidentsubmissions
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.incident_management.api.views.incidents_helper_function import update_incident

class UpdateIncident(APIView):    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)
    def put(self, request):
        person_id = self.request.user.user_per_id_id
        incident_id = request.data['incident_id']
        try:
            update_incident(incident_id, person_id)
            return Response({"message":'Incident updated'}, status=status.HTTP_200_OK)
        except:
            raise ValidationError("Error on updating incident")



        
            