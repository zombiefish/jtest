from datetime import datetime, timedelta
from decouple import config
import os
from io import BytesIO
import threading
from datetime import datetime
from django.db import connection
from django.http import HttpResponse
from django.template.loader import get_template
from django.http import FileResponse
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.utils import timezone
from rest_framework import serializers
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.get_logo import getClientLogo
from apps.language.models import Language, LanguageTranslation
from apps.user_settings_profile.models import UserProfile
from xhtml2pdf import pisa
from apps.common_utils.views.validate_permission import RolePermission
from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.common_utils.views.get_translations import get_translation
from apps.incident_management.api.views.incidents_helper_function import update_incident

def render_to_pdf(context_dict={}):
    template = get_template("training_record_template.html")
    html = template.render(context_dict)
    result = BytesIO()

    pdf = pisa.pisaDocument(BytesIO(html.encode("UTF-8", "ignore")), result)
    if not pdf.err:
        return result.getvalue()
    return None


def storeLocalfile(filePath, fPath, tmpfile):
    if os.path.exists(fPath) == False:
        os.mkdir(fPath)
    with open(filePath, 'wb') as dest:
        #for chunk in tmpfile.chunks():
        dest.write(tmpfile)


class ObtainTrainingRecords(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)

    def post(self, request, *args, **kwargs):
        person_id = self.request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per_id=person_id).upr_language
        lng_id = Language.objects.get(lng_name=lng_name) 
        ltr_ids = [2587, 143, 1260, 1326, 1262, 2589, 1930, 8613, 1034,
                   1265, 1169, 1925, 1261, 8699, 1929, 1295, 3494, 8865]
        finalTranslations = get_translation(ltr_ids, lng_id)
        today_stamp = datetime.now().strftime('%Y-%m-%d')
        today = datetime.now()
        about_stamp = today + timedelta(days=30)
        about_stamp = about_stamp.strftime('%Y-%m-%d')
        created_by_modified_by = self.request.user.user_per_id_id
        incidentNumber = request.data['incidentNumber']
        incidentId = request.data['incidentId']
        employees = request.data['employees']
        datestamp = datetime.now().strftime('%Y-%m-%d')
        for emp in employees:
            with connection.cursor() as cursor:
                cursor.execute("call get_training_records(%s,%s)", ([emp,lng_name]))
                row = dictfetchall(cursor)

            # check record status
            for record in row:
                if record['training_institution_code'] is None:
                    record['training_institution_code'] = ''
                if record['etr_expiry_date'] is None:
                    record['etr_expiry_date'] = ''
                if record['training_status_tag'] == 2045 or record['training_status_tag'] is None:  # complete
                    # if not expired:
                    if record['etr_expiry_date'] and record['etr_expiry_date'].strftime('%Y-%m-%d') < today_stamp:
                        record['etr_expiry_date'] = "<span class='expired'>" + record['etr_expiry_date'].strftime('%Y-%m-%d') + "</span>"
                        record['training_status_name'] = "<span class='expired'>" + LanguageTranslation.objects.get(ltr_tag=3494, ltr_lng_id=lng_id, ltr_tag_type=1).ltr_text + "</span>"  #  "ACTIVE"

                    elif record['etr_expiry_date'] and record['etr_expiry_date'].strftime('%Y-%m-%d') < about_stamp:
                        record['etr_expiry_date'] = "<span class='about-to-expire'>" + record['etr_expiry_date'].strftime('%Y-%m-%d') + "</span>"
                        record['training_status_name'] = "<span class='about-to-expire'>" + LanguageTranslation.objects.get(ltr_tag=8865, ltr_lng_id=lng_id, ltr_tag_type=1).ltr_text + "</span>"  #  "ACTIVE"

                    else:
                        record['training_status_name'] = LanguageTranslation.objects.get(ltr_tag=2045, ltr_lng_id=lng_id, ltr_tag_type=1).ltr_text  # 'COMPLETE'

            context = { 
                "date": datestamp,
                "person": row[0]['per_full_name'],
                "emp_id": row[0]['emp_employee_number'],
                "data":  row,
                'translations': finalTranslations,
                'logolocation': getClientLogo() ,
            }

            path = settings.FILES_DIR
            fileDir = os.path.join(path, incidentNumber)
            timestamp = datetime.now().strftime('%Y%m-%d%H-%M%S')
            filename = "%s_%s_%s.%s" % (row[0]['per_first_name'], row[0]['per_last_name'], timestamp, "pdf")
            # Actually Create the PDF
            pdf = render_to_pdf(context)

            filePath = os.path.join(fileDir, filename)

            file_args = (filePath, fileDir, pdf)
            file_thread = threading.Thread(target=storeLocalfile, args=file_args)
            file_thread.start()
            file_thread.join()
            with connection.cursor() as cursor:
                cursor.execute("call sp_insert_incident_attachments("
                    "%s,%s,%s,%s,%s)", (incidentId,filename, '.pdf',
                                    '1034', created_by_modified_by))
        if incidentId:
            update_incident(incidentId, person_id)
        return Response({"requested_data": "ok", "etr_id": "ok"})