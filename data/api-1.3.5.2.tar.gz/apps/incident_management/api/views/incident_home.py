from django.db import connection
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class GetOpenIncidentCountByPersonSite(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)
    """ Response for the All  """
    def post(self, request):
        _startDate  = request.data['startDate']    
        _endDate = request.data['endDate']    
        _per_id  = request.data['person']    
               
        with connection.cursor() as cursor:
            cursor.execute("call get_incidents_count_by_emp_site(%s,%s,%s)", ([_startDate],[_endDate],[_per_id]))             
            row = dictfetchall(cursor)
        return Response(row) 



class GetIncidentBreakDownByPersonDate(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)
    """ Response for the All  """
    def post(self, request):
        _startDate  = request.data['startDate']    
        _endDate = request.data['endDate']    
        _per_id  = request.data['person']    
               
        with connection.cursor() as cursor:
            cursor.execute("call get_incident_breakdown_by_date_person(%s,%s,%s)", ([_startDate],[_endDate],[_per_id]))             
            row = dictfetchall(cursor)
        return Response(row) 
