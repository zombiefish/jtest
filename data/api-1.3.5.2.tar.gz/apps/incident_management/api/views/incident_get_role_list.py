from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.sofvie_user_authorization.models import AuthRolePermissionMappingSofive, AuthRoleSofvie
from apps.user_settings_profile.models import UserProfile
from django.db.models import Subquery, OuterRef

from apps.language.models import LanguageTranslation, Language

class IncidentGetRolesList(APIView):
    # Basic Access
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)
    def get(self, request):
        person = self.request.user.user_per_id
        language = UserProfile.objects.get(upr_per=person).upr_language
        lng_id = Language.objects.get(lng_name=language).lng_id

        # get role_ids having Can Sign Off Incident permission
        role_ids = AuthRolePermissionMappingSofive.objects.filter(
            arp_ape_id__ape_name='Can Sign Off Incident', arp_enable = True
        ).values_list('arp_aro_id', flat=True).distinct()

        queryset = AuthRoleSofvie.objects.filter(
            aro_enable=1,
            aro_id__in=role_ids,
            ).annotate(
                role_name = Subquery(
                LanguageTranslation.objects.filter(
                    ltr_tag=OuterRef('aro_name'), 
                    ltr_tag_type = OuterRef('aro_tag_type'), 
                    ltr_lng_id = lng_id
                    ).values('ltr_text')[:1])
            ).values('aro_id', 'role_name', 'aro_signoff_default', 'aro_tag_type').order_by('role_name')

        return Response(queryset)