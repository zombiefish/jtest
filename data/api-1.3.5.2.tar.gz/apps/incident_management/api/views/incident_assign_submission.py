from django.db import connection
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.utils import json
from rest_framework.views import APIView
from rest_framework.parsers import JSONParser
from apps.incident_management.api.utlity_function import dictfetchall
from apps.common_utils.views.validate_permission import RolePermission, PersonAccessPermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class AssignSubmissionToIncident(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)
    parser_classes = [JSONParser]

    def post(self, request):

         # Access Role Permission - Atleast the ROLE having "Can Manage Incidents"
        # IsAccessPermits = PersonAccessPermission(self, RolePermission.CanManageIncidents)
        # if IsAccessPermits == 0:
        #     return Response({'accessMsg': 'Access denied - Do not have access to Manage Incidents'})
            

        # temp = request.data
        # print(temp)

        if 'incidentId' not in request.data:
            return Response({'error': 'Must pass `incidentId`'},
                            status=status.HTTP_400_BAD_REQUEST)
        elif type(request.data['incidentId']) != int:
            return Response({'error': '`incidentId` must be an integer'},
                            status=status.HTTP_400_BAD_REQUEST)

        if 'submissions' not in request.data:
            return Response({'error': 'Must pass `submissions`'}, status=status.HTTP_400_BAD_REQUEST)
        elif type(request.data['submissions']) != list:
            return Response({'error': '`submissions` must be list '},
                            status=status.HTTP_400_BAD_REQUEST)
        elif len(request.data['submissions']) == 0:
            return Response({'error': '`submissions` list must not be empty '},
                            status=status.HTTP_400_BAD_REQUEST)

        incident_id = request.data['incidentId']

        submissions = request.data['submissions']

        for submission in submissions:
            try:
                with connection.cursor() as cursor:
                    cursor.execute("call sp_AssignSubmissionsToIncident(%s,%s)",
                                   (incident_id, submission))
            except Exception as e:
                print(str(e))

        # return Response({'received data': request.data})
        return Response({'received data': request.data})
