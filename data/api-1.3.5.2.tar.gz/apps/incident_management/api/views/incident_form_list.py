from django.db import connection
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class IncidentFormListView(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewIncidents.value,)

    def get(self, request, lang):
        language = lang
        with connection.cursor() as cursor:
            cursor.execute("call get_incident_form_list(%s)",[(language),])
            row = dictfetchall(cursor)

        return Response(row)