from datetime import datetime
from io import BytesIO
import os
from django.http.response import HttpResponse
from django.template.defaultfilters import slugify

from django.template.loader import get_template
from django.conf import settings
from xhtml2pdf import pisa
from decouple import config

from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.language.models import Language, LanguageCategoryType, LanguageTranslation
from apps.imageupload.api.views.views import UplaodImageView


def modify_hazard_actions(self, data, fileTypeKey, lng_id):   
    '''
    hazard_type - rld_id to translate text
    hazard_identification - rld_id to translate text
    potential_risk - rld_id to translate text
    immediate_action_type - rld_id to translate text
    action_type - rld_id to translate text
    completed_action_type - rld_id to translate text
    sha_created_by_per - full name
    '''    
    for item in data:        
        item['sha_created_by_per'] = Person.objects.get(per_id=item['sha_created_by_per']).full_name

        ref_trans_list = ['hazard_type', 'hazard_identification', 'potential_risk', 'immediate_action_type', 'action_type', 'completed_action_type']

        for each in ref_trans_list:
            if item[each]:
                get_trans= RefListDetail.objects.get(rld_id = item[each])
                item[each] = LanguageTranslation.objects.filter(
                    ltr_tag = get_trans.rld_name, 
                    ltr_tag_type = get_trans.rld_tag_type, 
                    ltr_lng = lng_id).values_list('ltr_text', flat=True)[0]
        
        followup_attachments = []
        initial_attachments = []
        for attachment in item['attachments']:
            if(attachment[fileTypeKey]=='INITIAL'):
                initial_attachments.append(attachment)
            elif(attachment[fileTypeKey]=='FOLLOWUP'):
                followup_attachments.append(attachment)                               
            attachment['file_path'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'), attachment['attachmentfilename'])            
        item.pop('attachments')
        item['initial_attachments']=initial_attachments
        item['followup_attachments']=followup_attachments
    return data

def modify_general_actions(self, data, fileTypeKey, lng_id):    

    '''
    job - rld_id to text
    level - rld_id to text
    sga_action_by_who_per_id - full name
    sga_action_type_rld_id - rld_id to translated text
    sga_completed_action_type_rld_id - rld_id to translated text
    sga_completed_action_by_who_per - full name
    sga_created_by_per - full name
    ''' 
    for item in data:
        if item['sga_created_by_per']:  
            item['sga_created_by_per'] = Person.objects.get(per_id=item['sga_created_by_per']).full_name

        ref_trans_list = ['sga_action_type_rld_id', 'sga_completed_action_type_rld_id', 'job', 'level']

        for each in ref_trans_list:
            if item[each]:
                get_trans= RefListDetail.objects.get(rld_id = item[each])
                item[each] = LanguageTranslation.objects.filter(
                    ltr_tag = get_trans.rld_name, 
                    ltr_tag_type = get_trans.rld_tag_type, 
                    ltr_lng = lng_id).values_list('ltr_text', flat=True)[0]

        followup_attachments = []
        initial_attachments = []
        for attachment in item['attachments']:
            if(attachment[fileTypeKey]=='INITIAL'):
                initial_attachments.append(attachment)
            elif(attachment[fileTypeKey]=='FOLLOWUP'):
                followup_attachments.append(attachment)            
            attachment['file_path'] = os.path.join('https://',config('EMAIL_REPORT_IMAGESURL'),'general_action', attachment['gaa_file_name'])
        item.pop('attachments')
        item['initial_attachments']=initial_attachments
        item['followup_attachments']=followup_attachments
    return data


def translate_measures(self, item, lng_id):    
    p_risk = ''
    r_risk = ''
    risk_category = ''
    get_trans_list = []
    for each in item:
        if each.endswith('preliminary_risk'):
            p_risk = each
        if each.endswith('residual_risk'):
            r_risk = each
        if each.endswith('_preliminary') or each.endswith('_residual') or each.endswith('_risk_category') or each.endswith('_severity_to_risk'):
            get_trans_list.append(each)

    if p_risk in item and item[p_risk]:
        item[p_risk] = LanguageTranslation.objects.get(ltr_tag = item[p_risk], ltr_tag_type = 1, ltr_lng = lng_id).ltr_text
    if r_risk in item and item[r_risk]:
        item[r_risk] = LanguageTranslation.objects.get(ltr_tag = item[r_risk], ltr_tag_type = 1, ltr_lng = lng_id).ltr_text


    for each in get_trans_list:
        if item[each] and type(item[each]) == int:
            get_trans = RefListDetail.objects.get(rld_id = item[each])
            item[each] = LanguageTranslation.objects.filter(
                ltr_tag = get_trans.rld_name, 
                ltr_tag_type = get_trans.rld_tag_type, 
                ltr_lng = lng_id).values_list('ltr_text', flat=True)[0]

    return item

def render_to_pdf(templatename,context_dict={}):
    template = get_template(templatename)
    html  = template.render(context_dict)
    result = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode("UTF-8", "ignore")), result)
    # pisa.CreatePDF()
    if not pdf.err:
        return result.getvalue()
    return None

def save_to_file(path, filename, pdf):
    
    if os.path.exists(path) == False:
            os.mkdir(path)
    fn = os.path.join(path, filename)
    with open(fn, 'wb+') as dest:
        dest.write(pdf)

def attach_pdf_to_incident(incident_id,incident_number, filename, created_by, modified_by, label):       
    filetype = '.pdf'
    # files = []
    # files.append(filename)
    UplaodImageView.add_document_to_library_from_system(UplaodImageView,label, incident_id, incident_number, filename, created_by, modified_by)

def get_html(self, template, data):    
    html = ''
    template = get_template(template)
    html = template.render(dict(data))
    return html    

def save_ra_attachment(pdf, created_by, report, incident_number):    
    timestamp = datetime.now().strftime('%Y%m-%d%H-%M%S')                        
    filename = f"{slugify(created_by)}_{timestamp}_{slugify(report)}.pdf"            
    filepath = os.path.join(settings.FILES_DIR, incident_number)
    save_to_file(filepath, filename, pdf)
    response = HttpResponse(pdf, content_type='application/pdf')
    content = "inline; filename='%s'" % (filename)
    return filename