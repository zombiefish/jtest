from django.template.defaultfilters import slugify
from apps.common_utils.views.get_logo import getClientLogo
from apps.rmm_pra.models import RmmPraMaster
from ssl import ALERT_DESCRIPTION_PROTOCOL_VERSION
from apps.imageupload.api.views.views import UplaodImageView
from datetime import datetime
from django.db.models.expressions import OuterRef, Subquery
from django.http.response import HttpResponse
from apps.language.models import LanguageTranslation
from apps.reflist.models import RefListDetail
from apps.common_utils.views.get_translations import get_translation
from django.template.loader import get_template
from django.conf import settings
import os
from apps.person.models import Person
from apps.person.models import Person
from django.db.models import Value, CharField
from django.db.models.functions import Concat
from decouple import config
from django.forms import model_to_dict
from apps.rmm_jra.models import RmmJraMaster
from apps.incident_management.api.views.attachments_helper_functions import attach_pdf_to_incident, render_to_pdf, modify_general_actions, modify_hazard_actions, save_ra_attachment, save_to_file, translate_measures


def generateJRAPdf(self, list_jra, person, translations, lng_id, *args, **kwargs):
    '''
    input list_jra:[1,2,3]
    '''    
    # lng_id = 2
    reports = []
    ltr_ids = []
    filenames = []
    data = dict()
    data['translate'] = translations
    for jra in list_jra:
        get_jra = RmmJraMaster.objects.get(rmm_jra_id = jra)
        temp_jra = model_to_dict(get_jra)        
        site_ref = RefListDetail.objects.get(rld_id = get_jra.rmm_jra_site_id)             
        temp_jra['rmm_jra_site'] = LanguageTranslation.objects.get(ltr_tag = site_ref.rld_name, ltr_tag_type = site_ref.rld_tag_type, ltr_lng = lng_id).ltr_text
        job_ref = RefListDetail.objects.get(rld_id = get_jra.rmm_jra_job_id)
        temp_jra['rmm_jra_job'] = LanguageTranslation.objects.get(ltr_tag = job_ref.rld_name, ltr_tag_type = job_ref.rld_tag_type, ltr_lng = lng_id).ltr_text        
        temp_jra['rmm_jra_created_by_per'] = Person.objects.get(per_id = get_jra.rmm_jra_created_by_per_id).full_name
        temp_jra['doc_number'] = f"{temp_jra['rmm_jra_document_number']}.{temp_jra['rmm_jra_doc_version_number']}"
        if get_jra.rmm_jra_pra_id:
            temp_jra['rmm_jra_pra'] = RmmPraMaster.objects.get(rmm_pra_id=get_jra.rmm_jra_pra_id).rmm_pra_title        
        temp_jra['rmm_jra_created_date'] = get_jra.rmm_jra_created_date
        
        applicable_line_items = get_jra.pra_threat.filter(rmm_jpt_enable=True).values_list('rmm_jpt_pth__rmm_pth_threat', flat=True)
        step_data = []
        for step in get_jra.step_categories.filter(rmm_jsc_enable=True):
            row = model_to_dict(step)
            row["threats"] = []
            for index, ev in enumerate(step.threats.filter(rmm_jth_enable=True)):                
                row["threats"].append(translate_measures(self, model_to_dict(ev), lng_id))
                row["threats"][index]["control_measures"] = []
                row["threats"][index]["additional_control_measures"] = []
                for tag in ev.tags.filter(rmm_jta_enable=True):
                    row["threats"][index][tag.rmm_jta_parent_tag_name].append(model_to_dict(tag))
            step_data.append(row)
        
        # participants
        participants = get_jra.participants.filter(rmm_jrp_enable=True).annotate(
                full_name=Concat(
                    "rmm_jrp_per__per_first_name", Value(" "),
                    "rmm_jrp_per__per_last_name", output_field=CharField(),
                    )
                ).values_list("full_name", flat=True)
        # approvers
        approvers = get_jra.approvers.filter(
            rmm_jap_enable=True
            ).annotate(
                full_name=Concat(
                    "rmm_jap_per__per_first_name", Value(" "),
                    "rmm_jap_per__per_last_name", output_field = CharField()
                    )
                ).values('rmm_jap_id', "full_name", "rmm_jap_per", "rmm_jap_approved_date", "rmm_jap_approved")
        # reviewers
        get_ref_list = get_jra.rmm_jre_jra_master.annotate(
                            tag = Subquery(RefListDetail.objects.filter(rld_id = OuterRef('rmm_jre_position')).values('rld_name')[:1]),
                            tag_type = Subquery(RefListDetail.objects.filter(rld_id = OuterRef('rmm_jre_position')).values('rld_tag_type')[:1])            
                        ).values()
        reviewers = get_ref_list.annotate(
                        rmm_jre_position_name = Subquery(LanguageTranslation.objects.filter(ltr_tag = OuterRef('tag'), ltr_tag_type = OuterRef('tag_type'), ltr_lng_id = lng_id).values('ltr_text')[:1]),
                        reviewer_name = Concat('rmm_jre_per__per_first_name', Value(' '), 'rmm_jre_per__per_last_name', output_field = CharField())
                    ).values(
                        "rmm_jre_per_id",
                        "rmm_jre_position_name",
                        "rmm_jre_created_date",
                        'reviewer_name'
                    )


        data['header'] = temp_jra
        data['applicable_line_items'] = list(applicable_line_items)
        data['stepdata'] = step_data
        data['participants'] = participants
        data['approvers'] = approvers
        data['reviewers'] = reviewers
        data['logolocation'] = getClientLogo()

        data['general_actions'] = get_jra.get_sga_and_attachments(person)
        data['hazard_actions'] = get_jra.get_ha_and_attachments(person)
        
        if data['hazard_actions']:
            data['hazard_actions'] = modify_hazard_actions(self, list(data['hazard_actions']), 'attachmenttype', lng_id)
        if data['general_actions']:
            data['general_actions'] = modify_general_actions(self, list(data['general_actions']), 'gaa_type', lng_id)
        reports.append(data.copy())        

        pdf = render_to_pdf('jra_pdf.html',data)
        
        if pdf:
            filename = save_ra_attachment(pdf, temp_jra['rmm_jra_created_by_per'], data['translate'][2253], self.incident_number)            
            filenames.append(filename)
    
    attach_pdf_to_incident(self.incidentid,self.incident_number, filenames, self.request.user.user_per_id_id, self.request.user.user_per_id_id, 3668) # Risk Assessments and Procedures
            
    return reports