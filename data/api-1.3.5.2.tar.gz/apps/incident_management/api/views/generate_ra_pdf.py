from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.generics import ListAPIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from apps.language.models import Language
from apps.common_utils.views.get_translations import get_translation
from apps.incident_management.api.views.generate_jra_pdf import generateJRAPdf
from apps.incident_management.api.views.generate_ora_pdf import generateORAPdf
from apps.incident_management.api.views.generate_pra_pdf import generatePRAPdf
from apps.incident_management.api.views.incidents_helper_function import update_incident


class GenerateRAPDF(ListAPIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)

    def post(self, request):
        '''
        {
            "incidentid" : 1,
            "incident_number": 2021-070
            "ora": [123,124,125],
            "pra": [123,124,125],
            "jra": [40],
            "bowtie": [123,124,125]
        }
        '''
        person = request.user.user_per_id
        payloadData = request.data
        language = UserProfile.objects.get(upr_per=person).upr_language
        lng_id = Language.objects.get(lng_name=language).lng_id        
        ltr_ids = []
        translations = get_translation(ltr_ids, lng_id)
        self.incidentid = payloadData['incidentid']
        self.incident_number = payloadData['incident_number']
        list_jra = payloadData['jra']
        list_ora = payloadData['ora']
        list_pra = payloadData['pra']
        # list_bowtie = payloadData['bowtie']
        jraPdf = generateJRAPdf(self, list_jra, person, translations, lng_id)
        oraPdf = generateORAPdf(self, list_ora, person, translations, lng_id)
        praPdf = generatePRAPdf(self, list_pra, person, translations, lng_id)
        if self.incidentid:
            update_incident(self.incidentid, person.per_id)
        return Response({'Output': "OK"}) 