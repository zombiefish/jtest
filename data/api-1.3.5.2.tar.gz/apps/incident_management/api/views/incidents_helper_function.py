from apps.incident_management.models import Incident_Signoffs, Incidents, Incidentsubmissions
from datetime import datetime

# SOF-13562 updating lastmodifiedby and lastmodified in Incidents when an incident is modified
def update_incident(incident_id, person_id):
    existing_incident = Incidents.objects.filter(id=incident_id)
    existing_incident_check = existing_incident.exists()

    if incident_id and existing_incident_check:
        existing_incident.update(
            lastmodified = datetime.now(),
            lastmodifiedby = person_id
        )
        return existing_incident_check
    else:
        raise ValidationError("Incient Id does not exist")