from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.generics import ListAPIView
from rest_framework.views import APIView
from datetime import datetime
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from apps.language.models import Language
from apps.common_utils.views.get_translations import get_translation
from apps.incident_management.models import Incidents, Incident_Signoffs
from apps.incident_management.api.views.incidents_helper_function import update_incident

class AddIncidentRoles(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidentSignoff.value,)

    def post(self, request):
        '''
        Expected input payload
        {
            "incidentId" : 12345,
            "role_ids" : [2,8,4]
        }
        '''
        person = self.request.user.user_per_id
        
        if 'incidentId' in request.data and 'role_ids' in request.data and request.data['incidentId'] and request.data['role_ids']:
            incident_id = request.data['incidentId']
            role_ids = request.data['role_ids']

            # check if role_ids exists for incident ID in Incident_Signoffs

            existing_roles = Incident_Signoffs.objects.filter(iso_incident = incident_id, iso_enable = True).values_list('iso_role', flat=True)

            # existing_roles = [1,2,3,4,5,6]
            deleted_roles = [each for each in existing_roles if each not in role_ids]
            new_roles = [each for each in role_ids if each not in existing_roles]

            # SOF-9395 set iso_enable = 0 to deleted_role for the incident_id
            Incident_Signoffs.objects.filter(
                iso_incident = incident_id,
                iso_role_id__in = deleted_roles
            ).update(
                iso_enable = False,
                iso_modified_by_per = person,
                iso_modified_date = datetime.now()
            )

            # SOF-9395 add new roles for incident_id
            # SOF-9395 bulk creating as new_roles could be more than one.
            Incident_Signoffs.objects.bulk_create([
                    Incident_Signoffs(
                        iso_incident_id = incident_id,
                        iso_role_id = role,
                        iso_created_by_per = person
                    ) for role in new_roles
                ])
            
            if incident_id:
                update_incident(incident_id, person.per_id) 
        
            return Response(status=status.HTTP_201_CREATED)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)

            
            

