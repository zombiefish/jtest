from datetime import date, datetime
from django.db import connection
from django.urls import conf
from rest_framework import response
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.get_translations import get_translation
from django.db import transaction

from apps.common_utils.views.validate_permission import RolePermission
from apps.incident_management.api.utlity_function import dictfetchall
from apps.incident_management.models import Incident_Quick_Signoff_Note, Incident_Quick_Signoff_Role, Incident_Signoffs, Incidents
from apps.language.models import Language, LanguageTranslation
from apps.person.models import Person
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.sofvie_user_authorization.models import AuthRoleSofvie, AuthUserRoleMappingSofive
from apps.user.models import User
from apps.user_settings_profile.models import UserProfile
from django.db.models.functions import Concat, Substr
from django.db.models import Value, Max, F, Subquery, OuterRef, CharField
from apps.incident_management.api.views.incidents_helper_function import update_incident

class GetIncidentSignoffs(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)
    """ Response for the All  """
    def post(self, request):

        '''
        input payload
        {
            "incidentId" : 2
        }
        '''
        incidentId = request.data['incidentId']
        person = self.request.user.user_per_id

        language = UserProfile.objects.get(upr_per=person).upr_language
        lng_id = Language.objects.get(lng_name=language).lng_id

        signoff_data = Incident_Signoffs.objects.filter(
            iso_incident_id = incidentId,
            iso_enable = True
            ).annotate(
                per_full_name = Concat(
                    "iso_per__per_last_name", Value(", "),
                    "iso_per__per_first_name", output_field=CharField(),
                    ),
                role_name = Subquery(
                LanguageTranslation.objects.filter(
                    ltr_tag=OuterRef('iso_role__aro_name'), 
                    ltr_tag_type = OuterRef('iso_role__aro_tag_type'), 
                    ltr_lng_id = lng_id
                    ).values('ltr_text')[:1])
            ).values(
                'iso_id',
                'iso_per_id',
                'per_full_name',
                'iso_role_id',
                'role_name',
                'iso_signoff_datetime',
                ).order_by('role_name')          
        return Response(signoff_data)
    
class AddIncidentSignoff(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanSignOffIncident.value,)
    """ Response for the All  """
    def post(self, request):
        iso_id = request.data['iso_id']
        person = self.request.user.user_per_id

        # update iso_per_id, iso_signoff_datetime for iso_id in incident_signoffs
        Incident_Signoffs.objects.filter(
            iso_id = iso_id,
            iso_enable = True
        ).update(
            iso_per = person,
            iso_signoff_datetime = datetime.now(),
            iso_modified_by_per = person,
            iso_modified_date = datetime.now()
        )       

        return Response("Success")    
    
class RemoveIncidentSignoff(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanSignOffIncident.value,)
    """ Response for the All  """
    def post(self, request):
        iso_id = request.data['iso_id']
        person = self.request.user.user_per_id

        # update iso_per_id, iso_signoff_datetime to None for iso_id in incident_signoffs
        Incident_Signoffs.objects.filter(
            iso_id = iso_id,
            iso_enable = True
        ).update(
            iso_per = None,
            iso_signoff_datetime = None,
            iso_modified_by_per = person,
            iso_modified_date = datetime.now()
        )
        return Response("Success")   

class ClearIncidentSignoffs(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanClearIncidentSignatures.value,)
    """ Response for the All  """
    def post(self, request):
        incidentId = request.data['incidentId']   
        person = self.request.user.user_per_id
       
        # clear iso_per_id, iso_signoff_datetime for all records with iso_incident_id = incidentId
        clear_signoffs = Incident_Signoffs.objects.filter(
            iso_incident_id = incidentId,
            iso_enable = True
        ).update(
            iso_per_id = None,
            iso_signoff_datetime = None,
            iso_modified_by_per = person,
            iso_modified_date = datetime.now()
        )

        quick_sign_off =  Incidents.objects.filter(
            id = incidentId, inc_is_quick_signoff = True            
        )
        
        # validating if this incident is a quick sign off or not!
        if quick_sign_off:
            # update quick signoff flag 
            Incidents.objects.filter(
                id = incidentId            
            ).update(inc_is_quick_signoff = False)

            quickSignoff_note_rec = Incident_Quick_Signoff_Note.objects.filter(iqn_incident_id = incidentId, iqn_enable= True)

            #  Incident_Quick_Signoff_Role update the enable to false 
            if quickSignoff_note_rec:            
                Incident_Quick_Signoff_Role.objects.filter(
                    iqs_iqn_id =  Incident_Quick_Signoff_Note.objects.get(iqn_incident_id = incidentId, iqn_enable= True).iqn_id       
                ).update(iqs_enable = False)

            #  Incident_Quick_Signoff_Note update the enable to false 
            Incident_Quick_Signoff_Note.objects.filter(
                iqn_incident_id = incidentId
            ).update(iqn_enable = False)
        if incidentId:
            update_incident(incidentId, person.per_id)
        return Response("Success") 


class ValidateSignOff(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanSignOffIncident.value,)
    """ Response for the All  """
    def post(self, request):
        iso_id = request.data['iso_id']   
        
        validate = Incident_Signoffs.objects.filter(
            iso_id = iso_id,
            iso_enable = True            
        ).values('iso_per_id',
                'iso_signoff_datetime'
        )

        if validate[0]['iso_per_id'] and validate[0]['iso_signoff_datetime']:
            return Response({'message' :'signed', 'per_id':validate[0]['iso_per_id'],'iso_signoff_datetime':validate[0]['iso_signoff_datetime']})
        else:
            return Response({'message' :'unsigned'})

class CreateQuickSignOff(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanQuickIncidentSignoff.value,)
    """ Response for the All  """
    @transaction.atomic
    def post(self, request):
        incident_id = request.data['incident_id']   
        note = request.data['note']   
        person = self.request.user.user_per_id

        # validating the incident is already Quick signed off or not
        validate =Incidents.objects.filter(
            id = incident_id,
            inc_is_quick_signoff = True,
        ).values('id')       

        if len(validate)>0 and validate[0]['id']:         
            return Response({'message' :'signed'})
        else:
            # # not signed off 
            quick_signoffs = Incidents.objects.filter(
             id = incident_id           
            ).update(
                inc_is_quick_signoff = True,         
            )

            quickSignOffNote = Incident_Quick_Signoff_Note.objects.create(
                iqn_incident = Incidents.objects.get(id = incident_id),
                iqn_note = note,
                iqn_created_date = datetime.now(),
                iqn_created_by_per = person,         
                iqn_enable = True
            )

            userid = User.objects.get(user_per_id=person.per_id).id
            role_ids = AuthUserRoleMappingSofive.objects.filter(aur_user_id=userid).values_list('aur_aro_id', flat=True)

            Incident_Quick_Signoff_Role.objects.bulk_create([
                Incident_Quick_Signoff_Role(
                    iqs_iqn = quickSignOffNote,
                    iqs_aro = AuthRoleSofvie.objects.get(aro_id = role),
                    iqs_created_date = datetime.now(),
                    iqs_created_by_per = person,
                    iqs_enable = True,
                ) for role in role_ids
            ])

            if incident_id:
                update_incident(incident_id, person.per_id)

            return Response({'message' :'added sign'})
class GetQuickSignOffInfo(APIView):       
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewIncidents.value,)
    def post(self, request):
        incident_id = request.data['incident_id']         
        person = self.request.user.user_per_id

        language = UserProfile.objects.get(upr_per=person).upr_language
        lng_id = Language.objects.get(lng_name=language).lng_id

        # get the quick sign off information to show it on the screen
        quicksignoff_info = Incident_Quick_Signoff_Note.objects.filter(
            iqn_incident_id = incident_id,
            iqn_enable = True
        ).annotate(
                per_full_name = Concat(
                    "iqn_created_by_per__per_last_name", Value(", "),
                    "iqn_created_by_per__per_first_name", output_field=CharField(),
                    ),        
        ).values('iqn_id', 'iqn_created_by_per', 'per_full_name', 'iqn_created_date', 'iqn_note')


        for signNote in quicksignoff_info:
            signoffroles_data = Incident_Quick_Signoff_Role.objects.filter(
                iqs_iqn = signNote['iqn_id'],
                iqs_enable = True
                ).annotate(               
                    role_name = Subquery(
                    LanguageTranslation.objects.filter(
                        ltr_tag=OuterRef('iqs_aro__aro_name'), 
                        ltr_tag_type = OuterRef('iqs_aro__aro_tag_type'), 
                        ltr_lng_id = lng_id
                        ).values('ltr_text')[:1])
                ).values_list('role_name', flat=True).order_by('role_name') 
            rolesNames = ', '.join(map(str, list(signoffroles_data)))        
            signNote['role_names'] = rolesNames
            
        return Response({'quicksignoff_info': quicksignoff_info})
