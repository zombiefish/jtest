from django.db import connection
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Prefetch, F, Subquery, OuterRef
from django.db.models.functions import Substr
from apps.incident_management.api.utlity_function import dictfetchall
from apps.common_utils.views.validate_permission import PersonAccessPermission, RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission, \
    SofvieBasePermissionMixin

from apps.general_action.models import Formdescription, SubmissionSignoff, Submissionheader, Reports
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.employee.helper_function_user_visibility import helperEmployeeSites, helperEmployeeJobs
from django.db.models import Prefetch, Q, F, Case, When, Value, CharField, Count, functions, Subquery
from django.db.models.functions import Concat
from apps.incident_management.models import Incidentsubmissions
from apps.language.models import Language, LanguageTranslation


class IncidentManagementListView(APIView, SofvieBasePermissionMixin):    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewIncidents.value,)

    def post(self, request):        

        start_date = request.data['startDate']
        end_date = request.data['endDate']
        lang_name = request.data['language']
        
        person_id = self.request.user.user_per_id_id

        per_sites = []
        get_sites, data_user_visibility = helperEmployeeSites(self, person_id) 
        per_sites = [site['rld_id'] for site in get_sites] 

        per_jobs = []
        get_jobs, data_user_visibility = helperEmployeeJobs(self, person_id) 
        per_jobs = [job['rld_id'] for job in get_jobs] 
        
        # select_forms = ['PRELIMINARY INVESTIGATION', 'PRELIMINARY INCIDENT', 'INCIDENT STATEMENT']
        select_forms = ['220234', '221746', '224335']
        reportQueryset =  Reports.objects.all().values('id','reporturl','singleformreportid')
        incidentSubmissionQs = Incidentsubmissions.objects.all().values_list('submissionheaderid', flat = True)        

        site_filters = []
        job_filters = []
        
        if data_user_visibility !='all':
            site_filters = [Q(site__in=per_sites) | Q(submittedby_supervisorid=person_id)]
            job_filters = [Q(jobnumber__in=per_jobs) | Q(submittedby_supervisorid=person_id)]
               
        
        lng_id = Language.objects.get(lng_name = lang_name)
        mainQueryset = Submissionheader.objects.filter(
            Q(isarchived__isnull=True) & Q(formcreationdate__range=[start_date, end_date]) | Q(isarchived=False),
            *site_filters, 
            *job_filters,
            formdescriptionid__formid__in=select_forms
        ).exclude(
            id__in = incidentSubmissionQs
        ).annotate(
            ID=F('id'),
            SubmissionHeaderID=F('id'),  
            SubmissionDate=F('formsubmissiondate'),                           
            HeaderDate=F('headerdate'),
            JobNumber=F('jobnumber'),
            Site=F('site'),
            FormID=F('formdescriptionid__formid'),
            FormName = F('formdescriptionid__formname'),                       
            SubmittedBy=Concat(
                "submittedby_supervisorid__per_last_name", Value(" "),
                "submittedby_supervisorid__per_first_name", output_field=CharField()),
        ).annotate(
            tag_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('Site')).values('rld_name')[:1]
                ),
            tagtype_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('Site')).values('rld_tag_type')[:1]
                ),
            tag_rld_id_level = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('sitelevel')).values('rld_name')[:1]
                ),
            tagtype_rld_id_level = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('sitelevel')).values('rld_tag_type')[:1]
                ),
            jobcode = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('JobNumber')).values('rld_code')[:1]
                ), 
            Supervisor = Subquery(
                Person.objects.filter(per_id=OuterRef('supervisor')).annotate(
                    full_name = Concat("per_last_name",
                                        Value(" "),
                                        "per_first_name",
                                        output_field=CharField())
                ).values('full_name')[:1]
            )
        ).values().order_by('-formsubmissiondate')
        
        mainQueryset = mainQueryset.annotate(
                        Site = Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_site'), ltr_tag_type=OuterRef('tagtype_rld_id_site'), ltr_lng = lng_id).values('ltr_text')[:1]
                            ),
                        Level = Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_level'), ltr_tag_type=OuterRef('tagtype_rld_id_level'), ltr_lng = lng_id).values('ltr_text')[:1]
                            ),
                        JobNumber = F('jobcode'),
                        FormName = Subquery(
                                LanguageTranslation.objects.filter(ltr_tag=OuterRef('FormName'), ltr_lng = lng_id, ltr_tag_type = 1).values('ltr_text')[:1]
                            ),
                        ReportURL = Subquery(
                            Reports.objects.filter(singleformreportid=OuterRef('FormID')).values('reporturl')[:1]
                        ),
                        signed_by_per = Subquery(
                            SubmissionSignoff.objects.filter(
                                SubmissionHeaderID=OuterRef('SubmissionHeaderID'),
                                SigningAccount = person_id
                            ).values('ID')[:1]
                        ),
                        signoff_count = Subquery(
                            SubmissionSignoff.objects.filter(
                                SubmissionHeaderID=OuterRef('SubmissionHeaderID')
                            ).values('SubmissionHeaderID').annotate(
                                signoff_count=Count('SubmissionHeaderID')
                            ).values('signoff_count')[:1]
                        )
                        ).values(
                            'SubmissionHeaderID',
                            'FormID',
                            'FormName',
                            'SubmissionDate',
                            'Site',
                            'JobNumber',
                            'HeaderDate',
                            'SubmittedBy',
                            'workplace',
                            'Level',
                            'Supervisor',
                            'ReportURL',
                            'signed_by_per',
                            'signoff_count'
                         )

        return Response(mainQueryset)      