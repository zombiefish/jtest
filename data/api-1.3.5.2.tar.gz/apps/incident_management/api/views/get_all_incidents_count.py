from django.db import connection
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission, \
    SofvieBasePermissionMixin


class GetAllIncidentsCounts(APIView, SofvieBasePermissionMixin):
    
    permission_classes = [SofviePermission]
    
    def get(self, request):
        person_id = self.request.user.user_per_id_id

        with connection.cursor() as cursor:
            cursor.execute("call get_person_incidents(%s)", (person_id,))
            person_count = dictfetchall(cursor)[0]['my_open_incidents']

            cursor.execute("call get_person_total_incidents(%s)", (person_id,))
            person_count_total = dictfetchall(cursor)[0]['total_incident_created_by_me']

            cursor.execute("call get_site_incidents(%s)", (person_id,))
            site_count = dictfetchall(cursor)[0]['Open_Sites_Incidents']

            cursor.execute("call get_site_incidents_total(%s)", (person_id,))
            site_count_total = dictfetchall(cursor)[0]['total_incidents_at_sites']

            cursor.execute("call get_company_incidents()")
            company_count = dictfetchall(cursor)[0]['OpenCompanyIncidents']
            cursor.execute("call get_company_incidents_total()")
            company_count_total = dictfetchall(cursor)[0]['totalCompanyIncidents']

            incident_counts = {
                "person": person_count,
                "person_total": person_count_total,
                "site": site_count,
                "site_total": site_count_total,
                "company": company_count,
                "company_total": company_count_total,
            }

        return Response(incident_counts)
