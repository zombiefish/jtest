import datetime
import os
import tempfile
from io import BytesIO
from django.db.models.functions import Substr
from django.db.models import Prefetch, Value, IntegerField, Case, When, CharField, F,Subquery,OuterRef
from django.db.models.functions import Concat, Cast
from django.forms import model_to_dict
from django.http import HttpResponse
from django.template.loader import get_template
from django.utils import translation
from rest_framework.permissions import IsAuthenticated
from xhtml2pdf import pisa
from apps.admin_settings.models import ClientLogo
from apps.common_utils.views.validate_permission import RolePermission
from apps.person.models import Person
from apps.common_utils.views.get_logo import getClientLogo
from decouple import config
from apps.general_action.models import Submissionheader, PreopSubmissionHeader, \
    PreOpSubmissionValue
from apps.hazard_action.models import Submissiondetails, SubmissiondetailsExplode, \
    Submissionhap, Submissionhapattachments
from apps.general_action.models import SubmissionGeneralAction, SubmissionGeneralActionAttachment, \
    SubmissionSignoff
from apps.recognition.models import SubmissionPositiveRecognition, \
    SubmissionPositiveRecognitionPerson, SubmissionPositiveRecognitionAttachments
from apps.reflist.models import RefListDetail
from apps.equipment.models import Equipment, EquipmentType, EquipmentQuestions 
from django.conf import settings
from django.template.defaultfilters import slugify
from rest_framework.views import APIView
from rest_framework.response import Response
from apps.imageupload.api.views.views import UplaodImageView
from datetime import datetime
from apps.language.models import LanguageTranslation, Language
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from apps.common_utils.views.get_translations import get_translation
from apps.comments.models import Comments
from apps.general_action.models import PreOpAttachment
from apps.incident_management.api.views.incidents_helper_function import update_incident


# Handles generating Pre-Task PDF files and 
# attaches them to the incident.
class GeneratePreTaskPDF(APIView):

    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)

    def post(self, request, *args, **kwargs):
        self.incidentID = request.data['incidentid']
        self.incidentNumber = request.data['incidentnumber']
        self.created_by = self.request.user.user_per_id_id
        self.modified_by = self.request.user.user_per_id_id
        ids = request.data['data']
        for id in ids:
            self.generated_pretaskpdf(id)

        return Response('ok')

    def generated_pretaskpdf(self, taskid):
        person_id = self.request.user.user_per_id
        lang = UserProfile.objects.get(upr_per = person_id).upr_language
        lang_id = Language.objects.get(lng_name = lang)
        ltr_ids = [994,1901,1902,1904,1903,1168,124,617,828,621,959,844,1376,820,56,971,616,475,604,1377,627,923,933,604,595,
        606,586,30,2835,40,51,176,173,174,936,50,172,505,81,538,846,1378,838,837,423,422,1999,514,510,509,1914,2177,1144,1911,
        889,15,17,589,1912,1915,70,14,1913,2070,2071,1917,2401,1919,769,741,1039,2078,2026,2070,2071,2072,2073,1395,850,640,1397,
        777,166,773,1379,1380,1381,751,649,1277,771,770,170,467,71,1348,1188,9409,2401]

        finalTranslations = get_translation(ltr_ids,lang_id)
        
        # generate pretask data to apply to the report.

        # header = Submissionheader.objects.get(pk=taskid)

        header_queryset = Submissionheader.objects.filter(id=taskid).annotate(
            tag_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('site')).values('rld_name')[:1]
                ),
            tagtype_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('site')).values('rld_tag_type')[:1]
                ),
            jobcode = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('jobnumber')).values('rld_code')[:1]
                ),
            
            tag_rld_id_level = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('sitelevel')).values('rld_name')[:1]
                ),
            tagtype_rld_id_level = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('sitelevel')).values('rld_tag_type')[:1]
                )                    
        ).values() 

        header_queryset = header_queryset.annotate(
                site = Subquery(
                        LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_site'), ltr_tag_type= OuterRef('tagtype_rld_id_site'), ltr_lng = lang_id).values('ltr_text')[:1]
                    ),
                jobnumber = F('jobcode'),
                sitelevel = Subquery(
                            LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_level'), ltr_tag_type= OuterRef('tagtype_rld_id_level'), ltr_lng = lang_id).values('ltr_text')[:1]
                            ),             
                ).values()


        header = header_queryset[0]
        
        data = header # model_to_dict(header)
        
        if data['submittedby_supervisorid_id']:
            data['submittedby_supervisorid_id']= Person.objects.filter(
                                                per_id = data['submittedby_supervisorid_id']
                                            ).annotate(
                                                full_name=Concat('per_last_name',Value(', '),'per_first_name',output_field = CharField())
                                            ).values_list('full_name', flat=True)[0] 


        emp_path = f"employee_id_{data['submittedby_supervisorid_id']}"
        employee_name = data['submittedby_supervisorid_id'].replace(", ", "_")
        emp_path_with_name = f"{employee_name}_{data['submittedby_supervisorid_id']}"
        detaildata = SubmissiondetailsExplode.objects.filter(submissiondetailid__submissionheaderid__id=taskid)
        data['start_state_pictures'] = []
        data['end_state_pictures'] = []
     
        for item in detaildata:
            if item.formfielddescriptionid.fieldkey == 'start_state_pictures' or item.formfielddescriptionid.fieldkey=='end_state_pictures' :
                file_detail = {}
                try:
                    comt = Comments.objects.get(com_cmt_id=1, com_reference_id=item.id, com_enable=True) 
                except :
                    comt=None
                if comt:
                    file_detail['comment'] = comt
                file_detail['url'] = os.path.join('https://',config('EMAIL_REPORT_IMAGESURL'),item.value)
                file_detail['timestamp'] = item.sde_image_timestamp
                data[item.formfielddescriptionid.fieldkey].append(file_detail)

            elif item.formfielddescriptionid.fieldkey == 'signature_manager':
                try:
                    comt = Comments.objects.get(com_cmt_id=1, com_reference_id=item.id, com_enable=True) 
                except :
                    comt=None
                if comt:
                    data[item.formfielddescriptionid.fieldkey +'_comment'] = comt 
                if item.value:
                    data['signature_manager'] = os.path.join('https://',config('EMAIL_REPORT_IMAGESURL'),item.value)
                else:
                    data['signature_manager'] = ''
            elif item.formfielddescriptionid.fieldkey == 'signature_supervisor':
                try:
                    comt = Comments.objects.get(com_cmt_id=1, com_reference_id=item.id, com_enable=True) 
                except :
                    comt=None

                if comt:
                    data[item.formfielddescriptionid.fieldkey +'_comment'] = comt
                if item.value:
                    data['signature_supervisor'] = os.path.join('https://',config('EMAIL_REPORT_IMAGESURL'),item.value)
                else:
                    data['signature_supervisor'] = ''
            elif item.formfielddescriptionid.fieldkey == 'signature_other':
                try:
                    comt = Comments.objects.get(com_cmt_id=1, com_reference_id=item.id, com_enable=True) 
                except :
                    comt=None

                if comt:
                    data[item.formfielddescriptionid.fieldkey +'_comment'] = comt
                if item.value:
                    data['signature_other'] = os.path.join('https://',config('EMAIL_REPORT_IMAGESURL'),item.value)                    
                else:
                    data['signature_other']=''
            elif item.formfielddescriptionid.fieldkey == 'signature_end_of_shift_review':
                try:
                    comt = Comments.objects.get(com_cmt_id=1, com_reference_id=item.id, com_enable=True) 
                except :
                    comt=None
                if comt:
                    data[item.formfielddescriptionid.fieldkey + '_comment'] = comt
                if item.value:
                    data['signature_end_of_shift_review'] = os.path.join('https://',config('EMAIL_REPORT_IMAGESURL'),item.value)
                else:
                    data['signature_end_of_shift_review'] = ''
            else:
                if item.formfielddescriptionid.fieldkey not in ['sitelevel', 'site', 'submittedby_supervisorid_id']:
                    data[item.formfielddescriptionid.fieldkey] = item.value
                    
        if not 'signature_end_of_shift_review' in data:
            data['signature_end_of_shift_review'] = ''
            data['signature_end_of_shift_review_comment'] = ''


        data['gap'] =  get_general_action(taskid,lang_id) 
        data['hap'] =  get_hazards(taskid,lang_id)
        data['pid'] =  get_pid(taskid,lang_id)

        dist = SubmissiondetailsExplode.objects.filter(
            submissiondetailid__submissionheaderid__id=taskid).filter(
            formfielddescriptionid__sectionname=166).values_list(
            'value', flat=True
        ).values("value")

        data['Report_Distribution1'] = dist if dist[0]['value'] else None

        signoff = SubmissionSignoff.objects.filter(
            SubmissionHeaderID=taskid).annotate(
                sus_position_tag = Subquery(
                    RefListDetail.objects.filter(
                        rld_id=OuterRef("sus_position"), rld_enable=True,
                    ).values("rld_name")[:1]
                ),
                sus_position_tag_type = Subquery(
                    RefListDetail.objects.filter(
                        rld_id=OuterRef("sus_position"), rld_enable=True,
                    ).values("rld_tag_type")[:1]
                )
            ).values('SigningName','SigningTimestamp','sus_position_tag','sus_position_tag_type')


        signoff=signoff.annotate(position_name = Subquery(
            LanguageTranslation.objects.filter(
            ltr_tag=OuterRef("sus_position_tag" ),
            ltr_tag_type=OuterRef('sus_position_tag_type'),
            ltr_lng=lang_id

            ).values('ltr_text')[:1]
        )).values('SigningName','SigningTimestamp','position_name')

        data['signoff']=signoff
   
        if 'signature_supervisor_comment' in data:
            pass
        else: 
            data['signature_supervisor_comment']=''

        if 'signature_manager_comment' in data:
            pass
        else: 
            data['signature_manager_comment']=''

        if 'signature_other_comment' in data:
            pass
        else:
            data['signature_other_comment'] = ''
            
        if 'signature_end_of_shift_review_comment' in data:
            pass
        else:
            data['signature_end_of_shift_review_comment'] = ''            
        
        if 'shift' in data:
            shift_trans =  getTranslatedByText(lang_id,data['shift'],1)  
        else:
            shift_trans = ''

        data['shift_trans'] = shift_trans

        if 'signature_supervisor' in data:
            pass
        else:
            data['signature_supervisor'] = ''

        if 'signature_manager' in data:
            pass
        else:
            data['signature_manager'] = ''

        if 'signature_other' in data:
            pass
        else:
            data['signature_other'] = ''
            
        if 'signature_end_of_shift_review' in data:
            pass
        else:
            data['signature_end_of_shift_review'] = ''

        context= {
            'logolocation': getClientLogo(),
            'submissionid': data['id'],
            'site': does_field_exist_in_dataset('site',data),
            'level': does_field_exist_in_dataset('sitelevel',data),
            'submittedby': does_field_exist_in_dataset('submittedby_supervisorid_id',data),
            'jobnumber' : does_field_exist_in_dataset('jobnumber',data),
            'workplace' : does_field_exist_in_dataset('workplace',data),
            'supervisor' : does_field_exist_in_dataset('submittedby_supervisorid_id',data),
            'shift': does_field_exist_in_dataset('shift_trans',data),
            'assigned_tasks': does_field_exist_in_dataset('assigned_tasks',data) ,
            'workplace_score' : does_field_exist_in_dataset('workplace_score',data),
            'job_definition_score' : does_field_exist_in_dataset('job_definition_score',data),
            'experience_score' : does_field_exist_in_dataset('experience_score', data),
            'worst_case' : does_field_exist_in_dataset('worst_case',data),
            'what_are_you_doing' : does_field_exist_in_dataset('what_are_you_doing',data),
            'being_safe' : does_field_exist_in_dataset('being_safe',data),
            'travelways' :  get_yes_no_na(does_field_exist_in_dataset('travelways',data), finalTranslations),
            'housekeeping': get_yes_no_na(does_field_exist_in_dataset('housekeeping',data), finalTranslations),
            'ventilation' : get_yes_no_na(does_field_exist_in_dataset('ventilation',data), finalTranslations),
            'dust_control' : get_yes_no_na(does_field_exist_in_dataset('dust_control',data), finalTranslations),
            'ground_conditions' : get_yes_no_na(does_field_exist_in_dataset('ground_conditions',data) , finalTranslations),
            'leaky_feed' : get_yes_no_na(does_field_exist_in_dataset('leaky_feed',data), finalTranslations),
            'signs_barricades' : get_yes_no_na(does_field_exist_in_dataset('signs_barricades',data), finalTranslations),
            'hand_tools' : get_yes_no_na(does_field_exist_in_dataset('hand_tools',data), finalTranslations),
            'lock_tag' : get_yes_no_na(does_field_exist_in_dataset('lock_tag',data), finalTranslations),
            'hot_work_permit': get_yes_no_na(does_field_exist_in_dataset('hot_work_permit',data), finalTranslations),
            'sds_chemicals' : get_yes_no_na(does_field_exist_in_dataset('sds_chemicals',data), finalTranslations),
            'working_at_heights' : get_yes_no_na(does_field_exist_in_dataset('working_at_heights',data), finalTranslations),
            'working_alone' : get_yes_no_na(does_field_exist_in_dataset('working_alone',data), finalTranslations),
            'any_procedures' :   get_yes_no_na(does_field_exist_in_dataset('any_procedures',data), finalTranslations),
            'equipment_communication' : get_yes_no_na(does_field_exist_in_dataset('equipment_communication',data), finalTranslations),
            'comments' : does_field_exist_in_dataset('comments',data),
            'supervisor_comments' : does_field_exist_in_dataset('supervisor_comments',data),
            'commitment' : get_yes_no_na(does_field_exist_in_dataset('commitment',data), finalTranslations),
            'start_state_details' : does_field_exist_in_dataset('start_state_details',data),
            'end_state_details' :  does_field_exist_in_dataset('end_state_details',data),
            'proper_ppe' : get_yes_no_na(does_field_exist_in_dataset('proper_ppe',data), finalTranslations),
            'start_state_pictures' : generate_template_pictures(data['start_state_pictures'], 'timestamp', 'url', 'comment'),
            'end_state_pictures' : generate_template_pictures(data['end_state_pictures'], 'timestamp', 'url', 'comment'),
            'hap' : data['hap'],
            'gap' : data['gap'],
            'pid' : data['pid'],
            'signature_supervisor' : data['signature_supervisor'],
            'signature_manager' : data['signature_manager'], 
            'signature_other' : data['signature_other'], 
            'signature_end_of_shift_review' :data['signature_end_of_shift_review'],
            'formsubmissiondate': data['formsubmissiondate'].strftime('%Y-%m-%d'),
            'formcreationdate' :  data['formcreationdate'].strftime('%Y-%m-%d'),
            'signoff' : data['signoff'],
            'Report_Distribution1' : data['Report_Distribution1'],
            'translations': finalTranslations,
            'signature_supervisor_comment': data['signature_supervisor_comment'],
            'signature_manager_comment': data['signature_manager_comment'],
            'signature_other_comment': data['signature_other_comment'],
            'signature_end_of_shift_review_comment': data['signature_end_of_shift_review_comment']
        }
        
        pdf = render_to_pdf('pretask_pdf.html',context)
        if pdf:
            file_Name= get_translation([3447],lang_id)
            filePath = settings.FILES_DIR
            timestamp = datetime.now().strftime('%Y%m-%d%H-%M%S')
            filename = f"" \
                        f"{slugify(employee_name)}" \
                        f"_{timestamp}_{slugify(file_Name[3447])}-report.pdf"
            filepath = os.path.join(settings.FILES_DIR, self.incidentNumber)

            save_to_file(filepath, filename, context, pdf)

            response = HttpResponse(pdf, content_type='application/pdf')
            content = "inline; filename='%s'" % (filename)

            attach_pdf_to_incident(self.incidentID,self.incidentNumber, filename, self.created_by, self.modified_by, 3666) # Pretasks

            return response
        return HttpResponse("Not found")


def getTranslation(lng_id, lng_tag, lng_tag_type ):
    temp =LanguageTranslation.objects.select_related('ltr_lng_id').filter(ltr_tag = lng_tag, ltr_tag_type=lng_tag_type, ltr_lng_id = lng_id).values('ltr_text')
    rtrn = temp[0]['ltr_text'].title()
    return rtrn

def getTranslatedByText(lng_id, lng_tag_text, lng_tag_type ):
    temp_ltr_tag =LanguageTranslation.objects.select_related('ltr_lng_id').filter(ltr_text = lng_tag_text).values('ltr_tag')
    temp =LanguageTranslation.objects.select_related('ltr_lng_id').filter(ltr_tag = temp_ltr_tag[0]['ltr_tag'], ltr_tag_type=lng_tag_type, ltr_lng_id = lng_id).values('ltr_text')
    rtrn = temp[0]['ltr_text'].title()
    return rtrn
       
           
# Handles generating Pre-Op PDF files and 
# attaches them to the incident.
class GeneratePreOpPDF(APIView):

    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)

    def post(self,request, *args, **kwargs):
        # Entry point.
        ids = request.data['data']
        self.incidentID = request.data['incidentid']
        self.incidentNumber = request.data['incidentnumber']
        self.created_by = self.request.user.user_per_id
        self.modified_by = self.request.user.user_per_id_id
        for id in ids:
            self.generated_preoppdf(id)

        return Response('ok')


    # Generate PRE-OP PDF
    def generated_preoppdf(self, taskid):      
        
        person_id = self.request.user.user_per_id
        lang = UserProfile.objects.get(upr_per = person_id).upr_language
        lang_id = Language.objects.get(lng_name = lang)
        ltr_ids = [1953,995,1901,1902,1904,1903,1168,124,617,828,
            621,959,844,1239,1235,820,1465,1955, 1956,2989,2974,81,1188,
            1958,823,850,217,1142,514,510,509,1914,2177,1144,1911,
            889,15,17,1177,1379,1380,1912,1915,71,70,14,1913,2071,
            15,1917,2402,2401,1324,2078,773,2026,2070,2071,1039,
            751,771,770,467,1919,769,1918,777,166,1348,649,1277,8302,
            8303,8304,8351,8352,8305,8306,8307,8308,589,8724,8725,1957,1999,2072,2073,9409]

        finalTranslations = get_translation(ltr_ids,lang_id)
        header_queryset = Submissionheader.objects.filter(id=taskid).annotate(
            tag_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('site')).values('rld_name')[:1]
                ),
            tagtype_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('site')).values('rld_tag_type')[:1]
                ),
            jobcode = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('jobnumber')).values('rld_code')[:1]
                ),
            
            tag_rld_id_level = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('sitelevel')).values('rld_name')[:1]
                ),
            tagtype_rld_id_level = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('sitelevel')).values('rld_tag_type')[:1]
                )                
        ).values() 

        header_queryset = header_queryset.annotate(
                site = Subquery(
                        LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_site'), ltr_tag_type= OuterRef('tagtype_rld_id_site'), ltr_lng = lang_id).values('ltr_text')[:1]
                    ),
                jobnumber = F('jobcode'),
                sitelevel = Subquery(
                            LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_level'), ltr_tag_type= OuterRef('tagtype_rld_id_level'), ltr_lng = lang_id).values('ltr_text')[:1]
                            ),
                supervisor = Concat(Subquery(
                            Person.objects.filter(per_id=OuterRef('supervisor')).values('per_last_name')
                        ),
                        Value(', '),
                        Subquery(
                            Person.objects.filter(per_id=OuterRef('supervisor')).values('per_first_name')
                        ), output_field = CharField()),
                ).values()
        header = header_queryset[0]
        emp_path = f"employee_id_{header['submittedby_supervisorid_id']}"
        employee_name = Person.objects.get(per_id=header['submittedby_supervisorid_id'])

        emp_path_with_name = f"{employee_name.per_last_name}_" \
                    f"{employee_name.per_first_name}_{header['submittedby_supervisorid_id']}"

        preopheader = PreopSubmissionHeader.objects.filter(
                psh_submissionheader_id = taskid
            ).values('psh_id',
                'psh_submissionheader_id',
                'psh_pet_id__pet_equipment_identifier',
                'psh_pet_id__pet_poe_id'
            )[:1].get()

        ph_id=preopheader['psh_id']
        preopattachments = PreOpAttachment.objects.filter(poa_psh_id=ph_id)
         
        # Pull all image comments for this preop.
        comments = {}
        for poa in preopattachments:
            if poa.poa_element_name == 'signature_end_of_shift_review':
                preopheader['end_of_shift_review_date'] =  poa.poa_created_date
            if poa.poa_element_name == 'signature_supervisor_photo':
                preopheader['supervisor_signature_date'] =  poa.poa_created_date
            comt = Comments.objects.filter(com_cmt_id=4,com_reference_id = poa.poa_id, com_enable=True).values('com_cmt_id','com_comment')
            if comt:
                comments[poa.poa_element_name] = comt[0]['com_comment']

        if header['submittedby_supervisorid_id']:
            header['submittedby_supervisorid_id']= Person.objects.filter(
                                                per_id = header['submittedby_supervisorid_id']
                                            ).annotate(
                                                full_name=Concat('per_last_name',Value(', '),'per_first_name',output_field = CharField())
                                            ).values_list('full_name', flat=True)[0]         
        
        equipment = EquipmentType.objects.filter(
            poe_id=preopheader['psh_pet_id__pet_poe_id'],
        ).values()[0]
        
        language_tag = equipment['poe_equip_description']
        language_tag_type = equipment['poe_tag_type']
        preopheader['equipment_desc']=getTranslation(lang_id, language_tag, language_tag_type)
        preopdetails = PreOpSubmissionValue.objects.filter(
            psv_psh_id=preopheader['psh_id']
        ).values().all()

        questions = []
        front_start_pictures = []
        left_start_pictures = []
        right_start_pictures=[]
        back_start_pictures = []
        front_end_pictures = []
        left_end_pictures = []
        back_end_pictures = []
        right_end_pictures = []
        preopheader['startmeasures'] = [] 
        preopheader['endmeasures'] = []  
        
        for det in preopdetails:
            if det['psv_preop_question_identifier'].startswith('measure-start'):
                rld = det['psv_preop_question_identifier'].split('-')[2]
                det['text']=get_tag_text_for_ref_list_id(rld,lang_id)
                preopheader['startmeasures'].append(det)
            elif det['psv_preop_question_identifier'].startswith('measure-end'):
                rld = det['psv_preop_question_identifier'].split('-')[2]
                det['text']=get_tag_text_for_ref_list_id(rld,lang_id)
                preopheader['endmeasures'].append(det)
            elif det['psv_preop_question_identifier'] == 'shift':
                preopheader['shift'] =getTranslatedByText(lang_id,det['psv_value'],1) # det['psv_value'] #  getTranslation(lang_id,shift,'s')
            elif det['psv_preop_question_identifier']=='enginestart':
                preopheader['engine_start'] = det['psv_value']
            elif det['psv_preop_question_identifier'] == 'engineend':
                preopheader['engine_end'] = det['psv_value']
            elif det['psv_preop_question_identifier'] == 'comments':
                preopheader['comments_defects'] =  det['psv_value']
            elif det['psv_preop_question_identifier'] == 'levelendshift':
                preopheader['level_end_shift'] = det['psv_value']
            elif det['psv_preop_question_identifier'] == 'othercomments':
                preopheader['othercomments'] = det['psv_value']
            elif det['psv_preop_question_identifier'] == 'workplaceendshift':
                preopheader['end_shift_workplace'] = det['psv_value']
            elif det['psv_preop_question_identifier'] == 'signature_supervisor_photo':
                preopheader['supervisor_signature'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'),det['psv_value'])
                if 'signature_supervisor_photo' in comments:
                    preopheader['supervisor_comment'] = comments['signature_supervisor_photo']
            elif det['psv_preop_question_identifier'] == 'signature_employee_photo':
                preopheader['employee_signature'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'),det['psv_value'])
                
            elif det['psv_preop_question_identifier'] == 'signature_end_of_shift_review':
                preopheader['signature_end_of_shift_review'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'),det['psv_value'])
                if 'signature_end_of_shift_review' in comments:
                    preopheader['end_of_shift_review_comment'] = comments['signature_end_of_shift_review']

            elif det['psv_preop_question_identifier'] =='Report_Distribution1':
                preopheader['Report_Distribution1'] = det['psv_value'].replace('|',', ')
            elif det['psv_preop_question_identifier'].find('photo-front-start') != -1:
                pic={}
                pic['date'] = det['psv_preop_question_identifier'].partition('.')[0].strip("SUP")
                pic['url'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'),det['psv_value'])
                if det['psv_preop_question_identifier'] in comments:
                    pic['comment'] =comments[det['psv_preop_question_identifier']]
                front_start_pictures.append(pic)
            elif det['psv_preop_question_identifier'].find('photo-left-start') != -1:
                pic = {}
                pic['date'] = det['psv_preop_question_identifier'].partition('.')[0].strip("SUP")
                pic['url'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'),det['psv_value'])
                if det['psv_preop_question_identifier'] in comments:
                    pic['comment'] =comments[det['psv_preop_question_identifier']]
                left_start_pictures.append(pic)
            elif det['psv_preop_question_identifier'].find('photo-right-start') != -1:
                pic = {}
                pic['date'] = det['psv_preop_question_identifier'].partition('.')[0].strip("SUP")
                pic['url'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'),det['psv_value'])
                if det['psv_preop_question_identifier'] in comments:
                    pic['comment'] =comments[det['psv_preop_question_identifier']]
                right_start_pictures.append(pic)
            elif det['psv_preop_question_identifier'].find('photo-back-start') != -1:
                pic = {}
                pic['date'] = det['psv_preop_question_identifier'].partition('.')[0].strip("SUP")
                pic['url'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'),det['psv_value'])
                if det['psv_preop_question_identifier'] in comments:
                    pic['comment'] =comments[det['psv_preop_question_identifier']]
                back_start_pictures.append(pic)
            elif det['psv_preop_question_identifier'].find('photo-front-end') != -1:
                pic = {}
                pic['date'] = det['psv_preop_question_identifier'].partition('.')[0].strip("SUP")
                pic['url'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'),det['psv_value'])
                if det['psv_preop_question_identifier'] in comments:
                    pic['comment'] =comments[det['psv_preop_question_identifier']]
                front_end_pictures.append(pic)
            elif det['psv_preop_question_identifier'].find('photo-left-end') != -1:
                pic = {}
                pic['date'] = det['psv_preop_question_identifier'].partition('.')[0].strip("SUP")
                pic['url'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'),det['psv_value'])
                if det['psv_preop_question_identifier'] in comments:
                    pic['comment'] =comments[det['psv_preop_question_identifier']]
                left_end_pictures.append(pic)
            elif det['psv_preop_question_identifier'].find('photo-right-end') != -1: 
                pic = {}
                pic['date'] = det['psv_preop_question_identifier'].partition('.')[0].strip("SUP")
                pic['url'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'),det['psv_value'])
                if det['psv_preop_question_identifier'] in comments:
                    pic['comment'] =comments[det['psv_preop_question_identifier']]
                right_end_pictures.append(pic)
            elif det['psv_preop_question_identifier'].find('photo-back-end') != -1: 
                pic = {}
                pic['date'] = det['psv_preop_question_identifier'].partition('.')[0].strip("SUP")
                pic['url'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'),det['psv_value'])
                if det['psv_preop_question_identifier'] in comments:
                    pic['comment'] =comments[det['psv_preop_question_identifier']]
                back_end_pictures.append(pic)
            else:
                try:
                    question = model_to_dict( EquipmentQuestions.objects.get(
                        poq_preop_identifier = det['psv_preop_question_identifier']
                    ))

                    q = {}

                    language_tag = question['poq_preop_question']
                    language_tag_type = question['poq_tag_type']
                    poq_pct_id = question['poq_pct_id']
                    
                    q['question'] = getTranslation(lang_id, language_tag, language_tag_type) 
                    q['answer'] = ''
                    if poq_pct_id ==1:
                        q['answer'] = getTranslation(lang_id, get_ok_defective_na(det['psv_value']), 1)
                    elif poq_pct_id ==2:
                        q['answer'] = det['psv_value']

                    q['sortorder']= question['poq_sort_order']
                    questions.append(q)
                except EquipmentQuestions.DoesNotExist:
                    pass

        questions.sort(key =lambda q: q.get('sortorder'))
        pics = {}
        pics['start'] = {}
        pics['start']['front'] = generate_template_pictures(front_start_pictures, 'date', 'url', 'comment')
        pics['start']['left'] = generate_template_pictures(left_start_pictures, 'date', 'url', 'comment')
        pics['start']['back'] = generate_template_pictures(back_start_pictures, 'date', 'url', 'comment')
        pics['start']['right'] = generate_template_pictures(right_start_pictures, 'date', 'url', 'comment')
        pics['end'] = {}
        pics['end']['front'] = generate_template_pictures(front_end_pictures, 'date', 'url', 'comment')
        pics['end']['left'] = generate_template_pictures(left_end_pictures, 'date', 'url', 'comment')
        pics['end']['back'] = generate_template_pictures(back_end_pictures, 'date', 'url', 'comment')
        pics['end']['right'] = generate_template_pictures(right_end_pictures, 'date', 'url', 'comment')
        data ={}
        data['header'] = header
        data['preopheader'] = preopheader
        data['gap'] =  get_general_action(taskid, lang_id) 
        data['hap'] =  get_hazards(taskid,lang_id)
        data['pid'] =  get_pid(taskid,lang_id)

        signoff = SubmissionSignoff.objects.filter(
            SubmissionHeaderID=taskid).annotate(
                sus_position_tag = Subquery(
                    RefListDetail.objects.filter(
                        rld_id=OuterRef("sus_position"), rld_enable=True,
                    ).values("rld_name")[:1]
                ),
                sus_position_tag_type = Subquery(
                    RefListDetail.objects.filter(
                        rld_id=OuterRef("sus_position"), rld_enable=True,
                    ).values("rld_tag_type")[:1]
                )
            ).values('SigningName','SigningTimestamp','sus_position_tag','sus_position_tag_type')


        signoff=signoff.annotate(position_name = Subquery(
            LanguageTranslation.objects.filter(
            ltr_tag=OuterRef("sus_position_tag" ),
            ltr_tag_type=OuterRef('sus_position_tag_type'),
            ltr_lng=lang_id

            ).values('ltr_text')[:1]
        )).values('SigningName','SigningTimestamp','position_name')

        data['signoff']=signoff

        context = {
            'logolocation': getClientLogo(),
            'header': data['header'],
            'preopheader': data['preopheader'],
            'hap' : data['hap'],
            'gap' : data['gap'],
            'pid' : data['pid'],
            'questions' : questions,
            'pictures' : pics,
            'signoff': data['signoff'],
            'translations': finalTranslations
        }

        pdf = render_to_pdf('preop_pdf.html',context )
        if pdf:
            timestamp = datetime.now().strftime('%Y%m-%d%H-%M%S')
            translatedRptName = finalTranslations[1953].lower().replace(" ","-")
            filename = f"" \
                        f"{slugify(employee_name.per_last_name+'_'+ employee_name.per_first_name)}" \
                        f"_{timestamp}-{translatedRptName}.pdf"
            filepath = os.path.join(settings.FILES_DIR,str(self.incidentNumber))
            save_to_file(filepath, filename, context, pdf)
            response = HttpResponse(pdf, content_type='application/pdf')
            content = "inline; filename='%s'" % (filename)
            attach_pdf_to_incident(self.incidentID,self.incidentNumber, filename, self.created_by, self.modified_by, 3667) # PreOps

            return response
        return HttpResponse("Not found")

def get_tag_text_for_ref_list_id(rid, lang_id):
    try:
        id_tag = RefListDetail.objects.get(rld_id=rid)
        return LanguageTranslation.objects.get(ltr_tag=id_tag.rld_name, ltr_tag_type=id_tag.rld_tag_type,  ltr_lng = lang_id).ltr_text
    except:
        return None


def get_hazards(id, lang_id):
    hap = Submissionhap.objects.filter(submissionheaderid=id, sha_enable=1)
    hapdata = hap.values()
    for h in hapdata:
        hapattachments = Submissionhapattachments.objects.filter(submissionhapid=h["id"]).values().all()
        hazpics_initial = []
        hazpics_followup = []
        h['hazard_type']=get_tag_text_for_ref_list_id(h['hazard_type'], lang_id)
        h['hazard_identification']=get_tag_text_for_ref_list_id(h['hazard_identification'], lang_id)
        h['potential_risk'] =get_tag_text_for_ref_list_id(h['potential_risk'], lang_id)
        h['action_type']=get_tag_text_for_ref_list_id(h['action_type'], lang_id)
        h['immediate_action_type']=get_tag_text_for_ref_list_id(h['immediate_action_type'], lang_id)
        if hapattachments.exists():
            for pic in hapattachments:
                picdetails = {}
                picdetails['url'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'),pic['attachmentfilename'])
                picdetails['timestamp'] = pic['haa_image_timestamp']
                if pic['attachmenttype'] == 'INITIAL':
                    hazpics_initial.append(picdetails)
                elif pic['attachmenttype'] =='FOLLOWUP':
                    hazpics_followup.append(picdetails)
                
                comt = Comments.objects.filter(com_cmt_id = 5, com_reference_id = pic['id'], com_enable=True).values('com_comment')
                picdetails['comment']=  comt[0]['com_comment']

            h['hazattach_initial'] = generate_template_pictures(hazpics_initial, 'timestamp', 'url', 'comment')
            h['hazattach_followup'] = generate_template_pictures(hazpics_followup, 'timestamp', 'url', 'comment')
            if(h['completed_action_type']):
                h['completed_action_type'] = get_tag_text_for_ref_list_id( h['completed_action_type'] ,lang_id)

            if h['action_complete_by_who']:
                    h['action_complete_by_who']= Person.objects.filter(
                                                        per_id = h['action_complete_by_who']
                                                    ).annotate(
                                                        full_name=Concat('per_last_name',Value(', '),'per_first_name',output_field = CharField())
                                                    ).values_list('full_name', flat=True)[0]   
    
            if h['action_by_who']:
                h['action_by_who']= Person.objects.filter(
                                                    per_id = h['action_by_who']
                                                ).annotate(
                                                    full_name=Concat('per_last_name',Value(', '),'per_first_name',output_field = CharField())
                                                ).values_list('full_name', flat=True)[0] 
    if hap:
        return hapdata
    else:
        return None

def get_pid(id, lang_id):
    pid = SubmissionPositiveRecognition.objects.select_related('submissionheader').prefetch_related(
        Prefetch('submission_positive_recognition',
                SubmissionPositiveRecognitionPerson.objects.only(
                    'recognitionof'))).filter(
                        submissionheader_id=id,
                        spr_enable = True
                        ).annotate(
                            recognitionof_fullname = Concat(
                            'submission_positive_recognition__recognitionof__per_last_name',
                            Value(', '),  
                            'submission_positive_recognition__recognitionof__per_first_name', output_field = CharField()
                            ),
                            WasRecognitionGiven_annotate=Cast('WasRecognitionGiven', IntegerField())
                        ).values(
        'RecognitionType',
        'EventDescription',
        'submissionheader__id',
        'recognitionof_fullname',
        'WasRecognitionGiven_annotate',
        'RecognitionGivenType',
        'id',
    )
    
    pid=pid.annotate(
        WasRecognitionGiven = Case(
            When(WasRecognitionGiven_annotate=1, then=Value("Yes")),
            When(WasRecognitionGiven_annotate=0, then=Value("No")),
            output_field=CharField()
        )
    )
    
    for p in pid:
        p['RecognitionType'] = get_tag_text_for_ref_list_id(p['RecognitionType'],lang_id)
        
        # get attachments.
        pidpics = []
        pidattach = SubmissionPositiveRecognitionAttachments.objects.filter(
            submissionpositiverecognition_id = p['id']
        ).values('id','AttachmentFileName','spa_image_timestamp')
        if pidattach.exists():
            for pic in pidattach:
                picdetail = {}
                picdetail['url'] = os.path.join('https://', config('EMAIL_REPORT_IMAGESURL'),pic['AttachmentFileName'])
                picdetail['timestamp']=pic['spa_image_timestamp']
                comt = Comments.objects.filter(com_cmt_id = 6, com_reference_id = pic['id'], com_enable=True).values('com_comment')
                if comt:
                    picdetail['comment']=  comt[0]['com_comment']               
                
                pidpics.append(picdetail)
            p['pidattach']=generate_template_pictures(pidpics, 'timestamp', 'url', 'comment')
            
    
    if pid.exists():
        return pid
    else:
        return None

def get_general_action(id, lang_id):

    gap = SubmissionGeneralAction.objects.filter(sga_submission_header=id, sga_enable=1).annotate(
        action_by_who=Concat(
                                  'sga_action_by_who_per__per_last_name',
                                  Value(', '),  
                                  'sga_action_by_who_per__per_first_name', output_field = CharField()
                                 ),
    ).values()

    for g in gap:
        gapattach = SubmissionGeneralActionAttachment.objects.filter(gaa_sga=g['sga_id']).values('gaa_id','gaa_file_name','gaa_type','gaa_image_timestamp')
        gappics_initial = []
        gappics_followup = []
        for pic in gapattach:

            picdetail={}
            picdetail['url'] = os.path.join('https://',config('EMAIL_REPORT_IMAGESURL'))
            picdetail['url'] = picdetail['url'] + 'general_action' + '/' + pic['gaa_file_name']
            picdetail['timestamp'] = pic['gaa_image_timestamp']
            comt = Comments.objects.filter(com_cmt_id = 7, com_reference_id = pic['gaa_id'], com_enable=True).values('com_comment')
            if comt:
                picdetail['comment']=  comt[0]['com_comment']               

            if pic['gaa_type']=='INITIAL':
                gappics_initial.append(picdetail)
            elif pic['gaa_type']=='FOLLOWUP':
                gappics_followup.append(picdetail)

        g['gapattach_initial'] = generate_template_pictures(gappics_initial, 'timestamp', 'url', 'comment')
        g['gapattach_followup'] = generate_template_pictures(gappics_followup, 'timestamp', 'url', 'comment')
        g['action_type']=get_tag_text_for_ref_list_id(g['sga_action_type_rld_id'], lang_id)

        if g['sga_completed_action_type_rld_id']:
            g['completed_action_type']=get_tag_text_for_ref_list_id(g['sga_completed_action_type_rld_id'], lang_id)
        if g['sga_completed_action_taken']==None:
            g['sga_completed_action_taken']=" "
        
        if g['sga_completed_action_date']==None:
            g['sga_completed_action_date'] = " "

        if g['sga_completed_action_by_who_per_id']:
            g['action_completed_by_who']= Person.objects.filter(
                                                per_id = g['sga_completed_action_by_who_per_id']
                                            ).annotate(
                                                full_name=Concat('per_last_name',Value(', '),'per_first_name', output_field = CharField())
                                           ).values_list('full_name', flat=True)[0]            

    if gap.exists():
        return gap
    else:
        return None

# Helper functions

def render_to_pdf(templatename,context_dict={}):
    template = get_template(templatename)
    html  = template.render(context_dict)
    result = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode("UTF-8", "ignore")), result)
    if not pdf.err:
        return result.getvalue()
    return None

def attach_pdf_to_incident(incident_id,incident_number, filename, created_by, modified_by, label):
   
    filetype = '.pdf'
    files = []
    files.append(filename)
    UplaodImageView.add_document_to_library_from_system(UplaodImageView,label, incident_id, incident_number, files, created_by, modified_by)
    if incident_id:
        update_incident(incident_id, modified_by)

def does_field_exist_in_dataset(field, dct):

    if field in dct:
        return dct[field]
    else:
        dct[field] = ""
        return ""

def get_yes_no_na(num, transArray):    

    if num=='-1':
        return  transArray[1381] #  '1381' # 'N/A'
    elif num=='0':
        return transArray[1380]  #'1380'  # 'No'
    elif num=='1':
        return transArray[1379]  #'1379' # 'Yes'



def get_ok_defective_na(num):
    if num=='-1':
        return '1381' #  'N/A'
    elif num=='0':
        return '1440' # 'Defective'
    elif num=='1':
        return '1405' # OK

def save_to_file(path, filename, context, pdf):

    if os.path.exists(path) == False:
            os.mkdir(path)
    fn = os.path.join(path, filename)
    with open(fn, 'wb+') as dest:
        dest.write(pdf)

def generate_template_pictures(data, timestamp_label, url_label, comment_label):
    picoutput = "<tr>"
    if data:
        for x, pic in enumerate(data):
            com = str(pic[comment_label]) if comment_label in pic else ""
            picoutput += '<td>' + str(pic[timestamp_label]) + '<br /><img class="actionImage" src="'  \
                + pic[url_label] + '">' + '<br />' + com + '</td>'
            if (x+1) % 4 == 0:
                picoutput += "</tr><tr>"
        picoutput += '<td><img class="actionImage"></td></tr>'
    else:
        picoutput += '<td> No Data Available </td></tr>'
    return picoutput
