from django.db import connection
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.incident_management.api.utlity_function import dictfetchall
from apps.common_utils.views.validate_permission import RolePermission, PersonAccessPermission
from apps.incident_management.models import Incident_Signoffs, Incidents, Incidentsubmissions
from apps.sofvie_user_authorization.api.permissions import SofviePermission, \
    SofvieBasePermissionMixin
from apps.sofvie_user_authorization.models import AuthRoleSofvie


class InsertNewIncident(APIView):    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)
    def post(self, request):
        request_user = self.request.user
        person = request_user.user_per_id
        created_by = person.per_id
        incident_number = request.data['IncidentNumber']

        existing_incidents_check = Incidents.objects.filter(incidentnumber=incident_number).count()

        if incident_number and existing_incidents_check > 0:
            return Response({"message":"Incident Exists"}, status=status.HTTP_200_OK)
        
        args = [incident_number, created_by]
        with connection.cursor() as cursor:
            # result = cursor.callproc('sp_CreateNewIncident', args)

            result = cursor.execute('call sp_CreateNewIncident(@NewIncidentID,%s,%s)', (args))

            cursor.execute('select @NewIncidentID')
            inc = cursor.fetchall()
        
        # grab new incident id from above result and add records into incident_signoffs for all aro_id's with aro_signoff_default True from auth_role_sofvie table.         
        newIncidentID = inc[0][0]
        # get aro_id's with aro_signoff_default True from auth_role_sofvie
        role_ids = AuthRoleSofvie.objects.filter(aro_signoff_default = True, aro_enable = True).values_list('aro_id', flat=True)

        # add records for each role id into Incident_Signoffs
        Incident_Signoffs.objects.bulk_create([
                    Incident_Signoffs(
                        iso_incident_id = newIncidentID,
                        iso_role_id = role,
                        iso_created_by_per = person
                    ) for role in role_ids
                ])

        return Response(inc, status=status.HTTP_201_CREATED)



class GetHeaderidsExistsInIncidentSubmissions(APIView):
    permission_classes = [SofviePermission]
    def post(self, request):
        submissionids = request.data
        form_submission_exists = Incidentsubmissions.objects.filter(submissionheaderid__in = submissionids).count()
        return Response({"count":form_submission_exists}, status=status.HTTP_200_OK)