from django.template.defaultfilters import slugify
from apps.common_utils.views.get_logo import getClientLogo
from apps.rmm_pra.models import RmmPraMaster
from ssl import ALERT_DESCRIPTION_PROTOCOL_VERSION
from apps.imageupload.api.views.views import UplaodImageView
from datetime import datetime
from io import BytesIO
from django.contrib.auth.models import User
from django.db.models.expressions import OuterRef, Ref, Subquery
from django.http.response import HttpResponse

from apps.language.models import Language, LanguageTranslation
from apps.reflist.models import RefListDetail
from apps.common_utils.views.get_translations import get_translation
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.generics import ListAPIView, RetrieveAPIView
from django.template.loader import get_template
from django.conf import settings
import os
from apps.rmm_bowtie.api.serializers.serializer import RmmBowtieMasterSerializer
from apps.rmm_bowtie.models import RmmBowtieMaster, RmmBowtieRootCause
from apps.person.models import Person
from apps.person.models import Person
from django.db.models import Value, CharField
from django.db.models.functions import Concat
from decouple import config
from django.forms import model_to_dict
from apps.user_settings_profile.models import UserProfile
from apps.rmm_bowtie.api.views.bowtie_html_report import RmmBowtieGetDetailReport
from apps.rmm_jra.models import RmmJraMaster
from apps.rmm_ora.models import RmmOraMaster
from apps.rmm_jra.api.serializers.serializer import RmmJraMasterSerializer
from apps.rmm_ora.api.serializers.serializer import RmmOraMasterSerializer
import requests
import urllib.request, json
from apps.incident_management.api.views.attachments_helper_functions import attach_pdf_to_incident, render_to_pdf, modify_general_actions, modify_hazard_actions, save_ra_attachment, save_to_file, translate_measures

def generateORAPdf(self, list_ora, person, translations, lng_id, *args, **kwargs):
    '''
    input list_ora:[1,2,3]
    '''    
    # lng_id = 1
    reports = []
    # ltr_ids = []
    filenames = []
    data = dict()
    data['translate'] = translations
    for ora in list_ora:
        get_ora = RmmOraMaster.objects.get(rmm_ora_id = ora)
        temp_ora = model_to_dict(get_ora)        
        site_ref = RefListDetail.objects.get(rld_id = get_ora.rmm_ora_site_id)             
        temp_ora['rmm_ora_site'] = LanguageTranslation.objects.get(ltr_tag = site_ref.rld_name, ltr_tag_type = site_ref.rld_tag_type, ltr_lng = lng_id).ltr_text
        temp_ora['rmm_ora_created_by_per'] = Person.objects.get(per_id = get_ora.rmm_ora_created_by_per_id).full_name
        temp_ora['doc_number'] = f"{temp_ora['rmm_ora_document_number']}.{temp_ora['rmm_ora_doc_version_number']}"
        temp_ora['rmm_ora_created_date'] = get_ora.rmm_ora_created_date
        step_data = []
        for step in get_ora.event_categories.filter(rmm_oec_enable=True):
            row = model_to_dict(step)
            oec_ref = RefListDetail.objects.get(rld_id = row['rmm_oec_category'])             
            row['rmm_oec_category'] = LanguageTranslation.objects.get(ltr_tag = oec_ref.rld_name, ltr_tag_type = oec_ref.rld_tag_type, ltr_lng = lng_id).ltr_text
            row["events"] = []
            for index, ev in enumerate(step.events.filter(rmm_oev_enable=True)):                
                row["events"].append(translate_measures(self, model_to_dict(ev), lng_id))
                row["events"][index]["control_measures"] = []
                row["events"][index]["additional_control_measures"] = []
                for tag in ev.tags.filter(rmm_ota_enable=True):
                    row["events"][index][tag.rmm_ota_parent_tag_name].append(model_to_dict(tag))
            step_data.append(row)
        
        # participants
        participants = get_ora.participants.filter(rmm_orp_enable=True).annotate(
                full_name=Concat(
                    "rmm_orp_per__per_first_name", Value(" "),
                    "rmm_orp_per__per_last_name", output_field=CharField(),
                    )
                ).values_list("full_name", flat=True)
        # approvers
        approvers = get_ora.approvers.filter(
            rmm_oap_enable=True
            ).annotate(
                full_name=Concat(
                    "rmm_oap_per__per_first_name", Value(" "),
                    "rmm_oap_per__per_last_name", output_field=CharField(),
                    )
                ).values('rmm_oap_id', "full_name", "rmm_oap_per", "rmm_oap_approved_date", "rmm_oap_approved")
        # reviewers
        get_ref_list = get_ora.rmm_ore_ora_master.annotate(
                            tag = Subquery(RefListDetail.objects.filter(rld_id = OuterRef('rmm_ore_position')).values('rld_name')[:1]),
                            tag_type = Subquery(RefListDetail.objects.filter(rld_id = OuterRef('rmm_ore_position')).values('rld_tag_type')[:1])            
                        ).values()
        reviewers = get_ref_list.annotate(
                        rmm_ore_position_name = Subquery(LanguageTranslation.objects.filter(ltr_tag = OuterRef('tag'), ltr_tag_type = OuterRef('tag_type'), ltr_lng_id = lng_id).values('ltr_text')[:1]),
                        reviewer_name = Concat('rmm_ore_per__per_first_name',
                                               Value(' '),
                                               'rmm_ore_per__per_last_name',
                                               output_field=CharField(),)
                    ).values(
                        "rmm_ore_per_id",
                        "rmm_ore_position_name",
                        "rmm_ore_created_date",
                        'reviewer_name'
                    )


        data['header'] = temp_ora
        data['stepdata'] = step_data
        data['participants'] = participants
        data['approvers'] = approvers
        data['reviewers'] = reviewers

        data['general_actions'] = get_ora.get_sga_and_attachments(person)
        data['hazard_actions'] = get_ora.get_ha_and_attachments(person)
        data['logolocation'] = getClientLogo()
        
        if data['hazard_actions']:
            data['hazard_actions'] = modify_hazard_actions(self, list(data['hazard_actions']), 'attachmenttype', lng_id)
        if data['general_actions']:
            data['general_actions'] = modify_general_actions(self, list(data['general_actions']), 'gaa_type', lng_id)
        reports.append(data.copy())        

        pdf = render_to_pdf('ora_pdf.html',data)
        if pdf:
            filename = save_ra_attachment(pdf, temp_ora['rmm_ora_created_by_per'], data['translate'][2279], self.incident_number)
            filenames.append(filename)
    
    attach_pdf_to_incident(self.incidentid,self.incident_number, filenames, self.request.user.user_per_id_id, self.request.user.user_per_id_id, 3668) # Risk Assessments and Procedures

    return reports

