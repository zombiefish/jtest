"""
get incidnet header id - take incidnet id and return submission header details
"""

from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import F, DateField
from django.db.models.functions import Cast
from apps.common_utils.views.validate_permission import RolePermission
from apps.general_action.models import Submissionheader

from apps.sofvie_user_authorization.api.permissions import SofviePermission
from  apps.incident_management.models import Incidents,  Incidentsubmissions

class GetIncidentHeader(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)

    def get(self, request, incident_id):

        submission_header_id = Incidentsubmissions.objects.filter(incidentid=incident_id).first()       

        submission_header_details = Submissionheader.objects.filter(
            id=submission_header_id.submissionheaderid.id
        ).annotate(
            Header_date=Cast('headerdate', output_field=DateField()),
        ).values(
            'site',
            'jobnumber',
            'sitelevel',
            'workplace',
            'supervisor',            
            'Header_date',
        )
        
        return Response({"submission_header": submission_header_details})

class GetIncidentSubmissionHeaderId(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageIncidents.value,)

    def get(self, request, incident_id):
        submission_header_id = Incidentsubmissions.objects.filter(incidentid=incident_id).values('submissionheaderid').latest('id')
        return Response(submission_header_id)