from django.urls import path

from apps.incident_management.api.views.archive_root_cause_analyses import \
    ArchiveRootCauseAnalyses
from apps.incident_management.api.views.get_incident_linked import IncidentsCountByHeaderId
from apps.incident_management.api.views.incident_get_role_list import IncidentGetRolesList
from apps.incident_management.api.views.incident_home import GetOpenIncidentCountByPersonSite
from apps.incident_management.api.views.incident_home import GetIncidentBreakDownByPersonDate

from apps.incident_management.api.views.incident_form_list import \
    IncidentFormListView
from apps.incident_management.api.views.incident_list import IncidentListView
from apps.incident_management.api.views.insert_new_incident import \
    GetHeaderidsExistsInIncidentSubmissions, InsertNewIncident
from apps.incident_management.api.views.incident_assign_submission import \
    AssignSubmissionToIncident
from apps.incident_management.api.views.remove_immediate_cause import \
    RemoveImmediateCause
from apps.incident_management.api.views.remove_basic_cause import RemoveBasicCause
from apps.incident_management.api.views.remove_submissions_from_incident import \
    RemoveSubmissionsFromIncident
from apps.incident_management.api.views.unassigned_incident_list import \
    IncidentManagementListView
from apps.incident_management.api.views.incident_attachments import \
    GetIncidentAttachments, DeleteIncidentAttachments, RenameIncidentAttachments  
from apps.incident_management.api.views.incident_list import GetIncidentFormSubmissionsByHeaderIds
from apps.incident_management.api.views.incident_rca import GetIncidentRCAByIncidentId, GetRcaReviewersList, ReviewRootCauseAnalysis
from apps.incident_management.api.views.incident_action import GetIncidentActionsByIncidentId
from apps.incident_management.api.views.incident_rca import UpsertRootCauseAnalysis
from apps.incident_management.api.views.incident_rca import GetRootCauseAnalysisEdit_RootCauseId
from apps.incident_management.api.views.incident_signoffs import CreateQuickSignOff, GetIncidentSignoffs, AddIncidentSignoff, GetQuickSignOffInfo, RemoveIncidentSignoff, ClearIncidentSignoffs, ValidateSignOff
from apps.incident_management.api.views.incident_action import CreateHAP
from apps.incident_management.api.views.incident_training_records import ObtainTrainingRecords
from apps.incident_management.api.views.get_all_incidents_count import GetAllIncidentsCounts
from apps.incident_management.api.views.get_all_preops import GetAllPreops
from apps.incident_management.api.views.get_all_preops import GetAllPretasks
from apps.incident_management.api.views.output_preop_pretask_pdf import GeneratePreOpPDF,GeneratePreTaskPDF
from apps.incident_management.api.views.generate_ra_pdf import GenerateRAPDF
from apps.incident_management.api.views.add_incident_roles import AddIncidentRoles
from apps.incident_management.api.views.get_incident_header import GetIncidentHeader,GetIncidentSubmissionHeaderId
from apps.incident_management.api.views.update_incident import UpdateIncident

urlpatterns = [
    path('get-open-incident-count-by-person_site_date/', GetOpenIncidentCountByPersonSite.as_view()),
    path('get-incident-breakdown-by-person_site_date/', GetIncidentBreakDownByPersonDate.as_view()),
    path('unassigned-incident-list/', IncidentManagementListView.as_view()),
    path('incident-list/', IncidentListView.as_view()),
    path('incident-attachments/', GetIncidentAttachments.as_view()),
    path('delete-incident-attachments/', DeleteIncidentAttachments.as_view()),   
    path('rename-incident-attachments/', RenameIncidentAttachments.as_view()),      
    path('insert-new-incident/', InsertNewIncident.as_view()),
    path('remove-submissions-from-incident/', RemoveSubmissionsFromIncident.as_view()),
    path('archive-root-cause-analyses/', ArchiveRootCauseAnalyses.as_view()),
    path('assign-submission-to-incident/', AssignSubmissionToIncident.as_view()),
    path('incident-form-list/<str:lang>/', IncidentFormListView.as_view()),
    path('get-incident-form-submissions-by-header-ids/', GetIncidentFormSubmissionsByHeaderIds.as_view()),
    path('get-incident-rca_by_incident_id/',GetIncidentRCAByIncidentId.as_view()),
    path('get-incident-action-by-incident-id/',GetIncidentActionsByIncidentId.as_view()),
    path('upsert-root-cause-analysis/',UpsertRootCauseAnalysis.as_view()),
    path('get-root-cause-analysis-edit-rca-id/',GetRootCauseAnalysisEdit_RootCauseId.as_view()),
    path('get-incident-signoffs/', GetIncidentSignoffs.as_view()),
    path('add-incident-signoffs/', AddIncidentSignoff.as_view()),
    path('remove-incident-signoffs/', RemoveIncidentSignoff.as_view()),
    path('clear-incident-signoffs/', ClearIncidentSignoffs.as_view()),
    path('create-hap/', CreateHAP.as_view()),
    path('remove-immediate-cause/', RemoveImmediateCause.as_view()),
    path('remove-basic-cause/', RemoveBasicCause.as_view()),
    path('obtain-training-records/', ObtainTrainingRecords.as_view()),
    path('get-all-incidents-counts/', GetAllIncidentsCounts.as_view()),
    path('get-all-pretasks/', GetAllPretasks.as_view()),
    path('get-all-preops/', GetAllPreops.as_view()),
    path("pretaskpdf/", GeneratePreTaskPDF.as_view()),
    path("preoppdf/", GeneratePreOpPDF.as_view()),
    path("generate-ra-pdf/", GenerateRAPDF.as_view()),
    path("add-incident-roles/", AddIncidentRoles.as_view()),
    path("incident-get-role-list/", IncidentGetRolesList.as_view()),
    path("validate-signoff/", ValidateSignOff.as_view()),
    path("get-incident-header/<int:incident_id>/", GetIncidentHeader.as_view()),
    path("get-incident-header-id/<int:incident_id>/", GetIncidentSubmissionHeaderId.as_view()),
    path("create-quick-signoff/", CreateQuickSignOff.as_view()),
    path("get-quick-signoff-info/", GetQuickSignOffInfo.as_view()),
    path("get-incidents-count-by-headerid/", IncidentsCountByHeaderId.as_view()),
    path("get-headerids-exists-in-incidentsubmissions/", GetHeaderidsExistsInIncidentSubmissions.as_view()),
    path("get-rca-reviewers-list/<int:rca_id>/", GetRcaReviewersList.as_view()),
    path("review-rca/", ReviewRootCauseAnalysis.as_view()),    
    path("update-incident/", UpdateIncident.as_view()),
]
# GeneratePreTaskPDF