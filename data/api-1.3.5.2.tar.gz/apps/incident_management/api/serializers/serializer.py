from rest_framework import serializers
from rest_framework.serializers import ModelSerializer
from django.forms import model_to_dict

from apps.incident_management.models import GetAllPreopsMaster

from datetime import datetime
from apps.person.models import Person


class PreOpsSerializer(ModelSerializer):

    class Meta:
        model = PreopSubmissionHeader
        fields = [
            "SubmissionHeaderID",
            "psh_created_date",
            "EquipmentIdentifier",
            "psh_created_by_per_id",
        ]

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        ret['SubmittedBy_SupervisorID'] = \
            instance.SubmissionHeaderID.submittedby_supervisorid
        ret['Site'] = instance.SubmissionHeaderID.site
        return ret
