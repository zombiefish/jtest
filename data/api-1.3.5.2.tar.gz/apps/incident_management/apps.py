from django.apps import AppConfig


class IncidentManagementConfig(AppConfig):
    name = 'apps.incident_management'
