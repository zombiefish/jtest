from django.db import models
from django.db.models import (
    Model,
    AutoField,
    IntegerField,
    CharField,
    DateTimeField,
    ForeignKey,
    ManyToManyField,
    BooleanField,
    TextField,
    DateField,
    DecimalField,
    F, Value, Subquery, OuterRef
)
# Create your models here.
from apps.general_action.models import Submissionheader
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.models import AuthRoleSofvie


from apps.common_utils.views.sofvieModelFields import SofvieCharField, SofvieIntegerField, SofvieEmailField, SofvieTextField


class Incidents(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    incidentnumber = SofvieCharField(db_column='IncidentNumber', max_length=50)  # Field name made lowercase.
    inc_is_quick_signoff = BooleanField(default=False)
    creationdate = models.DateTimeField(db_column='CreationDate')  # Field name made lowercase.
    createdby = SofvieCharField(db_column='CreatedBy', max_length=100)  # Field name made lowercase.
    lastmodified = models.DateTimeField(db_column='LastModified', blank=True, null=True)  # Field name made lowercase.
    lastmodifiedby = models.ForeignKey(Person, null=True, blank=True,
                                    db_column='LastModifiedBy',
                                    on_delete=models.DO_NOTHING,
                                    related_name='incidents_last_modified_by',)

    class Meta:
        db_table = 'Incidents'


class Incidentsubmissions(models.Model):
    id = models.AutoField(primary_key=True)
    incidentid = models.ForeignKey(Incidents, db_column='IncidentID',
                                   on_delete=models.DO_NOTHING,
                                   related_name='incident')  ## Field name made   # lowercase.
    submissionheaderid = models.ForeignKey(Submissionheader,
                                           models.DO_NOTHING,
                                           db_column='SubmissionHeaderID',
                                           related_name='incident_submissionheader'
                                           )  # Field name made lowercase.

    class Meta:
        db_table = 'IncidentSubmissions'
        unique_together = (('incidentid', 'submissionheaderid'),)


class Rootcauseanalysis(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase. 
    incidentid = models.ForeignKey(Incidents, db_column='IncidentID', related_name='root_cause_incident',
                                   on_delete=models.DO_NOTHING)  # Field name made lowercase.
    preliminarytypeid = models.ForeignKey(RefListDetail, db_column='PreliminaryTypeID', blank=True, null=True,
                                    related_name='ref_preliminary_type', on_delete=models.DO_NOTHING)  # Field name made lowercase.
    potentiallossid = models.ForeignKey(RefListDetail, db_column='PotentialLossID', blank=True, null=True,
                                    related_name='ref_potential_loss', on_delete=models.DO_NOTHING)  # Field name made lowercase.
    actualtypeid = models.ForeignKey(RefListDetail, db_column='ActualTypeID', blank=True, null=True,
                                     related_name='ref_actual_type', on_delete=models.DO_NOTHING)  # Field name made lowercase.
    eventdetails = models.TextField(db_column='EventDetails', blank=True, null=True)  # Field name made lowercase.
    investigationfindings = models.TextField(db_column='InvestigationFindings', blank=True, null=True)  # Field name made lowercase.
    submissiondate = models.DateTimeField(db_column='SubmissionDate', blank=True, null=True)  # Field name made lowercase.
    submittedby = models.ForeignKey(Person, db_column='SubmittedBy', on_delete=models.DO_NOTHING, related_name='rca_submittedby_per_id')  # Field name made lowercase.
    lastupdated = models.DateTimeField(db_column='LastUpdated', blank=True, null=True)  # Field name made lowercase.
    lastupdatedby = models.ForeignKey(Person, db_column='LastUpdatedBy', blank=True, null=True, on_delete=models.DO_NOTHING, related_name='rca_lastupdatedby_per_id')  # Field name made lowercase.
    isarchived = models.BooleanField(db_column='IsArchived', blank=True, null=True)  # Field name made lowercase. This field type is a guess.
    incidenttypeid = models.ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,
                                       related_name='ref_incident_type' ,db_column='IncidentTypeID', blank=True, null=True)  # Field name made lowercase.
    preliminaryincidenttypecategoryid = models.ForeignKey(RefListDetail, db_column='PreliminaryIncidentTypeCategoryID', blank=True, null=True,
                                    related_name='ref_preliminary_incident_category', on_delete=models.DO_NOTHING)  # Field name made lowercase.
    preliminaryincidenttypedetailid = models.ForeignKey(RefListDetail, db_column='PreliminaryIncidentTypeDetailID', blank=True, null=True,
                                    related_name='ref_preliminary_incident_detail', on_delete=models.DO_NOTHING)  # Field name made lowercase.
    actualincidenttypecategoryid = models.ForeignKey(RefListDetail, db_column='ActualIncidentTypeCategoryID', blank=True, null=True,
                                    related_name='ref_actual_incident_category', on_delete=models.DO_NOTHING)  # Field name made lowercase.
    actualincidenttypedetailid = models.ForeignKey(RefListDetail, db_column='ActualIncidentTypeDetailID', blank=True, null=True,
                                    related_name='ref_actual_incident_detail', on_delete=models.DO_NOTHING)  # Field name made lowercase.
    
    class Meta:
        managed = True
        db_table = 'RootCauseAnalysis'

class Incident_Signoffs(Model):
    iso_id = AutoField(primary_key=True)
    iso_incident = ForeignKey(Incidents, blank=False, null=False, on_delete=models.DO_NOTHING, related_name='incidents', help_text="ForeignKey from Incidents Table")
    iso_role = ForeignKey(AuthRoleSofvie, blank=False, null=True, on_delete=models.DO_NOTHING, related_name='incident_role', help_text="ForeignKey from AuthRoleSofvie Table")
    iso_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, related_name='incident_signoff_per_id', help_text="ForeignKey from person Table")
    iso_signoff_datetime = DateTimeField(blank=True, null=True)
    iso_created_date = DateTimeField(auto_now_add=True)
    iso_created_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, related_name='incident_signoff_createdby_per_id', help_text="ForeignKey from person Table")
    iso_modified_date = DateTimeField(blank=True, null=True)
    iso_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, related_name='incident_signoff_modifiedby_per_id', help_text="ForeignKey from person Table")
    iso_enable = BooleanField(default=True)
    iso_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'incident_signoffs'       
    
class Incident_Quick_Signoff_Note(models.Model):
    iqn_id = AutoField(primary_key=True)
    iqn_incident = ForeignKey(Incidents, blank=True, null=True, on_delete=models.DO_NOTHING, related_name='incident_quick_signoff_note_iqn_incident_id', help_text="ForeignKey from Incidents Table")
    iqn_note = SofvieTextField(blank=True, null=True)
    iqn_created_date = DateTimeField(auto_now_add=True)
    iqn_created_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, related_name='incident_quick_signoff_note_createdby_per_id', help_text="ForeignKey from person Table")
    iqn_modified_date = DateTimeField(blank=True, null=True)
    iqn_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, related_name='incident_quick_signoff_note_modifiedby_per_id', help_text="ForeignKey from person Table")
    iqn_enable = BooleanField(default=True)
    iqn_enote = SofvieTextField(blank=True, null=True)
    class Meta:
        db_table = 'incident_quick_signoff_note'

class Incident_Quick_Signoff_Role(models.Model):
    iqs_id = AutoField(primary_key=True)
    iqs_iqn = ForeignKey(Incident_Quick_Signoff_Note, blank=False, null=False, on_delete=models.DO_NOTHING, related_name='incident_quick_signoff_role_iqs_iqn_id', help_text="ForeignKey from Incident_Quick_Signoff_Note Table")
    iqs_aro = ForeignKey(AuthRoleSofvie, blank=False, null=False, on_delete=models.DO_NOTHING, related_name='incident_quick_signoff_role_iqs_aro_id', help_text="ForeignKey from AuthRoleSofvie Table")
    iqs_created_date = DateTimeField(auto_now_add=True)
    iqs_created_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, related_name='incident_quick_signoff_role_createdby_per_id', help_text="ForeignKey from person Table")
    iqs_modified_date = DateTimeField(blank=True, null=True)
    iqs_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, related_name='incident_quick_signoff_role_modifiedby_per_id', help_text="ForeignKey from person Table")
    iqs_enable = BooleanField(default=True)
    iqs_enote = SofvieTextField(blank=True, null=True)
    class Meta:
        db_table = 'incident_quick_signoff_role'