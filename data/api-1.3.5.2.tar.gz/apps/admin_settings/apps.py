from django.apps import AppConfig


class AdminSettingsConfig(AppConfig):
    name = 'apps.admin_settings'
