from django.db import models
from django.db.models import (
    Model,
    ForeignKey,
    AutoField,
    DateTimeField,
    BooleanField,
    TextField
)


from apps.common_utils.views.sofvieModelFields import (
    SofvieCharField,
    SofvieIntegerField,
    SofvieTextField
)
from apps.person.models import Person


class ClientLogo(Model):
    clo_id = AutoField(primary_key=True)
    clo_image = SofvieTextField(allow_list=['//'])
    clo_image_file_type = SofvieCharField( max_length= 200)
    clo_is_sofvie_logo = BooleanField(default = False)
    clo_created_date = DateTimeField(auto_now_add=True)
    clo_created_by_per = ForeignKey(Person, blank=False, null=False, on_delete=models.DO_NOTHING, related_name='clo_created_person', help_text='Add the foreign key of logged in person')
    clo_modified_date = DateTimeField(blank=True, null= True)
    clo_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, related_name='clo_modified_person', help_text='Add the foreign key of logged in person')
    clo_enable = BooleanField(default=True)
    clo_enote = SofvieCharField(max_length=200, blank = True, null = True)

    class Meta:
        db_table = 'client_logo'
