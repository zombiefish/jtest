from django.db.models import Prefetch
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, RetrieveAPIView
from rest_framework.generics import ListCreateAPIView
from apps.common_utils.views.validate_permission import RolePermission


from apps.rmm_pra.api.serializers.serializer import RmmPraMasterSerializer
from apps.rmm_pra.models import RmmPraMaster, RmmPraApprover
from apps.sofvie_user_authorization.api.permissions import SofviePermission



class RmmPraGetGaHaDetail(RetrieveAPIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManagePRA.value,)
    serializer_class = RmmPraMasterSerializer
    action = "list"
    queryset = RmmPraMaster.objects.filter(rmm_pra_enable=True)

    def retrieve(self, request, *args, **kwargs):
        person_id = self.request.user.user_per_id
        obj = self.get_object()
        return Response({"general_actions":obj.get_sga_and_attachments(person_id), "hazard_actions": obj.get_ha_and_attachments(person_id)})

    # this is the response
