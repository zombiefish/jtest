from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.generics import CreateAPIView
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView

from django.db.models import F, Subquery, OuterRef
from apps.common_utils.views.validate_permission import RolePermission
from apps.language.models import Language, LanguageTranslation

# from apps.rmm_jra.api.serializers.serializer import RmmJraGetPraTitleSerializer
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user.models import User
from apps.person.models import Person
from apps.rmm_jra.models import RmmJraMaster
from apps.rmm_ora.models import RmmOraEventCategory
from apps.rmm_ora.api.serializers.serializer import RmmOraEventCategoriesSerializer

from operator import itemgetter

from apps.user_settings_profile.models import UserProfile


class RmmPraGetOraEventList(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManagePRA.value,)
    

    def get(self, request, rmm_ora_id):

        person_id = self.request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per= person_id).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)



        queryset = RmmOraEventCategory.objects.filter(
            rmm_oec_ora=rmm_ora_id, 
            rmm_oec_enable=True
        ).annotate(
            category_ltr_tag = F('rmm_oec_category__rld_name'),
            category_ltr_tag_type = F('rmm_oec_category__rld_tag_type'),
        ).values(
            'rmm_oec_id',
            'category_ltr_tag',
            'category_ltr_tag_type',
        )

        queryset = queryset.annotate(
            category_name = Subquery(
                LanguageTranslation.objects.filter(
                    ltr_tag=OuterRef('category_ltr_tag'), 
                    ltr_tag_type=OuterRef('category_ltr_tag_type'), 
                    ltr_lng = lng_id
                ).values('ltr_text')[:1]
            )
        ).values(
            'rmm_oec_id',
            'category_name'
        )
        return Response({"data":queryset})