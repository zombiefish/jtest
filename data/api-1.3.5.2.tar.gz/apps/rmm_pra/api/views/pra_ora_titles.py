from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.generics import CreateAPIView
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView

from django.db.models import Q
from django.db.models import Max
from apps.common_utils.views.validate_permission import RolePermission

# from apps.rmm_jra.api.serializers.serializer import RmmJraGetPraTitleSerializer
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user.models import User
from apps.person.models import Person
from apps.rmm_jra.models import RmmJraMaster
from apps.rmm_ora.models import RmmOraMaster
from apps.rmm_pra.api.serializers.serializer import RmmPraMasterSerializer


class RmmPraGetOraTitleList(APIView):
    # pass
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManagePRA.value,)

    def get(self, request):

        queryset = RmmOraMaster.objects.filter(rmm_ora_enable=True, rmm_ora_state='active').values('rmm_ora_id', 'rmm_ora_title').order_by('rmm_ora_title')      
        # serializer = RmmJraGetPraTitleSerializer(queryset, many=True)
        return Response({"data":queryset})
