from datetime import datetime
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db import transaction
from apps.attachments.models import RmmAttachments
from apps.comments.models import Comments
from apps.rmm_pra.models import RmmPraMaster, RmmPraGeneralAction,RmmPraHazardAction
from apps.hazard_action.models import Submissionhap
from apps.general_action.models import SubmissionGeneralAction, Submissionheader
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.common_utils.views.validate_permission import RolePermission

class RmmPraArchive(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewPRA.value,)

    @transaction.atomic
    def post(self, request):
        person_id = self.request.user.user_per_id_id
        payload_data = request.data
        pra_ids = []
        for rmm_pra in payload_data:
            pra_ids.append(rmm_pra['rmm_pra_id'])

        permission = SofviePermission()
        self.permission_attrs = (RolePermission.ArchiveSubmissions.value,)
        hasPermission = permission.has_permission(request, self)
        archive = None
        if not hasPermission:
            own_draft_pra_ids = RmmPraMaster.objects.filter(
                rmm_pra_id__in=pra_ids,
                rmm_pra_created_by_per_id = person_id,
                rmm_pra_state = 'draft'
            ).values_list('rmm_pra_id', flat=True)

            if own_draft_pra_ids:                
                # archive only own_draft_jra_ids 
                archive = archive_pra(self, own_draft_pra_ids, person_id)

                archive_message = 'Archived own draft submissions successfully'
            else:
                return Response(' You are not allowed to archive this submission')           
        else:
            # archive all submissions
            archive = archive_pra(self, pra_ids, person_id)
            archive_message = 'Archived successfully'
        
        if archive == True:
            return Response({'message': archive_message}, status = status.HTTP_200_OK)
        else:
            return Response({'message': f'Archive failed.\n{archive}'}, status = status.HTTP_400_BAD_REQUEST)       


def archive_pra(self, pra_ids, person_id):

    try:
        # archive rmm pra
        RmmPraMaster.objects.filter(rmm_pra_id__in=pra_ids).update(
                rmm_pra_enable=0, rmm_pra_modified_by_per_id=person_id,
                rmm_pra_archived_date = datetime.now(),
                rmm_pra_archived_by_per_id = person_id
            )
        # archive general action reference in pra
        RmmPraGeneralAction.objects.filter(rmm_pga_pra__in=pra_ids).update(
            rmm_pga_enable=0, rmm_pga_modified_by_per_id=person_id)
        
        # archive sga associated with pra
        SubmissionGeneralAction.objects.filter(
            rmm_pga_sga_id__rmm_pga_pra__in=pra_ids
        ).update(
            sga_enable=0,
            sga_modified_by_per_id=person_id,
            sga_archived_date = datetime.now(),
            sga_archived_by_per_id = person_id
        )

        ga_sh_ids = SubmissionGeneralAction.objects.filter(
            rmm_pga_sga_id__rmm_pga_pra__in=pra_ids
        ).values_list('sga_submission_header_id')

        Submissionheader.objects.filter(
            id__in = ga_sh_ids
        ).update(
            isarchived=True,
            archiveddate=datetime.now(),
            archived_by_per=person_id
        )


        # archive hazard action reference in pra

        RmmPraHazardAction.objects.filter(rmm_pha_pra__in=pra_ids).update(
            rmm_pha_enable=0, rmm_pha_modified_by_per_id=person_id)
        
        # archive submission hap associated with pra
        Submissionhap.objects.filter(
            rmm_pha_sha_id__rmm_pha_pra__in=pra_ids
        ).update(
            sha_enable=0,
            sha_modified_by_per_id=person_id,
            sha_archived_date = datetime.now(),
            sha_archived_by_per_id = person_id
        )

        ha_sh_ids = Submissionhap.objects.filter(
            rmm_pha_sha_id__rmm_pha_pra__in=pra_ids
        ).values_list('submissionheaderid_id')

        Submissionheader.objects.filter(
            id__in = ha_sh_ids
        ).update(
            isarchived=True,
            archiveddate=datetime.now(),
            archived_by_per=person_id
        )

        rmmAttachment_instances=RmmAttachments.objects.filter(rat_rmm_id__in=pra_ids, rat_enable=True).values()
        for rmmAttachment_instance in rmmAttachment_instances:
            Comments.objects.filter(com_reference_id=rmmAttachment_instance['rat_id'],com_cmt_id=rmmAttachment_instance['rat_mod_id'],com_enable=True).update(com_enable=False, com_modified_date= datetime.now(),com_modified_by_per_id=person_id)

        RmmAttachments.objects.filter(rat_rmm_id__in=pra_ids).update(rat_enable=False, rat_modified_date = datetime.now(),rat_modified_by_per_id=person_id)
        
        return True
    
    except Exception as e:
        return e
