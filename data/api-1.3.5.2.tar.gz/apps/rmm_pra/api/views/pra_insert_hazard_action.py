from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.generics import CreateAPIView
from django.db import transaction
from apps.common_utils.views.validate_permission import RolePermission

from apps.rmm_pra.models import RmmPraHazardAction
from apps.sofvie_user_authorization.api.permissions import SofviePermission

class RmmAddPraHazardAction(CreateAPIView):
    permission_classes=[SofviePermission]
    permission_attrs = (RolePermission.CanManagePRA.value,)
    
    def post(self, request, *args, **kwargs):
        
        try:

            self.person_instance = self.request.user.user_per_id
            self.pra_id = request.data.pop('rmm_pha_pra', None)
            self.sha_ids = request.data.pop('rmm_pha_sha', [])

            bulk_create_pra_hazard_action(self)

            return Response({"Message": "Successfully added hazard action to selected PRA."}, status=status.HTTP_200_OK)

        except Exception as e:

            return Response({"Message": f"Failed to add hazard action to selected PRA. {e}"}, status=status.HTTP_400_BAD_REQUEST)


@transaction.atomic
def bulk_create_pra_hazard_action(self):

    bulk_create_object = [RmmPraHazardAction(
        rmm_pha_pra_id = self.pra_id,
        rmm_pha_created_by_per = self.person_instance,
        rmm_pha_sha_id = sha_id
    ) for sha_id in self.sha_ids]
    
    RmmPraHazardAction.objects.bulk_create(bulk_create_object)