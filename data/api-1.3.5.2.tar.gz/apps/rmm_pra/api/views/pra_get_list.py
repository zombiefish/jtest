import datetime

from django.db.models import Prefetch, F, Q
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.incident_management.api.utlity_function import dictfetchall
from apps.rmm_ora.api.date_filter_utils import date_filter
from apps.rmm_pra.api.serializers.serializer import RmmPraMasterSerializer
from apps.rmm_pra.models import RmmPraMaster, RmmPraApprover
from apps.employee.helper_function_user_visibility import helperEmployeeSites
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class RmmPraGetList(ListAPIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewPRA.value,RolePermission.CanViewIncidents.value)
    all_permissions = False
    serializer_class = RmmPraMasterSerializer

    def get_queryset(self):
        start_date = self.request.data['start_date']
        end_date = self.request.data['end_date']
        person_id = self.request.user.user_per_id        
        get_sites, data_user_visibility = helperEmployeeSites(self, person_id)               
        site_list = [site['rld_id'] for site in get_sites]

        site_filters = []
        if data_user_visibility !='all':
            site_filters=[Q(rmm_pra_site__in=site_list) | Q(rmm_pra_site__isnull=True) | Q(rmm_pra_created_by_per=person_id)]

        queryset = RmmPraMaster.objects.filter(
                            *site_filters,                            
                            rmm_pra_enable=True,
                            rmm_pra_created_date__range=(date_filter(start_date, end_date)
                            )).prefetch_related(
            Prefetch('approvers',RmmPraApprover.objects.all().select_related('rmm_pap_per')),
            'participants', 'rmm_pre_pra_master')
        return queryset

    def get_serializer_context(self):
        context = super(RmmPraGetList, self).get_serializer_context()
        context["read"] = True
        return context

    def post(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)
    
