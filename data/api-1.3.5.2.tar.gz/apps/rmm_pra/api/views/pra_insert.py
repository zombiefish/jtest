from datetime import datetime
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import CreateAPIView
from django.db.models import Max
from apps.common_utils.views.validate_permission import RolePermission
from apps.rmm_pra.models import RmmPraMaster
from apps.rmm_ora.models import RmmOraMaster
from apps.rmm_pra.api.serializers.serializer import RmmPraMasterSerializer

from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user.models import User
from apps.person.models import Person

    
class RmmPraInsert(CreateAPIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManagePRA.value,)
    serializer_class = RmmPraMasterSerializer