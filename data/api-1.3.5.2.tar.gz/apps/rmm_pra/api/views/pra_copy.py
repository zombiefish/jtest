from django.db import transaction
from django.db.models import Prefetch, Max

from rest_framework.exceptions import ValidationError
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from rest_framework.generics import ListAPIView, ListCreateAPIView, RetrieveAPIView, UpdateAPIView, CreateAPIView
from apps.attachments.models import RmmAttachments
from apps.comments.models import Comments
from apps.common_utils.views.validate_permission import RolePermission

# from apps.rmm_ora.api.serializers.serializer import RmmOraMasterSerializer
from apps.rmm_pra.api.serializers.serializer import RmmPraMasterSerializer
from apps.rmm_pra.models import RmmPraMaster, RmmPraApprover, RmmPraGeneralAction, RmmPraHazardAction
from apps.rmm_ora.models import RmmOraEvent
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class RmmPraCopy(CreateAPIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManagePRA.value,)
    
    serializer_class = RmmPraMasterSerializer
    action = "retrieve"
    def get_queryset(self):
        return RmmPraMaster.objects.all()

    @transaction.atomic
    def create(self, request, pk, mode, *args, **kwargs):
        instance = self.get_object()
        context = self.get_serializer_context()
        context["read"] = 'copy_revision'
        context["read_actions"] = False
        serializer = RmmPraMasterSerializer(instance, context=context)
        data = serializer.data

        rmm_attachments= RmmAttachments.objects.filter(rat_rmm_id=data['rmm_pra_id'], rat_enable=True).values()

        del data['rmm_pra_id']
        if data["rmm_pra_state"]=="expired":
            data["rmm_pra_expiry_date"] = None
        del data['dlo_enable']
        del data['reviewers']
        data['approvers'] = [a["rmm_pap_per"] for a in data["approvers"]]
        data['ora_events'] = [RmmOraEvent.objects.get(rmm_oev_id=oe) for oe in data['ora_events']]
        if mode=="copy":
            del data["rmm_pra_document_number"]
            data["rmm_pra_doc_version_number"] = 1
            data["rmm_pra_state"] = 'draft'

        elif mode=="revision":

            if instance.rmm_pra_state == "draft":
                raise ValidationError("Can't make revision from draft document")
            else:
                draft_exists = RmmPraMaster.objects.filter(rmm_pra_document_number=instance.rmm_pra_document_number, rmm_pra_enable=True, rmm_pra_state='draft').exists()
                if draft_exists:
                    raise ValidationError("draft version of this document already exists")
                instance.save()     
            max_version_number = RmmPraMaster.objects.filter(rmm_pra_document_number=instance.rmm_pra_document_number).aggregate(Max("rmm_pra_doc_version_number"))
            data["rmm_pra_doc_version_number"] = max_version_number["rmm_pra_doc_version_number__max"] + 1
            data["rmm_pra_state"] = 'draft'
        else:
            raise ValidationError({"mode":"Invalid mode. Only allowed mode is copy/revision."})

        data["rmm_pra_site_id"] = data["rmm_pra_site"]
        data["rmm_pra_ora_id"] = data["rmm_pra_ora"]
        data["rmm_pra_created_by_per_id"] = request.user.user_per_id_id
        data["rmm_pra_created_by_per"] = request.user.user_per_id.full_name
        del data["rmm_pra_site"]
        del data["rmm_pra_ora"]

        for index, ev_c in enumerate(data["element_categories"]):
            del data["element_categories"][index]["rmm_pec_id"]
            del data["element_categories"][index]["rmm_pec_modified_by_per"]
            data["element_categories"][index]["rmm_pec_element"] = data["element_categories"][index].pop("rmm_pec_element")

            for e_index, ev in enumerate(data["element_categories"][index]["threats"]):
                data["element_categories"][index]["threats"][e_index]["rmm_pth_likelyhood_preliminary_id"] = data["element_categories"][index]["threats"][
                    e_index].pop("rmm_pth_likelyhood_preliminary")
                data["element_categories"][index]["threats"][e_index]["rmm_pth_severity_preliminary_id"] = data["element_categories"][index]["threats"][
                    e_index].pop("rmm_pth_severity_preliminary")
                data["element_categories"][index]["threats"][e_index]["rmm_pth_likelyhood_residual_id"] = data["element_categories"][index]["threats"][
                    e_index].pop("rmm_pth_likelyhood_residual")
                data["element_categories"][index]["threats"][e_index]["rmm_pth_severity_residual_id"] = data["element_categories"][index]["threats"][
                    e_index].pop("rmm_pth_severity_residual")
                data["element_categories"][index]["threats"][e_index]["rmm_pth_risk_category_id"] = data["element_categories"][index]["threats"][
                    e_index].pop("rmm_pth_risk_category")
                data["element_categories"][index]["threats"][e_index]["rmm_pth_severity_to_risk_id"] = data["element_categories"][index]["threats"][
                    e_index].pop("rmm_pth_severity_to_risk")
                del data["element_categories"][index]["threats"][e_index]["rmm_pth_id"]
                del data["element_categories"][index]["threats"][e_index]["rmm_pth_modified_by_per"]
                for t_index, o in enumerate(data["element_categories"][index]["threats"][e_index]["control_measures"]):
                    del data["element_categories"][index]["threats"][e_index]["control_measures"][t_index]["rmm_pta_id"]
                for t_index, o in enumerate(data["element_categories"][index]["threats"][e_index]["additional_control_measures"]):
                    del data["element_categories"][index]["threats"][e_index]["additional_control_measures"][t_index]["rmm_pta_id"]

        instance = serializer.create(data)

        for rmm_attachment in rmm_attachments:            
            new_rmm_attachment = {}
            new_rmm_attachment["rat_id"] = None
            new_rmm_attachment['rat_rmm_id'] = instance.rmm_pra_id
            new_rmm_attachment['rat_mod_id'] = rmm_attachment["rat_mod_id"]
            new_rmm_attachment['rat_file_name'] = rmm_attachment["rat_file_name"]
            new_rmm_attachment['rat_created_by_per'] = request.user.user_per_id
            attachments_instance=RmmAttachments.objects.create(**new_rmm_attachment)
            copy_revision_comments(rmm_attachment['rat_id'],attachments_instance.rat_id,rmm_attachment["rat_mod_id"])
        return Response({"Message": "Document copied.", "new_doc_id": instance.rmm_pra_id})

def copy_revision_comments(reference_id, new_reference_id,mod_id):
    '''
    get comments for reference id matching com_reference_id
    create new entries for all the comments
    '''
    comments = Comments.objects.filter(
        com_cmt_id=mod_id, 
        com_reference_id = reference_id,
        com_enable = True
    ).values()

    new_comments_obj = []
    for comment in comments:
        new_comment= {}
        new_comment['com_id'] = None
        new_comment['com_cmt_id'] = mod_id  
        new_comment['com_reference_id'] = new_reference_id
        new_comment['com_comment'] = comment['com_comment']
        new_comment['com_created_by_per_id'] = comment['com_created_by_per_id']
        new_comment['com_created_date'] = comment['com_created_date']
        new_comment['com_enable'] = comment['com_enable']
        new_comments_obj.append(Comments(**new_comment))
    Comments.objects.bulk_create(new_comments_obj)  




