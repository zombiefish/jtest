from django.contrib import admin

# Register your models here.
from apps.rmm_pra.models import *

admin.site.register(RmmPraMaster)
admin.site.register(RmmPraParticipant)
admin.site.register(RmmPraApprover)
admin.site.register(RmmPraGeneralAction)
admin.site.register(RmmPraHazardAction)
admin.site.register(RmmPraElementCategory)
admin.site.register(RmmPraThreat)
admin.site.register(RmmPraTags)
admin.site.register(RmmPraOraEvent)
# admin.site.register(RmmPraBowtieAssessment)


