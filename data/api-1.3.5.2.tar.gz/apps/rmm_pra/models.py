from decimal import Decimal
from datetime import date
from django.db import models
from django.db.models import (
    Model,
    AutoField,
    IntegerField,
    CharField,
    DateTimeField,
    ForeignKey,
    ManyToManyField,
    BooleanField,
    TextField,
    DateField,
    DecimalField,
    F, Value, Subquery, OuterRef
)

# Create your models here.
from django.utils import timezone
from django.db.models.functions import Concat, Substr
from apps.common_utils.views.common_global_functions import modify_ga_data, modify_ha_data
from apps.common_utils.views.sofvieModelFields import SofvieCharField, SofvieIntegerField, SofvieTextField
from apps.person.models import Person
from apps.rmm_ora.models import RmmOraMaster, RmmOraEvent
from apps.reflist.models import RefListDetail
from apps.general_action.models import SubmissionGeneralAction, SubmissionGeneralActionAttachment, SubmissionGeneralActionCompletedPerson, SubmissionGeneralActionCompletion, SubmissionGeneralActionPerson
from apps.hazard_action.models import Submissionhap, Submissionhapattachments
from apps.rmm_bowtie.models import RmmBowtieMaster
from apps.user_settings_profile.models import UserProfile
from apps.language.models import LanguageTranslation, Language
# Generating the document number

def get_doc_serial(document_number=None):
    if document_number:
        document_number = Decimal(document_number)
        document_number += Decimal("0.1")
        #document_number = str(document_number).zfill(7)
        return document_number
    try:
        last_obj = RmmPraMaster.objects.all().latest('rmm_ora_created_date')
        document_number = int(last_obj.rmm_ora_document_number)
        document_number += 1
        #document_number = str(document_number).zfill(6)
        return document_number
    except RmmPraMaster.DoesNotExist:
        return "1"

class RmmPraMaster(models.Model):
    rmm_pra_id = AutoField(primary_key=True)
    rmm_pra_document_number = SofvieIntegerField(help_text="Unique document number.", null=True)
    rmm_pra_doc_version_number = SofvieIntegerField(help_text="DocumentRevisionNumber", null=True)
    rmm_pra_title = SofvieCharField(max_length=70, db_index=True, blank=True, null=True)
    rmm_pra_scope = SofvieTextField(blank=True, null=True)
    rmm_pra_date = DateField(blank=True, null=True)
    rmm_pra_expiry_date = DateField(blank=True, null=True)
    rmm_pra_site = ForeignKey(RefListDetail, blank=True, null=True,
                              related_name='rmm_pra_site_id',
                              on_delete=models.DO_NOTHING,
                              help_text="ForeignKey from ref_list_detail Table")
    rmm_pra_workplace = SofvieCharField(max_length=255, blank=True, null=True)
    rmm_pra_other_participants = SofvieCharField(max_length=255, blank=True, null=True)
    rmm_pra_state = SofvieCharField(max_length=31, default='draft')
    rmm_pra_submitted_date = DateTimeField(blank=True, null=True)
    rmm_pra_executive_summary = SofvieTextField(blank=True, null=True,)
    rmm_pra_ora = ForeignKey(RmmOraMaster, blank=True, null=True,
                              related_name='rmm_pra_ora_id',
                              on_delete=models.DO_NOTHING,
                              help_text="Get Ora ID from rmm_pra")
    rmm_pra_created_date = DateTimeField(auto_now_add=True)
    rmm_pra_created_by_per = ForeignKey(Person, blank=False, null=True,
                                        related_name='rmm_pra_created_by_per_id',
                                        on_delete=models.DO_NOTHING,
                                        help_text="ForeignKey from person "
                                                  "Table")
    rmm_pra_modified_date = DateTimeField(blank=True, null=True) # make sure it will null BM
    rmm_pra_modified_by_per = ForeignKey(Person, blank=True, null=True,
                                         related_name='rmm_pra_modified_by_per_id',
                                         on_delete=models.DO_NOTHING,
                                         help_text="ForeignKey from person "
                                                   "Table")
    rmm_pra_archived_date = DateTimeField(blank=True, null=True) # make sure it will null BM
    rmm_pra_archived_by_per = ForeignKey(Person, blank=True, null=True,
                                         related_name='rmm_pra_archived_by_per_id',
                                         on_delete=models.DO_NOTHING,
                                         help_text="ForeignKey from person "
                                                   "Table")                                                
    rmm_pra_enable = BooleanField(default=True)
    rmm_pra_enote = SofvieTextField(blank=True, null=True)
    
    class Meta:
        db_table = 'rmm_pra'
        verbose_name = 'Project Risk Assessment'

    def only_mandatory_reviewers(self):
        return RmmPraApprover.objects.filter(rmm_pap_pra = self.rmm_pra_id, rmm_pap_enable=1)

    def __str__(self):
        return self.rmm_pra_created_by_per.full_name

    def get_sga_and_attachments(self, person_id):
        obj = self
        ga_data = obj.general_actions.filter(rmm_pga_enable=True, rmm_pga_sga_id__sga_enable=True).annotate(
            sga_recommended_action=F("rmm_pga_sga_id__sga_recommended_action"),
            sga_action_by_when=F("rmm_pga_sga_id__sga_action_by_when"),
            sga_id=F("rmm_pga_sga_id__sga_id"),
            sga_submission_header=F("rmm_pga_sga_id__sga_submission_header"),
            job = F('rmm_pga_sga_id__sga_submission_header__jobnumber'),
            level = F('rmm_pga_sga_id__sga_submission_header__sitelevel'),
            workplace = F('rmm_pga_sga_id__sga_submission_header__workplace'),
            supervisor = F('rmm_pga_sga_id__sga_submission_header__supervisor'),
            tag_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('rmm_pga_sga_id__sga_submission_header__site')).values('rld_name')[:1]
                ),
            tagtype_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('rmm_pga_sga_id__sga_submission_header__site')).values('rld_tag_type')[:1]
                ),
            sga_action_type_rld_id=F("rmm_pga_sga_id__sga_action_type_rld_id"),
            sga_completed_action_type_rld_id=F("rmm_pga_sga_id__sga_completed_action_type_rld_id"),
            sga_completed_action_date=F("rmm_pga_sga_id__sga_completed_action_date"),
            sga_completed_action_taken=F("rmm_pga_sga_id__sga_completed_action_taken"),
            sga_created_date=F("rmm_pga_sga_id__sga_created_date"),
            sga_created_by_per=F("rmm_pga_sga_id__sga_created_by_per"),
            sga_modified_date=F("rmm_pga_sga_id__sga_modified_date"),
            sga_modified_by_per=F("rmm_pga_sga_id__sga_modified_by_per"),
            sga_enable=F("rmm_pga_sga_id__sga_enable")).values()
        lng_name = UserProfile.objects.get(upr_per= person_id).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)
        ga_data = ga_data.annotate(
            site = Subquery(
                        LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_site'),ltr_tag_type=OuterRef('tagtype_rld_id_site'), ltr_lng = lng_id).values('ltr_text')[:1]
                    ),
        )
        
        ga_data = modify_ga_data(ga_data)

        return ga_data

    def get_ha_and_attachments(self, person_id):
        obj = self
        ha_data = obj.hazard_actions.filter(rmm_pha_enable=True, rmm_pha_sha_id__sha_enable=True).annotate(
            id=F("rmm_pha_sha_id__id"),
            submissionheaderid=F("rmm_pha_sha_id__submissionheaderid"),
            tag_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('rmm_pha_sha_id__submissionheaderid__site')).values('rld_name')[:1]
                ),
            tagtype_rld_id_site = Subquery(
                    RefListDetail.objects.filter(rld_id=OuterRef('rmm_pha_sha_id__submissionheaderid__site')).values('rld_tag_type')[:1]
                ),
            hazard_type=F("rmm_pha_sha_id__hazard_type"),
            hazard_identification=F("rmm_pha_sha_id__hazard_identification"),
            hazard_description=F("rmm_pha_sha_id__hazard_description"),
            potential_risk=F("rmm_pha_sha_id__potential_risk"),
            immediate_action_required_and_performed=F("rmm_pha_sha_id__immediate_action_required_and_performed"),
            immediate_action_taken=F("rmm_pha_sha_id__immediate_action_taken"),
            immediate_action_type=F("rmm_pha_sha_id__immediate_action_type"),
            further_action_required=F("rmm_pha_sha_id__further_action_required"),
            recommended_action=F("rmm_pha_sha_id__recommended_action"),
            action_type=F("rmm_pha_sha_id__action_type"),
            action_by_when=F("rmm_pha_sha_id__action_by_when"),
            action_completed_date=F("rmm_pha_sha_id__action_completed_date"),
            completed_action_taken=F("rmm_pha_sha_id__completed_action_taken"),
            completed_action_type=F("rmm_pha_sha_id__completed_action_type"),
            hazard_identification_score=F("rmm_pha_sha_id__hazard_identification_score"),
            potential_risk_score=F("rmm_pha_sha_id__potential_risk_score"),
            immediate_action_score=F("rmm_pha_sha_id__immediate_action_score"),
            completed_action_score=F("rmm_pha_sha_id__completed_action_score"),
            is_native_system=F("rmm_pha_sha_id__is_native_system"),
            sha_created_date=F("rmm_pha_sha_id__sha_created_date"),
            created_by=F("rmm_pha_sha_id__sha_created_by_per"),
            sha_created_by_per=F("rmm_pha_sha_id__sha_created_by_per"),
            sha_modified_date=F("rmm_pha_sha_id__sha_modified_date"),
            sha_modified_by_per=F("rmm_pha_sha_id__sha_modified_by_per"),
            sha_enable=F("rmm_pha_sha_id__sha_enable"), ).values()
        lng_name = UserProfile.objects.get(upr_per= person_id).upr_language
        lng_id = Language.objects.get(lng_name = lng_name)
        ha_data = ha_data.annotate(
            site = Subquery(LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_site'),ltr_tag_type=OuterRef('tagtype_rld_id_site'), ltr_lng = lng_id).values('ltr_text')[:1]),
            created_by=Subquery(Person.objects.filter(per_id=OuterRef('sha_created_by_per')).annotate(created_by = Concat('per_last_name',Value(', '), 'per_first_name',output_field = CharField())).values('created_by')[:1])
        )

        ha_data = modify_ha_data(ha_data)

        return ha_data


class RmmPraParticipant(Model):
    rmm_prp_id = AutoField(primary_key=True)
    rmm_prp_pra = ForeignKey(RmmPraMaster, blank=False, null=False, on_delete=models.DO_NOTHING,
                             related_name='participants')
    rmm_prp_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
                             related_name='rmm_prp_per_id',
                             help_text="ForeignKey from person/employee Table")
    rmm_prp_created_date = DateTimeField("Created Date", auto_now_add=True)
    rmm_prp_created_by_per = ForeignKey(Person, blank=False, null=False, on_delete=models.DO_NOTHING,
                                        related_name='rmm_prp_created_by_per_id',
                                        help_text="ForeignKey from person "
                                                  "Table")
    rmm_prp_submitted_by_per = ForeignKey(Person, blank=True, null=True,
                                          on_delete=models.DO_NOTHING,
                                          related_name='rmm_prp_submitted_by_per_id',
                                          help_text="ForeignKey from person "
                                                    "Table")
    rmm_prp_submitted_date = DateTimeField("Submitted date",
                                           blank=True, null=True)
    rmm_prp_modified_date = DateTimeField(blank=True, null=True)
    rmm_prp_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
                                         related_name='rmm_prp_modified_by_per_id',
                                         help_text="ForeignKey from person "
                                                   "Table")
    rmm_prp_enable = BooleanField(default=True)
    rmm_prp_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_pra_participant'
        # get_latest_by = 'rmm_orp_submitted_date'
        # ordering = ['-rmm_orp_submitted_date', 'rmm_orp_submitted_by_per']
        verbose_name = 'Participant'

    def __str__(self):
        return self.rmm_pra_created_by_per.full_name

class RmmPraApprover(Model):
    rmm_pap_id = AutoField(primary_key=True)
    rmm_pap_pra = ForeignKey(RmmPraMaster, blank=False, null=False, on_delete=models.DO_NOTHING,
                             related_name='approvers',
                             help_text='Foreignkey from rmm_ora table')
    rmm_pap_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
                             related_name='rmm_pap_per_id',
                             help_text='Foreignkey from person/employee table')
    rmm_pap_per_position = SofvieIntegerField(null=True, blank=True)
    rmm_pap_approved = BooleanField(default=False)
    rmm_pap_approved_date = DateTimeField("Approved date", auto_now_add=True)
    rmm_pap_submitted_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
                                          related_name='rmm_pap_submitted_by_per_id',
                                          help_text='Foreignkey from person '
                                                    'table')
    rmm_pap_submitted_date = DateTimeField("Submitted date", blank=True, null=True,)
    rmm_pap_created_date = DateTimeField(auto_now_add=True)
    rmm_pap_created_by_per = ForeignKey(Person, blank=False, null=False, on_delete=models.DO_NOTHING,
                                        related_name='rmm_pap_created_by_per_id')
    rmm_pap_modified_date = DateTimeField(blank=True, null=True)
    rmm_pap_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
                                         related_name='rmm_pap_modified_by_per_id',
                                         help_text='Foreignkey from person '
                                                   'table')
    rmm_pap_enable = BooleanField(default=True)
    rmm_pap_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_pra_approver'
        # get_latest_by = 'rmm_oap_submitted_date'
        # ordering = ['-rmm_oap_submitted_date']
        verbose_name = 'Approver'

    def __str__(self):
        return self.rmm_pra_per.full_name

class RmmPraGeneralAction(Model):
    rmm_pga_id = AutoField(primary_key=True)
    rmm_pga_pra = ForeignKey(RmmPraMaster, on_delete=models.DO_NOTHING,
                                related_name='general_actions',
                                help_text='Primary key from rmm_ora table/RmmOraMaster model'
                             )
    rmm_pga_sga = ForeignKey(SubmissionGeneralAction,
                                on_delete=models.DO_NOTHING,
                                related_name='rmm_pga_sga_id',
                                help_text='Primary key from submission_general_action table/SubmissionGeneralAction model',
                                blank=True, null=True
                             )
    rmm_pga_created_date = DateTimeField(auto_now_add=True)
    rmm_pga_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, 
                                           related_name='rmm_pga_created_by_per_id', 
                                           help_text='Primary key from person table/Person model')
    rmm_pga_modified_date = DateTimeField(blank=True, null=True)
    rmm_pga_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, 
                                            related_name='rmm_pga_modified_by_per_id',
                                         help_text='Primary key from person table/Person model')
    rmm_pga_enable = BooleanField(default=True)
    rmm_pga_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_pra_general_action'
        verbose_name = 'General Action'

    # def __str__(self):
    #     return self.rmm_pga_sga

class RmmPraHazardAction(Model):
    rmm_pha_id = AutoField(primary_key=True)
    rmm_pha_pra = ForeignKey(RmmPraMaster, on_delete=models.DO_NOTHING, 
                                related_name='hazard_actions', 
                                help_text='Primary key from rmm_pra table/RmmOraMaster model')
    rmm_pha_sha = ForeignKey(Submissionhap, on_delete=models.DO_NOTHING, 
                                related_name='rmm_pha_sha_id', 
                                help_text='Primary key from SubmissionHap table/Submissionhap model',
                                blank=True, null=True)
    rmm_pha_created_date = DateTimeField(auto_now_add=True)
    rmm_pha_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, 
                                           related_name='rmm_pha_created_by_per_id', 
                                           help_text='Primary key from person table/Person model')
    rmm_pha_modified_date = DateTimeField(blank=True, null=True)
    rmm_pha_modified_by_per = ForeignKey(Person, blank=True, null=True, 
                                            on_delete=models.DO_NOTHING, 
                                            related_name='rmm_pha_modified_by_per_id',
                                            help_text='Primary key from person table/Person model')
    rmm_pha_enable = BooleanField(default=True)
    rmm_pha_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_pra_hazard_action'
        verbose_name = 'Hazard Action'

    def __str__(self):
        return self.rmm_pha_created_by_per.full_name

class RmmPraElementCategory(Model):
    rmm_pec_id = AutoField(primary_key=True)
    rmm_pec_pra = ForeignKey(RmmPraMaster, blank=False, null=False, 
                             on_delete=models.DO_NOTHING, 
                             related_name='element_categories', 
                             help_text='Primary key from rmm_pra table/RmmPraMaster model')
    rmm_pec_element = SofvieCharField(max_length=255, blank=True, null=True)
    rmm_pec_sort = SofvieIntegerField()
    rmm_pec_created_date = DateTimeField(auto_now_add=True)

    rmm_pec_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, 
                                        related_name='rmm_pec_created_by_per_id', 
                                        help_text='Primary key from person table/Person model')
    rmm_pec_modified_date = DateTimeField(blank=True, null=True)
    rmm_pec_modified_by_per = ForeignKey(Person, blank=True, null=True, 
                                         on_delete=models.DO_NOTHING, 
                                         related_name='rmm_pec_modified_by_per_id',
                                         help_text='Primary key from person table/person model')
    rmm_pec_enable = BooleanField(default=True)
    rmm_pec_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_pra_element_category'
        ordering = ['rmm_pec_sort']

        verbose_name = 'ElementCategory'

    def __str__(self):
        return self.rmm_pec_element.rld_name

class RmmPraThreat(Model):
    rmm_pth_id = AutoField(primary_key=True)
    rmm_pth_pec = ForeignKey(RmmPraElementCategory, 
                             on_delete=models.DO_NOTHING, 
                             related_name='threats', 
                             help_text='Primary key from rmm_pra_element_category table/RmmPraSElementCategory model')
    rmm_pth_threat = SofvieTextField(blank=True, null=True)
    rmm_pth_outcome = SofvieTextField(blank=True, null=True)
    rmm_pth_risk_category = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,
                                                related_name='rmm_pth_risk_category',
                                                help_text= 'Primary key from ref_list_detail table/RefListDetail model',
                                                blank=True, null=True)
    rmm_pth_severity_to_risk = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,
                                                related_name='rmm_pth_severity_to_risk',
                                                help_text= 'Primary key from ref_list_detail table/RefListDetail model',
                                                blank=True, null=True)
    rmm_pth_likelyhood_preliminary = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,
                                                related_name='rmm_pth_likelyhood_preliminary',
                                                help_text='Primary key from ref_list_detail table/RefListDetail model',
                                                blank=True, null=True)

    rmm_pth_severity_preliminary = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,
                                              related_name='rmm_pth_severity_preliminary', 
                                              help_text='Primary key from ref_list_detail table/RefListDetail model',
                                              blank=True, null=True)

    # rmm_pth_preliminary_risk = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,
    #                                       related_name='rmm_pth_preliminary_risk', 
    #                                       help_text='Primary key from ref_list_detail table/RefListDetail model')
    rmm_pth_preliminary_risk = SofvieIntegerField(blank=True, null=True)
    rmm_pth_risk_alara_preliminary = BooleanField(default=False, blank=True, null=True)
    rmm_pth_require_bowtie = BooleanField(default=False, blank=True, null=True)
    rmm_pth_likelyhood_residual = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, blank=True, null=True,
                                             related_name='rmm_pth_likelyhood_residual', 
                                             help_text='Primary key from ref_list_detail table/RefListDetail model')

    rmm_pth_severity_residual = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, blank=True, null=True,
                                            related_name='rmm_pth_serverity_residual', 
                                            help_text='Primary key from ref_list_detail table/RefListDetail model')

    # rmm_pth_residual_risk = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING,
    #                                    related_name='rmm_pth_residual_risk', 
    #                                    help_text='Primary key from ref_list_detail table/RefListDetail model')

    rmm_pth_residual_risk = SofvieIntegerField(blank=True, null=True)
    rmm_pth_risk_alara_residual = BooleanField(default=False, blank=True, null=True)
    rmm_pth_created_date = DateTimeField(auto_now_add=True)
    rmm_pth_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, 
                                        related_name='rmm_pth_created_by_per_id', 
                                        help_text='Primary key from person table/Person model')
    rmm_pth_modified_date = DateTimeField(blank=True, null=True)
    rmm_pth_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, 
                                         related_name='rmm_pth_modified_by_per_id',
                                         help_text='Primary key from person table/Person model')
    rmm_pth_enable = BooleanField(default=True, blank=True, null=True)
    rmm_pth_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_pra_threat'
        # get_latest_by = 'rmm_oev_created_date'
        # ordering = ['-rmm_oev_created_date', 'rmm_oev_major_unwanted_event']
        verbose_name = 'RMM PRA Threat'

    # def __str__(self):
    #     return f"{self.rmm_oev_major_unwanted_event}: created on {self.rmm_oev_created_date} by {self.rmm_oev_created_by_per.full_name}"

class RmmPraTags(Model):
    rmm_pta_id = AutoField(primary_key=True)
    rmm_pta_pth = ForeignKey(RmmPraThreat, on_delete=models.DO_NOTHING, 
                                related_name='tags', 
                                help_text='Primary key from rmm_jth table/RmmJRAEvent model')

    rmm_pta_parent_tag_name = SofvieCharField(max_length=30, blank=True, null=True)
    rmm_pta_tag_name = SofvieCharField(max_length=31, blank=True, null=True)
    rmm_pta_blueline = BooleanField(default=False)
    rmm_pta_created_date = DateTimeField(auto_now_add=True)
    rmm_pta_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, 
                                        related_name='rmm_pta_created_by_per_id',
                                        help_text='Primary key from person table/Person model')
    rmm_pta_modified_date = DateTimeField(blank=True, null=True)
    rmm_pta_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, 
                                         related_name='rmm_pta_modified_by_per_id',
                                         help_text='Primary key from person table/Person model')
    rmm_pta_enable = BooleanField(default=True)
    rmm_pta_enote = SofvieTextField(blank=True, null=True)

    #tag - payload from front end
    tag=SofvieCharField(max_length=5000,blank=True, null=True)


    class Meta:
        db_table = 'rmm_pra_tags'
        # get_latest_by = 'rmm_ota_created_date'
        # ordering = ['-rmm_ota_created_date', 'rmm_ota_tag_name']
        verbose_name = 'PRA Tags'

    def __str__(self):
        return self.rmm_jta_tag_name


class RmmPraOraEvent(Model):
    rmm_poe_id = AutoField(primary_key=True)
    rmm_poe_pra = ForeignKey(RmmPraMaster, blank=False, null=False, on_delete=models.DO_NOTHING,
                             related_name='ora_event',
                             help_text='Foreignkey from rmm_pra table')
    rmm_poe_oev = ForeignKey(RmmOraEvent, blank=True, null=True, on_delete=models.DO_NOTHING,
                             related_name='rmm_poe_oev_id',
                             help_text='Foreignkey from PRA Threat table')

    rmm_poe_created_date = DateTimeField(auto_now_add=True)
    rmm_poe_created_by_per = ForeignKey(Person, blank=False, null=False, on_delete=models.DO_NOTHING,
                                        related_name='rmm_poe_created_by_per_id')
    rmm_poe_modified_date = DateTimeField(blank=True, null=True)
    rmm_poe_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
                                         related_name='rrmm_poe_modified_by_per_id',
                                         help_text='Foreignkey from person '
                                                   'table')
    rmm_poe_enable = BooleanField(default=True)
    rmm_poe_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'rmm_pra_ora_event'
        # get_latest_by = 'rmm_oap_submitted_date'
        # ordering = ['-rmm_oap_submitted_date']
        verbose_name = 'PRA ORA ThEvent'

    def __str__(self):
        return self.rmm_jpt_per.full_name

# class RmmPraBowtieAssessment(Model):
#     rmm_prb_id = AutoField(primary_key=True)
#     rmm_prb_ora = ForeignKey(RmmPraMaster, blank=False, null=False, on_delete=models.DO_NOTHING,
#                              related_name='rmm_prb_ora_id',
#                              help_text='Foreignkey from rmm_ora table')
#     rmm_prb_bow = ForeignKey(RmmBowtieMaster, blank=False, null=False, on_delete=models.DO_NOTHING,
#                              related_name='rmm_prb_bow_id',
#                              help_text='Foreignkey from RmmBowtieMaster/rmm_bowtie table')
#     rmm_prb_approved_date = DateTimeField("Approved date", auto_now_add=True)
#     rmm_prb_submitted_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
#                                           related_name='rmm_prb_submitted_by_per_id',
#                                           help_text='Foreignkey from person '
#                                                     'table')
#     rmm_prb_submitted_date = DateTimeField("Submitted date", auto_now_add=True, blank=True, null=True,)
#     rmm_prb_created_date = DateTimeField(auto_now_add=True)
#     rmm_prb_created_by_per = ForeignKey(Person, blank=False, null=False, on_delete=models.DO_NOTHING,
#                                         related_name='rmm_prb_created_by_per_id')
#     rmm_prb_modified_date = DateTimeField(blank=True, null=True)
#     rmm_prb_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING,
#                                          related_name='rmm_prb_modified_by_per_id',
#                                          help_text='Foreignkey from person '
#                                                    'table')
#     rmm_prb_enable = BooleanField(default=True)
#     rmm_prb_enote = SofvieTextField(blank=True, null=True)

#     class Meta:
#         db_table = 'rmm_pra_bowtie_assessment'
#         # get_latest_by = 'rmm_oap_submitted_date'
#         # ordering = ['-rmm_oap_submitted_date']
#         verbose_name = 'Bowtie Assessment'

#     def __str__(self):
#         return self.rmm_prb_bow_per.full_name

class RmmPraReview(Model):
    rmm_pre_id = AutoField(primary_key=True)
    rmm_pre_pra = ForeignKey(RmmPraMaster, on_delete=models.DO_NOTHING, related_name='rmm_pre_pra_master', help_text='Primary key from RmmPraMaster table')
    rmm_pre_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rmm_pre_person',
                             help_text='Primary key from Person table')
    rmm_pre_created_date = DateTimeField(auto_now_add=True)
    rmm_pre_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING,
                                        related_name='rmm_pre_created_by_per',
                                        help_text='Primary key from person table/Person model')
    rmm_pre_modified_date = DateTimeField(blank=True, null=True)
    rmm_pre_modified_by_per = ForeignKey(Person, blank=True, null=True,
                                         on_delete=models.DO_NOTHING, related_name='rmm_pre_modified_by_per',
                                         help_text='Primary key from person table/Person model')
    rmm_pre_enable = BooleanField(default=True)
    rmm_pre_enote = SofvieTextField(blank=True, null=True)
    rmm_pre_position = SofvieIntegerField(null=True, blank=True)
 

    class Meta:
        db_table = 'rmm_pra_review'
        verbose_name = 'PRA Review'