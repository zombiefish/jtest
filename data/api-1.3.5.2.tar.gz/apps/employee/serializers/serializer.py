from django.db import  transaction
from django.db.models import Value, Max, F
from django.db.models.functions import Concat
from rest_framework import serializers
from rest_framework.permissions import SAFE_METHODS
from rest_framework.relations import StringRelatedField
from rest_framework.serializers import ModelSerializer
from django.forms import model_to_dict
from datetime import datetime

from apps.person.models import Person
from apps.employee.models import Employee, EmployeeCustomSiteJob
from apps.reflist.models import RefListDetail

class EmployeeCustomSiteJobSerializer(ModelSerializer):

    esj_created_by_per = StringRelatedField()

    class Meta:
        model = EmployeeCustomSiteJob
        fields = '__all__'