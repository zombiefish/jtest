from django.test import TestCase

# Create your tests here.
# Create your tests here.
from apps.employee.models import Employee
from apps.person.models import Person
from apps.user.models import User


class MinimalEmployeeCreationTest(TestCase):

    def setUp(self):
        person_valid_data = {
            'per_first_name': "John",
            'per_last_name': "Doe",
            "per_created_by_per_id_id": 1,
            "per_modified_by_per_id_id": 1
        }
        user_valid_data = {
            'email': "webdeveloper@magtechpro.com",

        }

        person = Person.objects.create(**person_valid_data
                                       )

        employee_valid_data_list = [
            {
                'emp_employee_number': "100",
                "emp_per": person,
                "emp_pos_id": 100,
                "emp_reports_to_per":person,
                "emp_created_by_per":person,
                "emp_modified_by_per":person,
            },
        ]
        for employee_data in employee_valid_data_list:
            Employee.objects.create(**employee_data)

    def test_emp_employee_number(self):
        employee = Employee.objects.get(emp_id=1)
        self.assertEqual("100", employee.emp_employee_number)
