
from django.db import connection
from django.db.models import F, Subquery
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user.models import User
from apps.sofvie_user_authorization.models import AuthRolePermissionMappingSofive, AuthUserRoleMappingSofive
from apps.employee.models import Employee
from apps.person.models import Person
from apps.employee.helper_function_user_visibility import helperEmployeeJobs, helperEmployeeSites
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from apps.incident_management.api.utlity_function import dictfetchall
from itertools import chain
from unidecode import unidecode
from apps.common_utils.views.common_global_functions import titlekey

import pandas as pd
import re
        
class GetEmployees(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def get(self, request, role):

        per_id = self.request.user.user_per_id_id
        data_visibility_type = Employee.objects.get(emp_per_id = per_id).emp_data_visibility

        output_employee_list = []

        activeUsers_string = active_users(role)   

        output_employee_list = get_employees_list(self, per_id, activeUsers_string, data_visibility_type)       
        output_employee_list = sorted(output_employee_list,  key=titlekey)

        return Response({"Employee_list":output_employee_list, "data_visbility": data_visibility_type})


def active_users(role):
    if role == 'supervisor':
        with connection.cursor() as cursor:                
            cursor.execute("call get_supervisor_person_id()")
            activeUsers = dictfetchall(cursor)
    elif role == 'human-resource':
        with connection.cursor() as cursor:                
            cursor.execute("call get_human_resources_person_id()")
            activeUsers = dictfetchall(cursor)
    elif role == 'training':
        with connection.cursor() as cursor:                
            cursor.execute("call get_training_person_id()")
            activeUsers = dictfetchall(cursor)
    elif role == 'distribution':
        with connection.cursor() as cursor:
            cursor.execute("call get_distribution_person_id()")
            activeUsers = dictfetchall(cursor)
    elif role == 'rmm-ora':
        # get per_ids who has access to manage rmm-ora
        rmm_permission_list = [
            RolePermission.CanManageORA.value
        ]
        activeUsers = get_per_ids_on_permissions(rmm_permission_list)
    
    elif role == 'rmm-jra':
        # get per_ids who has access to manage rmm-jra
        rmm_permission_list = [
            RolePermission.CanManageJRA.value
        ]
        activeUsers = get_per_ids_on_permissions(rmm_permission_list)
    elif role == 'rmm-pra':
        # get per_ids who has access to manage rmm-pra
        rmm_permission_list = [
            RolePermission.CanManagePRA.value,
        ]
        activeUsers = get_per_ids_on_permissions(rmm_permission_list)
    elif role == 'rmm-bowtie':
        # get per_ids who has access to manage rmm-bowtie
        rmm_permission_list = [
            RolePermission.CanManageBowtie.value
        ]
        activeUsers = get_per_ids_on_permissions(rmm_permission_list)       

    elif role == 'include-disable':
        with connection.cursor() as cursor:
            cursor.execute("call get_all_person_id_ever()")
            activeUsers = dictfetchall(cursor)

    elif role == 'all':
        with connection.cursor() as cursor:
            cursor.execute("call get_all_person_id()")
            activeUsers = dictfetchall(cursor)
    else:
        return Response({"Employee_list":"Invalid Endpoint URL"}) 
    activeUsers_string = (',').join(str(act_user['per_id']) for act_user in activeUsers)

    return activeUsers_string

def get_employees_list(self, per_id, activeUsers_string, data_visibility_type):
    output_employee_list = []
    output_employee_list_all = []
    output_employee_list_profile = []
    output_employee_list_custom = []  
    if activeUsers_string == '':
        return output_employee_list
    if data_visibility_type == 'all':        
        with connection.cursor() as cursor:

            all_employees = []            
            cursor.execute("call get_employee_list_data_visibility_filter_by_all(%s)", (activeUsers_string,))
            all_employees = dictfetchall(cursor)                         
            output_employee_list = all_employees
    else:          
        logged_in_user_jobs_obj, placeholder = helperEmployeeJobs(self, per_id)
        logged_in_user_sites_obj, placeholder = helperEmployeeSites(self, per_id)

        logged_in_user_sites = [str(site['rld_id']) for site in logged_in_user_sites_obj]
        logged_in_user_jobs = [str(job['rld_id']) for job in logged_in_user_jobs_obj]

        output_employee_list_profile = get_profile_userVisibility_emp_list(activeUsers_string,logged_in_user_jobs,logged_in_user_sites)
        output_employee_list_custom = get_custom_userVisibility_emp_list(activeUsers_string,logged_in_user_jobs,logged_in_user_sites)
        output_employee_list_all = get_all_userVisibility_emp_list(activeUsers_string, logged_in_user_jobs, logged_in_user_sites)

        output_employee_list = list(chain(output_employee_list_profile,output_employee_list_custom,output_employee_list_all))

    return output_employee_list

def get_profile_userVisibility_emp_list(activeUsers_string, logged_in_user_jobs, logged_in_user_sites):
    output_employee_list_profile = []
    employees_jobs_profile_list = []
    with connection.cursor() as cursor:
        cursor.execute("call get_profile_user_visibility_emp_list(%s)", (activeUsers_string,))
        employees_jobs_profile_list = dictfetchall(cursor)
    df = pd.DataFrame(employees_jobs_profile_list)
    if df.empty:
        return output_employee_list_profile
        
    df = df.fillna('')
    df['user_applicable_for_site'] = df.sites_without_jobs.apply(lambda x: 1 if set(logged_in_user_sites).intersection(x.split(',')) else 0)

    df['user_applicable_for_job'] = df.employee_jobs.apply(lambda x: 1 if set(logged_in_user_jobs).intersection(x.split(',')) else 0)

    df = df[(df['user_applicable_for_job']==1) | (df['user_applicable_for_site']==1)]

    df = df[['per_id', 'employee_number', 'per_full_name', 'email', 'employee_sites', 'is_active', 'employee_jobs', 'emp_data_visibility']]    
    output_employee_list_profile = df.to_dict(orient='records')
    return output_employee_list_profile

def get_custom_userVisibility_emp_list(activeUsers_string, logged_in_user_jobs, logged_in_user_sites):
    output_employee_list_custom = []
    with connection.cursor() as cursor:
        cursor.execute("call get_custom_user_visibility_emp_list(%s)", (activeUsers_string,))
        employees_jobs_custom_list= dictfetchall(cursor)
    df = pd.DataFrame(employees_jobs_custom_list)
    if df.empty:
        return output_employee_list_custom
    
    df = df.fillna('')

    df['user_applicable_for_site'] = df.sites_without_jobs.apply(lambda x: 1 if set(logged_in_user_sites).intersection(x.split(',')) else 0)
    
    df['user_applicable_for_job'] = df.employee_jobs.apply(lambda x: 1 if set(logged_in_user_jobs).intersection(x.split(',')) else 0)
    
    df = df[(df['user_applicable_for_job']==1) | (df['user_applicable_for_site']==1)]
    df = df[['per_id', 'employee_number', 'per_full_name', 'email', 'employee_sites', 'is_active', 'employee_jobs', 'emp_data_visibility']]    

    output_employee_list_custom = df.to_dict(orient='records')
    return output_employee_list_custom

def get_all_userVisibility_emp_list(activeUsers_string, logged_in_user_jobs, logged_in_user_sites):
    output_employee_list_all = []
    if logged_in_user_sites:
        with connection.cursor() as cursor:
            cursor.execute("call get_all_user_visibility_emp_list(%s)", (activeUsers_string,))
            output_employee_list_all = dictfetchall(cursor)
    return output_employee_list_all

        

def get_per_ids_on_permissions(permission_list):
    activeUsers = Employee.objects.exclude(
        emp_per_id = 1
    ).filter(
        emp_per_id__in = Subquery(
            AuthRolePermissionMappingSofive.objects.prefetch_related(
                'arp_aro_id__sofvie_auth_user_role_mappings'            
            ).filter(
                arp_ape_id__in = permission_list,
                arp_enable = True
            ).annotate(
                per_id = F('arp_aro_id__sofvie_auth_user_role_mappings__aur_user_id__user_per_id')
            ).values_list('per_id', flat = True)
        ),
        emp_enable = True,
        emp_per__per_enable = True
    ).annotate(
        per_id = F('emp_per_id')
    ).values('per_id')

    return activeUsers