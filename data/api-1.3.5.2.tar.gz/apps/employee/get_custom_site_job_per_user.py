from django.db.models import Prefetch, F
from django.db.models.expressions import OuterRef, Subquery
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, ListCreateAPIView, RetrieveAPIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.employee.models import EmployeeCustomSiteJob, Employee
from datetime import datetime
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from django.forms import model_to_dict
from itertools import groupby 
from operator import itemgetter 
from django.db import connection
from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from apps.language.models import Language, LanguageTranslation




class GetCustomSiteJobPerUser(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewUsers.value,)

    def post(self, request):

        person = self.request.user.user_per_id_id # to get logged in user profile language. 
        lng_name = UserProfile.objects.get(upr_per_id=person).upr_language
        lang = Language.objects.get(lng_name=lng_name).lng_id

        with connection.cursor() as cursor:

            cursor.execute('call get_custom_site_job_per_user(%s)', (lang,))
            all_sites_jobs = dictfetchall(cursor)

        get_active_sites = RefListDetail.objects.filter(rld_enable = True, rld_deleted = False, rld_rlh_id = 1).values('rld_id', 'rld_name', 'rld_tag_type')        

        missing_sites = list(set([each['rld_id'] for each in get_active_sites]).difference([each['site_id'] for each in all_sites_jobs]))
        
        for each in missing_sites:
            site_data = next((x for x in get_active_sites if x['rld_id'] == each), None)
            all_sites_jobs.append({                
                "site_id": each,
                "site_description":LanguageTranslation.objects.filter(ltr_tag = site_data['rld_name'], ltr_tag_type = site_data['rld_tag_type'], ltr_lng = lang ).values_list('ltr_text', flat=True)[0],
                "enable": False
            })        


        #request.data['emp_id'] receving from front end
        person_id_payload = request.data['emp_id']        
        
        if(not person_id_payload):
            for item in all_sites_jobs:                
                item['enable'] = False
            return Response(all_sites_jobs)
        
        # getting emp_id from Employee table as for some users emp_id and per_id are not same.
        employee_id = Employee.objects.get(emp_per=person_id_payload).emp_id #using person_emp in user_sites_jobs ORM query to filter employee_custom_site_job with employee id

        user_sites_jobs = EmployeeCustomSiteJob.objects.select_related('esj_site_rld_id', 'esj_job_rld_id').filter(
            esj_emp_id=employee_id, esj_enable=True, esj_site_rld_id__rld_deleted=False, esj_site_rld_id__rld_enable=True).annotate(
            job_id=F('esj_job_rld_id'),
            job_description=F('esj_job_rld_id__rld_name'),
            site_id=F('esj_site_rld_id'),
            site_description=F('esj_site_rld_id__rld_name'),
            enable=F('esj_enable')
        ).values('job_id', 'job_description', 'site_id', 'site_description', 'enable').order_by('-esj_site_rld_id')

        for item in all_sites_jobs:
            if item['enable'] == 0:
                item['enable'] = False
            for each in user_sites_jobs:                
                if 'job_id' in item and item['job_id'] == each['job_id']:                    
                    item['enable'] = each['enable']
                elif 'job_id' not in item and item['site_id'] == each['site_id']:
                    item['enable'] = True



        return Response(all_sites_jobs)
