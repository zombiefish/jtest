from django.urls import path
from apps.employee import views
from apps.employee.create_or_update_custom_site_job_per_user import CreateUpdateCustomSiteJob
from apps.employee.get_custom_site_job_per_user import GetCustomSiteJobPerUser
from apps.employee.get_filtered_site_job import GetFilteredSiteJob
from apps.employee.get_employees import GetEmployees
from apps.employee.views import GetActivePersonList

urlpatterns = [
    path('get-employee-list/', views.GetEmployeeList.as_view()),
    path('get-all-employee-list/', views.GetAllEmployeeList.as_view()),
    path('get-employee-list-profile/', views.GetEmployeeListProfile.as_view()),
    path('get-full-employee-list-profile/<str:mode>/', views.GetFullEmployeeListProfile.as_view()),
    path('create-or-update-custom-site-job-per-user/<int:per_id>/', CreateUpdateCustomSiteJob.as_view()),
    path('get-custom-site-job-per-user/', GetCustomSiteJobPerUser.as_view()),
    path('get-filtered-site-job/<str:mode>/', GetFilteredSiteJob.as_view()),
    path('get-employee-list-uv/<str:role>/', GetEmployees.as_view()),
    path('get-active-person-list/', GetActivePersonList.as_view()),
]