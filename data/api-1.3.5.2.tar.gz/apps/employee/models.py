from datetime import datetime
from django.db import models
from django.db.models import (
    Model,
    AutoField,
    IntegerField,
    CharField,
    DateTimeField,
    ForeignKey,
    DO_NOTHING,
    ManyToManyField,
    BooleanField,
    TextField,
    DateField,
    SlugField,
    DecimalField, F, Value
)
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.common_utils.views.sofvieModelFields import(
    SofvieCharField,
    SofvieIntegerField,
    SofvieTextField
)

#
from apps.reflist.models import RefListDetail


class Employee(models.Model):
    emp_id = models.AutoField(primary_key=True)
    emp_per = models.ForeignKey('person.Person', on_delete=models.DO_NOTHING,
                                related_name='employees')
    emp_pos = models.ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, related_name='employees_pos')
    emp_employee_number = SofvieCharField(unique=True, max_length=200, \
                                                                blank=True,
                                           null=True)
    emp_start_date = models.DateField(blank=True, null=True)
    emp_end_date = models.DateField(blank=True, null=True)
    emp_reports_to_per = models.ForeignKey('person.Person', models.DO_NOTHING, related_name='report_to_per_employees')
    emp_data_visibility = SofvieCharField(max_length=11, default="profile", choices=(("profile", "profile"),("all", "all"),("custom", "custom")))
    emp_created_date = models.DateTimeField(default=datetime.now)
    emp_created_by_per = models.ForeignKey('person.Person', models.DO_NOTHING, related_name='created_employees')
    emp_modified_date = models.DateTimeField(default=datetime.now)
    emp_modified_by_per = models.ForeignKey('person.Person', models.DO_NOTHING, related_name='modified_employees')
    emp_enable = models.BooleanField(default=True)
    emp_enote = SofvieCharField(max_length=200, blank=True, null=True)


    class Meta:
        db_table = 'employee'

    def __str__(self):
        return f"{self.emp_per.full_name}"


class EmployeeSite(models.Model):
    esi_id = models.AutoField(primary_key=True)
    esi_emp = models.ForeignKey('Employee', models.DO_NOTHING, related_name='employee_sites')
    esi_sit = models.ForeignKey('reflist.RefListDetail', models.DO_NOTHING,
                                related_name='employee_sites')
    esi_created_date = models.DateTimeField(auto_now_add=True)
    esi_created_by_per = models.ForeignKey('person.Person', models.DO_NOTHING, blank=True, null=True,
                                           related_name='created_employee_sites')
    esi_modified_date = models.DateTimeField(blank=True, null=True, default=datetime.now)
    esi_modified_by_per = models.ForeignKey('person.Person', models.DO_NOTHING, blank=True, null=True,
                                            related_name='modified_employee_sites')

    esi_enable = models.BooleanField(default=True)
    esi_enote = SofvieCharField(max_length=200, blank=True, null=True)



    class Meta:
        db_table = 'employee_site'


class EmployeeJob(models.Model):
    ejo_id = models.AutoField(primary_key=True)
    ejo_emp = models.ForeignKey('Employee', models.DO_NOTHING, related_name='employee_jobs')
    ejo_job = models.ForeignKey('reflist.RefListDetail', models.DO_NOTHING, related_name='employee_jobs')
    ejo_created_date = models.DateTimeField(auto_now_add=True) 
    ejo_created_by_per = models.ForeignKey('person.Person', models.DO_NOTHING, blank=True, null=True, related_name='created_employee_jobsss')
    ejo_modified_date = models.DateTimeField(blank=True, null=True)
    ejo_modified_by_per = models.ForeignKey('person.Person', models.DO_NOTHING, blank=True, null=True, related_name='modified_employee_jobs')
    ejo_enable = models.BooleanField(default=True)
    ejo_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'employee_job'

# employee_custom_site_job
class EmployeeCustomSiteJob(Model):
    esj_id = AutoField(primary_key=True)
    esj_emp = ForeignKey(Employee, 
                            related_name = 'esj_emp_id', 
                            on_delete=models.DO_NOTHING, 
                            help_text='ForeignKey from employee table/employee model"')
    esj_site_rld = ForeignKey(RefListDetail, 
                                    blank=True, null=True,
                                    related_name= "esj_site_rld_id", 
                                    on_delete=models.DO_NOTHING,
                                    help_text= "ForeignKey from ref_list_detail table/RefListDetail model")
    esj_job_rld = ForeignKey(RefListDetail, 
                                    blank=True, null=True,
                                    related_name= "esj_job_rld_id", 
                                    on_delete=models.DO_NOTHING,
                                    help_text= "ForeignKey from ref_list_detail table/RefListDetail model")
    esj_created_date = DateTimeField(auto_now_add=True)
    esj_created_by_per = ForeignKey(Person, blank=True, null=True,
                                            related_name='esj_created_by_per_id',
                                            on_delete=models.DO_NOTHING,
                                            help_text='Foreign key from person table/Person model')
    esj_modified_date = DateTimeField(blank=True, null=True)
    esj_modified_by_per = ForeignKey(Person, blank=True, null=True,
                                            related_name='esj_modified_by_per_id',
                                            on_delete=models.DO_NOTHING,
                                            help_text='Foreign key from person table/Person model')    
    esj_enable = BooleanField(default=True)
    esj_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:
        db_table = 'employee_custom_site_job'        
        verbose_name = 'Employee Custom Site Job'
    
    def __str__(self):
        return self.esj_created_by_per
