from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from django.db import connection
from django.db.models import Value, CharField
from django.db.models.functions import Concat

# Create your views here.
from apps.common_utils.views.validate_permission import RolePermission
from apps.incident_management.api.utlity_function import dictfetchall
from apps.language.models import LanguageTranslation
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.person.models import Person
from apps.user_settings_profile.models import UserProfile
from apps.language.models import Language

class GetEmployeeList(APIView):
    # using only at Admin Training Controller    
    permission_classes = [SofviePermission]     
    def get(self, request):
        with connection.cursor() as cursor:
            cursor.execute("call get_employee_full_name_enable()")
            row = dictfetchall(cursor)
        return Response(row)


class GetAllEmployeeList(APIView):
    # using only at Admin Training Controller    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewTrainingRecords.value,)

    def get(self, request):
        with connection.cursor() as cursor:
            cursor.execute("call get_employee_full_name_nofilter()")
            row = dictfetchall(cursor)
        return Response(row)


class GetEmployeeListProfile(APIView):
    permission_classes = [SofviePermission]
    """ Response for the All  """

    def get(self, request):
        with connection.cursor() as cursor:
            cursor.execute("call get_employee_list_profile()")
            row = dictfetchall(cursor)
        return Response(row) 
    
class GetFullEmployeeListProfile(APIView):    
    # using Across the APP 
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)       
    
    def get(self, request, mode):

        person_instance = self.request.user.user_per_id
        user_lang = UserProfile.objects.get(upr_per=person_instance).upr_language
        lng_id = Language.objects.get(lng_name = user_lang).lng_id

        employee_list = get_full_employee_list_profile(lng_id, mode)

        return Response(employee_list)

def get_full_employee_list_profile(lng_id, mode='all'):

    with connection.cursor() as cursor:
        cursor.execute("call get_full_employee_list_profile()")
        employee_list = dictfetchall(cursor)

    if mode == 'all':
        # exlude user master in list
        employee_list = filter(lambda emp:emp['per_id'] != 1, employee_list)
        # add inactive label to inactive employees whose status_flag = 0
        employee_list = map(lambda obj: add_inactive(obj), employee_list)


    inactive_label = LanguageTranslation.objects.get(ltr_tag = 3793, ltr_tag_type = 1, ltr_lng_id = lng_id).ltr_text

    def add_inactive(obj):
        if obj['status_flag'] == 0:
            obj['per_full_name']   = f"{obj['per_full_name']} ({inactive_label})"
        return obj

    return employee_list



class GetActivePersonList(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def get(self, request):
        '''
        Used in Targets - to assign targets only to active persons
        '''
        active_person_list = Person.objects.filter(
            per_enable = 1
        ).annotate(
            per_full_name = Concat('per_last_name', Value(', '), 'per_first_name', Value(' '), 'per_middle_name', output_field=CharField(),)
        ).values(
            'per_id',
            'per_full_name'
        ).order_by('per_full_name')

        return Response(active_person_list, status = status.HTTP_200_OK)