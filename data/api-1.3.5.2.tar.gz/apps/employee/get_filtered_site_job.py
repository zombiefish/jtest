from django.db.models import Prefetch, F, Subquery
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, CreateAPIView, ListCreateAPIView, RetrieveAPIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.employee.serializers.serializer import EmployeeCustomSiteJobSerializer
from apps.employee.models import EmployeeCustomSiteJob, Employee, EmployeeSite, EmployeeJob
from datetime import datetime
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.employee.helper_function_user_visibility import helperEmployeeJobs, helperEmployeeSites
from apps.sofvie_user_authorization.api.permissions import SofviePermission

class GetFilteredSiteJob(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def get(self, request, mode):
        person_id = request.user.user_per_id
        if(mode =='site'):
            get_sites, data_user_visibility = helperEmployeeSites(self, person_id)
            return Response({'sites':get_sites})
        elif(mode == 'job'):
            get_jobs, data_user_visibility = helperEmployeeJobs(self, person_id)
            return Response({'jobs':get_jobs})
        elif(mode == 'joball'):
            get_jobs, data_user_visibility = helperEmployeeJobs(self, person_id)
            return Response({'jobs':get_jobs})            
        elif(mode == 'site_job'):
            # print(mode)
            get_sites, data_user_visibility = helperEmployeeSites(self, person_id)
            get_jobs, data_user_visibility = helperEmployeeJobs(self, person_id)
            return Response({'sites':get_sites, 'jobs':get_jobs})       

