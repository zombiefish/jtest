from django.db.models import Prefetch
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, CreateAPIView, ListCreateAPIView, RetrieveAPIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.employee.serializers.serializer import EmployeeCustomSiteJobSerializer
from apps.employee.models import EmployeeCustomSiteJob, Employee
from datetime import datetime
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class CreateUpdateCustomSiteJob(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageUsers.value,)    

    def post(self, request, per_id):
        
        person_id = self.request.user.user_per_id        
        input_payload = request.data
        emp_id = Employee.objects.get(emp_per_id=per_id).emp_id                           
        
        # Creating or updating a record if not exists.
        
        # for each_object in input_object:
        # existing jobs for emp
        existing_jobs = EmployeeCustomSiteJob.objects.filter(esj_emp_id=emp_id, esj_enable=True).values_list('esj_job_rld_id', flat = True).distinct()
        existing_sites = EmployeeCustomSiteJob.objects.filter(esj_emp_id=emp_id, esj_enable=True, esj_job_rld__isnull= True).values_list('esj_site_rld_id', flat = True).distinct()
        input_jobs = []        
        input_sites = []        
        for each in input_payload:
            if 'job_id' in each and each['job_id']:
                input_jobs.append(each['job_id'])
            if 'job_id' not in each:
                input_sites.append(each['site_id'])
                
        new_jobs = [each for each in input_jobs if each not in existing_jobs]
        removed_jobs = [each for each in existing_jobs if each not in input_jobs]
        new_sites = [each for each in input_sites if each not in existing_sites]
        removed_sites = [each for each in existing_sites if each not in input_sites]       


        new_sites_jobs = []
        for each in input_payload:                        
            for new_job in new_jobs:
                if 'job_id' in each and each['job_id'] == new_job:
                    new_sites_jobs.append(each)
            for new_site in new_sites:
                if 'job_id' not in each and each['enable'] == True:
                    each['job_id'] = None
                    new_sites_jobs.append(each)

        #update esj_enable to False for removed Job_ids
        if removed_jobs:
            EmployeeCustomSiteJob.objects.filter(esj_job_rld__in=removed_jobs,esj_emp_id=emp_id).update(esj_enable=False,esj_modified_date=datetime.now(), esj_modified_by_per=person_id)
        if removed_sites:
            EmployeeCustomSiteJob.objects.filter(esj_site_rld__in=removed_sites,esj_emp_id=emp_id).exclude(esj_job_rld__in=removed_jobs).update(esj_enable=False,esj_modified_date=datetime.now(), esj_modified_by_per=person_id)       

        #add new jobs and new sites        
        if new_sites_jobs:
            EmployeeCustomSiteJob.objects.bulk_create([
                EmployeeCustomSiteJob(esj_emp_id=emp_id, 
                                    esj_site_rld_id=each['site_id'],
                                    esj_job_rld_id=each['job_id'],
                                    esj_created_by_per=person_id) for each in new_sites_jobs])
        
        return Response({"message": "record added/updated successfully"})