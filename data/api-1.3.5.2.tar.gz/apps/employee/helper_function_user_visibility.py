from django.db.models import F, Subquery, OuterRef
from apps.employee.models import EmployeeCustomSiteJob, Employee, EmployeeSite, EmployeeJob
from apps.reflist.models import RefListDetail
from apps.language.models import Language, LanguageTranslation
from apps.user_settings_profile.models import UserProfile

def helperEmployeeSites(self, person_id, *args, **kwargs):  
    try:
        emp_object = Employee.objects.filter(emp_per_id = person_id).values('emp_id','emp_per_id', 'emp_data_visibility')
        emp_id = emp_object[0]['emp_id']
        data_visibility_type = emp_object[0]['emp_data_visibility']   
        lng_name = UserProfile.objects.get(upr_per= person_id).upr_language 
        lng_id = Language.objects.get(lng_name = lng_name)       
        if data_visibility_type == 'custom': 
            get_sites = EmployeeCustomSiteJob.objects.select_related(
                'esj_site_rld_id'
            ).filter(
                esj_emp_id=emp_id,
                esj_enable=True,
                esj_site_rld_id__rld_deleted=False,
                esj_site_rld_id__rld_enable=True,
            ).annotate(
                rld_id=F("esj_site_rld"),
                rld_code=F("esj_site_rld__rld_code"),
                tag=F("esj_site_rld__rld_name"),
                tagtype=F("esj_site_rld__rld_tag_type"),
                rld_parent_detail_rld_id=F("esj_site_rld__rld_parent_detail_rld_id"),
                rld_is_active = F("esj_site_rld__rld_is_active")
            ).values()

            get_sites = get_sites.annotate(
                rld_name = Subquery(
                    LanguageTranslation.objects.filter(
                        ltr_tag=OuterRef('tag'), 
                        ltr_tag_type = OuterRef('tagtype'), 
                        ltr_lng = lng_id
                    ).values('ltr_text')[:1]
                )
            ).values(
                'rld_id', 'rld_code', 'rld_name', 'rld_parent_detail_rld_id', 'rld_is_active'
            ).distinct().order_by('rld_name')
            

        elif data_visibility_type == 'profile':
            get_sites = EmployeeSite.objects.filter(
                esi_emp_id=emp_id, esi_enable=True
            ).annotate(
                rld_id=F('esi_sit_id'),
                rld_code=F("esi_sit_id__rld_code"),
                tag=F('esi_sit_id__rld_name'),
                tagtype=F('esi_sit_id__rld_tag_type'),
                rld_parent_detail_rld_id=F("esi_sit_id__rld_parent_detail_rld_id"),
                rld_is_active = F("esi_sit_id__rld_is_active")
            ).values()

            get_sites = get_sites.annotate(
                rld_name = Subquery(
                    LanguageTranslation.objects.filter(
                        ltr_tag=OuterRef('tag'), 
                        ltr_tag_type = OuterRef('tagtype'), 
                        ltr_lng = lng_id
                    ).values('ltr_text')[:1]
                )
            ).values(
                'rld_id','rld_code', 'rld_name', 'rld_parent_detail_rld_id', 'rld_is_active'
            ).order_by('rld_name')
            
        elif data_visibility_type == 'all':
            get_sites = RefListDetail.objects.filter(
                rld_rlh__rlh_name='ref_site', rld_enable=True, rld_deleted=False,
                rld_is_active=True
                ).annotate(
                    tag = F('rld_name')
                ).values()     

            get_sites = get_sites.annotate(
                rld_name = Subquery(
                    LanguageTranslation.objects.filter(
                        ltr_tag=OuterRef('tag'), 
                        ltr_tag_type = OuterRef('rld_tag_type'), 
                        ltr_lng = lng_id
                    ).values('ltr_text')[:1]
                )
            ).values('rld_id','rld_code', 'rld_name', 'rld_parent_detail_rld_id').distinct().order_by('rld_name')

    except Employee.DoesNotExist:
        return []
    
    return get_sites , data_visibility_type
    
def helperEmployeeJobs(self, person_id, *args, **kwargs):  
    jobDisplayMode = ''
    jobMode = self.__dict__
    try:
        jobDisplayMode = jobMode['kwargs']['mode']
    except Exception as e:        
        pass

    try:
        emp_object = Employee.objects.filter(emp_per_id = person_id).values('emp_id','emp_per_id', 'emp_data_visibility')
        emp_id = emp_object[0]['emp_id']
        data_visibility_type = emp_object[0]['emp_data_visibility']   
        lng_name = UserProfile.objects.get(upr_per= person_id).upr_language

        lng_id = Language.objects.get(lng_name = lng_name)
        if data_visibility_type == 'custom': 
            get_jobs = EmployeeCustomSiteJob.objects.select_related('esj_job_rld_id').filter(
                esj_emp_id=emp_id, 
                esj_enable=True, 
                esj_job_rld_id__rld_deleted=False,
                esj_job_rld_id__rld_enable=True,
            ).annotate(
                rld_id=F("esj_job_rld"),
                rld_code=F("esj_job_rld__rld_code"),
                tag=F("esj_job_rld__rld_name"),
                tagtype=F("esj_job_rld__rld_tag_type"),
                rld_parent_detail_rld_id=F("esj_job_rld__rld_parent_detail_rld_id"),
                rld_is_active = F("esj_site_rld__rld_is_active")
            ).values(
                'rld_id', 'rld_code', 'tag', 'tagtype', 'rld_parent_detail_rld_id','rld_is_active'
            ).distinct().order_by('rld_code')
            
            get_jobs = get_jobs.annotate(
                rld_name = Subquery(
                    LanguageTranslation.objects.filter(
                        ltr_tag=OuterRef('tag'), 
                        ltr_tag_type = OuterRef('tagtype'), 
                        ltr_lng = lng_id
                    ).values('ltr_text')[:1]
                )
            ).values('rld_id', 'rld_name', 'rld_code', 'rld_parent_detail_rld_id', 'rld_is_active').distinct().order_by('rld_code')
            
        elif data_visibility_type == 'profile':
            get_jobs = RefListDetail.objects.filter(
                rld_rlh_id =3, 
                rld_deleted =False, 
                rld_enable =True,
                rld_parent_detail_rld_id__in = Subquery(
                    EmployeeSite.objects.filter(esi_emp_id=emp_id, esi_enable=True).values('esi_sit_id')
                )
            ).annotate(
                tag = F('rld_name')
            ).values()
                
            get_jobs = get_jobs.annotate(
                rld_name = Subquery(
                    LanguageTranslation.objects.filter(
                        ltr_tag=OuterRef('tag'), 
                        ltr_tag_type = OuterRef('rld_tag_type'), 
                        ltr_lng = lng_id
                    ).values('ltr_text')[:1]
                )
            ).values(
                'rld_id','rld_code', 'rld_name', 'rld_parent_detail_rld_id', 'rld_is_active'
            ).order_by('rld_code')

            existing_jobs = EmployeeJob.objects.select_related('ejo_job').filter(
                ejo_emp=emp_id,
                ejo_enable=True,                    
            ).annotate(
                rld_id=F('ejo_job_id'),
                rld_parent_detail_rld_id = F('ejo_job__rld_parent_detail_rld_id'),
                rld_code=F('ejo_job__rld_code'),
                rld_is_active = F("ejo_job__rld_is_active"),
                tag=F('ejo_job__rld_name'),
                tagtype=F('ejo_job__rld_tag_type'),
            ).values()

            existing_jobs = existing_jobs.annotate(
                rld_name = Subquery(
                    LanguageTranslation.objects.filter(
                        ltr_tag=OuterRef('tag'), 
                        ltr_tag_type = OuterRef('tagtype'), 
                        ltr_lng = lng_id
                    ).values('ltr_text')[:1]
                )
            ).values(
                'rld_id','rld_code', 'rld_name', 'rld_parent_detail_rld_id', 'rld_is_active'
            ).order_by('rld_code')


            job_id_list = [job['rld_id'] for job in existing_jobs]

            get_jobs=list(get_jobs)
            existing_jobs = list(existing_jobs)
            remove_jobs = []
            for user_job in existing_jobs:
                for job in get_jobs:
                    if job['rld_parent_detail_rld_id'] == user_job['rld_parent_detail_rld_id']:
                        if job['rld_id'] not in job_id_list:
                            remove_jobs.append(job)
        
            for job in remove_jobs:
                if job in get_jobs:
                    get_jobs.remove(job)

        elif data_visibility_type == 'all':
            job_filter = { 'rld_rlh__rlh_name':'ref_job', 'rld_enable':True, 'rld_deleted' :False }
            if jobDisplayMode == 'job':
                job_filter['rld_is_active'] = True
            get_jobs = RefListDetail.objects.filter(**job_filter).annotate(
                 tag = F('rld_name')

            ).values('rld_id', 'rld_code', 'rld_tag_type', 'tag', 'rld_parent_detail_rld_id','rld_is_active').order_by('rld_code')

            get_jobs = get_jobs.annotate(
                rld_name = Subquery(
                    LanguageTranslation.objects.filter(
                        ltr_tag=OuterRef('tag'), 
                        ltr_tag_type = OuterRef('rld_tag_type'), 
                        ltr_lng = lng_id
                    ).values('ltr_text')[:1] 
                )
            ).values(
                'rld_id','rld_code', 'rld_name', 'rld_parent_detail_rld_id', 'rld_is_active'
            ).order_by('rld_code')
    
    except Exception as e:
        return []
    
    return get_jobs, data_visibility_type


