import uuid
from datetime import date

from django.conf import settings
from django.db import models, transaction
from django.utils import timezone
from django.db import models

from django.db.models import (
    Model,
    AutoField,
    IntegerField,
    CharField,
    DateTimeField,
    ForeignKey,
    ManyToManyField,
    BooleanField,
    TextField,
    DateField,
    DecimalField, F
)
from apps.person.models import Person
from apps.reflist.models import RefListDetail
from apps.common_utils.views.sofvieModelFields import SofvieCharField, SofvieIntegerField, SofvieTextField

class UserProfile(Model):
    upr_id = AutoField(primary_key=True)
    upr_per = ForeignKey(Person, blank=False, 
                                 null=False,
                                 related_name='upr_per_id',
                                 on_delete=models.DO_NOTHING,
                                 help_text="ForeignKey from person Table")
    upr_language = SofvieCharField(max_length=31, default="en")
    upr_theme_app = SofvieCharField(max_length=31, default="light")
    upr_theme_mobile = SofvieCharField(max_length=31, default="light")
    upr_site = ForeignKey(RefListDetail,
                              related_name='upr_site_id',
                              on_delete=models.DO_NOTHING,
                              help_text="ForeignKey from ref_list_detail Table", 
                              blank=True, null=True)
    upr_job = ForeignKey(RefListDetail,
                              related_name='upr_job_id',
                              on_delete=models.DO_NOTHING,
                              help_text="ForeignKey from ref_list_detail Table", 
                              blank=True, null=True)
    upr_level = ForeignKey(RefListDetail,
                              related_name='upr_level_id',
                              on_delete=models.DO_NOTHING,
                              help_text="ForeignKey from ref_list_detail Table", 
                              blank=True, null=True)                              
    upr_supervisor_per = ForeignKey(Person,
                              related_name='upr_supervisor_per_id',
                              on_delete=models.DO_NOTHING,
                              help_text="ForeignKey from Person Table", 
                              blank=True, null=True)
    upr_created_date = DateTimeField(auto_now_add=True)
    upr_created_by_per = ForeignKey(Person, blank=False, null=False,
                                        related_name='upr_created_by_per_id',
                                        on_delete=models.DO_NOTHING,
                                        help_text="ForeignKey from Person Table")
    upr_modified_date = DateTimeField(blank=True, null=True) # make sure it will null BM
    upr_modified_by_per = ForeignKey(Person, blank=True, null=True,
                                         related_name='upr_modified_by_per_id',
                                         on_delete=models.DO_NOTHING,
                                         help_text="ForeignKey from Person Table")
    upr_enable = BooleanField(default=True)
    upr_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = 'user_profile'
    
    def __str__(self):
        return self.upr_per.full_name


class UserProfileDistribution(Model):
    upd_id = AutoField(primary_key=True)
    upd_upr = ForeignKey(UserProfile, blank=False, null=False, 
                                        related_name='distribution_list',
                                        on_delete=models.DO_NOTHING,
                                        help_text="ForeignKey from User_profoile Table")
    upd_distribution_per = ForeignKey(Person, blank=True, 
                                 null=True,
                                 related_name='upd_distribution_per_id',
                                 on_delete=models.DO_NOTHING,
                                 help_text="ForeignKey from person Table")    
    upd_distribution_email = SofvieCharField(max_length=255, blank=True, null=True)    
    upd_created_date = DateTimeField(auto_now_add=True)
    upd_created_by_per = ForeignKey(Person, blank=False, null=False,
                                        related_name='upd_created_by_per_id',
                                        on_delete=models.DO_NOTHING,
                                        help_text="ForeignKey from Person Table")
    upd_modified_date = DateTimeField(blank=True, null=True) # make sure it will null BM
    upd_modified_by_per = ForeignKey(Person, blank=True, null=True,
                                         related_name='upd_modified_by_per_id',
                                         on_delete=models.DO_NOTHING,
                                         help_text="ForeignKey from Person Table")
    upd_enable = BooleanField(default=True)
    upd_enote = SofvieCharField(blank=True, null=True)

    class Meta:
        db_table = 'user_profile_distribution'
    
    def __str__(self):
        return self.upd_created_by_per.full_name
                                                       



