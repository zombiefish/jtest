from django.urls import path
from apps.user_settings_profile.api.views.get_user_profile import GetUserProfile, GetLanguages
from apps.user_settings_profile.api.views.update_user_profile import UpdateUserProfile

urlpatterns = [
    path('get-user-profile/<int:upr_per_id>/', GetUserProfile.as_view()),
    path('update-user-profile/', UpdateUserProfile.as_view()),
    path('get-languages/', GetLanguages.as_view()),
]