from datetime import datetime
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from apps.language.models import Language
from django.db import transaction
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile, UserProfileDistribution
from apps.user.api.helper_functions.sofvie_keycloak_helper_functions import changeUserKeycloakLocale

class UpdateUserProfile(APIView):
    permission_classes = [SofviePermission]
    
    @transaction.atomic
    def post(self, request):
        payload_data = request.data
        person = self.request.user.user_per_id


        distribution_list = payload_data.pop('distribution_list')        

        # if upr_language_id is none then get the default language from Language table
        if 'upr_language' not in payload_data or payload_data['upr_language'] == '' or payload_data['upr_language'] == None:
            payload_data['upr_language'] = Language.objects.filter(lng_default=True).first().lng_name
        
        try:
            # add upr_modified_by and upr_modified_date and update the user profile
            changeUserKeycloakLocale(self.request.user.id, payload_data['upr_language'])
            
            payload_data['upr_modified_date'] = datetime.now()
            payload_data['upr_modified_by_per'] = person
            update_or_create_user_profile = UserProfile.objects.update_or_create(upr_per_id=person, defaults=payload_data)

            # add upr_distribution_list and update the user profile distribution
            add_distributions(distribution_list, person, update_or_create_user_profile[0])

            return Response({"status": "success", "message": "User Profile Updated Successfully"}, status=status.HTTP_200_OK)

        except:
            raise Exception("User Profile Update Failed")

def add_distributions(distribution_list, person, instance):
    
    try:                
        # get existing user profile distribution
        existing_distribution_list = instance.distribution_list.filter(upd_enable=True).values_list('upd_distribution_email', flat=True)        

        # check for deleted distribution list
        deleted_distribution_list = list(set(existing_distribution_list) - set(distribution_list))

        # check for new distribution list
        new_distribution_list = list(set(distribution_list) - set(existing_distribution_list))        
        
        # delete distribution list from deleted_distribution_list
        delete_upd = instance.distribution_list.filter(upd_distribution_email__in=deleted_distribution_list).update(upd_enable=False, upd_modified_by_per=person, upd_modified_date=datetime.now())

        # bulk create new distribution list
        add_new_distribution_list = instance.distribution_list.bulk_create(
            [UserProfileDistribution(                
                upd_upr = instance,
                upd_distribution_email=d,                 
                upd_created_by_per=person, 
                upd_created_date=datetime.now()
            ) for d in new_distribution_list]
        )

        return True
    except:
        raise Exception("Distribution List Update Failed")