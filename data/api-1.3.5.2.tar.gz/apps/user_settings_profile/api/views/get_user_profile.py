from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile, UserProfileDistribution
from django.forms import model_to_dict
from django.db.models import F, Subquery, OuterRef
from apps.language.models import Language, LanguageTranslation

class GetUserProfile(APIView):
    permission_classes = [SofviePermission]

    def get(self, request, upr_per_id):

        try:

            user_settings = UserProfile.objects.get(upr_per_id=upr_per_id)

            user_dist_list =  UserProfileDistribution.objects.filter(
                upd_upr=user_settings.upr_id, 
                upd_enable=True
            ).annotate(               
                email = F("upd_distribution_email"),
            ).values("email")

            user_profile_object = model_to_dict(user_settings) 
            user_profile_object['lng_id'] = Language.objects.get(lng_name = user_profile_object['upr_language']).lng_id
            user_profile_object['distribution_list'] = user_dist_list
            
            return Response(user_profile_object)
        except UserProfile.DoesNotExist:
            # user_profile_object
            return Response("Record doesn't exist")


class GetLanguages(APIView):
    permission_classes = [SofviePermission]

    def get(self,request):
        person_id = self.request.user.user_per_id
        try:
            languages = Language.objects.filter(lng_enable=1, lng_selected=True).values(
                "lng_id",
                "lng_name",
                "lng_description"
            ).values()
            languages = languages.annotate(
                lng_description = Subquery(
                        LanguageTranslation.objects.filter(ltr_tag=OuterRef('lng_description'), ltr_tag_type= 1, ltr_lng=OuterRef('lng_id')).values('ltr_text')[:1]
                    )
                )

            return Response(languages)
        except Language.DoesNotExist:
            return Response("No Records")
