from django.db.models import Prefetch, CharField
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, RetrieveAPIView
from rest_framework.generics import ListCreateAPIView
from rest_framework import serializers
from rest_framework.serializers import ModelSerializer
from apps.user_settings_profile.models import UserProfile, UserProfileDistribution
from datetime import datetime
from django.db import transaction, IntegrityError
from rest_framework.permissions import SAFE_METHODS
from apps.person.models import Person
from django.db.models.functions import Concat
from django.db.models import Value, Max, F, Subquery
from apps.user.models import User
from django.forms import model_to_dict


class UserProfileSerializer(ModelSerializer):
    distribution_list = serializers.SerializerMethodField()
    class Meta:
        model = UserProfile
        fields = (
            "upr_id",
            "upr_per_id",
            "upr_language",
            "upr_theme_app",
            "upr_theme_mobile",
            "upr_site",
            "upr_job",
            "upr_level",
            "upr_supervisor_per",
            "distribution_list"
        )
        lookup_field = "upr_per_id"

    
    def __init__(self, *args, **kwargs):
        if kwargs["context"].get("request").method in SAFE_METHODS or kwargs["context"].get("read"):
            pass
            # self.fields.pop('upr_theme_mobile')
            # self.fields['distribution_list'] = serializers.SerializerMethodField()
        else:
            self.fields['distribution_list'] = serializers.PrimaryKeyRelatedField(many=True, write_only=True, queryset=Person.objects.all())
        super(UserProfileSerializer, self).__init__(*args, **kwargs)
        
    
    def get_distribution_list(self, obj):       

        obj_dist =  obj.distribution_list.filter(upd_enable=True).annotate(
                                                full_name=Concat(
                                                    "upd_distribution_per__per_last_name", Value(", "), 
                                                    "upd_distribution_per__per_first_name", output_field=CharField(),
                                                ),
                                                email=F("upd_distribution_per_id__users__email")).values("upd_id", "upd_distribution_per", "full_name", "email")        

        return obj_dist

    @transaction.atomic()
    def create(self, validated_data, *args, **kwargs):
        person = self.context['request'].user.user_per_id
        # print(person , validated_data)

        distribution_list = validated_data.pop('distribution_list')
        
        try:
            user_settings = UserProfile.objects.get(upr_per=person)
            #update new settings for user
            # print('existiong users __ ', model_to_dict( user_settings))
            validated_data['upr_modified_by_per'] = person
            validated_data['upr_modified_date'] = datetime.now()
            instance = super(UserProfileSerializer, self).update(user_settings, validated_data, *args, **kwargs)

            distribution_list_ids = [d.per_id for d in distribution_list]

            existing_distribution_list = instance.distribution_list.filter(upd_enable=True).values_list("upd_distribution_per", flat=True)
            deleted_distribution_list = [d for d in existing_distribution_list if d not in distribution_list_ids]
            new_distribution_list = [d for d in distribution_list_ids if d not in existing_distribution_list]

            UserProfileDistribution.objects.filter(upd_distribution_per_id__in=deleted_distribution_list).update(upd_enable=False, upd_modified_by_per=person, upd_modified_date=datetime.now())
            UserProfileDistribution.objects.bulk_create([UserProfileDistribution(upd_upr=instance,
                                                                                    upd_distribution_per_id=d,
                                                                                    upd_created_by_per=person)for d in new_distribution_list])
            
        except UserProfile.DoesNotExist:
            # create new settings for user profile

            validated_data['upr_created_by_per'] = person
            validated_data['upr_per'] = person
            instance = super(UserProfileSerializer, self).create(validated_data, *args, **kwargs)
            UserProfileDistribution.objects.bulk_create([UserProfileDistribution(upd_upr=instance,
                                                                                    upd_distribution_per=d,
                                                                                    upd_created_by_per=person)for d in distribution_list])

        return instance

    # @transaction.atomic()
    # def update(self, instance, validated_data, *args, **kwargs):

    #     request_user = self.context['request'].user

    #     distribution_list = validated_data.pop('distribution_list')
        
    #     validated_data['upr_modified_by_per'] = request_user.user_per_id
    #     instance = super(UserProfileSerializer, self).update(instance, validated_data, *args, **kwargs)       

    #     distribution_list_ids = [d.per_id for d in distribution_list]

    #     existing_distribution_list = instance.distribution_list.filter(upd_enable=True).values_list("upd_distribution_per", flat=True)
    #     deleted_distribution_list = [d for d in existing_distribution_list if d not in distribution_list_ids]
    #     new_distribution_list = [d for d in distribution_list_ids if d not in existing_distribution_list]

    #     UserProfileDistribution.objects.filter(upd_distribution_per_id__in=deleted_distribution_list).update(upd_enable=False)
    #     UserProfileDistribution.objects.bulk_create([UserProfileDistribution(upd_upr=instance,
    #                                                                             upd_distribution_per_id=d,
    #                                                                             upd_created_by_per=request_user.user_per_id)for d in new_distribution_list])        
    #     return instance