from django.apps import AppConfig


class UserSettingsProfileConfig(AppConfig):
    name = 'apps.user_settings_profile'
