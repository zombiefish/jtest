from django.db import models

from apps.person.models import Person


from apps.common_utils.views.sofvieModelFields import(
    SofvieCharField,
    SofvieEmailField,
    SofvieIntegerField,
    SofvieTextField
)


class DistributionGroup(models.Model):
    dig_id = models.AutoField(primary_key=True)
    dig_group_name = SofvieCharField(max_length=200)
    # dig_group_name = SofvieCharField(max_length=20, min_length=5)
    dig_created_date = models.DateTimeField(auto_now=True, blank=True,
                                            null=True)

    dig_created_by_per = models.ForeignKey(Person, on_delete = models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='dig_person_created_by')
    dig_modified_date = models.DateTimeField(auto_now=True, blank=True,
                                            null=True)
    dig_modified_by_per = models.ForeignKey(Person, on_delete = models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='dig_person_modified_by')
    dig_enable = models.BooleanField(default=True)
    dig_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:

        db_table = 'distribution_group'


class DistributionGroupEmail(models.Model):
    dge_id = models.AutoField(primary_key=True)
    dge_dig = models.ForeignKey(DistributionGroup, on_delete = models.DO_NOTHING,
                                           related_name='dge_dig_id')
    dge_email = SofvieEmailField(max_length=100)
    dge_created_date = models.DateTimeField(auto_now_add=True)

    dge_created_by_per = models.ForeignKey(Person, on_delete = models.DO_NOTHING,
                                           related_name='dge_person_created_by')
    dge_modified_date = models.DateTimeField(auto_now=True, blank=True,
                                            null=True)
    dge_modified_by_per = models.ForeignKey(Person, on_delete = models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='dge_person_modified_by')
    dge_enable = models.BooleanField(default=True)
    dge_enote = SofvieCharField(max_length=200, blank=True, null=True)

    class Meta:

        db_table = 'distribution_group_email'

    def __str__(self):
        return str(self.dge_email)
        