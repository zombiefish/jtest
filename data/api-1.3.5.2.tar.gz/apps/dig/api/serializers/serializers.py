from rest_framework import serializers
from rest_framework.relations import StringRelatedField

from apps.dig.models import DistributionGroup, DistributionGroupEmail


class GetAllDistributionSerializer(serializers.ModelSerializer):
    email = serializers.SerializerMethodField()
  
    class Meta:
        model = DistributionGroup
        fields = (
            'dig_id',
            'dig_group_name',
            'email',
            'dig_modified_by_per_id',
            'dig_modified_date'
        )
        
    def get_email(self, obj):
        emails_dis_group = DistributionGroupEmail.objects.filter(
                   dge_dig_id = obj.dig_id,
                   dge_enable=1
        ).values_list("dge_email", flat=True)
        return emails_dis_group


class GetDistributionGroupEmailSerializer(serializers.ModelSerializer):
    email = GetAllDistributionSerializer(many=True, read_only=True)
    class Meta:
        model = DistributionGroupEmail
        fields = ("dge_email","email")

class UpdateDistributionGroupsSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = DistributionGroup
        fields = (
            'dig_id',
            'dig_group_name'
        )