from django.urls import path
from apps.dig.api.views.get_all_distribution_groups import GetDistributionGroupList
from apps.dig.api.views.create_distribution_group import CreateDistributionGroup
from apps.dig.api.views.delete_distribution_group import DeleteDistributionGroup
from apps.dig.api.views.update_distribution_groups import UpdateDistributionGroup

urlpatterns = [

    path('get-all-distribution-group/', GetDistributionGroupList.as_view()),
    path('create-distribution-group/', CreateDistributionGroup.as_view()),
    path('delete-distribution-group/', DeleteDistributionGroup.as_view()),
    path('update-distribution-group/', UpdateDistributionGroup.as_view())
]