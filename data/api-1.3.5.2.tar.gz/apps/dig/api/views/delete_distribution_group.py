from rest_framework.generics import UpdateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.dig.models import DistributionGroup, DistributionGroupEmail
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class DeleteDistributionGroup(UpdateAPIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.ArchiveSubmissions.value,)

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        payload = request.data

        for i in payload['dig_id']:
            queryset_group = DistributionGroup.objects.filter(
                dig_id=i
            ).update(dig_enable=0, dig_modified_by_per_id=person_id)

            queryset_email = DistributionGroupEmail.objects.filter(
                dge_dig_id=i
            ).update(dge_enable=0, dge_modified_by_per_id=person_id)

        return Response({"message": "OK"})