from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Prefetch
from apps.common_utils.views.validate_permission import RolePermission

from apps.sofvie_user_authorization.api.permissions import SofviePermission

""" 
from apps.dig.api.serializers.serializers import GetListExternalDistributionList
from apps.dig.models import ExternalDistributionList """
from apps.dig.api.serializers.serializers import GetAllDistributionSerializer
from apps.dig.models import DistributionGroup, DistributionGroupEmail


class GetDistributionGroupList(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewUsers.value,)

    def get(self, request):
        queryset = DistributionGroup.objects.filter(dig_enable=1)
        serialize_class = GetAllDistributionSerializer(queryset, many=True)

        return Response(serialize_class.data)
