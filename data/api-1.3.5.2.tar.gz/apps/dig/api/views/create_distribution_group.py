from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.dig.models import DistributionGroup, DistributionGroupEmail
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class CreateDistributionGroup(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageUsers.value,)

    def post(self, request):
        dig_group_name = request.data["dig_group_name"]
                
        data = DistributionGroup.objects.filter(
            dig_group_name=dig_group_name
        )
        if len(data) > 0:
            return Response("This group already exists. Please change to another name.")

        person_id = self.request.user.user_per_id_id

        dge_email=request.data["email"]

        queryset = DistributionGroup.objects.create(
            dig_created_by_per_id=person_id,
            dig_group_name=dig_group_name
        )

        for email in dge_email:
            email_queryset = DistributionGroupEmail.objects.create(
                dge_dig_id=queryset.dig_id,
                dge_created_by_per_id=person_id,
                dge_modified_by_per_id=person_id,
                dge_email = email
            )

        return Response({"dig_id": queryset.dig_id})
