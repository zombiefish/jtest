from rest_framework.generics import UpdateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from apps.common_utils.views.validate_permission import RolePermission

from apps.dig.api.serializers.serializers import UpdateDistributionGroupsSerializer
from apps.dig.models import DistributionGroup, DistributionGroupEmail
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class UpdateDistributionGroup(UpdateAPIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageUsers.value,)
    serializer_class = UpdateDistributionGroupsSerializer
    queryset = DistributionGroup.objects.all()

    def get_object(self):
        return self.queryset.get(pk=self.request.data['dig_id'])

    def post(self, request, *args, **kwargs):
        person_id = self.request.user.user_per_id_id
        dig_data = request.data
        dge_email = request.data.pop('email')
        partial = kwargs.pop('partial', False)

        instance = self.get_object()

        serializer = self.get_serializer(instance, data=dig_data,
                                         partial=partial)

        serializer.is_valid(raise_exception=True)
        serializer.instance.dig_modified_by_per_id = person_id
        self.perform_update(serializer)

        emails_in_group = DistributionGroupEmail.objects.filter(
            dge_dig_id=request.data['dig_id']
        )
        enabled_emails = list(emails_in_group.filter(
            dge_enable=1
        ).values('dge_email'))

        enabled_emails = [x['dge_email'].lower() for x in enabled_emails]

        for email in dge_email:
            current_email = emails_in_group.filter(
                dge_email=email.lower()
            ).first()

            if current_email:
                if current_email.dge_enable == 1:
                    enabled_emails.remove(email.lower())
                    continue
                else:
                    # print("enter 2")
                    emails_in_group.filter(
                        dge_email=email.lower()
                    ).update(dge_enable=1, dge_modified_by_per_id=person_id)
                    continue
            email_queryset = DistributionGroupEmail.objects.create(
                dge_dig_id=self.request.data['dig_id'],
                dge_created_by_per_id=person_id,
                dge_modified_by_per_id=person_id,
                dge_email=email.lower()
            )

        if enabled_emails:
            for email in enabled_emails:
                emails_in_group.filter(
                    dge_email=email.lower()
                ).update(dge_enable=0, dge_modified_by_per_id=person_id, dge_email=email.lower)

        return Response({"dig_id": request.data['dig_id']})

def disableEmail(email, person_id):
    DistributionGroupEmail.objects.filter(dge_email=email.lower()).update(dge_enable=0, dge_modified_by_per_id=person_id)

def updateEmail(old_email, new_email, person_id):
    DistributionGroupEmail.objects.filter(dge_email=old_email).update(dge_email=new_email.lower(), dge_modified_by_per_id=person_id)
