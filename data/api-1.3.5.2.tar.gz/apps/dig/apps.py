from django.apps import AppConfig


class DigConfig(AppConfig):
    name = 'apps.dig'
