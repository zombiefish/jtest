import re
from django.db import connection
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from datetime import datetime
from apps.common_utils.views.validate_permission import RolePermission
from apps.form_builder.models import CustomFormMaster
# Create your views here.
from apps.incident_management.api.utlity_function import dictfetchall
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.recognition.models import SubmissionPositiveRecognition
from apps.general_action.models import Formdescription, SubmissionGeneralAction, Submissionheader
from django.db.models import Prefetch, Q, F, Case, When, Value, CharField, Count, functions, Subquery
from django.db.models.functions import Concat, Cast
from apps.person.models import Person
from apps.employee.models import Employee
from django.db.models import BooleanField, IntegerField
from apps.employee.helper_function_user_visibility import helperEmployeeJobs, helperEmployeeSites
from apps.user_settings_profile.models import UserProfile
from apps.language.models import LanguageTranslation, Language
from apps.hazard_action.models import Formsub, Submissionhap
from django.db.models import Subquery, F, Q, OuterRef
from django.db.models.functions import Concat, Substr
from apps.reflist.models import RefListDetail

from apps.language.models import LanguageTranslation, Language

from apps.rmm_ora.api.date_filter_utils import date_filter, full_date_filter
from apps.home.api.views.common_functions_home_page import verify_sites_jobs
from django.template.loader import get_template
from apps.common_utils.views.get_translations import get_translation
from django.core.mail import EmailMultiAlternatives
from apps.user.models import User
from decouple import config


class UpdateSubmissionArchive(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.ArchiveSubmissions.value,)
    """ Response for the All  """

    def post(self, request):
        archived_by = request.user.user_per_id_id
        ids = ''
        idArray = []
        if not request.data:
            return Response(False)
        ids = ",".join(str(x['ID']) for x in request.data)
        for x in request.data:
            idArray.append(x['ID'])

        with connection.cursor() as cursor:
            cursor.execute("call update_archive_submission_list(%s, %s)", ([ids, archived_by]))
            row = dictfetchall(cursor)
            
        # Also remove the Child Forms
        SubmissionGeneralAction.objects.filter(sga_submission_header__in=idArray, sga_enable=True).update(
            sga_action_is_complete=True,
            sga_enable=False,
            sga_archived_date=datetime.now(),
            sga_archived_by_per_id=archived_by)
        
        Submissionhap.objects.filter(submissionheaderid__in=idArray, sha_enable=True).update(
            action_status="COMPLETE",
            sha_enable=False,
            sha_archived_date=datetime.now(),
            sha_archived_by_per_id=archived_by)

        return Response(row)

    # end point - implemented in haps-service.js


class GetSubmissionHAPListByHeaderId(APIView):
    """ Response for the All  """
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def post(self, request):
        submissionHeaderID = request.data['submissionHeaderID']
        with connection.cursor() as cursor:
            cursor.execute("call get_submission_hap_by_header_id(%s)",
                           ([submissionHeaderID]))
            row = dictfetchall(cursor)
        return Response(row)

    # end point - implemented in haps-service.js


class GetAllSubmissionHAP(APIView):
    """ Response for the All  """
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def get(self, request):
        with connection.cursor() as cursor:
            cursor.execute("call get_hap()")
            row = dictfetchall(cursor)
        return Response(row)

    # end point - implemented in haps-service.js


class GetAllSubmissionPID(APIView):
    """ Response for the All Positive Id Submissions  """
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def post(self, request):

        person_id = request.user.user_per_id
        lng_name = UserProfile.objects.get(upr_per= person_id).upr_language 
        lng_id = Language.objects.get(lng_name = lng_name)    
        start_date = ''
        end_date = ''
        if(request.data):
            start_date = request.data['start_date']
            end_date = request.data['end_date']

        get_sites, data_user_visibility = helperEmployeeSites(self, person_id)
        get_jobs, data_user_visibility = helperEmployeeJobs(self, person_id)
        site_list = [site['rld_id'] for site in get_sites]
        job_list = [job['rld_id'] for job in get_jobs]

        site_filters = []
        job_filters = []
        if data_user_visibility !='all':
            site_filters = [Q(submissionheader__site__in=site_list) | Q(submissionheader__submittedby_supervisorid=person_id)]
            job_filters = [Q(submissionheader__site__in=site_list) | Q(submissionheader__submittedby_supervisorid=person_id)]

        # changing sp to orm query - import Submissionheader , FormDescription and SubmissionPositiveRecognition
        data = SubmissionPositiveRecognition.objects.filter(
                    Q(submissionheader__isarchived=False) | Q(submissionheader__isarchived__isnull=True),
                    *site_filters,
                    *job_filters,
                    submissionheader__formcreationdate__range=full_date_filter(start_date,end_date),
                    spr_enable = True
                    ).annotate(
                        ID=F('id'),
                        SubmissionHeaderID=F('submissionheader'),
                        FormName = Case(
                            When(submissionheader__formdescriptionid=1403, then=Subquery(
                                CustomFormMaster.objects.filter(
                                    cfm_submission_header_id = OuterRef('submissionheader')
                                ).annotate(
                                    name = Subquery(
                                        LanguageTranslation.objects.filter(
                                            ltr_lng_id = lng_id,
                                            ltr_tag = OuterRef('cfm_fob__fob_name'),
                                            ltr_tag_type = OuterRef('cfm_fob__fob_tag_type')
                                        ).values('ltr_text')[:1]
                                    )
                                ).values('name')[:1]
                            )),             
                            default=Subquery(
                                LanguageTranslation.objects.filter(
                                    ltr_lng_id = lng_id,
                                    ltr_tag = OuterRef('submissionheader__formdescriptionid__formname'),
                                    ltr_tag_type = 1
                                ).values('ltr_text')[:1]
                            ),
                            output_field=CharField()
                        ),
                        FormDescriptionID=Case(
                            When(submissionheader__formdescriptionid=1403, then=Subquery(
                                CustomFormMaster.objects.filter(
                                    cfm_submission_header_id = OuterRef('submissionheader')
                                ).annotate(
                                    custom_id = Concat(Value('custom-'), 'cfm_fob_id', output_field=CharField())
                                ).values('custom_id')[:1]
                            )),             
                            default=F('submissionheader__formdescriptionid'),
                            output_field=CharField()
                        ),
                        FormCreationDate = F('submissionheader__formcreationdate'),
                        FormSubmissionDate = F('submissionheader__formsubmissiondate'),
                        Site = F('submissionheader__site'),
                        JobNumber = F('submissionheader__jobnumber'),
                        SiteLevel = F('submissionheader__sitelevel'),
                        Workplace = F('submissionheader__workplace'),
                        SubmissionHeaderLabel = Concat('submissionheader__jobnumber', Value('_'), 'submissionheader__site', Value('_'), 'submissionheader__sitelevel', output_field=CharField()),
                        SubmittedBy=Concat(
                                "submissionheader__submittedby_supervisorid__per_last_name", Value(" "),
                                "submissionheader__submittedby_supervisorid__per_first_name", output_field=CharField(),),
                        Supervisor=F('submissionheader__supervisor'),
                        HeaderDate=F('submissionheader__headerdate'),
                        attachment_count=Count('SubmissionPositiveRecognitionAttachments_SubmissionPositiveRecognitionID'),
                        recognition_of=Concat(
                            'submission_positive_recognition__recognitionof__per_last_name', Value(' '), 'submission_positive_recognition__recognitionof__per_first_name', output_field=CharField()),
                        WasRecognitionGiven_annotate=Cast('WasRecognitionGiven', IntegerField()),
                        tag_rld_id_site = Subquery(
                            RefListDetail.objects.filter(rld_id=OuterRef('Site')).values('rld_name')[:1]
                        ),
                        tagtype_rld_id_site = Subquery(
                            RefListDetail.objects.filter(rld_id=OuterRef('Site')).values('rld_tag_type')[:1]
                        ),
                        tag_rld_id_site_level = Subquery(
                            RefListDetail.objects.filter(rld_id=OuterRef('SiteLevel')).values('rld_name')[:1]
                        ),
                        tagtype_rld_id_site_level = Subquery(
                            RefListDetail.objects.filter(rld_id=OuterRef('SiteLevel')).values('rld_tag_type')[:1]
                        ),
                        tag_rld_id_jobnumber = Subquery(
                            RefListDetail.objects.filter(rld_id=OuterRef('JobNumber')).values('rld_name')[:1]
                        ),
                        tagtype_rld_id_jobnumber = Subquery(
                            RefListDetail.objects.filter(rld_id=OuterRef('JobNumber')).values('rld_tag_type')[:1]
                        ),
                        tag_rld_id_recognition_type = Subquery(
                            RefListDetail.objects.filter(rld_id=OuterRef('RecognitionType')).values('rld_name')[:1]
                        ),
                        tagtype_rld_id_recognition_type = Subquery(
                            RefListDetail.objects.filter(rld_id=OuterRef('RecognitionType')).values('rld_tag_type')[:1]
                        ),
                        tag_rld_id_recognition_given_type = Subquery(
                            RefListDetail.objects.filter(rld_id=OuterRef('RecognitionGivenType')).values('rld_name')[:1]
                        ),
                        tagtype_rld_id_recognition_given_type = Subquery(
                            RefListDetail.objects.filter(rld_id=OuterRef('RecognitionGivenType')).values('rld_tag_type')[:1]
                        )
                    ).prefetch_related(
                        'SubmissionPositiveRecognitionAttachments_SubmissionPositiveRecognitionID',
                        'submission_positive_recognition'
                    ).values_list(
                            'ID', 
                            'SubmissionHeaderID',
                            'FormDescriptionID',
                            'EventDescription',
                            'WasRecognitionGiven_annotate',
                            'FormCreationDate',
                            'FormSubmissionDate',
                            'Workplace',
                            'SubmissionHeaderLabel',
                            'SubmittedBy',
                            'HeaderDate',
                            'attachment_count',
                            'recognition_of',
                            'FormName',
                            ).order_by('-submissionheader__formsubmissiondate')

         

        data = data.annotate(
            Supervisor = Concat(Subquery(
                            Person.objects.filter(per_id=OuterRef('Supervisor')).values('per_last_name')
                        ),
                        Value(' '),
                        Subquery(
                            Person.objects.filter(per_id=OuterRef('Supervisor')).values('per_first_name')
                        ), output_field=CharField()),            
            Site = Subquery(
                            LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_site'),ltr_tag_type=OuterRef('tagtype_rld_id_site'), ltr_lng = lng_id).values('ltr_text')[:1]
                        ),
            JobNumber = Subquery(
                            LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_jobnumber'),ltr_tag_type=OuterRef('tagtype_rld_id_jobnumber'), ltr_lng = lng_id).values('ltr_text')[:1]
                        ),
            SiteLevel = Subquery(
                            LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_site_level'),ltr_tag_type=OuterRef('tagtype_rld_id_site_level'), ltr_lng = lng_id).values('ltr_text')[:1]
                        ),
            RecognitionType = Subquery(
                            LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_recognition_type'),ltr_tag_type=OuterRef('tagtype_rld_id_recognition_type'), ltr_lng = lng_id).values('ltr_text')[:1]
                        ),
            RecognitionGivenType = Subquery(
                            LanguageTranslation.objects.filter(ltr_tag=OuterRef('tag_rld_id_recognition_given_type'),ltr_tag_type=OuterRef('tagtype_rld_id_recognition_given_type'), ltr_lng = lng_id).values('ltr_text')[:1]
                        )
        ).values()

        return Response(data)


class GetAllSubmissionHapByFilter(APIView):    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)
    """ Response for the All  """

    def post(self, request):

        # payload parsing
        startdate = request.data['start_date']
        enddate = request.data['end_date']
        filtertype = request.data['mode']
        values = request.data['values']
        redirect_from = request.data.get('redirect_from', None)
        person_id = self.request.user.user_per_id_id        

        filtervalues = ""
        if values:
            filtervalues += "".join(str(x) + "," for x in values)
        if redirect_from != 'homepage':
            get_jobs, data_user_visibility = helperEmployeeJobs(self, person_id)
            per_jobs = [job['rld_id'] for job in get_jobs]

            get_sites, data_user_visibility = helperEmployeeSites(self, person_id)
            per_sites = [site['rld_id'] for site in get_sites]

            self.jobs = ','.join(map(str, per_jobs))
            self.sites = ','.join(map(str, per_sites))
        else:
            self.site_ids = request.data.get('site_ids', '')
            self.site_ids = self.site_ids.split(",")
            self.job_ids = request.data.get('job_ids', '')

            verify_sites_jobs(self, person_id)

        lng_name = UserProfile.objects.get(upr_per= person_id).upr_language
        lng_id = Language.objects.get(lng_name = lng_name).lng_id
        
        get_all_submission_hap_by_filter = "get_all_submission_hap_by_filter"      

        with connection.cursor() as cursor: 
            cursor.execute(f"call {get_all_submission_hap_by_filter}(%s,%s,%s,%s,%s,%s,%s,%s)", (
                lng_id, startdate, enddate, self.sites, self.jobs, filtertype, filtervalues.rstrip(','),  person_id
            ))            
            row = dictfetchall(cursor)
        return Response(row)



class GetAllSubmissionHapByFilterUsersJobs(APIView):    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)
    """ Response for the All  """

    def post(self, request):
        person_id = self.request.user.user_per_id_id

        # payload parsing
        start_date = request.data['start_date']
        end_date = request.data['end_date']
        filter_type = request.data['mode']
        filter_values = request.data['values'] # convert to comma separated string
        user_ids = request.data['users']
        job_ids = request.data['jobs']
        toggle = request.data['toggle']
        
        lng_name = UserProfile.objects.get(upr_per= person_id).upr_language 
        lng_id = Language.objects.get(lng_name = lng_name).lng_id 

        toggle = '' if type(toggle) != str else toggle        
         
        comma_seperated_filter_values = ','.join(str(x) for x in filter_values)
        comma_seperated_user_ids = ','.join(str(x) for x in user_ids)
        comma_seperated_job_ids = ','.join(str(x) for x in job_ids)       

        hapquery = 'get_submission_hap_by_filters_users_jobs'
        with connection.cursor() as cursor:            
            cursor.execute(f"call {hapquery}(%s,%s,%s,%s,%s,%s,%s, %s)", (start_date, end_date, filter_type, 
                        comma_seperated_filter_values, toggle, 
                        comma_seperated_user_ids, comma_seperated_job_ids, lng_id))
            row = dictfetchall(cursor)

        return Response(row)        

class CheckSubmissionsSynced(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):
        submissionsList = []

        #Convert list of objects to list of SubmissionIDs
        for submission in request.data:
            submissionsList.append(submission["submissionID"])
        person_id = self.request.user.user_per_id_id

        #Query database to check if submission exists
        queryset = Submissionheader.objects.filter(
            submissionid__in = submissionsList
        ).values_list('submissionid',flat=True)

        #Build response
        submissionsListResponse = []
        for submission in submissionsList:
            if submission not in queryset: #Add submissionID if not found in database
                submissionsListResponse.append({"submissionID": submission})

        return Response(submissionsListResponse)

class MissingSubmissionsEmail(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):

        data = request.data
        person_id = self.request.user.user_per_id_id
        full_name = self.request.user.user_per_id.full_name
        user_email = User.objects.filter(user_per_id=person_id).first()

        lng_id = 1 #Hard code English since this is for helpdesk
        ltr_ids = [2398, 1903, 9004, 1168, 9041, 9046, 1952]

        final_trans = get_translation(ltr_ids,lng_id)

        dict = {            
            'submitted_by': full_name,
            'submissions': data,
            'translations': final_trans
        }

        subject = final_trans[9041]
        from_email = user_email
        to_email = [config('EMAIL_SUPPORT_EMAIL')]

        html_content = get_template("missing_submissions_email.html").render(dict)
        msg = EmailMultiAlternatives(subject, "", from_email, to_email)
        msg.attach_alternative(html_content, "text/html")
        msg.send()

        return Response({"Message": "Email sent successfully"})

class ReSubmitSubmissionEmail(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):

        data = request.data
        person_id = self.request.user.user_per_id_id
        full_name = self.request.user.user_per_id.full_name
        user_email = User.objects.filter(user_per_id=person_id).first()

        lng_id = 1 #Hard code English since this is for helpdesk
        ltr_ids = [2398, 1903, 9004, 1168, 9002, 9047, 1952]

        final_trans = get_translation(ltr_ids,lng_id)

        dict = {
            'submission_id': data['submissionID'],
            'form_name': data['formName'],
            'submission_datetime': data['submissionDateTime'],
            'submitted_by': full_name,
            'translations': final_trans
        }

        subject = final_trans[9002]
        from_email = user_email
        to_email = [config('EMAIL_SUPPORT_EMAIL')]

        html_content = get_template("resubmit_submission_email.html").render(dict)
        msg = EmailMultiAlternatives(subject, "", from_email, to_email)
        msg.attach_alternative(html_content, "text/html")
        msg.send()

        return Response({"Message": "Email sent successfully"})