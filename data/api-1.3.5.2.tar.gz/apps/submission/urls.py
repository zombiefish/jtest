from django.urls import path
from apps.submission import views
# from apps.form.models import CreateList

urlpatterns = [
    path('update-submission-archive/', views.UpdateSubmissionArchive.as_view()),
    path('get-submissionhap-by-headerid/', views.GetSubmissionHAPListByHeaderId.as_view()),
    path('get-submission-hap/', views.GetAllSubmissionHAP.as_view()),
    path('get-submission-pid/', views.GetAllSubmissionPID.as_view()),
    path('get-submission-hap-by-filter/', views.GetAllSubmissionHapByFilter.as_view()),
    path('get-submission-hap-by-filters-users-jobs/', views.GetAllSubmissionHapByFilterUsersJobs.as_view()),   
    path('check-submissions-synced/', views.CheckSubmissionsSynced.as_view()),
    path('missing-submissions-email/', views.MissingSubmissionsEmail.as_view()),
    path('resubmit-submission-email/', views.ReSubmitSubmissionEmail.as_view()),
]