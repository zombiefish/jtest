from django.contrib import admin
from .models import (
    AuthRoleSofvie,
    AuthPermissionSofvie,
    AuthUserRoleMappingSofive,
    AuthRolePermissionMappingSofive,
)

admin.site.register(AuthRoleSofvie)
admin.site.register(AuthPermissionSofvie)
admin.site.register(AuthUserRoleMappingSofive)
admin.site.register(AuthRolePermissionMappingSofive)