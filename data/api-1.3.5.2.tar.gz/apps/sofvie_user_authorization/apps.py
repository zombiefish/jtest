from django.apps import AppConfig


class SofvieUserAuthorizationConfig(AppConfig):
    name = 'apps.sofvie_user_authorization'
