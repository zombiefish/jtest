from django.db import models
from apps.form_builder.models import FormBuilder
from apps.person.models import Person
from apps.common_utils.views.sofvieModelFields import (
    SofvieCharField,
    SofvieIntegerField,
    SofvieTextField,
)
from apps.form.models import Form, Formcategories, Mobileforms


class AuthRoleSofvie(models.Model):
    aro_id = models.AutoField(primary_key=True)
    aro_name = SofvieIntegerField(blank=False, null=False)
    aro_tag_type = SofvieIntegerField(blank=False, null=False)
    aro_signoff_default = models.BooleanField(default=False)
    aro_created_date = models.DateTimeField(auto_now_add=True)
    aro_created_by_per_id = models.ForeignKey(
        "person.Person",
        db_column="aro_created_by_per_id",
        on_delete=models.DO_NOTHING,
        related_name="sofvie_auth_role_created",
    )
    aro_modified_date = models.DateTimeField(auto_now=True)
    aro_modified_by_per_id = models.ForeignKey(
        "person.Person",
        db_column="aro_modified_by_per_id",
        on_delete=models.DO_NOTHING,
        related_name="sofvie_auth_role_modified",
    )
    aro_enable = models.BooleanField(default=False)
    aro_enote = SofvieTextField(blank=True, null=True)
    aro_can_be_modified = models.BooleanField(default=False)

    class Meta:
        db_table = "auth_role_sofvie"


class AuthPermissionSofvie(models.Model):
    ape_id = models.AutoField(primary_key=True)
    ape_name = SofvieCharField(max_length=155)
    ape_display_name = SofvieIntegerField()
    ape_created_date = models.DateTimeField(auto_now_add=True)
    ape_created_by_per_id = models.ForeignKey(
        "person.Person",
        db_column="ape_created_by_per_id",
        on_delete=models.DO_NOTHING,
        related_name="sofvie_auth_permission_sofvie",
    )
    ape_modified_date = models.DateTimeField(auto_now=True)
    ape_modified_by_per_id = models.ForeignKey(
        "person.Person",
        db_column="ape_modified_by_per_id",
        on_delete=models.DO_NOTHING,
        related_name="sofvie_auth_permission_modified",
    )
    ape_parent_id = SofvieIntegerField(blank=True, null=True)
    ape_type_option = SofvieIntegerField(blank=True, null=True)
    ape_enable = models.BooleanField(default=False)
    ape_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = "auth_permission_sofvie"

    def __str__(self):
        return self.ape_name


class AuthUserRoleMappingSofive(models.Model):
    aur_id = models.AutoField(primary_key=True)
    aur_user_id = models.ForeignKey(
        "user.User",
        db_column="aur_user_id",
        related_name="sofvie_auth_user_role_mappings",
        on_delete=models.CASCADE,
    )
    aur_aro_id = models.ForeignKey(
        AuthRoleSofvie,
        db_column="aur_aro_id",
        related_name="sofvie_auth_user_role_mappings",
        on_delete=models.DO_NOTHING,
    )
    aur_created_date = models.DateTimeField(auto_now_add=True)

    aur_created_by_per_id = models.ForeignKey(
        Person,
        db_column="aur_created_by_per_id",
        on_delete=models.DO_NOTHING,
        related_name="sofvie_auth_role_mappings_created",
    )
    aur_modified_date = models.DateTimeField(blank=True, null=True)
    aur_modified_by_per_id = models.ForeignKey(
        Person,
        db_column="aur_modified_by_per_id",
        on_delete=models.DO_NOTHING,
        related_name="sofvie_auth_role_mappings_modified",
    )
    aur_enable = models.BooleanField(default=True)
    aur_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = "auth_user_role_sofvie"

    def __str__(self):
        return self.aur_user_id.name


class AuthRolePermissionMappingSofive(models.Model):
    arp_id = models.AutoField(primary_key=True)
    arp_aro_id = models.ForeignKey(
        AuthRoleSofvie,
        db_column="arp_aro_id",
        related_name="sofvie_auth_role_permission_mappings",
        on_delete=models.DO_NOTHING,
    )
    arp_ape_id = models.ForeignKey(
        AuthPermissionSofvie,
        db_column="arp_ape_id",
        related_name="sofive_auth_role_permission_mappings",
        on_delete=models.DO_NOTHING,
    )
    arp_created_date = models.DateTimeField(auto_now_add=True)
    arp_created_by_per_id = models.ForeignKey(
        "person.Person",
        db_column="arp_created_by_per_id",
        on_delete=models.DO_NOTHING,
        related_name="sofvie_auth_role_permission_mappings_created",
    )
    arp_modified_date = models.DateTimeField(auto_now=True)
    arp_modified_by_per_id = models.ForeignKey(
        "person.Person",
        db_column="arp_modified_by_per_id",
        on_delete=models.DO_NOTHING,
        related_name="sofivie_auth_role_permission_mappings_modified",
    )
    arp_enable = models.BooleanField(default=True)
    arp_enote = SofvieTextField(blank=True, null=True)

    class Meta:
        db_table = "auth_role_permission_sofvie"


class AuthRoleFormMappingSofvie(models.Model):
    arf_id = models.AutoField(primary_key=True)
    arf_aro = models.ForeignKey(
        AuthRoleSofvie, models.DO_NOTHING, related_name="sofvie_auth_role_form_mappings"
    )
    arf_mobileformid = models.ForeignKey(
        Mobileforms,
        models.DO_NOTHING,
        related_name="sofvie_auth_role_form_mappings",
        db_column="arf_mobileformid",
        null=True,
    )
    arf_fob = models.ForeignKey(
        FormBuilder,
        models.DO_NOTHING,
        related_name="arf_formbuilder_id",
        blank=True,
        null=True,
    )
    arf_created_date = models.DateTimeField(auto_now_add=True)
    arf_created_by_per_id = models.ForeignKey(
        "person.Person",
        models.DO_NOTHING,
        db_column="arf_created_by_per_id",
        related_name="sofvie_auth_role_form_mappings_created",
        blank=True,
        null=True,
    )
    arf_modified_date = models.DateTimeField(auto_now_add=True)
    arf_modified_by_per_id = models.ForeignKey(
        "person.Person",
        models.DO_NOTHING,
        db_column="arf_modified_by_per_id",
        related_name="sofvie_auth_role_form_mappings_modified",
        blank=True,
        null=True,
    )
    arf_enable = models.BooleanField(default=True)
    arf_enote = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = True
        db_table = "auth_role_form_sofvie"
