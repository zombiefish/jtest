from rest_framework import permissions

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.models import AuthRoleFormMappingSofvie, AuthRolePermissionMappingSofive


class IsSuperUserAdminUser(permissions.BasePermission):

    def has_permission(self, request, view):
        if request.user.is_superuser or request.user.roles.filter(
                aro_name='Super User').exists():
            return True
        return False

class SofviePermission(permissions.BasePermission):
    def has_permission(self, request, view):

        permission_attrs = getattr(view, 'permission_attrs',[])                        
        all_permissions = getattr(view, 'all_permissions', True)
        check_forms = getattr(view, 'check_forms', [])
        check_permission = True
        
        if check_forms:
            # query to check if user has permissions for all forms in check_forms - request.user
            check_form_permission = AuthRoleFormMappingSofvie.objects.filter(
                arf_enable = True,
                arf_mobileformid__in = check_forms,
                arf_aro_id__sofvie_auth_user_role_mappings__aur_user_id = request.user
            )

            return check_form_permission.exists()

        check_basic_permission = AuthRolePermissionMappingSofive.objects.filter(
                arp_ape_id = RolePermission.BasicAccess.value,
                arp_enable = True,
                arp_aro_id__sofvie_auth_user_role_mappings__aur_user_id=request.user,            
            ).exists()
        
        
        # return True if user has basic permission and no other permission is required i.e., permission_attrs is empty
        if len(permission_attrs) < 0 and check_basic_permission:
            return True

        # if user has basic permission and other permissions are required
        if check_basic_permission:
            
            # If user needs all permissions then check all permissions using for loop. 
            # else check using in operator, i.e., atleast on permission is required
            if all_permissions:                
                check_permission = check_all_permissions(request, permission_attrs)         
            else:                
                check_permission = AuthRolePermissionMappingSofive.objects.filter(
                    arp_ape_id__in = permission_attrs,
                    arp_enable = True,
                    arp_aro_id__sofvie_auth_user_role_mappings__aur_user_id=request.user,            
                ).exists()

            if check_permission:                        
                if not request.user.is_anonymous and check_permission:                  
                    return True
        return False

def check_all_permissions(request, permission_attrs):
    check_permission = True
    for permission in permission_attrs:
        check = AuthRolePermissionMappingSofive.objects.filter(
                arp_ape_id = permission,
                arp_enable = True,
                arp_aro_id__sofvie_auth_user_role_mappings__aur_user_id=request.user,            
            ).exists()
        if not check:
            check_permission = False 
            break       

    return check_permission
class SofvieBasePermissionMixin(object):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

