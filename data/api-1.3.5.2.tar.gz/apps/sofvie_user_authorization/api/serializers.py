from rest_framework import serializers

from apps.sofvie_user_authorization.models import AuthRoleSofvie, \
    AuthRolePermissionMappingSofive, AuthPermissionSofvie


class AuthRolePermissionMapSerialzier(serializers.ModelSerializer):
    model = AuthRolePermissionMappingSofive
    fields = [
        'arp_aro_id',
        'arp_ape_id',
        'arp_enable'
    ]

class AuthPermissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuthPermissionSofvie
        fields = [
            'ape_id',
            'ape_name',
            'ape_enable',

        ]
class AuthRoleSerializer(serializers.ModelSerializer):
    permissions = AuthPermissionSerializer(read_only=True)


    class Meta:
        model = AuthRoleSofvie
        fields = [
            'aro_id',
            'aro_name',
            'aro_tag_type',
            'aro_enable',
            'permissions',
        ]

    # def to_representation(self, instance):
    #     ret = super().to_representation(instance)
    #     # roles is 'sofvie_auth_role_mappings its not user.roles actually
    #     ret['permissions'] = instance.permission_id
    #     return ret


