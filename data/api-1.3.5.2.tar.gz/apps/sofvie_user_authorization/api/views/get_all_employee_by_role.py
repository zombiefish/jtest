from rest_framework import serializers, status
from rest_framework.exceptions import ValidationError
from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.person.models import Person
# from apps.person.api.views import  PersonSerializer
from ..permissions import SofvieBasePermissionMixin, SofviePermission
from ...models import AuthUserRoleMappingSofive

# Employee list APi
class GetEmployeeByRolesList(APIView):
    
    # used with archiving Role to check if any users are assigned to this role
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageAccess.value, RolePermission.ArchiveSubmissions.value,)

    class AuthUserRoleListSerializer(serializers.ModelSerializer):
        aur_user_id = serializers.SerializerMethodField()
        class Meta:
            model = AuthUserRoleMappingSofive
            fields = (
                'aur_user_id',                
            )        
        def get_aur_user_id(self, obj):            
            return obj.aur_user_id.name
    serializer_class = AuthUserRoleListSerializer

    def post(self, request):
        aro_id = request.data.pop('aro_id', '')
        queryset = AuthUserRoleMappingSofive.objects.filter(aur_aro_id=aro_id, aur_enable = 1)
        data = self.serializer_class(queryset, many=True).data  
        mydata = sorted(data, key=lambda k: k['aur_user_id'])
        return Response(mydata, status=status.HTTP_200_OK)