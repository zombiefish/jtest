from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from ..permissions import SofvieBasePermissionMixin, SofviePermission

from apps.sofvie_user_authorization.models import \
    AuthRolePermissionMappingSofive


class GetUserPermissionsList(APIView, SofvieBasePermissionMixin):
    permission_classes = [SofviePermission]

    # if api will access based on logged in user then use IsAuthenticated,
    # if API will access based on roles then use the following code
    def get(self, request):

        permission_list = AuthRolePermissionMappingSofive.objects.filter(
            arp_aro_id__sofvie_auth_user_role_mappings__aur_user_id=request.user, 
            arp_aro_id__sofvie_auth_user_role_mappings__aur_enable=1,
            arp_enable=True).values_list('arp_ape_id__ape_name', flat=True).distinct()
        return Response(permission_list)
