from apps.sofvie_user_authorization.api.views.create_role import addRole
from apps.language.api.views.helper_function_add_translation import helperAddTranslation
from rest_framework import serializers, status
from rest_framework.exceptions import ValidationError
from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.person.models import Person
from ..permissions import SofvieBasePermissionMixin, SofviePermission
from ...models import (
    AuthRoleFormMappingSofvie,
    AuthRoleSofvie,
    AuthRolePermissionMappingSofive,
    AuthPermissionSofvie,
    AuthUserRoleMappingSofive
)
from datetime import date, datetime


# update Role APi
class UpdateRole(APIView):
    # Basic Access
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageAccess.value,)
 
    class UpdateRoleListSerializer(serializers.ModelSerializer):
        class Meta:
            model = AuthRoleSofvie
            fields = ['aro_id', 'aro_name','aro_tag_type', 'aro_modified_date', 'aro_enable', 'aro_modified_by_per_id']
   

    serializer_class = UpdateRoleListSerializer


    def post(self, request):
        person_id = self.request.user.user_per_id_id
        payload_data = request.data
        aro_id = payload_data.pop('aro_id', '')
        aro_names = payload_data.pop('aro_names', '')
        '''
        get aro_names --> get tag from translation helper function
        send tag to database
        '''
        aro_name = helperAddTranslation(self, aro_names)


        isExists = AuthRoleSofvie.objects.filter(aro_name=aro_name).exclude(aro_id=aro_id).exists()
        # print('Isexists -- ', isExists)

        if isExists:
            return Response({"message": "Already Exists", "error":"Role Already Exists"})
        else:

            # update 
            prsn = Person.objects.get(per_id=person_id)        
            # print('person_id -- ', [person_id])

            soft_delete_AuthRoleSofvie = AuthRoleSofvie.objects.filter(aro_id=aro_id).update(
                aro_enable = False,
                aro_modified_date=datetime.now(), 
                aro_modified_by_per_id_id = person_id)

            soft_delete_AuthRoleFormMappingSofvie = AuthRoleFormMappingSofvie.objects.filter(arf_aro_id=aro_id).update(
                arf_enable = False, 
                arf_modified_date = datetime.now(),
                arf_modified_by_per_id = person_id
            )

            soft_delete_AuthRolePermissionMappingSofive = AuthRolePermissionMappingSofive.objects.filter(
                arp_aro_id_id=aro_id, 
                arp_ape_id_id=1
                ).update(
                    arp_enable = False,
                    arp_modified_date = datetime.now(),
                    arp_modified_by_per_id = person_id
                )          
            

            '''
            create a new aro record
            call addRole function from create_role.py
            '''
            add_role = addRole(self, aro_name, person_id)

            # add new role in AuthUserRoleMappingSofive
            user_role_exists = AuthUserRoleMappingSofive.objects.filter(aur_aro_id=aro_id).values_list('aur_user_id', flat=True)
            if user_role_exists:
                soft_delete_AuthUserRoleMappingSofive = AuthUserRoleMappingSofive.objects.filter(
                    aur_aro_id = aro_id
                ).update(
                    aur_enable = False,
                    aur_modified_by_per_id = person_id,
                    aur_modified_date = datetime.now()
                )

                AuthUserRoleMappingSofive.objects.bulk_create(
                    [AuthUserRoleMappingSofive(
                        aur_aro_id_id=add_role.aro_id, 
                        aur_created_date=datetime.now(), 
                        aur_created_by_per_id_id=person_id, 
                        aur_user_id_id = user_id) 
                        for user_id in user_role_exists]                    
                )       

            return Response({"message": "Record updated successfully", "error":""})