from rest_framework import viewsets
from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from rest_framework.views import APIView
from django.core import serializers

from apps.sofvie_user_authorization.api.serializers import \
    AuthRoleSerializer, AuthRolePermissionMapSerialzier, \
    AuthPermissionSerializer

from apps.sofvie_user_authorization.models import AuthRoleSofvie, \
    AuthRolePermissionMappingSofive, AuthPermissionSofvie


#
# class AuthRolePermissionMapViewSet(viewsets.ModelViewSet):
#     queryset = AuthRolePermissionMappingSofive.objects.all
#     serializer_class = AuthRolePermissionMapSerialzier

class AuthRolePermissionViewSet(viewsets.ModelViewSet):
    queryset = AuthRoleSofvie.objects.all()
    serializer_class = AuthRoleSerializer

    def get(self, request):
        queryset = AuthRoleSofvie.objects.filter(aro_enable=True)
        for query in queryset:
            # print(query.aro_id)
            for query in queryset:
                    role_permissions = AuthRolePermissionMappingSofive.objects.filter(
                        arp_enable = True,
                        arp_aro_id=query.aro_id).all()
                    query.aro_enote = []
                    for role_permission in role_permissions:
                        # arp_ape_id references to the object and not the id
                        permission = AuthPermissionSofvie.objects.filter(
                            ape_id=role_permission.arp_ape_id.ape_id).first()

                        json_perm = {
                            'id': permission.ape_id,
                            'name': permission.ape_name,
                            'enabled': permission.ape_enable
                        }
                        query.aro_enote.append(json_perm)

                # return Response(serializers.serialize('json', queryset))

        # serializer = AuthRoleSerializer(queryset, many=True)
        data = self.serializer_class(queryset, many=True).data
        return Response(data)




# class AuthRoleViewSet(ListAPIView):
#     # renderer_classes = [JSONRenderer]
#
#     def get(self, request, *args, **kwargs):
#         queryset = AuthRoleSofvie.objects.all()
#         for query in queryset:
#             role_permissions = AuthRolePermissionMappingSofive.objects.filter(
#                 arp_aro_id=query.aro_id).all()
#             query.aro_enote = []
#             for role_permission in role_permissions:
#                 # arp_ape_id references to the object and not the id
#                 permission = AuthPermissionSofvie.objects.filter(
#                     ape_id=role_permission.arp_ape_id.ape_id).first()
#
#                 json_perm = {
#                     'id': permission.ape_id,
#                     'name': permission.ape_name,
#                     'enabled': permission.ape_enable
#                 }
#                 query.aro_enote.append(json_perm)
#
#         # return Response(serializers.serialize('json', queryset))
#         return Response(serializers.serialize('json', queryset))
# serializer_class = AuthRoleSerializer
# serializer_class = AuthRoleSerializer

# def get_queryset(self):
#     active_role = AuthRoleSofvie.objects.filter(aro_enable=True).all()
#     return active_role
