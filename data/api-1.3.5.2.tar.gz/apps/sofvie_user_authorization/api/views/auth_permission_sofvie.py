from collections import defaultdict, ChainMap

from rest_framework import serializers, status
from rest_framework import response
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.language.models import Language, LanguageTranslation
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.sofvie_user_authorization.models import AuthPermissionSofvie
from apps.common_utils.views.get_translations import get_translation
from apps.user_settings_profile.models import UserProfile


class AuthPermissionSofvieListListApi(APIView):
    permission_classes = [SofviePermission]

    """
    {
        "ape_id": 1,
        "ape_permission" : "permission name",
        "child_permissions" : {
            "ape_id": 2,
            "ape_permission" : "permission name 2"
        },

   {
        "ape_id" : 3,
        "ape_permission": "permission name 3",
        "child_permissions" : {
            "ape_id":4,
            "ape_permission" : "permission name 4"
        }
    }
    
    """
    class AuthPermissionSofvieListSerializer(serializers.ModelSerializer):
        class Meta:
            model = AuthPermissionSofvie
            fields = ['ape_id', 'ape_name']

    serializer_class = AuthPermissionSofvieListSerializer

    def get(self, request):
        permissions = AuthPermissionSofvie.objects.all()
        serializer = self.serializer_class(permissions, many=True)
        return Response(serializer.data,status=status.HTTP_200_OK)


class PermissionCategory(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewAccess.value,)

    def get(self, request):

        # get all enabled permissions, excluding base permissions. 
        parent_queryset = AuthPermissionSofvie.objects.filter(ape_parent_id__isnull=True, ape_enable = True).exclude(ape_id=1).values('ape_id', 'ape_parent_id', 'ape_name','ape_display_name', 'ape_type_option').distinct()
        child_queryset = AuthPermissionSofvie.objects.filter(ape_parent_id__isnull=False, ape_enable = True).values('ape_id', 'ape_parent_id', 'ape_name', 'ape_display_name')

        globalPermissions=[]
        modulesPermissions=[]
        submissionsPermissions=[]

        displaynametags = AuthPermissionSofvie.objects.all().values_list('ape_display_name', flat=True)
        person_id = self.request.user.user_per_id_id
        lng_name = UserProfile.objects.get(upr_per= person_id).upr_language
        lng_id = Language.objects.get(lng_name = lng_name) 
        translateData = get_translation(displaynametags, lng_id)
 
        # return Response(translateData)
        for pq in parent_queryset:
            pq['parentSelected']=False
            pq['display_name']= translateData[pq['ape_display_name']]
            child_lst = [cq for cq in child_queryset if pq['ape_id'] == cq['ape_parent_id']]
            if child_lst:
                for cl in child_lst:
                    cl['display_name']= translateData[cl['ape_display_name']]
                    cl['childSelected']=False
                    cl['visibility']=True
                    sub_child_list = [cq for cq in child_queryset if cl['ape_id'] == cq['ape_parent_id']]
                    if sub_child_list:
                        for sc in sub_child_list:
                            sc['subchildSelected'] = False
                            sc['visibility']=True
                            sc['display_name']= translateData[sc['ape_display_name']]
                        sub_child_list = sorted(sub_child_list, key=lambda k: k['display_name']) 
                        cl['sub_child'] = sub_child_list
                child_lst = sorted(child_lst, key=lambda k: k['display_name']) 
                pq['child'] = child_lst
           
            if pq['ape_type_option'] == 1:
                globalPermissions.append(pq)
            if pq['ape_type_option'] == 2:
                modulesPermissions.append(pq)
            if pq['ape_type_option'] == 3:
                submissionsPermissions.append(pq)
            

        
        return Response({'global':globalPermissions,'modules':sorted(modulesPermissions, key=lambda k: k['display_name']) ,'submissions':submissionsPermissions})
