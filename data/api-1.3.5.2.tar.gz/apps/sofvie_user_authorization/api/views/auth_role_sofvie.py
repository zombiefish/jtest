from datetime import datetime
from django.db import transaction
from django.db.models.expressions import F, OuterRef, Subquery, Value, Case, When
from django.db.models import Q, DateField, Max
from django.db.models.functions import Cast
from django.db.models.functions.text import Concat
from rest_framework import serializers, status
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.person.models import Person
from ..permissions import SofviePermission
from ...models import (    
    AuthRoleFormMappingSofvie,
    AuthRoleSofvie,
    AuthRolePermissionMappingSofive    
)

from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile
from django.db.models import CharField


# Role list APi
class AuthRoleSofvieListApi(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewAccess.value,RolePermission.CanManageTargets.value,)
    # if at least one of the above permission is required then set it to False, otherwise set it to True
    all_permissions = False
    # todo   Need permissions to see this list if not superuser   

    def get(self, request, module):
        person = self.request.user.user_per_id
        lng_name = UserProfile.objects.get(upr_per=person).upr_language
        language_id = Language.objects.get(lng_name=lng_name)

        '''
        get all roles
        get all permissions for each role - group by role using pandas
        get all form access for each role - group by role using pandas 
        '''

        all_roles = AuthRoleSofvie.objects.filter(
                aro_enable=1
            ).annotate(
                role_trans=Subquery(
                    LanguageTranslation.objects.filter(
                        ltr_tag = OuterRef('aro_name'), 
                        ltr_tag_type = OuterRef('aro_tag_type'), 
                        ltr_lng_id = language_id
                    ).values('ltr_text')[:1]
                )
            ).values('aro_id', 'role_trans', 'aro_signoff_default', 'aro_tag_type', 'aro_enable', 'aro_enote')

        if module == 'admin':
            all_roles = get_permissions(self, language_id, all_roles)
            all_roles = get_form_access(self, language_id, all_roles)
        elif module == 'targets':
            all_roles = get_form_access(self, language_id, all_roles)

        return Response(all_roles)


def get_permissions(self, language_id, all_roles):
    all_permissions = AuthRolePermissionMappingSofive.objects.filter(
            arp_enable=True
    ).annotate(
        id=F('arp_ape_id'),
        enabled = F('arp_enable'),
        name = Subquery(
            LanguageTranslation.objects.filter(
                ltr_tag = OuterRef('arp_ape_id__ape_display_name'), 
                ltr_tag_type = 1, 
                ltr_lng_id = language_id
            ).values('ltr_text')[:1]
        ),
        created_date = F('arp_created_date'),
        created_by = Concat('arp_created_by_per_id__per_last_name', Value(' '), 'arp_created_by_per_id__per_first_name', Value(' '), 'arp_created_by_per_id__per_middle_name', output_field=CharField()),
    ).values(
        'id', 
        'arp_aro_id',
        'name',
        'enabled',
        'created_date',
        'created_by',
    ).order_by('name')


    from itertools import groupby

    def key_func(k):
        return k['arp_aro_id']
    
    all_permissions = sorted(all_permissions, key = key_func)

    final_dict = {}

    for key, value in groupby(all_permissions, key_func):
        final_dict[key] = list(value)    
    
    modified_data = get_role_modified_data()

    for role in all_roles:
        role_data = next((x for x in modified_data if x['arp_aro_id'] == role['aro_id']), None)
        role['role_modified_date'] = role_data['modified_date']
        role['role_modified_by'] = role_data['modified_by']
        
        role['permissions'] = final_dict[role['aro_id']] if role['aro_id'] in final_dict else []
    
    return all_roles

def get_role_modified_data():
    get_last_modified_data = AuthRolePermissionMappingSofive.objects.filter(
        arp_aro_id__aro_enable = True
    ).values(
        'arp_aro_id',
    ).annotate(
        last_modified_date = Max('arp_modified_date'),
    )

    filters= Q()
    for pair in get_last_modified_data:
        filters |= (Q(arp_aro_id__exact = pair['arp_aro_id']) & Q(arp_modified_date = pair['last_modified_date']))

    modified_data = AuthRolePermissionMappingSofive.objects.filter(filters).annotate(
        modified_by = Concat('arp_modified_by_per_id__per_last_name', Value(' '), 'arp_modified_by_per_id__per_first_name', Value(' '), 'arp_modified_by_per_id__per_middle_name', output_field=CharField()),
        modified_date = Cast('arp_modified_date', DateField())
    ).values(
        'arp_aro_id',
        'modified_by',
        'modified_date'
    ).order_by('arp_aro_id').distinct()

    return modified_data

def get_form_access(self, language_id, all_roles):
    # check for mfo_enable = True and as we have custom form_ids also mapped in AuthRoleFormMappingSofvie, check for mfo_enable__isnull = True against those predefined forms
    predefined_form_enable_filter = [Q(arf_mobileformid__mfo_enable = True) | Q(arf_mobileformid__mfo_enable__isnull = True)]
    # check for fob_enable = True and as we have predefined form_ids also mapped in AuthRoleFormMappingSofvie, check for fob_enable__isnull = True against those custom forms 
    custom_form_enable_filter = [Q(arf_fob__fob_enable = True) | Q(arf_fob__fob_enable__isnull = True)]
    
    person = self.request.user.user_per_id 
    
    all_form_access = AuthRoleFormMappingSofvie.objects.filter(
        *predefined_form_enable_filter,
        *custom_form_enable_filter,
        arf_enable=True,    
    ).annotate(        
        id= Case(
            When(arf_fob_id=None, then=F('arf_mobileformid')),
            When(arf_mobileformid=None, then=F('arf_fob_id')),               
            default=Value(''),
            output_field=CharField()
        ),           
        created_date = F('arf_created_date'),
        modified_date = F('arf_modified_date'),
        created_by = Concat('arf_created_by_per_id__per_last_name', Value(' '), 'arf_created_by_per_id__per_first_name', Value(' '), 'arf_created_by_per_id__per_middle_name', output_field=CharField()),
        modified_by = Concat('arf_modified_by_per_id__per_last_name', Value(' '), 'arf_modified_by_per_id__per_first_name', Value(' '), 'arf_modified_by_per_id__per_middle_name', output_field=CharField()),
        formID = Case(
            When(arf_mobileformid__isnull = False, then=F('arf_mobileformid__formid_id')),
            default = Value(None)
        ),            
        name = Case(
            When(arf_fob_id=None, then=Subquery(
                LanguageTranslation.objects.filter(
                    ltr_tag = OuterRef('arf_mobileformid__mobileformname'),
                    ltr_tag_type = 1,
                    ltr_lng_id = language_id
                ).values('ltr_text')[:1]
            )),
            When(arf_mobileformid=None, then=Subquery(
                LanguageTranslation.objects.filter(
                    ltr_tag = OuterRef('arf_fob__fob_name'),
                    ltr_tag_type = OuterRef('arf_fob__fob_tag_type'),
                    ltr_lng_id = language_id
                ).values('ltr_text')[:1]
            )),               
            default=Value(''),
            output_field=CharField()
        ),
        form_type=Case(
            When(arf_fob_id=None, then=Value('Pre-Defined Categories')),
            When(Q(arf_mobileformid=None) & Q(arf_fob__fob_fbc__isnull = False), then=Value('Custom Categories')),               
            When(Q(arf_mobileformid=None) & Q(arf_fob__fob_fca__isnull = False), then=Value('Custom-Form-Pre-Defined Categories')),               
            default=Value(''),
            output_field=CharField()
        ),
        form_category = Case(
            When(arf_fob_id=None, then=Subquery(
                LanguageTranslation.objects.filter(
                    ltr_tag = OuterRef('arf_mobileformid__formid__formcategoryid__category'),
                    ltr_tag_type = 1,
                    ltr_lng_id = language_id
                ).values('ltr_text')[:1]
            )),
            When(Q(arf_mobileformid=None) & Q(arf_fob__fob_fbc__isnull = False), then=Subquery(
                LanguageTranslation.objects.filter(
                    ltr_tag = OuterRef('arf_fob__fob_fbc__fbc_name'),
                    ltr_tag_type = OuterRef('arf_fob__fob_fbc__fbc_tag_type'),
                    ltr_lng_id = language_id
                ).values('ltr_text')[:1]
            )),
            When(Q(arf_mobileformid=None) & Q(arf_fob__fob_fca__isnull = False), then=Subquery(
                LanguageTranslation.objects.filter(
                    ltr_tag = OuterRef('arf_fob__fob_fca__category'),
                    ltr_tag_type = 1,
                    ltr_lng_id = language_id
                ).values('ltr_text')[:1]
            )),               
            default=Value(''),
            output_field=CharField()
        ),
    ).values(
        'id',
        'arf_aro_id',
        'created_date',
        'modified_date',
        'created_by',
        'modified_by',
        'formID',
        'arf_fob_id',            
        'name',
        'form_type',
        'form_category'
    ).order_by('name')

    from itertools import groupby

    def key_func(k):
        return k['arf_aro_id']
    
    all_form_access = sorted(all_form_access, key = key_func)

    final_dict = {}

    for key, value in groupby(all_form_access, key_func):
        final_dict[key] = list(value)

    modified_data = get_form_access_modified_data()

    for role in all_roles:
        try:
            role_data = next((x for x in modified_data if x['arf_aro_id'] == role['aro_id']), None)
            role['form_modified_date'] = role_data['modified_date']
            role['form_modified_by'] = role_data['modified_by']
            role['form_access'] = final_dict[role['aro_id']] if role['aro_id'] in final_dict else []
        except Exception as e:
            pass
        
        if "form_access" not in role:
            role['form_modified_date'] = role['form_modified_date'] if role['form_modified_date'] else datetime.now()
            role['form_modified_by'] = role['form_modified_by'] if role['form_modified_by']else person
            role['form_access'] = []
            
        
    return all_roles

def get_form_access_modified_data():
    get_last_modified_data = AuthRoleFormMappingSofvie.objects.filter(
        arf_aro_id__aro_enable = True
    ).values(
        'arf_aro_id',
    ).annotate(
        last_modified_date = Max('arf_modified_date'),
    )

    filters= Q()
    for pair in get_last_modified_data:
        filters |= (Q(arf_aro_id__exact = pair['arf_aro_id']) & Q(arf_modified_date = pair['last_modified_date']))

    modified_data = AuthRoleFormMappingSofvie.objects.filter(filters).annotate(
        modified_by = Concat('arf_modified_by_per_id__per_last_name', Value(' '), 'arf_modified_by_per_id__per_first_name', Value(' '), 'arf_modified_by_per_id__per_middle_name', output_field=CharField()),
        modified_date = Cast('arf_modified_date', DateField())
    ).values(
        'arf_aro_id',
        'modified_by',
        'modified_date'
    ).order_by('arf_aro_id').distinct()

    return modified_data
# # add permission to role
class AddPermissionsToRoleCreateApi(APIView):
    # todo we need to add custom permission to add permissions
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageAccess.value,)

    class AddPermissionToRoleCreateSerializer(serializers.Serializer):
        permissions = serializers.ListField(
            child=serializers.IntegerField(required=True))

    serializer_class = AddPermissionToRoleCreateSerializer
    
    @transaction.atomic
    def post(self, request, aro_id):
        person = self.request.user.user_per_id                    
            
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        permissions = serializer.validated_data.get('permissions')            

        try:
            role = AuthRoleSofvie.objects.get(aro_id=aro_id)
            # get current permissions for the aro_id in AuthRoleMappingSofvie table           

            existing_role_permissions = AuthRolePermissionMappingSofive.objects.filter(
                arp_aro_id=role, 
                arp_enable=True
            ).values_list('arp_ape_id', flat=True)
            
            
            new_permissions = [permission for permission in permissions if permission not in existing_role_permissions]
            deleted_permissions = [permission for permission in existing_role_permissions if permission not in permissions]            

            # set arp_enable to false for deleted permissions
            AuthRolePermissionMappingSofive.objects.filter(
                arp_aro_id=role, 
                arp_ape_id_id__in=deleted_permissions
            ).update(
                arp_enable=False,
                arp_modified_by_per_id=person,
                arp_modified_date=datetime.now()
            )
            
            # add new permissions - create bulk
            AuthRolePermissionMappingSofive.objects.bulk_create([
                AuthRolePermissionMappingSofive(
                    arp_aro_id=role,
                    arp_ape_id_id=permission,
                    arp_created_by_per_id=person,
                    arp_modified_by_per_id=person,
                ) for permission in new_permissions
            ])            

            return Response(serializer.data ,status=status.HTTP_200_OK)

        except AuthRoleSofvie.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'message':e},status=status.HTTP_400_BAD_REQUEST)

class AddFormAccessPermissionToRole(APIView):

    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageAccess.value,)


    @transaction.atomic
    def post(self, request):
        person = self.request.user.user_per_id 
        payload = request.data
        
        # following IDs originate from the MobileForms table.
        # 29 is employee discipline
        # 40 is 60 day review
        # 28 is annual review
        # 58 is JRA.
        # 56 is lifesaving rules
        # 3 is Incident Statement
        # 11 is Preliminary incident
        # 12 is Preliminary Investigation
        # 23 is VFL Audit
        # 34 is Daily log
        # 60 is Lockout Tagout Form

        rmm_id = [58]
        incident_ids = [3,11,12]
        dailylog_id = [34]
        management_ids=[23]
        hr_ids=[29,40,28,56]
        loto_id = [60]

        aro_id = payload['aro_id']

        if payload['rmm']=='ON':
            update_mapping_table(rmm_id, person, aro_id)
        elif payload['rmm']=='OFF':
            disable_mapping_table(rmm_id, person, aro_id)

        if payload['incident']=='ON':
            update_mapping_table(incident_ids, person, aro_id)
        elif payload['incident']=='OFF':
            disable_mapping_table(incident_ids, person, aro_id)

        if payload['dailylog'] == 'ON':
            update_mapping_table(dailylog_id, person, aro_id)
        elif payload['dailylog'] == 'OFF':
            disable_mapping_table(dailylog_id, person, aro_id)

        if payload['management']== 'ON':
            update_mapping_table(management_ids, person, aro_id)
        elif payload['management']== 'OFF':
            disable_mapping_table(management_ids, person, aro_id)

        if payload['hr'] == 'ON':
            update_mapping_table(hr_ids, person, aro_id)
        elif payload['hr'] == 'OFF':
            disable_mapping_table(hr_ids, person, aro_id)

        if payload['loto']=='ON':
            update_mapping_table(loto_id, person, aro_id)

        elif payload['loto']=='OFF':
            disable_mapping_table(loto_id, person, aro_id)

        return Response({"Message": "Done"})

# Disables the rforms for the role
def disable_mapping_table(ids, person, aro_id):
    for mob_form_id in ids:
                AuthRoleFormMappingSofvie.objects.filter(arf_aro_id = aro_id,
                    arf_mobileformid_id = mob_form_id, 
                    arf_enable = True).update(arf_enable = False, 
                    arf_modified_by_per_id=person, 
                    arf_modified_date=datetime.now())
                
# Activates the forms for the role.
def update_mapping_table(ids,person,aro_id):
    for mob_form_id in ids:
            access_count = AuthRoleFormMappingSofvie.objects.filter(arf_aro_id = aro_id,
                arf_mobileformid_id = mob_form_id, arf_enable = True).count()
            if access_count == 0:
                AuthRoleFormMappingSofvie.objects.create(
                    arf_aro_id = aro_id,
                    arf_mobileformid_id = mob_form_id,
                    arf_created_date =datetime.now(),
                    arf_created_by_per_id = person)
