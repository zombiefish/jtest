from django.utils import translation
from numpy import add
from rest_framework import serializers, status
from rest_framework.exceptions import ValidationError
from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db import transaction, IntegrityError

from apps.common_utils.views.validate_permission import RolePermission
from apps.person.models import Person
from ..permissions import SofvieBasePermissionMixin, SofviePermission
from ...models import (
    AuthRoleSofvie,
    AuthRolePermissionMappingSofive,
    AuthPermissionSofvie,
    AuthRoleFormMappingSofvie
)
from datetime import datetime
from apps.language.api.views.helper_function_add_translation import helperAddTranslation

# create Role APi
class CreateRole(APIView):
    # Basic Access
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageAccess.value,)

    
    def post(self, request):
        person_id = self.request.user.user_per_id_id        
        payload_data = request.data        
        aro_names = payload_data.pop('aro_names', '')
        '''
        aron_names -->
        get tag from translation helper function        
        add tag to database
        '''
        aro_name = helperAddTranslation(self, aro_names)                
        isExists = AuthRoleSofvie.objects.filter(aro_name=aro_name).exists()
        # print('isExists -- ',isExists )
        # queryset = AuthRoleSofvie.objects.get(aro_id=aro_id)
        if not isExists:
            # print('aro_name -- ', len(aro_name))
            if aro_name:
                add_role = addRole(self, aro_name, person_id)
                # print('Successfully created Roles')            
                return Response({"message": "saved successfully", "error":""})
            else:
                return Response({"message": "", "error":"please enter role name"})
        else:
            # print('Already exists')            
            return Response({"message": "Already exists", "error":"Role Already Exists"})

@transaction.atomic
def addRole(self, aro_name, person_id):
    role = AuthRoleSofvie.objects.create(
                aro_name=aro_name,
                aro_tag_type = 2,
                aro_created_by_per_id_id=person_id,
                aro_modified_by_per_id_id=person_id,
                aro_enable = 1,
                aro_can_be_modified = 1
        )

        # print('role -- ', role)
        # print('role -- ', role.aro_id)
        # insertedRole = AuthRoleSofvie.objects.get(aro_id=role.aro_id)  
        # print('insertedRole -- ', insertedRole)    

        # insert - auth_role_permission_sofvie
    AuthRolePermissionMappingSofive.objects.create(arp_aro_id_id=role.aro_id,
                                        arp_ape_id_id=1,
                                        arp_created_by_per_id_id=person_id,
                                        arp_modified_by_per_id_id=person_id)

    # print('role.aro_id, -- ', role.aro_id)
    # insert - auth_role_form_sofvie
    # POSITIVE IDENTIFICATION - 8
    if not AuthRoleFormMappingSofvie.objects.filter(
            arf_aro_id=role.aro_id,
            arf_mobileformid_id=8,
            arf_enable = True
    ).exists():
        AuthRoleFormMappingSofvie.objects.create(
            arf_aro_id=role.aro_id,
            arf_mobileformid_id=8,
            arf_created_by_per_id_id=person_id,
            arf_modified_by_per_id_id=person_id
        )

        # 44	GENERAL ACTION
    if not AuthRoleFormMappingSofvie.objects.filter(
            arf_aro_id=role.aro_id,
            arf_mobileformid_id=44,
            arf_enable = True
    ).exists():
        AuthRoleFormMappingSofvie.objects.create(
            arf_aro_id=role.aro_id,
            arf_mobileformid_id=44,
            arf_created_by_per_id_id=person_id,
            arf_modified_by_per_id_id=person_id
        )

    # 1	HAZARD REPORT
    if not AuthRoleFormMappingSofvie.objects.filter(
            arf_aro_id=role.aro_id,
            arf_mobileformid_id=1,
            arf_enable = True
    ).exists():
        AuthRoleFormMappingSofvie.objects.create(
            arf_aro_id=role.aro_id,
            arf_mobileformid_id=1,
            arf_created_by_per_id_id=person_id,
            arf_modified_by_per_id_id=person_id
        )


    # 41	PRE TASK
    if not AuthRoleFormMappingSofvie.objects.filter(
            arf_aro_id=role.aro_id,
            arf_mobileformid_id=41,
            arf_enable = True
    ).exists():
        AuthRoleFormMappingSofvie.objects.create(
            arf_aro_id=role.aro_id,
            arf_mobileformid_id=41,
            arf_created_by_per_id_id=person_id,
            arf_modified_by_per_id_id=person_id
        )

    # 42	PRE-OP
    if not AuthRoleFormMappingSofvie.objects.filter(
            arf_aro_id=role.aro_id,
            arf_mobileformid_id=42,
            arf_enable = True
    ).exists():
        AuthRoleFormMappingSofvie.objects.create(
            arf_aro_id=role.aro_id,
            arf_mobileformid_id=42,
            arf_created_by_per_id_id=person_id,
            arf_modified_by_per_id_id=person_id
        )
    
    return role
