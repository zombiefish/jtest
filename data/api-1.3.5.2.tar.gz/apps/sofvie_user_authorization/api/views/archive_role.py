from rest_framework import serializers, status
from rest_framework.exceptions import ValidationError
from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.validate_permission import RolePermission
from apps.person.models import Person
# from apps.person.api.views import  PersonSerializer
from ..permissions import SofvieBasePermissionMixin, SofviePermission
from ...models import AuthRoleSofvie, AuthUserRoleMappingSofive


# Archive role
class ArchiveRole(APIView):
    # Basic Access
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageAccess.value, RolePermission.ArchiveSubmissions.value,)

    def post(self, request):
        aro_id = request.data.pop('aro_id', '')
        # check aro_id is not mandatory and delete and check archive submissions and can manage access then proceed to delete

        can_archive_role = AuthRoleSofvie.objects.get(aro_id=aro_id).aro_can_be_modified
        if can_archive_role:            
            qs = AuthRoleSofvie.objects.filter(aro_id=aro_id).update(aro_enable=0)                
            queryset = AuthUserRoleMappingSofive.objects.filter(aur_aro_id=aro_id).update(aur_enable=0)
            return Response({"Message": "Archive successfully"})            
        else:
            return Response({"Message": "You don't have permission to archive this role"}, status=status.HTTP_403_FORBIDDEN)