from rest_framework import serializers, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Q

from apps.common_utils.views.validate_permission import RolePermission
from apps.user_settings_profile.models import UserProfile
from apps.language.models import LanguageTranslation, Language

from ..permissions import SofviePermission
from ...models import (
    AuthRoleSofvie,
)
import sys

class AuthRoleListSerializer(serializers.ModelSerializer):
    aro_name_trans = serializers.SerializerMethodField()
    aro_names = serializers.SerializerMethodField()


    
    class Meta:
        model = AuthRoleSofvie
        fields = (
            'aro_id', 
            'aro_modified_date', 
            'aro_enable', 
            'aro_modified_by_per_id', 
            'aro_can_be_modified',
            'aro_name_trans',
            'aro_names',
            'aro_signoff_default'
        )
    
    def __init__(self, *args, **kwargs):
        person = kwargs["context"].get("request").user.user_per_id        
        lang_name = UserProfile.objects.get(upr_per=person).upr_language
        self.lang_id = Language.objects.get(lng_name=lang_name).lng_id         
        self.selected_languages = list(Language.objects.filter(lng_selected=True).values_list('lng_id', flat=True))

        super(AuthRoleListSerializer, self).__init__(*args, **kwargs)
    
    def get_aro_name_trans(self, instance):
        try:            
            role_trans_queryset = LanguageTranslation.objects.filter(
                ltr_tag = instance.aro_name,
                ltr_tag_type = instance.aro_tag_type,
                ltr_lng=self.lang_id
            ).values_list('ltr_text', flat=True)[0]

            return role_trans_queryset
        except Exception as e:           
            return instance.aro_name

    def get_aro_names(self, instance):
        aro_names = []
        if instance.aro_can_be_modified:
            aro_names = LanguageTranslation.objects.filter(
                            ltr_lng_id__in = self.selected_languages,
                            ltr_tag = instance.aro_name, 
                            ltr_tag_type = instance.aro_tag_type
                        ).values('ltr_lng_id', 'ltr_text', 'ltr_translated')                                
        return aro_names
    

# Role list APi
class GetRolesList(APIView):
    permission_classes = [SofviePermission]

    def get(self, request, mode):
        person_id = self.request.user.user_per_id_id       
        lang_name = UserProfile.objects.get(upr_per=person_id).upr_language
        lng_id = Language.objects.get(lng_name=lang_name).lng_id   

        role_data = get_roles_list(self, lng_id, mode)
        
        return Response(role_data, status=status.HTTP_200_OK)


def get_roles_list(self, lng_id, mode = 'all'):
    filter_value = []
    if mode == 'active':
        filter_value = [Q(aro_enable = 1)]
    queryset = AuthRoleSofvie.objects.filter(*filter_value)

    data = AuthRoleListSerializer(queryset, context={'request': self.request} , many=True).data
    

    try:
        mydata = sorted(data, key=lambda k: k['aro_name_trans'])
    except:
        mydata = data

    if mode == 'all':
        mydata = map(lambda obj: add_inactive(obj), mydata)        
    inactive_label = LanguageTranslation.objects.get(ltr_tag = 3793, ltr_tag_type = 1, ltr_lng_id = lng_id).ltr_text

    def add_inactive(obj):
        if obj['aro_enable'] == 0:
            obj['aro_name_trans']   = f"{obj['aro_name_trans']} ({inactive_label})"            
        return obj
    
    return mydata
