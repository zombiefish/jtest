from datetime import datetime
from rest_framework import serializers, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Q
from apps.common_utils.views.validate_permission import RolePermission
from apps.person.models import Person
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.sofvie_user_authorization.models import AuthRoleSofvie, \
    AuthRoleFormMappingSofvie
from apps.form.models import Mobileforms
from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile

# Form List API

class FormListApi(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewAccess.value,)

    class FormListSerializer(serializers.ModelSerializer):
        mobileformname_trans = serializers.SerializerMethodField()


        def get_mobileformname_trans(self, instance):
            try:
                person = self.context['request'].user.user_per_id
                lng_name = UserProfile.objects.get(upr_per= person).upr_language
                lng_id = Language.objects.get(lng_name = lng_name)


                mobileformname_trans_queryset = LanguageTranslation.objects.filter(
                    ltr_tag = instance.mobileformname,
                    ltr_tag_type = 1,
                    ltr_lng=lng_id
                ).values_list('ltr_text', flat=True)[0]

                return mobileformname_trans_queryset
            except:
                return instance.mobileformname

        class Meta:
            model = Mobileforms
            fields = [
                'mobileformid',
                'mobileformname',
                'formid',
                'formurl',
                'mobileformname_trans'
            ]

    serializer_class = FormListSerializer

    def get(self, request):
        queryset = Mobileforms.objects.filter(mfo_enable=True).order_by('mobileformname')
        # queryset = Mobileforms.objects.all()
        serializer = self.serializer_class(queryset, context={'request': request}, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


# # add form access to self.role
class AddFromAccessToRoleCreateApi(APIView):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageAccess.value,)

    #     Create Serializer of all the forms
    class AddFromAccessToRoleCreateSerializer(serializers.Serializer):
        pre_defined_forms = serializers.ListField(child=serializers.IntegerField(required=True))
        custom_category_forms = serializers.ListField(child=serializers.IntegerField(required=True))

    serializers_class = AddFromAccessToRoleCreateSerializer

    #     Create Post function to add Form Access to Role

    def post(self, request, aro_id):       

        self.person = self.request.user.user_per_id       
        
        serializer = self.serializers_class(data=request.data)
        # validate the serialize data
        serializer.is_valid(raise_exception=True)
        # validate form data from form object in create serialzer class
        pd_forms_permissions = serializer.validated_data.get('pre_defined_forms')
        cc_forms_permissions = serializer.validated_data.get('custom_category_forms')        

        # Try Catch block
        try:
            self.role = AuthRoleSofvie.objects.get(aro_id=aro_id)

            add_or_update_form_access(self,pd_forms_permissions, 'arf_mobileformid')
            add_or_update_form_access(self,cc_forms_permissions, 'arf_fob')            

            return Response({"message":"Permissions addedd successfully"}, status=status.HTTP_200_OK)
            
        except AuthRoleSofvie.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
        
        except Exception as e:
            return Response({'message':e},status=status.HTTP_400_BAD_REQUEST)

        
def add_or_update_form_access(self, forms_permissions, key):
    existing_access_permissions = AuthRoleFormMappingSofvie.objects.filter(
        arf_aro_id=self.role, 
        arf_enable=True
    ).values_list(key, flat=True)

    new_permissions = [permission for permission in forms_permissions if permission not in existing_access_permissions]
    deleted_permissions = [permission for permission in existing_access_permissions if permission not in forms_permissions]
    
    form_id_filter = []
    if key == 'arf_mobileformid':
        form_id_filter = [Q(arf_mobileformid__in = deleted_permissions)]
        # add new permissions - create bulk
        bulk_data = [
            AuthRoleFormMappingSofvie(
                arf_aro=self.role,
                arf_mobileformid_id=permission,
                arf_created_by_per_id=self.person,
                arf_modified_by_per_id=self.person,
            ) for permission in new_permissions
        ]
    elif key == 'arf_fob':
        form_id_filter = [Q(arf_fob__in = deleted_permissions)]  
        # add new permissions - create bulk
        bulk_data = [
            AuthRoleFormMappingSofvie(
                arf_aro=self.role,
                arf_fob_id=permission,
                arf_created_by_per_id=self.person,
                arf_modified_by_per_id=self.person,
            ) for permission in new_permissions
        ]           

    # set arf_enable to false for deleted permissions
    AuthRoleFormMappingSofvie.objects.filter(
        *form_id_filter,
        arf_aro_id=self.role,         
        arf_enable = True
    ).update(
        arf_enable=False,
        arf_modified_by_per_id=self.person,
        arf_modified_date = datetime.now()
    )
    
    AuthRoleFormMappingSofvie.objects.bulk_create(bulk_data, batch_size=100)