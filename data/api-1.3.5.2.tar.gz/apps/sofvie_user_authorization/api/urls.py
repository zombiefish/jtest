from django.urls import path, include

from . import views
from rest_framework import routers

from .views.get_user_permissions_list import GetUserPermissionsList
from .views.views import AuthRolePermissionViewSet

from .views.get_role_list import GetRolesList
from .views.update_role import UpdateRole
from .views.create_role import CreateRole
from .views.get_all_employee_by_role import GetEmployeeByRolesList
from .views.archive_role import ArchiveRole


router = routers.DefaultRouter()
router.register(r'roles-permission', AuthRolePermissionViewSet, basename='role')


permissions = [
    # path('auth-permissions/', views.AuthPermissionSofvieListListApi.as_view()),
    path('permissions-category/', views.PermissionCategory.as_view()),
]
roles = [
    path('roles/<str:module>/', views.AuthRoleSofvieListApi.as_view()),
    path('user-role-and-permissions/', GetUserPermissionsList.as_view()),
    # path('form-list/', views.FormListApi.as_view()),
    path('roles/<int:aro_id>/add-permissions/',
         views.AddPermissionsToRoleCreateApi.as_view()),
    path('roles/<int:aro_id>/add-update-form-access/',
         views.AddFromAccessToRoleCreateApi.as_view()),
    path('get-role-list/<str:mode>/', GetRolesList.as_view()),
    path('update-role/', UpdateRole.as_view()),
    path('create-role/', CreateRole.as_view()),
    path('get-employee-by-role/', GetEmployeeByRolesList.as_view()),
    path('archive-role/', ArchiveRole.as_view()),
    path('', include(router.urls)),
    path('add-form-access-permission-to-role/', views.AddFormAccessPermissionToRole.as_view())
]

urlpatterns = roles + permissions