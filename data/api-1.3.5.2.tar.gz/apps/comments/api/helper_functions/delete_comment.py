from apps.comments.models import Comments


def delete_comment(com_obj, ids):
    com_obj_ids = com_obj.objects.filter(com_reference_id__in=ids)
    for c in com_obj_ids:
        c.com_enable = False

    Comments.objects.bulk_update(com_obj_ids, ['com_enable'])








