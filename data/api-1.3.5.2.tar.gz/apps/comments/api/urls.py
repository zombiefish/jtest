from django.urls import path

from apps.comments.api.views.add_comment import AddComment, AddMultipleComment
from apps.comments.api.views.update_comment import UpdateComment
from apps.comments.api.views.delete_comment import DeleteComment

urlpatterns = [
    path('add-comment/', AddComment.as_view()),
    path('add-multiple-comment/', AddMultipleComment.as_view()),
    path('update-comment/', UpdateComment.as_view()),
    path('delete-comment/', DeleteComment.as_view()),
]