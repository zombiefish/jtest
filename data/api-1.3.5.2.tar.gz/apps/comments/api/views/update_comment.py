from datetime import datetime

from rest_framework.response import Response
from rest_framework.views import APIView

from apps.comments.models import Comments
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class UpdateComment(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):
        person_id = request.user.user_per_id_id
        com_id = request.data['com_id']
        updated_comment = request.data['com_comment']

        get_com_id = Comments.objects.get(com_id=com_id,com_enable=True)
        for key, value in request.data.items():
            setattr(get_com_id, key, value)
        get_com_id.com_comment = updated_comment
        get_com_id.com_modified_by_per_id = person_id
        get_com_id.com_modified_date = datetime.now()
        get_com_id.save()

        return Response({"com_id": com_id})
