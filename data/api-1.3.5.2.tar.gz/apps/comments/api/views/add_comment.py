from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.comments.models import Comments
from apps.recognition.api.views.email_notification import send_email_positive_recognition
from apps.recognition.models import SubmissionPositiveRecognitionPerson
from apps.reflist.models import RefListDetail
from apps.sofvie_user_authorization.api.permissions import SofviePermission


def add_comment(com_cmt_id, com_reference_id, com_comment, person_id, position_id = None):

    if len(com_comment) > 0:
        position_rld_id = RefListDetail.objects.prefetch_related(
                'employees_pos'
            ).filter(employees_pos__emp_per_id=person_id).values_list('rld_id', flat=True)
        

        # if the user does not have a position assigned, set to None. 
        position_id = position_rld_id[0] if position_rld_id.count() > 0 else None

        obj = Comments.objects.create(
            com_cmt_id=com_cmt_id,
            com_reference_id=com_reference_id,
            com_comment=com_comment,
            com_position_id=position_id,
            com_created_by_per_id=person_id
        )
        return obj
   

class AddComment(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):
        person_id = request.user.user_per_id_id

        com_cmt_id = request.data['com_cmt_id']
        com_reference_id = request.data['com_reference_id']
        com_comment = request.data['com_comment']

        position_rld_id = RefListDetail.objects.prefetch_related(
            'employees_pos'
        ).filter(employees_pos__emp_per_id=person_id).values_list('rld_id', flat=True)

        position_rld_id = position_rld_id[0] if list(position_rld_id) else None
        
        try:
            existing_comment=Comments.objects.get(com_cmt_id=com_cmt_id,com_reference_id=com_reference_id,com_enable=True).com_id  
            return Response({
                    "Received data": request.data, 
                    "Message": "Object already exist"
                    },status=status.HTTP_400_BAD_REQUEST) 

        except Comments.DoesNotExist:
            obj = add_comment(com_cmt_id, com_reference_id, com_comment, person_id, position_rld_id)
            if obj is None:
                return Response(status=status.HTTP_204_NO_CONTENT)
            
            if obj.com_cmt_id == 11:            
                pid= obj.com_reference_id
                pid_persons = SubmissionPositiveRecognitionPerson.objects.filter(
                    submissionpositiverecognition_id = pid
                ).values_list('recognitionof', flat=True)
                
                if person_id not in pid_persons:
                    send_email_positive_recognition(self, 'new_comment', pid= pid, com_id=obj.com_id)

            return Response({"com_id": obj.com_id}, status=status.HTTP_201_CREATED)


class AddMultipleComment(APIView):
    permission_classes = [SofviePermission]

    def post(self, request):
        person_id = request.user.user_per_id_id

        com_cmt_id = request.data['com_cmt_id']
        com_reference_id = request.data['com_reference_id']
        com_comment = request.data['com_comment']

        position_rld_id = RefListDetail.objects.prefetch_related(
            'employees_pos'
        ).filter(employees_pos__emp_per_id = person_id).values_list('rld_id', flat=True)

        position_rld_id = position_rld_id[0] if list(position_rld_id) else None

        obj = add_comment(com_cmt_id, com_reference_id, com_comment, person_id, position_rld_id)
        if obj is None:
            return Response(status=status.HTTP_204_NO_CONTENT)
        if obj.com_cmt_id == 11:
            pid = obj.com_reference_id
            pid_persons = SubmissionPositiveRecognitionPerson.objects.filter(
                submissionpositiverecognition_id=pid
            ).values_list('recognitionof', flat=True)

            if person_id not in pid_persons:
                send_email_positive_recognition(self, 'new_comment', pid=pid, com_id=obj.com_id)

        return Response({"com_id": obj.com_id}, status=status.HTTP_201_CREATED)
