from django.contrib import admin

# Register your models here.
from apps.comments.models import CommentsTable, Comments

admin.site.register(CommentsTable)
admin.site.register(Comments)