from django.db import models

# Create your models here.
from django.db.models import (
    Model,
    AutoField,
    IntegerField,
    CharField,
    DateTimeField,
    ForeignKey,
    ManyToManyField,
    BooleanField,
    TextField,
    DateField,
    DecimalField, F, Value, Subquery, OuterRef
)

from apps.common_utils.views.sofvieModelFields import(
    SofvieCharField,
    SofvieIntegerField,
    SofvieTextField
)

from apps.person.models import Person
from apps.reflist.models import RefListDetail


class CommentsTable(models.Model):
    cmt_id = AutoField(primary_key=True, )
    cmt_name = SofvieCharField(blank=False, null=False, max_length=200, help_text='Add the comment table name here')
    cmt_description = SofvieCharField(blank=False, null=False, max_length=200, help_text='Add the comment table description')
    cmt_created_date = DateTimeField(auto_now_add=True, null=False, blank=False, help_text='Add automatically created date, when record is inserted')
    cmt_created_by_per = ForeignKey(Person, blank=False, null=False, on_delete=models.DO_NOTHING, related_name='comment_created_person', help_text='Add the foreign key of logged in person')
    cmt_modified_date = DateTimeField(auto_now=True, blank=True, null=True, )
    cmt_modified_date_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, related_name='comment_modified_person', help_text='Add logged in person id, when they update the record')
    cmt_enable = BooleanField(default=True, help_text='Add 0 or 1 for soft delete record')
    cmt_enote = SofvieCharField(max_length=200, blank=True, null=True, help_text='Use for internal purpose')

    class Meta:
        db_table = 'comment_table'

    def __str__(self):
        return self.cmt_name


class Comments(Model):
    com_id = AutoField(primary_key=True)
    com_cmt = ForeignKey(CommentsTable, blank=False, null=False, on_delete=models.DO_NOTHING, related_name='comment_commenttable', help_text='Add the foreign key from comment table when new comment inserted')
    com_reference_id = SofvieIntegerField(blank=False, null=False, help_text='Add the image id from associated table')
    com_comment = SofvieTextField(blank=True, null=True, help_text='Add the comment text')
    com_position = ForeignKey(RefListDetail, blank=True, null=True, on_delete=models.DO_NOTHING, related_name='comment_position', help_text='Add the foreign key of ref list detail for position rld_id, when new comment inserted')
    com_created_date = DateTimeField(auto_now_add=True, blank=False, null=False, help_text='Add the datetime when new record inserted')
    com_created_by_per = ForeignKey(Person, blank=False, null=False, on_delete=models.DO_NOTHING, related_name='person_comment', help_text='Add the logged in user id when they write comment')
    com_modified_date = DateTimeField(blank=True, null=True, help_text='Add the datetime when logged in user update the record')
    com_modified_by_per = ForeignKey(Person, blank=True, null=True, on_delete=models.DO_NOTHING, help_text='Add the logged in user id when they update the record')
    com_enable = BooleanField(default=True, help_text='Add the 0 or 1 for soft delete')
    com_enote = SofvieCharField(max_length=200, blank=True, null=True, help_text='Use for internal purpose')

    class Meta:
        db_table = 'comment'

    def __str__(self):
        return self.com_comment
