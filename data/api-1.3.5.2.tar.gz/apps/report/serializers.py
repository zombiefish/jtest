from rest_framework import serializers
from apps.formnavigation.models import MenuItem, FormCategory

class MenuItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuItem
        fields = '__all__'     

class FormCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = FormCategory
        fields = '__all__'           
