from django.urls import path
from apps.report import views

urlpatterns = [
    path('reportlist/', views.GetReportList.as_view()),
    path('groupby-reportlist/<int:report_id>/', views.GetGroupbyReportList.as_view()),
]