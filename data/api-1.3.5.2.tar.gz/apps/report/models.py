from django.db import models
from django.db import connection

class MenuItem(models.Model):
    id = models.IntegerField(db_column='temp_id', primary_key=True)
    path = models.IntegerField(db_column='path')
    name = models.CharField(db_column='name', max_length=64)
    subform =  models.BooleanField(db_column='subform')
    SubformID =  models.IntegerField(db_column='SubformID')
    SubformKey = models.CharField(db_column='SubformKey', max_length=32)
    order =  models.DecimalField(db_column='Site', decimal_places = 2, max_digits = 8)
    formDescriptionId =  models.IntegerField(db_column='formDescriptionId')
    formCategoryId =  models.IntegerField(db_column='formCategoryId')
    class Meta:
        managed = False
        db_table = 'menuitem' 

class FormCategory(models.Model):
    id = models.IntegerField(db_column='temp_id', primary_key=True)
    category = models.IntegerField(db_column='category')
    order =  models.IntegerField(db_column='Site')
    class Meta:
        managed = False
        db_table = 'all_formcategories' 