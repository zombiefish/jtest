from django.db import connection
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission
from apps.general_action.models import Reports
from django.db.models import Subquery, OuterRef, F

# reading .env file
# environ.Env.read_env()
from apps.incident_management.api.utlity_function import dictfetchall
from apps.language.models import Language, LanguageTranslation
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile


class GetReportList(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewReports.value,)
    def get(self, request):

        lang_name = UserProfile.objects.get(upr_per=request.user.user_per_id).upr_language    
        lang_id = Language.objects.get(lng_name = lang_name).lng_id

        with connection.cursor() as cursor:
            cursor.execute("call get_report_list_by_language(%s)", (lang_id,))
            row = dictfetchall(cursor)
        
        return Response(row)


class GetGroupbyReportList(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewReports.value,)

    def get(self, request, report_id):
        lang_name = UserProfile.objects.get(upr_per=request.user.user_per_id).upr_language
        lng_id = Language.objects.get(lng_name = lang_name).lng_id
        
        groupby_data = Reports.objects.filter(
            rpt_rpt_id = report_id
        ).annotate(
            rpt_id = F('id'),
            rpt_name = Subquery(
                LanguageTranslation.objects.filter(
                    ltr_enable = True,
                    ltr_lng_id = lng_id,
                    ltr_tag = OuterRef('reportname'),
                    ltr_tag_type = 1
                ).values('ltr_text')[:1]
            )
        ).values('rpt_id', 'rpt_name')

        return Response(groupby_data)