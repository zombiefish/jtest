from django.apps import AppConfig


class LlmConfig(AppConfig):
    name = 'apps.llm'
