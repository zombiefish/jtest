from django.urls import path
from . import views

from apps.llm.api.views.create_lesson_learned import CreateLessonLearned
from .views.add_lesson_learned_general_action import \
    AddLessonLearnedGeneralAction
from .views.add_lesson_learned_hazard_action import AddLessonLearnedHazardAction
from .views.add_lessons_learned_attachment import AddLessonsLearnedAttachments
from .views.add_unacknowledged import AddLessonLearnedUnAcknowledged
from .views.archive_lesson_learned import ArchiveLessonLearned
from .views.get_lesson_learned_general_action import \
    GetLessonLearnedGeneralAction
from .views.get_lesson_learned_hazard_action import GetLessonLearnedHazardAction
from .views.get_lessons_learned_attachments import GetLessonsLearnedAttachments
from .views.get_lessons_learned_list import GetLessonsLearnedList
from .views.remove_lessons_learned_attachments import \
    RemoveLessonsLearnedAttachments
from .views.update_lesson_learned import UpdateLessonLearned
from .views.add_acknowledged import AddLessonLearnedAcknowledged

urlpatterns = [
    path('add-lesson-learned/', CreateLessonLearned.as_view()),
    path('add-lessons-learned-attachments/',
         AddLessonsLearnedAttachments.as_view()),
    path('remove-lessons-learned-attachments/',
         RemoveLessonsLearnedAttachments.as_view()),
    path('get-lessons-learned-attachments/',
         GetLessonsLearnedAttachments.as_view()),
    path('update-lesson-learned/', UpdateLessonLearned.as_view()),
    path('lesson-learned-acknowledged/', AddLessonLearnedAcknowledged.as_view()),
    path('lesson-learned-unacknowledged/',
         AddLessonLearnedUnAcknowledged.as_view()),
    path('get-lesson-learned-list/', GetLessonsLearnedList.as_view()),
    path('add-lesson-learned-general-action/',
         AddLessonLearnedGeneralAction.as_view()),
    path('add-lesson-learned-hazard-action/',
         AddLessonLearnedHazardAction.as_view()),
    path('get-lesson-learned-general-action/',
         GetLessonLearnedGeneralAction.as_view()),
    path('get-lesson-learned-hazard-action/',
         GetLessonLearnedHazardAction.as_view()),
    path('archive-lesson-learned/',
         ArchiveLessonLearned.as_view()),

    
]