from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.validate_permission import RolePermission

from apps.llm.api.serializers.serializers import \
    GetLessonsLearnedAttachmentsSerializer
from apps.llm.models import LessonLearnedAttachment
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class GetLessonsLearnedAttachments(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewLessonsLearned.value,)


    def post(self, request):
        payload_data = request.data
        llm_id = payload_data.pop('llm_id', '')
        lat_qs = LessonLearnedAttachment.objects.filter(lat_llm_id=llm_id,
                                                        lat_enable=True)
        lat_serializer = GetLessonsLearnedAttachmentsSerializer(lat_qs, many=True)
        return Response(lat_serializer.data)