from datetime import datetime
from apps.general_action.models import SubmissionGeneralAction, Submissionheader
from apps.hazard_action.models import Submissionhap
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db import transaction
from apps.llm.models import LessonLearnedAcknowledged, LessonLearned, LessonLearnedGeneralAction, LessonLearnedHazardAction

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class ArchiveLessonLearned(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.ArchiveSubmissions.value,)
    
    @transaction.atomic
    def post(self, request):
        person_id = self.request.user.user_per_id_id
        llm_ids = [each['llm_id'] for each in request.data] 

        # Archive LEssons Learned Record
        LessonLearned.objects.filter(
            llm_id__in=llm_ids
        ).update(
            llm_enable=False,
            llm_archived_date=datetime.now(),
            llm_archived_by_per_id=person_id
        )

        # archive the General Actions
        LessonLearnedGeneralAction.objects.filter(llg_llm__in=llm_ids).update(
            llg_enable=False,
            llg_modified_date=datetime.now(),
            llg_modified_by_per_id=person_id
        )
        
        sga_ids = LessonLearnedGeneralAction.objects.filter(llg_llm__in=llm_ids).values_list('llg_sga_id', flat=True)
        SubmissionGeneralAction.objects.filter(
            sga_id__in=sga_ids
        ).update(
            sga_enable=False,
            sga_archived_by_per_id=person_id,
            sga_archived_date=datetime.now()
        )
        gen_sub_ids = SubmissionGeneralAction.objects.filter(sga_id__in=sga_ids).values_list('sga_submission_header', flat=True)
        Submissionheader.objects.filter(id__in=gen_sub_ids).update(
            isarchived=True,
            archiveddate=datetime.now(),
            archived_by_per=person_id
        )

        # Archive the Hazard Actions
        LessonLearnedHazardAction.objects.filter(llh_llm__in=llm_ids).update(
            llh_enable=False,
            llh_modified_date=datetime.now(),
            llh_modified_by_per_id=person_id
        )
        hap_ids = LessonLearnedHazardAction.objects.filter(
                    llh_llm__in=llm_ids).values_list('llh_sha_id', flat=True)
        Submissionhap.objects.filter(
            id__in=hap_ids
        ).update(
            sha_enable=False,
            sha_archived_date=datetime.now(),
            sha_archived_by_per=person_id
        )
        hap_sub_ids = Submissionhap.objects.filter(id__in=hap_ids).values_list('submissionheaderid', flat=True)
        Submissionheader.objects.filter(id__in=hap_sub_ids).update(
            isarchived=True,
            archiveddate=datetime.now(),
            archived_by_per=person_id
        )

        return Response({"message": "Record archive successfully"})
