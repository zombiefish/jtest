from datetime import datetime
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status


from apps.common_utils.views.validate_permission import RolePermission
from apps.llm.models import LessonLearnedHazardAction
from apps.sofvie_user_authorization.api.permissions import SofviePermission

class AddLessonLearnedHazardAction(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageLessonsLearned.value,)

    def post(self, request, *args, **kwargs):

        try:

            person_id = self.request.user.user_per_id_id

            llm_sha_ids = request.data.pop('llh_sha',[])

            bulk_create_object = [LessonLearnedHazardAction(
                llh_llm_id = request.data['llh_llm'],
                llh_created_date = datetime.now(),
                llh_created_by_per_id = person_id,
                llh_sha_id = sha_id
            ) for sha_id in llm_sha_ids ]

            LessonLearnedHazardAction.objects.bulk_create(bulk_create_object)
            return Response({"message":"success"}, status = status.HTTP_200_OK)
        except Exception as e:
             return Response({"message": f"Failed to update lessons learned hazard action. {e}"}, status = status.HTTP_400_BAD_REQUEST)
