from rest_framework.response import Response
from rest_framework.views import APIView
from apps.common_utils.views.add_attachment import save_the_file
from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class AddLessonsLearnedAttachments(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageLessonsLearned.value,)

    def post(self, request):
        person_id = request.user.user_per_id_id
        llm_id = request.POST['llm_id']
        lat_files = request.FILES.getlist('lat_files')             

        data_args = {
            "app": "Lessons_Learned",
            "person_id": person_id,
            "id": llm_id,
            "files": lat_files,
            "only_image": False
        }   

        response = save_the_file(data_args)

        return Response({"message": response,})
