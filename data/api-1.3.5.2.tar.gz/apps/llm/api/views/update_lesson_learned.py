from datetime import datetime
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.db import transaction
from django.template.loader import get_template
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common_utils.views.get_translations import get_translation
from apps.language.models import Language
from apps.llm.api.serializers.serializers import LessonLearnedSerializer
from apps.llm.models import LessonLearned, LessonLearnedParticipant
from apps.sofvie_user_authorization.api.permissions import SofviePermission, \
    SofvieBasePermissionMixin
from apps.user.models import User
from apps.common_utils.views.validate_permission import PersonAccessPermission, RolePermission
from apps.user_settings_profile.models import UserProfile


class UpdateLessonLearned(APIView, SofvieBasePermissionMixin):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageLessonsLearned.value,)

    @transaction.atomic
    def post(self, request):
        person_id = self.request.user.user_per_id_id
        full_name = self.request.user.user_per_id.full_name
        payload_data = request.data        
        llm_id = payload_data.pop('llm_id', '')
        participants = payload_data.pop('participants', '')
        payload_data['llm_submitted_by_per'] = person_id
        payload_data['llm_modified_by_per'] = person_id
        payload_data['llm_modified_date'] = datetime.now()
        llm_obj = LessonLearned.objects.get(llm_id=llm_id)
        # serialize the data with serializer
        # print(payload_data)
        ser = LessonLearnedSerializer(llm_obj, data=payload_data, partial=True)
        ser.is_valid(raise_exception=True)
        ser.save()
        lng_name = UserProfile.objects.get(upr_per_id=person_id).upr_language
        lng_id = Language.objects.get(lng_name=lng_name)
        ltr_ids = [4249, 3601, 4250, 1054, 1298, 1304, 1342, 4243, 4244, 4251,
                   4252, 4247, 3606, 3607, 3608, 3573, 4248, 1952]
        get_trans = get_translation(ltr_ids, lng_id)
        # deleting and creating the participants only which user select
        if participants:
            # queryset to exclude the id which user does not delete. Delete
            # only those which user delete
            to_delete_participants_qs = LessonLearnedParticipant.objects.filter(
                llp_llm_id=llm_obj.llm_id).exclude(
                llp_per_id__in=participants)
            # print(to_delete_participants_qs)
            to_delete_participants_qs.delete()
            # queryset for existing participant list and convert into LIST
            # object
            existing_participants = list(
                LessonLearnedParticipant.objects.filter(
                llp_llm_id=llm_obj.llm_id).values_list(
                'llp_per_id', flat=True))
            # print(existing_participants)
            # Create a loop to check which participant need to create
            participants_to_create = [participant for participant in
                                      participants if
                                      participant not in existing_participants]
            # print(participants_to_create)
            participants_obj_list = []
            for participant in participants_to_create:
                obj = LessonLearnedParticipant(
                    llp_llm_id=llm_id,
                    llp_per_id=participant,
                    llp_created_by_per_id=person_id,
                    llp_modified_by_per_id=person_id
                )
                participants_obj_list.append(obj)
            LessonLearnedParticipant.objects.bulk_create(participants_obj_list)

            user = User.objects.filter(user_per_id__in=participants)
            # print("FIltered users", user)
            if llm_obj.llm_is_submitted == 1:
                for i in user:
                    # print(i.name_first)

                    dict = {'user': i.name_first,
                            'created_by': full_name,
                            'title': llm_obj.llm_title,
                            'description': llm_obj.llm_summary,
                            'data': get_trans
                            }

                    # print("This is email list %s" % email_list)

                    subject, from_email, email_list = get_trans[4248], \
                                                      settings.DEFAULT_FROM_EMAIL_ADMIN, \
                                                      [i.email]
                    text_content = 'This is an important message.'
                    html_content = get_template(
                        "llm/lesson_learned_email.html").render(dict)
                    msg = EmailMultiAlternatives(subject, text_content, from_email,
                                                 email_list)
                    msg.attach_alternative(html_content, "text/html")
                    msg.send()

        return Response({"message": "Record updated successfully"})
