from datetime import datetime
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from apps.common_utils.views.validate_permission import RolePermission
from apps.llm.models import LessonLearnedGeneralAction
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class AddLessonLearnedGeneralAction(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageLessonsLearned.value,)

    def post(self, request, *args, **kwargs):

        try:
            person_id = self.request.user.user_per_id_id

            llm_sga_ids = request.data.pop('llg_sga', [])

            bulk_create_object = [LessonLearnedGeneralAction(
                llg_llm_id = request.data['llg_llm'],
                llg_created_date = datetime.now(),
                llg_created_by_per_id = person_id ,
                llg_sga_id = sga_id
            ) for sga_id in llm_sga_ids]

            LessonLearnedGeneralAction.objects.bulk_create(bulk_create_object)

            return Response({"message": "success"}, status = status.HTTP_200_OK)
        except Exception as e:
            return Response({"message": f"Failed to update lessons learned general action. {e}"}, status = status.HTTP_400_BAD_REQUEST)
