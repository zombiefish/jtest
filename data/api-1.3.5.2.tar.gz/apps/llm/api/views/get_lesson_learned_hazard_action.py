from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.hazard_action.models import Submissionhap
from apps.llm.api.serializers.serializers import \
    GetLLMHazardActionSerializer
from apps.common_utils.views.validate_permission import PersonAccessPermission, RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

class GetLessonLearnedHazardAction(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewLessonsLearned.value,)

    def post(self, request):
        llm_id = request.data['llm_id']
        
        ha_qs = Submissionhap.objects.filter(
            llh_hap_id__llh_llm=llm_id, action_status='INCOMPLETE', sha_enable=True)
        serializer_class = GetLLMHazardActionSerializer(ha_qs, many=True)
        return Response({"Hazard_Action": serializer_class.data})
