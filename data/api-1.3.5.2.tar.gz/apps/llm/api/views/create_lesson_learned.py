from datetime import datetime
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.db import transaction
from django.template.loader import get_template
from rest_framework import status, decorators, viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import parsers
from rest_framework.views import APIView

from rest_framework.parsers import JSONParser

from apps.common_utils.views.get_translations import get_translation
from apps.language.models import Language
from apps.llm.models import LessonLearned, LessonLearnedParticipant
from apps.sofvie_user_authorization.api.permissions import SofviePermission, \
    SofvieBasePermissionMixin
from apps.user.models import User
from apps.common_utils.views.validate_permission import PersonAccessPermission, RolePermission
from apps.user_settings_profile.models import UserProfile
from django.utils.safestring import mark_safe


class CreateLessonLearned(APIView, SofvieBasePermissionMixin):
    
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageLessonsLearned.value,)

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        person_id = self.request.user.user_per_id_id
        full_name = self.request.user.user_per_id.full_name

        # extract payload
        payload_data = request.data

        
        participants = payload_data.pop('participants', '')

        lng_name = UserProfile.objects.get(upr_per_id=person_id).upr_language
        lng_id = Language.objects.get(lng_name=lng_name)
        ltr_ids = [4249, 3601, 4250, 1054, 1298, 1304, 1342, 4243, 4244, 4251, 4252, 4247, 3606, 3607, 3608, 3573, 4248, 1952]
        get_trans = get_translation(ltr_ids, lng_id)
        submit_per = None
        if payload_data['llm_is_submitted'] == 1:
            submit_per = person_id
                       
        llm = LessonLearned.objects.create(
            llm_created_by_per_id=person_id,
            llm_created_date = datetime.now(),
            llm_submitted_by_per_id=submit_per,
            llm_submitted_date=None,
            **payload_data
        )
        for participant in participants:
            participant = LessonLearnedParticipant.objects.create(
                llp_llm_id=llm.llm_id,
                llp_per_id=participant,
                llp_created_by_per_id=person_id,
                llp_modified_by_per_id=person_id
            )

        user = User.objects.filter(user_per_id__in=participants)
        # print("FIltered users", user)
        if llm.llm_is_submitted == 1:
            # get_trans = get_translation(ltr_ids, lng_id)
            for i in user:
                # print(i.name_first)

                dict = {'user': i.name_first,
                        'created_by': full_name,
                        'title': mark_safe(llm.llm_title),
                        'description': mark_safe(llm.llm_summary),
                        'data': get_trans
                        }

                # print("This is email list %s" % email_list)

                subject, from_email, email_list = get_trans[4248], \
                                                  settings.DEFAULT_FROM_EMAIL_ADMIN, \
                                                  [i.email]
                text_content = 'This is an important message.'
                html_content = get_template(
                    "llm/lesson_learned_email.html").render(dict)
                msg = EmailMultiAlternatives(subject, text_content, from_email,
                                             email_list)
                msg.attach_alternative(html_content, "text/html")
                msg.send()
                return Response({"Message": "Record inserted successfully",
                                 "llm_id": llm.llm_id,
                                 "status": status.HTTP_201_CREATED})
        else:

            return Response({"Message": "Record inserted successfully",
                             "llm_id": llm.llm_id,
                             "status": status.HTTP_201_CREATED})
