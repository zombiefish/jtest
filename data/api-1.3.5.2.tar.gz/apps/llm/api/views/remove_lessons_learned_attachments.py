from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.comments.api.helper_functions.delete_comment import delete_comment
from apps.comments.models import Comments
from apps.common_utils.views.validate_permission import RolePermission
from apps.llm.api.serializers.serializers import \
    GetLessonsLearnedAttachmentsSerializer
from apps.llm.models import LessonLearnedAttachment
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class RemoveLessonsLearnedAttachments(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanManageLessonsLearned.value,)

    def post(self, request):
        payload_data = request.data

        
        ids = []
        for lat_id in payload_data:
            ids.append(lat_id['lat_id'])
        

        image_id = LessonLearnedAttachment.objects.filter(lat_id__in=ids)
        for i in image_id:
            i.lat_enable = False

        LessonLearnedAttachment.objects.bulk_update(image_id, ['lat_enable'])
        delete_comment(Comments, ids)
        
        return Response({"message": "Lessons Learned attachments deleted "
                                    "successfully"})
