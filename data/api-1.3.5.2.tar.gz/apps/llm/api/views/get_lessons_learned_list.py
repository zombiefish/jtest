from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

import datetime

from apps.llm.api.serializers.serializers import LessonLearnedSerializer
from apps.llm.models import LessonLearned

from apps.common_utils.views.validate_permission import PersonAccessPermission, RolePermission
from apps.employee.helper_function_user_visibility import helperEmployeeJobs, helperEmployeeSites
from django.db.models import Prefetch, F, Q
from apps.rmm_ora.api.date_filter_utils import date_filter
from apps.sofvie_user_authorization.api.permissions import SofviePermission

class GetLessonsLearnedList(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewLessonsLearned.value,)

    def post(self, request):
        start_date = request.data['start_date']
        end_date = request.data['end_date']        
        person_id = self.request.user.user_per_id        
        get_sites, data_user_visibility = helperEmployeeSites(self, person_id)
        get_jobs, data_user_visibility = helperEmployeeJobs(self, person_id)
        site_list = [site['rld_id'] for site in get_sites]
        job_list = [job['rld_id'] for job in get_jobs]


        site_filters = []
        job_filters = []
        if data_user_visibility !='all':
            site_filters = [Q(llm_job_rld__in=job_list) | Q(llm_job_rld__isnull=True) | Q(llm_created_by_per_id=person_id)]
            job_filters = [Q(llm_site_rld__in=site_list) | Q(llm_site_rld__isnull=True) | Q(llm_created_by_per_id=person_id)]            

        queryset = LessonLearned.objects.filter(
                        *site_filters,
                        *job_filters,
                        llm_enable=True, 
                        llm_created_date__range=(date_filter(start_date, end_date))
                        )

        serializer_class = LessonLearnedSerializer(queryset, context={'request': request}, many=True)

        return Response(serializer_class.data)
