from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.general_action.models import SubmissionGeneralAction
from apps.llm.api.serializers.serializers import \
    GetLLMGeneralActionSerializer

from apps.common_utils.views.validate_permission import PersonAccessPermission, RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class GetLessonLearnedGeneralAction(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewLessonsLearned.value,)

    def post(self, request):
        llm_id = request.data['llm_id']        

        qs = SubmissionGeneralAction.objects.filter(
            general_actions__llg_llm=llm_id, sga_action_is_complete=0
           )
        serializer_class = GetLLMGeneralActionSerializer(qs, many=True)

        return Response({"general_actions": serializer_class.data})
