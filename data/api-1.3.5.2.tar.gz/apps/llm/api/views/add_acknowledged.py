from apps.employee.models import Employee
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.llm.models import LessonLearnedAcknowledged

from apps.common_utils.views.validate_permission import  RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class AddLessonLearnedAcknowledged(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewLessonsLearned.value,)

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        payload_data = request.data
        payload_data['lla_position'] = Employee.objects.get(emp_per_id = person_id).emp_pos_id

        llm_id = payload_data['lla_llm_id']
                
        lla = LessonLearnedAcknowledged.objects.filter(
            lla_llm_id=llm_id, lla_per_id=person_id, lla_enable=True).first()

        if lla:
            return Response({
                "message": "Record already exists",
                "lla_id ": lla.lla_id
            })
        else:
            lla = LessonLearnedAcknowledged.objects.create(
                lla_per_id=person_id,
                lla_created_by_per_id=person_id,
                lla_modified_by_per_id=person_id,
                **payload_data
            )
            return Response({
                "message": "Record inserted successfully",
                "lla_id ": lla.lla_id
            })
