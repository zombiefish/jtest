from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.llm.models import LessonLearnedAcknowledged
from apps.common_utils.views.validate_permission import PersonAccessPermission, RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

class AddLessonLearnedUnAcknowledged(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.CanViewLessonsLearned.value,)

    def post(self, request):
        person_id = self.request.user.user_per_id_id
        payload_data = request.data          

        qs = LessonLearnedAcknowledged.objects.filter(
            lla_llm_id=payload_data['lla_llm_id'],
            lla_per_id=person_id

        ).update(lla_enable=0, lla_modified_by_per=person_id)

        return Response({"message": "Record archive successfully"})
