

from apps.comments.models import Comments
from apps.reflist.models import RefListDetail
from django.db.models import Value, CharField
from django.db.models.functions import Concat
from rest_framework import serializers
from collections import OrderedDict
from django.db.models import Value, F, Prefetch, CharField
from apps.dl.models import DocumentLock
from apps.general_action.api.serializers.serializer import \
    GetGeneralActionSerializer
from apps.general_action.models import SubmissionGeneralActionAttachment, \
    SubmissionGeneralAction, SubmissionGeneralActionPerson
from apps.hazard_action.models import Submissionhapattachments, Submissionhap, SubmissionHazardActionPerson
from apps.llm.models import LessonLearned, LessonLearnedParticipant, \
    LessonLearnedAcknowledged, LessonLearnedGeneralAction, \
    LessonLearnedHazardAction, LessonLearnedAttachment

from apps.language.models import LanguageTranslation, Language
from apps.user_settings_profile.models import UserProfile
from apps.person.models import Person


class GetLessonsLearnedAttachmentsSerializer(serializers.ModelSerializer):
    class Meta:
        model = LessonLearnedAttachment
        fields = [
            'lat_id',
            'lat_llm',
            'lat_file_name',
            'lat_comment',
            'lat_created_date',
            'lat_created_by_per',
            'lat_modified_date',
            'lat_modified_by_per',
            'lat_enable',

        ]

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        try:
            comment = Comments.objects.filter(com_reference_id=instance.lat_id, com_cmt=2,com_enable=True).values('com_id', 'com_comment').first()
            representation['com_id'] = comment['com_id']
            representation['com_comment'] = comment['com_comment']
        except:
            representation['com_id'] = None
            representation['com_comment'] = None
        return representation


class LessonLearnedParticipantSerializer(serializers.ModelSerializer):
    class Meta:
        model = LessonLearnedParticipant
        fields = [
            'llp_id',
            'llp_llm',
            'llp_per'
        ]


class AcknowledgeSerializer(serializers.ModelSerializer):
    lla_position = serializers.SerializerMethodField()

    class Meta:
        model = LessonLearnedAcknowledged
        fields = [
            'lla_id',
            'lla_llm',
            'lla_per',
            'lla_modified_date',
            'lla_enable',
            'lla_position'
        ]

    def get_lla_position(self, instance):
        if instance.lla_position:
            try:
                person = self.context['request'].user.user_per_id
                lng_name = UserProfile.objects.get(upr_per=person).upr_language
                lng_id = Language.objects.get(lng_name=lng_name)
                get_ref_list = RefListDetail.objects.get(rld_id=instance.lla_position)
                return LanguageTranslation.objects.filter(ltr_tag=get_ref_list.rld_name, ltr_tag_type=get_ref_list.rld_tag_type, ltr_lng=lng_id).values_list('ltr_text', flat=True)[0]
            except:
                return instance.lla_position

        else:
            return ''  

class LessonLearnedSerializer(serializers.ModelSerializer):
    participants = LessonLearnedParticipantSerializer(read_only=True, many=True)
    acknowledgements = AcknowledgeSerializer(read_only=True, many=True,
                                             source="only_enable")
    dlo_enable = serializers.SerializerMethodField()    

    class Meta:
        model = LessonLearned
        fields = [
            'llm_id',
            'llm_title',
            'llm_site_rld',
            'llm_job_rld',
            'llm_scope',
            'llm_summary',
            'llm_success',
            'llm_opportunity',
            'llm_other_participant',
            'llm_is_submitted',
            'llm_submitted_date',
            'llm_submitted_by_per',
            'llm_created_date',
            'llm_date',
            'llm_created_by_per',
            'llm_modified_date',
            'llm_modified_by_per',
            'llm_enable',
            'participants',
            'acknowledgements',
            'dlo_enable',

        ]

    def get_dlo_enable(self, obj):
        doc_lock = DocumentLock.objects.filter(
            dlo_document_id=obj.llm_id, dlo_dlt_id=7).annotate(            
            dlo_person=Concat(
                "dlo_per__per_last_name", Value(", "),
                "dlo_per__per_first_name",  output_field=CharField(),
            )
        ).values('dlo_document_id', 'dlo_person', 'dlo_enable')
        return doc_lock


class GetLLMHazardActionAttachmentsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Submissionhapattachments
        fields = [
            'id',
            'attachmentfilename',
            'attachmenttype'
        ]

class GetLLHazardActionActionByWho(serializers.ModelSerializer):
    class Meta:
        model = SubmissionHazardActionPerson
        fields = [
            'hap_per_id'
        ]


class GetLLGeneralActionActionByWho(serializers.ModelSerializer):
    class Meta:
        model = SubmissionGeneralActionPerson
        fields = [
            'gap_per_id'
        ]



class GetLLMHazardActionSerializer(serializers.ModelSerializer):
    attachments = GetLLMHazardActionAttachmentsSerializer(read_only=True,
                                                          many=True,
                                                          default=None, source='only_enable_haa_attachment')

    action_by_who = serializers.SerializerMethodField()

    class Meta:
        model = Submissionhap
        fields = [
            'id',
            'submissionheaderid',
            'hazard_type',
            'hazard_identification',
            'hazard_description',
            'potential_risk',
            'immediate_action_taken',
            'immediate_action_required_and_performed',
            'further_action_required',
            'recommended_action',
            'immediate_action_type',
            'action_type',
            'action_complete_by_who',
            'action_completed_date',
            'action_by_when',
            'action_by_who',
            'action_status',
            'completed_action_taken',
            'completed_action_type',
            'hazard_identification_score',
            'hazard_identification_score',
            'potential_risk_score',
            'immediate_action_score',
            'completed_action_score',
            'attachments',
            'sha_created_by_per'
        ]

    def get_action_by_who(self, instance):
        
        ids = SubmissionHazardActionPerson.objects.filter(
            hap_sha_id = instance.id,
            hap_enable = True
        ).values_list('hap_per_id', flat = True)

        return ids


class GetLLMGeneralActionAttachments(serializers.ModelSerializer):
    class Meta:
        model = SubmissionGeneralActionAttachment
        fields = [
            'gaa_id',
            'gaa_file_name',
            'gaa_type',
            'gaa_enable'
        ]


class GetLLMGeneralActionSerializer(serializers.ModelSerializer):
    # attachments = GetLLMGeneralActionAttachments(many=True, read_only=True)
    attachments = GetLLMGeneralActionAttachments(many=True, read_only=True, default=None, source='only_enable_attachment')
    sga_action_by_who_per_id = serializers.SerializerMethodField()

    class Meta:
        model = SubmissionGeneralAction
        fields = [
            'sga_id',
            'sga_submission_header_id',
            'sga_action_type_rld_id',
            'sga_action_by_who_per_id',
            'sga_action_by_when',
            'sga_recommended_action',
            'sga_action_is_complete',
            'sga_completed_action_type_rld_id',
            'sga_completed_action_by_who_per_id',
            'sga_completed_action_date',
            'sga_completed_action_taken',
            'sga_created_date',
            'sga_created_by_per_id',
            'sga_modified_date',
            'sga_modified_by_per_id',
            'sga_enable',
            'sga_enote',
            'attachments',

        ]

    def get_sga_action_by_who_per_id(self, instance):
        
        ids = SubmissionGeneralActionPerson.objects.filter(
            gap_sga_id = instance.sga_id,
            gap_enable = True
        ).values_list('gap_per_id', flat = True)

        return ids