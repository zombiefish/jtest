from django.db import models
from apps.reflist.models import RefListDetail
from apps.person.models import Person
from apps.general_action.models import SubmissionGeneralAction
from apps.hazard_action.models import Submissionhap
from apps.common_utils.views.sofvieModelFields import SofvieCharField, SofvieIntegerField, SofvieTextField

# Create your models here.

class LessonLearned(models.Model):
    llm_id = models.AutoField(primary_key=True)
    llm_title = SofvieCharField(max_length=200, blank=True, null=True)
    llm_date = models.DateField(blank = True, null = True)
    llm_site_rld = models.ForeignKey(RefListDetail, models.DO_NOTHING,
                                     related_name='llm_sitelist', blank=True, null=True)
    llm_job_rld = models.ForeignKey(RefListDetail, models.DO_NOTHING,
                                    related_name='llm_joblist', blank=True, null=True)
    llm_scope = SofvieTextField(blank=True, null=True)
    llm_summary = SofvieTextField(blank=True, null=True)
    llm_success = SofvieTextField(blank=True, null=True)
    llm_opportunity = SofvieTextField(blank=True, null=True)
    llm_other_participant = SofvieTextField(blank=True, null=True)
    llm_is_submitted = models.BooleanField(default=False)
    llm_submitted_date = models.DateTimeField(auto_now=True,
                                              blank=True,
                                              null=True)
    llm_submitted_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                             blank=True, null=True,
                                             related_name='llm_person_submitted_by')
    llm_created_date = models.DateTimeField(blank=True,
                                            null=True)
    llm_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='llm_person_created_by')
    llm_modified_date = models.DateTimeField(blank=True,null=True)
    llm_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='llm_person_modified_by')
    llm_archived_date = models.DateTimeField(blank=True,null=True)
    llm_archived_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='llm_person_archived_by')                                                
    llm_enable = models.BooleanField(default=True)
    llm_enote = SofvieCharField(max_length=255, blank = True, null = True)

    class Meta:
        db_table = 'lesson_learned'

    # Filter data for nested serializer
    def only_enable(self):
        return LessonLearnedAcknowledged.objects.filter(lla_llm=self,
                                                        lla_enable=1)


class LessonLearnedAcknowledged(models.Model):
    lla_id = models.AutoField(primary_key=True)
    lla_llm = models.ForeignKey(LessonLearned, models.DO_NOTHING,
                                related_name='acknowledgements')
    lla_per = models.ForeignKey(Person, models.DO_NOTHING,
                                blank=True, null=True,
                                related_name='lla_person_id')
    lla_created_date = models.DateTimeField(auto_now=True,
                                            blank=True,
                                            null=True)
    lla_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='lla_person_created_by')
    lla_modified_date = models.DateTimeField(auto_now=True,
                                             blank=True,
                                             null=True)
    lla_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='lla_person_modified_by')
    lla_enable = models.BooleanField(default=True)
    lla_enote = SofvieCharField(max_length = 255, blank = True, null = True)
    lla_position = SofvieIntegerField(blank=True, null=True)
    
    class Meta:
        db_table = 'lesson_learned_acknowledged'


class LessonLearnedGeneralAction(models.Model):
    llg_id = models.AutoField(primary_key=True)
    llg_llm = models.ForeignKey(LessonLearned, models.DO_NOTHING,
                                related_name='llg_lessonslearned')
    llg_sga = models.ForeignKey(SubmissionGeneralAction, models.DO_NOTHING,
                                blank=True, null=True,
                                related_name='general_actions')
    llg_created_date = models.DateTimeField(auto_now=True,
                                            blank=True,
                                            null=True)
    llg_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='llg_person_created_by')
    llg_modified_date = models.DateTimeField(auto_now=True,
                                             blank=True,
                                             null=True)
    llg_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='llg_person_modified_by')
    llg_enable = models.BooleanField(default=True)
    llg_enote = SofvieCharField(max_length= 255, blank = True, null = True)

    class Meta:
        db_table = 'lesson_learned_general_action'


class LessonLearnedHazardAction(models.Model):
    llh_id = models.AutoField(primary_key=True)
    llh_llm = models.ForeignKey(LessonLearned, models.DO_NOTHING,
                                related_name='llh_lessonslearned')
    llh_sha = models.ForeignKey(Submissionhap, models.DO_NOTHING,
                                blank=True, null=True,
                                related_name='llh_hap_id')
    llh_created_date = models.DateTimeField(auto_now=True,
                                            blank=True,
                                            null=True)
    llh_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='llh_person_created_by')
    llh_modified_date = models.DateTimeField(auto_now=True,
                                             blank=True,
                                             null=True)
    llh_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='llh_person_modified_by')
    llh_enable = models.BooleanField(default=True)
    llh_enote = SofvieCharField(max_length= 255, blank = True, null = True)

    class Meta:
        db_table = 'lesson_learned_hazard_action'


class LessonLearnedParticipant(models.Model):
    llp_id = models.AutoField(primary_key=True)
    llp_llm = models.ForeignKey(LessonLearned, models.DO_NOTHING,
                                related_name='participants')
    llp_per = models.ForeignKey(Person, models.DO_NOTHING,
                                blank=True, null=True,
                                related_name='llp_person_id')
    llp_created_date = models.DateTimeField(auto_now=True,
                                            blank=True,
                                            null=True)
    llp_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='llp_created_by')
    llp_modified_date = models.DateTimeField(auto_now=True,
                                             blank=True,
                                             null=True)
    llp_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='llp_modified_by')
    llp_enable = models.BooleanField(default=True)
    llp_enote = SofvieCharField(max_length= 255, blank = True, null = True)

    class Meta:
        db_table = 'lesson_learned_participant'


class LessonLearnedAttachment(models.Model):
    lat_id = models.AutoField(primary_key=True)
    lat_llm = models.ForeignKey(LessonLearned, models.DO_NOTHING,
                                related_name='llm_attachments')
    lat_file_name = SofvieCharField(max_length=200)
    lat_comment = SofvieTextField(blank=True, null=True)
    lat_created_date = models.DateTimeField(auto_now=True, blank=True,
                                            null=True)
    lat_created_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                           blank=True, null=True,
                                           related_name='lat_created_by')
    lat_modified_date = models.DateTimeField(auto_now=True, blank=True,
                                             null=True)
    lat_modified_by_per = models.ForeignKey(Person, models.DO_NOTHING,
                                            blank=True, null=True,
                                            related_name='lat_modified_by')
    lat_enable = models.BooleanField(default=True)
    lat_enote = SofvieCharField(max_length= 255, blank = True, null = True)

    class Meta:
        db_table = 'lesson_learned_attachment'
