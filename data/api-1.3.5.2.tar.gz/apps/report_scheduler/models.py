from django.db import models
from django.db.models import (
    Model,
    AutoField,
    DateTimeField,
    ForeignKey,    
    BooleanField,
    JSONField
)

from apps.common_utils.views.sofvieModelFields import (
    SofvieCharField,
    SofvieTextField,
    SofvieIntegerField
)

from apps.general_action.models import Reports
from apps.person.models import Person
from apps.reflist.models import RefListHeader, RefListDetail


class ReportFilterType(Model):
    rft_id = AutoField(primary_key=True)
    rft_name = SofvieCharField(max_length=100, unique=True, blank=False, null=False)
    rft_tag = SofvieIntegerField()
    rft_tag_type = SofvieIntegerField()
    rft_type = SofvieCharField(max_length=100, blank=False, null=False)
    rft_rlh = ForeignKey(RefListHeader, on_delete=models.DO_NOTHING, related_name='rft_ref_list_headers', blank=True, null=True)
    rft_sp = SofvieCharField(max_length=100, blank=True, null=True)
    rft_created_date = DateTimeField(auto_now_add=True)
    rft_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rft_createdby_per')
    rft_modified_date = DateTimeField(blank=True, null=True)
    rft_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rft_modifiedby_per', blank=True, null=True)
    rft_enable = BooleanField(default=True)
    rft_enote = SofvieCharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'report_filter_type'

class ReportFilterTypeMapping(Model):
    rfm_id = AutoField(primary_key=True)
    rfm_rpt = ForeignKey(Reports, on_delete=models.DO_NOTHING, related_name='rfm_reports')
    rfm_rft = ForeignKey(ReportFilterType, on_delete=models.DO_NOTHING, related_name='rfm_report_filter_type')
    rfm_is_mandatory = BooleanField(default=True)
    rfm_created_date = DateTimeField(auto_now_add=True)
    rfm_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rfm_createdby_per')
    rfm_modified_date = DateTimeField(blank=True, null=True)
    rfm_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rfm_modifiedby_per', blank=True, null=True)
    rfm_enable = BooleanField(default=True)
    rfm_enote = SofvieCharField(max_length=255, blank=True, null=True)


    class Meta:
        db_table = 'report_filter_type_mapping'


class ReportFilterParameter(Model):
    rfp_id = AutoField(primary_key=True)
    rfp_rft = ForeignKey(ReportFilterType, on_delete=models.DO_NOTHING, related_name='rfp_report_filter_type')
    rfp_value = SofvieCharField(max_length=255, blank=False, null=False)
    rfp_created_date = DateTimeField(auto_now_add=True)
    rfp_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rfp_createdby_per')
    rfp_modified_date = DateTimeField(blank=True, null=True)
    rfp_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rfp_modifiedby_per' , blank=True, null=True)
    rfp_enable = BooleanField(default=True)
    rfp_enote = SofvieCharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'report_filter_parameter'


class ReportSavedUserFilter(Model):
    rsu_id = AutoField(primary_key=True)
    rsu_filter_name = SofvieCharField(max_length=255)
    rsu_rpt = ForeignKey(Reports, on_delete=models.DO_NOTHING, related_name='rsu_reports')
    rsu_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rsu_person')
    rsu_is_scheduled = BooleanField(default=False)
    rsu_created_date = DateTimeField(auto_now_add=True)
    rsu_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rsu_createdby_per')
    rsu_modified_date = DateTimeField( blank=True, null=True)
    rsu_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rsu_modifiedby_per', blank=True, null=True)
    rsu_enable = BooleanField(default=True)
    rsu_enote = SofvieCharField(max_length=255, blank=True, null=True)


    class Meta:
            db_table = 'report_saved_user_filter'


class ReportScheduleMaster(Model):
    rsm_id = AutoField(primary_key=True)
    rsm_rpt = ForeignKey(Reports, on_delete=models.DO_NOTHING, related_name='rsm_reports')
    rsm_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rsm_person')
    rsm_rsu = ForeignKey(ReportSavedUserFilter, on_delete=models.DO_NOTHING, related_name='rsm_report_saved_user_filter', blank=True, null=True)
    rsm_description = SofvieTextField()
    rsm_frequency_rld = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, related_name='rsm_ref_list_detail_frequency')
    rsm_day_tag = SofvieIntegerField(blank=True, null=True)
    rsm_end_rld = ForeignKey(RefListDetail, on_delete=models.DO_NOTHING, related_name='rsm_ref_list_detail_end')
    rsm_start_date = DateTimeField(blank=False, null=False)
    rsm_expire_date = DateTimeField(blank=True, null=True)
    rsm_occurrences = SofvieIntegerField(blank=True, null=True)
    rsm_created_date = DateTimeField(auto_now_add=True)
    rsm_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rsm_createdby_per')
    rsm_modified_date = DateTimeField( blank=True, null=True)
    rsm_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rsm_modifiedby_per', blank=True, null=True)
    rsm_enable = BooleanField(default=True)
    rsm_enote = SofvieCharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'report_schedule_master'


class ReportScheduleDistribution(Model):
    rsd_id = AutoField(primary_key=True)
    rsd_rsm = ForeignKey(ReportScheduleMaster, on_delete=models.DO_NOTHING, related_name='rsd_report_schedule_master')
    rsd_email = SofvieTextField()
    rsd_created_date = DateTimeField(auto_now_add=True)
    rsd_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rsd_createdby_per')
    rsd_modified_date = DateTimeField( blank=True, null=True)
    rsd_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rsd_modifiedby_per', blank=True, null=True)
    rsd_enable = BooleanField(default=True)
    rsd_enote = SofvieCharField(max_length=255, blank=True, null=True)


    class Meta:
        db_table = 'report_schedule_distribution'




class ReportSavedFilterType(Model):
    rsf_id = AutoField(primary_key=True)
    rsf_rft = ForeignKey(ReportFilterType, on_delete=models.DO_NOTHING, related_name='rsf_reports')
    rsf_rsu = ForeignKey(ReportSavedUserFilter, on_delete=models.DO_NOTHING, related_name='rsf_report_saved_user_filter')
    rsf_created_date = DateTimeField(auto_now_add=True)
    rsf_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rsf_createdby_per')
    rsf_modified_date = DateTimeField( blank=True, null=True)
    rsf_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rsf_modifiedby_per', blank=True, null=True)
    rsf_enable = BooleanField(default=True)
    rsf_enote = SofvieCharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'report_saved_filter_type'


class ReportSavedFilterValue(Model):
    rsv_id = AutoField(primary_key=True)
    rsv_rsf = ForeignKey(ReportSavedFilterType, on_delete=models.DO_NOTHING, related_name='rsv_report_saved_filter_type')
    rsv_value = SofvieCharField(max_length=200)
    rsv_created_date = DateTimeField(auto_now_add=True)
    rsv_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rsv_createdby_per')
    rsv_modified_date = DateTimeField( blank=True, null=True)
    rsv_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rsv_modifiedby_per', blank=True, null=True)
    rsv_enable = BooleanField(default=True)
    rsv_enote = SofvieCharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'report_saved_filter_value'

class ReportScheduleEmailStatus(Model):
    rse_id = AutoField(primary_key=True)
    rse_rsm = ForeignKey(ReportScheduleMaster, on_delete=models.DO_NOTHING, related_name='rse_report_schedule_master')    
    rse_is_email_sent = BooleanField(default=False)
    rse_log_created_date = DateTimeField(auto_now_add=True)
    rse_log_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rse_log_createdby_per')
    rse_modified_date = DateTimeField(blank=True, null=True)
    rse_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rse_log_modifiedby_per', blank=True, null=True)
    rse_enable = BooleanField(default=True)
    rse_enote = SofvieCharField(max_length=255, blank=True, null=True)
    class Meta:
        db_table = 'report_schedule_email_status'

class ReportFilterUrl(Model):
    rfu_id = AutoField(primary_key=True)
    rfu_report_slug = SofvieCharField(max_length=100)
    rfu_report_filter = JSONField(null=True, blank=True)
    rfu_report_unique_code = SofvieCharField(max_length=200)
    rfu_created_date = DateTimeField(auto_now_add=True)
    rfu_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rfu_created_person_id', help_text='Enter foreignkey of person table')
    rfu_modified_date = DateTimeField(blank=True, null=True)
    rfu_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='rfu_modified_person_id', help_text='Enter foreignkey of person table', blank=True, null=True)
    rfu_enable = BooleanField(default=True)
    rfu_enote = SofvieTextField(null=True, blank=True)

    class Meta:
        db_table = 'report_filter_url'