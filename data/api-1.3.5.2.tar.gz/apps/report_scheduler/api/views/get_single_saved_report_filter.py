from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from apps.common_utils.views.validate_permission import RolePermission
from apps.report_scheduler.api.views.common_functions import get_filter_values
from apps.report_scheduler.models import ReportSavedUserFilter

from apps.sofvie_user_authorization.api.permissions import SofviePermission


class GetSingleSavedReportFilter(APIView):
    permission_classes = [IsAuthenticated, SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def post(self, request):
        rsu_id = request.data.get('rsu_id')
        try:
            if rsu_id:
                report_id = ReportSavedUserFilter.objects.get(
                    rsu_id = rsu_id
                ).rsu_rpt_id
                report_filters = get_filter_values(self, rsu_id=rsu_id, report_id = report_id)

                for each in report_filters:
                    each['show_inactive'] = True
                    if each['rft_values'] == ['allactive']:
                        each['rft_values'] = ['all']
                        each['show_inactive'] = False
                
                return Response({'rsm_arguments': report_filters}, status=status.HTTP_200_OK)
            else:
                return Response({'error': 'Report ID is required'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
    