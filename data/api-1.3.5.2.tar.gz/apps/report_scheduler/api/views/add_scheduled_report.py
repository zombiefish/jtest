from datetime import datetime
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from django.db import transaction

from apps.common_utils.views.validate_permission import RolePermission
from apps.report_scheduler.api.views.common_functions import check_all_filters_exists
from apps.report_scheduler.models import ReportFilterTypeMapping, ReportSavedFilterType, ReportSavedFilterValue, ReportSavedUserFilter, ReportScheduleDistribution, ReportScheduleMaster
from apps.sofvie_user_authorization.api.permissions import SofviePermission


class AddScheduledReport(APIView):
    permission_classes = [IsAuthenticated, SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)
    
    @transaction.atomic
    def post(self, request):

        person = self.request.user.user_per_id
        report_scheduler_data = request.data.pop('report_scheduler')
        

        rsm_filters = report_scheduler_data.pop('rsm_filters', None)
        rsm_distribution = report_scheduler_data.pop('rsm_distribution', None)
        add_schedule_report_data = report_scheduler_data

        try:
            if add_schedule_report_data and rsm_distribution:

                add_schedule_report_data['rsm_created_by_per'] = person
                add_schedule_report_data['rsm_per'] = person
                # create a new record for ReportSavedUserFIlter only when rsm_rsu_id is none or ''
                if add_schedule_report_data['rsm_rsu_id'] == None or add_schedule_report_data['rsm_rsu_id'] == '' and rsm_filters:                   
                    # create new saved user filter
                    new_saved_user_filter = add_saved_user_filter(self, person, add_schedule_report_data)
                    add_schedule_report_data['rsm_rsu_id'] = new_saved_user_filter.rsu_id
                    add_filters = add_filter_values(self, person, rsm_filters, new_saved_user_filter.rsu_id, add_schedule_report_data['rsm_rpt_id'])
                    if not add_filters:
                        return Response({"error": "Add Filter Values Failed"}, status=status.HTTP_400_BAD_REQUEST)

                add_schedule_report = ReportScheduleMaster.objects.create(**add_schedule_report_data)              
                

                add_distribution(self, person, rsm_distribution, add_schedule_report.rsm_id)

                return Response({'success': 'Successfully added Scheduled Report'}, status=status.HTTP_200_OK)
            else:
                return Response({'error': 'Adding Scheduled Report Failed'}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            return Response({'error': 'Adding Scheduled Report Failed \n'+str(e)}, status=status.HTTP_400_BAD_REQUEST)

@transaction.atomic
def add_saved_user_filter(self, person, add_schedule_report_data, is_scheduled=True):
    # create new saved user filter
    new_saved_user_filter_data = {
        'rsu_is_scheduled': is_scheduled,
        'rsu_created_by_per': person,
        'rsu_per': person,
        'rsu_created_date': datetime.now(),
        'rsu_filter_name': add_schedule_report_data['rsm_description'],
        'rsu_rpt_id': add_schedule_report_data['rsm_rpt_id']
    }
    new_saved_user_filter = ReportSavedUserFilter.objects.create(**new_saved_user_filter_data)

    return new_saved_user_filter

@transaction.atomic
def update_saved_user_filter(self, person, add_schedule_report_data, is_scheduled=True):
    # update existing saved used filter using rsm_rsu_id
    saved_user_filter = ReportSavedUserFilter.objects.get(rsu_id=add_schedule_report_data['rsm_rsu_id'])
    saved_user_filter.rsu_is_scheduled = is_scheduled
    saved_user_filter.rsu_modified_by_per = person
    saved_user_filter.rsu_modified_date = datetime.now()
    saved_user_filter.save()

    return saved_user_filter

@transaction.atomic
def add_filter_values(self, person, rsm_filters, rsu_id, report_id):
    # create record for ReportSavedFilterType with rft_ids from rsm_filters

    rft_ids = [filters['rft_id'] for filters in rsm_filters]

    all_mandatory_exists = check_all_filters_exists(self, rft_ids, report_id)

    if not all_mandatory_exists:        
        return False

    bulk_create_rsft = [
        ReportSavedFilterType(
            rsf_rsu_id = rsu_id,
            rsf_rft_id = rft_id,
            rsf_created_by_per = person,            
        ) for rft_id in rft_ids
    ]

    rsft_instance = ReportSavedFilterType.objects.bulk_create(bulk_create_rsft)    

    # bullk create for each rft_id (having mutiple values) in rsm_filters add to ReportSavedFilterValue    
    
    for rsm_filter in rsm_filters:        
        rft_values = rsm_filter['rft_values']

        rsft = [rsft for rsft in rsft_instance if rsft.rsf_rft_id == rsm_filter['rft_id']][0]

        bulk_create_rsfv = [
            ReportSavedFilterValue(
                rsv_rsf = rsft,
                rsv_value = rft_value,
                rsv_created_by_per = person,
            ) for rft_value in rft_values
        ]

        rsfv_instance = ReportSavedFilterValue.objects.bulk_create(bulk_create_rsfv)   
    
    return True

@transaction.atomic    
def add_distribution(self, person, rsm_distribution, rsm_id):
    # create record for ReportScheduleDistribution with list of distribution emails from rsm_distribution
    bulk_create_rsd = [
        ReportScheduleDistribution(
            rsd_rsm_id = rsm_id,
            rsd_email = distribution,
            rsd_created_by_per = person,            
        ) for distribution in rsm_distribution
    ]

    rsd_instance = ReportScheduleDistribution.objects.bulk_create(bulk_create_rsd)
