from datetime import datetime, timedelta
from apps.common_utils.views.custom_aggregate_function import GroupConcat
from apps.employee.views import get_full_employee_list_profile
from apps.equipment.api.views.get_full_equipment_list import get_full_equipment_list
from apps.equipment.api.views.list_preop_equipment import get_equipment_list
from apps.equipment.models import EquipmentType
from apps.form.views import get_all_form_list
from apps.general_action.models import Reports
from apps.report_scheduler.api.views.get_date_range import get_date_range
from apps.sofvie_user_authorization.api.views.get_role_list import get_roles_list
from apps.sofvie_user_authorization.models import AuthRoleSofvie
from apps.user_settings_profile.models import UserProfile

from numpy import positive
from apps.language.models import Language, LanguageTranslation
from apps.reflist.models import RefListDetail
from apps.report_scheduler.models import ReportFilterTypeMapping, ReportSavedFilterType
from django.db.models import Subquery, OuterRef, Q, F, Case, When, Value, CharField, BooleanField, IntegerField
from django.db.models.functions import Concat
import calendar
from dateutil.relativedelta import relativedelta

def get_report_filters_data(self, report_id,lng_id):

    # return controls for the specified filter parameter.
    get_report_filters = ReportFilterTypeMapping.objects.filter(
        rfm_rpt_id=report_id,
        rfm_enable=True
    ).select_related(
        'rfm_report_filter_type'
    ).annotate(
        rft_id = F('rfm_rft__rft_id'),
        rft_name = F('rfm_rft__rft_name'),
        rft_type = F('rfm_rft__rft_type'),
        rft_ref_name = F('rfm_rft__rft_rlh__rlh_name'),

        control_name = Subquery(
            LanguageTranslation.objects.filter(ltr_tag=OuterRef('rfm_rft__rft_tag'),ltr_tag_type=1, ltr_lng = lng_id).values('ltr_text')[:1]
        ),
    ).values(
        'rft_id',
        'rft_name',
        'rft_type',
        'rfm_is_mandatory',
        'rft_ref_name',
        'control_name'
    )

    for each in get_report_filters:
        if each['rft_ref_name'] is not None:
            self.report_id = report_id
            # This is a special case for the pending general/hazard action reports
            if (report_id == 71 or report_id == 11) and each['rft_ref_name'] == 'ref_report_schedule_period':
                each['ref_data'] = get_ref_data(self, each['rft_ref_name'], lng_id, [2,3])
            else:
                each['ref_data'] = get_ref_data(self, each['rft_ref_name'], lng_id)
                
            if each['rft_name'] == 'report_selection':
                each['ref_data'] = get_groupby_report_data(report_id, lng_id)

    return list(get_report_filters)

def get_ref_data(self, rlh_name, lng_id, rld_options=[], mode = 'all'):   

    self.lng_id = lng_id
    if rlh_name == 'ref_report_schedule_period':
        date_ranges =  get_date_range(self)

        # setting include future dates to None, 
        # assuming that future date range request is a special case only for selected reports
        
        include_future_dates = None
        try:
            include_future_dates = Reports.objects.get(pk = self.report_id).rpt_allow_future_dates
        except Reports.DoesNotExist:
            pass

        if not include_future_dates:
            # filter out date ranges from list of dict with rld_score > 0
            date_ranges = [each for each in date_ranges if each['rld_score'] == None or each['rld_score'] <= 0]
            return date_ranges

        return date_ranges

    rld_option_filter = []
    if rld_options:
        rld_option_filter = [Q(rld_option__in = rld_options)]

    filter_enable = []    
    if mode == 'allactive':
        filter_enable = [Q(rld_enable = True) & Q(rld_deleted = False) & Q(rld_is_active = True)]


    ref_data = RefListDetail.objects.filter(
        rld_rlh__rlh_name = rlh_name,
        *rld_option_filter,
        *filter_enable,
    ).exclude(rld_name = 0).annotate(
        name = Subquery(
            LanguageTranslation.objects.filter(
                ltr_enable = True,
                ltr_lng_id = lng_id,
                ltr_tag = OuterRef('rld_name'),
                ltr_tag_type = OuterRef('rld_tag_type')
            ).values('ltr_text')[:1]
        ),
        status_flag = Case(
            When(Q(rld_enable=True) & Q(rld_deleted = False), then=Value(True)),                   
            default=Value(False),
            output_field=BooleanField()
        ), 
    ).values('rld_id','name', 'rld_option',  'rld_code', 'rld_parent_detail_rld_id', 'status_flag')    

    if mode == 'all':
        inactive_label = LanguageTranslation.objects.get(ltr_tag = 3793, ltr_tag_type = 1, ltr_lng_id = lng_id).ltr_text

        ref_data = ref_data.annotate(
            rld_name = Case(
                When(status_flag = False, then = Concat('name',Value(f' ({inactive_label})'))),
                default = F('name'),
                output_field= CharField()
            )
        ).values(
            'rld_id', 'rld_name', 'rld_option', 'rld_code' , 'rld_parent_detail_rld_id', 'status_flag'
        ).order_by('rld_name')
    
    else:
        ref_data = ref_data.annotate(
            rld_name = F('name')
        ).values(
            'rld_id', 'rld_name', 'rld_option', 'rld_code' , 'rld_parent_detail_rld_id', 'status_flag'
        ).order_by('rld_name')


    return ref_data


def get_groupby_report_data(report_id, lng_id):
    groupby_data = Reports.objects.filter(
        rpt_rpt_id = report_id
    ).annotate(
        rld_id = F('reportname'),
        rld_name = Subquery(
            LanguageTranslation.objects.filter(
                ltr_enable = True,
                ltr_lng_id = lng_id,
                ltr_tag = OuterRef('reportname'),
                ltr_tag_type = 1
            ).values('ltr_text')[:1]
        ),
        rld_option = F('id')
    ).values('rld_id', 'rld_name', 'rld_option')

    return groupby_data


def check_all_filters_exists(self, rft_ids, report_id):

    # check if all rft_ids are in ReportFilterTypeMapping table
    all_mandatory_exists = True

    mandatory_args = ReportFilterTypeMapping.objects.filter(
        rfm_rpt_id=report_id,
        rfm_is_mandatory=True
    ).values_list('rfm_rft__rft_id', flat=True)

    all_agrs = ReportFilterTypeMapping.objects.filter(
        rfm_rpt_id=report_id      
    ).values_list('rfm_rft__rft_id', flat=True)    

    if set(mandatory_args).issubset(set(rft_ids)) and set(rft_ids).issubset(set(all_agrs)):
        all_mandatory_exists = True  
    
    return all_mandatory_exists

def get_start_date_end_date(self, rld_id,  rolling_days = None, start_date = None, end_date = None, offset_date_range = None):
    
    period_data = get_date_range(self)

    selected_date_range = next((d for d in period_data if d.get("rld_id") == rld_id), None)

    CURRENT_DATE = datetime.now().date()

    score = selected_date_range['rld_score']
    option = selected_date_range['rld_option']

    if selected_date_range['ref_dun_unit'] == 'custom':

        if option == 3:
            # custom rolling date range
            rolling_days = int(rolling_days)
            offset_date_range = int(offset_date_range)
            if rolling_days is not None and rolling_days >= 0:
                start_date = CURRENT_DATE + timedelta(days = offset_date_range)
                end_date = start_date + timedelta(days = rolling_days )
            elif rolling_days is not None and rolling_days < 0:
                end_date = CURRENT_DATE
                start_date = end_date + timedelta(days = rolling_days) - timedelta(days = offset_date_range)
            else:
                start_date = CURRENT_DATE
                end_date = CURRENT_DATE
            

    elif selected_date_range['ref_dun_unit'] == 'day':

        if score == -1 or score == 1:
            # yesterday = -1 and tomorrow = 1
            start_date = end_date = CURRENT_DATE + relativedelta(days = score)
        
        elif score > 0:
            start_date = CURRENT_DATE
            end_date = start_date + relativedelta(days = score)        
        
        else:
            end_date = CURRENT_DATE
            start_date = end_date + relativedelta(days = score)
    
    elif selected_date_range['ref_dun_unit'] == 'month':
        if score == 0:
            start_date = CURRENT_DATE.replace(day = 1)
            end_date = start_date+relativedelta(months = 1) + relativedelta(days = -1)
        elif score > 0:
            start_date = (CURRENT_DATE + relativedelta(months= 1)).replace(day=1)
            end_date = start_date + relativedelta(months = score) + relativedelta(days=-1)        
        elif score < 0:
            end_date = CURRENT_DATE.replace(day = 1) + relativedelta(days = -1)
            start_date = (end_date + relativedelta(months = score) + relativedelta(months=1)).replace(day=1)
    
    elif selected_date_range['ref_dun_unit'] == 'year':
        if option == 1:
            # year to date
            start_date = CURRENT_DATE.replace(month=1, day=1)
            end_date = CURRENT_DATE
        
        elif option == 9:
            # Since the beginning of time
            start_date = CURRENT_DATE.replace(year=2000, month=1, day=1)
            end_date = CURRENT_DATE
        
        elif option == 10:
            # from today onwards
            start_date = CURRENT_DATE
            end_date = CURRENT_DATE.replace(year=2100, month=12, day=31)


        if score is not None and score > 0:
            start_date = CURRENT_DATE.replace(month = 1 , day = 1) + relativedelta(years=1)
            end_date = CURRENT_DATE.replace(month = 12, day = 31) + relativedelta(years = score)
        
        elif score is not None and score < 0:
            end_date = CURRENT_DATE
            start_date = CURRENT_DATE + relativedelta(years = score)
    
    return start_date, end_date


def get_filter_values(self, person = None, rsu_id= None, report_id = None, group_by = False):
    exclude_group_by = [Q(rsf_rft_id = 24)] if not group_by else []

    '''
    function can be used for both APP and SOFVIE BI
    - for APP we always call to get complete details of single schedule report - input rsu_id
    - for SOFVIE BI we call to get complete details of all saved reports 
        for logged in user and selected  report_id - person, report_id
    
    depending on the input we will pass filters to below query rsu_filter or report_filter
    '''
    rsu_id = [rsu_id] if type(rsu_id) == int else rsu_id

    rsu_filter = [Q(rsf_rsu__rsu_id__in=rsu_id)] if rsu_id else []

    report_filter = [Q(rsf_rsu__rsu_rpt_id=report_id) & Q(rsf_rsu__rsu_per = person) & Q(rsf_rsu__rsu_enable=True)] if report_id and person else []

    person_instance = self.request.user.user_per_id

    lng_name = UserProfile.objects.get(upr_per_id=person_instance).upr_language
    lng_id = Language.objects.get(lng_name=lng_name).lng_id


    filter_values = ReportSavedFilterType.objects.prefetch_related(
        'rsv_report_saved_filter_type',
        'rsf_rft__rfm_report_filter_type',
    ).exclude(
        *exclude_group_by
    ).filter(
        *rsu_filter,
        *report_filter,
        rsf_enable = True,
        rsv_report_saved_filter_type__rsv_enable = True,
        rsf_rsu__rsu_rpt_id = F('rsf_rft__rfm_report_filter_type__rfm_rpt_id'),

    ).annotate(
        rft_values = GroupConcat('rsv_report_saved_filter_type__rsv_value', ''),
        rft_id = F('rsf_rft__rft_id'),
        rft_name = F('rsf_rft__rft_name'),
        rft_type = F('rsf_rft__rft_type'),
        rfm_is_mandatory = F('rsf_rft__rfm_report_filter_type__rfm_is_mandatory'),
        rft_ref_name = F('rsf_rft__rft_rlh__rlh_name'),        
        control_name = Subquery(
            LanguageTranslation.objects.filter(ltr_tag=OuterRef('rsf_rft__rft_tag'),ltr_tag_type=1, ltr_lng = lng_id).values('ltr_text')[:1]
        ),  
    ).values(        
        'rft_id',
        'rft_name',
        'rft_type',
        'rfm_is_mandatory',
        'rft_ref_name',
        'rft_values',
        'rsf_rsu__rsu_id',
        'rsf_rsu__rsu_rpt__reporturl',
        'control_name'
    )


    # remove duplicates for rft_values
    for each in filter_values:
        each['rft_values'] = ','.join(list(set(each['rft_values'].split(','))))


    # case when report has both site_ids & job_ids and job_ids is dependent on site_ids
    # if site_values not null get all/allactive jobs ids for selected site values
    site_values = check_site_jobs(filter_values)

    # The results of the filter values resides in a select list.
    # Need to identify and cast all integers before returning. 
    for each in filter_values:
        filter_key = each['rft_name']
        ref_data = False
        each['show_inactive'] = True
        if each['rft_type'] == 'datetime':
            # some legacy data have date string in 2022-8-8, 
            # converting that to date and string again would change format to 2022-08-08 which is acceptable in sofvie-bi code.
            date_value = datetime.strptime(each['rft_values'], "%Y-%m-%d")
            date_string = datetime.strftime(date_value, "%Y-%m-%d")
            each['rft_values'] = date_string
        if each['rft_ref_name'] is not None:
            filter_key = each['rft_ref_name']
            ref_data = True
            # This is a special case for the pending general/hazard action reports
            self.report_id = report_id
            if (report_id == 71 or report_id == 11) and each['rft_ref_name'] == 'ref_report_schedule_period':
                each['ref_data'] = get_ref_data(self, each['rft_ref_name'], lng_id, [2,3])
            else:
                each['ref_data'] = get_ref_data(self, each['rft_ref_name'], lng_id)
            if each['rft_name'] == 'report_selection':
                each['ref_data'] = get_groupby_report_data(report_id, lng_id)
        if each['rft_values'] == 'allactive' or each['rft_values'] == 'all':     
            each['rft_values'] = get_all_filter_values(filter_key, lng_id, each['rft_values'], ref_data, site_values)            
        else:
            if type(each['rft_values']) == str and each['rft_name'] not in ['start_date', 'end_date']:
                values_list = [int(v) for v in each['rft_values'].split(',')]
                each['rft_values'] = list(set(values_list))
            elif type(each['rft_values']) == list:
                unique_values = list(set(each['rft_values']))
                each['rft_values'] =list(map(int, unique_values))

    return list(filter_values)

def get_filter_report_url(self, person, rsu_id, report_id, lng_id):

    filter_values = get_filter_values(self, person=person, rsu_id=rsu_id, report_id=report_id,group_by = True)
    customdaterange_rld_id = RefListDetail.objects.get(
        rld_rlh_id = 93,
        rld_option = 2,
        rld_enable = True,
    ).rld_id

    arguments = []
            
    rolling_days = None
    rolling_days = next((item['rft_values'] for item in filter_values if item["rft_name"] == "days_from_today"), None)
    rolling_days = rolling_days[0] if rolling_days else 0

    offset_date_range = next((item['rft_values'] for item in filter_values if item["rft_name"] == "offset_date_range"), None)
    offset_date_range = offset_date_range[0] if offset_date_range else 0

    for arg in filter_values:
        rft_values = arg['rft_values']
        if arg['rft_name'] == 'date_range' and len(rft_values) ==1 and rft_values[0] != customdaterange_rld_id:
            date_range_rld_id = rft_values[0] if len(rft_values) == 1 else 0

            if rolling_days is not None:
                arguments.append('rolling_date=' + str(abs(int(rolling_days))))
                if int(rolling_days) < 0:
                    arguments.append('custom_rolling_option=Past')
                else:
                    arguments.append('custom_rolling_option=Future')

            if offset_date_range is not None:
                arguments.append('offset_date_range=' + str(abs(int(offset_date_range))))

            start_date, end_date = get_start_date_end_date(self, rld_id = date_range_rld_id, rolling_days=rolling_days, offset_date_range = offset_date_range)
            arguments.append(arg['rft_name'] + '=' + str(date_range_rld_id))
            arguments.append('start_date=' + str(start_date))
            arguments.append('end_date=' + str(end_date))
        
        else:              
            if arg['rft_name'] not in ['start_date', 'end_date']: 
                rft_values = ','.join(map(str, rft_values))
                arguments.append('display_inactive_'+arg['rft_name'] + '=' + str(arg['show_inactive']))
            arguments.append(arg['rft_name'] + '=' + rft_values)
    
    arguments.append('apply=1')


    return "&".join(arguments)


def get_all_filter_values(filter_key, lng_id, flag_value = "all", ref_data = True, site_values = []):

    '''    
    function to get all(active&inactive) or all active values of selected filter type 
    when user selects "select all" in report scheduling in APP or saved filters in Sofvie BI
    '''
    filter_values = ''
    if ref_data:
        rld_parent_filter = []
        if filter_key == 'ref_job' and len(site_values) > 0 and site_values!= 'allactive' and site_values != 'all':
            rld_parent_filter = [Q(rld_parent_detail_rld_id__in = site_values)]
        
        ref_ids = RefListDetail.objects.filter(rld_rlh__rlh_name = filter_key, *rld_parent_filter).values()

        
        if flag_value == 'allactive':
            filter_values = ref_ids.filter(rld_enable = True ,rld_deleted = False).values_list('rld_id', flat = True)
        else:
            filter_values = ref_ids.values_list('rld_id', flat = True)

    else:
        '''
        per_id, form_id, role_id, equipment_id
        '''
        if filter_key in ['per_ids', 'user_ids', 'by_who', 'from_who']:
            # call GetFullEmployeeListProfile from employee            
            per_ids = get_full_employee_list_profile(lng_id)
            if flag_value =='allactive':
                filter_values = [each['per_id'] for each in per_ids if each['status_flag'] == 1 ]
            else:
                filter_values = [each['per_id'] for each in per_ids]
        elif filter_key == 'form_ids':
            form_list = get_all_form_list(lng_id, flag_value)
            if flag_value == 'allactive':
                form_id_list = [each['FormID'] for each in form_list if each['status_flag'] == 1]
            else:
                form_id_list = [each['FormID'] for each in form_list]
            filter_values = additional_form_ids(form_id_list)
        elif filter_key == 'role_ids':
            role_ids = AuthRoleSofvie.objects.all()
            if flag_value == 'allactive':
                filter_values = role_ids.filter(aro_enable = True).values_list('aro_id', flat = True)
            else:
                filter_values = role_ids.values_list('aro_id', flat = True)
        elif filter_key == 'equipment_ids':
            equipment_list = EquipmentType.objects.all()
            if flag_value == 'allactive':
                filter_values = equipment_list.filter(poe_enable=True).values_list('poe_id', flat = True)
            else:
                filter_values = equipment_list.values_list('poe_id', flat = True)
        elif filter_key == 'full_equipment_ids':
            if flag_value == 'allactive':
                full_equipment_list = get_full_equipment_list(lng_id, 'allactive')
            else:
                full_equipment_list = get_full_equipment_list(lng_id)
            
            filter_values = [equipment['pet_id'] for equipment in full_equipment_list]

    return filter_values


def check_site_jobs(filter_values):
    arg_filters = [arg['rft_name'] for arg in filter_values]
    site_values = []
    if 'site_ids' and 'job_ids' in arg_filters:
        for arg in filter_values:
            
            if arg['rft_name'] == 'site_ids' and arg['rft_values'] != 'all' and arg['rft_values'] != 'allactive':
                if type(arg['rft_values']) == str:
                    arg['rft_values'] = arg['rft_values'].split(',')
                site_values = arg['rft_values']
    return site_values

def additional_form_ids(form_ids):
    # additioanl form ids to include employee departure and lineup in selection
    from apps.form.models import Mobileforms
    mobile_form_ids = list(Mobileforms.objects.exclude(
                formid__isnull = True
            ).values_list('formid', flat = True))
    additional_form_ids = Reports.objects.exclude(
        Q(singleformreportid__in = mobile_form_ids) | Q(singleformreportid = 131200)
    ).filter(
        rpt_enable = True
    ).values_list('singleformreportid', flat = True)
    
    form_ids = form_ids + list(filter(None,additional_form_ids))
    
    return form_ids