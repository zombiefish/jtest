from django.forms import model_to_dict
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from django.db.models import F, Q,OuterRef, Subquery
from apps.common_utils.views.custom_aggregate_function import GroupConcat

from apps.common_utils.views.validate_permission import RolePermission
from apps.report_scheduler.models import ReportSavedFilterType
from ....general_action.models import Reports

from apps.report_scheduler.api.views.common_functions import get_report_filters_data, get_filter_values
from apps.report_scheduler.api.views.get_schedule_report_list import get_schedule_report

from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.language.models import Language
from apps.user_settings_profile.models import UserProfile
from apps.person.models import Person

class GetSingleScheduleReport(APIView):
    permission_classes = [IsAuthenticated, SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)
    
    def post(self, request):
        person = self.request.user.user_per_id
        
        rsm_id = request.data.get('rsm_id')
        try:
            if rsm_id:

                single_schedule_report = get_schedule_report(self, person, rsm_id)
                single_schedule_report = single_schedule_report.annotate(
                    rsm_is_scheduled = F('rsm_rsu__rsu_is_scheduled'),
                ).values(
                    'rsm_id',            
                    'rsm_rsu_id',    
                    'rsm_rpt_id',
                    'rsm_description',
                    'rsm_frequency_rld',
                    'rsm_day_tag',
                    'rsm_end_rld_id',
                    'rsm_start_date',
                    'rsm_expire_date',
                    'rsm_occurrences',
                    'rsm_is_scheduled',
                    'rsm_distribution'
                )

                # get filter value details - 
                if len(single_schedule_report) == 1:
                    single_schedule_report = single_schedule_report[0]
                    group_by_rpt_id = check_group_by_report(single_schedule_report)
                    single_schedule_report['rsm_distribution'] = single_schedule_report['rsm_distribution'].split(',') \
                        if single_schedule_report['rsm_distribution'] else []
                    filter_values = get_filter_values(self, rsu_id = single_schedule_report['rsm_rsu_id'], report_id = single_schedule_report['rsm_rpt_id'], group_by=True)
                    

                    filter_values = validate_filter_values(self, person, filter_values, single_schedule_report['rsm_rpt_id']) 
                    single_schedule_report['group_by_report'] = False
                    single_schedule_report['group_by_report_id'] = None
                    if group_by_rpt_id:
                        filter_values = get_groupby_filter_values(self, group_by_rpt_id, filter_values )
                        single_schedule_report['group_by_report'] = True
                        single_schedule_report['group_by_report_id'] = int(group_by_rpt_id)
                    single_schedule_report['rsm_arguments'] = filter_values

                    return Response(single_schedule_report, status=status.HTTP_200_OK)
                else:
                    return Response({"error": "No Schedule Report Found"}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)  

def validate_filter_values(self, person, filter_values, rpt_id):
    
    lng_name = UserProfile.objects.get(upr_per_id=person).upr_language
    lng_id = Language.objects.get(lng_name=lng_name).lng_id

    all_arguments = get_report_filters_data(self, rpt_id, lng_id)

    selected_arg_ids = [each['rft_id'] for each in filter_values]
    
    res = [i for i in all_arguments if (i['rft_id'] not in selected_arg_ids)]

    for each in res:
        each['rft_values']  = []

    return filter_values + res


def check_group_by_report(single_schedule_report):
    check_group_by = Reports.objects.filter(
        rpt_rpt_id = single_schedule_report['rsm_rpt_id']
    ).exists()

    group_rpt_id = None

    if check_group_by:
        filter_values = ReportSavedFilterType.objects.prefetch_related(
                'rsv_report_saved_filter_type',
            ).filter(
                rsf_enable = True,
                rsf_rft_id = 24,
                rsf_rsu__rsu_id = single_schedule_report['rsm_rsu_id']
            ).annotate(
                rft_values = F('rsv_report_saved_filter_type__rsv_value')
            ).values(                        
                'rft_values'                
            )

        if filter_values:
            group_rpt_id = filter_values[0]['rft_values']
        return group_rpt_id
    return group_rpt_id

def get_groupby_filter_values(self, groupby_rpt_id, filter_values):

    lng_name = UserProfile.objects.get(upr_per_id=self.request.user.user_per_id_id).upr_language
    lng_id = Language.objects.get(lng_name=lng_name).lng_id
    groupby_rpt_arguments = get_report_filters_data(self, groupby_rpt_id, lng_id)
    rft_ids_list = [each['rft_id'] for each in groupby_rpt_arguments]
    modified_filter_values = []
    for filter in filter_values:
        if filter['rft_id'] in rft_ids_list:
            modified_filter_values.append(filter)
    return modified_filter_values