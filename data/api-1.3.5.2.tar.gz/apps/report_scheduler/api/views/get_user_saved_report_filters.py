from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import generics, status

from django.db.models import F

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.report_scheduler.models import ReportSavedFilterValue, ReportSavedUserFilter

class GetUserSavedReportFilters(APIView):
    permission_classes = [IsAuthenticated, SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def post(self, request):
        person = self.request.user.user_per_id
        report_id = request.data.get('rfm_rpt_id')
        sub_report_id = request.data.get('sub_rpt_id')

        try:
            if report_id:
                user_saved_report_filters = get_user_saved_report_filters(self, person, report_id, sub_report_id)
                return Response({'rsu_filters': user_saved_report_filters}, status=status.HTTP_200_OK)
            else:
                return Response({'error': 'Report ID is required'}, status=status.HTTP_400_BAD_REQUEST)       
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


def get_user_saved_report_filters(self, person, report_id, sub_report_id = None):

    if sub_report_id:

        get_user_saved_report_filters = ReportSavedFilterValue.objects.filter(
            rsv_rsf__rsf_rft_id = 24, #filter type value for report_selection unique for all clients
            rsv_value = sub_report_id,
            rsv_rsf__rsf_rsu__rsu_enable = True,
            rsv_rsf__rsf_rsu__rsu_is_scheduled=False,
            rsv_rsf__rsf_rsu__rsu_per=person
        ).annotate(
            rsu_id = F('rsv_rsf__rsf_rsu_id'),
            rsu_filter_name = F('rsv_rsf__rsf_rsu__rsu_filter_name')
        ).values(
            'rsu_id', 
            'rsu_filter_name'
        )


    else:
        get_user_saved_report_filters = ReportSavedUserFilter.objects.filter(
            rsu_per=person,
            rsu_rpt=report_id,
            rsu_is_scheduled=False,
            rsu_enable=True
        ).values(
            'rsu_id',
            'rsu_filter_name'
        )

    return list(get_user_saved_report_filters)



    
