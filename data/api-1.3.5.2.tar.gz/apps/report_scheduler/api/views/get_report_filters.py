from rest_framework.views import APIView
from rest_framework.response import Response

from django.db.models import F,  Subquery, OuterRef
from apps.language.models import LanguageTranslation

from apps.common_utils.views.validate_permission import RolePermission
from apps.report_scheduler.api.views.common_functions import get_report_filters_data
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.language.models import Language
from apps.user_settings_profile.models import UserProfile


from apps.common_utils.views.get_translations import get_translation


class GetReportFilters(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def post(self, request):
        report_id = request.data.get('rfm_rpt_id')
        person_id = self.request.user.user_per_id_id
        person_instance = self.request.user.user_per_id

        lng_name = UserProfile.objects.get(upr_per_id=person_instance).upr_language
        lng_id = Language.objects.get(lng_name=lng_name).lng_id

        try:
            if report_id:
                report_filters = get_report_filters_data(self, report_id,lng_id)
                
                return Response({'rsm_arguments': report_filters}, status=200)
            else:
                return Response({'error': 'Report ID is required'}, status=400)       
        except Exception as e:
            return Response({'error': str(e)}, status=500)




