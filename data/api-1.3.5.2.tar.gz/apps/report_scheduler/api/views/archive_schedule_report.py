from datetime import datetime
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response

from apps.common_utils.views.validate_permission import RolePermission
from apps.report_scheduler.models import ReportSavedUserFilter, ReportScheduleMaster
from apps.sofvie_user_authorization.api.permissions import SofviePermission

class ArchiveScheduleReport(APIView):
    permission_classes = [IsAuthenticated, SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def post(self, request):
        person = self.request.user.user_per_id
        rsm_ids = [each['rsm_id'] for each in request.data]
        try:
            if rsm_ids:

                # get report schedule master
                report_schedule_master = ReportScheduleMaster.objects.filter(rsm_id__in=rsm_ids)

                for rms_report in report_schedule_master:
                    rms_report.rsm_enable = False
                    rms_report.rsm_modified_by_per = person
                    rms_report.rsm_modified_date = datetime.now()
                    rms_report.save() 
                
                return Response({"success": "Report Schedule Archived Successfully"}, status=status.HTTP_200_OK)
            else:
                return Response({"error": "No Report Schedule Found"}, status=status.HTTP_400_BAD_REQUEST)
        except ReportScheduleMaster.DoesNotExist:
            return Response({"error": "No Report Schedule Found"}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)