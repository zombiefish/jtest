from datetime import datetime
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db import transaction

from apps.common_utils.views.validate_permission import RolePermission
from apps.report_scheduler.api.views.add_scheduled_report import add_saved_user_filter
from apps.report_scheduler.api.views.common_functions import check_all_filters_exists
from apps.report_scheduler.models import ReportSavedFilterType, ReportSavedFilterValue, ReportScheduleDistribution, ReportScheduleMaster
from apps.sofvie_user_authorization.api.permissions import SofviePermission



class UpdateScheduledReport(APIView):
    permission_classes = [IsAuthenticated, SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    @transaction.atomic
    def post(self, request):
        person = self.request.user.user_per_id

        try:
            report_scheduler_data = request.data.pop('report_scheduler')
            

            rsm_filters = report_scheduler_data.pop('rsm_filters', None)
            rsm_distribution = report_scheduler_data.pop('rsm_distribution', None)
            rsu_is_scheduled = report_scheduler_data.pop('rsm_is_scheduled', None)
            update_schedule_report_data = report_scheduler_data

            if update_schedule_report_data and rsm_distribution:

                if 'rsm_rsu_id' not in update_schedule_report_data or update_schedule_report_data['rsm_rsu_id'] is None:
                    # add record to ReportSavedUserFilter table:
                    new_rsu_id = add_saved_user_filter(self, person, update_schedule_report_data)                    
                    update_schedule_report_data['rsm_rsu_id'] = new_rsu_id.rsu_id
                
                # update report schedule master data
                # check if record exists in report scheudler master, if not throw error using exception
                schedule_report = ReportScheduleMaster.objects.get(rsm_id=update_schedule_report_data['rsm_id'], rsm_enable = True)

                update_schedule_report_data['rsm_modified_by_per'] = person
                update_schedule_report_data['rsm_modified_date'] = datetime.now()

                update_schedule_report = ReportScheduleMaster.objects.filter(
                    rsm_id=update_schedule_report_data['rsm_id']
                ).update(
                    **update_schedule_report_data
                )

                # on update if rsu_is_scheduled is false, that means a new user saved filter is selected 
                # if rsu_is_scheduled is true, that means an existing user saved filter is selected, so updating filter values
                if rsu_is_scheduled and rsm_filters:                           
                    update_filters = update_filter_values(self, person, update_schedule_report_data['rsm_rsu_id'], rsm_filters, update_schedule_report_data['rsm_rpt_id'])
                    
                    if not update_filters:
                        return Response({"error": "Updating Filter Values failed"}, status=status.HTTP_400_BAD_REQUEST)

                # update report schedule distribution data
                update_distribution(self, person, update_schedule_report_data['rsm_id'], rsm_distribution)

                return Response({"success": "Schedule Report Updated Successfully"}, status=status.HTTP_200_OK)
            else:
                return Response({"error": "Update Schedule Report Failed"}, status=status.HTTP_400_BAD_REQUEST)
        
        except ReportScheduleMaster.DoesNotExist:
            return Response({"error": "No Report Schedule Found"}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"error": "Update Schedule Report Failed\n"+str(e)}, status=status.HTTP_400_BAD_REQUEST)

@transaction.atomic
def update_distribution(self, person, rsm_id, rsm_distribution):       

    '''
    plan for updating - function receives new distribution data

    1. get existing distribution data
    2. compare new distribution data with existing data
    3. check if data is missing in new data, if yes, set rsd_enable = False to missing data
    4. check if new data is added in existing data, if yes, create new records in report schedule distribution
    '''
    
    existing_distribution = ReportScheduleDistribution.objects.filter(
        rsd_rsm_id=rsm_id,
        rsd_enable = True
    ).values_list('rsd_email', flat=True)

    missing_distribution = list(set(existing_distribution) - set(rsm_distribution))    

    # update rds_enable = False for missing distribution
    ReportScheduleDistribution.objects.filter(
        rsd_rsm_id=rsm_id,
        rsd_email__in=missing_distribution
    ).update(
        rsd_enable=False, 
        rsd_modified_by_per=person, 
        rsd_modified_date=datetime.now()
    )   

    new_distribution = list(set(rsm_distribution) - set(existing_distribution))    

    bulk_create_rsd = [
        ReportScheduleDistribution(
            rsd_rsm_id = rsm_id,
            rsd_email = distribution,
            rsd_created_by_per = person,            
        ) for distribution in new_distribution
    ]

    rsd_instance = ReportScheduleDistribution.objects.bulk_create(bulk_create_rsd)

@transaction.atomic
def update_filter_values(self, person, rsm_rsu_id, rsm_filters, report_id):

    '''
    plan for updating - function receives new rsm_filters data, report_id, rsm_rsu_id

    1. Check if all mandataory filters are selected, if not throw error using exception - 
        use check_all_filters_exists function
    2. get existing filter types data for selected rsm_rsu_id
    3. compare new filter types data with existing data
    4. check if data is missing in new data, if yes, set rsf_enable = False to missing data
    5. check if new data is added in existing data, if yes, create new records in report schedule filter types
        (optional filters might be added or removed in new data)

    6. get existing filter values data for each filter type selected rsm_rsu_id
    7. compare new filter values data with existing data
    8. check if data is missing in new data, if yes, set rsv_enable = False to missing data
    9. check if new data is added in existing data, if yes, create new records in report schedule filter values
    10. add new filters values data for new filter types using new_rsft_instace.

    '''

    # updating ReportSavedFilterType - rsf_rft_id's
    current_rft_ids = [each['rft_id'] for each in rsm_filters]

    # check if all mandatory filters are present in new data
    all_mandatory_exists = check_all_filters_exists(self, current_rft_ids, report_id)

    if not all_mandatory_exists:
        return False    

    # get existing filter arguments selected for the report
    existing_rft_ids = ReportSavedFilterType.objects.filter(
        rsf_rsu_id=rsm_rsu_id,
        rsf_enable=True
    ).values_list('rsf_rft_id', flat=True) 


    # get missing filter arguments from new data - optional filters might be added or removed in new data
    missing_rft_ids = list(set(existing_rft_ids) - set(current_rft_ids))

    # update rsf_enable = False for missing filters
    ReportSavedFilterType.objects.filter(
        rsf_rsu_id=rsm_rsu_id,
        rsf_rft_id__in = missing_rft_ids   
    ).update(
        rsf_enable=False,
        rsf_modified_by_per=person,
        rsf_modified_date=datetime.now()
    )

    # get new filter arguments from new data - optional filters might be added or removed in new data
    new_rft_ids = list(set(current_rft_ids) - set(existing_rft_ids))    

    # create new filter arguments for new data
    bulk_create_rsft = [
        ReportSavedFilterType(
            rsf_rsu_id = rsm_rsu_id,
            rsf_rft_id = rsf_id,
            rsf_created_by_per = person,            
        ) for rsf_id in new_rft_ids
    ]

    # create new filter arguments for new data
    new_rsft_instance = ReportSavedFilterType.objects.bulk_create(bulk_create_rsft)

    for rsm_filter in rsm_filters:

        '''
        1. update values for existing rft_ids
        2. check if rsm_filter['rft_id'] in existing_rft_ids
        3. If exists, update values for existing rft_ids
        4. If not exists, create new values for new rft_ids
        '''

        if rsm_filter['rft_id'] in existing_rft_ids:
            rsft = None
            # get existing filter values selected for the report
            current_rsf_ids = existing_rft_ids.values('rsf_id', 'rsf_rft_id')
            # get rsft instance for current filter argument and current filter values
            for each in current_rsf_ids:
                if each['rsf_rft_id'] == rsm_filter['rft_id']:
                    rsft = each['rsf_id']                
                    break
            update_existing_filter_values(self, person, rsm_filter, rsft)
        
        else:
            new_rsft = None
            for each in new_rsft_instance:
                if each.rsf_rft_id == rsm_filter['rft_id']:                    
                    new_rsft = each.rsf_id
            create_new_filter_values(self, person, rsm_filter, new_rsft)   
    
    return True

@transaction.atomic
def update_existing_filter_values(self, person, rsm_filter, rsft):    

    current_filter_values = rsm_filter['rft_values']
    # get existing filter values selected for the report
    existing_filter_values = ReportSavedFilterValue.objects.filter(
        rsv_rsf_id = rsft,
        rsv_enable=True
    ).values_list('rsv_value', flat=True)

    # get missing filter values from new data, filter values might have changed for all arguments mandatory and optional
    missing_filter_values = list(set(existing_filter_values) - set(current_filter_values))

    # update rsv_enable = False for missing filters
    ReportSavedFilterValue.objects.filter(
        rsv_rsf_id = rsft,
        rsv_value__in = missing_filter_values
    ).update(
        rsv_enable=False,
        rsv_modified_by_per=person,
        rsv_modified_date=datetime.now()
    )

    # get new filter values from new data, filter values might have changed for all arguments mandatory and optional
    new_filter_values = list(set(current_filter_values) - set(existing_filter_values)) 
    bulk_create_rsv = [
        ReportSavedFilterValue(
            rsv_rsf_id = rsft,
            rsv_value = rsv_value,
            rsv_created_by_per = person,                
        ) for rsv_value in new_filter_values
    ]
    rsv_instance = ReportSavedFilterValue.objects.bulk_create(bulk_create_rsv)

    return True

@transaction.atomic
def create_new_filter_values(self, person, rsm_filter, new_rsft):
    # create new filter values for new data
    if new_rsft:
        bulk_create_rsv = [
            ReportSavedFilterValue(
                rsv_rsf_id = new_rsft,
                rsv_value = rsv_value,
                rsv_created_by_per = person,                
            ) for rsv_value in rsm_filter['rft_values']
        ]
        rsv_instance = ReportSavedFilterValue.objects.bulk_create(bulk_create_rsv)

    return True