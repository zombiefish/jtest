from datetime import datetime, timedelta
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db import connection
from apps.incident_management.api.utlity_function import dictfetchall
from apps.language.models import Language
from apps.person.models import Person
# from apps.report_scheduler.api.views.common_functions import get_start_date_end_date
from apps.user_settings_profile.models import UserProfile
from dateutil.relativedelta import relativedelta

class GetDateRange(APIView):
    
    def get(self, request):
        
        try:
            self.person_instance = self.request.user.user_per_id
            self.lng_name  = UserProfile.objects.get(upr_per = self.person_instance).upr_language
            self.lng_id = Language.objects.get(lng_name = self.lng_name).lng_id

            self.date_range = get_date_range(self)

            return Response(self.date_range, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"message": str(e)}, status=status.HTTP_400_BAD_REQUEST)


def get_date_range(self):
    
    with connection.cursor() as cursor:
        cursor.execute("call get_date_range(%s)", ([self.lng_id]))
        date_range = dictfetchall(cursor) 
    
    return date_range


