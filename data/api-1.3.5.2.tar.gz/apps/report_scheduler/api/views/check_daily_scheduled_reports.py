'''
1. Global values
---------------------
current day  | current week | first day of current month | first day of current quarter | first day of current Biannual cycle | first day of current Annual cycle
---------------------
2. Add a function to set rsm_enable = False after rsm_end_rld condition satisfies for respective rsm_ids

3 - daily
get rsm_ids with frequence daily.

- weekly
get rsm_ids with frequency weekly and day of the week = today

- Bi-weekly (every other week)
get rsm_ids with frequncy every_other_week and day of the week - every alternative week day from created date

- monthly
get rsm_ids with frequency monthly and if its first day of current month

- quarterly
get rsm_ids with frequency quarterly and if its first day of current quarter

- Biannually
get rsm_ids with frequency Biannually and if its first day of current Biannual cycle

- Annually
get rsm_ids with frequency Annually and if its first day of current year
---------------------- '''
from datetime import datetime
from decouple import config
from django.conf import settings
from django.db.models import DateField
from django.template.loader import get_template
from django.core.mail import EmailMultiAlternatives
from django.db.models import Prefetch, Count, Value, F, Q, Subquery, OuterRef
from django.db.models.functions import Cast, Concat
from rest_framework import status
import calendar

from apps.common_utils.views.custom_aggregate_function import GroupConcat
from apps.common_utils.views.get_translations import get_translation
from apps.common_utils.views.sofvieModelFields import SofvieCharField
from apps.work_hour_log.models import SystemSettings
from apps.language.models import Language, LanguageTranslation
from apps.reflist.models import RefListDetail
from apps.report_scheduler.api.views.common_functions import check_site_jobs, get_all_filter_values, get_start_date_end_date
from apps.report_scheduler.api.views.get_schedule_report_list import calculate_expiry_date
from apps.report_scheduler.models import ReportScheduleEmailStatus, ReportScheduleMaster

from itertools import groupby
from apps.report_scheduler.models import ReportSavedFilterType
from rest_framework.views import APIView
from rest_framework.response import Response
from urllib import parse
from apps.report_scheduler.api.views.save_report_filter_url import save_report_filters


def get_frequency_month(month, frequency):
    frequency_number = (int(month) - 1) // frequency + 1
    frequency_month = (frequency_number * frequency) - (frequency-1)
    return frequency_month

class GetReportSchedulerRunTimeSettings(APIView):
    def get(self, request,):
        report_scheduler_settings = SystemSettings.objects.filter(
            sys_setting_type=4
        )
        all_settings = {}
        for each in report_scheduler_settings:
            all_settings[each.sys_setting_name] = each.sys_setting_value
        return Response({"all_settings": all_settings}) 

# to test report scheduling as an endpoint in local.
class GenerateScheduledReports(APIView):
    def get(self, request,):
        current_hour = datetime.now().hour
        current_minute = datetime.now().minute
        report_settings = GetReportSchedulerRunTimeSettings.get(self, request)
        report_settings = report_settings.data['all_settings']
        if report_settings['REPORT_SCHEDULER_RUN_STATUS'] == 0:            
            return Response({"message": "Report Scheduler is not running"}, status= status.HTTP_400_BAD_REQUEST)
        if report_settings['REPORT_SCHEDULER_RUN_HOUR'] != current_hour and report_settings['REPORT_SCHEDULER_RUN_MINUTE'] != current_minute:
            return Response({"message": "Report Scheduler is not running at this time."}, status = status.HTTP_403_FORBIDDEN)
        
        report_response = report_scheduler(self)
        if report_response == False:
            return Response({"message": "No emails to send"}, status = status.HTTP_400_BAD_REQUEST)
        return Response({"email sent to": report_response})


def report_scheduler(self):
    CURRENT_DAY = datetime.now()

    daily_rsm_rsu_ids = []
    weekly_rsm_rsu_ids = []
    biweekly_rsm_rsu_ids = []
    monthly_rsm_rsu_ids = []
    quaterly_rsm_rsu_ids = []
    biannually_rsm_rsu_ids = []
    annually_rsm_rsu_ids = []

    customdaterange_rld_id = RefListDetail.objects.get(
                rld_rlh_id = 93,
                rld_option = 2,
                rld_enable = True,
            ).rld_id

    score = {
        'daily': 1,
        'weekly': 7,
        'biweekly': 14,
        'monthly': 30,
        'quaterly': 90,
        'biannually': 182,
        'annually': 365
    }

    # find all rsu_ids
    daily_rsm_rsu_ids, daily_rsm_ids = get_rsu_ids(score['daily'])
    weekly_rsm_rsu_ids, weekly_rsm_ids = get_rsu_ids(score['weekly'])
    biweekly_rsm_rsu_ids, biweekly_rsm_ids = get_rsu_ids(score['biweekly'])
    monthly_rsm_rsu_ids, monthly_rsm_ids = get_rsu_ids(score['monthly'])
    quaterly_rsm_rsu_ids, quaterly_rsm_ids = get_rsu_ids(score['quaterly'])
    biannually_rsm_rsu_ids, biannually_rsm_ids = get_rsu_ids(score['biannually'])
    annually_rsm_rsu_ids, annually_rsm_ids = get_rsu_ids(score['annually'])


    all_rsu_ids = list(daily_rsm_rsu_ids) + list(weekly_rsm_rsu_ids) + list(monthly_rsm_rsu_ids) + list(quaterly_rsm_rsu_ids) + list(biannually_rsm_rsu_ids) + list(annually_rsm_rsu_ids) + list(biweekly_rsm_rsu_ids)
    all_rsm_ids = list(daily_rsm_ids) + list(weekly_rsm_ids) + list(monthly_rsm_ids) + list(quaterly_rsm_ids) + list(biannually_rsm_ids) + list(annually_rsm_ids) + list(biweekly_rsm_ids)

    if all_rsu_ids == [] or all_rsu_ids == None:    
        return False
    email_sent_today = check_email_sent_already(all_rsm_ids)
    if email_sent_today:
        return False

    all_filter_values =  get_filter_values(rsu_ids= all_rsu_ids)

    all_filter_values = all_filter_values.prefetch_related(
        'rsf_rsu__rsm_report_saved_user_filter',
        'rsf_rsu__rsm_report_saved_user_filter__rsd_report_schedule_master',
    ).filter(
        rsf_rsu__rsm_report_saved_user_filter__rsm_id__in = all_rsm_ids
    ).annotate(
        rsm_id = F('rsf_rsu__rsm_report_saved_user_filter__rsm_id'),
        rsm_description = F('rsf_rsu__rsm_report_saved_user_filter__rsm_description'),
        rsm_created_by = Concat('rsf_rsu__rsm_report_saved_user_filter__rsm_created_by_per__per_last_name', Value(', '),
        'rsf_rsu__rsm_report_saved_user_filter__rsm_created_by_per__per_first_name', output_field = SofvieCharField()),
        rsm_created_date = F('rsf_rsu__rsm_report_saved_user_filter__rsm_created_date'),
        rsm_modified_date = F('rsf_rsu__rsm_report_saved_user_filter__rsm_modified_date'),
        rsm_occurrences = F('rsf_rsu__rsm_report_saved_user_filter__rsm_occurrences'),
        rsm_frequency_rld__rld_score = F('rsf_rsu__rsm_report_saved_user_filter__rsm_frequency_rld__rld_score'),
        rsm_start_date = F('rsf_rsu__rsm_report_saved_user_filter__rsm_start_date'),
        rsm_day_tag = F('rsf_rsu__rsm_report_saved_user_filter__rsm_day_tag'),
        rsm_expire_date = F('rsf_rsu__rsm_report_saved_user_filter__rsm_expire_date'),
        rsd_email_list = GroupConcat('rsf_rsu__rsm_report_saved_user_filter__rsd_report_schedule_master__rsd_email', ''),
    ).values(
        'rft_id',
        'rft_name',            
        'rft_values',            
        'rsf_rsu__rsu_rpt__reporturl',
        'rsm_id',
        'rsd_email_list',
        'rsm_description',
        'rsm_created_by',
        'rsm_created_date',
        'rsm_modified_date',
        'rsm_occurrences',
        'rsm_frequency_rld__rld_score',
        'rsm_start_date',
        'rsm_day_tag',
        'rsm_expire_date',
        'ref_name'
    )

    for each in all_filter_values:
        each['rft_values'] = ','.join(set(each['rft_values'].split(',')))
        each['rsd_email_list'] = ','.join(set(each['rsd_email_list'].split(',')))
        each['rsd_email_list'] = each['rsd_email_list'].split(',') if each['rsd_email_list'] else []
    
    all_filter_values = calculate_expiry_date(all_filter_values)


    def key_func(k):
        return str(k['rsm_id'])

    all_filter_values = sorted(all_filter_values, key=key_func)


    all_values = {}    
    for key, value in groupby(all_filter_values, key_func):            
        all_values[key] = list(value)   

    report_urls = []
    for key, each in all_values.items():
        arguments = []
        data = {}
        if each:
            report_slug = each[0]['rsf_rsu__rsu_rpt__reporturl']
        else:
            continue
        
        rolling_days = None
        rolling_days = next((item['rft_values'] for item in each if item["rft_name"] == "days_from_today"), None)

        offset_date_range = next((item['rft_values'] for item in each if item["rft_name"] == "offset_date_range"), None)
        offset_date_range = offset_date_range[0] if offset_date_range else 0

        for arg in each:
            if arg['rft_name'] == 'date_range' and arg['rft_values'] != str(customdaterange_rld_id):
                if rolling_days is not None:
                    arguments.append('rolling_date=' + str(abs(int(rolling_days))))
                    if int(rolling_days) < 0:
                        arguments.append('custom_rolling_option=Past')
                    else:
                        arguments.append('custom_rolling_option=Future')

                if offset_date_range is not None:
                    arguments.append('offset_date_range=' + str(abs(int(offset_date_range))))

                # set lng_id as 1 - to get data range data only to calculate dates based on selected date range.
                self.lng_id = 1
                start_date, end_date = get_start_date_end_date(self, rld_id = int(arg['rft_values']), rolling_days=rolling_days, offset_date_range = offset_date_range)
                arguments.append(arg['rft_name'] + '=' + arg['rft_values'])
                arguments.append('start_date=' + str(start_date))
                arguments.append('end_date=' + str(end_date))   
            else:
                # case when report has both site_ids & job_ids and job_ids is dependent on site_ids
                # if site_values not null get all/allactive jobs ids for selected site values
                site_values = check_site_jobs(each)
                filter_key = arg['rft_name']
                ref_data = False
                if arg['ref_name']:
                    filter_key = arg['ref_name']
                    ref_data = True

                if arg['rft_values'] == 'allactive' or arg['rft_values'] == 'all':      
                    display_inactive = 'True' if arg['rft_values'] == 'all' else 'False'
                    arguments.append('display_inactive_'+arg['rft_name'] + '=' + display_inactive)
                    arg['rft_values'] = get_all_filter_values(filter_key, 1, arg['rft_values'], ref_data, site_values=site_values)
                
                if type(arg['rft_values']) != str:
                    rft_values_list = list(arg['rft_values'])
                    arg['rft_values'] = ','.join(map(str,rft_values_list))
                
                arguments.append(arg['rft_name'] + '=' + arg['rft_values'])
            
            data['rsm_id'] = arg['rsm_id']
            data['rsd_emails'] = arg['rsd_email_list']
            data['rsm_description'] = arg['rsm_description']
            data['rsm_created_by'] = arg['rsm_created_by']
            data['rsm_created_date'] = arg['rsm_created_date']
            data['rsm_modified_date'] = arg['rsm_modified_date']
            data['rsm_start_date'] = arg['rsm_start_date']
            data['rsm_expire_date'] = arg['rsm_expire_date'] if 'rsm_expire_date' in arg else None
        
        report_url = report_slug+'?'+"&".join(arguments)
        data['report_url'] = report_url           
        arguments.append('apply=1')
        report_urls.append(data)    
    
    send_email(report_urls)    
    return 'Run Successfully'

    #  Add a function to set rsm_enable = False after rsm_end_rld condition satisfies for respective rsm_ids
def expired_rsm_ids():
    CURRENT_DAY = datetime.now()


    ends_date_rld_id = RefListDetail.objects.get(rld_rlh__rlh_name = 'ref_report_schedule_end', rld_option = 2).rld_id
    ends_no_of_occurance_rld_id = RefListDetail.objects.get(rld_rlh__rlh_name = 'ref_report_schedule_end', rld_option = 3).rld_id
    rsm_ids_exclude_no_occurances = ReportScheduleMaster.objects.prefetch_related(
        Prefetch('rse_report_schedule_master',
            queryset = ReportScheduleEmailStatus.objects.filter(                
                rse_is_email_sent = True)
            )
    ).annotate(
        email_sent_count = Count('rse_report_schedule_master__rse_rsm_id'),
    ).filter(
        rsm_occurrences__lte = F('email_sent_count'),        
        rsm_end_rld = ends_no_of_occurance_rld_id
    ).values_list('rsm_id', flat = True)

    rsm_ids_exclude_end_date = ReportScheduleMaster.objects.filter(
        rsm_enable=True, 
        rsm_expire_date__lte = CURRENT_DAY, 
        rsm_end_rld = ends_date_rld_id
    ).values_list('rsm_id', flat = True)
    
    return list(rsm_ids_exclude_end_date) + list(rsm_ids_exclude_no_occurances)

# get rsu_ids based on the score.
def get_rsu_ids(score):
    CURRENT_DAY = datetime.today().date()
    CURRENT_MONTH = datetime.today().month
    CURRENT_WEEK_DAY = calendar.day_name[datetime.today().weekday()]
    FIRST_DAY_OF_CURRENT_MONTH = datetime.today().date().replace(day=1)
    FIRST_DAY_OF_CURRENT_QUARTER = datetime.today().date().replace(day = 1, month = get_frequency_month(CURRENT_MONTH, 3))
    FIRST_DAY_OF_CURRENT_BIANNUAL_CYCLE = datetime.today().date().replace(day = 1, month = get_frequency_month(CURRENT_MONTH, 6))
    FIRST_DAY_OF_CURRENT_ANNUAL_CYCLE = datetime.today().date().replace(month=1, day=1)  # first day of current Annual cycle

    rsm_rsu_ids = [] 
    rsm_ids = []     

    rsm_ids_exclude_list = expired_rsm_ids()

    ltr_tag = LanguageTranslation.objects.get(ltr_lng_id = 1, ltr_tag_type = 1, ltr_text = CURRENT_WEEK_DAY).ltr_tag
    frequency_rld_id = RefListDetail.objects.get(rld_rlh__rlh_name = 'ref_report_schedule_frequency', rld_score = score).rld_id

    weekly_filter = [Q(rsm_day_tag = ltr_tag)] if score == 7 else []       

    if score == 14:
        biweekly_rsm_rsu_ids, biweekly_rsm_ids  = get_biweekly_rsu_ids(ltr_tag, frequency_rld_id, rsm_ids_exclude_list)
        return biweekly_rsm_rsu_ids, biweekly_rsm_ids
        
                    

    if CURRENT_DAY != FIRST_DAY_OF_CURRENT_MONTH and score == 30:
        return rsm_rsu_ids, rsm_ids
    if CURRENT_DAY != FIRST_DAY_OF_CURRENT_QUARTER and score == 90:
        return rsm_rsu_ids, rsm_ids
    if CURRENT_DAY != FIRST_DAY_OF_CURRENT_BIANNUAL_CYCLE and score == 182:
        return rsm_rsu_ids, rsm_ids
    if CURRENT_DAY != FIRST_DAY_OF_CURRENT_ANNUAL_CYCLE and score == 365:
        return rsm_rsu_ids, rsm_ids
    
    

    rsm_instance = ReportScheduleMaster.objects.exclude(
        rsm_id__in = rsm_ids_exclude_list,
    ).filter(
        rsm_enable = True,
        rsm_frequency_rld=  frequency_rld_id,
        rsm_start_date__lte = CURRENT_DAY,
        *weekly_filter,
    )    

    rsm_rsu_ids = rsm_instance.values_list('rsm_rsu_id', flat=True)

    rsm_ids = rsm_instance.values_list('rsm_id', flat = True)    

    return rsm_rsu_ids, rsm_ids

def get_biweekly_rsu_ids(current_week_day_ltr_tag, frequency_rld_id, rsm_ids_exclude_list):
    CURRENT_DAY = datetime.today().date()
    
    rsm_rsu_ids = []
    rsm_ids = []

    # find the records for biweeking in rsm table
    rsm_list = ReportScheduleMaster.objects.exclude(
        rsm_id__in = rsm_ids_exclude_list,
    ).filter(
        rsm_enable = True,
        rsm_frequency_rld=frequency_rld_id,
        rsm_day_tag = current_week_day_ltr_tag,
        rsm_start_date__lte = datetime.now()
    )
    for rsm in rsm_list:
        rse_status = ReportScheduleEmailStatus.objects.filter(
            rse_enable = True,
            rse_is_email_sent = True, 
            rse_rsm = rsm
        ).values(
            'rse_rsm_id', 
            'rse_log_created_date'
        ).order_by(
            'rse_id'
        ).last()
        
        if rse_status: 
            # already sent email     
            date_diff = (CURRENT_DAY - rse_status['rse_log_created_date'].date()).days + 1
            if date_diff == 14: 
                # validate the date difference is 14 days(biweekly)
                rsm_rsu_ids.append(rsm.rsm_rsu_id)
                rsm_ids.append(rsm.rsm_id)
        else:                
            rsm_rsu_ids.append(rsm.rsm_rsu_id)
            rsm_ids.append(rsm.rsm_id)                 
    
    return rsm_rsu_ids, rsm_ids

def send_email(schedule_list):
    '''
    list of rsm_ids with associated email list and report urs
    - add entry to Report Schedule Email Status table. 
    - send email to each email in the list , include report url of that rsm_id
    '''
    for each in schedule_list:
        rsm_obj = ReportScheduleMaster.objects.prefetch_related(
            'rsm_created_by_per__upr_per_id'
        ).filter(
            rsm_id = each['rsm_id'],
        ).values(
            'rsm_created_by_per__upr_per_id__upr_language',
            'rsm_created_by_per_id'
        )
        if len(rsm_obj) == 0:
            continue
        rsm_obj = rsm_obj[0]
        lng_name = rsm_obj['rsm_created_by_per__upr_per_id__upr_language']
        person_id = rsm_obj['rsm_created_by_per_id']

        lng_id = Language.objects.get(lng_name = lng_name).lng_id
        report_name = ReportScheduleMaster.objects.filter(
            rsm_id = each['rsm_id'],
            rsm_enable = True
        ).annotate(
            report_name = Subquery(
                LanguageTranslation.objects.filter(
                    ltr_lng_id = lng_id,
                    ltr_tag_type = 1,
                    ltr_tag = OuterRef('rsm_rpt__reportname')
                ).values('ltr_text')[:1]
            )
        ).values_list('report_name', flat=True)

        frequency_name = ReportScheduleMaster.objects.filter(
            rsm_id = each['rsm_id'],
            rsm_enable = True
        ).annotate(
            frequency_name = Subquery(
                LanguageTranslation.objects.filter(
                    ltr_lng_id = lng_id,
                    ltr_tag_type = OuterRef('rsm_frequency_rld__rld_tag_type'),
                    ltr_tag = OuterRef('rsm_frequency_rld__rld_name')
                ).values('ltr_text')[:1]
            )
        ).values_list('frequency_name', flat=True)
        each['report_name'] = report_name[0] if report_name else None
        each['frequency_name'] = frequency_name[0] if frequency_name else None

        each['report_url'] = each['report_url'] + '&lang=' + str(lng_id)

        ltr_ids = [4257, 8468, 9023,9024,9030, 9031, 143, 1305, 1262, 8439, 3606, 3607, 3608, 1298, 1952 ]
        get_trans = get_translation(ltr_ids, lng_id)                                                                                                     

        email(report_data= each, get_trans=get_trans, person_id=person_id)

        # add records to ReportScheduleEmailStatus table
        log_email_status(each['rsm_id'])
        

def check_email_sent_already(all_rsm_ids):
    # check in ReportScheduleEmailStatus table, if emails for that rsm_id are already sent today
    # if yes, then don't send email again
    # if no, then send email

    rse_rsm_ids = ReportScheduleEmailStatus.objects.annotate(
        email_log_date = Cast('rse_log_created_date', DateField() )
    ).filter(
        rse_rsm_id__in = all_rsm_ids,
        email_log_date = datetime.today().date()
    ).values_list('rse_rsm_id', flat=True)  


    if sorted(list(set(rse_rsm_ids))) == sorted(all_rsm_ids):
        return True
    return False
    
def email(report_data, get_trans, person_id):
    # Saving report filters in report_filter_url table to get the shortened URL
    url_args = None
    short_url_param = None
    if report_data['report_url']:
        url_args = report_data['report_url'].split("?")
        if len(url_args) > 0:
            report_slug = url_args[0]
            report_filter_params = url_args[1]
            # parse is a in built python lib to convert URL path into a Dictonary
            report_filter_params = dict(parse.parse_qs(parse.urlsplit(report_filter_params).path))
            report_filter_dict = dict()
            report_filter_dict = {each: report_filter_params[each][0] for each in report_filter_params.keys()}
            code = save_report_filters(report_filter_dict, report_slug, person_id)
            short_url_param = f"{report_slug}?report_filter_unique_code={code}"
        else:
            raise Exception("The Report URL does not have arguments")
    else:
        raise AttributeError("The Report URL does not exist to be included in Email")
    
    email_dict = {'report_link': f"{config('EMAIL_REPORT_URL')}{short_url_param}",
            'domain_app': config('FRONTEND_HOST_NAME'),
            'translate': get_trans,
            'report_data': report_data
            }

    subject = 'Sofvie ' + get_trans[9023] + ' ' + report_data['report_name']
    from_email = settings.DEFAULT_FROM_EMAIL_ADMIN
    email_list = report_data['rsd_emails']


    text_content = 'This is an important message.'

    html_content = get_template("scheduledReportEmail.html").render(email_dict)
    msg = EmailMultiAlternatives(subject, text_content, from_email,email_list)

    msg.attach_alternative(html_content, "text/html")
    msg.send()    

def get_filter_values(rsu_ids= None):   

    rsu_filter = [Q(rsf_rsu__rsu_id__in=rsu_ids)] if rsu_ids else []     

    filter_values = ReportSavedFilterType.objects.prefetch_related(
        'rsv_report_saved_filter_type',
        'rsf_rft__rfm_report_filter_type',
    ).filter(
        *rsu_filter,
        rsf_enable = True,
        rsv_report_saved_filter_type__rsv_enable = True,
        rsf_rsu__rsu_rpt_id = F('rsf_rft__rfm_report_filter_type__rfm_rpt_id'),
    ).annotate(
        rft_values = GroupConcat('rsv_report_saved_filter_type__rsv_value', ''),
        rft_id = F('rsf_rft__rft_id'),
        rft_name = F('rsf_rft__rft_name'),         
        ref_name = F('rsf_rft__rft_rlh__rlh_name')    
    ).values()

    return filter_values


def log_email_status(rsm_id):

    ReportScheduleEmailStatus.objects.create(
        rse_rsm_id = rsm_id,
        rse_is_email_sent = True,
        rse_log_created_by_per_id = 1
    )
