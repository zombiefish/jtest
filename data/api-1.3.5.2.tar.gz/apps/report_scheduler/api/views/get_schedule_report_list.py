from datetime import datetime, timedelta
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from apps.person.models import Person
from django.db.models import Q, F, Subquery, OuterRef, Prefetch, Value, CharField
from django.db.models.functions import Concat

from apps.common_utils.views.validate_permission import RolePermission
from apps.common_utils.views.custom_aggregate_function import GroupConcat
from apps.language.models import Language, LanguageTranslation
from apps.report_scheduler.models import ReportScheduleMaster
from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile

from apps.report_scheduler.api.views.common_functions import get_filter_report_url

class GetScheduleReportList(APIView):
    permission_classes = [IsAuthenticated, SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def get(self, request):

        person = self.request.user.user_per_id
        language = UserProfile.objects.get(upr_per=person).upr_language
        lng_id = Language.objects.get(lng_name=language).lng_id
        
        try:
            get_schedule_reports = get_schedule_report(self, person)

            get_schedule_reports = get_schedule_reports.annotate(
                rsm_report_name = Subquery(
                        LanguageTranslation.objects.filter(ltr_tag=OuterRef('rsm_rpt__reportname'),ltr_tag_type=1, ltr_lng = lng_id, ltr_enable=1).values('ltr_text')[:1]
                    ),
                rsm_created_by_name = Concat(
                    "rsm_created_by_per__per_last_name", Value(" "),
                    "rsm_created_by_per__per_first_name", Value(" "),
                    "rsm_created_by_per__per_middle_name", output_field = CharField()
                    ),
                rsm_modified_by_name = Concat(
                    "rsm_modified_by_per__per_last_name", Value(" "),
                    "rsm_modified_by_per__per_first_name", Value(" "),
                    "rsm_modified_by_per__per_middle_name", output_field = CharField()
                    ),
                rsm_report_url = F("rsm_rpt__reporturl"),
                rsm_report_id = F("rsm_rpt__id"),
                rsm_rsu_id = F("rsm_rsu__rsu_id"),
            ).values(
                'rsm_id',
                'rsm_report_name',
                'rsm_description',
                'rsm_frequency_rld',
                'rsm_day_tag',
                'rsm_end_rld_id',
                'rsm_start_date',
                'rsm_expire_date',
                'rsm_created_date',
                'rsm_created_by_name',
                'rsm_modified_date',
                'rsm_modified_by_name',
                'rsm_distribution',
                'rsm_occurrences',
                'rsm_frequency_rld__rld_score',
                'rsm_report_url',
                'rsm_report_id',
                'rsm_rsu_id'
            ).order_by('-rsm_created_date')

            get_schedule_reports = calculate_expiry_date(get_schedule_reports)

            for report in get_schedule_reports:
                report['rsm_report_url_arguments'] = get_filter_report_url(self, person=person, rsu_id=report['rsm_rsu_id'], report_id=report['rsm_report_id'], lng_id=lng_id)
                del report['rsm_report_id']
                del report['rsm_rsu_id']
            

            return Response(get_schedule_reports, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)       


def get_schedule_report(self, person, rsm_id = None):

    rsm_id_filter = [Q(rsm_id = rsm_id)] if rsm_id else [] 

    get_schedule_reports = ReportScheduleMaster.objects.prefetch_related(
                'rsd_report_schedule_master'
            ).select_related(
                'rsm_rsu'
            ).filter(
                *rsm_id_filter,
                rsm_per = person,
                rsm_enable = True,
                rsm_created_by_per = person,   
                rsd_report_schedule_master__rsd_enable = True,    
            ).annotate(
                rsm_distribution = GroupConcat('rsd_report_schedule_master__rsd_email', '')
            ).values()

    return get_schedule_reports

def calculate_expiry_date(get_schedule_reports):

    WEEK_NUMBERS = {
        'MONDAY' :0,
        'TUESDAY' :1,
        'WEDNESDAY':2,
        'THURSDAY':3,
        'FRIDAY':4,
        'SATURDAY':5,
        'SUNDAY':6
    }
    
    for report in get_schedule_reports:
        if report['rsm_occurrences'] is not None:
            occurrences = report['rsm_occurrences']
            frequency = report['rsm_frequency_rld__rld_score']
            start_date = report['rsm_start_date']
            
            start_month = start_date.date().month
            start_year = start_date.date().year

            if frequency == 1:
                report['rsm_expire_date'] = start_date + timedelta(days = occurrences*frequency)
            
            elif frequency == 7:

                week_day = (LanguageTranslation.objects.get(
                    ltr_tag = report['rsm_day_tag'],
                    ltr_tag_type = 1,
                    ltr_lng_id = 1,
                    ltr_enable = True
                ).ltr_text).upper()

                actual_start_date = next_weekday(start_date, WEEK_NUMBERS[week_day])

                report['rsm_expire_date'] = actual_start_date + timedelta(days=(7*occurrences)-5)
            
            elif frequency == 14:
                week_day = (LanguageTranslation.objects.get(
                    ltr_tag = report['rsm_day_tag'],
                    ltr_tag_type = 1,
                    ltr_lng_id = 1,
                    ltr_enable = True
                ).ltr_text).upper()

                actual_start_date = next_weekday(start_date, WEEK_NUMBERS[week_day])

                report['rsm_expire_date'] = actual_start_date + timedelta(days=(7*2*occurrences)-13)

            
            elif frequency == 30:
                # read month from start_date and add occurrences to month and update rsm_expire_date

                temp_months = start_month + occurrences
                new_year = start_year + int(temp_months/12)
                new_month = int(temp_months%12)

                report['rsm_expire_date'] = start_date.replace(year = new_year, month = new_month)

            elif frequency == 90:

                temp_months = start_month + (occurrences*3)
                new_year = start_year + int(temp_months/12)
                new_month = int(temp_months%12)

                report['rsm_expire_date'] = start_date.replace(year = new_year, month = new_month)
            
            elif frequency == 182:

                temp_months = start_month + (occurrences*6)
                new_year = start_year + int(temp_months/12)
                new_month = int(temp_months%12)

                report['rsm_expire_date'] = start_date.replace(year = new_year, month = new_month)
            
            elif frequency == 365:

                new_year = start_year + occurrences

                report['rsm_expire_date'] = start_date.replace(year = new_year)

    return get_schedule_reports

def next_weekday(d, weekday):
    days_ahead = weekday - d.weekday()
    if days_ahead <= 0: # Target day already happened this week
        days_ahead += 7
    return d + timedelta(days_ahead)