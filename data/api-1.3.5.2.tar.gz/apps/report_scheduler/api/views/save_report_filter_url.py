from rest_framework.response import Response
from rest_framework.views import APIView
from apps.sofvie_user_authorization.api.permissions import SofviePermission
import uuid
from django.db import transaction
from apps.report_scheduler.models import ReportFilterUrl

def save_report_filters(payload_data, report_slug, person_id):
    code = None
    already_exists = ReportFilterUrl.objects.filter(
        rfu_report_filter = payload_data
    )
    if already_exists:
        code = already_exists.values_list("rfu_report_unique_code", flat=True)[0]
    else:
        unique_code = str(uuid.uuid4())
        save_filter_values = ReportFilterUrl.objects.create(
            rfu_report_slug = report_slug,
            rfu_report_filter = payload_data,
            rfu_report_unique_code = unique_code,
            rfu_created_by_per_id = person_id
        )
        code = unique_code
    return code

class SaveFilterValuesForUrl(APIView):
    permission_classes = [SofviePermission]

    @transaction.atomic
    def post(self, request):
        person_id = request.user.user_per_id_id
        payload_data = request.data
        report_slug = payload_data.pop('report_slug', None)
        code = save_report_filters(payload_data, report_slug, person_id)
        return Response({"rfu_unique_code": code}, status=200)