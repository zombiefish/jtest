from django.urls import include, path
from apps.report_scheduler.api.views.check_daily_scheduled_reports import  GenerateScheduledReports, GetReportSchedulerRunTimeSettings
from apps.report_scheduler.api.views.get_date_range import GetDateRange
from apps.report_scheduler.api.views.get_report_filters import GetReportFilters
from apps.report_scheduler.api.views.add_scheduled_report import AddScheduledReport
from apps.report_scheduler.api.views.get_schedule_report_list import GetScheduleReportList
from apps.report_scheduler.api.views.get_single_schedule_report import GetSingleScheduleReport
from apps.report_scheduler.api.views.archive_schedule_report import ArchiveScheduleReport
from apps.report_scheduler.api.views.get_user_saved_report_filters import GetUserSavedReportFilters
from apps.report_scheduler.api.views.update_scheduled_report import UpdateScheduledReport
from apps.report_scheduler.api.views.get_single_saved_report_filter import GetSingleSavedReportFilter
from apps.report_scheduler.api.views.save_report_filter_url import SaveFilterValuesForUrl

urlpatterns = [
    path('get-report-filters/', GetReportFilters.as_view()),
    path('add-scheduled-report/', AddScheduledReport.as_view()),
    path('get-scheduled-report-list/', GetScheduleReportList.as_view()),
    path('get-single-scheduled-report/', GetSingleScheduleReport.as_view()),
    path('archive-scheduled-report/', ArchiveScheduleReport.as_view()),
    path('get-user-saved-report-filters/', GetUserSavedReportFilters.as_view()),
    path('update-scheduled-report/', UpdateScheduledReport.as_view()),
    path('get-single-saved-report-filter/', GetSingleSavedReportFilter.as_view()),
    path('get-report-scheduler-run-time-settings/', GetReportSchedulerRunTimeSettings.as_view()),
    path('E03EDE6657278C27484BA90DA05CAF95DB64E8ADE6AAA9C0438C64092D3A0E12/', GenerateScheduledReports.as_view()),
    path('save_filter_values_for_url/',SaveFilterValuesForUrl.as_view()),
    path('get-date-range/',GetDateRange.as_view()),
]