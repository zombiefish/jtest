from django.apps import AppConfig
import os

class ReportSchedulerConfig(AppConfig):
    name = 'apps.report_scheduler'
