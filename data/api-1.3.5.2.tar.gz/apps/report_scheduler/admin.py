from django.contrib import admin

from .models import (
ReportFilterType,
ReportFilterTypeMapping,
ReportFilterParameter,
ReportSavedUserFilter,
ReportScheduleMaster,
ReportScheduleDistribution,
ReportSavedFilterType,
ReportSavedFilterValue
                     )

# Register your models here.

admin.site.register(ReportFilterType)
admin.site.register(ReportFilterTypeMapping)
admin.site.register(ReportFilterParameter)
admin.site.register(ReportSavedUserFilter)
admin.site.register(ReportScheduleMaster)
admin.site.register(ReportScheduleDistribution)
admin.site.register(ReportSavedFilterType)
admin.site.register(ReportSavedFilterValue)



