from django.urls import path
from apps.listmanifest import views

urlpatterns = [
    path('get-list-manifest-data-by-condition/', views.GetListManifestDataByCondition.as_view()),
    path('get-active-list-manifest-data-by-condition/', views.GetActiveListManifestDataByCondition.as_view())
]
