from apps.sofvie_user_authorization.api.permissions import SofviePermission
from apps.user_settings_profile.models import UserProfile
from django.shortcuts import render
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status, viewsets, generics
from rest_framework.views import APIView
from django.db import connection
from django.core import serializers


# Create your views here.
from apps.incident_management.api.utlity_function import dictfetchall


class GetListManifestDataByCondition(APIView):
    permission_classes = [SofviePermission]
    """ Response for the All  """
    def post(self, request):
        conditionParam = request.data['validatorStr']
        lang = request.data['language']
        person = self.request.user.user_per_id
        # lang = UserProfile.objects.get(upr_per = person).upr_language
        with connection.cursor() as cursor:
            cursor.execute("call get_ref_list_by_name(%s, %s)", ([conditionParam], [lang]))
            row = dictfetchall(cursor)
        for each in row:
            each['rld_name'] = each['rld_name'].replace('&quot;', '"')
        return Response(row)

class GetActiveListManifestDataByCondition(APIView):
    permission_classes = [SofviePermission]
    """ Response for the All  """
    def post(self, request):
        lang = request.data['language']
        conditionParam = request.data['validatorStr']     
        with connection.cursor() as cursor:
            # cursor.execute("call get_list_manifest_data_by_condition(%s)", ([conditionParam]))             
            cursor.execute("call get_active_ref_list_by_name(%s, %s)", ([conditionParam], [lang]))             
            row = dictfetchall(cursor)
        for each in row:
            each['rld_name'] = each['rld_name'].replace('&quot;', '"')
        return Response(row) 


