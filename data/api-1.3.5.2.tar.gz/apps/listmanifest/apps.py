from django.apps import AppConfig


class ListmanifestConfig(AppConfig):
    name = 'apps.listmanifest'
