from django.apps import AppConfig


class FormManagementConfig(AppConfig):
    name = 'apps.form_management'
