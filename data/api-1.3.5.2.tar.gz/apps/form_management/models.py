from django.db import models
from django.db.models import (
    Model,
    AutoField,
    DateTimeField,
    ForeignKey,    
    BooleanField,
)
from apps.common_utils.views.sofvieModelFields import (
    SofvieCharField,
    SofvieTextField,
    SofvieIntegerField
)
from apps.person.models import Person
from apps.hazard_action.models import Formfielddescription

class FormFieldVisibility(Model):
    ffv_id = AutoField(primary_key=True)
    ffv_ffd = ForeignKey(Formfielddescription, on_delete=models.DO_NOTHING, related_name='ffv_ffd')
    ffv_is_visible = BooleanField(default=True)
    ffv_created_date = DateTimeField(auto_now_add=True)
    ffv_created_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='ffv_createdby_per')
    ffv_modified_date = DateTimeField(blank=True, null=True)
    ffv_modified_by_per = ForeignKey(Person, on_delete=models.DO_NOTHING, related_name='ffv_modifiedby_per', blank=True, null=True)
    ffv_enable = BooleanField(default=True)
    ffv_enote = SofvieCharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'form_field_visibility'
