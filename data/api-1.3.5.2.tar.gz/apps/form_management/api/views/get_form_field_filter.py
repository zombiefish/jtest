from pickle import NONE
from rest_framework.views import APIView
from rest_framework.response import Response

from django.db.models import Q, F, Subquery, OuterRef, Count

from apps.common_utils.views.validate_permission import RolePermission
from apps.sofvie_user_authorization.api.permissions import SofviePermission

from apps.form_management.models import FormFieldVisibility

class GetFormFieldFilter(APIView):
    permission_classes = [SofviePermission]
    permission_attrs = (RolePermission.BasicAccess.value,)

    def post(self, request):

        try:
            form_id = self.request.data['form_id']
        except:
            form_id = None
            pass

        if not form_id:
            form_ids = FormFieldVisibility.objects.filter(ffv_enable=True).annotate(
                formId = F("ffv_ffd__formdescriptionid__formid")
            ).values_list('formId', flat=True).distinct()
        else:
            form_ids = [form_id]

        response = {}

        form_fields = FormFieldVisibility.objects.filter(ffv_enable=True, ffv_ffd__formdescriptionid__formid__in=form_ids).annotate(
            formId = F("ffv_ffd__formdescriptionid__formid"),
            formFieldDescriptionID = F("ffv_ffd"),
            fieldKey = F("ffv_ffd__fieldkey"),
            fieldName = F("ffv_ffd__fieldname"),
            fieldType = F("ffv_ffd__fieldtype"),
            sectionName = F("ffv_ffd__sectionname"),
        ).values(
            'formId',
            'ffv_is_visible',
            'formFieldDescriptionID',
            'fieldKey',
            'fieldName',
            'fieldType',
            'sectionName',
        )

        for field in form_fields:
            field_form_id = field['formId']

            if field_form_id not in response:
                response[field_form_id] = []

            del field['formId']
            response[field_form_id].append(field)

        if form_id:
            response = response[form_id]

        return Response(response)