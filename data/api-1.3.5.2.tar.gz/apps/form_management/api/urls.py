from django.urls import path

from apps.form_management.api.views.get_form_field_filter import GetFormFieldFilter

urlpatterns = [
    path('get-form-field-filter/', GetFormFieldFilter.as_view()),
]