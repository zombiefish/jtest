let strongPassword = false
let viewPassword = false

function showWiget(elementEndfix = "") {
  //Show/hide widget
  if(document.getElementById("password-policy-widget" + elementEndfix).classList.contains("d-none")) {
    document.getElementById("password-policy-widget" + elementEndfix).classList.remove("d-none")
    strongPassword = false
    viewPassword = false
  }
}




function passwordInputChanged(passInput, confirmInput, elementEndfix = "") {
  let strengthObj = checkPasswordStrength(passInput.value)
  passInput.type = viewPassword ? "text" : "password"
  strongPassword = strengthObj.strength >= 4;

  //Remove non-ASCII chars
  passInput.value = passInput.value.replace(/[^\x00-\x7F]/g, "")

  //Display strength text/bar
  let strengthText = document.getElementById("pass-strength-text" + elementEndfix)
  let strengthBar = document.getElementById("pass-strength-bar" + elementEndfix)
  let lockIcons = document.querySelectorAll('.fa-lock-open, .fa-lock')
  
  strengthText.classList = ""
  strengthBar.classList = ""
  strengthText.innerHTML = ""
  for(let l = 0; l < lockIcons.length; l++) {
    lockIcons[l].classList.remove("fa-lock")
    lockIcons[l].classList.add("fa-lock-open")
  }

  switch(strengthObj.strength) {
    case 1:      
      strengthText.classList.add("very-weak-color")
      strengthBar.classList.add("very-very-weak-color")
      strengthText.innerHTML = "Very Weak" //i18next.t('9057') //Very Weak
      break;
    case 2:
      strengthText.classList.add("very-weak-color")
      strengthBar.classList.add("very-weak-color")
      strengthText.innerHTML = "Very Weak" //i18next.t('9057') //Very Weak
      break;
    case 3:
      strengthText.classList.add("weak-color")
      strengthBar.classList.add("weak-color")
      strengthText.innerHTML = "Weak" // i18next.t('9058') //Weak
      break;
    case 4:
      strengthText.classList.add("strong-color")
      strengthBar.classList.add("strong-color")
      strengthText.innerHTML = "Strong" //i18next.t('9059') //Strong
      for(let l = 0; l < lockIcons.length; l++) {
        lockIcons[l].classList.remove("fa-lock-open")
        lockIcons[l].classList.add("fa-lock")
      }
      break;
    case 5:
      strengthText.classList.add("very-strong-color")
      strengthBar.classList.add("very-strong-color")
      strengthText.innerHTML = "Very Strong" //i18next.t('9060') //Very Strong
      for(let l = 0; l < lockIcons.length; l++) {
        lockIcons[l].classList.remove("fa-lock-open")
        lockIcons[l].classList.add("fa-lock")
      }
      break;      
  }

  //Reset criteria checks
  let checkIcons = [document.getElementById("check-icon-0" + elementEndfix),document.getElementById("check-icon-1" + elementEndfix),document.getElementById("check-icon-2" + elementEndfix),document.getElementById("check-icon-3" + elementEndfix)]
  for(let i = 0; i < checkIcons.length; i++) {
    checkIcons[i].classList.remove("fa-check")
    checkIcons[i].classList.add("fa-times")

    checkIcons[i].classList.remove("fa-blue")
    if(strengthObj.strength > 0) {
      checkIcons[i].classList.remove("fa-grey")
      checkIcons[i].classList.add("fa-red")
    }
    else {      
      checkIcons[i].classList.remove("fa-red")
      checkIcons[i].classList.add("fa-grey")
    }
  }

  //Display criteria checks
  if(strengthObj.criteria >= 16) { // 12 Chars
    checkIcons[0].classList.remove("fa-times")
    checkIcons[0].classList.add("fa-check")
    checkIcons[0].classList.remove("fa-red")
    checkIcons[0].classList.add("fa-blue")
    strengthObj.criteria -= 16;
  }
  if(strengthObj.criteria >= 8) { // 8 Chars
    checkIcons[0].classList.remove("fa-times")
    checkIcons[0].classList.add("fa-check")
    checkIcons[0].classList.remove("fa-red")
    checkIcons[0].classList.add("fa-blue")
    strengthObj.criteria -= 8;
  }
  if(strengthObj.criteria >= 4) { // 1 Lower & 1 Upper
    checkIcons[1].classList.remove("fa-times")
    checkIcons[1].classList.add("fa-check")
    checkIcons[1].classList.remove("fa-red")
    checkIcons[1].classList.add("fa-blue")
    strengthObj.criteria -= 4;
  }
  if(strengthObj.criteria >= 2) { // 1 Special
    checkIcons[3].classList.remove("fa-times")
    checkIcons[3].classList.add("fa-check")
    checkIcons[3].classList.remove("fa-red")
    checkIcons[3].classList.add("fa-blue")
    strengthObj.criteria -= 2;
  }
  if(strengthObj.criteria >= 1) { // 1 Number
    checkIcons[2].classList.remove("fa-times")
    checkIcons[2].classList.add("fa-check")
    checkIcons[2].classList.remove("fa-red")
    checkIcons[2].classList.add("fa-blue")
    strengthObj.criteria -= 1;
  }

  checkPasswordMatch(passInput, document.getElementById(confirmInput), elementEndfix)
}

function confirmPasswordInputChanged(passInput, confirmInput, elementEndfix = "") {
  confirmInput.type = viewPassword ? "text" : "password"

  //Remove non-ASCII chars
  confirmInput.value = confirmInput.value.replace(/[^\x00-\x7F]/g, "")

  checkPasswordMatch(document.getElementById(passInput), confirmInput, elementEndfix)
}

function checkPasswordMatch(password, confirmInput, elementEndfix = "")
{
  let matchText = document.getElementById("pass-match-text" + elementEndfix)
  if(document.getElementById("password-confirm").value == "") {
    matchText.innerHTML = ""
  }
  else if(document.getElementById("password").value != document.getElementById("password-confirm").value) {
    matchText.innerHTML = "Password Doesn't Match" //i18next.t('9065') //Password Doesn't Match
    if(matchText.classList.contains("match-color")) {
      matchText.classList.remove("match-color")
      matchText.classList.add("no-match-color")
    }
  }
  else {
    matchText.innerHTML = "Passwords Match" //i18next.t('9066') //Passwords Match
    if(matchText.classList.contains("no-match-color")) {
      matchText.classList.remove("no-match-color")
      matchText.classList.add("match-color")
    }
  }
}

function toggleViewPassword (passInput, confirmInput, elementEndfix = "") {
  viewPassword = !viewPassword

  passInput = document.getElementById(passInput)
  passInput.type = viewPassword ? "text" : "password"
  if(confirmInput != null) {
    confirmInput = document.getElementById(confirmInput)
    confirmInput.type = viewPassword ? "text" : "password"
  }
    
  let viewPassText = document.getElementById("view-pass-text" + elementEndfix)
  let viewIcon = document.getElementById("view-pass-icon" + elementEndfix)
  if(viewPassword == true) {
    viewPassText.innerHTML = "" //i18next.t('9081') //Hide Password
    viewIcon.classList.remove("fa-eye")
    viewIcon.classList.add("fa-eye-slash")
  }
  else {
    viewPassText.innerHTML = "" //i18next.t('9069') //View Password
    viewIcon.classList.remove("fa-eye-slash")
    viewIcon.classList.add("fa-eye")
  }
}

function checkPasswordStrength(pw) {
    let ideal = checkLengthIdeal(pw)
    let len = checkLength(pw)
    let lower = containsLowerCase(pw)
    let upper = containsUpperCase(pw)
    let num = containsNumeric(pw)
    let special = containsSpecialCharacters(pw)
    let strength = 0
    let criteriaMet = 0
    let criteriaMetCount = 0
  
    if (ideal) {
      criteriaMet += 16
    } 
    if (len) {
      criteriaMet +=8
      criteriaMetCount +=1
    }
  
    if (lower && upper) {
      criteriaMet +=4
      criteriaMetCount +=1
    }
  
    if (num) {
      criteriaMet +=1
      criteriaMetCount +=1
    }

    if (special) {
      criteriaMet +=2
      criteriaMetCount +=1
    }
  
    if(ideal && lower && upper && num && special){ // 4 critera met and ideal
        strength = 5
    } else if(len  && lower && upper && num && special){ // 4 critera met
        strength = 4
    } else if(criteriaMetCount >= 2){ // 2-3 criteria met
        strength = 3
    } else if (criteriaMetCount == 1){ // 1 critera met
        strength = 2
    } else { // No critera met
        strength = 1
    }

    return {"strength":strength,"criteria":criteriaMet}
}
  
function checkLengthIdeal(pw) {
    if (pw.length >= 12) {
        return true
    }
    return false
}

function checkLength(pw) {
    if (pw.length >= 8) {
        return true
    }
    return false
}

function containsLowerCase(pw) {
    for (let i = 0; i < pw.length; i++) {
        if (pw.charCodeAt(i) >= 97 && pw.charCodeAt(i) <= 122) {
            return true
        }
    }
    return false
}

function containsUpperCase(pw) {
    for (let i = 0; i < pw.length; i++) {
        if (pw.charCodeAt(i) >= 65 && pw.charCodeAt(i) <= 90) {
            return true
        }
    }
    return false
}

function containsNumeric(pw) {
    for (let i = 0; i < pw.length; i++) {
        if (pw.charCodeAt(i) >= 48 && pw.charCodeAt(i) <= 57) {
            return true
        }
    }
    return false
}

function containsSpecialCharacters(pw) {

    // Allowable special characters.  !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~
    const chars = [ "!",`"`,"#","$","%","&","'","(",")","*","+",",","-",".","/",":",";","<","=",">","?","@","[","\",","]","^","_","`","{","|","}","~"]

    for (let i = 0; i < chars.length; i++) {
        if (pw.includes(chars[i])) {
        return true
        }
    }
    return false
}
