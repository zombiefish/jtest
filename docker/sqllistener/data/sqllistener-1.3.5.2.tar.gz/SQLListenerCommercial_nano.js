"use strict";
/*
CouchDB 2 SQL Listener
Language: NodeJS/Server

Author: Robert Rivest
Creation Date: 20200324
Created By: Robert Rivest
Last Modified Date: 20200324 (Update LMD in code below)
Last Modified By: Robert Rivest
External Dependencies:	

Purpose:

Sofvie has the requirements to fill web based forms offline, whether underground, or outside of normal wifi range,
then synchronize the data with SQL server as soon as connection is established.

This is handle by Web Browser(local storage via PouchDB) > (Wifi) > CouchDB > (this code) > SQL Server.

The web application (forms) utilize PWA (service workers) to supply the web application while offline.
Form submissions are stored locally in the browser via PouchDB (https://pouchdb.com/). PouchDB will automatically
synchronize data with CouchDB (https://couchdb.apache.org/) on a remote server when an Internet connection 
becomes available.

Sofvie has the requirement of storing this submitted data into a MS SQL Server dataset.  We must copy the submitted
data to SQL Server.

CouchDB 2 SQL Listener runs on a server (which may be remote from either/both CouchDB/SQL Server) which listens for 
synchronization packets over HTTP from CouchDB (_changes log).  When recieved, it parses the packet, and dispatches 
them to the specified destination.

Replication occurs in one direction only (though both directions are possible). 

Data replicated to CouchDB lives indefinitely for historical purposes.

// RMR:20190729 - Moved SQL error handler even to global scope and eliminated function level scoping.
// RMR:20190730 - Added RecognitionTypeGiven column to SubmissionPositiveRecognition (insertPositiveID's)
// RMR:20190801 - columns in HAP were being saved with the concatenated score value.  Remove score value and save.
// RMR:20190807 - Write attachment to S2D table to stop the sync downloader from squawking.
// RMR:20190821 - Add ability to save preop form submissions with attachments.
// RMR:20190826 - Replace delimiter for Email distribution from '|' to a comma.
// RMR:20190829 - Properly handle PreOp Attachments
// RMR:20190903 - Process MSWordTemplate only if recipients are present
// RMR:20190916 - Added parseDistribution Function to separate and create seprate entries in the explode table.
// RMR:10190918 - Added code so pictures will be in the Explode Table.
// RMR:20190920 - Added Code to have Preop add Report Distribution to the  Explode table and to add an Entry to the Submission Details Table.
// RMR:20190923 - modified code so that Preop will accept HAP and PID subforms with images.
// RMR:20191004 - Roll back all code 20190904 version.
// RMR:20191004 - Replace pipe symbols in all multiselect types with commas
// RMR:20191004 - Add HAP/PID processing to PreOp form submits
// RMR:20191007 - Remove calls to DOCX distribution list (Deprecated).
// RMR:20191007 - Write multiselects to multiple 'explode' rows cleanly (This was only an issue for reporting. Appears on seperate lines, not on one line comma delimited - change results in multiple keys for the same record).
// RMR:20191009 - Fix issue with not saving HAP images when both HAP and PID images are submitted
// RMR:20191009 - Fix issue with images duplicated when multiple PID's are submitted.
// RMR:20191010 - Comment out template generation (Deprecated notifications), emailing, and includes of email libraries.
// RMR:20191010 - Remove some logging. Restucture Explode to save NULL's in empty Distribution list.
// RMR:20191021 - Commented out sql.on event handler in insertPositiveID that could cause event emitter memory leaks
// RMR:20191021 - Commented out event, and event.emitter declarations.
// RMR:20191022 - Commented out unneeded logging. Fixed scoping issue when calling HAP from PreOp.
// RMR:20191119 - Properly handle timezones in date from form submissions 
// RMR:20191129 - Add HeaderDate to Submission Header.
// RMR:20191211 - Remove raw logging of image data to log
// RMR:20191212 - Handle embedded single quote in recieved JSON packet (Zombie fix?)
// RMR:20200302 - v 0.8.0 - New SQL Listener to work with Mariadb instead of SQL Server
// RMR:20200508 - v 0.8.1 - Changed SQL Listener to work with SSL
// RMR:20200508 - v 0.8.2 - Corrected issue with action by when date then blank would cause action not so to save
// RMR:20200512 - v 0.8.3 - Corrected issue with Hazard Action Follow Up is still in report when not checked on form SOF-2567
// RMR:20200514 - v 0.8.4 - Added functionality to email submission after being saved to Maria DB
// RMR:20200514 - v 0.8.5 - Corrected Issue with Child form Pictures being duplicated in maria DB entries
// RMR:20200520 - v 0.8.6 - Modified Email Template to Have the proper look and feel
// RMR:20200618 - v 0.8.7 - Added Ability to add and close general actions with attachments.  NEW SUBFORM
// RMR:20200618 - v 0.8.7 - Added Ability to Acknowlege Documents to Review  NEW Feature
// RMR:20200625 - v 0.8.8 - Changed Email url to accept a new parameter for Template location for Pentaho
// RMR:20200629 - v 0.8.9 - Changed SQL Statement for Adding followup Photos when Closing Hazard Action Items to Point to SobmissionHAPAttachments Instead of ActionAttachments
// RMR:20200708 - v 0.8.10 - Modified Code to remove adding entries to the _dynamic_attachments table with is now gone
// RMR:20200711 - v 0.8.11 - Modified Code for Email URL to output a pdf instead of HTML
// RMR:20200811 - v 0.8.11 - Modified Location of log file
// RMR:20200814 - v 0.8.12 - New SQLListener using NANO. New way of listening couch
// RMR:20200814 - v 0.8.13 - Added Config setting to set DB name on Connection for Cloud
// RMR:20200827 - v 0.8.14 - Clean up code, logging and added a resume feed logging to track the feed also corrected issue when getting an IP Promose error that was
// 							 causing the program to cease resuming the feed  Also added Feature where if there is a critical error it will e-mail the help desk
// GR:20200828  - v 0.8.15 - Start the SQLListener from the last successful record inserted into the MariaDB
// RMR:20200814 - v 0.8.16 - Added Error Handling for Poll REcords Function
// RMR:20200814 - v 1.0.0 - Sofvie 1.0 Released and Corrected issue when Submitting General Actions
// RMR:20200814 - v 1.0.1 - Changed the position where we save the Sequence number to the end of the completed transaction this way if there are SQL errors we can restore data
// RMR:20200922 - v 1.0.2 - Modified Function insertSubmissionHAPs in add a submitted by field to be saved in SQL also changed name of SP to put_hazard_action  from putHAP
// RMR:20200925 - v 1.0.3 - Corrected issue when inserting data into the header with an apostrophe
// RMR:20200925 - v 1.0.4 - Corrected issue when inserting data into any table with an apostrophe
// RMR:20200925 - v 1.0.5 - Increased commection Timeout to the Maria DB Connection 
// RMR:20200925 - v 1.0.6 - Reset of Pools and connection options
// RMR:20201021 - v 1.0.7 - Added Picture timestamp - New SP's Created to accomodate
// RMR:20201116 - v 1.0.8 - Added Close of connection on PutHapUpdate
// RMR:20210112 - v 1.0.9 - Added Function and Chaged engine to be able to process Checklist Submissions 
							Also changed picture upload to only create files if the file size is not 0
							Also Added a PROTOCOL Environment variable to switch from http to https  to connect to Couch
// RMR"20210517 - v1.0.10 - Added code to use moment to control time on transactions and also changed so that all forms will be timestamped
//                          requires that the fields in SQL be changed to datetime instead of just date
// RMR:20210618 - v1.0.11 - Added Language Support for Submission Emails
// RMR:20210729 - v1.0.12 - For native ECMAScript Module (ESM) usage in Node.js only named exports are exposed, there is no more default export. 
                            changed const uuidv4 = require('uuid/v4');  to const { v4: uuidv4 } = require('uuid');
// RRH:20210811 - v1.0.13 - Changed the report url to sofvieBi URL
// RMR:20210823 - v1.0.14 - removed timezone offsets for General Actions and Hazard Actions
// RMR:20210823 - v1.0.15 - added code to handle signature timestamps
// RMR:20211006 - v1.0.16 - added function to handle comments on pictures and signatures and timestamps on signatures
                          - correct Preop insert to remove issues with Timeout on connections
// RMR:20211230 - v1.0.17 - corrected issue when submitting a Hazard Action without further action 
// RMR:20211230 - v1.0.18 - corrected issue when submitting a Hazard Action without an immediate action 
//              - v1.0.19 - updated comment reference field.
// JC :20220209 - v1.0.20 - Increase connection pool to 100.
// RMR:20220209 - v1.0.21 - Changed lookup routine for photos on Regular Parent forms and update form no longer using indexof.
// RMR:20220209 - v1.0.22 - Option to Remove Emojis from any test or testarea in the app
// RMR:20220329 - v1.0.23 - Memory LEAK error - All Variables are now properly
// JC :20220408 - v1.0.24 - Undefined translations in email template fix.
// RMR:20220408 - v1.0.25 - renamed SP putPostiveID to put_positive_recognition
// RMR:20220505 - v1.0.26 - Change retrieveal of the form ID not to use the formname - Not Needed.
// ZR :20220510 - v1.0.27 - Pentest update
// RRH :20220531 - v1.0.28 - Sending email the form name in the subject line
// JC ZR :20220615 - v1.0.29 - New custom form handleing
// RRH ZR :20220706 - v1.0.30 - Sending an email to a person who is doing the action General Action or Hazard Action
// SS :20220719 - v1.0.31 - Adding environment label and formdata to emails.
// ZR :20220715 - v1.0.32 - Send an email to all the stakeholders when completing a General Action or Hazard Action
// SS :20221221 - v1.0.33 - Update new RegExp("'", "g"), "\\'" to new RegExp("'", "g"), "\'" and create a centralized function replace_apostrophe
// RRH:20230117 - v1.0.34 - Update the client logo configuration in email template
// RMR:20230117 - v1.0.35 - Update SP's to work with new Preop Schemas.
// WL:20230131 - v1.0.36 - Assigning Actions to Multiple Users
*/

// Set the SqlListener Version
const LMD='1.0.36'

// Bypass SSL
process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0

function pad2(n) { return n < 10 ? '0' + n : n }
const args = process.argv[2]
let debug = false

if(args === 'debug')
	debug = true
const configLocation = 'env/'
const logLocation = 'logs/'
const http = require('http')
const https = require('https')
var moment = require('moment-timezone');
moment().tz("Canada/Eastern").format();
//const https = require('https').globalAgent.options.ca = require('ssl-root-cas/latest').create();
const querystring = require('querystring')
const sql = require('mariadb')
const fs = require('fs')
const { v4: uuidv4 } = require('uuid');
const path = require('path')
const dotenv = require('dotenv')
const nodemailer = require("nodemailer")
const { release } = require('os')

//sanitizeHtml Documentation: https://www.npmjs.com/package/sanitize-html
const sanitizeHtml = require('sanitize-html');
const { response } = require('express');

getRuntimeConfig()

let transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: process.env.EMAIL_PORT,
    secure: false, // true for 465, false for other ports
    tls: {rejectUnauthorized: false},
	authMethod: process.env.SMTP_AUTHMETHOD,																			// Method defualts to Login. If network, then remove along with credentials (presence of credentials, they will still be sent)
	auth: {
		user: process.env.EMAIL_USER,
		pass: process.env.EMAIL_PASSWORD 
		}
  })

  // NANO START AND CONFIGURATION.
  const opts = {
	"url": `${process.env.PROTOCOL}://${process.env.COUCHURL}:${process.env.COUCHPORT}`,
	"rejectUnauthorized": false,
  }


let theSequence = null
const nano = require('nano')(opts)
const sofvie = nano.use(`${process.env.COUCHDBNAME}`)
const feed = sofvie.follow({since: readSequence()})

feed.on('change', (change) => {
	logIt(`Total connections START:  ${pool.totalConnections()}`,'')
	logIt(`Active connections START:  ${pool.activeConnections()}`,'')
	logIt(`Idle connections: START:  ${pool.idleConnections()}`,'')
	theSequence = change.seq
	logIt("New Record coming in from the Change", change)	
	if(change.id) {
		if(change.id.substring(0,4) === "DMM:"){
			feed.pause()
			pollDRM(change.id)
		}
		else if(change.id.substring(0,7) === "_design")
		{
			logSequence(theSequence)
			resumeFeed('Couch Design')
		}
		else {
			feed.pause()
				logIt(`Total connections Feed:  ${pool.totalConnections()}`,'')
				logIt(`Active connections Feed:  ${pool.activeConnections()}`,'')
				logIt(`Idle connections: Feed:  ${pool.idleConnections()}`,'')
				pollRecords(change.id)
		}
	}
})


// RMR:20200324 - Use Environment for config.
var attachmentPath =  process.env.SUB_ATTACHMENTPATH
let attachmentPathGeneralAction = process.env.SUB_ATTACHMENTPATH_GENERAL_ACTION
const intMaxImages = 25;

// CouchDB connection parameters
var dbProtocol = 'http://'
var dbName = '/' + process.env.COUCHDBNAME.toLowerCase()
var dbHostname = process.env.COUCHURL
var dbHostport = process.env.COUCHPORT
var dbQuerypath = '/_changes?feed=continuous&since=now&include_docs=true&heartbeat=30000'
var dbMethod = 'GET'

const environment = process.env.DOMAIN.split('.')[0].split('//')[1]

// String to send in request body.
const postData = querystring.stringify({																				
  'msg': ''
})

let SQLconfig = {
    user: process.env.DB_WRITE_USER, 
    password: process.env.DB_WRITE_PASS, 
	host: process.env.DB_WRITE_IP,
	database: process.env.DB_WRITE_NAME,
	connectionLimit: 100,
	connectTimeout: 30000
}

let pool = sql.createPool(SQLconfig)

// Plug in couchDB connection parameters
const couchDBConnectionOptions = {
	hostname: dbHostname.replace('https://', ''),
	port: dbHostport,
	path: dbName + dbQuerypath,
	rejectUnauthorized: false, 
	method: dbMethod,
	headers: {
		'Content-Type': 'application/json',
		'Content-Length': Buffer.byteLength(postData),
		'Connection': 'keep-alive'
	}
}

// Header for Logging to File
logIt(` *********  CouchDB > SQL Listener Commercial [version: ${LMD}] *********`,'')
logIt('To access CouchDB web based administrator: ' + dbProtocol + dbHostname.replace('https://', '') + ':' + dbHostport + '/_utils\r\n','')
logIt('Usage: 	node SQLListenerCommercial.js [debug]\r\n','')
logIt('Started: ' + new Date().toISOString() + '\r\n','')

logIt('CONFIGURATION','','debuginfo')
logIt('-------------','','debuginfo')
logIt('Runtime environment : ', process.env.SOFVIERUNENV,'debuginfo')
logIt('','','debuginfo')
logIt('SQL ','','debuginfo')
logIt('-------------','','debuginfo')
logIt('DB_WRITE_IP : ', process.env.DB_WRITE_IP,'debuginfo')
logIt('DB_WRITE_NAME : ', process.env.DB_WRITE_NAME,'debuginfo')
logIt('DB_READ_NAME : ', process.env.DB_READ_NAME,'debuginfo')
logIt('DB_WRITE_USER : ', process.env.DB_WRITE_USER,'debuginfo')
logIt('DB_WRITE_PASS : <HIDDEN>','','debuginfo')
logIt('','','debuginfo')
logIt('Misc','','debuginfo')
logIt('-------------','','debuginfo')
logIt('DOMAIN : ', process.env.DOMAIN,'debuginfo')
logIt('SUB_ATTACHMENTPATH : ', process.env.SUB_ATTACHMENTPATH,'debuginfo')
logIt('PREOPFORM : ', process.env.PREOPFORM,'debuginfo')
logIt('EMAIL_HOST : ', process.env.EMAIL_HOST,'debuginfo')
logIt('EMAIL_PORT : ', process.env.EMAIL_PORT,'debuginfo')
logIt('EMAIL_USER : ', process.env.EMAIL_USER,'debuginfo')
logIt('EMAIL_FROM : ', process.env.EMAIL_FROM,'debuginfo')
logIt('','','debuginfo')
logIt('-------------','','debuginfo')
logIt('EOF CONFIGURATION','','debuginfo')
logIt('','','debuginfo')
logIt(`Couch Connection Options: `, JSON.stringify(couchDBConnectionOptions),'debuginfo')
// Show all of the Configuration Variables to the Console
logIt('SQL Config: ', JSON.stringify(SQLconfig),'debuginfo')
logIt(`DB Hostname: `,dbHostname,'debuginfo')
logIt(`DB Port:`, dbHostport,'debuginfo')
logIt('Couch DB Name: ', process.env.COUCHDBNAME.toLowerCase())
logIt('Couch DB Hostname: ', dbHostname.replace('https://', 'http://'))

//Used to escape and sanatize parameters
function cleanParams (params)
{
	let sanitizeList = ['{{', '}}', '${', '$(', '==', '===', '&&', '--', '++', '||', '//', '/*', '*/']
	for(let p = 0; p < params.length; p++) {
		if(params[p] != null && typeof params[p] == "string") {
			//Santitize using custom list
			for(let e = 0; e < sanitizeList.length; e++) {
				params[p] = params[p].replace(sanitizeList[e], "")
			}

			//Escape html
			params[p] = sanitizeHtml(params[p], {
				disallowedTagsMode: 'recursiveEscape',
				allowedTags: [],
				nonTextTags: []
			})

			params[p] = removeEmojis(params[p])
		}
	}
	return params
}

function pollRecords(id){
	logIt(`Total connections Now:  ${pool.totalConnections()}`,'')
	logIt(`Active connections Now:  ${pool.activeConnections()}`,'')
	logIt(`Idle connections: Now:  ${pool.idleConnections()}`,'')
	sofvie.get(id).then(newrecs =>{
		try {
			saveFormKeyValue(newrecs.formdata)
		}
		catch (err) {
			logIt("Error with Incoming Record: ", err.stack)
			feed.resume()
			logIt("The Feed has been resumed after error","")
			sendHelpDeskEmail({error: err.stack, id:id})
		}
	}).catch((err)=>{
		logIt("Poll Record Error", err,'debuginfo')
		feed.resume("After Error in Poll REcords")
		sendHelpDeskEmail({error: err, id:id})
	})
}

function pollDRM(id){
	logIt(`Total connections DRM:  ${pool.totalConnections()}`,'')
	logIt(`Active connections DRM:  ${pool.activeConnections()}`,'')
	logIt(`Idle connections: DRM:  ${pool.idleConnections()}`,'')
	sofvie.get(id).then(newrecs =>{
		processDRMAcknowlegement(newrecs)
	}).catch((err)=>{
		logIt("Poll DRM Error", err,'debuginfo')
		feed.resume("After Error in Poll DRM")
		sendHelpDeskEmail({error: err, id:id})
	})	
}

function replace_apostrophe (value){
	return value.replace(new RegExp("'", "g"), "&#39;")
}

// Initiate listening
feed.follow()

function processDRMAcknowlegement(doc){
	logIt(`**********  Acknowleging Document -  **********SQLListener VER(${LMD})**`,"")
	logIt(`Document Review ID =  ${doc.ack_id}`,'')
	logIt(`processDRMAcknowlegement: drrID= ${doc.ack_id}`, "",'debuginfo')
	logIt(`processDRMAcknowlegement: drrTimestamp= ${doc.ack_timestamp}`, "",'debuginfo')

	return new Promise((resolve, reject) =>	{																			// Wrap the call in a promise
		pool.getConnection()
		.then(conn => {
			logIt("INSERTING Acknowlegement",doc.ack_id,"debuginfo")
			let query = `call update_reviewed_document_by_drr_id(?,?)`
				let params = cleanParams([
					doc.ack_id, 
					doc.ack_timestamp
				])
				logIt("This is the Acknowlegment Query", query, 'debuginfo')
			conn.query(query, params)
			.then(rows => { 
				return rows
			})
			.then(res => { 
				logIt("Acknowlegment Pushed to SQL", res, 'debuginfo')
				logIt("Acknowlegment Pushed to SQL", '')
				conn.release() // release to pool
				resolve(true)
			}).then((data)=> {
				logSequence(theSequence)
				resumeFeed("ACKNOWLEDGE")
			})
			.catch(err => {
				logIt("INSERTING Acknowlegement error", JSON.stringify(err))
				conn.release() // release to pool
				resumeFeed("ACKNOWLEDGE ERROR")
			})
			
		}).catch(err => {
		logIt("Acknowlegement connection Error", JSON.stringify(err))
		resumeFeed("ACKNOWLEDGE CONNECTION ERROR")
		})
	}).catch((err)=>{
		logIt("Acknowlegement Promise Error", JSON.stringify(err))
		reject(err)
		resumeFeed("ACKNOWLEDGE PROMISE ERROR")
	}) // End Promise

}

function getUserLanguageAsync(user) {
	return new Promise((resolve, reject) =>	{
		pool.getConnection()
		.then(conn => {			
			let params = cleanParams([
				user
			])
			let query = "call get_user_profile_language(?)"
			logIt("User Language Query", query, 'debuginfo')
			conn.query(query, params)
				.then(rows => { 
					return rows
				})
				.then(res => { 
					conn.release(); // release to pool
					resolve(res[0][0])
				})
				.catch(err => {
					logIt("error", err)
					conn.release(); // release to pool
					resumeFeed("Language Lookup ERROR")
			})
		}).catch(err => {
				logIt("Error getting formfieldDescription", JSON.stringify(err))
				resumeFeed("FORM DESCRIPTIONID ERROR2 2")				
				reject(err)

		})		
	})
}

function removeEmojis(text) {
	return process.env.SHOW_EMOJIS === '0' ? text.replace(/(?:[\u2700-\u27bf]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff]|[\u0023-\u0039]\ufe0f?\u20e3|\u3299|\u3297|\u303d|\u3030|\u24c2|\ud83c[\udd70-\udd71]|\ud83c[\udd7e-\udd7f]|\ud83c\udd8e|\ud83c[\udd91-\udd9a]|\ud83c[\udde6-\uddff]|\ud83c[\ude01-\ude02]|\ud83c\ude1a|\ud83c\ude2f|\ud83c[\ude32-\ude3a]|\ud83c[\ude50-\ude51]|\u203c|\u2049|[\u25aa-\u25ab]|\u25b6|\u25c0|[\u25fb-\u25fe]|\u00a9|\u00ae|\u2122|\u2139|\ud83c\udc04|		[\u2600-\u26FF]|\u2b05|\u2b06|\u2b07|\u2b1b|\u2b1c|\u2b50|\u2b55|\u231a|\u231b|\u2328|\u23cf|[\u23e9-\u23f3]|[\u23f8-\u23fa]|\ud83c\udccf|\u2934|\u2935|[\u2190-\u21ff])/g, '') : text
}


function sendSubmissionEmail(payload){
	
	logIt("This is the Email Payload", payload, 'debuginfo')

	if(payload.email) {
		// Load the Language file for the Email Distribution
		getUserLanguageAsync(payload.elements.submittedby).then((langOut)=>{
			

			let	selectedLang = JSON.parse(fs.readFileSync(`locales/translation_${langOut.lang_name}.json`, 'utf8'));
			let reportURLLink = `${process.env.EMAIL_REPORT_URL}${payload.form}/${payload.headerid}?lang=${langOut.lang_id}`	
			logIt("This is the Report Link",reportURLLink,'debuginfo')

			let created_by_name = ''
			if('submittedby_name' in payload.elements){
				created_by_name = payload.elements.submittedby_name
			}

			let formtype = payload.elements.formname
			let form_email_data = {
				form_name : formtype,
				created_by: created_by_name,
				created_date: payload.elements.date_submit,
			}

			let emailBody = generateEmail(reportURLLink,selectedLang, form_email_data)
			
			if (payload.elements.formmisc){
				formtype += ' - ' +  payload.elements.formmisc
			}

 			let info = {

				from: process.env.EMAIL_FROM, // sender address
				to: payload.email.split("|").join(","), // list of receivers
				subject: ` ${selectedLang['8301']} - ${formtype}`, // Subject line  "Email from Sofvie"				
			
				html: emailBody ,
				secure: true
			}

			
		
			transporter.sendMail(info,(data)=>{
				logIt('Submission Email Sent for - ', payload.headerid)
			},(err)=>{
				logIt("Email Not Sent", err)
			})
		})
	}
}

/*

1. get the client logo url if, it does not exist set to default sofvie logo in the email template 


*/

function getClientLogoUrl(){
		let get_client_logo_url = process.env.DOMAIN
		logIt("default_url", get_client_logo_url)
		let build_client_logo_url = get_client_logo_url.split('-mobile.sofvie.com')[0]
		build_client_logo_url +='-images.sofvie.com/client_logo/logo.png'
		logIt("build_client_logo_url", build_client_logo_url)
		return build_client_logo_url
		
	}



function generateEmail(reportURLLink,selectedLang, form_email_data){

	let htmldata = `<!DOCTYPE html>
	<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
	
	<head>
	  <!--[if gte mso 15]>
	  <xml>
	  <o:OfficeDocumentSettings>
	  <o:AllowPNG/>
	  <o:PixelsPerInch>96</o:PixelsPerInch>
	  </o:OfficeDocumentSettings>
	  </xml>
	  <![endif]-->
	
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	  <meta http-equiv="x-ua-compatible" content="ie=edge">
	  <title note='Distribution Report'>${selectedLang['8299']}</title>
	  <style>
		body {background-color: #e0e0e0;}
		td {font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 20px; text-align: center;}
	  </style>
	</head>
	<body>
	  <table style="background-color: #e0e0e0; color: #212529; width: 100%; height:100%; padding: 20px; margin:0 !important;">
		<tr>
		  <td>
			<table style="max-width:600px; background-color: #ffffff;
			margin: 40px auto; border-radius: 3px; border-collapse: collapse; box-shadow: 0 0 25px 0 #afafaf;">
			  <tr>
				<td style="background-color:#0072ce; border-top-right-radius: 3px; border-top-left-radius: 3px; padding:10px; color: #ffffff;">
					<img src="${getClientLogoUrl()}" alt="Sofvie Logo" style="display:block; margin:10px auto; height:45px;" />
				</td>
			  </tr>
			  <tr>
				<td style="padding:20px;" note = "You have received this email in view of the fact that a Sofvie user has added you to their form distribution list. Click the button below to open the form submission report.">
				<!--	<h3>Hi  Replace with recipient's first name [Robert] Replace with recipient's first name,</h3> -->
				 ${selectedLang['4255']} ${selectedLang['4256']}
				</td>
			  </tr>   
			  <tr>
				<td>
					<table width="50%" style="margin: 0 auto;">
						<tr>
							<td style="border-radius: 3px; background-color: #0072ce; padding: 15px;">
							  <a href="${reportURLLink}" id="button" style=" text-decoration: none; color: #ffffff;">
								<span style="width:100%; display:block; font-size:18px;" note="OPEN REPORT">${selectedLang['4257']}</span>
							  </a>
							</td>
						</tr>
					</table>
				</td>
			  </tr>
			  <tr>
					<td>								
						<table width="50%" style="margin: 0 auto;">
							<tr>
								<td style="text-align: left; padding: 20px;">
									<strong>${selectedLang['1903']}:</strong> ${form_email_data['form_name']}<br/>
									<strong>${selectedLang['1298']}:</strong> ${form_email_data['created_by']} <br/>
									<strong>${selectedLang['1305']}:</strong> ${form_email_data['created_date']} <br/>
									<strong>${selectedLang['1952']}:</strong> ${environment}
								</td>
							</tr>
						</table>								
					</td>
				</tr>
			  <tr>
				<td style="padding:40px 20px 0 20px;" note="As a Sofvie user, you can access the desktop application and take advantage of the numerous data driven features like:">
					${selectedLang['4258']}
				</td>
			  </tr>
			  <tr>
				<td style="padding:10px 20px 20px 20px; line-height: 16px;">
				  <table style="margin: 0 auto; table-layout: fixed; width: 100%;">
					<tr>
						<td style="padding:0 10px; text-align: left; ">
						  <strong style="background-color:#f6be00; border-radius: 50%; display: inline-block; width: 21px; text-align: center;" note="View all form submissions from the beginning of time.">&nbsp;1&nbsp;</strong>&nbsp;${selectedLang['4259']}
						</td>
						<td style="padding:0 10px; text-align: left;">
						  <strong style="background-color:#f6be00; border-radius: 50%; display: inline-block; width: 21px; text-align: center;" note="Filter form field data and create your own custom reports.">&nbsp;2&nbsp;</strong>&nbsp;${selectedLang['4260']}
						</td>
						<td style="padding:0 10px; text-align: left;">
						  <strong style="background-color:#f6be00; border-radius: 50%; display: inline-block; width: 21px; text-align: center;" note="Browse analytics based on key metrics gathered from the field.">&nbsp;3&nbsp;</strong>&nbsp;${selectedLang['4261']}
						</td>
					</tr>
				  </table>
				</td>
			  </tr>
			  <tr>
				<td>
					<table width="50%" style="margin: 0 auto;">
						<tr>
							<td style="border-radius: 3px; border: 2px solid #0072ce; padding:15px;">
							  <a href="${process.env.DOMAIN_APP}" style=" text-decoration: none; color: #0072ce;">
								<span style="width:100%; display:block; font-size:16px; "><strong note="GO TO SOFVIE">${selectedLang['4262']}</strong></span>
							  </a>
							</td>
						</tr>
					</table>
				</td>
			  </tr>
			  <tr>
				<td style="padding:20px;"></td>
			  </tr>
			  <tr >
				  <td style="background-color:#0072ce; border-bottom-left-radius: 3px; border-bottom-right-radius: 3px; padding:20px; color: #ffffff;">
					<small>
					  
					  <a href="mailto:support@sofvie.com" style="color:#ffffff; text-decoration:none;" note="Support">${selectedLang['3606']}</a> |
					  <a href="https://sofvie.com/knowledge-base" target="_blank" style="color:#ffffff; text-decoration:none;" note="Documentation">${selectedLang['3607']}</a> | 
					  <a href="https://sofvie.com" target="_blank" style="color:#ffffff; text-decoration:none;" note="Website">${selectedLang['3608']}</a>
					  
					</small>
				  </td>
			  </tr>
			</table>
		  </td>
		</tr>
	  </table>
	</body>
	</html>`
return htmldata
}

function sendHelpDeskEmail(payload) {
	let info = {
		from: process.env.EMAIL_FROM, // sender address
		to: process.env.EMAIL_HELPDESK,
		//cc: "rrivest@sofvie.com", // CC stuff
		subject: "Error from SQL Listener", // Subject line
		//text: payload.error, // plain text body
		//html: `<table style="border: 1px solid black;background-color: yellow;"><tr><th style="border: 1px solid black;width:200px;">Email Link<th><td style="border: 1px solid black;">${reportURLLink}</td></tr></table>` // html body
		  html: `<!DOCTYPE html>
		  <h1>${payload.id}</h1>
		  <h3>${payload.error}</h3>
		  </html>`
		}
}

function sendPositiveRecognitionEmail(PositiveID){
	if(PositiveID) {

		let params = cleanParams([
			PositiveID,
		])
		let query = "call get_positive_recognition_email_details(?)"

		pool.getConnection().then(conn => { 
			conn.query(query, params).then((data)=> {
				data = data[0]
				conn.release()

				for(let i = 0; i < data.length; i++) {

					let	translations = JSON.parse(fs.readFileSync(`locales/translation_${data[i].lng_name}.json`, 'utf8'));
					let emailBody = generatePositiveRecognitionEmail(data[i], translations)
					let info = {
						from: process.env.EMAIL_FROM, // sender address
						to: data[i].email, // list of receivers
						subject: ` ${translations['3597']}`, // Subject line  "New Positive Recognition"
						html: emailBody,
						secure: true
					}
					transporter.sendMail(info,(data)=>{
						logIt('Positive Recognition Email Sent for PID: ', PositiveID)
					},(err)=>{
						logIt("Positive Recognition Email Not Sent", err)
					})
				}

			}).catch((err)=>{
				conn.release()
				logIt("POSITIVE EMAIL Error get_positive_recognition_email_details", JSON.stringify(err))
			})
		}).catch((err) =>{
			logIt("POSITIVE EMAIL Error connecting to pool", JSON.stringify(err))
		})
	}
}

function generatePositiveRecognitionEmail(data, translations){

	let htmldata = `<!DOCTYPE html>
	<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
	
		<head>
			<!--[if gte mso 15]>
			<xml>
			<o:OfficeDocumentSettings>
			<o:AllowPNG/>
			<o:PixelsPerInch>96</o:PixelsPerInch>
			</o:OfficeDocumentSettings>
			</xml>
			<![endif]-->
		
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
			<meta http-equiv="x-ua-compatible" content="ie=edge">
			<title note='Hi'>${translations['3597']}</title>
			<style>
			body {background-color: #e0e0e0;}
			td {font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 20px; text-align: center;}
			</style>
		</head>
		<body>
			<table style="background-color: #e0e0e0; color: #212529; width: 100%; height:100%; padding: 20px;">
				<tr>
					<td>
						<table style="max-width:600px; background-color: #ffffff;
						margin: 40px auto; border-radius: 3px; border-collapse: collapse; box-shadow: 0 0 25px 0 #afafaf;">
							<tr>
								<td style="background-color:#0072ce; border-top-right-radius: 3px; border-top-left-radius: 3px; padding:10px; color: #ffffff;">
									<img src="${getClientLogoUrl()}" alt="Sofvie Logo" style="display:block; margin:10px auto; height:45px;" />
								</td>
							</tr>
							<tr>
								<td style="padding:20px;">
									<h1 style="color: #f6be00;">${translations['3597']}</h1>
								</td>
							</tr>
							<tr>
								<td style="padding:0 20px;">
									<h3>${translations['3601']} ${data.recognition_of}</h3>
									<p>${translations['8935']}<p>
								</td>
							</tr>
							<tr>
								<td style="text-align: left; padding: 20px;">
									<strong>${translations['1054']}:</strong> ${data.recognition_type}<br/>
									<strong>${translations['1298']}:</strong> ${data.submitted_by}<br/>
									<strong>${translations['124']}:</strong> ${moment(data.submitted_date).format('MMM, Do, YYYY, hh:mm a')}<br/>
									<strong>${translations['1952']}:</strong> ${environment}</br>
								</td>
							</tr>
							<tr>
								<td style="padding:20px 20px 40px 20px; line-height: 16px; text-align: left;">
									<small>
										${translations['4243']}:<br/>
										1. ${translations['4244']}<br/>
										2. ${translations['8927']}<br/>
										3. ${translations['8926']}<br/>
										4. ${translations['8929']}
									</small>
								</td>
							</tr>
							<tr >
								<td style="background-color:#0072ce; border-bottom-left-radius: 3px; border-bottom-right-radius: 3px; padding:20px; color: #ffffff;">
									<small>										
										<a href="mailto:support@sofvie.com" style="color:#ffffff; text-decoration:none;" note="Support">${translations['3606']}</a> |
										<a href="https://sofvie.com/knowledge-base" target="_blank" style="color:#ffffff; text-decoration:none;" note="Documentation">${translations['3607']}</a> | 
										<a href="https://sofvie.com" target="_blank" style="color:#ffffff; text-decoration:none;" note="Website">${translations['3608']}</a>
									</small>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</body>
	</html>`
return htmldata
}

function sendActionCompleteEmail(ActionSubmissionID, action){
	if(ActionSubmissionID) {

		let params = cleanParams([
			ActionSubmissionID,
		])

		//Hazard
		let query = "call get_hazard_action_complete_email_details(?)"
		//General
		if(action == "general")
			query = "call get_general_action_complete_email_details(?)"

		pool.getConnection().then(conn => { 
			conn.query(query, params).then((data)=> {
				data = data[0]
				conn.release()

				for(let i = 0; i < data.length; i++) {

					let	translations = JSON.parse(fs.readFileSync(`locales/translation_${data[i].lng_name}.json`, 'utf8'))
					let reportURLLink = `${process.env.EMAIL_REPORT_URL}${data[i].ReportURL}/${data[i].submission_header_id}?lang=${data[i].lng_id}`

					let body_text = translations['9167'] // A hazard action you have been tagged to has been completed.
					if(action == "general")
						body_text = translations['9172'] // A general action you have been tagged to has been completed.

					let emailBody = generateActionCompleteEmail(reportURLLink, body_text, data[i], translations)
					let info = {
						from: process.env.EMAIL_FROM, // sender address
						to: data[i].email, // list of receivers
						subject: `${translations['2026']}`, // Subject line  "Action Completed"
						html: emailBody,
						secure: true
					}
					transporter.sendMail(info,(data)=>{
						logIt('Action complete Email Sent: ', data[i].email)
					},(err)=>{
						logIt("Action complete Email Not Sent", err)
					})
				}

			}).catch((err)=>{
				conn.release()
				logIt("ACTION COMPLETE EMAIL Error get_action_close_email_details", JSON.stringify(err))
			})
		}).catch((err) =>{
			logIt("ACTION COMPLETE EMAIL Error connecting to pool", JSON.stringify(err))
		})
	}
}

function generateActionCompleteEmail(reportURLLink, body_text, data, translations){

	let htmldata = `<!DOCTYPE html>
	<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
	
		<head>
			<!--[if gte mso 15]>
			<xml>
			<o:OfficeDocumentSettings>
			<o:AllowPNG/>
			<o:PixelsPerInch>96</o:PixelsPerInch>
			</o:OfficeDocumentSettings>
			</xml>
			<![endif]-->
		
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
			<meta http-equiv="x-ua-compatible" content="ie=edge">
			<title note='Hi'>${translations['3597']}</title>
			<style>
			body {background-color: #e0e0e0;}
			td {font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 20px; text-align: center;}
			</style>
		</head>
		<body>
			<table style="background-color: #e0e0e0; color: #212529; width: 100%; height:100%; padding: 20px;">
				<tr>
					<td>
						<table style="max-width:600px; background-color: #ffffff;
					margin: 40px auto; border-radius: 3px; border-collapse: collapse; box-shadow: 0 0 25px 0 #afafaf;">
							<tr>
								<td style="background-color:#0072ce; border-top-right-radius: 3px; border-top-left-radius: 3px; padding:10px; color: #ffffff;">
									<img src="${getClientLogoUrl()}"
										alt="Sofvie Logo"
										style="display:block; margin:10px auto; height:45px;"/>
								</td>
							</tr>
							<tr>
								<td style="padding:0 20px;">
									<h3>${translations['3601']}, </h3>
									<p>${body_text}<p>
								</td>
							</tr>
							<tr>
								<td style="text-align: left; padding: 20px;">
									<strong>${translations['17']}:</strong> ${data.action_type}<br/>
									<strong>${translations['15']}:</strong> ${data.action_taken}<br/>
									<strong>${translations['2028']}:</strong> ${data.completed_by}<br/>
									<strong>${translations['2001']}</strong> ${moment(data.completed_date).format('MMM, Do, YYYY')}<br/>
									<strong>${translations['1952']}:</strong> ${environment}
								</td>
							</tr>
							<tr>
			
							</tr>
							<tr>
								<td>
									<table width="50%" style="margin: 0 auto;">
										<tr>
											<td style="border-radius: 3px; background-color: #0072ce; padding: 15px;">
												<a href="${reportURLLink}" id="button" style=" text-decoration: none; color: #ffffff;">
													<span style="width:100%; display:block; font-size:18px;">${translations['4257']}</span>
												</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
							</tr>
							<tr>
							</tr>
							<tr>
							</tr>
							<br/>
							<br/>
							<br/>
							<tr>
								<td style="background-color:#0072ce; border-bottom-left-radius: 3px; border-bottom-right-radius: 3px; padding:20px; color: #ffffff;">
									<small>										
										<a href="mailto:support@sofvie.com" style="color:#ffffff; text-decoration:none;">${translations['3606']}</a> |
										<a href="https://sofvie.com/knowledge-base" target="_blank" style="color:#ffffff; text-decoration:none;"> ${translations['3607']}</a> |
										<a href="https://sofvie.com" target="_blank" style="color:#ffffff; text-decoration:none;">${translations['3608']}</a>			
									</small>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</body>
	</html>`
return htmldata
}

function saveFormKeyValue(formelements)	{ // Save the form results to a DB
	// Write form contents to database.
	// INPUT: formelements = JSON object containing entire form submission.
	var arrAttachments = {}  // Create storage for the attachments (Used for MS Word Templator)
	var submissionID = formelements.submissionId.trim()  // Extract the unique submission id from the form
    var formId = formelements.formid.trim() // Extract the FF formid from the form
    var formVersion = formelements.version.trim() // Extract the FF version from the form
    var formName = formelements.formname.trim() // Extract the FF form name from the form
	// Dump the extracted values
	logIt(`**********  Saving Form - ${formelements.formname.trim()}  **********SQLListener VER(${LMD})**`,"")
	logIt(`saveFormKeyValue(): submissionID =  ${submissionID}`,'','debuginfo')
	logIt(`saveFormKeyValue(): formId = ${formId}`,'','debuginfo')
	logIt(`saveFormKeyValue(): formVersion= ${formVersion}`,'','debuginfo')
	logIt(`saveFormKeyValue(): formName= ${formName}`,'','debuginfo')



	var subExists = 0
	let submissionHeaderID = ''	 // Declare and Init or flag for form previously saved
	var formDescriptionID = 0 // Initialize the row id of this form
	var results = null // Initialize our return vars
	
	DoesSubmissionExist(submissionID).then(function (results){	 // Look up the submission id
		subExists = results	 // Assign the result
		logIt('DoesSubmissionExist: Returned: ', subExists,'debuginfo')
	
		if(subExists)	{
			// SJB: 20190607 - Add functionality to update Actionable forms (HAP)
			// HANDLE FORM COMPLETIONS (UPDATE)			
			// All actionable items are stored via Hazard Action Protocol (really should be called Actions). With the introduction of 'Incidents' lookup table (IncidentSubmissions)
			// HAP saves are stored in individual columns per row.
			logIt('Calling putHAPUpdate() ', subExists,'debuginfo')
			let SubCompleted = 0
			if(formName === 'GENERALACTIONCOMPLETE'){
				IsGeneralAcionCompleted(formelements.general_rowid).then(function (results){	 // Look up the submission id
					SubCompleted = results	 // Assign the result
					logIt('IsGeneralAcionCompleted: Returned: ', SubCompleted,'debuginfo')
                	putGeneralActionUpdate(formelements,SubCompleted)
				})
			}
			else if (formName === 'ACTIONCOMPLETE'){
				IsHazardAcionCompleted(formelements.rowid).then(function (results){	 // Look up the submission id
					SubCompleted = results	 // Assign the result
					logIt('IsHazardAcionCompleted: Returned: ', SubCompleted,'debuginfo')
                	putHAPUpdate(formelements,SubCompleted) // This is a Hazard Action, process it.
				})				
			}
			else {
				resumeFeed("We have this record")
			}
			
			logIt('Return from putHAPUpdate()', '','debuginfo')
		}	
		else { // This is a fresh insert
 			//RMR:20200814  Detect form submission from PreOp. Pre-Op forms do not have a proper form defintion (only the header) so they have to be manually handled.
			//RMR:20200814 Retrieve Pre-Op formid from config.
			if(formId == process.env.PREOPFORM)	{ // If we got a pre  op form.. handle it.
				logIt('********  PROCESSING Pre-Op form : ', formId ,'debuginfo')

			// RMR:20201022 - Scoping issue on submissionHeaderID, restructured code block.
				GetFormDescriptonID(formId, formVersion, formName, formelements) // Promise chain to save submission
				.then(formDescriptionID => InsertSubmissionHeader(formelements, submissionID, formDescriptionID)) //{// Function to resolve row id ofthis form
				.then(function(response){
					submissionHeaderID = response; // return the id of the new row.
					insertSubmissionDetail(submissionHeaderID)
					.then(submissionDetailID => ExplodeTopLevelFormData(submissionDetailID, formelements, arrAttachments))
					.then(returnPreOpDetail => insertPreOp(submissionHeaderID, formelements))				
					
				})
				.then(returnDetail => dispatchHAPS(submissionHeaderID, formelements))
				.then(returnDetail => {
					let actionEmails = returnDetail
					dispatchGeneralActions(submissionHeaderID, formelements).then(returnDetail => {
						dispatchPositiveIDs(submissionHeaderID, formelements)
						actionEmails = appendEmail(returnDetail, actionEmails)

						let emailList = appendEmail(actionEmails, formelements.Report_Distribution1)

						sendSubmissionEmail({headerid:submissionHeaderID , form: formelements.email_form_report, email: emailList, lang: 'en', elements: formelements})
					}).then((data)=> {
						logSequence(theSequence)
						resumeFeed("SAVE KEYFORM STANDARD")
					}) // Save PID, FK is resolved from submission GUID.
				})
			}	
				//Custom Forms form handling
			else if(formId == process.env.CUSTOMFORM)	{ 
				logIt('********  PROCESSING Custom Form : ', formId ,'debuginfo')
			 	GetFormDescriptonID(formId, formVersion, formName, formelements) // Promise chain to save submission
				.then(formDescriptionID => InsertSubmissionHeader(formelements, submissionID, formDescriptionID)) //{// Function to resolve row id ofthis form
				.then((response) => {
					submissionHeaderID = response

					insertSubmissionDetail(response)
					.then(submissionDetailID => ExplodeTopLevelFormData(submissionDetailID, formelements, arrAttachments))
					.then(returnDetail => insertCustomForm(submissionHeaderID,formelements, returnDetail))
					.then(customFormID => insertCustomFormItems(formelements, customFormID))
					.then(returnDetail => dispatchHAPS(submissionHeaderID, formelements))
					.then(returnDetail => {
						let actionEmails = returnDetail
						dispatchGeneralActions(submissionHeaderID, formelements).then(returnDetail => {
							dispatchPositiveIDs(submissionHeaderID, formelements)
							actionEmails = appendEmail(returnDetail, actionEmails)

							let emailList = appendEmail(actionEmails, formelements.Report_Distribution1)

							sendSubmissionEmail({headerid:submissionHeaderID , form: formelements.email_form_report, email: emailList, lang: 'en', elements: formelements})
						}).then((data)=> {
							logSequence(theSequence)
							resumeFeed("SAVE KEYFORM STANDARD")
						}) // Save PID, FK is resolved from submission GUID.
					})
				})
			}
			else {
				logIt('Processing NON-Pre-Op or Custom form : ', formId ,'debuginfo')
				GetFormDescriptonID(formId, formVersion, formName, formelements) // Promise chain to save submission
				.then(formDescriptionID => InsertSubmissionHeader(formelements, submissionID, formDescriptionID)) //{// Function to resolve row id ofthis form
				.then(function(response){
					submissionHeaderID = response; // return the id of the new row.

					insertSubmissionDetail(submissionHeaderID)
					.then(submissionDetailID => ExplodeTopLevelFormData(submissionDetailID, formelements, arrAttachments))
					.then(returnDetail => dispatchHAPS(submissionHeaderID, formelements))
					.then(returnDetail => {
						let actionEmails = returnDetail
						dispatchGeneralActions(submissionHeaderID, formelements).then(returnDetail => {
							dispatchPositiveIDs(submissionHeaderID, formelements)
							actionEmails = appendEmail(returnDetail, actionEmails)
							let emailList = appendEmail(actionEmails, formelements.Report_Distribution1)
							sendSubmissionEmail({headerid:submissionHeaderID , form: formelements.email_form_report, email: emailList, lang: 'en', elements: formelements})
						}).then((data)=> {
							logSequence(theSequence)
							resumeFeed("SAVE KEYFORM STANDARD")
						}) // Save PID, FK is resolved from submission GUID.
					})
					let incidentForms=['224335','220234']
					if(incidentForms.includes(formelements.formid) && formelements.incident_id){
						InsertIncidentSubmissions(formelements, submissionHeaderID, formelements.incident_id)
					}
				})
			}
		}
	})
}

function appendEmail (email, existingEmailList) {
	if(!email)
		return existingEmailList
	else if (!existingEmailList)
		return email
	return `${existingEmailList}|${email}`
}

function insertCustomForm(submissionHeaderID, formelements, returnDetail) {
	return new Promise((resolve, reject) =>	{	
		logIt("Inserting Custom Form Data","")	
		pool.getConnection()
	   .then(conn => {
		   
		let customFormParams = cleanParams([
			submissionHeaderID,
			formelements.customForm,
			formelements.submittedby
		])
		let query = "call add_custom_form(?,?,?,@Output)"

		logIt("CUSTOMFORM Master Query", query ,'debuginfo')
		conn.query(query, customFormParams).then((res)=>{
			conn.release()
			resolve(res[0][0].cfm_id)
		})
		}).catch((err)=>{
			logIt("CUSTOMFORM Error connecting to pool", JSON.stringify(err))
			conn.release() // release to pool
			resumeFeed("SUBMISSION HEADER ERROR")
		})
	}).catch((err) => {
		logIt("CUSTOMFORM Promise Error", JSON.stringify(err))
		resumeFeed('INSERT CUSTOMFORM PROMISE ERROR')
	})
}

function insertCustomFormItems(formelements, customFormID) {
	logIt("Custom Form ID",customFormID)
	return new Promise((resolve, reject) =>	{
		logIt("Inserting The CUSTOMFORM ITEMS","")
		let promises = []
		let detailDataList = {} //Key: fbi_id, Value: detailData
		
		//Create detailDataList 
		for (let category of Object.keys(formelements)) {

			let newDetailData = {}
			let attData = {}
			let elementValue = formelements[category]
			newDetailData.attDataList = []
			newDetailData.elementName = category
			newDetailData.submittedBy = formelements.submittedby
			newDetailData.customFormID = customFormID

			if(category.indexOf('_signature') > -1 && !(category.indexOf('_comments') > -1) && !(category.indexOf('_img_time') > -1)) { // Signature fields
				logIt("Inserting CUSTOMFORM SIGNATURE ITEM ", category)
				let itemID = parseInt(category.split("_")[1])

				newDetailData.itemParams = cleanParams([
					customFormID,
					itemID,
					"",
					formelements.submittedby,
					true,
					null
				])

				attData.dataURL = elementValue
				attData.comment = formelements[`${category}_comments`] ? formelements[`${category}_comments`] : ""
				attData.imageTime = formelements[`${category}_img_time`] ? moment(new Date(formelements[`${category}_img_time`])).format("YYYY-MM-DD HH:mm:ss") : null
				
				//If the item does not exist, create a new item detail object
				if(!detailDataList[itemID]) {
					detailDataList[itemID] = newDetailData
				}

				// Add attachment to the attachment list in the item detail object
				detailDataList[itemID].attDataList.push(attData)

			} else if(category.indexOf('galleryid') > -1 && !(category.indexOf('_comment') > -1)) { // Image fields
				logIt("Inserting CUSTOMFORM IMAGE ITEM ", category)
				let itemID = parseInt(category.split("|")[1].split("_")[1])

				newDetailData.itemParams = cleanParams([
					customFormID,
					itemID,
					"",
					formelements.submittedby,
					true,
					null
				])

				attData.dataURL = elementValue
				attData.comment = formelements[`${category}_comment`] ? formelements[`${category}_comment`] : ""
				attData.imageTime = category ? category.substring(0,19) : null

				//If the item does not exist, create a new item detail object
				if(!detailDataList[itemID]) {
					detailDataList[itemID] = newDetailData
				}

				// Add attachment to the attachment list in the item detail object
				detailDataList[itemID].attDataList.push(attData)
			
			} else if(category.indexOf('item_') > -1 && excludeCheck(category)) { // All other fields
				logIt("Inserting CUSTOMFORM ITEM ", category)
				let itemID = parseInt(category.split("_")[1])

				newDetailData.itemParams = cleanParams([
					customFormID,
					itemID,
					elementValue ? elementValue.replace(new RegExp("'","g"),"\\'") : elementValue,
					formelements.submittedby,
					false,
					formelements[`${category}_additional_info`] ? formelements[`${category}_additional_info`] : null
				])

				detailDataList[itemID] = newDetailData
			}
		}

		// Create promise list
		for (let detailData of Object.values(detailDataList)) {
			promises.push(addCustomFormItemDetails(detailData))
		}

		// Cxecute promises
		Promise.all(promises).then((values) => {
			resolve(customFormID)
		})		
	})

	function excludeCheck(category) {
		// Determine if this category should be excluded from adding detail data.
		if(!(category.indexOf('_signature') > -1) && !(category.indexOf('galleryid') > -1) && !(category.indexOf('_additional_info') > -1) && !(category.indexOf('_submit') > -1))
			return true
		else 
			return false
	}
}

function addCustomFormItemDetails(detailData){
	return new Promise((resolve, reject) =>	{
		let query = "call add_custom_form_item(?,?,?,?,?,?,@Output)"
		pool.getConnection().then(conn => { 
			conn.query(query, detailData.itemParams).then((data)=> {
				conn.release()

				detailData.detailID = data[0][0].detailID

				// Check if this has an attachment
				if(detailData.attDataList.length > 0) {					
					insertCustomFormAttachments(detailData).then((customFormID) => {
						logIt("CUSTOM FORM ATTACHMENTS INSERTED", customFormID)
						resolve(data)
					})
				} else {
					resolve(detailData.customFormID)
				}

			}).catch((err)=>{
				conn.release()
				logIt("CUSTOMFORM Error Inserting Items into custom_form_detail", JSON.stringify(err))
				resumeFeed("CUSTOMFORM SUBMISSION ITEMS ERROR")
			})
		}).catch((err) =>{
			logIt("CUSTOMFORM Items Error connecting to pool", JSON.stringify(err))
			conn.release() // release to pool
			resumeFeed("Custom Form Items connection ERROR")
		})
	})
}

function insertCustomFormAttachments(detailData) {
	return new Promise((resolve, reject) =>	{

		function generateFiles() {

			let fileArray = []

			//Loop through 
			for(let a = 0; a < detailData.attDataList.length; a++) {
				let att = detailData.attDataList[a]
				
				var fileName = uuidv4();	 // Generate a GUID for a filename.
				fileName += '.jpg'	 // All image submissions will be JPG

				logIt(`Generated filename: ${attachmentPath}${fileName}`,"","debuginfo")

				var theImageBase64 = att.dataURL  // Copy the image data
				let data = theImageBase64.replace(/^data:image\/\w+;base64,/, "")	 // Strip the data header then
				var buf = new Buffer.from(data, 'base64')	// Create a buffer converting from Base64 to Binary
				fs.writeFileSync(attachmentPath + fileName, buf, function(err)	{	 // Save the file to the filesystem
					if(err)	{
						logIt("Error Writing Custom Form Attachment to File", JSON.stringify(err))
						return (err);
					}
				})

				logIt(`Custom form Image Saved to File: (${fileName})`,'');

				fileArray.push({'filename': fileName, "elementName": detailData.elementName, "timestamp": att.imageTime, 'comment': att.comment})
			}

			return fileArray
		}

		async function commentCustomFormAttachment(commParams) {
			return new Promise((resolve, reject) =>	{
				let query = 'call add_custom_form_attachment_comment(?,?,?,?)'

				pool.getConnection().then(conn => { 
					conn.query(query, commParams).then((output)=> {
						conn.release()
						logIt(`Comment Inserted`,"")
						resolve(output)
					})
					.catch((err)=>{
						conn.release()
						logIt("CUSTOMFORM Insert Comments Error", JSON.stringify(err))
						resumeFeed("CUSTOMFORM Insert Comments Error")
					})
				}).catch((err)=>{
					conn.release()
					logIt("CUSTOMFORM Insert Comments Commection Error", JSON.stringify(err))
					resumeFeed("CUSTOMFORM Insert Comments Commection Error")
				})
					
			}).catch((err)=>{
				logIt("INSERT Custom Form comments ASYNC ERROR", JSON.stringify(err))
				resumeFeed("INSERT Custom Form comments ASYNC ERROR")
			})
		}

		async function insertCustomFormAttachment(file) {
			return new Promise((resolve, reject) =>	{
				let attParams = cleanParams([
					file.filename,
					file.elementName,
					file.timestamp,
					detailData.submittedBy,
					detailData.customFormID,
					detailData.detailID
				])	

				let query = 'call add_custom_form_attachment(?,?,?,?,?,?,@Output)'
				pool.getConnection().then(conn => { 
					conn.query(query, attParams).then((res)=> {
						logIt(`ATTACHMENT INSERTED`, res[0][0].attachment_id)

						if(file.comment.trim() != "")
						{
							let commParams = cleanParams([
								res[0][0].attachment_id,
								file.comment,
								detailData.submittedBy, 
								detailData.customFormID
							])
	
							commentCustomFormAttachment(commParams).then((result)=>{
								conn.release()
								resolve(detailData.customFormID)
							})
						} else {
							resolve(detailData.customFormID)
						}						
					}).catch((err)=>{
						conn.release()
						logIt("CUSTOMFORM Error Inserting Pictures into custom_form_attachments", JSON.stringify(err))
						resumeFeed("CUSTOMFORM SUBMISSION ATTACHMENTS ERROR")
					})
				}).catch((err) =>{
					logIt("CUSTOMFORM ATTACHMENTS connecting to pool", JSON.stringify(err))
					conn.release() // release to pool
					resumeFeed("CustomForm ATTACHMENTS connection ERROR")
				})
			})
		}

		let fileArray = generateFiles()
		let promises = []

		for(let c = 0; c < fileArray.length; c++) {
			promises.push(insertCustomFormAttachment(fileArray[c]))
		}

		Promise.all(promises).then((values) => {
			resolve(detailData.customFormID)
		})

	}).catch(function(err) {
		resumeFeed('INSERT CustomForm Attachmment Promise ERROR')
		logIt("INSERT CustomForm Attachmment Promise ERROR", JSON.stringify(err))
	})
}


function GetFormDescriptonID(formID, formVersion, formName, formelements) { // Function to check if form metadata exists							
	// Call Stored procedure and return the rowID of the form definition.
	//	INPUT: 	FF formID (int)
	//					FF formVersion (int)
	//					FF formName (string)
	// 	OUTPUT:	RowId of this form definition (int)
	
		logIt(`GetFormDescriptonID(): formId = ${formID}\r\n`,'','debuginfo')	
		logIt(`GetFormDescriptonID(): formVersion= ${formVersion}\r\n`,'','debuginfo')
		logIt(`GetFormDescriptonID(): formName= ${formName}\r\n`,'','debuginfo')																																// Dump the extracted values

	return new Promise((resolve, reject) =>	{																			// Wrap the call in a promise
		pool.getConnection()
		.then(conn => {
			
			let query = `call getFormDescription(?,?,@OutputID,@isInserted)`
			let params = cleanParams([
				formID,
				formVersion
			])

			logIt("GetFormDescriptonID() Query", query, 'debuginfo')
			conn.query(query, params)
				.then(rows => { 
					return rows
				})
				.then(res => { 
					logIt(`Form Description ID =`,res[0][0].OutputID)
					logIt(`Result from getFormDescriptionID`, JSON.stringify(res),"debuginfo")
					conn.release(); // release to pool
					resolve(res[0][0].OutputID)
				})
				.catch(err => {
					logIt("error", err)
					conn.release(); // release to pool
					resumeFeed("FORM DESCRIPTIONID ERROR")
			})
				
		}).catch(err => {
				logIt("Error getting formfieldDescription", JSON.stringify(err))
				resumeFeed("FORM DESCRIPTIONID ERROR2 2")				
				reject(err)

		})
	}).catch((err)=>{
			logIt("Get FormDescriptionID Error", JSON.stringify(err))
			resumeFeed("FORM DESCRIPTIONID PROMISE ERROR")
			reject(err)

	}) // End of Promise
}

function DoesSubmissionExist(submissionID)	{
		// Call stored procedure to see if this form is a previous submit,
	// INPUT: forms submissionID - unique ident.
	// OUPUT: bool exists (true).
	
	logIt("Check if Submission Exists: submissionID = ", submissionID)
	return new Promise((resolve, reject) =>	{
		let params = cleanParams([
			submissionID
		])
		let query = "call sp_SubmissionExists(?, @SubExists)"
		pool.getConnection()
			.then(conn => {
				conn.query(query, params)
				.then(rows => { 
					return rows
				})
				.then(res => { 
					res[0][0].SubExists ? logIt("Submission Exists","") : logIt("Submission Does Not Exist","")
					logIt("result from DoesSubmissionExist()", JSON.stringify(res),"debuginfo")
					conn.release(); // release to pool
					resolve(res[0][0].SubExists)
				})
				.catch(err => {
					logIt("DoesSubmissionExist() error", JSON.stringify(err))
					conn.release(); // release to pool
					resumeFeed("SUBMISSION EXIST ERROR")
				})
			}).catch(err => {
				resumeFeed("SUBMISSION EXIST CONNECTION ERROR")
				reject(err)
				
			});
	}).catch((err)=>{
		logIt("Submission Exist Error", JSON.stringify(err))
		resumeFeed("SUBMISSION EXIST PROMISE ERROR")
		reject(err)
	  }); // End Promise
}

function IsGeneralAcionCompleted(sga_id)	{
	// Call stored procedure to see if this action is completed,
// INPUT: forms submissionID - unique ident.
// OUPUT: bool exists (true).

logIt("Check if Submission completed: sga_id = ", sga_id)
return new Promise((resolve, reject) =>	{
	let params = cleanParams([
		sga_id
	])
	let query = "call get_general_action_completed_count(?, @SubCompleted)"
	pool.getConnection()
		.then(conn => {
			conn.query(query, params)
			.then(rows => { 
				return rows
			})
			.then(res => { 
				res[0][0].SubCompleted ? logIt("Submission Completed","") : logIt("Submission Is Not Completed","")
				logIt("result from IsGeneralAcionCompleted()", JSON.stringify(res),"debuginfo")
				conn.release(); // release to pool
				resolve(res[0][0].SubCompleted)
			})
			.catch(err => {
				logIt("IsGeneralAcionCompleted() error", JSON.stringify(err))
				conn.release(); // release to pool
				resumeFeed("SUBMISSION COMPLETED ERROR")
			})
		}).catch(err => {
			resumeFeed("SUBMISSION EXIST CONNECTION ERROR")
			reject(err)
			
		});
}).catch((err)=>{
	logIt("Submission Completed Error", JSON.stringify(err))
	resumeFeed("SUBMISSION COMPLETED PROMISE ERROR")
	reject(err)
  }); // End Promise
}

function IsHazardAcionCompleted(hac_sha_id)	{
	// Call stored procedure to see if this action is completed,
// INPUT: forms submissionID - unique ident.
// OUPUT: bool exists (true).

logIt("Check if Submission completed: hac_sha_id = ", hac_sha_id)
return new Promise((resolve, reject) =>	{
	let params = cleanParams([
		hac_sha_id
	])
	let query = "call get_general_action_completed_count(?, @SubCompleted)"
	pool.getConnection()
		.then(conn => {
			conn.query(query, params)
			.then(rows => { 
				return rows
			})
			.then(res => { 
				res[0][0].SubCompleted ? logIt("Submission Completed","") : logIt("Submission Is Not Completed","")
				logIt("result from IsHazardAcionCompleted()", JSON.stringify(res),"debuginfo")
				conn.release(); // release to pool
				resolve(res[0][0].SubCompleted)
			})
			.catch(err => {
				logIt("IsHazardAcionCompleted() error", JSON.stringify(err))
				conn.release(); // release to pool
				resumeFeed("SUBMISSION COMPLETED ERROR")
			})
		}).catch(err => {
			resumeFeed("SUBMISSION EXIST CONNECTION ERROR")
			reject(err)
			
		});
}).catch((err)=>{
	logIt("Submission Completed Error", JSON.stringify(err))
	resumeFeed("SUBMISSION COMPLETED PROMISE ERROR")
	reject(err)
  }); // End Promise
}

function InsertSubmissionHeader(formelements, submissionID, formID)	{
	// Save  header to the Submission Header table.
	// INPUT: formelements - JSON form submission
	//				formID - ID of form defintion
	// OUTPUT: bool success/fail (true).
	//	process.stdout.write(`InsertSubmissionHeader(): formelements = ${formelements}\r\n`);
		logIt(`InsertSubmissionHeader(): submissionID= ${submissionID}`, "",'debuginfo')
		logIt(`InsertSubmissionHeader(): formID= ${formID}`, "",'debuginfo')

	return new Promise((resolve, reject) =>	{																			// Wrap the call in a promise
		pool.getConnection()
		.then(conn => {
			let supervisorFinalValue = formelements.supervisor ? replace_apostrophe(formelements.supervisor) : null
			let siteFinalValue = formelements.site ? replace_apostrophe(formelements.site) : null
			let workplaceFinalValue = formelements.workplace ? replace_apostrophe(formelements.workplace) : null
			let levelFinalValue = formelements.level ? replace_apostrophe(formelements.level) : null
			let jobNumberFinalValue = formelements.job_number ? replace_apostrophe(formelements.job_number) : null
			let query = `call put_submission_header(@OutputID,?,?,?,?,?,?,?,?,?,?,?,?)`
			let params = cleanParams([
				formID,
				submissionID,
				`${moment(formelements.startFormTimeStamp).format("YYYY-MM-DD HH:mm:ss")}.000`,
				`${moment(formelements.endFormTimeStamp).format("YYYY-MM-DD HH:mm:ss")}.000`,
				siteFinalValue,
				jobNumberFinalValue,
				levelFinalValue,
				workplaceFinalValue,
				supervisorFinalValue,
				formelements.submittedby,
				`${moment(formelements.date).format('YYYY-MM-DD')} 12:00:00.000`,
				formelements.formLanguage ? formelements.formLanguage : 'en'
			])
			logIt("INSERTING HEADER",query,"debuginfo")
		  	conn.query(query, params)
			.then(rows => { 
				return rows
			})
			.then(res => { 
				logIt("Submission Header ID = ", res[0][0].ID)
				logIt("InsertSubmissionHeader() Response", JSON.stringify(res),'debuginfo')
				conn.release() // release to pool
				resolve(res[0][0].ID)
			})
			.catch(err => {
				logIt("InsertSubmissionHeader() error", JSON.stringify(err))
				  conn.release() // release to pool
				  resumeFeed("SUBMISSION HEADER ERROR")
			})
			
		}).catch(err => {
		  logIt("InsertSubmissionHeader() connection Error", JSON.stringify(err))
		  resumeFeed("SUBMISSION HEADER CONNECTION ERROR")
		})
	}).catch((err)=>{
		  logIt("Submission Header Promise Error", JSON.stringify(err))
		  resumeFeed("SUBMISSION HEADER PROMISE ERROR")
	}) // End Promise
		

}

function insertSubmissionDetail(submissionHeaderID)	{
	// Save  the Submission Detail (XML) as a child of the header record.  
	// This is a placeholder as XML isn't used by FF replacement and is only used to maintain db structure.
	// INPUT: submissionHeaderID - Submission Header record
	// OUTPUT: ID of submission detail row.
	// Dump the extracted values
	logIt(`InsertSubmissionDetail(): submissionHeaderID = ${submissionHeaderID}`,"",'debuginfo')
	return new Promise((resolve, reject) =>	{																			// Wrap the call in a promise
		pool.getConnection()
		.then(conn => {
			logIt("Insert Submission Details",submissionHeaderID,'debuginfo')
			let query= `call putSubmissionDetails(@OutputID,?,'<formResult></formResult>')`
			let params = cleanParams([
				submissionHeaderID
			])
			conn.query(query, params).then(rows => {
				return rows
			})
			.then(res => { 
				logIt("Submission Detail ID = ", res[0][0].ID)
				logIt("Submission Details result", JSON.stringify(res),'debuginfo')
				conn.release(); // release to pool
				resolve(res[0][0].ID)
			})
			.catch(err => {
				logIt("InsertSubmissionDetail() error", JSON.stringify(err))
				conn.release(); // release to pool
				resumeFeed("SUBMISSION DETAIL ERROR")
				reject(err)
			})
		}).catch(err => {
			resumeFeed("SUBMISSION DETAIL CONNECTION ERROR")
			reject(err)
		});
	}).catch((err)=>{
		logIt("Submission Detail Error", JSON.stringify(err))
		resumeFeed("SUBMISSION DETAIL PROMISE ERROR")
	}) // End Promise
}

function InsertIncidentSubmissions(formelements, submissionHeaderID, incidentId)	{
	// Save  header to the Submission Header table.
	// INPUT: formelements - JSON form submission
	//				formID - ID of form defintion
	// OUTPUT: bool success/fail (true).
	//	process.stdout.write(`InsertSubmissionHeader(): formelements = ${formelements}\r\n`);
		logIt(`InsertSubmissionHeader(): submissionID= ${submissionHeaderID}`, "",'debuginfo')
		logIt(`InsertSubmissionHeader(): incidentId= ${incidentId}`, "",'debuginfo')

	return new Promise((resolve, reject) =>	{																			// Wrap the call in a promise
		pool.getConnection()
		.then(conn => {
			let query = `call put_incident_submission(@OutputID,?,?)`
			let params = cleanParams([
				incidentId,
				submissionHeaderID
			])
			logIt("INSERTING IncidentSubmissions",query,"debuginfo")
		  	conn.query(query, params)
			.then(rows => { 
				return rows
			})
			.then(res => { 
				logIt("Incident ID = ", res[0][0].ID)
				logIt("InsertIncidentSubmissions() Response", JSON.stringify(res),'debuginfo')
				conn.release() // release to pool
				resolve(res[0][0].ID)
			})
			.catch(err => {
				logIt("InsertIncidentSubmissions() error", JSON.stringify(err))
				  conn.release() // release to pool
				  resumeFeed("INCIDENT SUBMISSION ERROR")
			})
			
		}).catch(err => {
		  logIt("InsertIncidentSubmissions() connection Error", JSON.stringify(err))
		  resumeFeed("INCIDENT SUBMISSION CONNECTION ERROR")
		})
	}).catch((err)=>{
		  logIt("Incident Submission Promise Error", JSON.stringify(err))
		  resumeFeed("INCIDENT SUBMISSION PROMISE ERROR")
	}) // End Promise
		

}

function checkForImage(imageName, fieldKey) {
	let imgNameArray = imageName.split("|")
	if(imgNameArray.length > 1) {
		if(imgNameArray[1] === fieldKey) {
			return true
		}
		else {
			return false
		}
	}
}

function ExplodeTopLevelFormData(submissionDetailID, formelements, arrAttachments)	{
	// Save the Submission Detail as a child of the XML detail record.  
	// INPUT:	submissionDetailID - Submission XML Detail record
	//		:	formelements - submitted form data
	// OUTPUT: true or false.
	// RMR: Return field data for this submission from form definition. 
	//		Exclude HAP and PI form types, they get handled seperately
	//		Exclude Header and Duration Sections.
	let strPhotoPointer = ''
	logIt(`Insert form Explode Fields: submissionDetailID= ${submissionDetailID}`,"")

	return new Promise((resolve, reject) =>	{
		pool.getConnection()
		.then(conn => {
		logIt("Retrieving Form Details", submissionDetailID)
		  let query = `call getFormDefinitionFromDetailID(?)`
			let params = cleanParams([
				submissionDetailID
			])
			conn.query(query, params).then(rows => { 
				return rows
			})
			.then(res => { 
				res[0].forEach((fieldList, index)=>{
					let fieldCursorValue = null
					if(fieldList.fieldType === 'MultiPhotoPicker')	{	// Is this a photo field?
						// Locate the submitted element and save the value
						let origCursorValue = null
						for (var ptrSubmit in formelements)	{	
							if(checkForImage(ptrSubmit, fieldList.fieldKey) && ptrSubmit.indexOf('_comment') == -1)	{	// Does this element contain our  photo element 'root'
								arrAttachments[ptrSubmit] = formelements[ptrSubmit]	// Store the image name and data
								origCursorValue = ptrSubmit	
								let imgComments = formelements[`${ptrSubmit}_comment`]
								logIt("Parent Photo Found: ", origCursorValue)	// Copy the value
								insertAttachments(formelements[ptrSubmit],origCursorValue).then((newCursorValue)=>{
									writeSubmissionDetailExplode(submissionDetailID, fieldList.ID, newCursorValue.filename, newCursorValue.timestamp, imgComments,formelements.submittedby)
								})
							}
						}
					}
			// BOB:20200314-15:44 - Replace pipe symbol in multiselects with comma's.
				if(fieldList.fieldType === 'GlobalListPicker' && fieldList.AllowMultiple) {	
					// BOB:20191004 - Is this row a multiselect?
					// RMR:20190916 - This function will take the value from the Multiselect fields and parse into Separate Entries in the Explode Table
					//  when there is no value it will put in NULL
					// RMR:20201007 - This code block was inlined as the database save could be mistargeted depending on the caller.
 					let multiValue = formelements[fieldList.fieldKey]	// Copy the value
					if(multiValue)	{	// Do we have a value?
						let multiList = multiValue.split('|')
					// Split the string on the pipe into an array
						multiList.forEach((multiCursorValue)=> {	//	Iterate for each array elem
							if(multiCursorValue) {
								writeSubmissionDetailExplode(submissionDetailID, fieldList.ID, multiCursorValue, null)	// Save the parsed row
								fieldCursorValue = multiCursorValue	// ensure we don't duplicate the source data during save.
							}
						})
					} 
					else {
					// If value is non-true, it will be handled below as a null value.
						writeSubmissionDetailExplode(submissionDetailID, fieldList.ID, null, null);	// Save the parsed row
					}
				}// RMR: 20190424 - Add code block to handle signature submissions as file attachments.
				 else if(fieldList.fieldType === 'SignatureCapture')	{											// Is this a Signature field?
					// Locate the submitted element and save the value
				    logIt("Signature Found", fieldList.fieldKey)
					for (var ptrSubmit in formelements)	{															// Iterate over the submission elements
						if(ptrSubmit.indexOf(fieldList.fieldKey) > -1 && ptrSubmit.substring(ptrSubmit.length - 8) !== "img_time" && ptrSubmit.indexOf('_comments') == -1)	{// Does this element contain our  photo element 'root'
							let sigComments = formelements[`${ptrSubmit}_comments`]
							logIt("comment", sigComments)
							logIt("image Time", formelements[`${ptrSubmit}_img_time`])

							fieldCursorValue = ptrSubmit	
							if(ptrSubmit === fieldList.fieldKey) { // Copy the value
								insertAttachments(formelements[ptrSubmit],"").then((fieldCursorValue)=>{
									writeSubmissionDetailExplode(submissionDetailID, fieldList.ID, fieldCursorValue.filename, formelements[`${ptrSubmit}_img_time`], sigComments,formelements.submittedby)
								});// Pass in the submit, and the value
								
							}
						}
					}
				}

				//BOB:20191010 - If it is any other type of field, or a select box with no multi select capability, handle it normally
				else if(!fieldCursorValue)	{	// If we don't have a value, its not a type defined above
					if(formelements.hasOwnProperty(fieldList.fieldKey))	{	// Does the form submit have this field defined as a property?
						fieldCursorValue = formelements[fieldList.fieldKey]	// Extract the value for this form field

						//If SingleLineEntryAlpha trim value to max length of 200
						if(fieldList.fieldType === 'SingleLineEntryAlpha')
							fieldCursorValue = fieldCursorValue.substring(0, 200);

							logIt(`Explode Field:  ${fieldList.fieldKey}:   -> Value:`, fieldCursorValue)
						writeSubmissionDetailExplode(submissionDetailID, fieldList.ID, fieldCursorValue, null);  // Save the value
					} 
					else {
					  	logIt(`ExplodeTopLevelFormData(): form field: ${fieldList.fieldKey} not found in submitted dataset`,'', 'debuginfo');
					}
				} 
				else {
					logIt('No Explode Field Value:', fieldCursorValue, 'debuginfo');
				}
					logIt("ExplodeIndex fieldList", index , 'debuginfo')
				 })
				conn.release(); // release to pool
				resolve(submissionDetailID)
			})
			.catch(err => {
				logIt("Explode Data Query error", JSON.stringify(err))
				  conn.release(); // release to pool
				  resumeFeed("SUBMISSION DETAIL EXPLODE ERROR")
			})
			
		}).catch(err => {
		  logIt("DB Not Connected in Explode", JSON.stringify(err))
		  resumeFeed("SUBMISSION DETAIL EXPLODE CONNECTION ERROR")
		});
	}).catch((err)=>{
			logIt("Submission Explode Error", JSON.stringify(err))
			resumeFeed("SUBMISSION DETAIL EXPLODE PROMISE ERROR")
	  })
}

function writeSubmissionDetailExplode(submissionDetailID, fieldCursorKey, fieldCursorValue, picData, comment='', user)	{
	// RMR:20201007 - Addition
	// Save a row into SubmissionDetailExplode, this formerly was handled within the function.
	// The requirement to generate multiple rows from multiselect nescessatated moving it out of function to be called as a separate function.
	// INPUT: submissionDetailID = Foriegn key to parent
	// fieldCursorKey = name of key value
	// fieldCursorValue = value of key field
		logIt(`writeSubmissionDetailExplode: submissionDetailID (${submissionDetailID}, ${fieldCursorKey}, ${fieldCursorValue})`,'', 'debuginfo');
		pool.getConnection()
		.then(conn => {
			logIt("Insert Explode Details: ",submissionDetailID,'debuginfo')
			let finalValue = fieldCursorValue ? replace_apostrophe(fieldCursorValue) : null
			let finalPictureTimestamp =  picData ? picData.substring(0,19) : null
			if(finalPictureTimestamp) {
				logIt("This is the Final Picture Timestamp", finalPictureTimestamp, 'debuginfo')
			}
			let query=`CALL put_submission_details_explode(@ID,?,?,?,?)`
			let params = cleanParams([
				submissionDetailID,
				fieldCursorKey,
				finalValue,
				finalPictureTimestamp
			])
			conn.query(query, params).then(rows => { 
				return rows
			})
			.then(res => { 
				logIt("Submission Details result - Now Adding the comments", res, 'debuginfo')
				if(comment){
					insertCommentsAsync(res[0][0].ID, comment,user,1).then((data) =>{
						conn.release(); // release to pool
					})
				}
				else{
					conn.release(); // release to pool
				}
			})
			.catch(err => {
				logIt("`writeSubmissionDetailExplode: error", err)
				conn.release(); // release to pool
				resumeFeed("WRITE SUBMISSION DETAIL EXPLODE ERROR")
			})
			
		}).catch(err => {
			logIt("Error adding Explode Details", err)
			resumeFeed("WRITE SUBMISSION DETAIL EXPLODE CONNECTION ERROR")
		})
}

function dispatchHAPS(submissionHeaderID, formelements)	{
	// Dispatch any HAP's
	// INPUT:	formelements - submitted  form data
	// OUTPUT: true or false.
	// Dump the extracted values
	logIt(`Check for Hazard Actions : ${submissionHeaderID}`,"")

	return new Promise((resolve, reject) =>	{
		let found = false
		let insertPromiseList = []

		for(let child of formelements['Children'])	{	// If this form contains child data.
			let HAPelements = child.formdata;	// Grab them
			if(HAPelements.hasOwnProperty('hazard_type')) {	// If we got hazard action data, save it
				found = true
				logIt(`Found Hazard Action`,'')
				logIt(`Found HAP Elements`,HAPelements,'debuginfo')
				logIt('Calling insertSubmissionHAPs()','','debuginfo')
				insertPromiseList.push(
					new Promise((resolve, reject) => { 
						insertSubmissionHAPs(submissionHeaderID, HAPelements, formelements.submittedby) // Save the Hazard data
						.then(submissionHAPID => {
							if(HAPelements.action_by_who.includes("|") && HAPelements.is_group==0){ //multiple user individual action
								let submissionEmailList=[]
								for(let submissionHAPid of submissionHAPID){
									submissionEmailList.push(submissionHAPid.email)
									insertSubmissionHAPAttachments(submissionHAPid.id, submissionHAPid.child)
								}
								resolve(submissionEmailList)
							}
							else{
								insertSubmissionHAPAttachments(submissionHAPID.id, submissionHAPID.child)
								resolve(submissionHAPID.email);
							}		
						})
					})
				)
			} 					
		}

		!found ? logIt(`No Hazard Actions Found!`,''):""
		logIt("SUBMISSION HEADER for PID", submissionHeaderID,'debuginfo')

		Promise.all(insertPromiseList).then((values) => { // Wait for all action inserts to finish
			resolve(values.filter(Boolean).join("|"))
		})
	}).catch((err)=>{
		logIt("Dispatch Haps Error", JSON.stringify(err))
		resumeFeed("DISPATCH HAPS ERROR")
	  })
}

function dispatchGeneralActions(submissionHeaderID, formelements)	{
	// Dispatch any HAP's
	// INPUT:	formelements - submitted  form data
	// OUTPUT: true or false.
	// Dump the extracted values
	logIt(`Check for General Actions : ${submissionHeaderID}`,"")
	
	return new Promise((resolve, reject) =>	{
		let found = false
		let insertPromiseList = []

		for(let child of formelements['Children'])	{	// If this form contains child data.
			let GENelements = child.formdata;	// Grab them
			if(GENelements.hasOwnProperty('general_action_by_when')) {
				found = true
				logIt(`Found General Action`,'')
				logIt(`Found General Action Elements`,GENelements,'debuginfo')
				logIt('Calling insertSubmissionGeneralAction','','debuginfo')

				insertPromiseList.push(
					new Promise((resolve, reject) => {
						insertSubmissionGeneralAction(submissionHeaderID, GENelements) // Save the Hazard data
						.then(submissionGAID => {
							if(GENelements.action_by_who.includes("|") && GENelements.is_group==0){ //multiple user individual action
								let submissionEmailList=[]
								for(let submissionGAid of submissionGAID){
									submissionEmailList.push(submissionGAid.email)
									insertSubmissionGeneralActionAttachments(submissionGAid.id, submissionGAid.child)
								}
								resolve(submissionEmailList)
							}
							else{
								insertSubmissionGeneralActionAttachments(submissionGAID.id, submissionGAID.child)
								resolve(submissionGAID.email)
							}		
						})
					})
				)
			}
		}

		!found ? logIt(`No General Actions Actions Found!`,''):""
		logIt("SUBMISSION HEADER ID", submissionHeaderID,'debuginfo')

		Promise.all(insertPromiseList).then((values) => { // Wait for all action inserts to finish
			resolve(values.filter(Boolean).join("|"))
		})
	}).catch((err)=>{
		resumeFeed("DISPATCH GENERAL ACTION ERROR")
		logIt("Dispatch Haps Error", JSON.stringify(err))
	  })
}

function insertSubmissionHAPs(submissionHeaderID, HAPelements, submittedBy)	{
	// Save  the HAPs as a child of the submission header record.  
	// INPUT:	submissionHeaderID - parent submission header id
	// 				HAPelements - form submission data
	// OUTPUT: true or false.
		logIt(`insertSubmissionHAPs(): submissionHeaderID= ${submissionHeaderID}`,"",'debuginfo')
		logIt(`insertSubmissionHAPs(): HAPelements= ${HAPelements}`,"",'debuginfo')

	return new Promise((resolve, reject) =>	{	// Wrap the call in a promise
		pool.getConnection()
		.then(conn => {
			logIt("INSERTING Hazard Action HEADER",submissionHeaderID, 'debuginfo')
			let actionCompletedDate = null
			if(HAPelements.action_completed_date){
				actionCompletedDate = `${HAPelements.action_completed_date}`
			}
			let completedActionType = null
			if(parseValueScore(HAPelements.completed_action_type)){
				completedActionType = `${parseValueScore(HAPelements.completed_action_type)}`
			}
			logIt("Completed Action Type", completedActionType,'debuginfo')
			let completionDate = HAPelements.action_by_when ? HAPelements.action_by_when : null
			logIt("This is the Submitted BY:", submittedBy, 'debuginfo')
			let query = `call put_hazard_action(@OutputID,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
				let params = cleanParams([
					submissionHeaderID,
					HAPelements.hazard_type ? replace_apostrophe(HAPelements.hazard_type) : HAPelements.hazard_type,
					parseValueScore(HAPelements.hazard_identification),
					HAPelements.hazard_identification_score || 0,
					HAPelements.hazard_description ? replace_apostrophe(HAPelements.hazard_description) : HAPelements.hazard_description,
					parseValueScore(HAPelements.potential_risk),
					HAPelements.potential_risk_score || 0,
					HAPelements.immediate_action_required_and_performed || 0,
					HAPelements.immediate_action_taken ? replace_apostrophe(HAPelements.immediate_action_taken) : HAPelements.immediate_action_taken,
					parseValueScore(HAPelements.immediate_action_type) || null,
					HAPelements.immediate_action_score || 0,
					HAPelements.further_action_required || 0,
					HAPelements.recommended_action ? replace_apostrophe(HAPelements.recommended_action) : HAPelements.recommended_action,
					parseValueScore(HAPelements.action_type) || null,
					HAPelements.action_by_who,
					HAPelements.is_group,
					completionDate, 
					HAPelements.action_status,
					HAPelements.action_completed_by_who,
					actionCompletedDate,
					HAPelements.completed_action_taken ? replace_apostrophe(HAPelements.completed_action_taken) : null,
					completedActionType,
					HAPelements.completed_action_score || 0,
					submittedBy
				])

				logIt("insertSubmissionHAPs() Query", query,'debuginfo')
				conn.query(query, params).then(rows => { 
					return rows
				})
				.then(res => {
					logIt("Hazard Action Added: ", res)
					conn.release(); // release to pool
					if(HAPelements.action_by_who.includes("|") && HAPelements.is_group==1){  //multiple user group action
						let emails=[]
						let emailLists=convertReturnValues(res[0][0].emails_ids)
						for(let emailList of emailLists){
							emails.push(emailList.email)
						}
						resolve({
							id: emailLists[0].id,
							email: emails,
							child: HAPelements
						})
					}
					else if(HAPelements.action_by_who.includes("|") && HAPelements.is_group==0){ //multiple user individual action
						let returnIDEmails=[]
						let emailLists=convertReturnValues(res[0][0].emails_ids)
						for(let emailList of emailLists){
							let returnIDEmail={
								id: emailList.id,
								email: emailList.email,
								child: HAPelements
							}
							returnIDEmails.push(returnIDEmail)
						}
						resolve(returnIDEmails)
					}
					else{
						resolve({
							id: res[0][0].ID,
							email: res[0][0].email,
							child: HAPelements
						})
					}
				})
				.catch(err => {
					logIt("insertSubmissionHAPs() Query error", JSON.stringify(err))
					conn.release(); // release to pool
					resumeFeed("INSERT SUBMISSION HAPS ERROR")
				})
			}).catch(err => {
				logIt("Could not Submit HAPS", JSON.stringify(err))
				resumeFeed("INSERT SUBMISSION HAPS CONNECTION ERROR")
				reject(err)
			});
	}).catch(err => {
		logIt("insertSubmissionHAPs() Promise Error", JSON.stringify(err))
		resumeFeed("INSERT SUBMISSION HAPS PROMISE ERROR")
	}) // End Promise
}

function insertSubmissionGeneralAction(submissionHeaderID, GENelements)	{
	// Save  the HAPs as a child of the submission header record.  
	// INPUT:	submissionHeaderID - parent submission header id
	// 				HAPelements - form submission data
	// OUTPUT: true or false.
		logIt(`insertSubmissionGeneral Action(): submissionHeaderID= ${submissionHeaderID}`,"",'debuginfo')
		logIt(`insertSubmissionGeneral Action(): General Action Element= ${GENelements}`,"",'debuginfo')

	return new Promise((resolve, reject) =>	{	// Wrap the call in a promise
		pool.getConnection()
		.then(conn => {
			logIt("INSERTING General Action HEADER",submissionHeaderID, 'debuginfo')
			logIt("Action Type", GENelements.action_type,'debuginfo')
			let completionDate = GENelements.general_action_by_when ? GENelements.general_action_by_when : null
			let query = `call put_general_action(@OutputID,?,?,?,?,?,?,?)`
				let params = cleanParams([
					submissionHeaderID,
					GENelements.action_type,
					GENelements.action_by_who,
					GENelements.is_group,
					completionDate,
					GENelements.recommended_action ? replace_apostrophe(GENelements.recommended_action) : GENelements.recommended_action,
					GENelements.submittedby
				])
				logIt("put_general_action() Query", query,'debuginfo')
				conn.query(query, params).then(rows => { 
					return rows
				})
				.then(res => {
					logIt("General Action Added: ", res)
					conn.release(); // release to pool
					logIt("GENelements.action_by_who ", GENelements.action_by_who)
					if(GENelements.action_by_who.includes("|") && GENelements.is_group==1){  //multiple user group action
						let emails=[]
						let emailLists=convertReturnValues(res[0][0].emails_ids)
						for(let emailList of emailLists){
							emails.push(emailList.email)
						}
						resolve({
							id: emailLists[0].id,
							email: emails,
							child: GENelements
						})
					}
					else if(GENelements.action_by_who.includes("|") && GENelements.is_group==0){ //multiple user individual action
						let returnIDEmails=[]
						let emailLists=convertReturnValues(res[0][0].emails_ids)
						for(let emailList of emailLists){
							let returnIDEmail={
								id: emailList.id,
								email: emailList.email,
								child: GENelements
							}
							returnIDEmails.push(returnIDEmail)
						}
						resolve(returnIDEmails)
					}
					else{
						resolve({
							id: res[0][0].ID,
							email: res[0][0].email,
							child: GENelements
						})
					}
				})
				.catch(err => {
					logIt("insertSubmissionGeneralAction() Query error", JSON.stringify(err))
					conn.release(); // release to pool
					resumeFeed("INSERT GENERAL ACTION ERROR")
				})
			}).catch(err => {
				logIt("Could not Submit General Action", JSON.stringify(err))
				resumeFeed("INSERT GENERAL ACTION CONNECTION ERROR")
				reject(err)
			});
	}).catch(err => {
		logIt("insertSubmissionGeneralAction() Promise Error", JSON.stringify(err))
		resumeFeed("INSERT GENERAL ACTION PROMISE ERROR")
	}) // End Promise
}

function insertSubmissionHAPAttachments(submissionHAPID, HAPelements)	{
	// Save  the PositiveID's attachement as a child of the PositiveID  record.  
	// INPUT: submissionHAPID - Row ID of parent record
	// INPUT: HAPelements - submitted form data
	// OUTPUT: true or false.
		logIt(`insertSubmissionHAPAttachments(): submissionHAPID= ${submissionHAPID}`,"",'debuginfo')
		logIt(`insertSubmissionHAPAttachments(): HAPelements= ${HAPelements}`,"",'debuginfo')

	return new Promise((resolve, reject) =>	{ // Wrap the call in a promise
		let pic = null
		//let fileArray = []
		const arrImageName = ['hazard_attachment', 'completed_action_attachment']	// Arrays to hold form defs for images in HAP
		var strAttachmentType = 'INITIAL'  // Default to initial submissions, not followups

		arrImageName.forEach(function(strImageName)	{	 // Iterate over defined image names
			logIt(`Searching for image name : ${strImageName}`,"",'debuginfo')
			if(arrImageName[strImageName] == 'completed_action_attachment')	 // If were looking for follups, change the form type
				strAttachmentType = 'FOLLOWUP'

			async function loadPictures () {
				let fileArray = []
				for(let ptrCursor in HAPelements)	{	 // Iterate over submissions
					logIt('ptrCursor = :', ptrCursor, 'debuginfo');
					if(checkForImage(ptrCursor, strImageName) && ptrCursor.indexOf('_comment') == -1)	{ // Does this element contain a substring of the image name
						logIt(`Found image form element: `, ptrCursor,'debuginfo')
						pic = ptrCursor
						let fileName = uuidv4()  // Generate a GUID for a filename.
						fileName += '.jpg'   // Indicate its a jpg file
						logIt(`Generated filename: ${attachmentPath}  ${fileName}`,"")
						let theImageBase64 = HAPelements[ptrCursor]	 // Copy the image from the form data
						let data = theImageBase64.replace(/^data:image\/\w+;base64,/, "")  // Strip the header
						let buf = new Buffer.from(data, 'base64')	 // Copy the data into a buffer that is accessible to the file system with a type
						let finalPictureTimestamp =  pic ? pic.substring(0,19) : null
						let imageComment = HAPelements[`${ptrCursor}_comment`] ? HAPelements[`${ptrCursor}_comment`] : ""
						try{
							// Get a list of the Queries for when we add to the DB
							fileArray.push({
								submissionHAPID: submissionHAPID,
								filename: fileName,
								attachmentType: strAttachmentType,
								picTimestamp: finalPictureTimestamp,
								comment: imageComment,
								user: HAPelements['submittedby']
							})
							fs.writeFileSync(attachmentPath + fileName, buf)
							logIt(`Hazard Action Image Saved to File:  (${fileName})`,'');
						} catch(err) {
							logIt("Could not Save HAP Image",JSON.stringify(err))
							resumeFeed("HAP ATTACHMENT PROMISE ERROR")
						}
					} 
				}
				return fileArray
				// End formelement loop
			}

			loadPictures().then((res)=>{
				res.forEach((q)=>{
					try{
						//	Save the file name to the db, and, the image to the file system.
						pool.getConnection()
						.then(conn => {
							logIt("Insert HAP Attachment", q.filename)
							let finalPictureTimestamp =  q.picTimestamp ? q.picTimestamp : null
							let comment = q.comment ? replace_apostrophe(q.comment) : ''
							let per_id = q.user ? q.user : 1
							let query = `call put_hap_attachment(@ID,?,?,'',?,1,?,?,?,?)`
							let params = cleanParams([
								q.submissionHAPID,
								q.filename,
								q.attachmentType,
								finalPictureTimestamp,
								comment,
								per_id,
								null
							])
							conn.query(query, params)
							.then(rows => { 
								return rows
							})
							.then(res => { 
								logIt("Hap Image Inserted", JSON.stringify(res), 'debuginfo')
								conn.release(); // release to pool
								resolve(true)
							})
							.catch(err => {
								logIt("HAP Attachment SQL Error", err)
								conn.release(); // release to pool
								resumeFeed("HAP ATTACHMENT ERROR")
							})
						}).catch(err => {
							logIt("Hap Attachment Could not Connect to Maria", JSON.stringify(err))
							resumeFeed("HAP ATTACHMENT CONNECTION ERROR")
							reject(err)
						})	
	
					} catch(err) {
						logIt("Could not Save HAP Image",JSON.stringify(err))
						resumeFeed("HAP ATTACHMENT PROMISE ERROR")
					}
				})
				
				// End Imagename loop
				logIt(`No more images found`,"", 'debuginfo');	// Indicate we successfully handled image submissions
				resolve(true)
			})
		})
	}).catch((err)=>{
			logIt("HAP Attachments Promise Error", JSON.stringify(err))
	})
}

function insertSubmissionGeneralActionAttachments(submissionGENID, GENelements)	{
	// Save  the General Actions attachement as a child of the General Action  record.  
	// INPUT: submissionGENID - Row ID of parent record
	// INPUT: GENelements - submitted form data
	// OUTPUT: true or false.
		logIt(`insertSubmissionGeneralActionAttachments: submissionHAPID= ${submissionGENID}`,"",'debuginfo')
		logIt(`insertSubmissionGeneralActionAttachments: GENelements= ${GENelements}`,"",'debuginfo')

	return new Promise((resolve, reject) =>	{ // Wrap the call in a promise
		let pic = null
		const arrImageName = ['general_action_images', 'completed_general_action_images']	
		var strAttachmentType = 'INITIAL' 
		arrImageName.forEach(function(strImageName)	{	
			logIt(`Searching for image name : ${strImageName}`,"",'debuginfo')
			if(arrImageName[strImageName] === 'completed_general_action_images')
				strAttachmentType = 'FOLLOWUP'

			async function loadPictures() {
				let fileArray = []
				for(let ptrCursor in GENelements) {
					logIt('ptrCursor = :', ptrCursor, 'debuginfo');
					if(checkForImage(ptrCursor, strImageName) && ptrCursor.indexOf('_comment') == -1)	{
						logIt(`Found image form element: `, ptrCursor,'debuginfo')
						pic = ptrCursor
						let fileName = uuidv4()  
						fileName += '.jpg'  
						logIt(`Generated filename: ${attachmentPathGeneralAction}${fileName}`,"")
						let theImageBase64 = GENelements[ptrCursor]	 
						let data = theImageBase64.replace(/^data:image\/\w+;base64,/, "")  
						let buf = new Buffer.from(data, 'base64')
						let imageComment = GENelements[`${ptrCursor}_comment`] ? GENelements[`${ptrCursor}_comment`] : ""
						let finalPictureTimestamp =  pic ? pic.substring(0,19) : null
						// Get a list of the Queries for when we add to the DB
						fileArray.push({
							submissionGENID: submissionGENID,
							filename: fileName,
							strAttachmentType: strAttachmentType,
							submittedBy: GENelements.submittedby,
							picTimestamp: finalPictureTimestamp,
							comment: imageComment
						})
						try{
							fs.writeFileSync(`${attachmentPathGeneralAction}${fileName}`, buf)  
							logIt(`General Action Image Saved to File:  (${fileName})`,'');
						
						} catch(err) {
							logIt("Could not Save General Action Image",JSON.stringify(err))
							resumeFeed("GENERAL ATTACHMENT CONNECTION ERROR")
						}
					} 
				}// End formelement loop
				return fileArray
			}

			loadPictures().then((res)=>{
				res.forEach((q)=>{
					try{
						// Save the file name to the db, and, the image to the file system.
						logIt("Insert General Action Attachment", q.filename)
						let finalPictureTimestamp =  q.picTimestamp ? q.picTimestamp : null
						let comment = q.comment ? replace_apostrophe(q.comment) : ''
						let query = `call put_gap_attachment(@ID,?,?,?,?,?,?,?)`
						let params = cleanParams([
							q.submissionGENID,
							q.filename,
							comment,
							q.strAttachmentType,
							q.submittedBy,
							finalPictureTimestamp,
							null
						])
						logIt("This is the Query for the General Attachment", query, 'debuginfo')
						pool.getConnection()
						.then(conn => {
							conn.query(query, params)
							.then(rows => {
								return rows
							})
							.then(res => {
								logIt("General Action Image Inserted", JSON.stringify(res), 'debuginfo')
								conn.release(); // release to pool
								resolve(true)
							})
							.catch(err => {
								logIt("General Action Attachment SQL Error", err)
								conn.release(); // release to pool
								resumeFeed("GENERAL ATTACHMENT ERROR")
							})
						}).catch(err => {
							logIt("General Action Attachment Could not Connect to Maria", JSON.stringify(err))
							resumeFeed("GENERAL ATTACHMENTCONNECTION ERROR")
							reject(err)
						})			
					} catch(err) {
						logIt("Could not Save General Action DB Entries",JSON.stringify(err))
						resumeFeed("GENERAL ATTACHMENT CONNECTION ERROR")
					}
				})
				logIt(`No more images found`,"", 'debuginfo');	// Indicate we successfully handled image submissions
				resolve(true)
			})
		})
	}).catch((err)=>{
		logIt("General Action Attachments Promise Error", JSON.stringify(err))
		resumeFeed("GENERAL ATTACHMENT CONNECTION ERROR")
	})
}

function dispatchPositiveIDs(submissionHeaderID, formelements)	{
	logIt("Check for Positive Identification : ", submissionHeaderID)
	// Dispatch any positive ID's
	// INPUT:	formelements - submitted  form data
	// OUTPUT: true or false.
	return new Promise((resolve, reject) =>	{
		let found = false
		for(let child of formelements['Children'])	{	// If this form contains child data.
			let childelements = child.formdata	// Extract the unique child record from the array Grab them

			if(childelements.hasOwnProperty('recognition_type')) {	 // If we got positive id data, save it.
				found = true
				logIt(`Found Positive ID form data`,"","debuginfo")
				logIt("Child Elements", childelements, "debuginfo")
				let submissionPositiveIDID = null
				InsertPositiveIDs(submissionHeaderID, childelements)  // Promise chain to save positiveid's
				.then(function(response){
					submissionPositiveIDID = response  // Extract the ID of the PositiveID return the id of the new row.
					logIt('InsertPositiveIDs returned = ', submissionPositiveIDID.id, "debuginfo")
					sendPositiveRecognitionEmail(submissionPositiveIDID.id)
				}).then(function(response){	// Handle any attachments on the child
					insertPositiveIDAttachments(submissionPositiveIDID.id, submissionPositiveIDID.child)
				})
			} 
		}
		!found ? logIt(`No Positive ID Found!`,''):""
		resolve(true);
	}).catch((err)=>{
		logIt("PID Dispatch Promise Error", JSON.stringify(err))
		resumeFeed('PID DISPATCH PROMISE ERROR')
	  }) // End Promise
}

function InsertPositiveIDs(submissionHeaderID, childelements)	{	// Positive Actions get saved to unique table.
	// Save  the PositiveID's as a child of the XML detail record.  
	// INPUT:	childelements - submitted  child form data
	// OUTPUT: PIDID and childelements
	logIt("Insert Positive ID",submissionHeaderID)
	logIt(`InsertPositiveIDs(): childelements= ${childelements}\r\n`,"","debuginfo")
	return new Promise((resolve, reject) =>	{	// Wrap the call in a promise
		pool.getConnection()
		.then(conn => {
			logIt("Insert Positive ID", submissionHeaderID ,"debuginfo")
			let query = 
			`call put_positive_recognition(@OutputID,?,?,?,?,?)`
			let params = cleanParams([
				submissionHeaderID,
				childelements.recognition_type,
				childelements.event_description ? replace_apostrophe(childelements.event_description) : childelements.event_description,
				parseInt(childelements.was_recognition_given, 10) || 0,
				childelements.recognition_given_type ? replace_apostrophe(childelements.recognition_given_type) : childelements.recognition_given_type
			])
			conn.query(query, params)
			.then(rows => { 
				return rows
			})
			.then(res => { 
				logIt("Positive ID added: ",res[0][0].ID)
				let submissionPositiveIDID = res[0][0].ID;// Extract and assign the ID
				logIt(`InsertPositiveIDs:ID = ${submissionPositiveIDID}\r\n`,"","debuginfo")
				let arrRecognition = childelements.recognition_of.split('|')	// We receive the data pipe delimited, so split it.

				let positiveIDPersonPromiseList = []

				arrRecognition.forEach((ptrCursor)	=> { // Iterate over the resulting array
					positiveIDPersonPromiseList.push(insertPositiveIDPerson(ptrCursor, submissionPositiveIDID))
				})
				conn.release(); // release to pool
				Promise.all(positiveIDPersonPromiseList).then((values) => { // Wait for all person records to finish
					resolve({id:submissionPositiveIDID , child:childelements})
				})				
			})
			.catch(err => {
				logIt("Insert Positive People error", JSON.stringify(err))
				resumeFeed('PID PEOPLE PROMISE ERROR')
			  	conn.release(); // release to pool
			})
		}).catch(err => {
			resumeFeed()
		  reject(err)
		});
	}).catch((err)=>{
		resumeFeed()
		logIt("Insert Positive ID Connection error", JSON.stringify(err))
	}) // End Promise
}

function insertPositiveIDPerson(ptrCursor, submissionPositiveIDID) {
	return new Promise((resolve, reject) =>	{	// Wrap the call in a promise
		logIt(`InsertPositiveIDRecognition(): ptrCursor = ${ptrCursor}\r\n`,"","debuginfo")
		pool.getConnection()
		.then(conn => {
		logIt("Insert Positive ID People", submissionPositiveIDID)
		let query = `call putPositiveRecognition(@ID,?,?)`					
			let params = cleanParams([
				submissionPositiveIDID,
				ptrCursor
			])
			conn.query(query, params)
			.then(res => { 
				logIt("PID People", JSON.stringify(res),"debuginfo")
				conn.release(); // release to pool
				resolve(true)
			})
			.catch(err => {
				logIt("PID People SQL error", JSON.stringify(err))
				conn.release(); // release to pool
				reject(err)
			})
		}).catch(err => {
			logIt("Insert positive ID Person SQL Error", JSON.stringify(err))
			resumeFeed('PID PEOPLE ERROR 2')
			reject(err)
		});
	})
}

function insertPositiveIDAttachments(submissionPositiveID, formelements)	{
	// Save  the PositiveID's attachement as a child of the PositiveID  record.  
	// INPUT: submissionPositiveID - Row ID of parent record
	// INPUT:	formelements - submitted form data
	// OUTPUT: true or false.
	logIt(`insertPositiveIDAttachments(): submissionPositiveID= ${submissionPositiveID}`,"","debuginfo")

	return new Promise((resolve, reject) =>	{	// Wrap the call in a promise
		let pic = null
		let fileArray = []
		async function loadPictures () {
			for(let ptrCursor in formelements)	{	// Iterate over submissions
				logIt('PID Attachments ptrCursor = :', ptrCursor,"debuginfo")
				if(ptrCursor.indexOf('positive_id_multiphoto_picker') > -1 && ptrCursor.indexOf('_comment') == -1)	{	// is the photoname embedded in this form element
					logIt(`Found image form element:`, ptrCursor)
					let imageComment = formelements[`${ptrCursor}_comment`] ? formelements[`${ptrCursor}_comment`] : ""
					pic = ptrCursor
					let fileName = uuidv4()  // Generate a GUID for a filename.
					fileName += '.jpg'  // All image submissions will be JPG
					logIt(`Generated filename: ${attachmentPath}  ${fileName}`,"")
					let theImageBase64 = formelements[ptrCursor]  // Copy the image data
					let data = theImageBase64.replace(/^data:image\/\w+;base64,/, "") // Strip the data header then
					let buf = new Buffer.from(data, 'base64')  // Create a buffer converting from Base64 to Binary
					let finalPictureTimestamp =  pic ? pic.substring(0,19) : null
					// Get a list of the Queries for when we add to the DB
					fileArray.push({
						submissionPositiveID: submissionPositiveID,
						filename: fileName,
						picTimestamp: finalPictureTimestamp ,
						comment: imageComment,
						user: formelements['submittedby']
					})

					try{
						fs.writeFileSync(attachmentPath + fileName, buf)  // Save the file synchronosly
						logIt(`Positive Recognition Image Saved to File:  (${fileName})`,'');

					} catch(err) {
						logIt("Error Writing Positive Id Attachment File", JSON.stringify(err))
						resumeFeed("PID ATTACHMENT PROMISE ERROR")
					}
				}	// End fieldType PhotoPicker
			}	// End loop
		}
		loadPictures().then((res) =>{
			fileArray.forEach((q)=>{
				try{
					pool.getConnection()
						.then(conn => {
							logIt("Insert Positive ID Attachment",submissionPositiveID, 'debuginfo')
							let finalPictureTimestamp =  q.picTimestamp ? q.picTimestamp : null
							let comment = q.comment ? replace_apostrophe(q.comment) : ''
							let per_id = q.user ? q.user : 1
							let query = `call put_positive_id_attachment(@ID,?,?,'',?,?,?)`
							let params = cleanParams([
								q.submissionPositiveID,
								q.filename,
								finalPictureTimestamp,
								comment,
								per_id
							])
							conn.query(query, params)
							.then(rows => { 
								return rows
							})
							.then(res => { 
								logIt('PID Attachment:',q.filename )
								logIt("PID Attachments successful", JSON.stringify(res),'debuginfo')
								conn.release(); // release to pool
								resolve(true)
							})
							.catch(err => {
								logIt("Positive ID Attachment Sql Error", JSON.stringify(err))
								conn.release() // release to pool
								resumeFeed("PID ATTACHMENT ERROR")
							})
						}).catch(err => {
							logIt("Insert PID Attachment SQL Connection Error", JSON.stringify(err))
							resumeFeed("PID ATTACHMENT CONNECTION ERROR")
							reject(err)
						})
				} catch(err) {
						logIt("Could not Save HAP Database Entries",JSON.stringify(err))
						resumeFeed("HAP ATTACHMENT PROMISE ERROR")
				}
			})
			logIt(`No more images found`,"","debugimfo")
			resolve(true)
		})
    // Return success in the promise	
	}).catch((err)=>{
		logIt("Insert Positive ID Attachments Error", JSON.stringify(err))
		resumeFeed("PID ATTACHMENT PROMISE 2 ERROR")
	  })
}

function parseValueScore(strValue)	{
	// Parse out index value from  Index,Score tuple
	// INPUT: strValue = Parse out index part of tuple
	let intIndex = null;																															// Always return at least a NULL
	if(strValue.indexOf('|') > -1)	{																							// If we have a delimiter
		let arrTuple = strValue.split('|');																						// Split on it
		intIndex = arrTuple[0];																											// Extract the index portion of the tuple
	}
	return intIndex ? replace_apostrophe(intIndex) : intIndex;																															// Return index or null
}

function getRuntimeConfig()	{
	// // Read in our environment configuration
    logIt("Config Path: ",  configLocation + 'config.env')
	dotenv.config({ path: configLocation + 'config.env' });
}

function insertCommentsAsync(id,comment,user, comment_id)	{
	return new Promise((resolve, reject) =>	{
		pool.getConnection()
		.then(conn => {
			let commParams = cleanParams([
				comment_id,
				id,
				replace_apostrophe(comment),
				user
			])
			let query = "call add_comment(?,?,?,?)"

			logIt("Comments Master Query", query ,'debuginfo')
			conn.query(query, commParams).then((data)=>{
				conn.release()
				resolve(true)
			}).catch((err)=>{
				logIt("Comment Error Inserting into comment table", JSON.stringify(err))
				conn.release()
				resumeFeed("Comment Insert ERROR")
			})
		}).catch((err)=>{
			logIt("Comment Error connecting to pool", JSON.stringify(err))
			conn.release()
			resumeFeed("Comment connection ERROR")
		})
	}).catch((err)=>{
		logIt("insertAttachmentsAsync Error", JSON.stringify(err))
		resumeFeed("INSERT comments ASYNC ERROR")
	})
}

function insertAttachments(fileelement, timestamp) {
    // Save  the attachement(s) as a child of the submission  record.  
    // INPUT:       fileelement - submitted form element
    // OUTPUT: true or false.
	let theImageBase64 = fileelement     // Copy the image data
	return new Promise((resolve, reject) =>	{
    if(theImageBase64.length > 0) {
        let fileName = uuidv4()  // Generate a GUID for a filename.
        fileName += '.jpg'   // All image submissions will be JPG
		logIt(`Generated filename : ${attachmentPath}${fileName}`,"")
        let data = theImageBase64.replace(/^data:image\/\w+;base64,/, "")   // Strip the data header then
        var buf = new Buffer.from(data, 'base64')  // Create a buffer converting from Base64 to Binary

			fs.writeFileSync(attachmentPath + fileName, buf, function(err)  {
				if(err) {
					logIt("Writing Attachment File Error",JSON.stringify(err))
					reject(err)
				}
			})
			logIt(`Image Scanned Saved to File:  (${fileName})`,'');
			resolve({"filename": fileName, "timestamp": timestamp})
		}
	})
}

function insertAttachmentsAsync(fileelement, picfilename, rowid, per_id, comment,AttachmentType,haa_hac_id)	{
	// Save  the attachement(s) as a child of the submission  record Asynchronously.  
	// INPUT:		fileelement - submitted form element
	// OUTPUT: true or false.
	let picquery = ""
	let finalPictureTimestamp =  picfilename ? picfilename.substring(0,19) : null
	finalPictureTimestamp = finalPictureTimestamp.substring(0,3) === 'sig' ? null : finalPictureTimestamp
	logIt("Insert Async Insert Attachments","")
	logIt("Insert Async Insert Attachments",haa_hac_id)
	return new Promise((resolve, reject) =>	{
		var fileName = uuidv4()	  // Generate a GUID for a filename.
		fileName += '.jpg'	// All image submissions will be JPG
		logIt(`Generated filename: ${attachmentPath}  ${fileName}`,"")
		var theImageBase64 = fileelement   // Copy the image data
		let data = theImageBase64.replace(/^data:image\/\w+;base64,/, "")	// Strip the data header then
		var buf = new Buffer.from(data, 'base64')	// Create a buffer converting from Base64 to Binary
		fs.writeFileSync(attachmentPath + fileName, buf, function(err)	{
			if(err)	{
				logIt("Error Writing Async Insert Attchments",JSON.stringify(err))
				return (err)
			}
		})
		logIt(`Image Saved to File:  (${fileName})`,'');
		finalPictureTimestamp =  finalPictureTimestamp ? finalPictureTimestamp : null
		picquery = `call put_hap_attachment(@ID,?,?,'',?,1,?,?,?,?)`
		let params = cleanParams([
			rowid,
			fileName,
			AttachmentType,
			finalPictureTimestamp,
			comment,
			per_id,
			haa_hac_id
		])
		logIt("Followup Picture Entry Query", picquery,"debuginfo")
		pool.getConnection().then(connupdate => {
			connupdate.query(picquery,params)
			.then(rows => { 
				return rows
			})
			.then(res => { 
				logIt("Followup Attachments ROWS Hazard Action Complete", JSON.stringify(res))
				connupdate.end()
				resolve({filename:fileName, picName:finalPictureTimestamp, id:res[0][0]})

			})
			.catch(err => {
				logIt("Followup Picture Entry Query error", JSON.stringify(err))
				resumeFeed("PUT HAP UPDATE ERROR")
				// release to pool
				connupdate.end()
			})
		}).catch((err)=>{
			logIt("insertAttachmentsAsync Error", JSON.stringify(err))
			resumeFeed("INSERT ATTACHMENT ASYNC ERROR")
		})
	}).catch((err)=>{
		logIt("insertAttachmentsAsync PROMISE Error", JSON.stringify(err))
		resumeFeed("INSERT ATTACHMENT PROMIMSE ASYNC ERROR")
	})
}

function insertGeneralActionAttachmentsAsync(fileelement, picfilename, rowid, personId, comment,gaa_type,gaa_gac_id)	{
	// Save  the attachement(s) as a child of the submission  record Asynchronously.  
	// INPUT:		fileelement - submitted form element
	// OUTPUT: true or false.
	let picquery = ""
	let finalPictureTimestamp =  picfilename ? picfilename.substring(0,19) : null
	finalPictureTimestamp = finalPictureTimestamp.substring(0,3) === 'sig' ? null : finalPictureTimestamp
	logIt("Insert Async Insert Attachments","")
	return new Promise((resolve, reject) =>	{
		var fileName = uuidv4()	  // Generate a GUID for a filename.
		fileName += '.jpg'	// All image submissions will be JPG
		logIt(`Generated filename: ${attachmentPathGeneralAction}  ${fileName}`,"")
		var theImageBase64 = fileelement   // Copy the image data
		let data = theImageBase64.replace(/^data:image\/\w+;base64,/, "")	// Strip the data header then
		var buf = new Buffer.from(data, 'base64')	// Create a buffer converting from Base64 to Binary
		fs.writeFileSync(`${attachmentPathGeneralAction}${fileName}`, buf, function(err)	{	// Save the file to the filesystem
			if(err)	{
				logIt("Error Writing Async Insert Attchments",JSON.stringify(err))
				return (err)
			}
		})
		logIt(`General Action Image Saved to File:  (${fileName})`,'');
		finalPictureTimestamp =  finalPictureTimestamp ? finalPictureTimestamp : null
		picquery = `call put_gap_attachment(@ID,?,?,?,?,?,?,?)`
		let params = cleanParams([
			rowid,
			fileName,
			comment,
			gaa_type,
			personId,
			finalPictureTimestamp,
			gaa_gac_id
		])
		logIt("Followup Picture Entry Query", picquery,"debuginfo")
		pool.getConnection().then(connupdate => {
			connupdate.query(picquery, params)
			.then(rows => { 
				return rows
			})
			.then(res => { // res: { affectedRows: 1, insertId: 1, warningStatus: 0 }
				logIt("Followup Attachments ROWS General Action Complete", JSON.stringify(res))
				connupdate.end()
				resolve({filename:fileName, picName:finalPictureTimestamp, id:res[0][0].ID})
			//	return file.filename
			})
			.catch(err => {
				logIt("Followup Picture Entry Query error", JSON.stringify(err))
				resumeFeed("PUT GAP UPDATE ERROR")
				connupdate.end(); // release to pool
			})
		}).catch(err => {
				logIt("Followup Picture Entry Connection  error", JSON.stringify(err))
				resumeFeed("PUT GAP Connection ERROR")
				connupdate.end(); // release to pool
		})
		//resolve(fileName)
	}).catch((err)=>{
		resumeFeed("INSERT GENERAL ATTACHMENT ASYNC ERROR")
		logIt("insertAttachmentsAsync Error", JSON.stringify(err))
	})
}

function insertPREOPAttachments(fileelement, picfilename)	{
	// Save  the attachement(s) as a child of the submission  record.  
	// INPUT:		fileelement - submitted form element
	// OUTPUT: true or false.
	let finalPictureTimestamp =  picfilename ? picfilename.substring(0,19) : null
	finalPictureTimestamp = finalPictureTimestamp.substring(0,3) === 'sig' ? null : finalPictureTimestamp
	logIt("Insert Preop Attachment","",'debuginfo')
	return new Promise((resolve, reject) =>	{	
        let fileName = ""
		var theImageBase64 = fileelement  // Copy the image data
		if(theImageBase64.length > 0) {
			fileName = uuidv4();	 // Generate a GUID for a filename.
			fileName += '.jpg'	 // All image submissions will be JPG
			logIt(`Generated filename: ${attachmentPath}${fileName}`,"","debuginfo")
			let data = theImageBase64.replace(/^data:image\/\w+;base64,/, "")	 // Strip the data header then
			var buf = new Buffer.from(data, 'base64')	// Create a buffer converting from Base64 to Binary

			fs.writeFileSync(attachmentPath + fileName, buf, function(err)	{	 // Save the file to the filesystem
				if(err)	{
					logIt("Error Writing PreOP Attachment to File", JSON.stringify(err))
					return (err);
				}
			})
			logIt(`Preop Image Saved to File:  (${fileName})`,'');
			resolve({filename:fileName, picName:finalPictureTimestamp})
		}
		else {
			reject(null)
		}
	}).catch((err)=>{
		resumeFeed("INSERT PREOP ATTACHMENT ERROR")
		logIt("InsertPREOPAttachments Error", JSON.stringify(err))
	})
}

function putHAPUpdate(formelements,SubCompleted)	{
	// Update an existing Hazard Action Protocol form submission with completed process data.
	// OUTPUT: Success = true/false
	// RMR: 20200325 - Added
	logIt('PutHAPUpdate()',"");
	logIt(`putHAPUpdate(): SubmissionHAPID = `,formelements.rowid,"debuginfo")
	logIt(`putHAPUpdate(): completed_by_who = `, formelements.action_complete_by_who,"debuginfo")
	logIt(`putHAPUpdate(): completed_date = `,formelements.action_completed_date,"debuginfo")
	logIt(`putHAPUpdate(): completed_action_type = `, formelements.completed_action_type,"debuginfo")
	logIt(`putHAPUpdate(): completed_action_taken = `, formelements.completed_action_taken,"debuginfo")
	return new Promise((resolve, reject) =>	{	// Wrap the call in a promise
       	logIt('In promise putHAPUpdate()',"");		
		   let AttachmentType=null
		   if(SubCompleted)	{
			   AttachmentType="FOLLOWUP2"
		   }
		   else{
			   AttachmentType="FOLLOWUP"
		   }
		pool.getConnection()
		.then(connupdate => {
			logIt("Update Rowid",formelements.rowid)
			let query = `call putHAPUpdate(@OutputID,?,?,?,?,?,0,?,?)`
			let params = cleanParams([
				formelements.rowid, 
				formelements.action_complete_by_who, 
				formelements.action_completed_date, 
				replace_apostrophe(formelements.completed_action_taken),
				formelements.completed_action_type,
				formelements.hapSubmmitedBy,
				SubCompleted
			])
			logIt("Hap Update Query", query,"debuginfo")
			let hapCompletion=connupdate.query(query, params).then((res)=>{				
				connupdate.end()
				return res[0][0].OutputID
			})
			return hapCompletion
			}).then(res => { 
					logIt("HAP Update Result", res)
					let haa_hac_id=res
					Object.keys(formelements).forEach(function(rec){
						logIt("ITEM: ", rec , "debuginfo")
						if(rec.indexOf('actionphoto') > -1 && rec.indexOf('_comment') == -1)	{
							insertAttachmentsAsync(formelements[rec], rec,formelements.rowid,formelements.action_complete_by_who,formelements[`${rec}_comment`],AttachmentType,haa_hac_id).then((file)=>{
							})
						}
					})
					}).then((data)=> {

						sendActionCompleteEmail(formelements.rowid, "hazard")

						logSequence(theSequence)				
						resumeFeed("END OF COMPLETE HAP")
					}).catch(err => {
						logIt("Hap Update Query error",JSON.stringify(err))
						resumeFeed("PUT HAP UPDATE ERROR 3")
						connupdate.end() // release to pool
						reject("Error")
					})
		}).catch(err => {
			logIt("Hap Update Promise error", JSON.stringify(err))
			resumeFeed("PUT HAP UPDATE PROMISE ERROR")
		}) // End Promise
}

function putGeneralActionUpdate(formelements,SubCompleted)	{
	// Update an existing Hazard Action Protocol form submission with completed process data.
	// OUTPUT: Success = true/false
	// RMR: 20200325 - Added
	logIt('PutGeneralActionUpdate():', formelements)
	logIt('PutGeneralActionUpdate()',"");
	logIt(`PutGeneralActionUpdate(): SubmissionHAPID = `,formelements.general_rowid,"debuginfo")
	logIt(`PutGeneralActionUpdate(): completed_by_who = `, formelements.general_action_complete_by_who,"debuginfo")
	logIt(`PutGeneralActionUpdate(): completed_date = `,formelements.general_action_completed_date,"debuginfo")
	logIt(`PutGeneralActionUpdate(): completed_action_type = `, formelements.general_completed_action_type,"debuginfo")
	logIt(`PutGeneralActionUpdate(): completed_action_taken = `, formelements.general_completed_action_taken,"debuginfo")	
	return new Promise((resolve, reject) =>	{	// Wrap the call in a promise
		logIt('In promise PutGeneralActionUpdateUpdate()',"");		
		let gaa_type=null
		if(SubCompleted)	{
			gaa_type="FOLLOWUP2"
		}
		else{
			gaa_type="FOLLOWUP"
		}
		  pool.getConnection()
		 .then(connupdate => {
		 	logIt("Update Rowid",formelements.general_rowid)
		 	let query = `call put_general_action_update(@output_id,?,?,?,?,?,?,?)`
			let params = cleanParams([
				formelements.general_rowid, 
				formelements.general_action_complete_by_who, 
				formelements.general_action_completed_date, 
				replace_apostrophe(formelements.general_completed_action_taken), 
				formelements.general_completed_action_type,
				formelements.gapSubmmitedBy,
				SubCompleted
			])
		 	logIt("General Action Update Query", query, 'debuginfo')
			 let qrows = connupdate.query(query, params).then((res)=>{
				connupdate.end() // release to pool
				return res[0][0].output_id
			 })
			 return qrows
		 	}).then(res => { 
					logIt("General Action Update Result", res, 'debuginfo')
					let gaa_gac_id=res
					Object.keys(formelements).forEach(function(rec){
						logIt("ITEM: ", rec, "debuginfo")
						if(rec.indexOf('completed_general_action_images') > -1 && rec.indexOf('_comment') == -1)	{
							logIt("We found a Followup Photo","")
							insertGeneralActionAttachmentsAsync(formelements[rec], rec, formelements.general_rowid, formelements.general_action_complete_by_who, formelements[`${rec}_comment`],gaa_type,gaa_gac_id).then((id)=>{
							})
						}
					})
			}).then((data)=> {
				sendActionCompleteEmail(formelements.general_rowid, "general")

				resolve("ok")
				logSequence(theSequence)
				resumeFeed("GENERAL ACTION COMPLETED")
			}).catch(err => {
		 		logIt("GENERAL ACTION UPDATE ERROR",JSON.stringify(err))
				 resumeFeed("GENERAL ACTION UPDATE CONNECTION ERROR")
				 connupdate.end(); // release to pool
				 reject("Error")
		 	})
		}).catch(err => {
			logIt("Hap Update Promise error", JSON.stringify(err))
			resumeFeed("GENERAL ACTION UPDATE PROMISE ERROR")
		}) // End Promise
}

function insertPreOp(submissionDetailID, formelements)	{
	// Insert Pre-Op form submission into SQL tables as a key>value pairing.
	// INPUT: 	submissionDetailID - ID of Header record
	//					formelements - JSON array of form elements and values
	// OUTPUT: Success = true/false
	logIt(`insertPreOp(): submissionDetailID = `, submissionDetailID, 'debuginfo')
	logIt(`insertPreOp(): formelements= `, formelements, 'debuginfo')
	return new Promise((resolve, reject) =>	{	
		logIt("************ START Inserting The PREOP ************","")																		// Wrap the call in a promise
		pool.getConnection()
		.then(conn => {
			logIt("put_preop_submission_header", submissionDetailID)
			let query = `call put_preop_submission_header(@OutputID,?,?,?)`
			let params = cleanParams([
				submissionDetailID, 
				formelements['pet_id'],
				formelements.submittedby
			])
			logIt("This is the Preop Header Query", query, 'debuginfo')
			conn.query(query, params)
			.then(rows => { 
				return rows
			})
			.then(res => {
				logIt("result put_preop_submission_header", JSON.stringify(res))
				conn.release(); // release to pool
				let PreOpSubmissionHeaderID= res[0][0].PreOpSubmissionHeaderID						// Grab the result ID and use it for the key/values
				Object.keys(formelements).forEach(function(category){
			 		logIt("This is the Category", category,'debuginfo')
					if((category.indexOf('photo') === -1 && category.indexOf('signature') === -1 || category.indexOf('_img_time') > -1) && category !== 'Children') {
						pool.getConnection()
							.then(conn => {
								logIt("put_preop_submission_detail",PreOpSubmissionHeaderID, 'debuginfo')
								let query = `call put_preop_submission_detail(@OutputID,?,?,?,?)`
								let params = cleanParams([
									PreOpSubmissionHeaderID, 
									category, 
									formelements[category] ? replace_apostrophe(formelements[category]) : formelements[category],
									formelements.submittedby
								])
								logIt("This is the put_preop_submission_detail Query", query,'debuginfo')
								conn.query(query, params).then((res)=>{
									conn.release()
								})
								.catch(err => {
									logIt("put_preop_submission_detail SQL error", JSON.stringify(err))
									resumeFeed('INSERT PREOP ERROR')
									conn.release()   // release to pool
								})
							}).catch (err => {
								logIt("put_preop_submission_detail SQL Connection error", JSON.stringify(err))
								resumeFeed('INSERT PREOP Connection ERROR')
							})
					}

					 if((category.indexOf('photo') > -1 || category.indexOf('signature') > -1) && category.indexOf('_comment') == -1 && category.indexOf('_img_time') == -1) {
						if(formelements[category]) {
							insertPREOPAttachments(formelements[category], category).then((file)=>{
							logIt("********** This is the Image filename **********", file.filename)
							pool.getConnection()
							.then(conn => {
								logIt("put_preop_submission_detail ",PreOpSubmissionHeaderID, 'debuginfo')
								let query = `call put_preop_submission_detail(@OutputID,?,?,?,?)`;
								let params = cleanParams( [
									PreOpSubmissionHeaderID, 
									category, 
									file.filename,
									formelements.submittedby
								])
								logIt("PreOP Submission Detail Query", query, 'debuginfo')
								// Run the Query to add the photo into the preop details
								conn.query(query, params)
								.then(res => { 
									conn.release()
									// RMR:20200829 - Properly handle PreOp Attachments
									// Determine Shift time from element name
									let strShift = 'Before';																									// Default to start of shift
									if(category.indexOf('end') > -1)																			// If it contains the word end, its post shift
										strShift = 'After';																									// Reset shift
									
									let strOrientation = 'Front';																							// Default to front facing
									if(category.indexOf('left') > -1)																		// If it contains the word left, its left side
										strOrientation = 'Left';																						// Reset Orientation
									if(category.indexOf('right') > -1)																		// If it contains the word right, its right side
										strOrientation = 'Right';																						// Reset Orientation
									if(category.indexOf('back') > -1)																		// If it contains the word back, its from the rear
										strOrientation = 'Back';	
									logIt("put_preop_attachment",PreOpSubmissionHeaderID, 'debuginfo')
									let finalPictureTimestamp =  file.picName ? file.picName : null
									let comment = formelements[`${category}_comment`] ? replace_apostrophe(formelements[`${category}_comment`]) : ""
									if (category.indexOf('signature') > -1) {
										comment = formelements[`${category}_comments`] ? replace_apostrophe(formelements[`${category}_comments`]) : ""
									}
									let per_id =  formelements['submittedby'] ? formelements['submittedby'] : 1
									let query = `call put_preop_attachment(@OutputID,?,?,?,?,?,?,?,?)`
									let params = cleanParams( [
										PreOpSubmissionHeaderID, 
										category, 
										strOrientation, 
										strShift, 
										file.filename, 
										finalPictureTimestamp, 
										comment, 
										per_id
									])
									logIt("PreOP Attachment Query", query, 'debuginfo')
									pool.getConnection()
									.then(conn2 => {
									conn2.query(query, params)
									.then(rows => { 
										conn2.end(); // release to pool
										}).catch(err => {
											resumeFeed('INSERT PREOP ATTACHMENTS ERROR')
											logIt("put_preop_submission_detail Query error", JSON.stringify(err),'debuginfo')
											conn2.end(); // release to pool
									})
								}).catch(err => {
									resumeFeed('2nd query connection error')
									logIt("put_preop_attachment detail error", JSON.stringify(err))
								})
								
								}).catch(err => {
									resumeFeed('INSERT PREOP detail ERROR')
									logIt("put_preop_attachment detail error", JSON.stringify(err))
								})
							}).catch(err => {
								resumeFeed('preop connection error')
								logIt("preop connection error", JSON.stringify(err))
								conn.release(); // release to pool
							})
							})
						}
					 }
				})
			})
			.catch(err => {
				resumeFeed('putPreOpSubmissionHeader ERROR')
				logIt("putPreOpSubmissionHeader error", JSON.stringify(err))
			  	conn.release(); // release to pool
			})

		}).catch(function(err) {
			resumeFeed('PREOP Pool Connection Error')
			logIt("PREOP Pool Connection Error", JSON.stringify(err))
			reject(Error(err));
		})
	}).catch(function(err) {
		resumeFeed('INSERT PREOP PROMISE ERROR')
		logIt("PREOP Promise Error", JSON.stringify(err))
	})
}

function tStamp(){
	let today = new Date()
	return `${today.getFullYear().toString()}-${pad2(today.getMonth() + 1)}-${pad2(today.getDate())} ${pad2(today.getHours())}:${pad2(today.getMinutes())}:${pad2(today.getSeconds())}`
}

function logSequence(seq){
	logIt(`Writing sequence: `, seq)
	fs.writeFileSync(logLocation + 'seq.txt', `${seq}`, (err) => {
		// throws an error, you could also catch it here
		if (err) throw err;
	})
}

function readSequence(){
	let data = `now`
	try {
		data = fs.readFileSync(logLocation + 'seq.txt','utf8')
		logIt(`Starting the Listener from sequence: `, data)
		return data
	} catch (err) {
		logIt(`Seq file not found. This is the error->`, err,`debuginfo`)
		logIt(`Starting the Listener from now`, ``)
		return data
	}
}

function logToFile(log) {
	fs.appendFileSync(logLocation + 'listenlog.txt', `${tStamp()} -- ${log}\r\n`, (err) => {
		// throws an error, you could also catch it here
		if (err) throw err;
	});

}

function resumeFeed(source = 'default') {
	setTimeout(()=>{
        logIt(`Now We are resuming the feed - Ready for Next Document - ${source}\r\n\r\n`,"")
		feed.resume()
	},1000)
}

function logIt(log, params, type='log') {
	switch(type){
		case 'log': console.log(`${tStamp()} -- ${log}`, params)
		    logToFile(`${log} : ${params}`)
			break
		case 'info': console.log(`${tStamp()} -- ${log}`, params)
			logToFile(`${log} : ${params}`)
			break
		case 'debug': debug ? console.log(`${tStamp()} -- ${log}`, params) : ''
		     debug ? logToFile(`${log} : ${params}`) : ''
			break
		case 'debuginfo': debug ? console.log(`${tStamp()} -- ${log}`, params) : ''
		    debug ? logToFile(`${log} : ${params}`) : ''
			break
		default:
			break;
	}
}

function convertReturnValues(returnedString) {
	let retrunArray=[]
	let emailLists=returnedString.substring(1).split("|")
	for(let emailList of emailLists){
		let emailElements=emailList.split(",")
		let emailObj={id:emailElements[0],email:emailElements[1]}
		retrunArray.push(emailObj)
	}
	return retrunArray
}