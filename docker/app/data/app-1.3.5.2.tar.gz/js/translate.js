function getCookie(name) {
	const value = `; ${document.cookie}`;
	const parts = value.split(`; ${name}=`);
	if (parts.length === 2) return parts.pop().split(';').shift();
}
  
selectedLanguage_i18n = navigator.language.substring(0,2)
langCookie = getCookie("lang")
selectedLanguage_i18n = langCookie ? langCookie : selectedLanguage_i18n
if(window.localStorage.getItem('language'))
  selectedLanguage_i18n= window.localStorage.getItem('language')

// Start i18Next for Translations
i18next
  .use(i18nextXHRBackend)
  .init({
	  fallbackLng: ["en", "fr", "es"],
	  lng: `${selectedLanguage_i18n}`,
	  debug: false,
	  backend: {
		  loadPath: `/locales/translation/translation_${selectedLanguage_i18n}.json`
	  }
	}, (err, t) => {
	  jqueryI18next.init(i18next, $)
	  // Handle Lable Translations
	  $('.translate').localize()

     // Handle the Page Title
	 try{
		document.getElementById('page_name').innerHTML = i18next.t(document.getElementById('formname').getAttribute('tag'))
	 } catch (error) {}

	  // Handle the Tooltips 
	  let tooltips = document.getElementsByClassName('trans_tooltip') 

	  for(tooltip in tooltips){
		  try {
		    tooltips[tooltip].setAttribute('title', i18next.t(tooltips[tooltip].getAttribute('title')))
		  } catch (error) {}
	  }	
	  // Handle the search in Select 2
	  reInitializeSelect2Language()
  })

  function reInitializeSelect2Language() {
	let select2Search = document.getElementsByClassName('select2-search__field')
//	console.log("Reinitialize Select 2 language", select2Search)
	for(search in select2Search){
	//	console.log("This is the Search", select2Search[search])
	  try {
		select2Search[search].setAttribute('placeholder', i18next.t("2346"))
	  } catch (error) {}
	}	
  }