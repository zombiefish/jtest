function setScripts(link) {
    let itm = document.createElement("script")
    itm.type = "text/javascript"
    itm.src = `${__env.resourceUrl}${link}`
    document.getElementById("indexhead").appendChild(itm);
        }	  

// Dynamically Set the Scripts
setScripts('/js/popper.min.js')
setScripts('/js/bootstrap.min.js')
setScripts('/js/addons/datatables.min.js')
setScripts('/js/select2.min.js')
setScripts('/js/moment-with-locales.min.js')
setScripts('/js/mdb.min.js')