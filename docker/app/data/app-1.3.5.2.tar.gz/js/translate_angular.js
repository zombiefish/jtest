function getCookie(name) {
	const value = `; ${document.cookie}`;
	const parts = value.split(`; ${name}=`);
	if (parts.length === 2) return parts.pop().split(';').shift();
}

//Grab language from the browser
selectedLanguage = navigator.language.substring(0,2)
//Grab language from the cookie
langCookie = getCookie("lang")
//Use the cookie language if avalible
selectedLanguage = langCookie ? langCookie : selectedLanguage

if(window.localStorage.getItem('language'))
  selectedLanguage= window.localStorage.getItem('language')

let agGridFieldTags = {}
let plotlyTags = {}
let translations_tags = {}

// Main Translation File
$.getJSON(`./locales/translation/translation_${selectedLanguage}.json`, function(json_data) {
	translations_tags = json_data;
})

// translations for ag-grid module
$.getJSON(`./locales/translation/agGrid_${selectedLanguage}.json`, (json_data) => {
	agGridLang = json_data
})

$.getJSON(`./locales/translation/agGridFieldTags.json`, function(json_data) {
	agGridFieldTags = json_data;
})

$.getJSON(`./locales/translation/plotlyTags.json`, function(json_data) {
  plotlyTags = json_data;
})

$.getJSON(`./locales/translation/genericTags.json`, function(json_data) {
  genericTags = json_data;
})

$.getJSON(`./locales/translation/translation_en.json`, function(json_data) {
	translations_tags_en = json_data;
})

function translateAgGridField(key) {
    var translation = undefined
    translation = translateTag(agGridFieldTags[key])
    if (translation === undefined){
      // console.log("Undefined Translations", translation)
      // console.log("ag-grid Key", key)
      var break_flag = false
      for (const obj_key in translations_tags_en) {
        if (!break_flag){
          if(translations_tags_en[obj_key] === key){
            translation = translateTag(obj_key);
            break_flag = true;
          }
        }
      }
    }
  //  console.log(`KEY: ${key} Translate: ${translation}`)
	return translation != undefined ? translation : agGridFieldTags[key]
}

function translatePlotlyField(key) {
  translation = translateTag(plotlyTags[key])
  return translation != undefined ? translation : plotlyTags[key]
}

function translateGenericFields(key) {
  translation = translateTag(genericTags[key])
  return translation != undefined ? translation.toString() : genericTags[key]
}

// To be used within the javascript controllers
function translateTag(key) {
  translation = translations_tags[key]
  return translation != undefined ? translation.toString(): key 
}

function translateAgGridHeader (gridOptions) {
  field_keys = gridOptions.api.columnController.gridColumns
  field_keys_object = {}
  for (let i = 0; i < field_keys.length; i++) {
      field_keys_object[field_keys[i].colId] =  field_keys[i].colId
      if (! (gridOptions.api.getColumnDef(field_keys[i].colId).headerName ==='') )
          gridOptions.api.getColumnDef(field_keys[i].colId).headerName = translateAgGridField(field_keys[i].colId)
    }
    gridOptions.api.refreshHeader();
}

let select2LanguageFunction = window[`sofvie_select2_languages_${selectedLanguage}`]
if (!(typeof select2LanguageFunction === "function"))
{
  select2LanguageFunction = {}
  console.error("Failed to get Select2 Translations")
}