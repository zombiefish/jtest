function setLinks(link, rel, type='none') {
    let itm = document.createElement("link")
    itm.rel = rel
    if(type !== 'none'){
       itm.type = type 
    }
    itm.href = `${__env.resourceUrl}${link}`
    document.getElementById("indexhead").appendChild(itm);
        }

// Dynamically Set the Links and Scripts
setLinks('/img/favicon.png','icon','image/png')
setLinks('/css/all.min.css','stylesheet','text/css')
setLinks('/css/bootstrap.min.css','stylesheet','text/css')
setLinks("/css/mdb-webapp.css", "stylesheet",'text/css')
setLinks('/css/select2.min.css','stylesheet','text/css')
