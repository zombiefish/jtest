
if (window.location.hostname.split(".")[0].substring(0,4) ==='test') {
	document.getElementById('test-pill-id').classList.remove('d-none')
	document.getElementById('test-pill-id').classList.add('d-block')
} else {
	document.getElementById('test-pill-id').classList.remove('d-block')
	document.getElementById('test-pill-id').classList.add('d-none')
}