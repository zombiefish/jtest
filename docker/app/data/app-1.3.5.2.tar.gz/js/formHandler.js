var form = document.forms[0];																										// Create a ref to our form
var primaryKeyField = form.keyField.value;																			// What form field is unique to use as an id.
//var output = document.getElementById( "output" );															// And to our output area (debugging)
var draft = document.getElementById(form.draftField.value);											// Name of our Draft selector
var debug = false;																															// Set our debug flag

var config = {																																	// Define some config itmes
	draftDbName: 'safetodotemp', 																			// db name for draft storage
	draftRemoteSync: false,																						// Sync path for draft, false for none
	commitDBName: 'safetodo', 																				// Committed db name
	commitRemoteSync: 'https://testforms.technicagroup.com:6984/safetodo'						// Sync path for committed, false for none
};


(function () {
	document.addEventListener("DOMContentLoaded", function () {										// On document loaded
		console.log(" Form Handler Page Load Starting")
		try {
			formHeader.formInitialize(document.forms[0]);
		} catch (err) {
			console.warn('formHeader.formInitialize does not exist. \n' + err);
		}

		try {
			formBody.formInitialize(document.forms[0]);
		} catch (err) {
			console.warn('formBody.formInitialize does not exist. \n' + err);
		}

		try {
			formFooter.formInitialize(document.forms[0]);
		} catch (err) {
			console.warn('formFooter.formInitialize does not exist. \n' + err);
		}

		var db = new PouchDB(config.commitDBName, { auto_compaction: true });					// Create a ref to the local DB
		sync(db, config.commitRemoteSync);																					// sync to it.

		getFormDraftList(draft)																											// Handle the draft list select box

		// Save a draft (local only) copy of this form. 		
		document.getElementById("saveDraft").addEventListener("click", function (e) {	// And a hook to form submission.
			e.preventDefault();

			if (formHandle(form, 'draft')) {																  // Terminate and validate form

				var json = toJSONString(form);																  // Convert the form submission to JSON
				if (debug) console.log(json);																  // Log it to the console
				output.innerHTML = json;																	  // And display it on screen

				db = new PouchDB(config.draftDbName, { auto_compaction: true });					          // Create a ref to the local temp DB
				sync(db, config.draftRemoteSync);															  // sync to it.

				if (primaryKeyField) {																		  // Is our unique key field identified
					key = draftName(primaryKeyField);
					/*
										var key = form[primaryKeyField].value								  // Retrieve the unique field value
										key = form.name + ':' + key;										  // Build a key for this submission
					*/
					addFormDraft(db, json, key, form, true);												  // Then save the JSON to our localDB
				}
			}
		}, false);


		// Save a local, and remote, copy of the form.
		form.addEventListener("submit", function (e) {														   // And a hook to form submission.
			e.preventDefault();
			// Handle any post processing to the form component
			if (formHandle(form, 'full')) {																		// Terminate and validate form

				var json = toJSONString(this);																	// Convert the form submission to JSON
				if (debug) console.log(json);																	// Log it to the console
				//		output.innerHTML = json;																// And display it on screen
				db = new PouchDB(config.commitDBName, { auto_compaction: true });					            // Create a ref to the local DB
				sync(db, config.commitRemoteSync);																// sync to it.

				if (primaryKeyField) {
					var key = draftName(primaryKeyField);														// Build a key for this submission
					//					key = form.name + ':' + key;											// The key is always the form name + the <key> field specified in the form
					addForm(db, json, _id.value, form);															// Then save the JSON to our localDB
				}
			}	// End Form Valid
		}, false);

		/* SJB: 20190220 Removed management of submit button as per Dan.
				// Enable the commit button via a checkbox.
				$('#saveEnable').click(function(){																					// Toggle the state of the submit button from the checkbox
					if($(this).prop('checked') === false){																		// If were not checked
						$('#submit').attr("disabled","disabled");   														// Disable
					} else {																																	// Otherwise
						$('#submit').removeAttr('disabled');																		// Enable the button
					}
				});
				*/
	});
})();

function draftName(primaryKeyField) {
	// Build a unique form identifier for saved draft of 'this' form, based on the contents of the hidden keyField
	// All draft field names contain the timestamp and site.
	// INPUTS:
	//	primaryKeyField - the primaryKeyField values, can be a pipe '|' seperated array for compound id's.

	var draftTitle = form.formname.value + ' ' + formatDate(new Date(form.startFormTimeStamp.value));

	var arrKeys = primaryKeyField.split('|');
	arrKeys.forEach(function (element) {
		draftTitle = draftTitle + ' ' + form[element].value;
	});
	console.log(draftTitle);
	return draftTitle;

}

function disableDraftKeys(primaryKeyField) {
	// Disable our unique form identifiers after recalling a draft so that they cannot change (if they change, you cannot update/save)
	// All draft field names contain the timestamp and site.
	// INPUTS:
	//	primaryKeyField - the primaryKeyField values, can be a pipe '|' seperated array for compound id's.

	var arrKeys = primaryKeyField.split('|');																		// Retrieve and split our key elements from the form
	arrKeys.forEach(function (element) {																				// Iterate over them					
		if (document.getElementById(element).tagName == 'SELECT') {							// Are we a select box?
			document.getElementById(element).parentNode.children[1].disabled = true; // Point to the customized select box
		} else {
			form[element].disabled = true;																					// Disable each element so that they cannot be changed.
		}
	});

}


function formatDate(date) {
	return date.toLocaleString();
	var monthNames = [
		"January", "February", "March",
		"April", "May", "June", "July",
		"August", "September", "October",
		"November", "December"
	];

	var day = date.getDate();
	var monthIndex = date.getMonth();
	var year = date.getFullYear();

	return monthNames[monthIndex] + ' ' + day + ' ' + year;
}

function formHandle(form, submissionType) {
	// Handle the form.  First perform any post processing before validation.
	try {
		formHeader.formTerminate(form);
	} catch (err) {
		console.warn('formHeader.formTerminate does not exist. \n' + err);
	}
	try {
		formBody.formTerminate(form);
	} catch (err) {
		console.warn('formBody.formTerminate does not exist. \n' + err);
	}
	try {
		formFooter.formTerminate(form);
	} catch (err) {
		console.warn('formFooter.formTerminate does not exist. \n' + err);
	}

	// Handle validation of the form component, we always validate the form header.
	try {
		formHeader.formValidate(form);
	} catch (err) {
		console.error('formHeader.formValidate: ' + err);
		return false;
	}
	if (submissionType == 'full') {																							// We can skip the body and footer validation for draft saves. 
		try {
			formBody.formValidate(form);
		} catch (err) {
			console.error('formBody.formValidate : ' + err);
			return false;
		}
		try {
			formFooter.formValidate(form);
		} catch (err) {
			console.error('formFooter.formValidate:' + err);
			return false;
		}
	}
	return true;
}
/*
	function toJSONString( form ) {																							// Convert form submission to JSON string
		var obj = {};																															// Create storage object
		var elements = form.querySelectorAll( "input, select, textarea" );				// Create a reference to all form element types
		for( var i = 0; i < elements.length; ++i ) {															// Iterate over it
			var element = elements[i];																							// Extract the element type
			var name = element.name;																								// The element name
			var value = element.value;																							// The value

			if( name ) {																														// If it has a name attribute
				obj[ name ] = value;																									// Store the values in the storage object
			}
		}
		return JSON.stringify( obj );																							// When were done iterating, convert the object to a JSON string and return it
	}
*/
function toJSONString(form) {																								// Convert form submission to JSON string
	var obj = {};																																// Create storage object
	var elements = form.querySelectorAll("input, select, textarea");					// Create a reference to all form element types
	for (var i = 0; i < elements.length; ++i) {																// Iterate over it
		var element = elements[i];																								// Extract the element type
		var name = element.name;																									// The element name
		var value = element.value;																								// The value

		if (name) {																															// If it has a name attribute
			if (!obj[name]) {																												// Has this element already been added?
				if (element.matches('[type="radio"]')) {																// Is a radio button
					if (element.checked) {																								// Is it checked
						obj[name] = element.value;																				// Assign the associated value to the element
					}

				} else if (element.tagName == 'SELECT') {															// Is a select box 

					obj[name] = getSelectValues(element);															// Handle if it contains 1 or more selections.
				} else {
					obj[name] = element.value;																					// Its another kind of input element
				}

			}
		}
		if (debug)
			console.log(name + '=' + obj[name]);																		// Store the values in the storage object
	}
	return JSON.stringify(obj);																								// When were done iterating, convert the object to a JSON string and return it
}

function getSelectValues(select) {																						// Parse a select box for one or more selected items
	var result = [];																														// Initialize and array to hold our results
	var options = select && select.options;																			// Our option values
	var opt;																																		// Temp storage

	for (var i = 0, iLen = options.length; i < iLen; i++) {														// Iterate over all options
		opt = options[i];																													// Copy the option

		if (opt.selected) {																												// Is it selected?
			result.push(opt.value || opt.text);																			// Push the value onto the array (value maybe the option value, or the option text)
		}
	}

	return result.join('|');																										// Join all the data separated by a comma (comma delimited list)
}
/*
	function setSelectValues(select, value) {																			// Parse a select box for one or more selected items
		var result = [];																														// Initialize and array to hold our results
		var options = select && select.options;																			// Our option values
		var opt;																																		// Temp storage

		for (var i=0, iLen=options.length; i<iLen; i++) {														// Iterate over all options
			opt = options[i];																													// Copy the option

			if (opt.selected) {																												// Is it selected?
				result.push(opt.value || opt.text);																			// Push the value onto the array (value maybe the option value, or the option text)
			}
		}
		
		return result.join(',');																										// Join all the data separated by a comma (comma delimited list)
	}	
	*/

function getUniquePhotoName(photoElemName) {																	// Generate unique hidden field name for photo's
	// Generate a sequential element name as a suffix to photoElemName
	// INPUT :	photoElemName = base elem name
	// OUTPUT: 	return unique file base on photoElemName
	var i = 1;																																	// Set the starting index
	for (i = 1; ; i++) {																														// Iterate over possible names
		photoName = form.formtype.value + photoElemName + i;											// Create the name
		if (debug) console.warn('PhotoName: ' + photoName);
		if (!document.getElementById(photoName)) {																	// If that name exist?
			break;																																	// Bust out or loop
		}
	}

	if (debug) console.log('PhotoName: ' + photoName);
	return photoName;																														// Return the resolved 'next' name
}

function takePhoto(elemCanvas, elemVideo, elemPhotoButton, elemSnap, formField, elemGallery) {			// Function to enable using device camera
	// Grab elements, create settings, etc.
	var canvas = document.getElementById(elemCanvas);														// Where will display the image
	var context = canvas.getContext('2d');																			// Context of the stream
	var video = document.getElementById(elemVideo);															// Where will display the video
	var photoButton = document.getElementById(elemPhotoButton);									// Where is the button that we clicked?
	var snap = document.getElementById(elemSnap);																// Where is the snap button that we clicked?
	var gallery = document.getElementById(elemGallery);													// Where is the gallery 
	front = false;
	var mediaConfig = {
		fillLightMode: "flash",
		advanced: [{
			facingMode: "environment",
			torch: true
		}]
	};																																					// Set our device parameters
	var errBack = function (e) {
		console.error('An error has occurred!', e)
	};

	// Enable display of components
	video.style.display = 'block';																							// Display the video feed
	snap.style.display = 'block';																								// Display the button to take the picture
	canvas.style.display = 'none';																							// Turn off the display of the image
	context.clearRect(video, 0, 0, canvas.width, canvas.height);								// New image, clear the canvas
	var context = canvas.getContext('2d');																			// Context of the stream

	photoButton.style.display = 'none';																					// Turn off the image toggle

	// Put video listeners into place
	if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {					// Does this browser support vid?
		navigator.mediaDevices.getUserMedia({ video: mediaConfig })									// If it supports this vid requirements
			.then((stream) => {
				var imageCaptureConfig = {
					fillLightMode: "flash", /* or "auto","off","flash"*/
					focusMode: "continuous"
				};
				console.log("Lets Turn on the Light")
				video.setOptions(imageCaptureConfig)
				video.srcObject = stream	
					    																				// Attach the video stream to the video element and autoplay.
			})
	} else {
		console.log("There is no camera")
	}

	// Trigger photo take
	document.getElementById(elemSnap).addEventListener('click', function (e) {		// Bind to the take a pic button
		e.preventDefault();																												// Don't bubble
		context.drawImage(video, 0, 0, canvas.width, canvas.height);							// Whatever is on the video screen, grab it and stuff it onto the canvas

		
		var canvasImage = canvas.toDataURL("image/png");													// Copy the image to mem
		// Insert a new thumbnail into the gallery using the saved image.
		gallery.innerHTML += '<div class="col-md-3 col-sm-4 col-6"><span class="deleteGalleryImage fa fa-2x fa-times-circle text-danger"><img name="' + formField + 'Gallery" id="' + formField + 'Gallery" width="100%" src="' + canvasImage + '"></span></div>';

		video.srcObject.getVideoTracks().forEach((track) => {
			console.log(track.getCapabilities())
			track.stop()
		});					// Stop all video streams.

		// Hide display components
		video.style.display = 'none';																							// Shut off the video feed.
		snap.style.display = 'none';																							// Hide the shutter button
		canvas.style.display = 'block';																						// Display the image
		photoButton.style.display = 'block';																			// Show the grab photo button in case they want to retake.

		var input = document.createElement('input');															// Create an input element to form
		input.type = 'hidden';																										// Make it hidden
		input.name = formField;																										// Name it whatever we were passed to the function
		input.id = formField;																											// Name it whatever we were passed to the function
		input.value = canvas.toDataURL("image/jpg");															// Convert the canvas to a ping and store it in the hidden form field.
		form.appendChild(input);																									// Append the form element to the form.

		// Trigger photo delete
		if ($(".deleteGalleryImage")[0]) {
			$(".deleteGalleryImage").click(function () {															// Bind to the delete button
				this.parentElement.remove();																				// Delete the node
			});
		}

		this.removeEventListener('click', arguments.callee, false);									// Unhook the event on the shutter button
	});


	return false;
}

function getFormDraftList(selectID) {
	// Retrieve JSON list of saved form drafts
	if (selectID) {																															// Is draft enabled?
		db = new PouchDB(config.draftDbName, { auto_compaction: true });						// Create a ref to the local DB
		sync(db, config.draftRemoteSync);																					// Sync to it

		// SJB:20190110 - Added filter by form name.
		// SJB:20190318 - Modified to filter by full form name, not form.id
		db.allDocs({																															// Get all matching drafts for this form name 
			include_docs: false,
			attachments: false,
			startkey: form.formname.value,
			endkey: form.formname.value + '\ufff0'
		}).then(function (result) {																								// If we got results
			// handle result
			if (debug) console.log(result);																					// Output to console
			$(selectID).empty();																										// Whack the existing data in the select should be none
			$(selectID).append($('<option>').text("Select Draft").attr('value', ''));								// Add a prompt for the first entry
			$.each(result.rows, function (i, obj) {																		// Iterate over the results 
				$(selectID).append($('<option>').text(obj.key).attr('value', obj.id));// Add them into the select list
			});

		}).catch(function (err) {
			console.error(err);
		});
	}
}

function getFormData(theForm) {					 																			// Retrieve selected draft form and populate form
	db = new PouchDB(config.draftDbName, { auto_compaction: true });							// Create a ref to the local DB
	sync(db, config.draftRemoteSync);																						// Sync to it

	if ((selectedDraft = theForm[theForm.selectedIndex].value) != '') {					// Retrieve whatever was selected, and if it has a value, action it

		db.get(selectedDraft).then(function (result) {														// Get selected item from the db
			// handle doc

			var parsedJSON = JSON.parse(result.formdata);														// Parse out the form data
			if (debug)
				console.dir(parsedJSON);

			/*							
			
							for(var key in parsedJSON)	{																						// Iterate over the data
								if(parsedJSON.hasOwnProperty(key))	{																	// Is this a 'real' key
									if(debug) console.log(key + " -> " + parsedJSON[key]);							// Log it
									if(!document.getElementsByName(key))	{																	// If their is no element with that name, create it (Used for images)
										var input = document.createElement('input');											// Create an input element to form
										input.type = 'hidden';																						// Make it hidden
										input.name = key;																									// Name it whatever we were passed to the function
										input.id = key;																										// Name it whatever we were passed to the function
										input.value = null;																								// Convert the canvas to a ping and store it in the hidden form field.
										form.appendChild(input);																					// Append the form element to the form.
										if(document.getElementById('galleryid'))
											document.getElementById('galleryid').innerHTML += '<div class="col-md-3 col-sm-4 col-xs-6"><img name="' + key + 'Gallery" id="' + key + 'Gallery" width="160" height="120" src="' + parsedJSON[key] + '"><span class="deleteGalleryImage">X</span></div>';
										
									}
									element = document.getElementsByName(key);													// Find that form element name in the document
									type = element[0].getAttribute('type');																				// Get its type
									if(type == undefined)																									// Properly handle input types
										type = element[0].tagName;																							// Otherwise, use the tagName for selects
			
									if(key == 'job_number')	{																						// Populate job_number drop down
										formHeader.populateJobSelect(document.getElementById('site').value)
										formHeader.populateLevelSelect(document.getElementById('job_number').value)
									}
									if(key == 'level')	{																								// Populate level drop down
										formHeader.populateLevelSelect(document.getElementById('job_number').value)
									}
			
									switch(type)	{
									case 'checkbox':																										// If it's a checkbox
										element[0].attr('checked', 'checked');																		// Set the check attribute
										break;
									case 'radio':																												// If it's a radio
										element[0].filter('[value="' + parsedJSON[key] + '"]').attr('checked', 'checked');				// If their elements value matches the form, set the checked attribute
										break;
									case 'SELECT':																												// If it's a radio
										//Set the original
										SetSelectValue(element[0], parsedJSON[key]);				// If their elements value matches the form, set the checked attribute
										break;
			
									default:																														// Otherwise
										element[0].value = parsedJSON[key];																											// Set the elements value
			
										
										if(element.matches('[type="radio"]'))	{													// Is this radio box?
											if(key.value == parsedJSON[key])	{														// does the value match the key value
													element.checked = true;																		// Set the check
											}
										}	else	{
											element.value = parsedJSON[key];																		// Stuff in the value
										}
									}
								}
							}
				*/


			/*
							$.each(parsedJSON, function(name, val){																	// Iterate over our parsed object
								var $el = $('[name="'+name+'"]'),																			// Build a var pointing to the object
								type = $el.attr('type');																							// Get its type
								if(type == undefined)																									// Properly handle input types
									type = $el[0].tagName;																							// Otherwise, use the tagName for selects
			
								if(name == 'job_number')	{																						// Trigger to populate job_number drop down
									formHeader.populateJobSelect(document.getElementById('site').value)
								}
								if(name == 'level')	{																									// Trigger to populate level drop down
									formHeader.populateLevelSelect(document.getElementById('job_number').value)
								}
			
								switch(type){																													// Handle special cases
									case 'checkbox':																										// If it's a checkbox
										$el.attr('checked', 'checked');																		// Set the check attribute
										break;
									case 'radio':																												// If it's a radio
										$el.filter('[value="'+val+'"]').attr('checked', 'checked');				// If their elements value matches the form, set the checked attribute
										break;
									case 'SELECT':																												// If it's a radio
										//Set the original
										SetSelectValue($el[0], val);				// If their elements value matches the form, set the checked attribute
										$("li:contains(" + val + ")")[1].className += ' active';
										$el.filter('[value="'+val+'"]').attr('checked', 'checked');				// If their elements value matches the form, set the checked attribute
										$el[0].parentNode.children[1].value = val;
										break;
			
									default:																														// Otherwise
										$el.val(val);																											// Set the elements value
								}
							});
			*/

			putJSONForm(theForm, parsedJSON);


			document.forms[0]._rev.value = result._rev;															// Plug in the pouchdb value for revision
			document.forms[0]._id.value = result._id;																// Plug in the pouchdb value for the unique key
			disableDraftKeys(form['keyField'].value);																	// Disable all the key elements
			//				form[primaryKeyField].disabled = true;																	// If we retrieved something, we can't change tghe key so disable the field.

		}).catch(function (err) {
			console.error(err);
		});
	} else {																																		// A blank option was selected. 
		clearForm();																															// Clear the form in case their was soemthing there from a previous selection

	}
}

function putJSONForm(theForm, parsedJSON) {
	// Put JSON array data into form values
	//	INPUTS:	theForm = pointer to form
	//					parsedJSON = JSON formatted for data

	$.each(parsedJSON, function (name, val) {																	// Iterate over our parsed object
		var $el = $('[name="' + name + '"]'),																			// Build a var pointing to the object
			type = $el.attr('type');																							// Get its type
		if (type == undefined)																									// Properly handle input types
			type = $el[0].tagName;																							// Otherwise, use the tagName for selects

		switch (type) {																													// Handle special cases
			case 'checkbox':																										// If it's a checkbox
				$el.attr('checked', 'checked');																		// Set the check attribute
				break;
			case 'radio':																												// If it's a radio
				$el.filter('[value="' + val + '"]').attr('checked', 'checked');				// If their elements value matches the form, set the checked attribute
				break;
			case 'SELECT':																												// If it's a Select box
				SetSelectValue($el[0], val);
				break;

			default:																														// Otherwise
				$el.val(val);																											// Set the elements value
		}
		if (name == 'job_number') {																						// Trigger to populate job_number drop down
			formHeader.populateJobSelect(document.getElementById('site').value)
		}
		if (name == 'level') {																									// Trigger to populate level drop down
			formHeader.populateLevelSelect(document.getElementById('site').value);
			SetSelectValue(document.getElementById('level'), val);
		}
	});

}

function SetSelectValue($el, value) {
	// Set the value in the options list of the select box to selected, can be a | delimited array.

	arrLen = $el.options.length;																								// How many option elements do we have
	var arrKeys = value.split('|');																							// Try splitting
	// SJB: 20190307 - Modification to suit Select2 select box plug in for jquery
	$('#' + $el.name).val(arrKeys);
	$('#' + $el.name).trigger('change');
	return;
	/*
	
			arrKeysLen = arrKeys.length;																								// How long is it
			var ptrArrKeys = ptrArrLen = 0;																							// Initialize our loop pointers
			for(ptrArrKeys = 0; ptrArrKeys < arrKeysLen; ptrArrKeys++) {								// Iterate over the values
			
				for(ptrArrLen = 0; ptrArrLen < arrLen; ptrArrLen++) {											// Iterate over the options
					if($el.options[ptrArrLen].value == arrKeys[ptrArrKeys])									// If the value matches the opition
						$el.options[ptrArrLen].selected = true;																// Set the option
				}
			}
		*/
}

function addFormDraft(db, text, pouchid, form) {															// Write the JSON data to the local DB
	db.get(pouchid).then(function (doc) {																			// Try to retrieve existing unique id
		return db.put({																													// If we got a result
			_id: pouchid,																													// Update it
			_rev: doc._rev,																												// Must pass the existing revision
			formdata: text																												// and the data
		});
	}).then(function (response) {
		getFormDraftList(draft);																								// Update draft list.
		if (debug) console.log('response:' + response);
	}).then(function (response) {																						// and then
		clearForm();																													// Clear the form
	}).catch(function (err) {
		if (debug) console.log('Creating New Rec: ' + err);											// This rec does not exist in the specified db, save it.
		db.put({																																// If we got a result
			_id: pouchid,																													// Overwrite it
			_rev: text._rev,																											// Must pass the existing revision
			formdata: text																												// and the data
		});
		getFormDraftList(draft);																								// Update draft list.
	});
}

function addForm(db, text, pouchid, form) {																		// Write the JSON data to the local DB
	db.get(pouchid).then(function (doc) {																				// Check to see if this id already has been committed
		console.error('addForm: Commit Found ID: ' + pouchid);										// It exists, you can't overwrite an ID
		alert('You cannot save this form. This id already exists\r\nID = ' + pouchid)
		//Reset disabled stated on Commit/Save button
		$('#saveEnable').prop('checked', false);																	// UnCheck the save enable button
		$('#submit').prop("disabled", "disabled");																	// Disable the commit/save button.

		return;
	}).catch(function (err) {
		// Everything is fine, proceed.
	});

	// Check to see if this was from a draft, if so, delete the draft copy.
	dbDraft = new PouchDB(config.draftDbName, { auto_compaction: true });					// Create a instance to the local temp DB
	sync(dbDraft, config.draftRemoteSync);																			// Sync to it

	dbDraft.get(pouchid).then(function (doc) {																		// Try to retrieve existing unique id
		if (debug) console.log('addForm: Draft Found ID: ' + pouchid);
		return dbDraft.remove(																										// If we got a result
			doc._id,
			doc._rev																																// Overwrite it
		);
		if (debug) console.log('addForm: Draft Removed ID: ' + pouchid);

	}).catch(function (err) {
		console.warn('ERROR or nothing to delete from drafts: ' + err);						// Error
	});


	db.put({
		_id: pouchid,																															// Update it
		formdata: text																														// and the data
	}).then(function (response) {
		if (debug) console.log('addForm: Commit Update ID: ' + pouchid);
		getFormDraftList(draft);																									// Update draft list.
	}).then(function (response) {
		clearForm();																															// Clear the form
	}).catch(function (err) {
		console.error('AddForm: Error Committing Data: ' + err);									// This rec does not exist in the specified db, save it.
	});
}

function deleteDraft() {																											// The user clicked the Reset/Delete Draft button
	if (form._id.value) {																												// If this form has been saved previously (form has db id)
		if (form._rev.value) {																											// And if it has a revision (redundant)
			db.get(form._id.value).then(function (doc) {															// Retrieve the form data
				return db.remove(doc);																								// delete the doc
			}).then(function (result) {																							// and the housekeeping
				form._rev.value = '';																									// Reset the form rev
				form._id.value = '';																										// Reset the form id
				getFormDraftList(draft);																							// Update the draft list
			}).then(function (result) {																						// and then
				clearForm();																													// Clear the form
			}).catch(function (err) {
				console.error('ERROR deleting draft: ' + err);
			});

		}
	}
}

function clearForm() {
	// Iterate over form elements and set values to null
	var elements = form.querySelectorAll("input, select, textarea");					// Create a reference to all form element types
	for (var i = 0; i < elements.length; ++i) {																// Iterate over it
		var element = elements[i];																								// Extract the element type
		element.value = null;																											// Reset the value
	}

	// Delete all images in gallery
	while ($(".deleteGalleryImage")[0]) {
		$(".deleteGalleryImage")[0].parentElement.remove();										// Delete the node
	}


	//Reset disabled stated on Commit/Save button
	$('#saveEnable').prop('checked', false);																	// UnCheck the save enable button
	$('#submit').prop("disabled", "disabled");																	// Disable the commit/save button.


}
/*
function sync(db, syncTo) {
	if (navigator.onLine) {																											//  If were online, bind to the server to sync
		if (syncTo) {
			var opts = { live: true, retry: true };																		// Configure synching

			db.replicate.to(syncTo, opts)																						// One way replicate (to only)
				.then(function (response) {
					console.log('Replicating To: ' + syncTo);															// Log it to the console
				}).catch(function (err) {
					console.error('Error replicating to : ' + syncTo + ' : ' + err);			// Report a warning that were not online. 
				});
		} else {
			if (debug) console.log('Nothing to sync to');
		}
	} else {
		console.warn('Browser offline, not replicating');
	}

}
*/
/*
	// Handle the service worker to act as a PWA
	if ('serviceWorker' in navigator) {																						// Does this browser support service workers.
	  window.addEventListener('load', function() {															// Listen for a load event
	    navigator.serviceWorker.register('/sw.js').then(function(registration) {// Register the service workers
	      // Registration was successful
				if(debug) console.log('ServiceWorker registration successful with scope: ', registration.scope);	// Log it
	    }, function(err) {
	      // registration failed :(
	      console.error('ServiceWorker registration failed: ', err);						// Log the error
	    });
	  });
	  */
//	}
