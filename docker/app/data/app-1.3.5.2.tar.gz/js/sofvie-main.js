class SofvieModal {
    constructor(name = 'theModal') {
        this.name = name;
    }
    // This ojbect sets the default values for the model buttons and elements
    themeClasses = '';
    alertClasses = '';

    // Default Modal Setting and Main Settings Object
    modalSettings = {
        warning: {
            modalTheme: `modal-warning`,
            modalAlert: `fa-exclamation-triangle`,
            modalTitle: `Submit Form`,
            modalText: `This action is permanent. Are you sure you want to proceed?`,
            modalButtons: `<a role="button" class="btn btn-outline-warning waves-effect" data-dismiss="modal">Cancel</a>
            <a role="button" class="btn btn-warning waves-effect confirm">Yes</a>`
        },
        info: {
            modalTheme: `modal-info`,
            modalAlert: `fa-info-circle`,
            modalTitle: `Information`,
            modalText: ``,
        },
        danger: {
            modalTheme: `modal-danger`,
            modalAlert: `fa-times-circle`,
            modalTitle: 'Delete Form',
            modalText: 'This action is permanent. Are you sure you want to proceed?',
            modalButtons: `<a role="button" class="btn btn-outline-danger waves-effect" data-dismiss="modal">Cancel</a>
            <a role="button" class="btn btn-danger waves-effect confirm">Yes</a>`
        },
        success: {
            modalTheme: `modal-success`,
            modalAlert: `fa-check-circle`,
            modalTitle: ``,
            modalText: ``,
            modalButtons: `<a role="button" class="btn btn-success waves-effect" data-dismiss="modal">Ok</a>`
        }
    }

    // method for combining the available class for theme and alert to remove before adding the indicated one.
    getClasses() {
        const modelData = Object.entries(this.modalSettings)
        for (let item of modelData) {
            this.themeClasses += `${item[1].modalTheme} `
            this.alertClasses += `${item[1].modalAlert} `
        }
    }

    // method for setting modal elements on the fly
    setModalElements(mode, element, newvalue) {
        this.modalSettings[mode][element] = newvalue
    }

    // Method for modifying the Modal then displaying it on the screen when completed
    handleModal(mode) {
        this.getClasses();

        // Common Element changes
        $(`#${this.name} p.heading`).html(this.modalSettings[mode].modalTitle)
        $(`#${this.name} .modal-notify`).removeClass(this.themeClasses).addClass(this.modalSettings[mode].modalTheme)
        $(`#${this.name} div.text-center  i.fas`).removeClass(this.alertClasses).addClass(this.modalSettings[mode].modalAlert)
        $(`#${this.name} .modal-body-text`).html(this.modalSettings[mode].modalText)
        $(`#${this.name} .modal-footer`).html(this.modalSettings[mode].modalButtons)

        // Open the Modal
        $(`#${this.name}`).modal('show')
        $(`#${this.name}`).show()
    }

    hideModal() {
     //   $(`#${this.name}`).modal('hide');
     console.log("Hiding the Modal",this.name)
        $(`#${this.name}`).hide();
    }

}

class SofvieValidation {
    myElems = ''
    myButtons = ''
    returnValue = true
    materialRadioButtonValidationShowError() {
        // check radio buttons to see if there is one not checked
        let returnValue = true
        this.myElems = document.getElementsByClassName(`btn-group btn-group-sm d-flex`)
        for (let count = 0; count < this.myElems.length; count++) {
            if (this.myElems[count].getElementsByClassName(`btn btn-outline-primary form-check-label active`).length === 0) {
                document.getElementsByClassName(`invalid-feedback`)[count].style.display = 'block'
                returnValue = false
            } else {
                document.getElementsByClassName(`invalid-feedback`)[count].style.display = 'none'
                returnValue = true
            }
            // make all of the events for the buttons
            this.myButtons = this.myElems[count].getElementsByClassName(`btn btn-outline-primary`)
            for (var i = 0; i < this.myButtons.length; i++) {
                this.myButtons[i].addEventListener(`click`, () => {
                    document.getElementsByClassName(`invalid-feedback`)[count].style.display = 'none'
                })
            }
        }
        return returnValue
    }
}

class DateUtils {
    months = [`Jan`, `Feb`, `Mar`, `Apr`, `May`, `Jun`, `Jul`, `Aug`, `Sep`, `Oct`, `Nov`, `Dec`]
    fullMonths = [`January`, `February`, `March`, `April`, `May`, `June`, `July`, `August`, `September`, `October`, `November`, `December`]
    formatCurrentDate(type) {
        const myDate = new Date
        return `${myDate.getDate()} ${this.months[myDate.getMonth()]}, ${myDate.getFullYear()}`
    }


}

/**
 * Form Rules:
 * Class that emplements rules based on actions from radio buttons, check etc to open or close thier Sibling area
 * 
 *  */
class FormRules {
    activateRules() {
        // Form Rules for Radio Buttons
        const checkButtons = document.getElementsByClassName(`custom-radio`)
        for (let a = 0; a < checkButtons.length; a++) {
            checkButtons[a].addEventListener(`change`, (event) => {
                const radioNoRadio = event.srcElement.parentNode.classList.contains("no-radio")
                const radioNoSub = event.srcElement.parentNode.classList.contains("no-sub")
                const inputs = $(event.target).parent().parent().nextAll(`.cond-form-check-area:first`);
              if(!radioNoSub) {
                switch (event.srcElement.value.toUpperCase()) {
                    case 'COMPLETE':
                        radioButtonsShow(inputs)
                        break
                    case 'ACTION REQUIRED':
                        $(event.target).parent().parent().nextAll(`.cond-form-check-area:first`).show()
                        break
                    case 'NO': 
                    if(radioNoRadio)
                    {
                        radioButtonsShow(inputs)
                    }else {
                        radioButtonHide(inputs)   
                    }
                            break         
                    case '0': 
                    if(radioNoRadio)
                    {
                         radioButtonsShow(inputs)
                    }else {
                         radioButtonHide(inputs)   
                    }
                                    break                                                    
                    case 'YES':
                    if(!radioNoRadio)
                    {
                        radioButtonsShow(inputs)
                    //    event.srcElement.id === `improvement_action_subform_yes` ? window.open(`http://sofviemobile/forms/formPositiveActionSub.php?submissionId=${$('#submissionId').val()}`, '_blank') : ''
                    }else{
                        radioButtonHide(inputs)
                    }
                        break
                    case '1':
                        if(!radioNoRadio)
                        {
                            radioButtonsShow(inputs)
                        }else{
                            radioButtonHide(inputs)
                        }
                            break

                    default:
                        radioButtonHide(inputs)
                        break
                }
            }
            }, false);
        }

        function radioButtonHide(inputs) {
            let test =   $(event.target).parent().parent().nextAll(`.cond-form-check-area:first`).find('input,select,textarea')
            inputs.find('input,select,textarea').each((index, data)=>{
                if(data.required) {
                    data.classList.add('should_be_validated')
                    data.required = false
                }
           });
            $(event.target).parent().parent().nextAll(`.cond-form-check-area:first`).hide()
        }

        function radioButtonsShow(inputs){
            inputs.find('.should_be_validated').each((index, data)=>{
                data.classList.remove('should_be_validated')
                data.required = true
           });
            $(event.target).parent().parent().nextAll(`.cond-form-check-area:first`).show()   
        }

        // Form Rules for Check Boxes
        const chkboxButtons = document.getElementsByClassName(`cond-form-check`)
        for (let a = 0; a < chkboxButtons.length; a++) {
            chkboxButtons[a].addEventListener(`click`, (event) => {
                switch (event.srcElement.checked) {
                    case true :
                      event.srcElement.value = '1'
                      $('.invalid-feedback').css('display','none')
                      const inputs = $(event.target).parent().nextAll(`.cond-form-check-area:first`).find('.should_be_validated');
                      if(event.target.classList.contains('complete-off')) {
                          $('#completed-button').hide()
                      }

                      if(inputs.length > 0) {
                      let b=0;
                       do {
                        inputs[b].required = true
                        inputs[b].classList.remove('should_be_validated')
                        b++;
                      }
                      while (b < inputs.length && inputs[b].type !== 'radio');
                    }
                        $(event.target).parent().nextAll(`.cond-form-check-area:first`).show()
                        break

                    default:
                    event.srcElement.value = ''
                    let def = $(event.target).parent().nextAll(`.cond-form-check-area:first`).find('input,select,textarea')
                    if(event.target.classList.contains('complete-off')) {
                        $('#completed-button').show()
                    }
                    if(def.length > 0) {
                        let b=0;
                         do {
                            def[b].required = false
                            def[b].classList.add('should_be_validated')
                          b++;
                        }
                        while (b < def.length && def[b].type !== 'radio');
                      }
                        $(event.target).parent().nextAll(`.cond-form-check-area:first`).hide()
                        break
                }

            }, false);
        }     
    }

    hideRuleFields() {
        $(`.cond-form-check-area`).find('select, input, textarea').each((index,data) => {
            if(data.required) {
                data.required = false 
                data.classList.add("should_be_validated") 
               }
        
        });
        $(`.cond-form-check-area`).hide()
    }
}
