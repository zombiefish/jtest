 // function to reset toastr options
 function resetToastrOptions() {
    toastr.options.progressBar = false
    toastr.options.positionClass = undefined
    toastr.options.timeOut = 5000
}

//function to throw toastr with time interval
function throwToastr(type,message,time){
    toastr.options.timeOut = time
    toastr.options.positionClass = 'rmm-toast-custom'
    switch (type) {
        case 'success':
            toastr.success(message)
            break;
        case 'warning':
            toastr.warning(message)
            break;
        case 'error':
            toastr.error(message)
            break;
        case 'info':
            toastr.info(message)
            break;
    }
    resetToastrOptions()
}
