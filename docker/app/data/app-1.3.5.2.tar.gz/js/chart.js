class makeDonut {
  element = ``
  mode = "type"
  newChartData = "donutChart"
  totalItems = 0
  totalLegendLines = 0
  chartData = {
    chart: {
      renderTo: this.element,
      plotBackgroundColor: null,
      plotBorderWidth: null,
      plotShadow: false,
      marginTop: 60,
      height: "500",
      events: {
        redraw: function(element) {
          var series = this.series;
          let grand = 0;
          $.each(series, function(i, serie) {
            for (let data in series[0].data) {
              if (series[0].data[data]["y"] != undefined) {
                if (series[0].data[data]["visible"]) {
                  grand += series[0].data[data]["y"];
                }
              }
            }
          })
          this.setTitle( { text: `${grand}
          <button class="btn btn-outline-primary btn-rounded d-block waves-effect py-2" 
          id="${this.series[0].chart.renderTo.id}-toggle"  value="${this.series[0].chart.renderTo.id}">Toggle Legend</button>
          <span class="d-block pt-2" style="font-size: .8rem;">company wide<br>for the past 90 days</small>
          `})

        
        $(`#${this.series[0].chart.renderTo.id}-toggle`).click(event => {
          var x = $(`#${event.target.value} .highcharts-legend-item`);
          if (x.css("display") === "none") {
            x.css("display", `block`);
            $(`#${event.target.value} .highcharts-container`).css(
              "height",
              (this.series[0].chart.height = 600 + series[0].data.length * 44)
            );
          } else {
            x.css("display", `none`);
            $(`#${event.target.value} .highcharts-container`).css(
              "height",
              "650px"
            );
          }
        });
        },
        render: function() {}
      },
      style: { fontFamily: "inherit", fontWeight: "bold" }
    },

    title: {
      text: "",
      useHTML: true,
      align: "center",
      y: 295,
      style: {
        fontSize: "4rem",
        textAlign:"center"
      }
    },
    credits: {
      enabled: false
    },
    tooltip: {
      pointFormat: "{series.name}: <b>{point.percentage:.1f}%</b>"
    },
    plotOptions: {
      series: {
        showCheckbox: true
      },
      pie: {
        allowPointSelect: true,
        cursor: "pointer",
        dataLabels: {
          enabled: false
        },
        showInLegend: true
      }
    },
    colors: [
      "#0E6AC1",
      "#C0D7C5",
      "#64996B",
      "#097392",
      "#7FB5DB",
      "#FE9B56",
      "#B6D2EA",
      "#D55535",
      "#E59998",
      "#234234",
      "#FFF07C",
      "#D782B8",
      "#EF798A",
      "#20639B"
    ],
    series: [
      {
        type: "pie",
        name: this.chartLableType,
        innerSize: "75%",
        size:"500",
        data: this.newChartData
      }
    ],
    legend: {
      symbolWidth: 0,
      symbolHeight: 20,
      symbolPadding: 24,
      itemMarginTop: 10,
      itemMarginBottom: 10,
      layout: "vertical",
      useHTML: true,
      itemStyle: {
        lineHeight: "20px",
        fontWeight: "400",
        fontSize: "20px"
      },
      labelFormatter: function() {
        return (
          "<div style='width:450px;' class='d-flex justify-content-between'><span style='overflow: hidden; text-overflow: ellipsis;'>" +
          this.name +
          "</span><span>" +
          this.y +
          "</span></div>"
        );
      }
    }
  }
  legendColors = Array([
    "#0E6AC1",
    "#C0D7C5",
    "#097392",
    "#7FB5DB",
    "#FE9B56",
    "#B6D2EA",
    "#D55535",
    "#E59998",
    "#234234",
    "#FFF07C",
    "#D782B8",
    "#EF798A",
    "#20639B"
  ])

  constructor(element, chartData, title) {
    this.mode = "type"
    this.chartData.series[0].data = chartData
    this.chartData.series[0].name = title
    this.element = element
    this.setTotalLegendLines(chartData.length)
    this.setItemTotals(chartData)
    this.setCenterTitle()
  }

  setCenterTitle(title) {
    this.chartData.title.text = `${this.totalItems}
      <button class="btn btn-outline-primary btn-rounded d-block waves-effect py-2" 
      id="${ this.element}-toggle"  value="${this.element}">Toggle Legend</button>
      <span class="d-block pt-2" style="font-size: .8rem;">company wide<br>for the past 90 days</small>
    `
   
  }

  setItemTotals(data) {
    this.totalItems = 0
    for (let items in data) {
      this.totalItems += data[items][1]
    }
  }

  getChartData() {
    return this.chartData
  }

  getElement() {
    return this.element
  }

  setTotalLegendLines(total) {
    this.totalLegendLines = total
    this.chartData.chart.height = 600 + this.totalLegendLines * 44
  }

  setChartData(chartData) {
    this.chartData.series[0].data = chartData
    this.setTotalLegendLines(chartData.length)
    this.setItemTotals(chartData)
    this.setCenterTitle()
  }

  chartMainTitle(chart, title) {
    let myTitle = chart.renderer.text(`${title}`, 200, 40).attr({rotation: 0}).css({fontSize: "1.5rem"}).add()
    let textBBox = myTitle.getBBox();
    let x = chart.plotLeft + chart.plotWidth * 0.5 - textBBox.width * 0.5
    myTitle.attr({ x: x })
  }

  chartToggleButtons(pickedChart, chartData, title) {
    $(`#${this.element}`).before(`
    <div class="btn-group btn-group-sm d-flex mb-3" data-toggle="buttons" id="${
      this.element
    }-radio" style="margin: 0 auto auto auto; ">
      <label class="btn btn-outline-primary form-check-label focus active" >
        <input class="form-check-input" type="radio" name="chart-radio" id="type" value='type' checked> Type
      </label>
      <label class="btn btn-outline-primary form-check-label">
        <input class="form-check-input" type="radio" name="chart-radio" id="site" value='site'> Site
      </label>
    </div>
    `)
    $(`#${this.element}-radio`).click(e => {
      e.preventDefault();
      this.mode = e.target.children[0].value;
      pickedChart.setChartData(chartData[this.mode]);
      const myChart = Highcharts.chart(
        `${pickedChart.getElement()}`,
        pickedChart.getChartData(),
        chart => {
          pickedChart.chartMainTitle(chart, `${title}`);
        },
      )
    myChart.redraw()
    })
    
    $(`#${this.element}-toggle`).click(event => {
      var x = $(`#${event.target.value} .highcharts-legend-item`);
      if (x.css("display") === "none") {
        x.css("display", `block`);
        $(`#${event.target.value} .highcharts-container`).css(
          "height",
          (this.chartData.chart.height = 600 + this.totalLegendLines * 44)
        )
      } else {
        x.css("display", `none`);
        $(`#${event.target.value} .highcharts-container`).css(
          "height",
          "650px"
        )
      }
    })
  }
}
