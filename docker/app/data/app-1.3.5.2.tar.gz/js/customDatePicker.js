/* 
Ticket: SOF-13682 
The property 'max:true' restricts users from selecting future dates and it is
implemented for Preliminary Incident and Preliminary Investigation.
*/
function preventFutureDatePickerInit() {
    $('.prevent_future_datepicker').pickadate({
        format: 'yyyy-mm-dd',
        max: true,
        onClose : function(){
            this.$holder.blur()
        },
    }).removeAttr('readonly')
    .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
        evt.preventDefault()
    })
}