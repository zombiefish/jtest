// All these characters should be restricted in the front end
function validateText (data, allowedValues) {
    let invalidList = ['{{', '}}', '${', '$(', '==', '===', '&&', '--', '++', '||', '//', '/*', '*/']

    // To remove allowed values override
  
    if(allowedValues != undefined && allowedValues != null) {

        invalidList = invalidList.filter((val) => {
            return !allowedValues.includes(val)
        })
    }

    // To check if its not empty
    if(data){
        for (let i = 0; i < invalidList.length; i++) {
            if(data.includes(invalidList[i])){
                return false
            }
        } 
    }
    return true
}

function validateFormFields (form, allowBlank=false, allowFields = {}) {
    let formVal = document.forms[form]
    let validated_flag = true
    let validated_count = 0
    let total_input_count = 0

    // On saving a draft (allowBlank=true), was-validated class will not be added as mandatory condition 
    // is not required to be checked
    if (!allowBlank){                
        formVal.classList.add('was-validated')
    }
    for (let a = 0; a < formVal.length; a++) {
        if (formVal[a].tagName === "INPUT" || formVal[a].tagName === "TEXTAREA" && formVal[a].type != 'password') {
            total_input_count += 1
           
            if(!validateText(formVal[a].value, allowFields[formVal[a].id])){
                formVal[a].classList.add('invalid')
                formVal[a].setCustomValidity(false)
            }else{
                formVal[a].classList.remove('invalid')
                formVal[a].setCustomValidity("")
                validated_count += 1
            }
        }
        if (!allowBlank){
            if (!formVal[a].validity.valid) {
                validated_flag = false
            }
        }
    }
    //Return true if all the input/textarea fields are validated and are proper
    if(allowBlank){
        if (validated_count===total_input_count){
            validated_flag = true
        }else{
            validated_flag = false
        }
    }
    return validated_flag
}

// Function to reset the class list for the form fields
function resetFormFieldClassList (form){
    let formVal = document.forms[form]
    formVal.classList.remove('was-validated') 
    for (let a = 0; a < formVal.length; a++) {
        formVal[a].classList.remove('invalid')
        formVal[a].setCustomValidity("")     
    }
}

function cleanDoubleCurly(value) {
    if(typeof(value) != "string")
        return value

    value = value.replaceAll("{{", "")
    value = value.replaceAll("}}", "")
    return value
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }