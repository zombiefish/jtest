var form = document.forms[0];																										// Create a ref to our form
var primaryKeyField = form.keyField.value;																			// What form field is unique to use as an id.
//var output = document.getElementById( "output" );															// And to our output area (debugging)
var draft = document.getElementById(form.draftField.value);											// Name of our Draft selector
var debug = _DEBUG;																																// Set our debug flag
/*
var config = {																																	// Define some config itmes
						  draftDbName: 'safetodotemp', 																			// db name for draft storage
							draftRemoteSync: false,																						// Sync path for draft, false for none
							commitDBName: _DB_WRITE_NAME, 																				// Committed db name
							//commitRemoteSync: 'https://testforms.technicagroup.com:6984/safetodo'						// Sync path for committed, false for none
							//commitRemoteSync:  _DOMAIN + ':6984/safetodo'						// Sync path for committed, false for none
							commitRemoteSync:  _SYNCDOMAIN + ':' + _SYNCPORT + '/safetodo'						// Sync path for committed, false for none

							};
*/


(function() {
	document.addEventListener( "DOMContentLoaded", function() {										// On document loaded
		try	{																																				// Trigger form handling for Header
			formHeader.formInitialize(document.forms[0]);
		} catch(err)	{
			console.warn('formHeader.formInitialize does not exist. \n' + err);
		}

		try	{																																				// Trigger form handling for Body
			formBody.formInitialize(document.forms[0]);
		} catch(err)	{
			console.warn('formBody.formInitialize does not exist. \n' + err);
		}

		try	{																																				// Trigger form handling for Footer
			formFooter.formInitialize(document.forms[0]);
		} catch(err)	{
			console.warn('formFooter.formInitialize does not exist. \n' + err);
		}


		// Open connection to both DB's and leave them open (commitDB needs to be opoen to sync)
        // db = new PouchDB(config.commitDBName, {auto_compaction: true});							// Create a ref to the local DB
        // sync(db, config.commitRemoteSync);																					// sync to it.
		dbDraft = new PouchDB(DBconfig.draftDbName, {auto_compaction: true});					// Create a ref to the local Draft DB
		//sync(dbDraft, config.draftRemoteSync);																			// Sync to it
        //console.dir(getAllDrafts());
		getFormDraftList(draft)																											// Handle the draft list select box

		// Save a draft (local only) copy of this form. 	
		setTimeout(function(){ 	

		document.getElementById("saveDraft").addEventListener( "click", function( e ) {	// And a hook to form submission.
			stopAutoSave()
			document.getElementById("saveDraft").disabled = true;
			e.preventDefault();
			if(formHandle(form, 'draft'))	{	
				var json = toJSONString( form );																				// Convert the form submission to JSON
		//		if(debug) console.log(json);																				// Log it to the console
				if(primaryKeyField)	{																										// Is our unique key field identified
					key = draftName(primaryKeyField)
					if (form.checkValidity() === false) {																	// Was the form valid?
						e.preventDefault();																									// No, prevent firing
						e.stopImmediatePropagation()																			// and propogation
					} 
					form.classList.add('was-validated')																// Otherwise, mark it as valid
					addFormDraft(json, key.trim(), form.submissionId.value, form.formname.value);// Then save the JSON to our localDB
					return;
				} else	{
					alert('No primary keyfield defined for this form, please contact admin');
				}
			}
		}, false);																																	// End event handler for draft
	},1);
		// Save a local, and remote, copy of the form.

		setTimeout(function(){ 
		form.addEventListener( "submit", function( e ) {														// And a hook to form submission.
		e.preventDefault()																											// Stop normal processing of this form, we'll handle it
		stopAutoSave()
		autoValidateSave()

		// Handle any post processing to the form component
			if(formHandle(form, 'full'))	{																						// Terminate and validate form
				var json = toJSONString( form ) 																				// Convert the form submission to usable JSON 
				if(primaryKeyField)	{
					var key = draftName(primaryKeyField) 																	// Build a key for this submission
		 /// Start of Modal for Saving the Submission

		 formModal = new SofvieModal()                                           // initialize the Modal 
		 formModal.handleModal(`warning`)                                        // Display the Warning Modal
		 $(`.modal-footer .confirm`).click(() => {                               // create event listener for OK button
			formModal.hideModal()
			 // Submit to Pouch //
			 let formStatus = addForm( json, key, form.submissionId.value, form.formname.value, form._rev.value, form.formid.value);					                              // Send request to submit form
			 ////////////////////
		//	 formStatus = true;
			 if (formStatus) {     

	  } else {
				 formModal.setModalElements(`danger`, `modalText`, `The form submission failed.`)
				 formModal.setModalElements(`danger`, `modalTitle`, `Form Submission Failure`)
				 formModal.setModalElements(`danger`, `modalButtons`, `<a role="button" class="btn btn-outline-danger waves-effect" data-dismiss="modal">OK</a>`)
				 formModal.handleModal(`danger`)
				 startAutoSave()
			 }
		 })
		 // End of Modal Submit
		// Then save the JSON to our localDB
				} else	{
					alert('No primary keyfield defined for this form, please contact admin')
				}
			}	// End Form Valid
		}, false)		
	}, 1000)																															// End Event Handler for submit
	});
})();

	function draftName(primaryKeyField)	{
		// Build a unique form identifier for saved draft of 'this' form, based on the contents of the hidden keyField
		// All draft field names contain the timestamp and site.
		// INPUTS:
		//	primaryKeyField - the primaryKeyField values, can be a pipe '|' seperated array for compound id's.
		
		// Create a base name for this form (name + formatted timestamp)
		// if the form has PRENT in IT just cut it off - RR
		let fname = form.formname.value
		if(fname.indexOf(' PARENT') >= 0){
			fname = form.formname.value.slice(0, -7);
		}
		var draftTitle = fname + ' ' + formatDate(new Date(form.startFormTimeStamp.value));
		
		var arrKeys = primaryKeyField.split('|');																		// Split the definition on a pipe seperator
		arrKeys.forEach(function(element) {																					// Iterate over the resulting array
			draftTitle = draftTitle + ' ' + form[element].value;											// Append the value to the base name
		});
		if(debug) console.log(draftTitle);	
		return draftTitle;																													// Return it
		
	}
	
	function disableDraftKeys(primaryKeyField)	{
		// Disable our unique form identifiers after recalling a draft so that they cannot change (if they change, you cannot update/save)
		// All draft field names contain the timestamp and site.
		// INPUTS:
		//	primaryKeyField - the primaryKeyField values, can be a pipe '|' seperated array for compound id's.
		
		var arrKeys = primaryKeyField.split('|');																		// Retrieve and split our key elements from the form
			arrKeys.forEach(function(element) {																				// Iterate over them					
				if(document.getElementById(element).tagName == 'SELECT')	{							// Are we a select box?
					document.getElementById(element).parentNode.children[1].disabled = true; // Point to the customized select box
				}	else{
					form[element].disabled = true;																				// Disable each element so that they cannot be changed.
				}
		});
		
	}

	function formatDate(date) {																										
		// Return a human readable, short, date string
		// INPUTS:
		//	a date object (timestamp)
		// SJB: 20190809 - Enforce locale definitions (these should come from env). To solve issue with different date formats being submitted.
		return date.toLocaleString('en-CA', { timeZone: 'America/Toronto' });																								// Just return the date as defined by machine settings
	}

	function formHandle(form, submissionType)			{
		// Handle the form.  First perform any post processing before validation.
		try	{																																				// Call any form termination code in the header
			formHeader.formTerminate(form);
		} catch(err)	{
			console.warn('formHeader.formTerminate does not exist. \n' + err);
		}
		try	{																																				// Call any form termination code in the body
			formBody.formTerminate(form);
		} catch(err)	{
			console.warn('formBody.formTerminate does not exist. \n' + err);
		}
		try	{	
																			  
			formFooter.formTerminate(form);                                                                          // Call any form termination code in the footer
		} catch(err)	{
			console.warn('formFooter.formTerminate does not exist. \n' + err);
		}

		// Handle validation of the form component, we always validate the form header because the data is used in defining the draft.
		try	{		
			headForm = formHeader.formValidate(form)	  // Call any form validation code in the header
			if(headForm === false)	{															                     // If the header failed, abort
				return false;																														// Return failure to abort the event
			}				
		} catch(err)	{
			console.error('formHeader.formValidate: ' + err);
			return false;
		}

		if(submissionType !== 'full')	{																			 // Handle the special case of child forms (HAP/PID) using their respective form ids
			if(form.formid.value == 131042 || form.formid.value == 166071)	{					                     // We must always validate child forms whether submit or draft
				try	{																																		// Call any form validation code in the header
						return formFooter.formValidate(form);	
				} catch(err)	{
					console.error('formFooter.formValidate: ' + err);
					return false;
				}
			}
		 
		}	 else	{																																		// We can skip the body and footer validation for draft saves unless its a subform then we must force  validation
			try	{																																			// Call any form validation code in the body
				formBody.formValidate(form);	
			} catch(err)	{
				console.error('formBody.formValidate : ' + err);
				return false;
			}
			try	{				
				return formFooter.formValidate(form);	                                  	                           // Call any form validation code in the footer
			} catch(err)	{
				console.error('formFooter.formValidate:' + err);
				return false;
			}
		}
			document.getElementById("saveDraft").disabled = true;
		return true;
	}

	function toJSONString( form ) {																						// Convert form submission to JSON string
		// Extract all form elements, iterate over, extracte values, save as JSON Key:Value pairs
		// INPUTS:
		//	form - form object from the event listener
		var obj = {};																																// Create storage object
		var elements = form.querySelectorAll( "input, select, textarea" );					                            // Create a reference to all form element types
		for( var i = 0; i < elements.length; ++i ) {																    // Iterate over it
			var element = elements[i];																					// Extract the element type
			var name = element.name.substring(element.name.indexOf('~') + 1, 80);	                                    // Extract the name, stripping off everything to the left of the tilde. This is a kludge to work around dupe form element names in modals.
			var value = element.value;																					// The value

			if( name ) {																															// If it has a name attribute
				if(!obj[name]) {																												// Has this element already been added?
					if(element.matches('[type="radio"]')) {																// Is a radio button
						if(element.checked)	{																			// Is it checked
							obj[name] = element.value;																	// Assign the associated value to the element
						} 

					} else if (element.tagName == 'SELECT') {															// Is a select box 
							obj[name] = getSelectValues(element);														// Handle if it contains 1 or more selections.
					} else {
						obj[name] = element.value;																		// Its another kind of input element
					}
				}
			} 
		// 	if(debug)console.log(name + '=' + obj[name]);																		
		                                                                                                                // Store the values in the storage object
		 }
		return JSON.stringify( obj );																					// When were done iterating, convert the object to a JSON string and return it
	}
	
	function getSelectValues(select) {																					// Parse a select box for one or more selected items
		var result = [];																														// Initialize and array to hold our results
		var options = select && select.options;																			// Our option values
		var opt;																																		// Temp storage

		for (var i=0, iLen=options.length; i<iLen; i++) {														// Iterate over all options
			opt = options[i];																													// Copy the option

			if (opt.selected) {																												// Is it selected?
				result.push(opt.value || opt.text);																			// Push the value onto the array (value maybe the option value, or the option text)
			}
		}
		
		return result.join('|');																										// Join all the data separated by a comma (comma delimited list)
	}	
	
	function getUniquePhotoName(galleryName, photoElemName)	{											// Generate unique hidden field name for photo's
		// Generate a sequential element name as a suffix to photoElemName
		// INPUT :		galleryName - Name of display gallery	
		//						photoElemName = base elem name
		// OUTPUT: 	return unique file base on photoElemName
		var i = 1;																																	// Set the starting index
		for(i=1; ; i++)	{																														// Iterate over possible names
			photoName = form.formtype.value + '.' + galleryName + '.' + photoElemName + i;											// Create the name
		//	if(debug) console.warn('PhotoName: ' + photoName);	
			if(!document.getElementById(photoName))	{																	// If that name exist?
				break;																																	// Bust out or loop
			}
		}
		
	//	if(debug) console.log('PhotoName: ' + photoName);		
		return photoName;																														// Return the resolved 'next' name
	}

	// Set canvas size dynamically to match camera orientation
	//var canvasElement = document.querySelectorAll("canvas[id^=canvas]");            // Store all canvas elements that have id starting with 'canvas' in a variable

	window.onload = pageOrientation;                                                // Set the canvas size on page load
	window.addEventListener("orientationchange", pageOrientation);                  // Set the canvas size when page orientation changes

	function pageOrientation() {
		var canvasElement = document.querySelectorAll("canvas[id^=canvas]"); 
	setTimeout(function () {                                                      // Use timeout to delay the orientation check trigger
		canvasElement.forEach((canvas) => {
		canvas.setAttribute("width", "480");
		canvas.setAttribute("height", "640");

		if (window.innerWidth > window.innerHeight) {                               // Check if page orientation is landscape
			canvas.setAttribute("width", "640");
			canvas.setAttribute("height", "480");
		}
		})
		
	}, 1000);
	};

	function removeModalImg(imgWrapper) {
        const theElements = {
          modalTheme: `modal-danger`,
          modalAlert: `fa-times-circle`,
          modalTitle: `Delete Image`,
          modalText: `This action is permanent. Are you sure you want to delete this Image?`,
          modalButtons: `<a role="button" id='alertModalCancel' class="btn btn-outline-danger waves-effect">Cancel</a>
          <a role="button" id='deleteModalImageConfirm' class="btn btn-danger waves-effect confirm">Yes</a>`
        };
        showAlertModal($("#child-form")[0], "posModal", "warning", theElements);
    
        $("#deleteModalImageConfirm").click(() => {
          if(imgWrapper.parentNode.parentNode.children.length === 1){
            imgWrapper.parentNode.parentNode.parentNode.parentNode.classList.add('invalid')
           }
           imgWrapper.parentElement.remove();
           picInput = imgWrapper.previousSibling.getAttribute("name");												// Extract the name of the display image
           picInput = picInput.replace(/GALLERY+$/, '')												          // Strip off the trailing 'GALLERY' indentifier
           element = document.getElementById(picInput);												          // Get the element
           element.parentNode.removeChild(element);
          $('#alertModalShow').hide();
        });
	 }
	 
	function takePhoto(elemCanvas, elemVideo, elemPhotoButton, elemSnap, formField, elemGallery, selectedForm = form)	{				// Function to enable using device camera
		// first clear all of the pictures back to TakePhoto not snap Photo
		if(selectedForm.formid.value !== '131042' && selectedForm.formid.value !== '166071') {
		images = $('.photoImage')
		for(let a = 0; a < images.length; a++) {
			images[a].querySelector('.fa-camera').parentNode.style.display = 'none'
			if(images[a].querySelector('.fa-images').parentNode)
			images[a].querySelector('.fa-images').parentNode.style.display = 'block'
			images[a].querySelector('video').style.display = 'none'
			var old_element = images[a].querySelector('.fa-camera').parentNode;
            var new_element = old_element.cloneNode(true);
            old_element.parentNode.replaceChild(new_element, old_element);
		}
	}
		// Grab elements, create settings, etc.
		var canvas = document.getElementById(elemCanvas);														// Where will display the image
		var context = canvas.getContext('2d');																			// Context of the stream
		var video = document.getElementById(elemVideo);															// Where will display the video
		var photoButton = document.getElementById(elemPhotoButton);									// Where is the button that we clicked?
		var snap = document.getElementById(elemSnap);																// Where is the snap button that we clicked?
		var gallery = document.getElementById(elemGallery);													// Where is the gallery 
			front = false;
		var mediaConfig =   {
			advanced: [{
				facingMode: "environment"
			}]
		};																																					// Set our device parameters
		var errBack = function(e) {
			console.error('An error has occurred!', e)
		};

			// Enable display of components
			video.style.display = 'block';																							// Display the video feed
			snap.style.display = 'block';																							// Display the button to take the picture
			canvas.style.display = 'none';																							// Turn off the display of the image
			context.clearRect(video, 0, 0, canvas.width, canvas.height);								                            // New image, clear the canvas
		    var context = canvas.getContext('2d');																			            // Context of the stream
			photoButton.style.display = 'none';																					     // Turn off the image toggle

		// Put video listeners into place
		if(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {					// Does this browser support vid?
				navigator.mediaDevices.getUserMedia({video: mediaConfig})									// If it supports this vid requirements
				.then((stream) => {
				video.srcObject = stream;		    																				// Attach the video stream to the video element and autoplay.
			});  
		}

			// Trigger photo take
			snap.addEventListener('click', function(e) {		// Bind to the take a pic button
				e.preventDefault();																												// Don't bubble
				let curTimeStamp =  new Date().toLocaleString()
				context.drawImage(video, 0, 0, canvas.width, canvas.height);							// Whatever is on the video screen, grab it and stuff it onto the canvas
                canvas.parentNode.parentNode.classList.remove('invalid')
				var canvasImage = canvas.toDataURL("image/jpg");													// Copy the image to mem
				// Insert a new thumbnail into the gallery using the saved image.
				gallery.innerHTML += '<div class="col-md-3 col-sm-4 col-6 mb-3"><img name="' + formField + 'GALLERY" id="' + formField + 'GALLERY" width="100%" src="' + canvasImage + '"><span onclick="removeImg(this);" class="deleteGalleryImage far fa-2x fa-trash-alt text-secondary" title="Delete Item"></span></div>';
					let timeField = formField.split('.')[2].substring(6,100)
					console.log("This is the Time Field", timeField)
					$(`#${timeField}_timestamp`).remove()
					$('<input>').attr({ type: 'hidden', id: `${timeField}_timestamp`, name: `${timeField}_timestamp`, value:`${curTimeStamp}`}).appendTo('form');
				if(video.srcObject)	
		           video.srcObject.getVideoTracks().forEach(track => track.stop());					// Stop all video streams.

			// Hide display components
				video.style.display = 'none';																							// Shut off the video feed.
				snap.style.display = 'none';																							// Hide the shutter button
				canvas.style.display = 'none';																						// Display the image
				photoButton.style.display = 'block';																			// Show the grab photo button in case they want to retake.

				var input = document.createElement('input');															// Create an input element to form
				input.type = 'hidden';																										// Make it hidden
	//			photoName = formField.split('.');

	            if(photoName.length )	{
					input.name = photoName;																									// Name it whatever we were passed to the function
					input.id =  photoName;																									// Name it whatever we were passed to the function
				}
				input.value = canvas.toDataURL("image/jpg");															// Convert the canvas to a ping and store it in the hidden form field.
				selectedForm.appendChild(input);																									// Append the form element to the form.
			
				this.removeEventListener('click',arguments.callee,false);									       // Unhook the event on the shutter button
			});
			
			return false;
	}

    //Trigger photo delete
function removeImg(imgWrapper) {
		delImg = new SofvieModal()
		delImg.setModalElements('danger', 'modalTitle', 'Delete Image')
		delImg.setModalElements('danger', 'modalText', 'This action is permanent. Are you sure you want to delete this Image?')
		delImg.handleModal('danger')
		$(`.modal-footer .confirm`).click((e) => {
      let closestGallery = imgWrapper.closest(".photoGallery")
      imgWrapper.parentElement.remove();
			picInput = imgWrapper.previousSibling.getAttribute("name");												// Extract the name of the display image
			picInput = picInput.replace(/GALLERY+$/, '')												          // Strip off the trailing 'GALLERY' indentifier
			element = document.getElementById(picInput);												          // Get the element
      element.parentNode.removeChild(element);
      if (closestGallery.innerHTML === "" && closestGallery.closest(".photoImage").hasAttribute("required")) {
        closestGallery.closest(".photoImage").classList.add('invalid')
      }
			 $(`#theModal`).modal('hide')
    })

}
	
 	function getFormDraftList(selectID, url = '') {
		 console.log("Getting the Draft List", selectID)
		 // Retrieve JSON list of saved form drafts, and display in specified drop down
		// let formname = form.formname.value
		 formname = form.formid.value === '350049' || form.formid.value === '349935' ?  form.formname.value.slice(0, -7) : form.formname.value
		 if(selectID)	{																															// Is draft enabled?
			dbDraft.allDocs({																													// Get all matching drafts for this form name 
			  include_docs: true,
			  attachments: false,
				startkey: formname,
				endkey: formname + '\ufff0'
			}).then(function (result) {	
				let count = 0	
				console.log("These are the Draft Results", result)
				$.each(result.rows, function(i, obj){	
					fid = JSON.parse(obj.doc.formdata).formid																	// Iterate over the results 
					if( fid !== '131042' && fid !== '166071')
				count++;
			  });																						// If we got results
			  count === 0 ? $('#draft').parent().hide():$('#draft').parent().show()     // if there are no drafts do not show the pulldown
			  // handle result
				//if(debug) console.log(result);	
				console.log("This is the Select ID Here", $(selectID))																				// Output to console
				$(selectID).empty();																										// Whack the existing data in the select should be none
				$(selectID).append($('<option>').text("Select Draft").attr('value', ''));								// Add a prompt for the first entry
				$.each(result.rows, function(i, obj){																		// Iterate over the results 
					    fid = JSON.parse(obj.doc.formdata).formid																	// Iterate over the results 
					    if( fid !== '131042' && fid !== '166071')
					$(selectID).append($('<option>').text(obj.key).attr('value', obj.id));// Add them into the select list
				});
				if(url)
				{
					$(selectID).val(url).parent().find('label').addClass('filled')
				}
				if (typeof postOpAction !== 'undefined' && typeof postOpAction === 'function') {
					postOpAction()
				}
			
			}).catch(function (err) {
			  console.error(err);
			});
		}	
 	}
 	
	function getAllDrafts()	{
 		// Retrieve JSON list of saved form drafts
			dbDraft.allDocs({																													// Get all matching drafts for this form name 
			  include_docs: true,
			  attachments: false,
				startkey: '',
				endkey: '\ufff0'
			}).then(function (result) {																								// If we got results
			  // handle result
			  if(debug) console.log(result);																					// Output to console
				return result.rows;
			}).catch(function (err) {
			  console.error(err);
			});
 	}
	 
	 
	function getFormData(theForm, theURL = '') {	
		// Retrieve selected draft form and populate form
		let selectedDraft = ''
		if(theURL)
		selectedDraft = theURL.trim()
		if(theForm[theForm.selectedIndex]) {
	    selectedDraft = theForm[theForm.selectedIndex].value.trim()                           // Retrieve whatever was selected, and if it has a value, action it
		}
		if(selectedDraft)	{	
			$("#deleteDraft").css('display','block')
			$('#currentDraft').val(selectedDraft)				
			dbDraft.get(`${selectedDraft}`).then(function (result) {											                   	// Get selected item from the db
				var parsedJSON = JSON.parse(result.formdata);	  // Parse out the form data
				if(debug)
				  console.dir(parsedJSON);
				  
				clearAllQuestions()
				clearAllSignatures()
				putJSONForm(theForm, parsedJSON);
				document.forms[0]._rev.value = result._rev;															// Plug in the pouchdb value for revision
				document.forms[0]._id.value = result._id;	                                                        // Plug in the pouchdb value for the unique key
				checkForChildForms()
				if (typeof postOpAction !== 'undefined' && typeof postOpAction === 'function') {
					postOpAction()
				}
		        //	disableDraftKeys(form['keyField'].value);																// Disable all the key elements
			}).catch(function (err) {
			  console.error(err);
			});			
		} else	{																																		// A blank option was selected. 
			clearForm();																															// Clear the form in case their was soemthing there from a previous selection
      }
 	}

	function putJSONForm(theForm, parsedJSON) {
		if(parsedJSON.formname === 'PREOP') {
			findMachines(parsedJSON.machine_number) 
			populateQuestions(parsedJSON.machine_number,parsedJSON.machineType)
		}
        // remove all images
		$('.singleImage').remove()
		// clear all of the radio buttons
		$(".form-check-input").parent().removeClass('focus active')
		$(".form-check-input").attr('checked', false)

		// Put JSON array data into form values
		//	INPUTS:	theForm = pointer to form
		//					parsedJSON = JSON formatted for data

		let s=1;
		let xcount = 0;	
		//console.log(parsedJSON)
		$.each(parsedJSON, function(name, val){			                                                // Iterate over our parsed object
			var $el = $('[name="' + name + '"]');				                    	// Build a var pointing to the object
			// If we don't have an element, it must be a photo, we'll need to create a hidden field, and a gallery display
			if($el.length === 0)	{	
				var input = document.createElement('input');														// Create an input element to form
				input.type = 'hidden';
				input.classList.add('singleImage');																									// Make it hidden
				input.name = name;

				input.id = input.name;																									// Copy the name into the ID
				form.appendChild(input);																								// Append the form element to the form.
				$el = $('[name="' + name + '"]');																				// Copy a pointer to the newly created object

				var photoComponents = name.split('.');	
															// Parse out photo components from name (formname_gallername_photoname)
				if(photoComponents.length > 1) {
					document.getElementById(photoComponents[1]).innerHTML += '<div class="col-md-3 col-sm-4 col-6 singleImage mb-3"><img name="' + name + 'GALLERY" id="' + name + 'GALLERY" width="100%" src="' + val + '"><span onclick="removeImg(this);" class="deleteGalleryImage far fa-2x fa-trash-alt text-secondary" title="Delete Item"></span></div>';
				}
			$el.val(val);																														// Set the elements value

			} else	{																																	// This is a regular form element
				type = $el.attr('type');																								// Get its type
				if(type == undefined)	{																									// Properly handle input types
							type = $el[0].tagName;																						// Otherwise, use the tagName for selects
				}
			//	console.log("Found a checkbox", type)
				switch(type){																														// Handle special cases
					case 'checkbox':	                             // If it's a checkbox
					console.log("We have a checkbox",val)
					if(val === "1"){
						$el.val(val)
						$el.attr('checked', 'checked');	             	// Set the check attribute
					}
						break;
					case 'radio':
						// If it's a radio
						$el.filter('[value="'+val+'"]').attr('checked', 'checked');					// If their elements value matches the form, set the checked attribute
						$el.filter('[value="'+val+'"]').parent().addClass('active')
						break;
					case 'SELECT':																												// If it's a Select box
						SetSelectValue($el[0], val);
						break;
					default:																															// Otherwise
						$el.val(val);																			// Set the elements value

             if (val  && ($el[0].type === 'text' || $el[0].localName === 'textarea' || $el[0].type === 'number') && !$el.parent().find("label").hasClass('active')) {
               $el.parent().find("label").addClass('active');
			 }
                                                            // Image and data recall for Modal Signature
			if($el.hasClass('modalSignature')){
				let image = $el.val()
				if($el.val()) {
					let s = $el.prev().prev().children()
					s[0].innerHTML = '<i class="fa fa-pen"></i> Re-sign'
					s[1].classList.remove('d-none')
					let recall = $el.prev().attr('src', image)
				}
			}
		}

				if(type != 'hidden')	{																									// If these are dropdowns, populate and update
					if(name == 'job_number')	{																						// Trigger to populate job_number drop down
						formHeader.populateJobSelect(document.getElementById('site').value)
						SetSelectValue(document.getElementById('job_number'), val);
					}
					if(name == 'level')	{																									// Trigger to populate level drop down
						formHeader.populateLevelSelect(document.getElementById('site').value);
						SetSelectValue(document.getElementById('level'), val);
					}
				}

		// check if there are scores in the triangle
		if(document.forms[0].workplace_score) {
			workplaceScore = document.forms[0].workplace_score.value
			jobDefScore = document.forms[0].job_definition_score.value
			experienceScore = document.forms[0].experience_score.value
			if(workplaceScore && jobDefScore && experienceScore) {
			drawSafetyTriangle(workplaceScore, jobDefScore, experienceScore)  
			}	
		}
	}
	 // check to see if there is a Dynamic form Function

	});
		try {
			populateDynamicForm()
		}
		catch(err) {
			//console.log("this is the Error Message: ", err.message)
		}

		try {
			
		populateEquipmentDynamicForm()
		}
		catch(err) {
			//console.log("this is the Error Message: ", err.message)
		}
	}

    function SetSelectValue($el, value) {
  // Set the value in the options list of the select box to selected, can be a | delimited array.
  arrLen = $el.options.length;																								// How many option elements do we have
	var arrKeys = value.split('|');		// Try splitting
  // SJB: 20190307 - Modification to suit Select2 select box plug in for jquery
	$('#' + $el.name).val(arrKeys);

	if($el.classList.contains('score')){
		$('#' + $el.name).val(fixMultiSelects(arrKeys))
	}

    $('#' + $el.name).trigger('change');
    if (arrKeys != '') {
      $('#' + $el.name).next().next().addClass('filled')
    }
		return;
	}

	function fixMultiSelects(values) {
		let arr = [];
		let score = "";
		let pick = "";
		values.forEach((data, index) => {
			!isOdd(index) ? (pick = data) : (score = data);
			if (pick != "" && score != "") {
				arr.push(`${pick}|${score}`);
				pick = "";
				score = "";
			}
		});
		return arr;
	}
	
	function isOdd(num) {
		return num % 2;
	}

	function addFormDraft(text, pouchid, submissionID, formname, mode='yes', type='parent') {								// Write the JSON data to the local DB
		dbDraft.get(pouchid).then(function(doc) {		
			return dbDraft.put({											// Try to retrieve existing unique id																// If we got a result
				_id: pouchid,																														// Update it
				_rev: doc._rev,	
				submissionID: submissionID,		                                                                          // SJB: 20190329 - Make submissionID available
				formname: formname,																												// Must pass the existing revision
				formdata: text																													// and the data
			});
		}).then(function(response) {
            if(mode === 'yes'){
				updateDraftListSelect(pouchid)
				console.log("This is the Pouch ID after same id", pouchid)				
				showAlert()
			}	                                          

		}).catch(function (err) {
			if(debug) console.log('Creating New Rec: ' + err);												// This rec does not exist in the specified db, save it.
			dbDraft.put({																															// If we got a result
				_id: pouchid,																														// Overwrite it
				_rev: text._rev,																												// Must pass the existing revision
				submissionID: submissionID,																							// SJB: 20190329 - Make submissionID available
				formname: formname,
				formdata: text																													// and the data
			}).then( ()=> {
				if ($("#currentDraft").val() !== "" && type === 'parent') {
					dbDraft.get($("#currentDraft").val()).then(function(doc) {
					  return dbDraft.remove(doc);
					}).then(()=>{
					if(mode === 'yes') {
							console.log("This is the Pouch ID after new id", pouchid)
							updateDraftListSelect(pouchid)
							showAlert()   
						}
                                                       // Update draft list.
					});
				}
				else {
					if(mode === 'yes'){
						updateDraftListSelect(pouchid)
						console.log("This is the Pouch ID after same id", pouchid)
						showAlert()   
					}

				}
			});
		});		
 	}

    function updateDraftListSelect(pouchid)  {
		$("#draft").select2('destroy'); 
		getFormDraftList('#draft')
		$('#draft').select2({theme: "material", allowClear: true, placeholder:""})
		.on('select2:select', function(){$(this).parent().find('label').addClass('filled');})
		.on('select2:unselect', function(){
		  if($(".select2-selection__choice")[0]){
		  $(this).parent().find('label').addClass('filled');
		 }else {
		 $(this).parent().find('label').removeClass('filled');  
		 }
		})
		setTimeout(()=>{
			console.log("This is the Pouch id Final", pouchid)
			$('#draft').val(pouchid).trigger('change')
			console.log("This is the Draft Lable",$("#draft").parent().find('label'))
			$("#draft").parent().find('label').addClass('filled');
			$('#currentDraft').val(pouchid)
		},500)
	}

	async function addForm(text, pouchid, submissionID, formname, _rev, formid) {	// Write the JSON data to the local DB
 // add the Modal for adding the form
   
		var arrParent = {};																						// Create storage for all forms
		arrParent =	JSON.parse(text);																			// Convert our parent to an object to allow us to add children to it.
		
	var arrChildren = [];
		var arrIDs=[];																															// Storage for ID's to allow easier deletion later
		arrIDs.push({'_id' : pouchid, '_rev' : _rev}); 															// Store the parent ident
		if(debug) console.dir(arrParent);
	
		if(submissionID)	{																													// Is draft enabled?

			await dbDraft.createIndex({																			// Update our index (required by pouch)
				index: {fields: ['submissionID', 'formname']}													// Were querying by subid and formname
			}).then(function(response)	{
				if(debug) console.log('ReIndexed db');
			}).then(function(doc)	{

				dbDraft.find({selector: {																		// Query where subid matches and is not the parent form
					'submissionID':submissionID ,					
					'formname':  {"$ne": formname} 
				},
				fields: ['formdata', '_id', '_rev']																// We only care about the formdata
				
				}).then(function(doc)	{
					if(debug) console.log('result of child find');
					if(debug) console.dir(doc);

					for(s of doc.docs)	{																										// Iterate over the results
						arrIDs.push({'_id' : s._id, '_rev' : s._rev});												// Store the ID's so we can delete from drafts
						arrChildren.push({'formdata' :	JSON.parse(s.formdata)});							// and push on to the array
					}
					if(debug) console.log('arrIDs');	
					if(debug) console.dir(arrIDs);	

					if(debug) console.log('arrChildren');	
					if(debug) console.dir(arrChildren);	

	//				arrParent.doc.formdata['Children'] = arrChildren;
					arrParent['Children'] = arrChildren;

					if(debug) console.log('arrParent');	
					if(debug) console.dir(arrParent);

				}).then(function(doc)	{

					db.get(pouchid).then(function(doc) {																		// Check to see if this id already has been committed

						if(form.formid.value == 131042 || form.formid.value == 349935)	{			// If this is an actionable form (Hazard), throw an error to skip into the catch block
							if(debug) console.log('skipping Pouch exists check because of Hazard Action')
							throw true;						
						}

						console.error('addForm: Commit Found ID: ' + pouchid);								// It exists, you can't overwrite an ID
						alert('You cannot save this form. This id already exists\r\nID = ' + pouchid )
					//Reset disabled stated on Commit/Save button
						$('#saveEnable').prop('checked', false);															// UnCheck the save enable button
						$('#submit').prop("disabled","disabled");															// Disable the commit/save button.
						
						return false;
					}).catch(function (err) {
						// Everything is fine, proceed.
						db.put({
							_id: pouchid,																												// Update it
	//						_rev: _rev,
							submissionID: submissionID,																					// SJB: 20190329 - Make submissionID available
							formname: formname,
							formdata: arrParent,																							// and the data
							timestamp: +new Date																							// SJB: 20190809 - Timestamp this record to allow for easy deletion.
						}).then(function(response) {
							clearForm();																											// Clear the form
	//dbClose(db);
						}).then(function(response) {
							if(debug)	console.log('addForm: Commit Update ID: ' + pouchid);

							// SJB:20190425 - Update Target Notifications directly
							remoteData = JSON.parse(localStorage.getItem('remoteData'));			// Retrieve the array of targets
							targets = remoteData[0].targets;																	// Extract the notifications
							var formTarget = arrayItem = 0;																		// Declare our vars
							for(var arrayItem in targets)	{																		// Iterate over our target array
								if(targets[arrayItem].FDFormID == formid)	{											// Does it equal our formid? (arrParent.formid)
									formTarget = targets[arrayItem].Target;												// Get the Target value
									if(debug) console.log(formTarget);		
									formTarget = (formTarget) ? formTarget -1 :	0									// Decrement if were greater than zero
									targets[arrayItem].Target = formTarget;												// Stuff it back in the array
								}
									
							}
							if(debug) console.log(targets);
							remoteData[0].targets = targets;																	// Store the results back on our object
						//	targets = localStorage.setItem('remoteData', JSON.stringify(remoteData));												// Then store that back in local storage

						}).then(function(response) {
						// Check to see if this was from a draft, if so, delete the draft copy.
						for(s of arrIDs)	{																									// Iterate over the results					
							if(debug)	console.log('s._id: ' + s._id);
							dbDraft.get(s._id).then(function(doc) {														// Try to retrieve existing unique id
								if(debug) console.log('addForm: Draft Found ID (to delete): ' + s._id);
								return dbDraft.remove(																					// If we got a result
									doc._id, 
									doc._rev																											// Overwrite it
								);
								if(debug)	console.log('addForm: Draft Removed ID: ' + doc._id);
								getFormDraftList(draft);																				// Update draft list.

								
							}).catch(function (err) {
								console.warn('ERROR or nothing to delete from drafts: ' + err);	// Error
							});		

						}
            
            // Remove validation to eliminate issue with selects showing invalid styling after form submission
            $(`form.validated`).removeClass('was-validated')

						// Display the success modal (addForm is async, so we put this modal inline)
					 formModal.setModalElements(`success`, `modalText`, `The form has been submitted successfully.`)
					 formModal.setModalElements(`success`, `modalTitle`, `Form Submitted`)
					 formModal.setModalElements(`success`, `modalButtons`, `<a role="button" class="btn btn-outline-success waves-effect repeatform">Create Another</a>
					 <a role="button" class="btn btn-success waves-effect tohomepage" >OK</a>`)
					 formModal.handleModal(`success`)
					 console.log("Lets Start The modal")
					 $(`.modal-footer .repeatform`).click(() => {
						 formModal.hideModal();
						 sessionStorage.setItem("lastformdata", JSON.stringify(arrParent));
//						 console.clear();
						 location.reload();
					 })
					 $(`.modal-footer .tohomepage`).click(() => {
						 formModal.hideModal();
						 console.log(window.location.hostname.split('/'));
						 window.open($('#parentpage').attr('url'), '_self');
					//	 window.location.replace('http://' + window.location.hostname + $('#parentpage').attr('url'));
					 })

						return true;

					}).catch(function (err) {
						console.error('AddForm: Error Committing Data: ' + err);						// This rec does not exist in the specified db, save it.
						return false;
					});		

				});		
			});
			}).catch(function (err)	{
				console.error('Error finding child form');
				console.error(err);
				return false;
			});

		}																																						// End submissionid check
		return false;
 	}

	function modalDeleteDraft() {
		formModal = new SofvieModal();                                          // initialize the Modal 
		formModal.setModalElements(`danger`, `modalTitle`, `Delete Draft`)
		formModal.handleModal(`danger`)                                        // Display the Warning Modal
		$(`.modal-footer .confirm`).click(() => {                               // create event listener for OK button
      formModal.hideModal()       
		//	const formStatus = deleteDraft();                                // Send request to submit form
		var url = new URL(window.location.href);
		let urldraftid = url.searchParams.get("draftid");
		draftID = $('#draft').val()
		if(urldraftid)
		draftID = urldraftid
			dbDraft.get(draftID).then(function(doc) {
				 dbDraft.remove(doc);
				 setTimeout(function(){ window.history.back() }, 1000);
			});
		})
	}
	
	// This is an orphan
	function deleteDraft()	{																											// The user clicked the Reset/Delete Draft button
		if(form._id.value)	{																												// If this form has been saved previously (form has db id)
			if(form._rev.value)	{																											// And if it has a revision (redundant)
				dbDraft.get(form._id.value).then(function(doc) {															// Retrieve the form data
				  return dbDraft.remove(doc);																								// delete the doc
				}).then(function (result) {	       																			// and the housekeeping
				  form._rev.value= '';																									// Reset the form rev
				  form._id.value= '';																										// Reset the form id
				  getFormDraftList(draft);																							// Update the draft list
					}).then(function (result) {																						// and then
		  		clearForm();																													// Clear the form
				}).catch(function (err) {
				  console.error('ERROR deleting draft: ' + err);
				});				
			}
		}
	}

	function showAlert() {
		startAutoSave()
		document.getElementById("saveDraft").disabled = false;
		modalData = `<div class="alert alert-success" role="alert" id='alert-message'>Draft Saved</div>`
		$('#cancelForm').parent().after(modalData)
		$('#alert-message').delay(2000).fadeOut()
		setTimeout(()=>{
			$('#alert-message').remove()
		    if(window.sessionStorage.getItem('modalsave')) {
				window.sessionStorage.removeItem('modalsave')


		      } else{
			  window.history.back()
		    }
	  },2000)
	}

    function clearForm()	{
		// Iterate over form elements and set values to null
		var elements = form.querySelectorAll( "input, select, textarea" );					// Create a reference to all form element types
		var obj = {};																																// Create storage object

		for( var i = 0; i < elements.length; ++i ) {																// Iterate over it
			var element = elements[i];																								// Extract the element type
			var name = element.name;																									// The element name
			element.value = null;																											// Reset the value

			if( name ) {																															// If it has a name attribute
				if(!obj[name]) {																												// Has this element already been added?
					if(element.matches('[type="radio"]')) {																// Is a radio button
						if(element.checked)	{																								// Is it checked
							obj[name] = element.value;																				// Assign the associated value to the element
						} 

					} else if (element.tagName == 'SELECT') {															// Is a select box 
							obj[name] = getSelectValues(element);															// Handle if it contains 1 or more selections.
							element.selectedIndex = -1;

					} else {
						obj[name] = element.value;																					// Its another kind of input element
					}
				}
			}
		}

		// Delete all images in gallery
		while ($(".deleteGalleryImage")[0])	{
					$(".deleteGalleryImage")[0].parentElement.remove();										// Delete the node
		}
		//Reset disabled stated on Commit/Save button
			$('#saveEnable').prop('checked', false);																	// UnCheck the save enable button
			$('#submit').prop("disabled","disabled");																	// Disable the commit/save button.
    }
	/*	
		function sync(db, syncTo) {	
			if(navigator.onLine)	{																											//  If were online, bind to the server to sync
				if(syncTo)	{
				var opts = {live: true, retry: true};																		// Configure synching

				db.replicate.to(syncTo, opts)																						// One way replicate (to only)
				.then(function(response) {
					console.log('Replicating To: ' + syncTo);															// Log it to the console
						console.dir(response);
					}).catch(function (err) {
					console.error('Error replicating to : ' + syncTo + ' : ' + err);			// Report a warning that were not online. 
					});		
				}	else	{
					if(debug) console.log('Nothing to sync to');
				}
			} else	{
				console.warn('Browser offline, not replicating');
			}
			
		}
	*/

    function convertFieldTitle(input) {
		if (input.includes("_")) {
		  splitData = ''
		  temp = input.split("_")
		  temp.forEach((tempdata) => {
			splitData += tempdata.charAt(0).toUpperCase() + tempdata.slice(1) + " "
		  })
		  return splitData
		}
		return(input.charAt(0).toUpperCase()) + input.slice(1)
    }

  function getDraftSubmissions() {
		return new Promise((resolve, reject) => {
			dbDraft.allDocs({																													// Get all matching drafts for this form name 
				include_docs: true,
				attachments: false,
				}).then(function (result) {																								// If we got results
					resolve(result)
				}).catch(function (err) {
					reject(err)
				});
		   });
    }

  function checkForChildForms() {
		document.getElementById('hapChildExists').value = false
		document.getElementById('pidChildExists').value = false
		let subid  = document.getElementById('submissionId')
		let currentForm = document.getElementById('formname').value
			if(subid && (currentForm === 'HAZARD REPORT PARENT' || currentForm === 'POSITIVE IDENTIFICATION PARENT')){
			let draftData = getDraftSubmissions()
			draftData.then((data) => {
				for(let records in data.rows) {
					let formname = data.rows[records].doc.formname
					if(subid.value === data.rows[records].doc.submissionID) {
						if(formname === 'HAZARD REPORT') {
							document.getElementById('hapChildExists').value = true
							document.getElementById('hazards_identified').value = '1'							
						}
						if(formname === 'POSITIVE IDENTIFICATION') {
							document.getElementById('pidChildExists').value = true
							document.getElementById('positive_identification_opportunities_identified').value = '1'
						}
					}
				}
			})
		}
    }

  // Clear Questions on Draft recall  - created 2019-9-1 3:15 p.m.- RMR
  function clearAllQuestions(){
	   if(document.getElementById('preopQuestions')) 
		   document.getElementById('preopQuestions').innerHTML = ''
	
  }

  // Clear Modal Signature  - created 2019-9-1 9:30 a.m.- RMR
  function clearAllSignatures() {
	  $('.signatureImage').attr('src','')
	  $('.modalSignature').val('')
	  $('.sign').html('<i class="fa fa-pen"></i> Sign')
	  $('.clear_sign').addClass('d-none')
  }

  // Photo Capture functions created 2019-9-11 8:00 a.m. - RMR
  function capturePicture(canvas, elemName, galleryElement,source = "parent") {
	  // injection variable to insert the camera into the form using the <div id='insertPhotoModal'></div> that is in the footer.php file
		const pictureModal = 
		`<div class="modal fade" id="cameraModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
		  <div class="modal-dialog modal-notify modal-info m-0" role="document" style="max-width:100vw;" >
		    <div class="modal-content bg-dark" style="height:100vh; overflow:hidden;">
			    <div class="modal-body p-0">
				    <form method="post" action="" class="camModal">
              <div class="text-center buttonArea d-flex justify-content-center position-fixed w-100" style="bottom:20px; z-index:1;">
                <span id="photoCaptured" class="badge badge-secondary position-absolute" style="top: -40px;">PHOTO CAPTURED</span>
                <div class='btn-floating btn-white' mode='off' id="lightOnOff"><i class="fas fa-bolt"></i></div> 
						    <div class='btn-floating btn-white btn-lg' id="grabFrameButton"><i class="fas fa-camera"></i></div> 
						    <div class='btn-floating btn-white' id="closeCapture"><i class="fas fa-times"></i></div>
              </div>
					    <video autoplay style="width: 100vw;></video>
					    <input type="hidden" name="output" class="output" />
				    </form>
          </div>
		    </div>
		  </div>
		</div>`;
		
		// Insert the Modal into the Tag
		  $('#insertPhotoModal').html(pictureModal)
		// Show the Modal
		  $("#cameraModal").modal("show");
		// hide the Photocaptured tag until the photo is taken
		  $('#photoCaptured').hide()
        // open the video stream and active the camera aslo start witht the camera light off
			onGetUserMediaButtonClick(false)
		// event Listener for when you take a picture
		  $("#grabFrameButton").on("click",()=> {
			onTakePhotoButtonClick(canvas, galleryElement,elemName,source)
		  })
		  
	     // event listener to toggle the light on and off
		  $("#lightOnOff").on("click",(e)=> {
        d = false
        mode = e.currentTarget.getAttribute('mode')
			  if(mode === 'off'){
				d = true
          e.currentTarget.setAttribute('mode','on')
          e.currentTarget.innerHTML = '<span class="fa-stack" style="width:47px;"><i class="fas fa-bolt"></i><i class="fas fa-slash fa-stack-1x" style="-webkit-text-stroke: 1px white;"></i></span >'
			  } else {
          e.currentTarget.setAttribute('mode','off') 
          e.currentTarget.innerHTML = '<i class="fas fa-bolt"></i>'
			  }
			  stopStreamedVideo(document.querySelector("video"))
			  onGetUserMediaButtonClick(d)  
		  })
		 
		 // Event Listener to stop the video stream and close the Camera Modal 
		  $('#closeCapture').on('click', ()=>{
			stopStreamedVideo(document.querySelector("video"))
			$("#cameraModal").modal('hide')
			$("#cameraModal").hide();
		if($('#child-modal .show').length > 0){
			setTimeout(()=>{
				$('body').addClass('modal-open')
			}, 500)
		}
		  })
  }
  // Setup the Camera for Pictures and Light
  function onGetUserMediaButtonClick(mode = false) {
	  let supported = navigator.mediaDevices.getSupportedConstraints()
    let constraints = { advanced: [{ torch: mode }], video: { facingMode: ["environment"], width: 1080, height: 1920, aspectRatio: 1.777777778}}
	  navigator.mediaDevices.getUserMedia({
		  advanced: { torch: mode },
		  video: {
		    facingMode: ["environment"],
		    width: 1080,
        height: 1920,
        aspectRatio: 1.777777778
		  }
	  })
	  .then(mediaStream => {
		document.querySelector("video").srcObject = mediaStream;
		const track = mediaStream.getVideoTracks()[0]
		imageCapture = new ImageCapture(track)
		const photoCapabilities = imageCapture
		  .getPhotoCapabilities()
		  .then(cap => {
			track.applyConstraints(constraints)
		  }).catch(error => console.log(error));
  	  })
	  .catch(error => console.log(error))
}
  
  // function to Stop the Video Stream
  function stopStreamedVideo(videoElem) {
	 let stream = videoElem.srcObject
	 let tracks = stream.getTracks()
	  tracks.forEach(function(track) {
	  track.stop()
	 });
	videoElem.srcObject = null;
  }
  
  // function to capture the photograph image and store it into the canvas on the Parent Form
  function onTakePhotoButtonClick(canvas, galleryElement, elemName, source) {
	  // Capture the video image and create a Bitmap
	imageCapture.takePhoto().then(blob => createImageBitmap(blob)).then(imageBitmap => {
		const canvasCapture = document.querySelector(`#${canvas}`);
		// set the canvas size for in incoming picture
		canvasCapture.setAttribute('width','1080')
		canvasCapture.setAttribute('height','1920')
		// run function to mode the image to the canvas and create the Hidden input that will be used when tranmitting the picture with the form
		drawCanvas(canvasCapture, imageBitmap, galleryElement, elemName, source)
	  }).catch(error => console.log(error))
  }
  // function to send the bitmap to the canvas
  function drawCanvas(canvas, img, galleryElement, elemName,source) {
	  let removeFunction = `removeImg`
	  if(source === 'modal')
	  removeFunction = `removeModalImg`
	  var gallery = document.getElementById(galleryElement);
	  // set the canvas to rotate the picture 90 degrees
	  canvas.getContext("2d").clearRect(0, 0, 0, 0)
      canvas.getContext("2d").translate(1080, 0)
      canvas.getContext("2d").rotate(90 * Math.PI / 180);
	  canvas.getContext("2d").drawImage(img, 0, 0, 1920, 1080);
	  // convert the data to a jpeg
	  var canvasImage = canvas.toDataURL("image/jpeg");
	  // get a unique photoname because you can take multiple photos
	  let photoName = getUniqueModalPhotoName(galleryElement, elemName)
	  // insert the thumbnail image into the gallery
		gallery.innerHTML += `<div class="col-md-3 col-sm-4 col-6 mb-3"><img name="${photoName}GALLERY" id="${photoName}GALLERY" width="100%" src="${canvasImage}"><span onclick="${removeFunction}(this);" class="deleteGalleryImage far fa-2x fa-trash-alt text-secondary" title="Delete Item"></span></div>`;
	  // create and insert the hidden field with the unique field name theis sent to the server and parsed by its root name
		var input = document.createElement("input");
      input.setAttribute("type", "hidden");
	  input.setAttribute("name", photoName);
	  input.setAttribute("id", photoName);
	  input.setAttribute("value", canvasImage);
	  gallery.appendChild(input);
    //append to form element that you want.
    gallery.parentNode.classList.remove('invalid')

 // display "photo catured then fade out."	
  $('#photoCaptured').fadeIn(500).delay(1500).fadeOut(500);
  }

  function getUniqueModalPhotoName(galleryName, photoElemName)	{		
	// Generate unique hidden field name for photo's
	// Generate a sequential element name as a suffix to photoElemName
	// INPUT :		galleryName - Name of display gallery	
	//						photoElemName = base elem name
	// OUTPUT: 	return unique file base on photoElemName
    var i = 1;																																	// Set the starting index
	let photoName = `${form.formtype.value}.${galleryName}.${photoElemName}${i}`
	if (document.getElementById(photoName)) {
		i++
		photoName = `${form.formtype.value}.${galleryName}.${photoElemName}${i}`
       while(document.getElementById(photoName))
        {
		photoName = `${form.formtype.value}.${galleryName}.${photoElemName}${i}`
        i++
		} 
	}
	else {
		return photoName
	}
	return photoName	
  }
    // Code to autosave the form every 20 seconds if the header 
	// information is properly filled out
	let autoSaveInterval = ''
  function startAutoSave() {
	  console.log("The Parent Autosave has been Started")
		autoSaveInterval = setInterval(()=>{
			autoValidateSave()
		}, 20000)
	}

	// function to stop the Autosave interval on Submission
  function stopAutoSave() {
	  console.log("The Parent Autosave has been Stopped")
		clearInterval(autoSaveInterval);
	  }

  function autoValidateSave() {
		let formValidationStatus = $('form')[0].classList.contains('was-validated')  // Added a condition so if the form was validated before the autosave it will respect it
		let status = formHeader.formValidate($('form')[0],'autosave')
		if(status){
			window.sessionStorage.setItem('modalsave','1')
			document.getElementById('saveDraft').click() 
		if(!formValidationStatus){
			$('form')[0].classList.remove('was-validated')                       // check if the form was validated before the autosave.
		  }
		}
		console.log("Parent AutoSAVE")
	}

	startAutoSave()

	// this is used to disable the Select List when OTHER is used
	let olist = document.querySelectorAll('.otherclass')
	olist.forEach((data)=>{
		data.addEventListener('keyup', (e)=>{
			if(e.target.value === ''){
				e.target.parentNode.previousElementSibling.querySelector('select').required = true
			}
			else {
				e.target.parentNode.previousElementSibling.querySelector('select').required = false
			}
		})
	})
	// 2019-10-02 - RMR
	// These functions are used to handle a Dynamic form athat has and add/remove section in it
	// Mostly with Shift Reports
	// Initialize the Form for a new one
if(document.getElementById('numCrews')){
	let crews = ''
	const totalCrews = document.getElementsByClassName('crewsection').length + 1
	secs = document.getElementsByClassName('crewsection')
	for(c in secs){
		if(secs[c].classList)
	  secs[c].classList.add('d-none')
	}
	document.getElementById('removeCrew').classList.add('d-none')


// add a crew
document.getElementById('addCrew').addEventListener('click',(e)=>{
	crews = document.getElementById('numCrews').value
	if(crews < totalCrews) {
		crews++
		let myCrew = $(`.crewsection[value="${crews}"]`)
		myCrew.removeClass('d-none')
		makeRequired(myCrew.find('[isrequired]'))
		if(crews === totalCrews)
		e.target.classList.add('d-none')
		document.getElementById('numCrews').value = crews
	} 
	if(crews > 1 && crews <= totalCrews)
  	 document.getElementById('removeCrew').classList.remove('d-none')
})

// remove a crew 
document.getElementById('removeCrew').addEventListener('click',(e)=>{
	let theCrew = $(`.crewsection[value="${crews}"]`)
	theCrew.addClass('d-none')
	theCrew.find('textarea.md-textarea').val('').parent().find('label').removeClass('active filled')
	theCrew.find('input.form-control').val('').parent().find('label').removeClass('active filled')
	theCrew.find('select').val('').trigger('change').parent().find('label').removeClass('filled')

	photos = theCrew.find('.photoGallery img')
     // remove the photos from the gallery and the body
	for(let data in photos){
		if(photos[data].id){
			let picInput = photos[data].id
		    picInput = picInput.replace(/GALLERY+$/, '')
			element = document.getElementById(picInput);	
	        element.parentNode.removeChild(element);
		}
	}
	theCrew.find('.photoGallery').html('')
	removeRequired(theCrew.find('[required]'))
	crews--
	document.getElementById('numCrews').value = crews
	if(crews > 1 && crews <= totalCrews)
	document.getElementById('removeCrew').classList.remove('d-none')
	if(crews >= totalCrews){
		document.getElementById('addCrew').classList.add('d-none')
	}
	else{
		document.getElementById('addCrew').classList.remove('d-none')
	}
	if(crews === 1) 
	document.getElementById('removeCrew').classList.add('d-none')
//	autoValidateSave() 
})

// Populate the Form from a Draft by showing the sections activated in FormHandler
function populateDynamicForm() {
	crews = document.getElementById('numCrews').value
	if(crews > 1 && crews <= totalCrews)
	document.getElementById('removeCrew').classList.remove('d-none')
	if(crews >= totalCrews)
	document.getElementById('addCrew').classList.add('d-none')
	for (a = 2; a <= crews; a++) {
		let getCrew = $(`.crewsection[value="${a}"]`)
		getCrew.removeClass('d-none')
		makeRequired(getCrew.find('[isrequired]'))
	}
}

// when adding a crew make crew fields required
function makeRequired(elements) {
	for(let data in elements){
		if(elements[data].attributes) {
			elements[data].removeAttribute('isrequired')
			elements[data].setAttribute('required', '')
		}
	}
}

// when removing a crew make crew fields not required
function removeRequired(elements) {
	for(let data in elements){
		if(elements[data].attributes) {
		elements[data].setAttribute('isrequired','')
		elements[data].removeAttribute('required')
		}
	}
}
}
// END of Section RMR