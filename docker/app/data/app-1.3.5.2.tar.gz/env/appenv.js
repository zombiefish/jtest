(function (window) {
    window.__env = window.__env || {};
       // API url
   window.__env.mainApi = "https://devcore-app.sofvie.com"
   window.__env.resourceUrl = "https://devcore-resources.sofvie.com/"
//    window.__env.resourceUrl = "http://sofvieresources:85"
//    window.__env.apiUrl = 'https://devcore-app.sofvie.com:8003'
   window.__env.mysds_url = "https://clients.mysds.ca/api.php"
   window.__env.apiUrl =  'http://localhost:8000'
   // window.__env.apiUrl =  'http://192.168.13.58:8001'
   //  window.__env.imageUrl = "https://devcore-images.sofvie.com/"
   window.__env.mobileURL = "https://devcore-mobile.sofvie.com/"
   window.__env.imageUrl = "https://core-images.sofvie.com/"
   window.__env.idpUrl = "https://pentest-keycloak.sofvie.com/"
   window.__env.idpRealm = "sofvie"
   window.__env.idpClientId = "sofvie-app"
   window.__env.pentahoUrl = "https://reports.sofvie.com:9000/report/"
   window.__env.pentahoImagesUrl = "devcore-images.sofvie.com/"
   window.__env.pentahoUserName = "dev@cordev"
   window.__env.pentahoPassword = "G6YaA7Xhub"
   window.__env.pentahoPath = 'home%3Adev@cordev'
   window.__env.version =  '1.0'
   window.__env.test_environment = false
   window.__env.hr_departure_email = 'jcoles@sofvie.com'  //departures@technicamining.com
   window.__env.mysds_url = 'https://clients.mysds.ca/api.php'


       // Base url  
    window.__env.baseUrl = '/';
       // Whether or not to enable debug mode
      // Setting this to false will disable console output
    window.__env.enableDebug = true;
    window.__env.languages = [
         {
            id : 'default',
            label: 'Default'
         },    
         {
            id: 'english',
            label: "English"
         },
         {
            id: 'french',
            label: "French"
         }
    ];
    window.__env.themes = [
      {
         id : 'default',
         label: 'Default'
      },    
      {
         id: 'light',
         label: "Light"
      },
      {
         id: 'dark',
         label: "Dark"
      }
   ];

    }(this));