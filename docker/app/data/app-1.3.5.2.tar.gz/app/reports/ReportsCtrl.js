﻿angular
    .module('safeToDo')
    .controller('ReportsCtrl', ['$scope', '$timeout', '$sce', '$window', 'reportsService', 'gridService', 'select2Service', 'modalService', '$rootScope','profileService','$q','listService','equipmentService','adminTargetService','adminRoleService', 'documentReviewService', '$compile', 'exportCSV',
    function ($scope, $timeout, $sce, $window, reportsService, gridService, select2Service, modalService, $rootScope, profileService, $q, listService, equipmentService, adminTargetService, adminRoleService, documentReviewService, $compile, exportCSV) {
        var vm = this;
        vm.options = gridService.getCommonOptions();
        vm.reportSchedulerOptions = gridService.getCommonOptions(); // Report Scheduler options
        vm.reports = [];        
        vm.reportSchedulerList = [];
        vm.reportURL = '';
        vm.topSearch = "";
        vm.topSearchReportScheduler ="";
        vm.loadMessage = translateTag(3802) //Loading reports page. Please wait.
        vm.fullEmployeeList = []  
        vm.distributionList=[]
        vm.submitted = false
        vm.schedulerMode = ""
        vm.filter_parameter_type = 1
        vm.scheduledPeriod = []
        vm.scheduleReportFrequency = []
        vm.scheduleReportEnds = []
        vm.daysOfWeekTags = [8666,8660,8661,8662,8663,8664,8665]
        vm.daysOfWeek = []
        vm.dynamicRefListsObject = {}
        vm.controls = []
        vm.modalElements = {}
        vm.loadingFilters = false
        vm.actionsDisabled =true
        vm.report_is_group = false
        vm.report_selection = null
        vm.showInactiveObject = {}

        const NoDate = 1
        const DateRange = 2
        const RollingDateRange = 3
        vm.currentDateRange = NoDate
        vm.dateRangeData = {}
        vm.userFilters = []
        vm.schedule_report_ends = []

        
        const DATE_FILTERS = ['date_range', 'start_date', 'end_date', 'days_from_today', 'rolling_direction']

        vm.setupDaysOfWeek = ()=> {
            let rtrn = []
            for(let i=0;i<vm.daysOfWeekTags.length;i++){
              rtrn.push({id: vm.daysOfWeekTags[i], text: translateTag(vm.daysOfWeekTags[i])})
            }            
            return rtrn
        }
  
        vm.statusFilter = [
          {rld_id: 1, rld_name : translateTag(2045), status_flag : true}, // complete
          {rld_id: 0, rld_name : translateTag(5028), status_flag : true}  // incomplete
        ]

        vm.rollingRangeDescription = [
          {rld_id: -1, rld_name: translateTag(8878)}, // Past
          {rld_id: 1,  rld_name: translateTag(8879)}  // Future
        ]

        vm.resetModal = () => {
          vm.modalElements = {
            title: 'Modal Title',
            message: 'Modal Message RS',
            buttons: `<button class='btn btn-primary btn-lg' ng-click="vm.closeConfirmModal()">OK</button>`
          }
        }

        resetDateRange = () => {
          vm.dateRangeData = {
            start_date: '',
            end_date: '',
            days_from_today: null,
            direction : 1,
            offset_date_range : 0
          }
        }

        // Current record.
        vm.resetReportSchedule = () => {
          vm.currentReportSchedule = {
            rsm_description: "",
            rsm_rpt_id : null,
            rsm_frequency_rld_id: null,
            rsm_day_tag: null,
            rsm_end_rld_id: null,
            rsm_expire_date: null,
            rsm_start_date: null,
            rsm_occurrences: null,
            rsm_rsu_id: null, // saved filter id
            rsm_filters: [], // custom saved filters for this report from this user.
            rsm_distribution:[],
          }

          resetDateRange()

          vm.resetModal()
          vm.filter_parameter_type = 1
          vm.dynamicRefListsObject = {}
          vm.controls = []
          vm.submitted = false
        }
        vm.resetReportSchedule()        

        vm.showDaysOfWeek = () => {
          for(let i = 0; i < vm.scheduleReportFrequency.length; i++) {
            if(vm.currentReportSchedule.rsm_frequency_rld_id == vm.scheduleReportFrequency[i].rld_id)
              return vm.scheduleReportFrequency[i].rld_score == 7 || vm.scheduleReportFrequency[i].rld_score == 14
          }
          return false
        }

        vm.showEndsAfter = () => {          
          for(let i = 0; i < vm.scheduleReportEnds.length; i++) {
            if(vm.currentReportSchedule.rsm_end_rld_id == vm.scheduleReportEnds[i].rld_id)
              return vm.scheduleReportEnds[i].rld_option
          }
          return 0
        }

        vm.getSelectedOption = (ref_list, rld_id) => {
          for(let i = 0; i < ref_list.length; i++) {
            if(rld_id == ref_list[i].rld_id)
              return ref_list[i].rld_option
          }
          return 0
        }

        vm.getEmployees= () => {
          $q.all([
            profileService.getFullEmployeeProfile('all'),
            profileService.getDistributionList()
          ]).then(() => {
             vm.fullEmployeeList = profileService.readFullEmployeeProfile()
             vm.distributionList = profileService.readDistributionList()
          })
        }

        
        
        vm.topSearchChanged = function () {
            vm.options.api.onFilterChanged();
        };
        vm.options.isExternalFilterPresent = function () {
            return vm.topSearch !== "";
        };
        vm.options.doesExternalFilterPass = function (gridRow) {
            for (var property in gridRow.data) {
                if (gridRow.data.hasOwnProperty(property)) {
                    //any property in the row matches search box
                    if ((gridRow.data[property] + "").toLowerCase().indexOf(vm.topSearch.toLowerCase()) > -1) {
                        return true;
                    }
                }
            }
            return false;
        };

        var defWidth = 10;
        vm.options.onColumnResized = function (params) {
            if (params.column.colDef.field === 'ReportName') {
              defWidth = params.column.actualWidth;
            }
        };
 
        //Function for the top search bar in Report Scheduler Grid
        vm.topSearchReportSchedulerChanged = () =>{
          vm.reportSchedulerOptions.api.setQuickFilter(vm.topSearchReportScheduler)
        }

        var rptColumns = [
          {
            field: "Cat",
            headerName: "",
            minWidth: 40,
            maxWidth: 40,
            suppressMenu: true,
            cellRenderer: function (params) {
                return `<span class="pointer text-left" ng-click="reports.openReport('${params.data.ReportURL}','','filtered')"><i class="fa fa-external-link-alt" note="Launch Report" title="{{menu.translateLabels(3429)}}"></i></span>`
            }, filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab']
          },
          {
              field: "ReportName", headerName: "",
              minWidth: 250,
              maxWidth: 325,
              filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab'],
              cellRenderer: (params) => {                
                return `<span class="clip" ng-non-bindable>${params.value}</span>`
              }
          },
          {
              field: "ReportDescription", headerName: "",  
              filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab'],
              cellRenderer: 'tippyCellRenderer',
          } 
        ];

        // Report Scheduler Columns
        let reportSchedulerColumns = [
          {
              headerName: '',
              field: 'dummyCheckbox',
              maxWidth: 50,
              minWidth: 50,
              checkboxSelection: true,
              suppressMenu: true,
              suppressSorting: true,
              headerCheckboxSelection: true,
              headerCheckboxSelectionFilteredOnly: true,
          },
          {
              field: "review",
              headerName: " ",
              minWidth: 75,
              maxWidth: 100,
              suppressMenu: true,
              cellRenderer: (params) => {               
                return  `<span class="fa-1x fa-stack" style=" width: 1.25em;"><i class="fa fa-pen pointer" ng-click="reports.openScheduler('edit', ${params.data.rsm_id})" title="${translateTag(1194)}" notes="Edit"></i></span>`
                      + `<span  class="signoff-count"></span>` // Extra span to add a space between the icons
                      + `<span class="pointer text-left" ng-click="reports.openReport('${params.data.rsm_report_url}', '${params.data.rsm_report_url_arguments}', 'scheduled')"><i class="fa fa-external-link-alt" note="Launch Report" title="{{menu.translateLabels(3429)}}"></i></span>`
              },  
              filter: 'agSetColumnFilter',
               menuTabs: ['filterMenuTab']
          },
          
          {
              field: "rsm_report_name",
              headerName: " ", // Report Name
              minWidth: 150,
              maxWidth: 250,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: 'tippyCellRenderer',
          },
          {
              field: "rsm_description",
              headerName: " ", // Description
              minWidth: 150,
              maxWidth: 220,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: 'tippyCellRenderer',
          },
          {
              field: "rsm_distribution",
              headerName: " ", // Distribution
              minWidth: 100,
              maxWidth: 1000,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: 'tippyCellRenderer',
          },
          {
              field: "frequency_text",
              headerName: " ", // Frequency
              minWidth: 75,
              maxWidth: 200,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: 'tippyCellRenderer',
          },
          {
            field: "rsm_created_date",
            headerName: " ", // Created Date
            minWidth: 100,
            maxWidth: 150,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: 'tippyCellRenderer',
          },
          {
              field: "rsm_expire_date",
              headerName: " ", // Expiry Date
              minWidth: 100,
              maxWidth: 150,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: (params) =>
              {      
                  let expiryDate
                  if(params.data.rsm_expire_date){
                    expiryDate = moment(params.data.rsm_expire_date).format('YYYY-MM-DD') 
                    expiryDate = new Date(expiryDate)
                    expiryDate = new Date(expiryDate.getTime() + expiryDate.getTimezoneOffset() * 60000)
                  }

                  if(expiryDate) {
                    let currentDate = new Date()
                    let warningDate = new Date(expiryDate)
                    warningDate.setMonth(expiryDate.getMonth() -1)
                    if(currentDate > expiryDate){
                        return '<div class="text-danger" >'+moment(expiryDate).format('YYYY-MM-DD')+'</div>'
                    } else if(warningDate <= currentDate) {
                        return '<div  class="text-warning">'+moment(expiryDate).format('YYYY-MM-DD')+'</div>'

                    } else {
                      return  moment(expiryDate).format('YYYY-MM-DD') 
                    }
                  }
              },
          },
          {
            field: "rsm_modified_date",
            headerName: " ",
            minWidth: 100,
            maxWidth: 150,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: 'tippyCellRenderer',
          },    
        ]

        
        vm.reportSchedulerOptions.columnDefs = reportSchedulerColumns
        vm.options.columnDefs = rptColumns;
        vm.options.headerHeight = 0;
        vm.getEmployees()

        vm.reportSchedulerOptions.onSelectionChanged=  () =>{
          var selectedRows = vm.reportSchedulerOptions.api.getSelectedRows()
          vm.actionsDisabled = selectedRows.length === 0
          $scope.$apply()
        } 

        vm.prepareShowInactiveObject = (setDefault) =>  {
          
          let controls_length = vm.controls.length
          for(let i = 0; i < controls_length; i++) {
            if(setDefault == true){
              vm.showInactiveObject[vm.controls[i].rft_name] = false
            }
            else{
              vm.showInactiveObject[vm.controls[i].rft_name] = vm.controls[i].show_inactive
            }
          }
        }

        vm.modifyDynamicReflistObject = () => {
          let controls_length = vm.controls.length
          for(let i = 0; i < controls_length; i++) {
            noInactiveFilters = ['status', 'date_range']
            if(!noInactiveFilters.includes(vm.controls[i].rft_name)){
              changeEyeIcon(vm.controls[i].rft_name)
              vm.dynamicRefListsObject[vm.controls[i].rft_name] = vm.showHideInactive(vm.controls[i].rft_name)

            }
          }
        }

        vm.openScheduler = (mode="new", rsm_id) => {
          vm.schedulerMode = mode
          vm.showInactiveObject = {}

          vm.currentDateRange = NoDate
          vm.resetReportSchedule()
          vm.setEndDate()
          if(mode=="new") {
            vm.initializeSelect2('ReportScheduler').then(() => { // Wait for select2 initilize to finish to avoid incorrect style flashes
              modalService.Open('ReportScheduler')
            })
            vm.initializeDatePicker()
          } else if(mode=='edit') {
            reportsService.getSingleScheduledReport({"rsm_id": rsm_id}).then((data) => {                   
              if(data['group_by_report'] == true && data['group_by_report_id'] !== null){
                vm.report_is_group = data.group_by_report
                vm.report_selection = data.group_by_report_id
                vm.currentReportSchedule.rsm_rpt_id = data.rsm_rpt_id
                // get group by data            
                reportsService.getGroupByReports(data.rsm_rpt_id).then((data) => {
                  vm.groupby_report_data = data
                  
                })
              }
              
              if(data.rsm_is_scheduled)// The filter was created just for this scheduled report
                vm.filter_parameter_type = 0
              else                      // The filter was created through SofvieBI as a saved filter
                loadSavedFilterList(data.rsm_rpt_id, true)

              vm.currentReportSchedule = prepareEditData(data)
              buildFilterControls(data)
              data = filterControls(data['rsm_arguments'])
              for(let i = 0; i < data.length; i++) {
                vm.currentReportSchedule.rsm_filters[i].rft_values = data[i].rft_values
              }         
              vm.prepareShowInactiveObject()
            }).then(()=>{
              vm.initializeSelect2('ReportScheduler').then(() => { // Wait for select2 initilize to finish to avoid incorrect style flashes
                modalService.Open('ReportScheduler')
              }).then(()=>{
                vm.modifyDynamicReflistObject()
              })
              vm.initializeDatePicker()              
            })
          }          
        }        

        prepareEditData = (data) => {
          let preparedData = {
            rsm_id: data.rsm_id,
            rsm_description: data.rsm_description,
            rsm_rpt_id : data.rsm_rpt_id,
            rsm_frequency_rld_id: data.rsm_frequency_rld,
            rsm_day_tag: data.rsm_day_tag,
            rsm_end_rld_id: data.rsm_end_rld_id,
            rsm_expire_date: data.rsm_expire_date ? moment(data.rsm_expire_date).format('YYYY-MM-DD') : null,
            rsm_occurrences: data.rsm_occurrences,
            rsm_rsu_id: data.rsm_rsu_id, // saved filter id
            rsm_distribution: data.rsm_distribution,
            rsm_is_scheduled: data.rsm_is_scheduled,
            rsm_start_date: data.rsm_start_date ? moment(data.rsm_start_date).format('YYYY-MM-DD') : null,
            rsm_filters: [],
          }
          return preparedData
        }

        vm.closeScheduler = () => {
          // clear all fields.
          vm.resetReportSchedule()
          document.forms['reportSchedulerForm'].classList.remove('was-validated')  
          modalService.Close('ReportScheduler')
          vm.report_is_group = false
          vm.groupby_report_data = []
          vm.showInactiveObject = {}
          vm.dynamicRefListsObject = {}
        }

        vm.loadFiltersForReport = (allowSwitch)=> {
          vm.report_is_group = false
          //Reset all filter variables
          vm.dynamicRefListsObject = {}
          vm.controls = []
          vm.currentReportSchedule.rsm_rsu_id = null
          vm.currentReportSchedule.rsm_filters = []
          vm.userFilters = []
          vm.currentDateRange = NoDate
          vm.report_selection = null

          let report_id = vm.currentReportSchedule.rsm_rpt_id

          checkGroupByReport(report_id)
          if(vm.report_is_group){
            // get group by data            
            reportsService.getGroupByReports(report_id).then((data) => {
              vm.groupby_report_data = data
            })            
          }
          else{
            vm.loadFilters(report_id, allowSwitch)
          }
        }

        checkGroupByReport=(report_id)=>{
          vm.reports.forEach(element => {
            if(element.ID == report_id && element.rpt_is_group == 1){
              vm.report_is_group = true
            }
          });    
        }

        vm.loadFilters = (report_id, allowSwitch) =>{
          if(vm.report_is_group === true && (vm.report_selection == null || vm.report_selection == undefined)){
            vm.controls = []
            vm.userFilters = []
            return
          }
          if(vm.report_is_group){
            report_id = vm.report_selection
          }

          vm.dynamicRefListsObject = {}
          vm.controls = []
          vm.currentReportSchedule.rsm_rsu_id = null
          vm.currentReportSchedule.rsm_filters = []
          vm.userFilters = []
          vm.currentDateRange = NoDate
          if(vm.filter_parameter_type == 1) {
            loadSavedFilterList(report_id, allowSwitch)
          } else {
            vm.loadCustomFilter(report_id)
          }
        }

        loadSavedFilterList = (rpt_id, allowSwitch) => {
          if(!rpt_id)
            return          
          let payload = {
            "rfm_rpt_id" : rpt_id
          }
          if(vm.report_is_group){
            payload['sub_rpt_id'] = vm.report_selection
          }
          // call endpoint and retrieve the filter data
          reportsService.getUserSavedReportFilters(payload).then((data) => {
            if(data.rsu_filters.length > 0){
              vm.userFilters = data.rsu_filters
            }
            else if (allowSwitch) { // The user has no saved filters so switch to "Select filter values"
              vm.filter_parameter_type = 0
              vm.loadCustomFilter(rpt_id)
            }
          })
        }
        
        //Load saved filters with the saved data.
        vm.loadSavedFilter = () => {
          
          vm.controls = []
          vm.showInactiveObject = {}
          vm.currentReportSchedule.rsm_filters = []

          if(!vm.currentReportSchedule.rsm_rsu_id)
            return

          vm.loadingFilters = true

          let payload = {
            "rsu_id": vm.currentReportSchedule.rsm_rsu_id,
          }
          reportsService.getSingleSavedReportFilters(payload).then((data) =>{
            buildFilterControls(data)

            data = filterControls(data['rsm_arguments'])
            for(let i = 0; i < data.length; i++) {
              vm.currentReportSchedule.rsm_filters[i].rft_values = data[i].rft_values
            }
            vm.prepareShowInactiveObject()

            vm.initializeSelect2('ReportScheduler').then(() => { // Wait for select2 initilize to finish to avoid incorrect style flashes
              vm.loadingFilters = false
              $scope.$apply()
            }).then((data) => {
              vm.modifyDynamicReflistObject()
            })
            vm.initializeDatePicker()
          })         
        }
        
        vm.loadCustomFilter = (report_id) => {
          if(!vm.currentReportSchedule.rsm_rpt_id)
            return

          vm.loadingFilters = true
          vm.showInactiveObject = {}

          let payload = {
            "rfm_rpt_id" :  report_id
          }
          // call the endpoint to load the controls.
          reportsService.getReportFilters(payload).then((data) =>{
            buildFilterControls(data)
            
            vm.prepareShowInactiveObject(true)

            vm.initializeSelect2('ReportScheduler').then(() => { // Wait for select2 initilize to finish to avoid incorrect style flashes
              vm.loadingFilters = false
              $scope.$apply()
            }).then(()=>{
              vm.modifyDynamicReflistObject()
              vm.initializeSelect2('ReportScheduler')
              $scope.$apply()
            })
            vm.initializeDatePicker()
          })
        }

        buildFilterControls = (data) => {
          vm.controls = filterControls(data['rsm_arguments'])
          vm.dynamicRefListsObject = {}
          let promiseList = []
          let rftList = []
          for(let i = 0; i < vm.controls.length; i++){
            let item = vm.controls[i]
            item.show = true
            vm.currentReportSchedule.rsm_filters[i] = {
              rft_id: item.rft_id,
              rft_values: []
            }
            if(vm.controls.rft_type =='select')
              rft_values[0] = null
            if(item.rft_ref_name || item.rft_name === 'report_selection'){
                // Add to the ref_lists array.
                vm.dynamicRefListsObject[item.rft_name] = item.ref_data
            } 
            else { 
              // per_ids, equipment ids, form ids, role ids
              let employeeIdIdItems = [
                'per_ids' ,
                'by_who',
                'emp_ids',
                'from_who',
                'rec_by_ids',
                'user_ids'
              ]
              
              if(employeeIdIdItems.includes(item.rft_name)){
                let employee_data = getEmployeeList()
                vm.dynamicRefListsObject[item.rft_name] = employee_data 
                vm.controls[i]['ref_data'] = employee_data
              } else if (item.rft_name=='equipment_ids') {
                promiseList.push(getEquipmentList)
                rftList.push({rft_name:'equipment_ids', index: i})
              } else if(item.rft_name=='form_ids') {
                promiseList.push(getFormList)
                rftList.push({rft_name:'form_ids', index: i})
              } else if(item.rft_name=='role_ids') {
                promiseList.push(getRoleList)
                rftList.push({rft_name:'role_ids', index: i})
              } else if(item.rft_name=='doc_names') {
                promiseList.push(getDocumentNameList)
                rftList.push({rft_name:'doc_names', index: i})
              } else if (item.rft_name =='status') {
                vm.dynamicRefListsObject[item.rft_name] = vm.statusFilter
              } else if (item.rft_name =='full_equipment_ids') {
                promiseList.push(getFullEquipmentList)
                rftList.push({rft_name:'full_equipment_ids', index: i})
              } else {
                vm.dynamicRefListsObject[item.rft_name] = []
              }
            }
            
            // This is a special case for the pending general/hazard action reports
            if(vm.currentReportSchedule.rsm_rpt_id == 71 || vm.currentReportSchedule.rsm_rpt_id == 11) {
              if(item.rft_name == 'date_range')
                vm.controls[i].control_name = translateTag(9240)
            }
          }
          Promise.allSettled(promiseList).then((data) => {

            for(let j = 0; j < data.length; j++) {
              if (rftList[j].rft_name == 'equipment_ids') {
                vm.dynamicRefListsObject[rftList[j].rft_name] = data[j].value
                vm.controls[rftList[j].index]['ref_data'] = data[j].value
              } else if (rftList[j].rft_name == 'form_ids') {
                vm.dynamicRefListsObject[rftList[j].rft_name] = data[j].value
                vm.controls[rftList[j].index]['ref_data'] = data[j].value
              }  else if(rftList[j].rft_name == 'role_ids') {
                vm.dynamicRefListsObject[rftList[j].rft_name] = data[j].value
                vm.controls[rftList[j].index]['ref_data'] = data[j].value
              }  else if(rftList[j].rft_name == 'doc_names') {
                vm.controls[rftList[j].index].ref_data = data[j].value                
                vm.dynamicRefListsObject[rftList[j].rft_name] = []
              } else if(rftList[j].rft_name == 'full_equipment_ids') {
                vm.controls[rftList[j].index].ref_data = data[j].value                
                vm.dynamicRefListsObject[rftList[j].rft_name] = []
              }
              
            }
          }).then(()=>{
            for(let l = 0; l < vm.controls.length; l++) {
              if(vm.controls[l].rft_type == 'multiselect')
              {
                vm.multiSelectListChanged(l)
              }                
            }          
          })
        }
        
        // filter each time the list changes.
        filterDocNameList = (data) =>{
          let rtrn=[]
          let sites = vm.currentReportSchedule.rsm_filters.find(item=>{
            return item.rft_id == 14
          }).rft_values
          let docTypes = vm.currentReportSchedule.rsm_filters.find(item=>{
            return item.rft_id == 2
          }).rft_values

          for(let l =0; l < data.length; l++) {
            if(sites.includes(data[l].site) && docTypes.includes(data[l].document_type)) {
                rtrn.push(data[l])              
            }  
          }

          rtrn = [...new Map(rtrn.map(item => [item.rld_id, item])).values()]

          return rtrn
        }

        checkSitesJobs = (rft_name) =>{
          let selectedSiteValues = null
          
          if(rft_name == 'job_ids'){            
            vm.controls.forEach((element, index) => {
              if(element.rft_name === 'site_ids'){
                selectedSiteValues = vm.currentReportSchedule.rsm_filters[index].rft_values

              }
            })
          }
          return selectedSiteValues
        }

        vm.switchActiveInactive = (rft_name, switchIndex) => { 
          // if vm.showInactiveObject['rft_name'] = true, on click of this function switch from showInactive to false, so filter status flag to true 
          vm.showInactiveObject[rft_name] = !vm.showInactiveObject[rft_name]
          vm.dynamicRefListsObject[rft_name] = vm.showHideInactive(rft_name)          
          changeEyeIcon(rft_name)
          vm.initializeSelect2('ReportScheduler').then(()=>{
            $(`#${rft_name}_multi_select_${switchIndex}`).trigger("change");
          })
        }
        
        vm.showHideInactive = (rft_name) => {
          let tempList = []
          let siteValues = checkSitesJobs(rft_name)
          let actual_item = vm.controls.filter(function (item) {return item.rft_name === rft_name})
          let actual_list = []
          if(actual_item.length == 1){
            if(actual_item[0].ref_data !== undefined)
              actual_list = actual_item[0].ref_data
          }
          if(vm.showInactiveObject[rft_name] === false){
            for (let index = 0; index < actual_list.length; index++) {
              if(actual_list[index].status_flag === true){
                let value = filterList(rft_name, siteValues, actual_list[index])
                if(value !== undefined && value != null){
                  tempList.push(value)
                }
              }
            }
          }
          else{
            for (let index = 0; index < actual_list.length; index++) {
              let value = filterList(rft_name, siteValues, actual_list[index])
              if(value !== undefined && value != null){
                tempList.push(value)
              }
            }   
          }
          return tempList
        }

        filterList = (rft_name, siteValues, data) =>{
          if(rft_name ==='job_ids' && siteValues != null && siteValues.length > 0){
            if(siteValues.includes(data.rld_parent_detail_rld_id))
              return data
          }
          else{
            return data
          }
        }              

        changeEyeIcon = (rft_name) => {
          if(DATE_FILTERS.includes(rft_name)) {
            return
          }
          let showInactiveIcon = document.getElementById(`${rft_name}_showinactive`)
          let fa_eye = "fa-eye"
          let fa_eye_slash = "fa-eye-slash"
          
          if(vm.showInactiveObject[rft_name]){
            showInactiveIcon.classList.add(fa_eye)
            showInactiveIcon.classList.remove(fa_eye_slash)
            showInactiveIcon.title = translateTag(9170)
          }
          else{
            showInactiveIcon.classList.remove(fa_eye)
            showInactiveIcon.classList.add(fa_eye_slash)
            showInactiveIcon.title = translateTag(9171)
          }

          if(vm.filter_parameter_type == 1){
            disableIcons(rft_name)
          }
        }

        disableIcons = (rft_name) =>{
          let disabled_class = "disabled"
          let eye_button = document.getElementById(`${rft_name}_showinactive_button`)
          let select_all = document.getElementById(`${rft_name}_select_all_button`)
          let clear_all = document.getElementById(`${rft_name}_clear_all_button`)
          eye_button.classList.add(disabled_class)
          select_all.classList.add(disabled_class)
          clear_all.classList.add(disabled_class)
        }

        vm.selectAll= (rft_name, switchIndex) => { 
          $(`#${rft_name}_multi_select_${switchIndex}`).find("option").prop('selected', true)
          vm.initializeSelect2('ReportScheduler').then(()=>{
            setTimeout(() => {
              $(`#${rft_name}_multi_select_${switchIndex}`).trigger("change");              
            }, 100);
          })
        }
        vm.clearAll= (rft_name, switchIndex) => { 
          $(`#${rft_name}_multi_select_${switchIndex} option`).prop('selected', false);
          vm.initializeSelect2('ReportScheduler').then(()=>{
            $(`#${rft_name}_multi_select_${switchIndex}`).trigger("change");
          })

        }

        filterControls = (controls) =>{          
          let rtrn = []
          vm.currentDateRange = NoDate
          
          let additioanl_days_filters = ['days_from_today', 'offset_date_range']
          let controls_length = controls.length

          for(let c = 0; c < controls_length; c++) {
            if(controls[c].rft_type === 'datetime' || additioanl_days_filters.includes(controls[c].rft_name)) {

              //Todo: Add to another object for future use
              if(controls[c].rft_values && controls[c].rft_values.length > 0) {
                if(controls[c].rft_name === 'start_date'){
                  vm.dateRangeData.start_date = controls[c].rft_values
                  vm.currentDateRange = DateRange
                }
                if(controls[c].rft_name === 'end_date'){ 
                  vm.dateRangeData.end_date = controls[c].rft_values
                  vm.currentDateRange = DateRange
                }
                if(controls[c].rft_name === 'days_from_today'){
                  vm.dateRangeData.days_from_today = controls[c].rft_values[0]
                  vm.dateRangeData.days_from_today > 0 ? vm.dateRangeData.direction = 1 : vm.dateRangeData.direction = -1
                  vm.dateRangeData.days_from_today = Math.abs(vm.dateRangeData.days_from_today)
                  vm.currentDateRange = RollingDateRange
                  vm.rollingChanged()
                }
                if(controls[c].rft_name === 'offset_date_range'){                  
                  vm.dateRangeData.offset_date_range = controls[c].rft_values[0]
                  vm.currentDateRange = RollingDateRange
                  vm.rollingChanged()
                }

              }
            } 
            else {

              rtrn.push(controls[c])              
            }

            // If the ref list is using code add it to the name
            if(controls[c].ref_data) {
              for(rc = 0; rc < controls[c].ref_data.length; rc++) {
                if(controls[c].ref_data[rc].rld_code && controls[c].rft_ref_name !== 'ref_site'){
                  controls[c].ref_data[rc].rld_name = `${controls[c].ref_data[rc].rld_code} - ${controls[c].ref_data[rc].rld_name}`
                }
              }
            }

          }
          return rtrn
        }        

        const getEquipmentList = new Promise((resolve, reject) => {
          let equipment = []
          $q.all([equipmentService.getPreopEquipmentList('all')]).then(() =>{
            equipment = equipmentService.readListPreopEquipments()
            let equip=[]
            for(let i=0;i<equipment.length;i++){
              let equipitem = {
                rld_name : equipment[i].poe_equip_description,
                rld_id : equipment[i].poe_id,
                status_flag: equipment[i].status_flag == 0? false : true
              }
              equip.push(equipitem)                      
            }
            equip.sort((a,b)=> (a.rld_name.toLowerCase() > b.rld_name.toLowerCase() ) ? 1 : -1)

            resolve(equip)
          })
        })

        const getFullEquipmentList = new Promise((resolve, reject) => {
          let fullEquipmentList = []
          $q.all([equipmentService.getFullEquipmentList()]).then(() =>{
            fullEquipmentList = equipmentService.readFullEquipmentList()
            let fullEquipmentList_length = fullEquipmentList.length
            let equip=[]
            for(let i=0;i<fullEquipmentList_length;i++){
              if(fullEquipmentList[i].poe_equip_desc != null){
                let equipitem = {
                  rld_name : fullEquipmentList[i].poe_equip_desc ? fullEquipmentList[i].poe_equip_desc : '',
                  rld_id : fullEquipmentList[i].pet_id,
                  status_flag: fullEquipmentList[i].pet_enable == 0? false : true
                }
                equip.push(equipitem)  
              }                                  
            }
            if(equip.length > 0)
              equip.sort((a,b)=> (a.rld_name.toLowerCase() > b.rld_name.toLowerCase() ) ? 1 : -1)

            resolve(equip)
          })
        })        

        const getRoleList = new Promise((resolve, reject) => {
          let roleIds = []
          $q.all([adminRoleService.getAllRoleList("all")]).then(() =>{
            roleIds = adminRoleService.readRoleList()
            let role=[]
            for(let i=0;i<roleIds.length;i++){
              let roleitem = {
                rld_name : roleIds[i].aro_name_trans,
                rld_id : roleIds[i].aro_id,
                status_flag: roleIds[i].aro_enable == false ? false : true
              }
              role.push(roleitem)
            }

            role.sort((a,b)=> (a.rld_name.toLowerCase() > b.rld_name.toLowerCase() ) ? 1 : -1)

            resolve(role)
          })
        })
        
        getEmployeeList = () => {
          let emps = []
          for(let i = 0; i<vm.fullEmployeeList.length;i++){
            let emp = {
              rld_name: vm.fullEmployeeList[i].per_full_name,
              rld_id : vm.fullEmployeeList[i].per_id,
              status_flag : vm.fullEmployeeList[i].status_flag == 0 ? false : true
            }
            emps.push(emp)
          }
          return emps
        }

        const getFormList = new Promise((resolve, reject) => {
          let formIds = []
          $q.all([adminTargetService.getFormList("all")]).then(() =>{
            formIds = adminTargetService.readFormList()
            let form=[]
            for(let i=0;i<formIds.length;i++){
              if(formIds[i].FormName !== null && formIds[i].FormName !== undefined){
                let formitem = {
                  rld_name : formIds[i].FormName,
                  rld_id : formIds[i].FormID,
                  status_flag: formIds[i].status_flag == 0 ? false : true
                }                
                form.push(formitem)  
              }                                  
            }

            form.sort((a,b)=> (a.rld_name.toLowerCase() > b.rld_name.toLowerCase() ) ? 1 : -1)

            resolve(form)
          })
        })

        const getDocumentNameList = new Promise((resolve, reject) => {
          let documentNames = []
          $q.all([documentReviewService.getDocumentNameList()]).then(() =>{
            documentNames = documentReviewService.readDocumentNamesList()

            resolve(documentNames)
          })
        })

        checkSelectALL = (rft_id, rft_values) =>{
          vm.controls.forEach(control => {
            if(control.rft_id === rft_id){
              let object = control.ref_data              
              if(object !== undefined){
                let active_ids = []
                let all_ids = []
                let objectLength = object.length
                for (let index = 0; index < objectLength; index++) {
                  if(object[index].status_flag === true){
                    active_ids.push(object[index].rld_id)
                  }
                  all_ids.push(object[index].rld_id)
                }
                if(active_ids.length === rft_values.length && JSON.stringify(active_ids.sort()) === JSON.stringify(rft_values.sort())){
                  rft_values = ['allactive']
                }
                else if(all_ids.length === rft_values.length){
                  rft_values = ['all']
                }
              }
              
            }
          })

          return rft_values
        }

        vm.submitReportSchedule = (mode='new') => {
          
          if(validateFormFields('reportSchedulerForm')) {
            vm.submitted = true            
            // Add additional date range filters to the payload
            vm.currentReportSchedule.rsm_filters = vm.currentReportSchedule.rsm_filters.concat(prepareDateRangeData())
            vm.currentReportSchedule.rsm_filters.forEach(element => {
                element.rft_values = checkSelectALL(element.rft_id, element.rft_values)
            });
            
            if(vm.report_is_group){
              let report_selection = {
                "rft_id":24,
                "rft_values":[vm.report_selection]
              }
              vm.currentReportSchedule.rsm_filters.push(report_selection)
            }
            let payload = {
              'report_scheduler': vm.currentReportSchedule,
            }
            if(vm.schedulerMode === 'new') {

              reportsService.addScheduledReport(payload).then((response) => {
                vm.closeScheduler()
                vm.refreshReports()
              })
            } else {
              // Pass rsm_is_scheduled = true if the filter is custom
              vm.filter_parameter_type == 1 ? vm.currentReportSchedule.rsm_is_scheduled = false : vm.currentReportSchedule.rsm_is_scheduled = true

              reportsService.updateScheduledReport(payload).then((response) => {                
                vm.closeScheduler()
                vm.refreshReports()
              })
            }

          } else {
            $rootScope.$broadcast("CALLCONFIRMMODAL")
          }
        }

        vm.multiSelectListChanged = (index) => {
          if(vm.controls[index].rft_name == 'site_ids') {
            //filter jobs and documents
            let selectedValue = vm.currentReportSchedule.rsm_filters[index].rft_values ? vm.currentReportSchedule.rsm_filters[index].rft_values : []
            for(let i = 0;i< vm.controls.length;i++) {
              if(vm.controls[i].rft_name == "job_ids") {
                let filteredVals = []
                let showInactivJobIds  = vm.showInactiveObject["job_ids"]
                
                if(selectedValue.length == 0 ){
                  vm.dynamicRefListsObject[vm.controls[i].rft_name] = filteredVals             
                }
                else{
                  //do some job filtering here.                                  
                  for(let j = 0;j<vm.controls[i].ref_data.length;j++){
                    let data = vm.controls[i].ref_data[j]
                    if(data.rld_parent_detail_rld_id){
                      if(selectedValue.includes(data.rld_parent_detail_rld_id)){
                        if(showInactivJobIds){
                          filteredVals.push(data)
                        }
                        else{
                          if(data.status_flag == true){
                            filteredVals.push(data)
                          }
                        }
                      }
                    }
                  }
                  vm.dynamicRefListsObject[vm.controls[i].rft_name] = filteredVals

                }
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                  $scope.$apply()
              }
            }
          }

          if (vm.controls[index].rft_name =='site_ids' || vm.controls[index].rft_name == 'doc_ids') {
            //filter documents here based on site and type.            
            for(let i = 0; i < vm.controls.length; i++) {
              if(vm.controls[i].rft_name == "doc_names") {
                vm.dynamicRefListsObject[vm.controls[i].rft_name] = filterDocNameList(vm.controls[i].ref_data)
                vm.showInactiveObject["doc_names"] = true
              } 
            }

          }            
          if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
              $scope.$apply()     
          
        }


        vm.selectChanged = (filterName, ref_list, rld_id) => {
          if(filterName == 'date_range')
            vm.dateRangeSelectChanged(ref_list, rld_id)
        }

        vm.dateRangeSelectChanged = (ref_list, rld_id) =>{
          let dateRangeOption = vm.getSelectedOption(ref_list, rld_id)
          if(dateRangeOption == 2) {
            vm.currentDateRange = DateRange
            vm.dateRangeData.days_from_today == null
          } else if(dateRangeOption == 3) {
            vm.currentDateRange = RollingDateRange
            vm.rollingChanged()
          } else {
            vm.currentDateRange = NoDate
            resetDateRange()
          }
        }

        prepareDateRangeData = () => {
          let rtrn = []

          if(vm.currentDateRange == DateRange) {

            rtrn.push({
              rft_id: 15,
              rft_values: [vm.dateRangeData.start_date]
            })
            rtrn.push({
              rft_id: 4,
              rft_values: [vm.dateRangeData.end_date]
            })

          } else if(vm.currentDateRange == RollingDateRange) {

            rtrn.push({
              rft_id: 22,
              rft_values: [vm.dateRangeData.days_from_today * vm.dateRangeData.direction]
            })

            rtrn.push({
              rft_id: 25,
              rft_values: [vm.dateRangeData.offset_date_range]
            })

          }
          
          return rtrn
        }

        vm.closeConfirmModal = () => {
          modalService.Close('rsFormConfirmModal')
        }

        vm.openReport = (report, arguments, mode='filtered')=>{  
          let lang_number = localStorage.getItem('lang_id')
          if (mode==='scheduled'){
            let url_params = `lang=${lang_number}&${arguments}`
            // The below code converts the URL parameters into a JSON object
            let params_payload = JSON.parse('{"' + decodeURI(url_params).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g,'":"').replace(/\s/g,'') + '"}')
            params_payload['report_slug'] = report
            reportsService.saveFilterParametersForLongUrl(params_payload).then((res)=>{
              let url_arg = res['rfu_unique_code'].toString()
              vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${report}?report_filter_unique_code=${url_arg}`)
              $window.open(vm.reportURL, "_blank")
            })
          }else{
            vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${report}?lang=${lang_number}&${arguments}`)
            $window.open(vm.reportURL, "_blank")
          }
        }   
        
          //Funtion to export the selected rows to CSV file
        vm.exportCSV = () => {
            let rows = JSON.parse(JSON.stringify(vm.reportSchedulerOptions.api.getSelectedRows()))
            exportCSV.export_csv(rows, translateTag(9012))                            
        }

        //Function to open archive confirmation Modal
        vm.archiveConfirmationModal = () => {
          vm.archiveCount = vm.reportSchedulerOptions.api.getSelectedRows().length
          modalService.Open('rptArchiveConfirmationModal')
        }

        //Fuction used to close modals
        vm.cancelModal = (modalId) => {
          modalService.Close(modalId)
        } 

        //Function to archive the selected rows
        vm.archive = () => {
          var rows = vm.reportSchedulerOptions.api.getSelectedRows()
          if (rows.length > 0) {
            var ids = []
            for (var i = 0; i < rows.length; i++) {
                ids.push({rsm_id: rows[i].rsm_id})
            }          
            reportsService.archiveScheduledReport(ids).then((r) => {
              vm.refreshReports()
            })
          }
          modalService.Close('rptArchiveConfirmationModal')
          vm.actionsDisabled = true
        }

        vm.back = ()=>{
          vm.reportURL = null
          vm.refreshReports()
        }

        vm.refreshReports =() =>{
          $scope.$emit('STARTSPINNER', vm.loadMessage)
          $q.all([
            reportsService.getDateRange(),
            listService.getSelectListData('ref_report_schedule_frequency'),
            listService.getSelectListData('ref_report_schedule_end'),
            reportsService.getReports(),
            reportsService.getScheduledReportList(),
          ]).then((data) => {
            vm.scheduledPeriod =data[0]
            vm.scheduleReportFrequency =  data[1]
            vm.scheduleReportEnds = data[2]
            vm.daysOfWeek = vm.setupDaysOfWeek()
            vm.reports = data[3]            

            if (vm.options.api) {
              let model = vm.options.api.getFilterModel()
              vm.options.api.setRowData(fixTippy(vm.reports))
              vm.options.api.redrawRows()
              $timeout(function () {
                vm.options.api.sizeColumnsToFit()
                vm.options.api.setFilterModel(model)
              }, 500)
            }

            vm.reportSchedulerList = data[4]
            if (vm.reportSchedulerOptions.api) {
              let model = vm.options.api.getFilterModel()
              vm.reportSchedulerOptions.api.setRowData(vm.prepareGridData())
              vm.reportSchedulerOptions.api.redrawRows()
              translateAgGridHeader(vm.reportSchedulerOptions)
              $timeout(function () {
                vm.reportSchedulerOptions.api.sizeColumnsToFit()
                vm.reportSchedulerOptions.api.setFilterModel(model)
              }, 500)
            }

            $scope.$emit('STOPSPINNER')
          })
        }

        function fixTippy(data){
          // If any data needs to be fixed in the tippy add conditions to 
          // fix itppy.
          data.forEach((item) =>  {
              item.exceptionFields = ["rpt_is_group","rpt_output_type","ReportURL","ID","ReportName"]
            })
          return data
      }
        vm.prepareGridData = () => {
          let gridData = JSON.parse(JSON.stringify(vm.reportSchedulerList))          
          gridData.forEach((report) =>{ 
            report.frequency_text = getFrequencyText(report.rsm_frequency_rld)
            report.exceptionFields = ['rsm_frequency_rld', 'rsm_created_by_per','rsm_day_tag', 'rsm_end_rld_id','rsm_frequency_rld__rld_score','rsm_start_date','rsm_occurrences', 'rsm_report_url','rsm_report_url_arguments']
            report.rsm_modified_date = report.rsm_modified_date == null? '' : moment(report.rsm_modified_date).format('YYYY-MM-DD')
            report.rsm_created_date = report.rsm_created_date == null? '' : moment(report.rsm_created_date).format('YYYY-MM-DD')
            report.rsm_expire_date = report.rsm_expire_date == null? '' : moment(report.rsm_expire_date).format('YYYY-MM-DD')

          })
          return gridData
        }

        function getFrequencyText(value) {
          let freq = value
          vm.scheduleReportFrequency.forEach((fq)=>{
              if(fq.rld_id === value) {
                freq = fq.rld_name
              }
          })
          return freq
        }

        vm.rollingChanged = () => {
          let daysFrom = moment(new Date()).add(vm.dateRangeData.days_from_today * vm.dateRangeData.direction, 'days').format('YYYY-MM-DD')
          if(vm.dateRangeData.direction > 0) {
            // start date is today.
            // add the number of days to today into the future
            vm.dateRangeData.start_date =  moment(new Date()).format('YYYY-MM-DD')
            vm.dateRangeData.end_date = daysFrom
          } else {
            // end date is today.
            // add the number of days from today into the past
            vm.dateRangeData.end_date =  moment(new Date()).format('YYYY-MM-DD')
            vm.dateRangeData.start_date = daysFrom
          }
        }

        vm.refreshReports()

        $scope.$on('menu-width-changed', function () {
          $timeout(function () {
            if (vm.options.api) {
              vm.options.api.sizeColumnsToFit();
            }
            if (vm.reportSchedulerOptions.api) {
              vm.reportSchedulerOptions.api.sizeColumnsToFit();
            }
            }, 500);
        });

        $(window).on('resize', function () {
          $timeout(function () {
            if (vm.options.api) {
              vm.options.api.sizeColumnsToFit();
            }
            if (vm.reportSchedulerOptions.api) {
              vm.reportSchedulerOptions.api.sizeColumnsToFit();
            }
            });
        });

        $scope.$on("$destroy", function() {
            $(window).off('resize');
        });

        // This is a fix/hack to fix select2 preventing the modal scroll from working
        // Link: https://forums.select2.org/t/scrolling-prevented-on-page/1851/2
        $('.select').on('select2:open', function (e) {
          const evt = "scroll.select2";
          $(e.target).parents().off(evt);
          $(window).off(evt);
        });

        vm.setEndDate = () => {
          let expiryPicker = $("#schedule_ends_date_picker").pickadate('picker')
          if(vm.showEndsAfter() != 3){
            vm.currentReportSchedule.rsm_occurrences = null
          }
          if(vm.showEndsAfter() == 1 || vm.showEndsAfter() == 3){
            if(expiryPicker) {
              vm.currentReportSchedule.rsm_expire_date = null
            }
          } else if (vm.showEndsAfter() == 2){

            let from_picker = $('#rsm_start_date').pickadate('picker')
            
            if(expiryPicker){
              expiryPicker.set('min', moment(from_picker.get('value'), 'YYYY-MM-DD').add(1, 'days').format('YYYY-MM-DD'))

              expiryPicker.on('set', function(event) {
                if (event.select) {
                  if(from_picker) from_picker.set('max', expiryPicker.get('value'))
                    expiryPicker.set('min', from_picker.get('value'))
                } else if ('clear' in event) {
                  from_picker.set('max', false)
                  
                }
            
              })
            } 
          }
        }

        vm.initializeSelect2 = (parent)=> {
          return new Promise((resolve, reject)  => {
            setTimeout(()=>{
              $('.select-single, .select-multiple')
                .select2({ 
                  theme: "material", 
                  language: select2LanguageFunction(), 
                  allowClear: true, placeholder: "", width: '90%', 
                  dropdownParent: $(`#${parent} .modal-body`), escapeMarkup: function (text) { return text } })
                .on('select2:select', (event) => {
                  if (event.target.parentNode.querySelector('.distribution-list')){
                    $rootScope.$broadcast('distribution-list-added', event)
                    
                    
                  } else if (event.target.parentNode.querySelector('.selected_report')){
                  } 
                  $(this).parent().find('label').addClass('filled')
                })
                .on('select2:unselect', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list')){
                      $rootScope.$broadcast('distribution-list-removed', event)
                    }
                    $(this).parent().find('label').addClass('filled')
                })

                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()                
            }, 10)
            resolve(true)
          })
        }

        vm.initializeDatePicker = () =>{   
          setTimeout(()=> {
            $.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
            $('.datepicker').pickadate({
              format: 'yyyy-mm-dd',
            }).removeAttr('readonly').on('mousedown',
              function cancelEvent(evt) { 
                // This is a fix/hack to prevent the datepicker from flashing 
                // Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                evt.preventDefault()
            })

            $('#schedule_ends_date_picker').pickadate('picker').set('min', moment(new Date(), 'YYYY-MM-DD').add(1, 'days').format('YYYY-MM-DD'))

            let startPicker = $('#rsm_start_date').pickadate('picker')
            startPicker.set('min', moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD'))


            let from_picker = $('#start_date').pickadate('picker')
            let to_picker = $('#end_date').pickadate('picker')
            // Check if there's a 'from' or 'to' date to start with and if so, set their appropriate properties.
            if (from_picker.get('value') && from_picker.get('select')) {
              to_picker.set('min', from_picker.get('select'))
            }
            if (to_picker.get('value') && to_picker.get('select')) {
              from_picker.set('max', to_picker.get('select'))
            }
          
            // Apply event listeners in case of setting new 'from' / 'to' limits to have them update on the other end. If 'clear' button is pressed, reset the value.
            from_picker.on('set', function (event) {
              if (event.select) {
                to_picker.set('min', from_picker.get('select'))
              } else if ('clear' in event) {
                to_picker.set('min', false)
              }
            })
            to_picker.on('set', function (event) {
              if (event.select) {
                from_picker.set('max', to_picker.get('select'))
              } else if ('clear' in event) {
                from_picker.set('max', false)
              }
            })
          }, 50)
        }
      
}]);
