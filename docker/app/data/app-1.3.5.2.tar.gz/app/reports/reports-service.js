﻿angular
    .module('safeToDo')
    .service('reportsService', ['$http',
        function ($http) {

            return {
                getReports: function () {
                    return $http.get(`${__env.apiUrl}/api/report/reportlist/`)
                        .then(function (response) {
                            return response.data;
                        }, function (errorParams) {
                            console.log('Failed to load reports');
                            console.log(errorParams);
                        });
                }, 
                getGroupByReports: function (report_id) {
                    return $http.get(`${__env.apiUrl}/api/report/groupby-reportlist/${report_id}/`)
                        .then(function (response) {
                            return response.data;
                        }, function (errorParams) {
                            console.log('Failed to load reports');
                            console.log(errorParams);
                        });
                },                
                viewReports: function (reportArr) {
                    // reportArr objects: { ID: int, reportUrl: string }
                    for (var i = 0; i < reportArr.length; i++) {
                        console.log('opening window for ' + reportArr[i].ID);
                        window.open(reportArr[i].reportUrl + '&ID=' + reportArr[i].ID, '_blank');
                    }
                },
                getScheduledReportList: function() {
                    return $http.get(`${__env.apiUrl}/api/report-scheduler/get-scheduled-report-list/`)
                    .then(function (response) {
                        return response.data;                       
                    }, function (errorParams) {
                        console.log('Failed to load reports');
                        console.log(errorParams);
                    });
                },
                archiveScheduledReport: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/report-scheduler/archive-scheduled-report/`, payload).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to archive decision', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                addScheduledReport: function(payload){
                    return $http.post(`${__env.apiUrl}/api/report-scheduler/add-scheduled-report/`, payload)
                    .then(function (response) {
                        return response.data;
                    }, function (errorParams) {
                        console.log('Failed to add scheduled report');
                        console.log(errorParams);
                    });
                },
                updateScheduledReport: function(payload){
                    return $http.post(`${__env.apiUrl}/api/report-scheduler/update-scheduled-report/`, payload)
                    .then(function (response) {
                        return response.data;
                    }, function (errorParams) {
                        console.log('Failed to update scheduled report');
                        console.log(errorParams);
                    });
                },
                getSingleScheduledReport: function(payload){
                    return $http.post(`${__env.apiUrl}/api/report-scheduler/get-single-scheduled-report/`, payload)
                    .then(function (response) {
                        return response.data;
                    }, function (errorParams) {
                        console.log('Failed get single scheduled report');
                        console.log(errorParams);
                    });
                },
                getUserSavedReportFilters: function(payload){
                    return $http.post(`${__env.apiUrl}/api/report-scheduler/get-user-saved-report-filters/`, payload).then(
                        function (response) {
                            return response.data;
                        }, 
                        function (errorParams) {
                            console.log(errorParams)
                        }
                    );
                },
                getReportFilters: function(payload) {                    
                    return $http.post(`${__env.apiUrl}/api/report-scheduler/get-report-filters/`, payload)
                    .then(function (response) {
                        return response.data;
                    }, function (errorParams) {
                        console.log('Failed to get report filters');
                        console.log(errorParams);
                    }); 
                },
                getSingleSavedReportFilters: function(payload) {
                    return $http.post(`${__env.apiUrl}/api/report-scheduler/get-single-saved-report-filter/`, payload)
                    .then(function (response) {
                        return response.data;
                    }, function (errorParams) {
                        console.log('Failed to load single saved report filter');
                        console.log(errorParams);
                    }); 
                },
                getDateRange: function() {
                    return $http.get(`${__env.apiUrl}/api/report-scheduler/get-date-range/`)
                    .then(function (response) {
                        return response.data;
                    }, function (errorParams) {
                        console.log('Failed to load single saved report filter');
                        console.log(errorParams);
                    }); 
                },
                saveFilterParametersForLongUrl: function(payload) {
                    return $http.post(`${__env.apiUrl}/api/report-scheduler/save_filter_values_for_url/`, payload)
                    .then(function (response) {
                        return response.data;
                    }, function (errorParams) {
                        console.log('Failed to save the long URL');
                        console.log(errorParams);
                    }); 
                }
            };
        }
    ]);