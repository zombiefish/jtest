﻿angular
    .module('safeToDo')
    .service('hapsService', ['$http',
        function ($http) {
            function getObjectWithFormattedDates(input) {
                let inputWithGoodDates = {}
                for (let property in input) {
                    if (input.hasOwnProperty(property)) {
                        if (Object.prototype.toString.call(input[property]) === "[object Date]") {
                            inputWithGoodDates[property] = input[property].toJSON().split('T')[0]
                        } else if (property.indexOf('date') > -1 || property.indexOf('by_when') > -1) { // HACK: I don't like this
                            let dt = new Date(input[property])
                            let parts = input[property].split('/')
                            if (parts[0].length == 1)
                                parts[0] = '0' + parts[0]

                            if (parts[1].length == 1)
                                parts[1] = '0' + parts[1]

                            let newDate = parts[2] + '-' + parts[0] + '-' + parts[1]

                            inputWithGoodDates[property] = newDate
                        } else {
                            inputWithGoodDates[property] = input[property]
                        }
                    }
                }
                return inputWithGoodDates
            }
            return {
                getHaps: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/submission/get-submission-hap/`).then((response) => {
                            return response.data
                        }, (args) => {
                            console.log('Failed to load HAPs.',args)
                        })
                },

                getHapsByFilter: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/submission/get-submission-hap-by-filter/`, payload).then((response) => {
                        return response.data
                    }, (args) => {
                        console.log('Failed to load HAPs', args)
                        return []
                    })
                },

                getHapsByUsersJobsFilter: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/submission/get-submission-hap-by-filters-users-jobs/`, payload).then((response) => {
                        return response.data
                    }, (args) => {
                        console.log('Failed to load Site HAPs', args)
                        return []
                    })
                },                

                stageHapFiles: () => {
                    return $http.post('/api/localfiles').then((params) => {
                            return params.data
                        }, (failParams) => {
                                console.log('HAP File Stage Failed', failParams)
                        });
                },

                getStagedAttachments: (stageFolder) => {
                    return $http.get('/api/haps/initial/' + stageFolder + '/f' + '?bust=' + new Date().getTime())
                        .then((response) => {
                            return response.data
                        }, (args) => {
                            console.log('Failed to load followup attachments');
                        })
                },
                deleteInitialAttachment: (folderName, fileName) => {
                    return $http.delete('/api/haps/initial/' + folderName + '/' + encodeURI(fileName)).then((response) => {
                            return fileName
                        }, (args) => {
                            console.log('Cannot Delete Initial Atachment', args)
                        })
                },
                validateHap: (hap) => {
                    if (!hap.hazard_type) return "Hazard Type required."
                    if (!hap.hazard_identification) return "Hazard Identification required."
                    if (!hap.hazard_description) return "Hazard Description required."
                    if (!hap.potential_risk) return "Potential Loss required."

                    if (hap.recommended_action
                        || hap.action_by_who
                        || hap.action_type
                        || hap.action_by_when) {
                        // replace explicit "followup?" question with requiring all fields if 1 is filled in
                        if (!hap.recommended_action) return "Recommended Action required."
                        if (!hap.action_by_who) return "By Who required."
                        if (!hap.action_type) return "Action Type required."
                        if (!hap.action_by_when) return "By When required."
                    }
                },

                createHap: (formData) => {
                    return $http.post(`${__env.apiUrl}/api/incident-management/create-hap/`, formData, {
                        // this cancels AngularJS normal serialization of request
                        transformRequest: angular.identity,
                        // this lets browser set `Content-Type: multipart/form-data` 
                        // header and proper data boundary
                        headers: {'Content-Type': undefined}
                    }).then((response)=>{
                        return response
                    }, (errorParams) => {
                        console.log('Failed to create hap', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else
                            toastr.error(errorParams.data.error)
                    })
                },
                //api/incident-management/create-hap/
                updateFollowup: (formData) => {

                  return $http.post(`${__env.apiUrl}/api/incident-management/update-hap-followup/`, formData, {
                    // this cancels AngularJS normal serialization of request
                    transformRequest: angular.identity,
                    // this lets browser set `Content-Type: multipart/form-data` 
                    // header and proper data boundary
                    headers: {'Content-Type': undefined}
                    }).then((response) => {
                    return response.data;
                    }, (errorParams) => {
                        console.log('Failed to update followup', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else
                            toastr.error(errorParams.data.error)
                    })
                },

                completeHazardAction: (payload) =>{
                    return $http.post(`${__env.apiUrl}/api/ha/complete-hazard-action/`, payload)
                        .then((response) => {
                            return response.data
                        }, (args) => {
                            console.log('Failed to complete hazard action', args)
                    })
                },
                
                getInitialAttachments: (hapId) => {
                    return $http.post(`${__env.apiUrl}/api/hap/get-submission-attachment-by-hapid/`, { "hapid": hapId, "hap_type": 'INITIAL'})
                        .then((response) => {
                            return response.data
                        }, (args) => {
                            console.log('Failed to load followup attachments', args)
                    })
                },

                getFollowupAttachments: (hapId) => {
                    return $http.post(`${__env.apiUrl}/api/hap/get-submission-attachment-by-hapid/`, { "hapid": hapId, "hap_type": 'FOLLOWUP'})
                        .then((response) => {
                            return response.data
                        }, (args) => {
                            console.log('Failed to load followup attachments', args)
                    })
                },

                deleteFollowupAttachment: (hapId, fileName) => {
                    return $http.delete('/api/haps/' + hapId + '/followup/f/' + encodeURI(fileName))
                        .then((response) => {
                            return fileName
                        }, (args) => {
                            console.log('Error Delting Followup Attachment', args)
                    })
                },
                getHap: (hapId) => {
                    return $http.post(`${__env.apiUrl}/api/hap/get-individual-hap/`, { "hapid": hapId})
                        .then((response) => {
                            return response.data
                        }, (args) => {
                            console.log('Failed to load hap', args)
                    })
                }
            }
        }
    ])