﻿angular
    .module('safeToDo')
    .controller('HapsCtrl', ['$scope', '$rootScope', '$routeParams', '$window', '$location', '$q', 'formsService', 'hapsService', 'gridService', 'select2Service', 'modalService', 'listService', 'sitesService', 'profileService', 'employeesService', 'actionManagementService','exportCSV', 'menuService',
      function ($scope, $rootScope, $routeParams, $window, $location, $q, formsService, hapsService, gridService, select2Service, modalService, listService, sitesService, profileService, employeesService, actionManagementService, exportCSV, menuService) {
        let vm = this
        
        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        vm.actionTypeList = []
        vm.employeeList = []
        vm.fullEmployeeList = []
        vm.topSearch = ""
        vm.actionMode = 'new'
        vm.hazardEditData = {}
        vm.options = gridService.getCommonOptions()
        vm.actionTypes = listService.getActionTypes()
        vm.loadMessage = translateTag(3650) //Loading hazard actions page. Please wait.
        vm.formPermissions =  {
            viewAllHRSubmissions: false,
            viewOwnHRSubmissions: false,
            canViewOwnDailyLog: false,
            canViewAllDailyLog: false,
            canViewAllManagementSubmissions:false,
            canViewOwnManagementSubmissions:false
        }
        vm.canArchiveSubmissions = false
        vm.defaultDateFilter = '30'
        vm.mobileDisabled = true

        $rootScope.$on("MOBILE-LOADED", (event,result) => {
            vm.mobileDisabled = false
            $scope.$digest()
        })
        
        //Get permissions for the user
        menuService.getPagePermissions().then((data) => {
            vm.permissions = data         
            vm.canManageActionItems = vm.permissions.includes('Can Manage Action Items') ? true : false
            vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
            vm.canCloseAllActions = vm.permissions.includes('Can Close All Actions') ? true : false

        })


        vm.followup = {
            ID: 0,
            recommended_action: '',
            action_type: 0,
            action_by_who: [],
            action_by_when: '',
            action_status: 'INCOMPLETE',
            action_complete_by_who: [],
            action_completed_date: new Date(),
            completed_action_taken: '',
            completed_action_type: 0
        }

        vm.currentRow = {}

        vm.options.defaultColDef = {
            filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab'],
            headerCheckboxSelection: (params) => {
                var displayedColumns = params.columnApi.getAllDisplayedColumns()
                var thisIsFirstColumn = displayedColumns[0] === params.column
                return thisIsFirstColumn
            },
            checkboxSelection: (params) => {
                var displayedColumns = params.columnApi.getAllDisplayedColumns()
                var thisIsFirstColumn = displayedColumns[0] === params.column
                return thisIsFirstColumn
            }
        }

        let hapColumns = [
            { 
                field: "dummyCheckbox", 
                headerName: "", 
                width: 50, 
                suppressMenu: true, 
                suppressSorting: true, 
                headerCheckboxSelectionFilteredOnly: true 
            },
            {
               // headerName: "Header",
                children: [
                    {
                        field: "",
                        headerName: "",
                        width: 35,
                        suppressMenu: true,
                        cellRenderer: function (params) {
                            let invisible = params.data.action_status === translateTag(2045) ? 'invisible' : ''
                          return `<span class="pointer ${invisible}" ng-if="haps.canManageActionItems" ng-click="haps.openHazModal('hazardActionModal','edit', ${params.data.ID})"><i class="fa fa-pen" style="padding: 5px" note="Edit" title="{{menu.translateLabels(1194)}}"></i></span>`
                        }, 
                        filter: 'agSetColumnFilter', 
                        menuTabs: ['filterMenuTab']
                    },
                    {
                        headerName: " ",
                        field: "review",
                        cellRenderer: (params) => {
                            if(params.data.SubmissionHeaderID) {
                                return `<a class="source clip" href="/a/forms/${params.data.FormDescriptionID}?submissionId=${params.data.SubmissionHeaderID}">${params.data.FormName}</a>`
                            }
                            else {
                                return `<div class="clip">${params.data.FormName}</div>`;
                            }

                        },
                        valueGetter: (params) => {
                            return params.data.FormName
                        },
                        filter: 'agSetColumnFilter',
                        menuTabs: ['filterMenuTab'],                        
                        width: 200,
                        getQuickFilterText: function(params) {
                            return params.data.FormName;
                        },
                    },
                    {
                        //Added the id to the Ag-Grid and hid it. Used to sort the grid to show newest submissions first
                        field: 'ID',
                        hide: true,
                        sort: 'desc',
                    },
                    { 
                        field: "FormSubmissionDate",
                        headerName: " ",
                        width: 160,
                        filter: 'agSetColumnFilter',
                        // filterParams: gridService.dateFilterParams,
                        cellRenderer: 'tippyCellRenderer',
                    },
                    { 
                        field: "submitted_by",
                        headerName: " ",
                        width: 200,
                        filter: 'agSetColumnFilter',
                        menuTabs: ['filterMenuTab'],
                        filterParams: gridService.dateFilterParams,
                        cellRenderer: 'tippyCellRenderer',
                    },
                    {
                        field: "HeaderDate",
                        headerName: " ",
                        width: 160,
                        filter: 'agSetColumnFilter',
                        // filterParams: gridService.dateFilterParams,
                        cellRenderer: 'tippyCellRenderer',
                    },
                        {field: "Site", headerName: " ", cellRenderer: 'tippyCellRenderer' },
                        {field: "JobNumber", headerName: " ", cellRenderer: 'tippyCellRenderer', width: 120},
                        {field: "SiteLevel", headerName: " ", cellRenderer: 'tippyCellRenderer' },
                        {field: "Workplace", headerName: " ", cellRenderer: 'tippyCellRenderer', width:350 },
                        {field: "Supervisor", headerName: " ", cellRenderer: 'tippyCellRenderer'}
                ]
            },
            {
                headerName: translateTag(1320),
                children: [
                        { field: "hazard_type", headerName: " ", hide: true},
                        { field: "hazard_identification", headerName: " ", hide: true},
                        { field: "hazard_description", headerName: " ",  hide: true},
                        { field: "potential_risk", headerName: " ",  hide: true, cellRenderer :'tippyCellRenderer'}
                ]
            },
            //immediate actions
            {
                headerName: translateTag(1719),
                children: [
                  { field: "immediate_action_required_and_performed", headerName: " ", valueGetter: gridService.yesNoValueGetter},
                  { field: "immediate_action_taken", headerName: " ", cellRenderer: 'tippyCellRenderer',},
                  { field: "immediate_action_type", headerName: " ", cellRenderer: 'tippyCellRenderer',}, 
                    {
                        field: "further_action_required", headerName: " ",
                      valueGetter: gridService.yesNoValueGetter,
                        hide: true
                    }
                ]
            },
            //recommended followup
            {
                headerName: translateTag(1215),
                children: [
                    { field: "recommended_action", headerName: " ", cellRenderer: 'tippyCellRenderer',},
                  { field: "action_type", headerName: " ", cellRenderer: 'tippyCellRenderer',},
                  { field: "ActionAssignedTo", headerName: " ", cellRenderer: 'tippyCellRenderer',},
                  { field: "action_by_when",  headerName: " ", filter: 'agSetColumnFilter', 
                        cellRenderer: (params) => {
                            let expiryDate = new Date(params.data.action_by_when)
                            let currentDate = new Date()
                            let status = params.data.action_status
                            params.data.action_by_when =  params.data.action_by_when != null ? params.data.action_by_when : ''
                            if (expiryDate < currentDate && status == "Incomplete")
                                return '<div class="red-text">' + params.data.action_by_when + '</div>'
                            else
                                return '<div>' + params.data.action_by_when + '</div>'
                        },
                }
                ]
            },
            //actual followup
            {
            headerName: translateTag(1216),
                children: [
                    { field: 'action_status', headerName: " ", width: 120, cellRenderer: 'tippyCellRenderer'},
                    { field: "completed_action_taken", headerName: " ", cellRenderer: 'tippyCellRenderer',},
                    { field: "completed_action_type", headerName: " ", cellRenderer: 'tippyCellRenderer',},
                    { field: "action_complete_by_who", headerName: " ", cellRenderer: 'tippyCellRenderer',},
                    { field: "action_completed_date", headerName: " ", filter: 'agSetColumnFilter', cellRenderer: 'tippyCellRenderer',                 
                 },
                ]
            },
            {
                field:"FollowupAttachments",
                hide:true
            },
            {
                field:"FormID",
                hide:true
            },
            {
                field:"SubmissionHeaderID",
                hide:true
            },
            {
                field:"SubmissionHeaderLabel",
                hide:true
            },
            {
                field:"SubmissionID",
                hide:true
            },
            {
                field:"completed_action_score",
                hide:true
            },
            {
                field:"followup_attachments_count",
                hide:true
            },
            {
                field:"hazard_identification_score",
                hide:true
            },
            {
                field:"immediate_action_score",
                hide:true
            },
            {
                field:"initial_attachments_count",
                hide:true
            },
            {
                field:"potential_risk_score",
                hide:true
            },
            {
                field:"sha_created_by_per_id",
                hide:true
            },
            {
                field:"sha_created_date",
                hide:true
            },
            {
                field:"sha_modified_by_per_id",
                hide:true
            },
            {
                field:"sha_modified_date",
                hide:true
            },
            {
                field:"submitted_by_per_id",
                hide:true
            },
            {
                field:"FormDescriptionID",
                hide:true
            }
        ] 

        vm.options.columnDefs = hapColumns;

    function mainLoadHaps() {
        $scope.$emit('STARTSPINNER', vm.loadMessage)
        $q.all([
            profileService.checkUserPermission('View All HR Submissions'),
            profileService.checkUserPermission('View Own HR Submissions'),
            profileService.checkUserPermission('Can View Own Daily Log'),
            profileService.checkUserPermission('Can View All Daily Log'),
            profileService.checkUserPermission('Can View All Management Submissions'),
            profileService.checkUserPermission('Can View Own Management Submissions'),
            listService.getSelectListData('ref_general_action'),
            profileService.getAllEmployeeProfile(),
            profileService.getFullEmployeeProfile(),
            listService.getJobListByDataVisibility(),
            employeesService.getPersonProfile()

        ]).then((data) => {
            vm.formPermissions.viewAllHRSubmissions = data[0].isPermits
            vm.formPermissions.viewOwnHRSubmissions = data[1].isPermits
            vm.formPermissions.canViewOwnDailyLog = data[2].isPermits
            vm.formPermissions.canViewAllDailyLog = data[3].isPermits
            vm.formPermissions.canViewAllManagementSubmissions = data[4].isPermits
            vm.formPermissions.canViewOwnManagementSubmissions = data[5].isPermits
            vm.actionTypeList = data[6]
            vm.employeeList = profileService.readAllEmployeeProfile()
            vm.fullEmployeeList = profileService.readFullEmployeeProfile()
            vm.userJobsOndv = listService.readJobsByDataVisibility()
            vm.userId = data[10].per_id
        }).then(()=>{
            loadHaps() 
        })
    }    
                   

        function startFilter() {
            vm.filter = {
                start_date: "",
                end_date: "",
                values: [],
                mode: ""
            }
        }

        vm.employees = listService.getEmployees().A

        vm.topSearchChanged = () => {
            vm.options.api.setQuickFilter(vm.topSearch)
        }

        vm.options.dateComponent = JUIDateComponent
        vm.actionsDisabled = false
        vm.is_query_filtered = false
        vm.options.onSelectionChanged = (params) => {
            vm.actionsDisabled = vm.options.api.getSelectedRows().length != 0
            $scope.$apply()
        }

        //Function to open archive confirmation Modal
        vm.archiveConfirmationModal = (action) => {
            
            vm.archiveCount = vm.options.api.getSelectedRows().length
            
            vm.modalElements = {
                title: translateLabels(1355),  //"Archive Action?"
                message: `<div><p>${translateTag(3580)} ${vm.archiveCount} ${translateTag(3582)}</p></div>`, //"submissions. Undoing this will require IT support. Are you sure?"
                buttons: 
                    `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('archiveHazardAction')" notes="Yes">${translateTag(1379)}</button>
                    <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" notes="Cancel" >${translateTag(1257)}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'ACTIONCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("ACTIONCALLCONFIRMMODAL", (event,result) => {
            if (result=='archiveHazardAction') {
                vm.hazardArchive()
            }
        })

        //Functions to archive the actions
        vm.hazardArchive = () => {
            let rows = vm.options.api.getSelectedRows()
            if (rows.length > 0) {
                let payload = []
                rows.forEach((row)=>{
                    payload.push({submission_hap_id: row.ID})
                })
                actionManagementService.archiveHazardAction(payload).then((r) => {
                    if (r === true) {
                        loadHaps()
                    }
                })
            }
            else    
                toastr.error(translateTag(3816)) // "No Rows Selected")
            modalService.Close('confirmModal')
        }

        vm.hapFollowupComponentModalId = "hapFollowupComponent"

        vm.options.onRowDoubleClicked = (row) => {
            if(row.data.action_status === translateTag(2045)){
                // if action COMPLETE, do not open edit modal - add invisble class
                return
            }
            if(!vm.canCloseAllActions){
                if(row.data.created_by_per_id != vm.userId && !row.data.action_by_who.includes(vm.userId)){
                    toastr.success(translateTag(9525)) // You can only close actions created by you or assigned to you.
                    return
                }
            }  
            actionManagementService.getHazardActionSingle({hap_id: row.data.ID}).then((response)=>
            {
                vm.followup = response

                vm.followup.action_completed_date = dateToday.format('YYYY-MM-DD')
                vm.followup.action_complete_by_who = (vm.followup.action_complete_by_who && vm.followup.action_complete_by_who != 'None') ? parseInt(getEmployeeID(vm.followup.action_complete_by_who)) : null
                vm.followup.attachmentModalFiles = []
                vm.followup.followupAttachmentModalFiles = []
                vm.followup.action_status = vm.followup.action_status.toLowerCase() == 'complete'?translateTag(2045):translateTag(5028) //'Complete':'Incomplete'
     
                vm.followup.attachments.forEach((attRec) => {
                    if(attRec.attachmenttype === 'INITIAL')
                    {
                        attRec.imageDir = `${__env.imageUrl}/`
                        attRec.AttachmentFileName = attRec.attachmentfilename
                        vm.followup.attachmentModalFiles.push(attRec) 
                    }
                    else if(attRec.attachmenttype === 'FOLLOWUP')
                    {
                        attRec.imageDir = `${__env.imageUrl}/`
                        attRec.AttachmentFileName = attRec.attachmentfilename
                        vm.followup.followupAttachmentModalFiles.push(attRec) 
                    }
                })
                
                vm.followup.HapId = row.data.ID
                vm.followup.action_by_who_name = row.data.action_by_who
                vm.followup.modalId = 'hapFollowupComponent'                

                vm.openModal('hapFollowupComponent')
                setTimeout(()=>{
                    $scope.$broadcast('HAZARD_FOLLOWUP_OPENED')
                },100)
            })
        }

        $scope.$on('GET_FOLLOWUP_ATTACHMENTS', (event, response, id) => {
            if (vm.currentRow.ID === id) {
                vm.currentRow.FollowupAttachments.length = 0
                vm.currentRow.FollowupAttachments.push.apply(vm.currentRow.data.FollowupAttachments, response)
                var updateNodes = [vm.currentRow]
                vm.options.api.refreshRows(updateNodes)
            }
        })

        $scope.$on('UPDATE_FOLLOWUP', (event, response) => {
            mainLoadHaps()
        })

        vm.attachmentModalFiles = []

        vm.openModal = (id) => {
            vm.actionMode = 'new'    //reset mode
            if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                $scope.$apply()

            $('.modal .scroll').scrollTop(0)
            if(id=='hapsModal'){
                vm.modalElementsHaps = {
                    title: translateTag(1067), //"Actions"
                    message: `<p note="Hazard actions and incident actions.">${translateTag(2175)}</p><dl class="help-list">
                    <div>
                      <dt note="Hazard actions">${translateTag(1218)}</dt>
                      <dd note="Actions logged using the Hazard Action form.">${translateTag(2164)}</dd>
                    </div>
                    <div>
                      <dt note="Incident actions">${translateTag(1219)}</dt>
                      <dd note="Actions logged in the Incident Management module that are tied to an incident.">${translateTag(1223)}</dd>
                    </div></dl>`,                     
                }
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsHaps)
            }
            else{
                modalService.Open(id)
            }
            vm.initializeSelect2(id)
        }

        vm.openHazModal = (modalId, mode = 'new', id) => {
            vm.actionMode = mode
            if(mode === 'edit' && modalId === 'hazardActionModal') {
                openHazardEdit(id, modalId)
            }
            else
            {
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()

                $('.modal .scroll').scrollTop(0)
                modalService.Open(modalId)
                vm.initializeSelect2(modalId)
            }
        }

        vm.closeModal = (id) => {
            modalService.Close(id)
        }

        //Function to prepare data to edit a hazard action
        function openHazardEdit(id, modalId) {
            actionManagementService.getHazardActionSingle({hap_id: id}).then ((response) => {
                vm.hazardEditData = response

                vm.hazardEditData.Site = parseInt(vm.hazardEditData.Site)
                vm.hazardEditData.JobNumber = parseInt(vm.hazardEditData.JobNumber)
                vm.hazardEditData.SiteLevel = parseInt(vm.hazardEditData.SiteLevel)
                vm.hazardEditData.Supervisor = parseInt(vm.hazardEditData.Supervisor)

                vm.hazardEditData.HeaderDate = moment(vm.hazardEditData.HeaderDate).format('YYYY-MM-DD')

                let i = 0
                let initialAtt = JSON.parse(JSON.stringify(vm.hazardEditData.attachments))
                initialAtt.forEach((att) => {
                    if(att.attachmenttype === 'FOLLOWUP')
                        vm.hazardEditData.attachments.splice(i, 1)
                    else
                        i++
                })

                vm.hazardEditData.attachments.forEach((att) => {
                    att.imageDir = `${__env.imageUrl}/`
                })
                                
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()            

                $('.modal .scroll').scrollTop(0)

                modalService.Open(modalId)
                vm.initializeSelect2(modalId) 
            })
        }

        vm.selectedHapId = 0
        vm.attachmentMode = 'INITIAL'

        vm.deleteFollowupAttachment = (hapId, fileName) => {
            hapsService.deleteFollowupAttachment(hapId, fileName)
                .then((fn) => {
                    vm.getFollowupAttachments(hapId)
            })
        }

        vm.exportCSV = function () {
            let rows = JSON.parse(JSON.stringify(vm.options.api.getSelectedRows()))
            exportCSV.export_csv(rows, translateTag(1218))            
        }       

        vm.exportPressed = function () {
            $('#myDropdown').addClass('show')
        };

        $(window).click(function (e) {
            $('#myDropdown').removeClass('show')
        });

        var hapRows

        function applyQuerySetFilter(queryValue, columnField, dictionary) {
            if (!queryValue) {
                return;
            }
            var filterComponent = vm.options.api.getFilterInstance(columnField);
            var filterArray = [];
            if (Array.isArray(queryValue)) {
                for (var i = 0; i < queryValue.length; i++) {
                    filterArray.push(queryValue[i]);
                }
            } else {
                filterArray.push(queryValue);
            }

            // OR set filter model and update
            filterComponent.setModel({
                type: 'set',
                values: filterArray
            });
            filterComponent.onFilterChanged()
        }

        function applyDateBetweenFilter(startDate, endDate, columnField) {
            if (startDate == undefined || endDate == undefined) {
                return;
            }

            var filterComponent = vm.options.api.getFilterInstance(columnField);

            filterComponent.setModel({
                type: 'inRange',
                dateFrom: startDate,
                dateTo: endDate
            });
            filterComponent.onFilterChanged()
            
        }

        vm.applyQueryFilters = () => {
            applyQuerySetFilter(vm.hazard, 'hazard_identification', sitesService.dictHazardType)
            applyQuerySetFilter(vm.potential_risk, 'potential_risk', sitesService.dictPotentialRisk)
            applyDateBetweenFilter(vm.start_date, vm.end_date, 'FormSubmissionDate')
        }

        vm.clearAllFilters = () => {
            vm.is_query_filtered = false
            $window.sessionStorage.removeItem('hapFilter')
            loadHaps()
        }

        function loadHapsResponse(hapObjects) {
            if(vm.options.api)
            {
                try{
                    translateAgGridHeader (vm.options)
                    let model = vm.options.api.getFilterModel()
                    vm.options.api.setRowData(prepareHazardActionsGridData(hapObjects))
                    vm.options.api.redrawRows()
                    vm.options.api.setFilterModel(model)
                }
                catch(e){}
            }
  
        }

        function filterActionsByUser(hapData) {
            for (let a = 0; a < hapData.length; a++) {
                if (hapData[a].action_by_who != vm.currentUserID || hapData[a].action_status === 'COMPLETE') {
                    hapData.splice(a, 1)
                    a--
                }
            }
            return (hapData);
        }

        vm.currentUserName = null
        vm.currentUserID = null
        employeesService.getPersonProfile().then((userData) => {
            vm.currentUserName = userData.per_full_name
            vm.currentUserID = userData.per_id
        })

        function loadHaps() {
            $scope.$emit('STARTSPINNER', translateTag(3655)) //Loading hazard action grid. Please wait.
            startFilter()
            vm.actionsDisabled = false

            if($window.sessionStorage.getItem('hapFilter', true) !== null) {
                vm.filter = JSON.parse($window.sessionStorage.getItem('hapFilter'))                
                vm.filter.start_date =moment(vm.filter.start_date).format('YYYY-MM-DD')                
                vm.filter.end_date =moment(vm.filter.end_date).format('YYYY-MM-DD')                
                vm.is_query_filtered = true
                vm.defaultDateFilter = vm.filter.redirect_from === 'homepage' && vm.filter.date_type ? vm.filter.date_type : '30'
                hapsService.getHapsByFilter(vm.filter).then((response) => {                    
                    $window.sessionStorage.removeItem('hapFilter')
                    let finalData = filterPermissions(response)
                    loadHapsResponse(finalData)
                    $scope.$emit('STOPSPINNER')
                })

            } else if($window.sessionStorage.getItem('siteFilter', true) !== null && $location.url() !== '/a/sites') {
                vm.filter = JSON.parse($window.sessionStorage.getItem('siteFilter'))
                vm.is_query_filtered = true
                hapsService.getHapsByUsersJobsFilter(vm.filter).then((response) => {
                    $window.sessionStorage.removeItem('siteFilter')
                    let finalData = filterPermissions(response)
                    loadHapsResponse(finalData)
                    $scope.$emit('STOPSPINNER')
                })  
            }
            else if($location.url() === '/a/sites') {
                vm.filter = JSON.parse($window.sessionStorage.getItem('siteBackFilter'))
                vm.filter.start_date = $window.sessionStorage.getItem('start_date')
                vm.filter.end_date = $window.sessionStorage.getItem('end_date') 
                vm.filter.users = vm.filter.users ? vm.filter.users:[]
                vm.filter.jobs = vm.filter.jobs ? vm.filter.jobs:[]
                localStorage.setItem("navToFormSubFilterHazards", JSON.stringify(
                    {"start_date":vm.filter.start_date,"end_date":vm.filter.end_date}));
                hapsService.getHapsByUsersJobsFilter(vm.filter).then((response) => {
                    let finalData = filterPermissions(response)
                    loadHapsResponse(finalData)
                    $scope.$emit('STOPSPINNER')
                })  
            }
            else if($location.url() === '/a/positive-id' || $location.url() === '/a/home') {
                vm.filter.start_date = $window.sessionStorage.getItem('start_date')
                vm.filter.end_date = $window.sessionStorage.getItem('end_date')
                $scope.$emit('STOPSPINNER')
            }    
            else {
                vm.filter.start_date = vm.mainDateFilter.start_date
                vm.filter.end_date = vm.mainDateFilter.end_date
                vm.filter.users = vm.filter.users ? vm.filter.users:[]
                vm.filter.jobs = vm.userJobsOndv.map((obj) => obj.rld_id);               
           
                hapsService.getHapsByFilter(vm.filter).then((response) => {
                    let finalData = filterPermissions(response)
                    loadHapsResponse(finalData)
                    $scope.$emit('STOPSPINNER')
                })
                
            }
            
            function filterPermissions(data){
                let outData = []
                data.forEach((rec)=>{
                    if(filterForms(rec))
                     outData.push(filterForms(rec))
                })
                return outData

            }

            function filterForms(rec) {
                // HR forms
                if(rec.FormID == '248310' || rec.FormID == '339913' || rec.FormID == '248322') {
                    if(vm.formPermissions.viewAllHRSubmissions){
                        return rec
                    }
                    if(vm.formPermissions.viewOwnHRSubmissions && rec.submitted_by_per_id == vm.currentUserID){
                        return rec
                    }
                    rec.SubmissionHeaderID = null
                    return rec
                }
                // Daily log
                else if(rec.FormID == '336724') {
                    if(vm.formPermissions.canViewAllDailyLog){
                        return rec
                    }
                    if(vm.formPermissions.canViewOwnDailyLog && rec.submitted_by_per_id == vm.currentUserID){
                        return rec
                    }
                    rec.SubmissionHeaderID = null
                    return rec
                }
                // Management Forms
                else if(rec.FormID == '138900') {
                    if(vm.formPermissions.canViewAllManagementSubmissions){
                        return rec
                    }
                    if(vm.formPermissions.canViewOwnManagementSubmissions && rec.submitted_by_per_id == vm.currentUserID){
                        return rec
                    }
                    rec.SubmissionHeaderID = null
                    return rec
                }
                // If no match return record  no permissions needed.
                else {
                    return rec
                }
            }
        }

        $rootScope.$on('HAPDATERANGE', (range) => {
            mainLoadHaps()
        })

        $scope.$on('DATERANGE', (range) => {
            vm.mainDateFilter = {
                start_date: moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD'),
                end_date: moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')
            }
            mainLoadHaps()
        })

        //Function to prepare Hap Data for the grid/tippy
        function prepareHazardActionsGridData(data) {   
            let gridData = JSON.parse(JSON.stringify(data))
            gridData.forEach((rec) =>{
                rec.exceptionFields = ['ActionAssignedTo', 'further_action_required', 'immediate_action_required_and_performed', 'sha_enable', 'sha_enote', 'FollowupAttachments', 'InitialAttachments', 'is_native_system', 'submitted_by_per_id', 'SubmittedBy', 'SiteId']
                rec.action_by_who = rec.ActionAssignedTo
                rec.action_complete_by_who = getEmployeeName(rec.action_complete_by_who)
                rec.sha_modified_by_per_id = getEmployeeName(rec.sha_modified_by_per_id)
                rec.sha_created_by_per_id = getEmployeeName(rec.sha_created_by_per_id)
                rec.submitted_by = getEmployeeName(rec.submitted_by_per_id)
                rec.Supervisor = getEmployeeName(rec.Supervisor)

                if(rec.HeaderDate != null)
                    rec.HeaderDate = moment(rec.HeaderDate).format('YYYY-MM-DD')
                rec.FormSubmissionDate = moment(rec.FormSubmissionDate).format('YYYY-MM-DD')
                rec.sha_created_date = moment(rec.sha_created_date).format('YYYY-MM-DD')
                rec.sha_modified_date = rec.sha_modified_date == null ? '' : moment(rec.sha_modified_date).format('YYYY-MM-DD')

                if(rec.action_status != null)
                    rec.action_status = rec.action_status.toLowerCase() == 'complete'?translateTag(2045):translateTag(5028) //'Complete':'Incomplete'                
            })

            return gridData
        }

        //Functions to convert names to IDs
        function getEmployeeName(value) {
            let name = value
            vm.fullEmployeeList.forEach((emp)=>{
              if(emp.per_id == value) {
                name = emp.per_full_name
              }
            })
            return name
        }
        function getEmployeeID(value) {
            let nameID = value
            vm.fullEmployeeList.forEach((emp)=>{
            if(emp.per_full_name == value) {
                nameID = emp.per_id
            }
            })
            return nameID
        }

        vm.showHelp = function (id) {
            vm.openModal(id)
        }

        $scope.$on('HAP_REFRESHDATA', (event) => {
            loadHaps()
        })

        // vm.Report_Distribution1 = []
        vm.groupsSelected = []
        vm.openForm = () =>{
            let message={activeFormID:null,incidentId:null,moduleId:null}            
            vm.activeFormID='131042'
            message.activeFormID=vm.activeFormID
            $rootScope.$broadcast("OPENMOBILEFRAME", message)
        }

        //Refresh grid when any form is submitted
        $scope.$on('REFRESH_FORMSUBMISSIONS', (event) => {
            mainLoadHaps()
        })

        //Function to initialize select2
        vm.initializeSelect2 = (parent)=> {
            setTimeout(()=>{
            $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} .modal-body`), escapeMarkup: function (text) { return text } })
                .on('select2:select', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list'))
                        $rootScope.$broadcast('distribution-list-added', event)
                    $(this).parent().find('label').addClass('filled') 
                })
                .on('select2:unselect', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list'))
                        $rootScope.$broadcast('distribution-list-removed', event)
                    $(this).parent().find('label').addClass('filled')
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()
            }, 100)
            if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
            $('.datepicker').pickadate({
                format: 'yyyy-mm-dd',
                onClose : function(){
                    this.$holder.blur()
                },
            }).removeAttr('readonly')
            .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                evt.preventDefault()
            })

            preventFutureDatePickerInit()

            let pickadateTranslations = sofvie_pickatime_languages[`${selectedLanguage}`]
            $('.timepicker').pickatime({
                donetext: pickadateTranslations.done,
                cleartext: pickadateTranslations.clear,
                twelvehour: true, 
                'default': '24:00'
            })
        }

    }])