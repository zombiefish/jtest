﻿angular
    .module('safeToDo')
    .service('hrService', ['$http',
        function ($http) {
            let positiveIdData = []
            let hazardsToPositiveId = {}
            let hazardsToPositiveIdAll = {}

            let getTop10OneWordHrData = ''
            let getTop10EmpDisplinedData = ''

            let color_palette = ["#0072ce", "#66aae2", "#F7BD03","#00447c", "#6e94ba", "#7272ad", "#d8bd87", "#447259", "#474747", "#b3bccf", 
            "#99bcac", "#a9ddff", "#96a9aa", "#001e60", "#777777", "#005ba5", "#0087b3", "#002e52", "#99c7eb", "#a4a1d5", "#00445a", 
            "#378ddc", "#424686", "#fcecb3", "#9c6492", "#16492d", "#d193ae", "#eacfce", "#8a7fd0", "#616699", "#006586", "#ddab00", 
            "#c292cd", "#d6d3ff", "#5f3c79", "#00a9e0", "#ffb359", "#58cad3"]

            let dataSet={
                title:{text:"", font:{family:"Arial Black", color:"black", size:"16"}, x:0.5, xanchor:"center", y:-20, yanchor: "top"},                
                type: 'pie',
                showlegend: false,
                labels: [],
                values: [],
                hovertemplate:
                "<b>%{label}</b><br><br>"+
                "<extra></extra>",
                textinfo: "label",
                marker: {
                    color: color_palette[0]
                },                              
                offsetgroup: 1,
            }

            let noData = [{type:'bar', x: [translateTag(3838)], y: [0]}]

            return {
                getTop10OneWordHr: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/analytic/top-10-one-word-theme-and-their-sentiments/`, dateRange).then((response) => { 
                        getTop10OneWordHrData = response.data
                        return response.data                    
                        
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getTop10EmpDisplined: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/analytic/top-10-employee-being-disciplined-and-their-sentiments/`, dateRange).then((response) => { 
                        getTop10EmpDisplinedData = response.data
                        return response.data     
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getEmployeeCountByStartDate: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/analytic/new-employee-count-by-start-date/`, dateRange).then((response) => {
                        if (response.data == 'No Data to Show'){
                            return noData
                        }
                        else{
                            data=[]
                            data.push({
                                type: 'bar',
                                x: response.data.x_axis,
                                y: response.data.y_axis[0],  
                                marker: {
                                    color: color_palette[0]
                                },                              
                                name: translateTag(3833), //'New Employee Count'
                                yaxis: 'y',
                                offsetgroup: 1,
                                }
                            ), 
                            data.push({
                                type: 'bar',
                                x: response.data.x_axis,
                                y: response.data.y_axis[1],
                                marker: {
                                    color: color_palette[1]
                                },
                                name: translateTag(3834), //'Cumulative Count'
                                yaxis: 'y2',
                                offsetgroup: 2,                                
                                }
                            ) 
                        }    
                        return data     
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getEmployeeCountPositionSiteGeneration: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/analytic/employee-count-position-site-generation/`, dateRange).then((response) => {
                        getEmployeeCountPositionSiteGenerationData = response.data
                        dataSet1=JSON.parse(JSON.stringify(dataSet))
                        dataSet2=JSON.parse(JSON.stringify(dataSet))
                        dataSet3=JSON.parse(JSON.stringify(dataSet))
                        dataSet1.title.text=translateTag(3835) //"By Position"
                        dataSet2.title.text=translateTag(3836) //"By Site"
                        dataSet3.title.text=translateTag(3837) //"By Generation"
                        data=[dataSet1,dataSet2,dataSet3]
                        if (response.data == 'No Data to Show'){
                            dataNoData=data                         
                            dataNoData[0].labels=dataNoData[1].labels=dataNoData[2].labels=["No Data To Show"]
                            dataNoData[0].values=dataNoData[1].values=dataNoData[2].values=[1]
                            return data
                        }
                        else{
                            data[0].textinfo=data[1].textinfo=data[2].textinfo="%value"
                            percent = 0.02
                            types = ['by_position', 'by_site', 'by_generation']
                            for(let i in types){
                                curdata = response.data[types[i]]
                                twopercent = curdata.y_axis.reduce(function(a,b) {return a + b}, 0) * percent
                                other = 0
                                others = ''
                                for(let j in curdata.y_axis){
                                    if (curdata.y_axis[j] >= twopercent){
                                        if(curdata.x_axis[j]=="Boomer" || curdata.x_axis[j]=="Millenial" || curdata.x_axis[j]=="Gen Z" || curdata.x_axis[j]=="Gen X"){
                                            curdata.x_axis[j]=translateTag(parseInt(plotlyTags[curdata.x_axis[j]]))
                                        }
                                        data[i].values.push(curdata.y_axis[j])
                                        data[i].labels.push(curdata.x_axis[j])
                                    } else {
                                        other += curdata.y_axis[j]
                                        others += '<br />' + curdata.x_axis[j]
                                    }
                                }
                                if (other > 0){
                                    data[i].values.push(other)
                                    data[i].labels.push(translateTag(688)+':' + others) //"Other"
                                }
                            }
                        }                 
                        return data
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getAverageEmployeeAge: (dateRange) => {
                    if (dateRange.emp_pos == []){
                        return noData
                    }
                    else{
                        return $http.post(`${__env.apiUrl}/api/analytic/current-average-employee-age-per-position/`,dateRange).then((response) => { 
                            if (response.data == 'No Data to Show'){
                                return noData
                            }
                            else{
                                curdata = response.data
                                data=[{
                                    type: 'bar',
                                    x: curdata.x_axis,
                                    y: curdata.y_axis['mean'],
                                    name: 'Average Age',
                                    line: {
                                    color: color_palette[0],
                                    width: 1
                                    }
                                },]

                                return data 
                            }    
                        }, (args) => {
                            console.log('Failed to load action trend data.', args)
                        })
                    }
                },

                getAverageTrainingCompleted: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/analytic/average-training-completed/`, dateRange).then((response) => { 
                        dataSet1=JSON.parse(JSON.stringify(dataSet))   
                        dataSet1.title.text=translateTag(3837) //"By Generation"
                        data=[dataSet1]   
                        if (response.data == 'No Data to Show'){
                            dataNoData=data                         
                            dataNoData[0].labels=["No Data To Show"]
                            dataNoData[0].values=[1]
                            return data
                        }
                        else{
                            curdata = response.data
                            data[0].textinfo="%value"
                            data[0].labels = []
                            for(i in curdata.x_axis){
                                data[0].labels.push(translateTag(parseInt(plotlyTags[curdata.x_axis[i]])))
                            }
                            data[0].values=curdata.y_axis
                            return data 
                        }    
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getAverageNumberOfValidTrainingByStartDate: () => {
                    return $http.post(`${__env.apiUrl}/api/analytic/average-number-of-valid-training-by-start-date/`).then((response) => { 
                        if (response.data == 'No Data to Show'){
                            return noData
                        }
                        else{         
                            curdata = response.data
                            data=[{
                                type: 'bar',
                                x: curdata.x_axis,
                                y: curdata.y_axis,
                                name: 'Average Number of Valid Trainings',
                                line: {
                                color: color_palette[0],
                                width: 1
                                }
                            },]
                            return data 
                        }    
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getAverageNumberOfTrainingCompletedByYearAndMonth: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/analytic/average-number-of-training-completed-by-year-and-month/`, dateRange).then((response) => { 
                        if (response.data == 'No Data to Show'){
                            return noData
                        }
                        else{
                            data=[]
                            for (year in response.data){
                                month_name=[]
                                for(month in response.data[year].x_axis){
                                    month_trans=translateTag(plotlyTags[response.data[year].x_axis[month]])
                                    month_name.push(month_trans)
                                }
                                data.push({
                                    type: 'bar',
                                    x: month_name,
                                    y: response.data[year].y_axis,                                
                                    name: response.data[year].name,
                                    marker: {color: color_palette[year]},
                                    }
                                )
                            }

                            var reorder = function (attr, originalArray){
                                var newArray = originalArray.slice() // clone array
                                newArray.sort(function(a){return a.groupValue !== attr?1:-1}) // put in first
                                return newArray;
                            }
                            return data 
                        }    
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getAverageNumberOfValidTrainingCompletedByYearSite: (dateRange) => {
                    if (dateRange.sites == []){
                        return noData
                    }
                    else{
                        return $http.post(`${__env.apiUrl}/api/analytic/average-number-of-valid-training-by-year-and-site/`, dateRange).then((response) => { 
                            if (response.data == 'No Data to Show' || response.data.hasOwnProperty('error')){
                                return noData
                            }
                            else{
                                data=[]
                                for (year in response.data){
                                    data.push({
                                        type: 'bar',
                                        x: response.data[year].x_axis,
                                        y: response.data[year].y_axis,                                
                                        name: response.data[year].name,
                                        marker: {color: color_palette[year]}
                                        }
                                    )
                                }
                                return data 
                            }    
                        }, (args) => {
                            console.log('Failed to load action trend data.', args)
                        })
                    }
                },

                getDisciplinesBrokenDownBySiteMonthAndYear: (dateRange) => {
                    if (dateRange.sites == []){
                        return noData
                    }
                    else{
                        return $http.post(`${__env.apiUrl}/api/analytic/disciplines-broken-down-by-site-month-and-year/`, dateRange).then((response) => { 
                            if (response.data == 'No Data to Show'){
                                return noData
                            }
                            else{
                                curdata = response.data
                                data=[{
                                    type: 'bar',
                                    x: curdata.x_axis,
                                    y: curdata.y_axis,
                                    name: 'Age',
                                    line: {
                                    color: color_palette[0],
                                    width: 1
                                    }
                                },]

                                data=[]
                                for (year in response.data){
                                    month_name=[]
                                    for(month in response.data[year].x_axis){
                                        month_trans=translateTag(plotlyTags[response.data[year].x_axis[month]])
                                        month_name.push(month_trans)
                                    }
                                    data.push({
                                        type: 'bar',
                                        x: month_name,
                                        y: response.data[year].y_axis,                                
                                        name: response.data[year].name,
                                        marker: {color: color_palette[year]}
                                        }
                                    )
                                }
                                return data 
                            }    
                        }, (args) => {
                            console.log('Failed to load action trend data.', args)
                        })
                    }
                },

                getReviewsBrokenDownBySiteMonthAndYear: (dateRange) => {
                    if (dateRange.sites == []){
                        return noData
                    }
                    else{
                        return $http.post(`${__env.apiUrl}/api/analytic/reviews-broken-down-by-site-month-and-year/`, dateRange).then((response) => { 
                            if (response.data == 'No Data to Show'){
                                return noData
                            }
                            else{
                                data=[]
                                for (year in response.data){
                                    month_name=[]
                                    for(month in response.data[year].x_axis){
                                        month_trans=translateTag(plotlyTags[response.data[year].x_axis[month]])
                                        month_name.push(month_trans)
                                    }
                                    data.push({
                                        type: 'bar',
                                        x: month_name,
                                        y: response.data[year].y_axis,                                
                                        name: response.data[year].name,
                                        marker: {color: color_palette[year]}
                                        }
                                    )
                                }
                                return data 
                            }    
                        }, (args) => {
                            console.log('Failed to load action trend data.', args)
                        })
                    }
                },

                readTop10OneWordHr:()=>{
                    return getTop10OneWordHrData
                },
                readTop10EmpDisplined:()=>{
                    return getTop10EmpDisplinedData
                },
            }
        }
    ])