﻿angular
    .module('safeToDo')
    .controller('HrCtrl', ['$scope', '$compile','$timeout', '$rootScope', '$q', '$location', '$window', 'employeesService', 'gridService', 'hrService', 'modalService','profileService','listService','complianceService','formsService',
        function ($scope, $compile, $timeout,$rootScope,$q, $location, $window, employeesService, gridService, hrService, modalService, profileService,listService,formsService,complianceService) {
            var vm = this
            
            vm.targets = []
            vm.supervisors = []
            vm.frequencies = []
            vm.forms = []
            vm.hazards = []
            vm.options = gridService.getCommonOptions()
            vm.topSearch = ''
            vm.loadMessage = translateTag(3797) //Loading human resource page. Please wait.
            vm.employeeList = []
            vm.curPage = "Graphs" 
            
            vm.mainDateFilter = {
                start_date: moment().subtract(90, 'days').format('YYYY-MM-DD'),
                end_date: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD')
            }                  
        
            vm.monthNamesLong = [{name:'January', short: 'Jan', number: '01'},
            {name: 'February', short: 'Feb', number: '02'} ,
            {name:'March', short: 'Mar', number:'03'} , 
            {name:'April', short: 'Apr', number:'04'}, 
            {name:'May', short: 'May', number:'05'}, 
            {name:'June', short: 'June', number:'06'}, 
            {name:'July', short: 'July', number:'07'}, 
            {name:'August', short: 'Aug', number:'08'}, 
            {name:'September', short: 'Sept', number:'09'}, 
            {name:'October', short: 'Oct', number:'10'}, 
            {name:'November', short: 'Nov', number:'11'}, 
            {name:'December', short: 'Dec', number:'12'}]
            vm.monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
            vm.years = [2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030]
            vm.options = gridService.getCommonOptions()
            vm.count = 1

            vm.currentInfo = {}

            let filterObject = {
                Jobs:[]
            }

            function getMonthFromString(mon) {
                return new Date(Date.parse(mon + " 1, 2017")).getMonth() + 1;
            }

            vm.graphFilters = {
                'get-employee-count-position-site-generation': {'status': 'active'},
                'get-average-number-of-valid-training-completed-by-year-site': {'start_date': '', 'end_date': '', 'sites': []},
                'get-disciplines-broken-down-by-site-month-and-year': {'start_date': '', 'end_date': '', 'sites': []},
                'get-current-average-employee-position': {'start_date': '', 'end_date': '', 'positions': []},
                'get-reviews-broken-down-by-site-month-and-year': {'start_date': '', 'end_date': '', 'sites': []}
            }
          
            $scope.$on('FILTERCHANGE', (data) => {
                if($location.url() === '/analytics/hr'){
                    id = data.targetScope.vm.id
                    vm.count ++
                    if (data.targetScope.vm.typeOfFilter == 'site'){
                        vm.filter = data.targetScope.vm.curSites
                    } else if (data.targetScope.vm.typeOfFilter == 'date'){
                        // Convert the date to proper format for API endpoint
                        data.targetScope.vm.range.start_date = new Date(data.targetScope.vm.range.start_date).toISOString().replace('T', ' ').replace('Z', '')                      
                        data.targetScope.vm.range.end_date = new Date(data.targetScope.vm.range.end_date).toISOString().replace('T', ' ').replace('Z', '')
                        vm.filter = data.targetScope.vm.range
                    } else if (data.targetScope.vm.typeOfFilter == 'active'){
                        vm.filter = data.targetScope.vm.actionvalue
                    }

                    typeOfFilter = data.targetScope.vm.typeOfFilter

                    if (id == 'get-new-employee-count-by-start-date'){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        vm.getEmployeeCountByStartDate(vm.filter)
                        $scope.$emit('STOPSPINNER')
                    }
                    else if(id == "get-employee-count-position-site-generation"){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        if (typeOfFilter == "date"){
                            vm.graphFilters[id]['start_date'] = data.targetScope.vm.range['start_date']
                            vm.graphFilters[id]['end_date'] = data.targetScope.vm.range['end_date']
                        }
                        else if (typeOfFilter == "active"){
                            vm.graphFilters[id]['status'] = vm.filter
                        }
                        vm.getEmployeeCountPositionSiteGeneration(vm.graphFilters[id])
                        $scope.$emit('STOPSPINNER')
                    }
                    else if(id == "get-current-average-employee"){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        vm.getAverageEmployeeAge({'emp_pos':data.targetScope.vm.curPositionsIds})
                        $scope.$emit('STOPSPINNER')
                    }
                    else if(id == "get-average-training-completed"){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        vm.getAverageTrainingCompleted(vm.filter)
                        $scope.$emit('STOPSPINNER')
                    }
                    else if(id == "get-average-number-of-valid-training-by-year"){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        vm.getAverageNumberOfValidTrainingByStartDate(vm.filter)
                        $scope.$emit('STOPSPINNER')
                    }
                    else if(id == "get-average-number-of-training-completed-by-year-and-month"){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        vm.getAverageNumberOfTrainingCompletedByYearAndMonth(vm.filter)
                        $scope.$emit('STOPSPINNER')
                    }
                    else if(id == "get-average-number-of-valid-training-completed-by-year-site"){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        if (typeOfFilter == "date"){
                            vm.graphFilters[id]['start_date'] = data.targetScope.vm.range['start_date']
                            vm.graphFilters[id]['end_date'] = data.targetScope.vm.range['end_date']
                        }
                        else if (typeOfFilter == "site"){
                            vm.graphFilters[id]['sites'] = data.targetScope.vm.curSitesIds
                        }
                        // for (var key in vm.graphFilters[id]) {
                        //     if (vm.graphFilters[id][key] == ""){                            
                        //         return
                        //     }
                        // }
                        vm.getAverageNumberOfValidTrainingCompletedByYearSite(vm.graphFilters[id])
                        $scope.$emit('STOPSPINNER')

                    }
                    else if(id == "get-disciplines-broken-down-by-site-month-and-year"){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        if (typeOfFilter == "date"){
                            vm.graphFilters[id]['start_date'] = data.targetScope.vm.range['start_date']
                            vm.graphFilters[id]['end_date'] = data.targetScope.vm.range['end_date']
                        }
                        else if (typeOfFilter == "site"){
                            vm.graphFilters[id]['sites'] = data.targetScope.vm.curSitesIds
                        }
                        // for (var key in vm.graphFilters[id]) {
                        //     if (vm.graphFilters[id][key] == ""){                           
                        //         return
                        //     }
                        // }
                        vm.getDisciplinesBrokenDownBySiteMonthAndYear(vm.graphFilters[id])
                        $scope.$emit('STOPSPINNER')
                    }
                    else if(id == "get-reviews-broken-down-by-site-month-and-year"){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        if (typeOfFilter == "date"){
                            vm.graphFilters[id]['start_date'] = data.targetScope.vm.range['start_date']
                            vm.graphFilters[id]['end_date'] = data.targetScope.vm.range['end_date']
                            $scope.$emit('STOPSPINNER')

                        }
                        else if (typeOfFilter == "site"){
                            vm.graphFilters[id]['sites'] = data.targetScope.vm.curSitesIds
                            $scope.$emit('STOPSPINNER')
                        }
                        // for (var key in vm.graphFilters[id]) {
                        //     if (vm.graphFilters[id][key] == ""){                      
                        //         return
                        //     }
                        // }
                        vm.getReviewsBrokenDownBySiteMonthAndYear(vm.graphFilters[id])
                        $scope.$emit('STOPSPINNER')
                    }
                    else if (id == 'top10OneWordHr'){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                            $q.all([
                                hrService.getTop10OneWordHr(vm.filter),
                            ]).then(() => {
                                vm.top10OneWordHrData = hrService.readTop10OneWordHr()
                                vm.loadWidgetComponent('top10OneWordHr', vm.top10OneWordHrData, "", translateTag(2159))            
                                $scope.$emit('STOPSPINNER')
                            }) 
                    }
                    else if (id == 'top10EmpDisplined'){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        $q.all([
                            hrService.getTop10EmpDisplined(vm.filter),
                        ]).then(() => {
                            vm.top10EmpDisplinedData = hrService.readTop10EmpDisplined()
                            vm.loadWidgetComponent('top10EmpDisplined', vm.top10EmpDisplinedData, "", translateTag(204))  
                            $scope.$emit('STOPSPINNER')

                        })
                    } 
                }
            })


            var currentDate = new Date();
            let dateToday = moment(new Date(), 'YYYY-MM-DD')
            function getMonthName(month, type='long'){
                let theMonth = ''
               vm.monthNamesLong.forEach((mth)=>{
                   if(mth.number === month) {
                    theMonth =  type === 'long'? mth.name : nth.short
                   }
                })
                return theMonth
            }

            vm.dateFilter = {
                start_month: $window.sessionStorage.getItem("start_month") ? $window.sessionStorage.getItem("start_month") : dateToday.format("MM"),
                start_year: $window.sessionStorage.getItem("start_year") ? Number($window.sessionStorage.getItem("start_year")) : currentDate.getFullYear(),
                end_month: $window.sessionStorage.getItem("end_month") ? $window.sessionStorage.getItem("end_month") : dateToday.format("MM"),
                end_year: $window.sessionStorage.getItem("end_year") ? Number($window.sessionStorage.getItem("end_year")) : currentDate.getFullYear(),
                getFormattedRange: () => {
                    var start = getMonthName(vm.dateFilter.start_month) + " " + this.start_year
                    var end = getMonthName(vm.dateFilter.end_month) + " " + this.end_year
                    if (start == end) {
                        return start
                    }

                    return start + " - " + end;
                },
                validate: () => {
                    if (this.start_year > this.end_year) {
                        return false
                    }
                    if (this.start_year == this.end_year) {
                        if (getMonthFromString(this.start_month) > getMonthFromString(this.end_month)) {
                            return false
                        }
                    }

                    return true;
                }
            }

            vm.loadWidgetComponent = (divId, data, title,subTitle) => {
                let widgetData = []
                data.forEach((item) => {
                    if(item.keyword=='No Data to Show'){
                        item.keyword=translateTag(3838)
                    }
                    else if(item.keyword=="N/A"){
                        item.keyword=translateTag(1381)
                    }
                    widgetData.push({id:item.id, keyword: item.keyword.toString().replaceAll("'","&#39"), trend:item.trend, sentiment:item.sentiment})
                })
                vm.newdata = JSON.stringify(widgetData)
                $('#'+divId).html($compile(`    
                    <top-ten-widget-form data='${vm.newdata}' sub-title='${subTitle.toString().replaceAll("'","&#39")}'></top-ten-widget-form>
                `)($scope))
            }

            /*
                Date filter Stuff
            */
            vm.getStartDate = () => {
                if (vm.dateFilter.start_month && vm.dateFilter.start_year) {
                    var monthNum = vm.dateFilter.start_month
                    var sd =`${vm.dateFilter.start_year}-${monthNum}-01`
                    return sd
                }
                return null
            }

            vm.getEndDate = () => {
                
                if (vm.dateFilter.end_month && vm.dateFilter.end_year) {
                    var monthNum = vm.dateFilter.end_month
                    momentEndDate = moment(`${vm.dateFilter.end_year}-${monthNum}-01`,'YYYY-MM-DD')
                    var ed = `${vm.dateFilter.end_year}-${monthNum}-${momentEndDate.endOf('month').format('DD')}`
                    return ed
                }
                return null;
            }

            vm.getDateFilterDescription = () => {
                return vm.dateFilter.getFormattedRange();
            }

            vm.dateFilterMenu = ($event) => {
                $event.stopPropagation();
                vm.hideDropdowns();
                var actions = $('#dateFilterDropdown');
                actions.addClass('show');
            }

            vm.dateFilterValid = () => {
                return vm.dateFilter.validate();
            }
            
            vm.layout1 = {
                // automargin:true,
                autosize:true,
                showlegend: true,
                legend: {"orientation": "h", 
                        "font":{
                        "family":"Arial", 
                        "size":18
                        },
                        "yanchor":"bottom",
                        "y":-1,
                        "xanchor":"center",
                        "x":0.5,
                        automargin:true
                    },
                xaxis: {
                    title: {
                        text: "",
                        font: {
                            family:"Arial",
                            size: 14,
                            
                        //   color: "Black"
                        },  
                        standoff: 40
                    },
                    showgrid:false,
                    automargin:true
                    // pad: 50
                    // dtick: 1
                },
                yaxis: {
                    title: {
                        text: '',
                        font: {
                            family: "Arial",
                            size: 14,
                        //   color: 'black'
                        },
                    },
                    zeroline: false,
                    automargin:true
                    // ticks: 'outside',
                },
                yaxis2: {
                    title: {
                        text: '',
                        font: {
                        family: "Arial",
                        size: 14,
                        // color: 'black'
                        },
                    },
                    zeroline: false,
                    overlaying: 'y', 
                    side: 'right',
                    automargin:true,
                    showgrid:false
                }, 
                barmode:'group', 
                // automargin:true
                margin: {
                    // l: 50,
                    // r: 50,
                    // b: 0,
                    // t: 0,
                    pad: 15
                  },
            };

            vm.layoutNormal = {
                // automargin:true,
                autosize:true,
                showlegend: true,
                legend: {"orientation": "h", 
                        "font":{
                        "family":"Arial", 
                        "size":18
                        },
                        "yanchor":"bottom",
                        "y":-1,
                        "xanchor":"center",
                        "x":0.5,
                        automargin:true
                    },
                xaxis: {
                    title: {
                        text: "",
                        font: {
                            family:"Arial",
                            size: 14,
                            
                        //   color: "Black"
                        },  
                        standoff: 40
                    },
                    showgrid:false,
                    automargin:true
                    // pad: 50
                    // dtick: 1
                },
                yaxis: {
                    title: {
                        text: '',
                        font: {
                            family: "Arial",
                            size: 14,
                        //   color: 'black'
                        },
                    },
                    zeroline: false,
                    automargin:true
                    // ticks: 'outside',
                },
                yaxis2: {
                    title: {
                        text: '',
                        font: {
                        family: "Arial",
                        size: 14,
                        // color: 'black'
                        },
                    },
                    zeroline: false,
                    overlaying: 'y', 
                    side: 'right',
                    automargin:true,
                    showgrid:false
                }, 
                barmode:'group', 
                automargin:true
                // margin: {
                //     // l: 50,
                //     // r: 50,
                //     // b: 0,
                //     // t: 0,
                //     pad: 15
                //   },
            };

            vm.layoutSmall = {
                // automargin:true,
                autosize:true,
                showlegend: true,
                legend: {"orientation": "h", 
                        "font":{
                        "family":"Arial", 
                        "size":18
                        },
                        "yanchor":"bottom",
                        "y":-4,
                        "xanchor":"center",
                        "x":0.5,
                        automargin:true
                    },
                xaxis: {
                    title: {
                        text: "",
                        font: {
                            family:"Arial",
                            size: 14,
                            
                        //   color: "Black"
                        },  
                        standoff: 40
                    },
                    showgrid:false,
                    automargin:true
                    // pad: 50
                    // dtick: 1
                },
                yaxis: {
                    title: {
                        text: '',
                        font: {
                            family: "Arial",
                            size: 14,
                        //   color: 'black'
                        },
                    },
                    zeroline: false,
                    automargin:true
                    // ticks: 'outside',
                },
                yaxis2: {
                    title: {
                        text: '',
                        font: {
                        family: "Arial",
                        size: 14,
                        // color: 'black'
                        },
                    },
                    zeroline: false,
                    overlaying: 'y', 
                    side: 'right',
                    automargin:true,
                    showgrid:false
                }, 
                barmode:'group', 
                automargin:true
                // margin: {
                //     // l: 50,
                //     // r: 50,
                //     // b: 0,
                //     // t: 0,
                //     pad: 15
                //   },
            };

            var config = {
                locale: selectedLanguage,
                responsive: true,
                displayModeBar: false
              }

            var config1 = {
            locale: selectedLanguage,
            responsive: true,
            displayModeBar: true,
            displaylogo: false,
            modeBarButtonsToRemove: ['toggleSpikelines','hoverClosestCartesian', 'hoverCompareCartesian'],
            // scrollZoom: true
            }

            if ($(window).width() < 960) {
                // console.log("small screen")
                vm.layout=vm.layoutSmall
            }
            else {
                // console.log("Normal screen")
                vm.layout=vm.layoutNormal
            }

            function getLayout() {
                if ($(window).width() < 960) {
                    // console.log("small screen")
                    vm.layout=vm.layoutSmall
                }
                else {
                    // console.log("Normal screen")
                    vm.layout=vm.layoutNormal
                }
            }

            $(window).resize(function() {
                // console.log('window was resized');
                getLayout()
                if(vm.layout==vm.layoutNormal){
                    vm.layoutYearMonth= JSON.parse(JSON.stringify(vm.layout)) 
                    vm.layoutYearMonth.xaxis.dtick= 1
                    vm.layoutYearMonth.xaxis.title.text=translateTag(2050)
                    vm.layoutYearMonth.yaxis.title.text=''
    
                    vm.layoutYearSite= JSON.parse(JSON.stringify(vm.layout)) 
                    vm.layoutYearSite.legend.y=-2
                    vm.layoutYearSite.xaxis.title.text=translateTag(828) //Site
                    vm.layoutYearSite.yaxis.title.text=translateTag(3841) //'Average Number of Valid Trainings Completed'
                    Plotly.relayout('get-average-number-of-training-completed-by-year-and-month',vm.layoutYearMonth)
                    Plotly.relayout('get-average-number-of-valid-training-completed-by-year-site', vm.layoutYearSite)
                }
                else{
                    Plotly.relayout('get-average-number-of-training-completed-by-year-and-month',vm.layout)
                    Plotly.relayout('get-average-number-of-valid-training-completed-by-year-site', vm.layout)
                }
            });

            vm.getEmployeeCountByStartDate = (dateRange) => {
                $q.all([
                    hrService.getEmployeeCountByStartDate(dateRange)
                ]).then((response)=>{
                    layout = JSON.parse(JSON.stringify(vm.layout))
                    if (response[0][0].x[0] == translateTag(3838)){
                        layout.showlegend = false
                    } else if (response[0][0].x.length < 3){
                        layout.xaxis.dtick = "D1"
                    }
                    layout.automargin=false
                    layout.margin={pad:15}
                    layout.xaxis.title.text = translateTag(1133) //"Date Range"
                    layout.yaxis.title.text=translateTag(3833) //'New Employee Count'
                    layout.yaxis2.title.text=translateTag(3834) //'Cumulative Count'
                    layout.legend.y=-0.7
                    // console.log("layoutis",layout)
                    Plotly.newPlot('get-new-employee-count-by-start-date', response[0], layout,config)
                })
            }

            vm.getEmployeeCountPositionSiteGeneration = (dateRange) => {
                $q.all([
                    hrService.getEmployeeCountPositionSiteGeneration(dateRange)
                ]).then((response)=>{
                    layout = JSON.parse(JSON.stringify(vm.layout))
                    layout.showlegend = false
                    if (response){
                        Plotly.newPlot('get-employee-count-position', [response[0][0],],layout,config);    
                        Plotly.newPlot('get-employee-count-site', [response[0][1],], layout,config);
                        Plotly.newPlot('get-employee-count-generation', [response[0][2]], layout,config);
                    }
                })
            }

            vm.getAverageEmployeeAge = (dateRange) => {
                $q.all([
                    hrService.getAverageEmployeeAge(dateRange)
                ]).then((response)=>{
                    layout = JSON.parse(JSON.stringify(vm.layout))
                    if (response[0][0].x[0] == translateTag(3838)){
                        layout.showlegend = false
                    }
                    // layout.margin.l=50
                    // layout.margin.r=50
                    // layout.margin.t=0
                    layout.xaxis.title.text= translateTag(1277) //"Position"
                    layout.yaxis.title.text= translateTag(3839) //'Age'
                    layout.legend.y=-2
                    layout.showlegend=false
                    if (response){
                        Plotly.newPlot('get-current-average-employee', response[0],layout,config)
                    }
                })
            }

            vm.getAverageTrainingCompleted = (dateRange) => {
                $q.all([
                    hrService.getAverageTrainingCompleted(dateRange)
                ]).then((response)=>{      
                    layout = JSON.parse(JSON.stringify(vm.layout))      
                    Plotly.newPlot('get-average-training-completed', response[0],layout,config)
                })
            }

            vm.getAverageNumberOfValidTrainingByStartDate = () => {
                $q.all([
                    hrService.getAverageNumberOfValidTrainingByStartDate()
                ]).then((response)=>{    
                    layout = JSON.parse(JSON.stringify(vm.layout))   
                    if (response[0][0].x[0] == translateTag(3838)){
                        layout.showlegend = false
                    } else if (response[0][0].x.length == 1) {
                        layout.xaxis.range = [response[0][0].x[0]]
                    }
                    // layout.margin.t=50
                    layout.showlegend=
                    layout.xaxis.title.text= translateTag(2061) //"Year"
                    layout.yaxis.title.text= translateTag(3842) //'Average Number of Valid Trainings'
                    Plotly.newPlot('get-average-number-of-valid-training-by-year', response[0], layout,config1)
                })
            }

            vm.getAverageNumberOfValidTrainingByStartDate()

            vm.getAverageNumberOfTrainingCompletedByYearAndMonth = (dateRange) => {
                $q.all([
                    hrService.getAverageNumberOfTrainingCompletedByYearAndMonth(dateRange)
                ]).then((response)=>{ 
                    layout = JSON.parse(JSON.stringify(vm.layout))  
                    if (response[0][0].x[0] == translateTag(3838)){
                        layout.showlegend = false
                    }
                    // layout.xaxis.categoryorder = "category ascending"
                    layout.xaxis.dtick= 1
                    layout.xaxis.title.text= translateTag(2050) //"Month"
                    layout.yaxis.title.text= translateTag(3840) //'Average Number of Trainings Completed'
                    
                    layout.xaxis.title.text=translateTag(2050) //"Month"
                    layout.yaxis.title.text= translateTag(3785) //Average Number of Trainings Completed by Year and Month
                    Plotly.newPlot('get-average-number-of-training-completed-by-year-and-month', response[0], layout,config)
                })
            }

            vm.getAverageNumberOfValidTrainingCompletedByYearSite = (dateRange) => {
                $q.all([
                    hrService.getAverageNumberOfValidTrainingCompletedByYearSite(dateRange)
                ]).then((response)=>{    
                    layout = JSON.parse(JSON.stringify(vm.layout))          
                    if (response[0][0].x[0] == translateTag(3838)){
                        layout.showlegend = false
                    } 
                    layout.legend.y=-2
                    layout.xaxis.title.text= translateTag(828)  //"Site"
                    layout.yaxis.title.text= translateTag(3841)  //'Average Number of Valid Trainings Completed'
                    Plotly.newPlot('get-average-number-of-valid-training-completed-by-year-site', response[0], layout,config)
                })
            }

            vm.getDisciplinesBrokenDownBySiteMonthAndYear = (dateRange) => {
                $q.all([
                    hrService.getDisciplinesBrokenDownBySiteMonthAndYear(dateRange)
                ]).then((response)=>{   
                    layout = JSON.parse(JSON.stringify(vm.layout))   
                    if (response[0][0].x[0] == translateTag(3838)){
                        layout.showlegend = false
                    }
                    layout.xaxis.title.text= translateTag(2050) //"Month"
                    layout.yaxis.title.text= translateTag(3843) //'Discipline Count'
                    Plotly.newPlot('get-disciplines-broken-down-by-site-month-and-year', response[0], layout,config)
                })
            }
            vm.getReviewsBrokenDownBySiteMonthAndYear = (dateRange) => {
                $q.all([
                    hrService.getReviewsBrokenDownBySiteMonthAndYear(dateRange)
                ]).then((response)=>{  
                  
                    layout = JSON.parse(JSON.stringify(vm.layout)) 
                    if (response[0][0].x[0] == translateTag(3838)){
                        layout.showlegend = false
                    }
                    layout.xaxis.title.text= translateTag(2050) //"Month"
                    layout.yaxis.title.text= translateTag(3493) //'Review Count'
                    Plotly.newPlot('get-reviews-broken-down-by-site-month-and-year', response[0], layout,config)
                })
            }

            vm.filterCharts = (mode='graphs') => {
                filterObject.Jobs = vm.jobIdArray
                filterObject.Supervisors = vm.supervisorsArray
                filterObject.toggles = vm.toggles
                let startDate = vm.mainDateFilter.start_date
                let endDate = vm.mainDateFilter.end_date

                if (startDate)
                    filterObject.StartDate = startDate
                    filterObject.start_date = startDate //sarath
                if (endDate)
                    filterObject.EndDate = endDate
                    filterObject.end_date = endDate //sarath
                // getWidegtData(filterObject, mode)
                refreshFilters(filterObject, mode)
                dateRange={
                    "start_date": filterObject.StartDate,
                    "end_date": filterObject.EndDate,  
                    "lang": selectedLanguage           
                }
                $scope.dateRange = dateRange
            }

            vm.showHelp = (id) => {
                $('.modal .scroll').scrollTop(0)
                modalService.Open(id)
            }
            
            let infoObjects = {
                hrCumulativeEmployeeCount: {
                    title: translateTag(3751), // New and Cumulative Employee Counts by Employee Start Date
                    toolTip: translateTag(8735), // This graph outlines the number of new employees with the total number of active employees for each month over a selected period of time. The left side vertical axis displays the number of new employees for each month while the right side axis displays the total number of active employees.
                    list: [
                        {
                            label: translateTag(3833), // New Employee Count
                            description: translateTag(8736) // The number of new employees for each month
                        },
                        {
                            label: translateTag(3834), // Cumulative Count
                            description: translateTag(8737) // The total number of employees for the month
                        },
                        {
                            label: translateTag(1133), // Date Range
                            description: translateTag(8738) // The time period selected from the page filter
                        }
                    ]
                },
                hrEmployeeCountStatus: {
                    title: translateTag(3752), // Employee Count by Status
                    toolTip: translateTag(8739), // The three pie charts show the percentage of all, active or inactive employees within different categories 
                    list: [
                        {
                            label: translateTag(3835), // By Position
                            description: translateTag(8740) // The percentage of employees assigned to different positions
                        },
                        {
                            label: translateTag(3836), // By Site
                            description: translateTag(8741) // The number of employees at each site
                        },
                        {
                            label: translateTag(3837), // By Generation
                            description: translateTag(8742) // A segment of employees that belong to a certain generation group (Boomer, GenX, Millenial, GenZ)
                        },
                    ]
                },
                hrEmployeeAge: {
                    title: translateTag(3753), // Average Employee Age per Position
                    toolTip: translateTag(8743), // The graph shows the average age off all active employees within a certain position.
                    list: [
                        {
                            label: translateTag(3839), // Age
                            description: translateTag(8744) // Average age of the employees
                        },
                        {
                            label: translateTag(1277), // Position
                            description: translateTag(8745) // The position assigned to a group of individuals
                        }
                    ]
                },
                hrTrainingCompleted: {
                    title: translateTag(3770), // Average Training Completed
                    toolTip: translateTag(8746), // The pie chart displays as a percentage, the number of average trainings complete by all active employees during the selected period of time
                    list: [
                        {
                            label: translateTag(3837), // By Generation
                            description: translateTag(8742) // A segment of employees that belong to a certain generation group (Boomer, GenX, Millenial, GenZ)
                        }
                    ]
                },
                hrValidTrainingsYear: {
                    title: translateTag(3771), // Average Number of Valid Trainings by Year
                    toolTip: translateTag(8747), // This graph outlines the average number of valid trainings per person over time by year.
                    list: [
                        {
                            label: translateTag(3842), // Average Number of Valid Trainings
                            description: translateTag(8830) // Average number of valid training records per employee
                        },
                        {
                            label: translateTag(2061), // Year
                            description: translateTag(8831) // Years starting with the first year with a training record mapped
                        }
                    ]
                },
                hrTrainingCompletedYearMonth: {
                    title: translateTag(3785), // Average Number of Trainings Completed by Year and Month
                    toolTip: translateTag(8748), // This graph outlines the average number of valid trainings completed per person by year and month, for the selected time period. Each bar in the chart represents the average trainings completed in a specific month across multiple years.
                    list: [
                        {
                            label: translateTag(3840), // Average Number of Trainings Completed
                            description: translateTag(8749) // The average number of trainings completed per person
                        },
                        {
                            label: translateTag(2050), // Month
                            description: translateTag(8750) // Month of the year the training was completed in
                        }
                    ]
                },
                hrValidTrainingsYearSite: {
                    title: translateTag(3786), // Average Number of Valid Trainings Completed by Year and Site
                    toolTip: translateTag(8751), // This graph outlines the average number of valid trainings completed per person in a given year and grouped by site. Each bar in the graph represents one year.
                    list: [
                        {
                            label: translateTag(3840), // Average Number of Trainings Completed
                            description: translateTag(8749) // The average number of trainings completed per person
                        },
                        {
                            label: translateTag(828), // Site
                            description: translateTag(8753) // The site the person that complete the training is currently mapped to
                        }
                    ]
                },
                hrDisciplineSiteMonthYear: {
                    title: translateTag(3788), // Disciplines broken down by Site, Month and Year
                    toolTip: translateTag(8754), // The chart displays the number of disciplines created every month at the sites selected for a desired period of time. The bars in the chart represent the total number of disciplines submitted at all the sites selected during each month of a particular year.
                    list: [
                        {
                            label: translateTag(3843), // Discipline Count
                            description: translateTag(8755) // Total number of disciplines submitted
                        },
                        {
                            label: translateTag(2050), // Month
                            description: translateTag(8756) // Month of the year grouping the discipline count
                        }
                    ]
                },
                hrReviews: {
                    title: translateTag(3789), // Reviews broken down by Site, Month and Year
                    toolTip: translateTag(8757), // The graph displays the number of reviews on all the submissions in the application within a month for a given period of time. Each bar in the chart represents one year.
                    list: [
                        {
                            label: translateTag(3493), // Review Count
                            description: translateTag(8758) // The number of reviews within a month
                        },
                        {
                            label: translateTag(2050), // Month
                            description: translateTag(8759) // Month of the year grouping the review count
                        }
                    ]
                },
                hrTop10OneWordDisciplines: {
                    title: translateTag(3790), // Top 10 Disciplines - One Word Themes and Their Sentiments
                    toolTip: translateTag(8760), // The list compares the data from the current time span selected with the data from the same period of time that preceded it. The word within the Discipline Event Description field with the highest count is displayed at the top of the list. The trend shows the change in item position in the hierarchy between the current and previous time span.
                    list: [
                        {
                            label: "#", // #
                            description: translateTag(8761) // Order of items with the highest count at 1 and lowest count at 10
                        },
                        {
                            label: translateTag(2159), // One Word Theme
                            description: translateTag(8762) // A single word that is commonly used in the Discipline Event Description field
                        },
                        {
                            label: translateTag(2157), // Trend
                            description: translateTag(8763) // The difference in position of item in current time period compared to previous time period
                        },
                        {
                            label: translateTag(3721), // Sentiment
                            description: translateTag(8764) // These values range from -1 to 1. If the value is negative the text is negative (ex. Worst day ever) and if the value is positive the text is outlining a positive sentiment (ex. Excellent effort everyone!).
                        },
                    ]
                },
                hrTop10EmployeesDisciplined: {
                    title: translateTag(3791), // Top 10 Employees Being Disciplined
                    toolTip: translateTag(8832), // The list compares the data from the current time span selected with the data from the same period of time that preceded it. The employee with the highest number of disciplines is displayed at the top of the list. The trend shows the change in item position in the hierarchy between the current and previous time span.
                    list: [
                        {
                            label: "#", // #
                            description: translateTag(8761) // Order of items with the highest count at 1 and lowest count at 10
                        },
                        {
                            label: translateTag(204), // Employee Name
                            description: translateTag(8766) // The name of the employee being disciplined
                        },
                        {
                            label: translateTag(2157), // Trend
                            description: translateTag(8763) // The difference in position of item in current time period compared to previous time period
                        }
                    ]
                }
            }

            vm.openInfoModal = (infoObject) => {
                vm.currentInfo = infoObjects[infoObject]
                modalService.Open('infoModalComponent')
            }

        }])