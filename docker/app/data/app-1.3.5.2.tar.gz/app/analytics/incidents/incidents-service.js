﻿angular
    .module('safeToDo')
    .service('incidentsAnalyticsService', ['$http',
        function ($http) {
            let positiveIdData = []
            let hazardsToPositiveId = {}
            let hazardsToPositiveIdAll = {}

            let gettop10AvgIncPerPositionData = ''
            let gettop10IncTypeAndCategoriesData = ''
            let getTop10Incident1WordThemesData = ''
            let getTop10Incidents2WordData = ''

            let color_palette = ["#0072ce", "#66aae2", "#F7BD03","#00447c", "#6e94ba", "#7272ad", "#d8bd87", "#447259", "#474747", "#b3bccf", 
            "#99bcac", "#a9ddff", "#96a9aa", "#001e60", "#777777", "#005ba5", "#0087b3", "#002e52", "#99c7eb", "#a4a1d5", "#00445a", 
            "#378ddc", "#424686", "#fcecb3", "#9c6492", "#16492d", "#d193ae", "#eacfce", "#8a7fd0", "#616699", "#006586", "#ddab00", 
            "#c292cd", "#d6d3ff", "#5f3c79", "#00a9e0", "#ffb359", "#58cad3"]

            let dataSet={
                title:{text:"", font:{family:"Arial Black", color:"black", size:"16"}, x:0.5, xanchor:"center", y:-20, yanchor: "top"},                
                type: 'pie',
                showlegend: false,
                labels: [],
                values: [],
                hovertemplate:
                "<b>%{label}</b><br><br>"+
                "<extra></extra>",
                textinfo: "label",
                marker: {
                    color: color_palette[0]
                },                              
                offsetgroup: 1,
            }

            let noData = [{type:'bar', x: [translateTag(3838)], y: [0]}]

            return {
            getAbsoluteAndAverageIncidentsBySite: (dateRange) => {
                    if (dateRange.sites === []){
                        return noData
                    }
                    else{
                        return $http.post(`${__env.apiUrl}/api/analytic/absolute-incident-count-vs-average-incident-per-person-by-site/`, dateRange).then((response) => { 
                            if (response.data == 'No Data to Show' || response.data.hasOwnProperty('error') || response.statusText == "Internal Server Error" || response.data == 'Please provide the site'){
                                return noData
                            }
                            else{ 
                                 
                                data=[]   

                                try{
                                                        
                                        data.push({
                                            type: 'bar',
                                            x: response.data.x_axis,
                                            y: response.data.y_axis.average_incidents,                                      
                                            marker: {
                                                color: color_palette[0]
                                            },                              
                                            name: 'Average Incidents',
                                            yaxis: 'y',
                                            offsetgroup: 1,
                                            }
                                        ), 
                                        data.push({
                                            type: 'bar',
                                            x: response.data.x_axis,
                                            y: response.data.y_axis.total_incidents,
                                            marker: {
                                                color: color_palette[31]
                                            },
                                            name: 'Incident Count',
                                            yaxis: 'y2',
                                            offsetgroup: 2,                                
                                            }
                                        ) 
                                    }
                                    catch(e){
                                    }

                                return data 
                            }    
                        }, (args) => {
                            console.log('Failed to load action trend data.', args)
                        })
                    }
                },

            getIncidentsBySiteMonthYear: (dateRange) => {
                if (dateRange.year.length === 0  || dateRange.sites.length === 0){                    
                    return noData
                } else{              
                return $http.post(`${__env.apiUrl}/api/analytic/incident-by-site-month-and-year/`, dateRange).then((response) => { 
                  
                    if (response.data == 'No Data to Show' || response.data.statusText == "Internal Server Error"){
                        return noData
                    }
                    else{
                        data=[]
                       
                        for (year in response.data){
                            month_name=[]
                            for(month in response.data[year].x_axis){
                                month_trans=translateTag(plotlyTags[response.data[year].x_axis[month]])
                                month_name.push(month_trans)
                                

                            }
                            data.push({
                                type: 'bar',
                                x: month_name,
                                y: response.data[year].y_axis,                                
                                name: response.data[year].name,
                                marker: {color: color_palette[year]},
                                }
                            )
                        }
                        return data 
                    }    
                }, (args) => {
                    console.log('Failed to load getIncidentsBySiteMonthYear data.', args)
                })
            }
            },

            getIncidenTypeBySiteMonthYear: (dateRange) => {
                if ( dateRange.year=== undefined || dateRange.year.length === 0  || dateRange.sites=== undefined || dateRange.sites.length === 0){
                    return noData
                }  
                
                return $http.post(`${__env.apiUrl}/api/analytic/incident-type-by-site-month-and-year/`, dateRange).then((response) => { 
                    if (response.data == 'No Data to Show'){
                        return noData
                    }
                    else{
                        data=[]
                        for (year in response.data){
                            month_name=[]
                            for(month in response.data[year].x_axis){
                                month_trans=translateTag(plotlyTags[response.data[year].x_axis[month]])
                                month_name.push(month_trans)
                                

                            }
                        for (year in response.data){
                            data.push({
                                type: 'bar',
                                x: month_name,
                                y: response.data[year].y_axis,                                
                                name: response.data[year].name,
                                marker: {color: color_palette[year]},
                                }
                            )
                        }
                        return data 
                    }    
                }
            }, (args) => {
                    console.log('Failed to load getIncidenTypeBySiteMonthYear data.', args)
                })
            },
            
            getIncidentsVsHazardsCountByMonth: (dateRange) => {
                if (dateRange.start_date === "" || dateRange.end_date === ""){
                    return noData
                }
                else{
                    return $http.post(`${__env.apiUrl}/api/analytic/incident-vs-hazards-count-by-month/`, dateRange).then((response) => { 
                          
                        if (response.data == 'No Data to Show' || response.data.hasOwnProperty('error') || response.statusText == "Internal Server Error"){
                            return noData
                        }
                        else{ 
                             
                            data=[]
                            month_name=[]
                        for (month in response.data.x_axis){                           
                                month_trans=translateTag(plotlyTags[response.data.x_axis[month]])
                                month_name.push(month_trans)
                            }  
                        

                            try{
                                                    
                                    data.push({
                                        type: 'bar',
                                        x: month_name,
                                        y: response.data.y_axis.incident_count,                                      
                                        marker: {
                                            color: color_palette[0]
                                        },                              
                                        name: translateTag(3853), //'Incident Count',
                                        yaxis: 'y',
                                        offsetgroup: 1,
                                        }
                                    ), 
                                    data.push({
                                        type: 'bar',
                                        x: month_name,
                                        y: response.data.y_axis.hazard_count,
                                        marker: {
                                            color: color_palette[31]
                                        },
                                        name: translateTag(2128), //'Hazard Count',
                                        yaxis: 'y2',
                                        offsetgroup: 2,                                
                                        }
                                    ) 
                                }
                                catch(e){
                                }

                            return data 
                        }    
                    }
                , (args) => {
                        console.log('Failed to load getIncidentsVsHazardsCountByMonth data.', args)
                    })
                
                }
            },

            getIncidentsVsHazardsCountByDayOfWeek: (dateRange) => {
                if (dateRange.sites == []){
                    return noData
                }
                else{
                    return $http.post(`${__env.apiUrl}/api/analytic/incident-vs-hazard-count-by-count-of-week/`, dateRange).then((response) => { 
                        if (response.data == 'No Data to Show' || response.data.hasOwnProperty('error') || response.statusText == "Internal Server Error"){
                            return noData
                        }
                        else{ 
                             
                            data=[]
                            
                            week_name=[]
                            for (week in response.data.x_axis){                           
                                week_trans=translateTag(plotlyTags[response.data.x_axis[week]])
                                week_name.push(week_trans)
                            }

                            try{
                                                    
                                    data.push({
                                        type: 'bar',
                                        x:week_name,
                                        y: response.data.y_axis.incident_count,                                      
                                        marker: {
                                            color: color_palette[0]
                                        },                              
                                        name: translateTag(3853), //'Incident Count',
                                        yaxis: 'y',
                                        offsetgroup: 1,
                                        }
                                    ), 
                                    data.push({
                                        type: 'bar',
                                        x:week_name,
                                        y: response.data.y_axis.hazard_count,
                                        marker: {
                                            color: color_palette[31]
                                        },
                                        name: translateTag(2128), //'Hazard Count',
                                        yaxis: 'y2',
                                        offsetgroup: 2,                                
                                        }
                                    ) 
                                }
                                catch(e){
                                }

                            return data 
                        }    
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                }
            },  
            
            getAverageIncidentsByGeneration: (dateRange) => {
                return $http.post(`${__env.apiUrl}/api/analytic/average-incidents-by-generation/`, dateRange).then((response) => {
                   
                    dataSet1=JSON.parse(JSON.stringify(dataSet))   
                    data=[dataSet1]   
                    if (response.data == 'No Data to Show'){
                        dataNoData=data                         
                        dataNoData[0].labels=["No Data To Show"]
                        dataNoData[0].values=[1]
                        return data
                    }
                    else{
                        curdata = response.data.by_generation
                        
                            data[0].textinfo="%value"
                            data[0].labels = []
                            for(i in curdata.x_axis){
                                data[0].labels.push(translateTag(parseInt(plotlyTags[curdata.x_axis[i]])))
                            }
                        data[0].textinfo="%value"
                        data[0].title.text=translateTag(3837) //"By Generation"
                        data[0].values=curdata.y_axis
                        return data 
                    }    
                }, (args) => {
                    console.log('Failed to load action trend data.', args)
                })
            },

            getIncidentCountByMonthAndYear: (dateRange) => {
                if (dateRange['year'] == []){
                    return noData
                }
               
                return $http.post(`${__env.apiUrl}/api/analytic/incident-count-by-month-and-year/`, dateRange).then((response) => { 
                    if (response.data == 'No Data to Show' || response.data == 'Please provide the year: []'){
                        return noData
                    }
                    else{
                        data=[]
                        curYear = ""                   
                        let counter = 0;
                        for (year in response.data){
                            month_name=[]
                            for(month in response.data[year].x_axis){
                                month_trans=translateTag(plotlyTags[response.data[year].x_axis[month]])
                                month_name.push(month_trans)
                                

                            }
                            data.push({
                                            type: 'line',
                                            x: month_name,
                                            y: response.data[year].y_axis,                                
                                            name: response.data[year].name,
                                            marker: {color: color_palette[year]},
                                            }
                                        )
                        }                        
                        return data 
                    }    
                }, (args) => {
                    console.log('Failed to load getIncidentCountByMonthAndYear data.', args)
                })
            },

            getTRIFRAnalyticsData: () => {
                return $http.get(`${__env.apiUrl}/api/whl/get-trifr-analytics-data/`).then((response) => {                     
                    trifr_chart_data = response.data
                    data={
                        "rec_inc_inj_ytd": [],
                        "rec_inc_inj_past_12_months": [],
                        "is_empty": false,
                        "trifr_track_option": trifr_chart_data.trifr_track_option,
                        "trir_track_option" : trifr_chart_data.trir_track_option
                    }
                  
                    if (trifr_chart_data.trifr_ytd.length == 0 || trifr_chart_data.trifr_past_year.length == 0){
                        data['rec_inc_inj_ytd'].push(noData)
                        data['rec_inc_inj_past_12_months'].push(noData)
                        data['is_empty'] = true
                        return data
                    }
                    else {
                        
                        data['rec_inc_inj_ytd'].push({
                            type: 'line',
                            x: trifr_chart_data.trifr_ytd[0].dates,
                            y: trifr_chart_data.trifr_ytd[0].y_axis_trifr,
                            yaxis: 'y',                              
                            name: translateTag(2738), //"Rate of Recordable injuries",
                        })
                        data['rec_inc_inj_ytd'].push({
                            type: 'line',
                            x: trifr_chart_data.trifr_ytd[0].dates,
                            y: trifr_chart_data.trifr_ytd[0].y_axis_trir,                              
                            name: translateTag(2739), //"Rate of Recordable incidents",
                            yaxis: 'y2',
                        })
                        data['rec_inc_inj_past_12_months'].push({
                            type: 'line',
                            x: trifr_chart_data.trifr_past_year[0].dates,
                            y: trifr_chart_data.trifr_past_year[0].y_axis_trifr,
                            yaxis: 'y',                              
                            name: translateTag(2738), //"Rate of Recordable injuries",
                        })
                        data['rec_inc_inj_past_12_months'].push({
                            type: 'line',
                            x: trifr_chart_data.trifr_past_year[0].dates,
                            y: trifr_chart_data.trifr_past_year[0].y_axis_trir,                              
                            name: translateTag(2739), //"Rate of Recordable incidents",
                            yaxis: 'y2',
                        })                  
                        return data 
                    }
                })   
            },

            getAverageTrainingCompletedVsAverageIncidentsByPosition: (dateRange) => {
                if (dateRange.sites == []){
                    return noData
                }
                else{
                    return $http.post(`${__env.apiUrl}/api/analytic/average-training-completed-vs-average-incidents-by-position/`, dateRange).then((response) => { 
                        if (response.data == 'No Data to Show' || response.data.hasOwnProperty('error') || response.statusText == "Internal Server Error"){
                            return noData
                        }
                        else{ 
                             
                            data=[]   

                            try{
                                                    
                                    data.push({
                                        type: 'bar',
                                        x: response.data.x_axis, 
                                        y: response.data.y_axis.avg_trainings,                                      
                                        marker: {
                                            color: color_palette[0]
                                        },                              
                                        name: 'Average Trainings',
                                        yaxis: 'y',
                                        offsetgroup: 1,
                                        }
                                    ), 
                                    data.push({
                                        type: 'bar',
                                        x: response.data.x_axis,
                                        y: response.data.y_axis.avg_incidents,
                                        marker: {
                                            color: color_palette[31]
                                        },
                                        name: 'Average Incidents',
                                        yaxis: 'y2',
                                        offsetgroup: 2,                                
                                        }
                                    ) 
                                }
                                catch(e){
                                }

                            return data 
                        }    
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                }
            }, 

            getAverageNumberOfValidTrainingsCompletedBySite: (dateRange) => {
                if (dateRange.sites == [] || dateRange.start_date == ''){
                    return noData
                }
                else{
                    return $http.post(`${__env.apiUrl}/api/analytic/average-trainings-completed-vs-average-incidents-by-site/`, dateRange).then((response) => { 
                        if (response.data == 'No Data to Show' || response.data.hasOwnProperty('error') || response.statusText == "Internal Server Error" || response.data == 'Please provide the site'){
                            return noData
                        }
                        else{ 
                             
                            data=[]   

                            try{
                                                    
                                    data.push({
                                        type: 'bar',
                                        x: response.data.x_axis, 
                                        y: response.data.y_axis.avg_trainings,                                      
                                        marker: {
                                            color: color_palette[0]
                                        },                              
                                        name: 'Average Trainings',
                                        yaxis: 'y',
                                        offsetgroup: 1,
                                        }
                                    ), 
                                    data.push({
                                        type: 'bar',
                                        x: response.data.x_axis,
                                        y: response.data.y_axis.avg_incidents,
                                        marker: {
                                            color: color_palette[31]
                                        },
                                        name: 'Average Incidents',
                                        yaxis: 'y2',
                                        offsetgroup: 2,                                
                                        }
                                    ) 
                                }
                                catch(e){
                                }

                            return data 
                        }    
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                }
            }, 


            getIncidentAndHazardCountsVsSubmissionCompliance: (dateRange) => {
                if (dateRange.start_date == ""){
                    return noData
                }
                else{
                    return $http.post(`${__env.apiUrl}/api/analytic/incident-and-hazard-counts-vs-submission-compliance/`, dateRange).then((response) => { 
                        if (response.data == 'No Data to Show'){
                            return noData
                        }
                        else{
                            data=[]
                            curYear = ""                   
                            let counter = 0;
                     
                            data.push({
                                type: 'line',
                                x: response.data.x_axis, 
                                y: response.data.y_axis.incident_count, 
                                name: translateTag(3853), //'hello',//'Incident Count',
                                marker: {color: color_palette[1]},
                                yaxis: 'y',                              
                                title: translateTag(3853) //'hello',//'Incident Count',
                                }
                            )

                            data.push({
                                    type: 'line',
                                    x: response.data.x_axis, 
                                    y: response.data.y_axis.hazard_count,                        
                                    name: translateTag(2128), //'Hazard Count',
                                    marker: {color: color_palette[2]},
                                    yaxis: 'y2',                                      
                               }
                            )
                            data.push({
                                    type: 'line',
                                    x: response.data.x_axis, 
                                    y: response.data.y_axis.submission_count,                        
                                    name: translateTag(8651), //'Submission Compliance',
                                    marker: {color: color_palette[3]},
                                    yaxis: 'y3',
                                }
                            )
                            return data 
                        }    
                    }, (args) => {
                        console.log('Failed to load getIncidentAndHazardCountsVsSubmissionCompliance data.', args)
                    })
                }
            }, 


            gettop10AvgIncPerPosition: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/analytic/top-10-average-incidents-by-position/`, dateRange).then((response) => { 
                        gettop10AvgIncPerPositionData = response.data
                        return response.data                    
                        
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
            },
            
            readtop10AvgIncPerPosition:()=>{
                return gettop10AvgIncPerPositionData
            },

            gettop10IncTypeAndCategories: (dateRange) => {
                return $http.post(`${__env.apiUrl}/api/analytic/top-10-incident-types-and-categories/`, dateRange).then((response) => { 
                    gettop10IncTypeAndCategoriesData = response.data
                    return response.data                    
                    
                }, (args) => {
                    console.log('Failed to load action trend data.', args)
                })
             },
        
            readtop10IncTypeAndCategories:()=>{
                return gettop10IncTypeAndCategoriesData
            },
            

            getTop10Incident1WordThemes: (dateRange) => {
                return $http.post(`${__env.apiUrl}/api/analytic/top-10-incident-one-word-themes/`, dateRange).then((response) => { 
                    getTop10Incident1WordThemesData = response.data
                    return response.data 
                }, (args) => {
                    console.log('Failed to load action trend data.', args)
                })
             },
        
            readTop10Incident1WordThemes:()=>{
                return getTop10Incident1WordThemesData
            },

            getTop10Incidents2Word: (dateRange) => {
                return $http.post(`${__env.apiUrl}/api/analytic/top-10-incident-two-word-themes/`, dateRange).then((response) => { 
                    getTop10Incidents2WordData = response.data
                    return response.data  
                }, (args) => {
                    console.log('Failed to load action trend data.', args)
                })
             },
        
            readTop10Incidents2WordThemes:()=>{
                return getTop10Incidents2WordData
            },



           

               
            }
        }
    ])