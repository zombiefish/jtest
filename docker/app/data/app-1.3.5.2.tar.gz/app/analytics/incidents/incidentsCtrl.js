﻿angular
    .module('safeToDo')
    .controller('incindetAnalyticsCtrl', ['select2Service', 'employeesService', 'listService', '$scope', '$compile','$timeout', '$rootScope', '$q', '$location', '$window', 'gridService', 'incidentsAnalyticsService', 'modalService',
        function (select2Service, employeesService, listService, $scope, $compile, $timeout,$rootScope,$q, $location, $window, gridService, incidentsAnalyticsService, modalService) {
            var vm = this
            
            vm.targets = []
            vm.supervisors = []
            vm.frequencies = []
            vm.forms = []
            vm.defaultselectedSites= []
            vm.defaultIncidentClassselectedSites=null
            vm.toolTipSites = ''
            vm.toolTipIncidentTypeSites = ''
            vm.defaultUserProfileSites= []
            vm.siteList = []
            vm.hazards = []
            vm.track_trifr = false
            vm.options = gridService.getCommonOptions()
            vm.topSearch = ''
            vm.incidentYear = ""    
            vm.incidentClassYear = ""    
            vm.employeeList = []
            vm.curPage = "Graphs" 

            setTimeout(()=>{
                vm.loadMessage = translateTag(8678) // "Loading Incidents Analytics Page. Please wait..."
            },500)

            vm.initializeSelect2 = (parent, section='') => {
                $timeout(() => {
                $('.select-single, .select-multiple')
                    .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} ${section}`), escapeMarkup: function (text) { return text }})
                    .on('select2:select', (event) => {
                        $(this).parent().find('label').addClass('filled');
                        $(event.currentTarget).parent().find('label').addClass('filled')
                    })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down");
                select2Service.select2Tags_2_max()
                }, 100)
            }

            $('#incident_site').change(function(){
                if($("#incident_site option[value='-1']").is(':selected')){
                    if(!vm.isSelectAll){
                        selectAll()
                        vm.isSelectAll = true
                    }
                    else{
                        deSelectAll()
                        vm.isSelectAll = false
                    }
                }
            })
    
            function selectAll(){
                $('#incident_site option').prop('selected', true)
                $("#incident_site option[value='-1']").prop('selected', false)
            }
    
            function deSelectAll(){
                $('#incident_site option').prop('selected', false)
                $("#incident_site option[value='-1']").prop('selected', false)
            }
            vm.initializeSelect2("siteselection")            

            bindSiteControl()
            function bindSiteControl(){
                $q.all([
                    employeesService.getPersonProfile(),
                    listService.getSelectListData('ref_site'),
                ]).then((data) => {
                    vm.getUserProfile = data[0]
                    vm.siteList = data[1]
                    vm.incidentTypeSiteList = data[1]
                    if(vm.siteList && vm.siteList.length>0){
                        var select = document.getElementById("incident_site")
                        var option = document.createElement('option')
                        option.text =  translateTag(8684)
                        option.value =  -1
                        select.add(option, 0)
                    }
                    if(vm.getUserProfile.siteIds != null && vm.getUserProfile.siteIds){
                        if(vm.getUserProfile.siteIds.length > 0){
                            vm.defaultselectedSites = vm.getUserProfile.siteIds.split(', ').map(element => {
                                return Number(element)
                            })
                            
                            vm.defaultUserProfileSites = vm.defaultselectedSites
                            if(vm.defaultselectedSites.length>0){
                                vm.defaultIncidentClassselectedSites=vm.defaultselectedSites[0]
                            }
                            vm.toolTipSites = vm.getUserProfile.sites
                            vm.toolTipIncidentTypeSites=vm.getUserProfile.sites
                        } 
                    }
                }).then(() => {
                    vm.initializeSelect2("siteselection") 
                    vm.initializeSelect2("incidentTypeSiteselection")
                    
                }).then(()=>{
                    vm.siteApplyFilter()
                    vm.IncidentClassSiteFilter()                  

                })
            }

            // button click for selected sites 
            vm.siteApplyFilter = () =>{
                $scope.$emit('STARTSPINNER', vm.loadMessage)
                let payload = {
                    year:"",
                    sites:[]
                }               
                payload.year = vm.incidentYear
                payload.sites = vm.defaultselectedSites 
                vm.getIncidentsBySiteMonthYear(payload)
            }
            // incident class apply filter
            vm.IncidentClassSiteFilter = () =>{
                $scope.$emit('STARTSPINNER', vm.loadMessage)
                let payload = {
                    year:"",
                    sites:""
                }               
                payload.year = vm.incidentClassYear
                if(vm.defaultIncidentClassselectedSites){
                    payload.sites = vm.defaultIncidentClassselectedSites 
                }
                else{
                    payload.sites=''
                }
                vm.getIncidenTypeBySiteMonthYear(payload)
            }
            
                   
            vm.mainDateFilter = {
                start_date: moment().subtract(90, 'days').format('YYYY-MM-DD 00:00:00.000'),
                end_date: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD 00:00:00.000')
            }    

            let noData = [{type:'bar', x: ['No Data to Show'], y: [0]}]              
        
            vm.monthNamesLong = [{name:'January', short: 'Jan', number: '01'},
            {name: 'February', short: 'Feb', number: '02'} ,
            {name:'March', short: 'Mar', number:'03'} , 
            {name:'April', short: 'Apr', number:'04'}, 
            {name:'May', short: 'May', number:'05'}, 
            {name:'June', short: 'June', number:'06'}, 
            {name:'July', short: 'July', number:'07'}, 
            {name:'August', short: 'Aug', number:'08'}, 
            {name:'September', short: 'Sept', number:'09'}, 
            {name:'October', short: 'Oct', number:'10'}, 
            {name:'November', short: 'Nov', number:'11'}, 
            {name:'December', short: 'Dec', number:'12'}]
            vm.monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
            // vm.years = [2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030]
            vm.options = gridService.getCommonOptions()
            vm.count = 1
            vm.closeFlag = false
            vm.singleRun = true

            vm.currentInfo = {}

            let filterObject = {
                Jobs:[]
            }

            function getMonthFromString(mon) {
                return new Date(Date.parse(mon + " 1, 2017")).getMonth() + 1;
            }

            vm.graphFilters = {
                'get-absolute-incident-count-vs-average-incidents-by-site': {'start_date': '', 'end_date': '', 'sites': []},
                'get-incident-by-site-month-year-currentyear': {'year': [], 'sites': []},
                'get-incident-type-by-site-month-and-year-currentyear-single': {'year': [], 'sites': []},
                'get-incidents-vs-hazards-count-by-month': {'start_date': '', 'end_date': ''},
                'get-incidents-vs-hazards-count-day-of-week': {'start_date': '', 'end_date': ''},     
                'get-incident-count-by-month-and-year-currentyear': {'year': ''},
                'get-incident-and-hazard-counts-vs-submission-compliance-default90': {'start_date': '', 'end_date': ''},                
                'get-average-training-completed-vs-average-incidents-by-position': {'start_date': '', 'end_date': ''},
                'get-average-trainings-completed-vs-average-incidents-by-site': {'start_date': '', 'end_date': '', 'sites': []},
            }
            
            $scope.$on('FILTERCHANGE', (data) => {
                $scope.$emit('STARTSPINNER', vm.loadMessage)
               
                if($location.url() === '/analytics/incidents'){
                    id = data.targetScope.vm.id
                    vm.count ++

                    if (data.targetScope.vm.typeOfFilter == 'site'){
                        vm.filter = data.targetScope.vm.curSites
                    } else if (data.targetScope.vm.typeOfFilter == 'date'){
                        vm.filter = data.targetScope.vm.range
                        vm.filter.start_date = `${vm.filter.start_date} 00:00:00.000`
                        vm.filter.end_date = `${vm.filter.end_date} 23:59:59.999`
                    } else if (data.targetScope.vm.typeOfFilter == 'active'){
                        vm.filter = data.targetScope.vm.dropdownDisplay
                    }

                    typeOfFilter = data.targetScope.vm.typeOfFilter
                                     
                    if (id == 'get-incident-by-site-month-year-currentyear'){  
                        // Section :: Incident by Site, Month, and Year
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        if (typeOfFilter == "year"){
                            vm.incidentYear = data.targetScope.vm.selectedYears[0]         
                        }
                        vm.siteApplyFilter()
                        vm.getSiteSelectedTooltip()
                    }  
                    else if (id == 'get-incident-type-by-site-month-and-year-currentyear-single'){  
                        // Section :: Incident Type by Site, Month, and Year
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        if (typeOfFilter == "year"){                            
                            vm.incidentClassYear = data.targetScope.vm.selectedYears[0]
                        }                     
                        vm.IncidentClassSiteFilter()
                    }
                    else if (id == 'get-incidents-vs-hazards-count-by-month'){  
                        // Section :: Incidents vs Hazards Count by Month
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        if (typeOfFilter == "date"){
                            vm.graphFilters[id]['start_date'] = data.targetScope.vm.range['start_date']
                            vm.graphFilters[id]['end_date'] = data.targetScope.vm.range['end_date']
                        }                                     
                        if(vm.graphFilters[id]['start_date'] != '' ){
                            vm.getIncidentsVsHazardsCountByMonth(vm.graphFilters[id])
                        }
                        if(vm.closeFlag){
                            $scope.$emit('STOPSPINNER')
                        }
                    }
                    else if (id == 'get-incidents-vs-hazards-count-day-of-week'){  
                        // Section :: Incidents vs Hazards Count by Day Of Week
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        if (typeOfFilter == "date"){
                            vm.graphFilters[id]['start_date'] = data.targetScope.vm.range['start_date']
                            vm.graphFilters[id]['end_date'] = data.targetScope.vm.range['end_date']
                        }                                     
                        if(vm.graphFilters[id]['start_date'] != '' ){
                            vm.getIncidentsVsHazardsCountByDayOfWeek(vm.graphFilters[id])
                        }
                        if(vm.closeFlag){
                            $scope.$emit('STOPSPINNER')
                        }
                    }
                    else if(id == "get-average-incidents-by-generation"){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        vm.getAverageIncidentsByGeneration(vm.filter)
                        $scope.$emit('STOPSPINNER')
                    }
                    else if(id == "get-incident-count-by-month-and-year-currentyear"){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                        if (typeOfFilter == "year"){
                            vm.graphFilters[id]['year'] = data.targetScope.vm.selectedYears         
                        }
                    
                        vm.getIncidentCountByMonthAndYear(vm.graphFilters[id]['year'])
                        if(vm.closeFlag){
                            $scope.$emit('STOPSPINNER')
                        }
                       
                    }
                    else if(id == "get-incident-and-hazard-counts-vs-submission-compliance-default90"){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)                       
                        if (typeOfFilter == "date"){
                         
                            vm.graphFilters[id]['start_date'] = data.targetScope.vm.range['start_date']
                            vm.graphFilters[id]['end_date'] = data.targetScope.vm.range['end_date']
                        } 
                        vm.getIncidentAndHazardCountsVsSubmissionCompliance(vm.graphFilters[id])                        
                        if(vm.closeFlag){
                            $scope.$emit('STOPSPINNER')
                        }
                    }
                    else if (id == 'top10IncTypeAndCategories-default90'){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)
                            $q.all([                                
                                incidentsAnalyticsService.gettop10IncTypeAndCategories(vm.filter),
                            ]).then(() => {
                                setTimeout(() => { 
                                    vm.top10IncTypeAndCategories = incidentsAnalyticsService.readtop10IncTypeAndCategories()                                                                
                               
                                    vm.loadWidgetComponent('top10IncTypeAndCategories-default90', vm.top10IncTypeAndCategories, "", translateTag(8851)) //'Type - Category'           
                                
                                    if(vm.closeFlag){
                                        $scope.$emit('STOPSPINNER')
                                    }
                                }, 100);
                            }) 
                    }
                    else if (id == 'top10Inc1WordTheme-default90'){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)                      
                            $q.all([                                
                                incidentsAnalyticsService.getTop10Incident1WordThemes(vm.filter),
                            ]).then(() => { 
                                setTimeout(() => {                                
                                    vm.top10Incident1WordThemes = incidentsAnalyticsService.readTop10Incident1WordThemes()
                                    vm.loadWidgetComponent('top10Inc1WordTheme-default90', vm.top10Incident1WordThemes, "", translateTag(2159))  //'One Word Theme'          
                                    if(vm.closeFlag){
                                        $scope.$emit('STOPSPINNER')
                                    }
                                }, 100);
                            }) 
                    }
                    else if (id == 'top10Inc2Word-default90'){
                        $scope.$emit('STARTSPINNER', vm.loadMessage)                      
                            $q.all([                                
                                incidentsAnalyticsService.getTop10Incidents2Word(vm.filter),
                            ]).then(() => {
                                setTimeout(() => {   
                                    vm.top10Incidents2Word = incidentsAnalyticsService.readTop10Incidents2WordThemes()
                                    vm.loadWidgetComponent('top10Inc2Word-default90', vm.top10Incidents2Word, "",translateTag(2161)) //'Two Word Theme'
                                    vm.closeFlag= true
                                    if(vm.closeFlag){
                                        $scope.$emit('STOPSPINNER')
                                    }
                                }, 100);
                            }) 
                    }

                    if(vm.closeFlag){
                        $scope.$emit('STOPSPINNER')
                    }
                    
                }
            })
            
            var currentDate = new Date();
            let dateToday = moment(new Date(), 'YYYY-MM-DD')
            function getMonthName(month, type='long'){
                let theMonth = ''
               vm.monthNamesLong.forEach((mth)=>{
                   if(mth.number === month) {
                    theMonth =  type === 'long'? mth.name : nth.short
                   }
                })
                return theMonth
            }

            vm.dateFilter = {
                start_month: $window.sessionStorage.getItem("start_month") ? $window.sessionStorage.getItem("start_month") : dateToday.format("MM"),
                start_year: $window.sessionStorage.getItem("start_year") ? Number($window.sessionStorage.getItem("start_year")) : currentDate.getFullYear(),
                end_month: $window.sessionStorage.getItem("end_month") ? $window.sessionStorage.getItem("end_month") : dateToday.format("MM"),
                end_year: $window.sessionStorage.getItem("end_year") ? Number($window.sessionStorage.getItem("end_year")) : currentDate.getFullYear(),
                getFormattedRange: () => {
                    var start = getMonthName(vm.dateFilter.start_month) + " " + this.start_year
                    var end = getMonthName(vm.dateFilter.end_month) + " " + this.end_year
                    if (start == end) {
                        return start
                    }

                    return start + " - " + end;
                },
                validate: () => {
                    if (this.start_year > this.end_year) {
                        return false
                    }
                    if (this.start_year == this.end_year) {
                        if (getMonthFromString(this.start_month) > getMonthFromString(this.end_month)) {
                            return false
                        }
                    }

                    return true;
                }
            }

            vm.loadWidgetComponent = (divId, data, title,subTitle) => {
                setTimeout(() => {                    
               
                    let widgetData = []
                    data.forEach((item) => {
                        if(item.keyword=='No Data to Show'){
                            item.keyword=translateTag(3838)
                        }
                        else if(item.keyword=="N/A"){
                            item.keyword=translateTag(1381)
                        }
                    widgetData.push({id:item.id, keyword: item.keyword.toString().replaceAll("'","&#39"), trend:item.trend})
                    })
                    vm.newdata = JSON.stringify(widgetData)
                    $('#'+divId).html($compile(`    
                        <top-ten-widget-form data='${vm.newdata}' sub-title='${subTitle.toString().replaceAll("'","&#39")}'></top-ten-widget-form>
                    `)($scope))

                }, 1000);
            }

            /*
                Date filter Stuff
            */
            vm.getStartDate = () => {
                if (vm.dateFilter.start_month && vm.dateFilter.start_year) {
                    var monthNum = vm.dateFilter.start_month
                    var sd =`${vm.dateFilter.start_year}-${monthNum}-01`
                    return sd
                }
                return null
            }

            vm.getEndDate = () => {
                
                if (vm.dateFilter.end_month && vm.dateFilter.end_year) {
                    var monthNum = vm.dateFilter.end_month
                    momentEndDate = moment(`${vm.dateFilter.end_year}-${monthNum}-01`,'YYYY-MM-DD')
                    var ed = `${vm.dateFilter.end_year}-${monthNum}-${momentEndDate.endOf('month').format('DD')}`
                    return ed
                }
                return null;
            }

            vm.getDateFilterDescription = () => {
                return vm.dateFilter.getFormattedRange();
            }

            vm.dateFilterMenu = ($event) => {
                $event.stopPropagation();
                vm.hideDropdowns();
                var actions = $('#dateFilterDropdown');
                actions.addClass('show');
            }

            vm.dateFilterValid = () => {
                return vm.dateFilter.validate();
            }

            vm.loadTop10=()=>{
                $scope.$emit('STARTSPINNER', vm.loadMessage)    
                $q.all([                                
                    incidentsAnalyticsService.gettop10IncTypeAndCategories(vm.mainDateFilter),
                    incidentsAnalyticsService.getTop10Incident1WordThemes(vm.mainDateFilter),
                    incidentsAnalyticsService.getTop10Incidents2Word(vm.mainDateFilter),
                ]).then(() => {
                    setTimeout(() => { 
                        vm.top10IncTypeAndCategories = incidentsAnalyticsService.readtop10IncTypeAndCategories()                                                                                           
                        vm.loadWidgetComponent('top10IncTypeAndCategories-default90', vm.top10IncTypeAndCategories, "", translateTag(8851)) //Type - Category  
                        vm.top10Incident1WordThemes = incidentsAnalyticsService.readTop10Incident1WordThemes()
                        vm.loadWidgetComponent('top10Inc1WordTheme-default90', vm.top10Incident1WordThemes, "", translateTag(2159)) //'One Word Theme'            
                        vm.top10Incidents2Word = incidentsAnalyticsService.readTop10Incidents2WordThemes()
                        vm.loadWidgetComponent('top10Inc2Word-default90', vm.top10Incidents2Word, "",translateTag(2161))   //'Two Word Theme'          
                        vm.curPage = 'Top10'
                        $scope.$emit('STOPSPINNER')
                    }, 500);
                })              

            }            

            var config = {
                responsive: true,
                displayModeBar: false
              }

            var config1 = {
            responsive: true,
            displayModeBar: true,
            displaylogo: false,
            modeBarButtonsToRemove: ['toggleSpikelines','hoverClosestCartesian', 'hoverCompareCartesian'],
            }

            vm.layout1 = {
                autosize:true,
                showlegend: true,
                
                legend: {
                    "orientation": "h", 
                        "font":{
                        "family":"Arial", 
                        "size":18
                        },
                        "yanchor":"bottom",
                        "y":-1,
                        "xanchor":"center",
                        automargin:true
                    },
                xaxis: {
                    title: {
                        text: "",
                        font: {
                            family:"Arial",
                            size: 14,
                        },  
                        standoff: 40,
               
                    
                    },
                    showgrid:false,
                    automargin:true
                },
                yaxis: {
                    title: {
                        text: '',
                        font: {
                            family: "Arial",
                            size: 14,
                        },
                    },
                    zeroline: false,
                    automargin:true
                },
                yaxis2: {
                    title: {
                        text: '',
                        font: {
                        family: "Arial",
                        size: 14,
                        },
                    },
                    zeroline: false,
                    overlaying: 'y', 
                    side: 'right',
                    automargin:true,
                    showgrid:false
                }, 
                barmode:'group', 
                margin: {
                    pad: 15
                  },
            };

            vm.layoutNormal = {
                autosize:true,
                showlegend: true,
                
                legend: {"orientation": "h", 
                        "font":{
                        "family":"Arial", 
                        "size":18
                        },
                        "yanchor":"bottom",
                        "y":-1,
                        "xanchor":"center",
                        "x":0.5,
                        automargin:true
                    },
                xaxis: {
                    title: {
                        text: "Hello world",
                        font: {
                            family:"Arial",
                            size: 14,
                        },  
                        standoff: 40,
                        zeroline: false,
                      
                    },
                    showgrid:false,
                    automargin:true
                },
                yaxis: {
                    title: {
                        text: '',
                        font: {
                            family: "Arial",
                            size: 14,
                        },
                    },
                    zeroline: false,
                    automargin:true
                },
                yaxis2: {
                    title: {
                        text: '',
                        font: {
                        family: "Arial",
                        size: 14,
                        },
                    },
                    zeroline: false,
                    overlaying: 'y', 
                    side: 'right',
                    automargin:true,
                    showgrid:false
                }, 
                barmode:'group', 
                automargin:true,
            };

            vm.layoutIncidentsBySiteMonthYear_normal = {
                autosize:true,
                showlegend: true,
                
                legend: {"orientation": "h", 
                        "font":{
                        "family":"Arial", 
                        "size":18
                        },
                        "yanchor":"bottom",
                        "y":-1,
                        "xanchor":"center",
                        "x":0.5,
                        automargin:true
                    },
                xaxis: {
                    title: {
                        text: "Hello world",
                        font: {
                            family:"Arial",
                            size: 14,
                        },  
                        standoff: 40,
                        zeroline: false,
                      
                    },
                    showgrid:false,
                    automargin:true
                },
                yaxis: {
                    title: {
                        text: '',
                        font: {
                            family: "Arial",
                            size: 14,
                        },
                    },
                    zeroline: false,
                    automargin:true
                },
                yaxis2: {
                    title: {
                        text: '',
                        font: {
                        family: "Arial",
                        size: 14,
                        },
                    },
                    zeroline: false,
                    overlaying: 'y', 
                    side: 'right',
                    automargin:true,
                    showgrid:false
                }, 
                barmode:'group', 
                automargin:true,
                hovermode: 'x unified',
                hoverlabel: {
                    xanchor: 'right',
                    orientation: 'h'
                  }
            };

            vm.layoutIncidentsBySiteMonthYear_small = {
                autosize:true,
                showlegend: true,
                legend: {"orientation": "h", 
                        "font":{
                        "family":"Arial", 
                        "size":18
                        },
                        "yanchor":"bottom",
                        "y":-4,
                        "xanchor":"center",
                        "x":0.5,
                        automargin:true
                    },
                xaxis: {
                    title: {
                        text: "",
                        font: {
                            family:"Arial",
                            size: 14,
                        },  
                        standoff: 40
                    },
                    showgrid:false,
                    automargin:true
                },
                yaxis: {
                    title: {
                        text: '',
                        font: {
                            family: "Arial",
                            size: 14,
                        },
                    },
                    zeroline: false,
                    automargin:true
                },
                yaxis2: {
                    title: {
                        text: '',
                        font: {
                        family: "Arial",
                        size: 14,
                        },
                    },
                    zeroline: false,
                    overlaying: 'y', 
                    side: 'right',
                    automargin:true,
                    showgrid:false
                }, 
                barmode:'group', 
                automargin:true,
                hovermode: 'x unified',
                hoverlabel: {
                    xanchor: 'right',
                    orientation: 'h'
                  }
            };


            vm.layoutMultiple = {
                autosize:true,
                showlegend: true,
                legend: {"orientation": "h", 
                        "font":{
                        "family":"Arial", 
                        "size":18
                        },
                        "yanchor":"bottom",
                        "y":-2,
                        "xanchor":"center",
                        "x":0.5,
                         automargin:true
                    },
                xaxis: {
                    title: {
                        
                        font: {
                            family:"Arial",
                            size: 14,
                        },  
                        standoff: 40,
                        zeroline: false,
                      
                    },
                    showgrid:false,
                    automargin:true
                },
                yaxis: {
                    title: {
                        text: '',
                        font: {
                            family: "Arial",
                            size: 14,
                        },
                    },
                    zeroline: false,
                },
                yaxis2: {
                    title: {
                        text: '',
                        font: {
                        family: "Arial",
                        size: 14,
                        },
                    },
                    zeroline: false,
                    overlaying: 'y', 
                    side: 'left',
                    showgrid:false,
                    anchor: 'free',
                    position: 0.02,
                    
                }, 
                yaxis3: {
                    title: {
                        text: '',
                        font: {
                        family: "Arial",
                        size: 14,
                        },
                    },
                    zeroline: false,
                    overlaying: 'y', 
                    side: 'right',
                    automargin:true,
                    showgrid:false
                },
                barmode:'group', 
              
            };


            vm.layoutSmall = {
                autosize:true,
                showlegend: true,
                legend: {"orientation": "h", 
                        "font":{
                        "family":"Arial", 
                        "size":18
                        },
                        "yanchor":"bottom",
                        "y":-4,
                        "xanchor":"center",
                        "x":0.5,
                        automargin:true
                    },
                xaxis: {
                    title: {
                        text: "",
                        font: {
                            family:"Arial",
                            size: 14,
                        },  
                        standoff: 40
                    },
                    showgrid:false,
                    automargin:true
                },
                yaxis: {
                    title: {
                        text: '',
                        font: {
                            family: "Arial",
                            size: 14,
                        },
                    },
                    zeroline: false,
                    automargin:true
                },
                yaxis2: {
                    title: {
                        text: '',
                        font: {
                        family: "Arial",
                        size: 14,
                        },
                    },
                    zeroline: false,
                    overlaying: 'y', 
                    side: 'right',
                    automargin:true,
                    showgrid:false
                }, 
                barmode:'group', 
                automargin:true
            };

     
            if ($(window).width() < 960) {
                vm.layout=vm.layoutSmall
                vm.layoutIncidentsBySiteMonthYear = vm.layoutIncidentsBySiteMonthYear_small
            }
            else {
                vm.layout=vm.layoutNormal
                vm.layoutIncidentsBySiteMonthYear = vm.layoutIncidentsBySiteMonthYear_normal
            }

            function getLayout() {
                if ($(window).width() < 960) {
                    vm.layout=vm.layoutSmall
                    vm.layoutIncidentsBySiteMonthYear = vm.layoutIncidentsBySiteMonthYear_small
                }
                else {
                    vm.layout=vm.layoutNormal
                    vm.layoutIncidentsBySiteMonthYear = vm.layoutIncidentsBySiteMonthYear_normal
                }
            }

            $(window).resize(function() {
                getLayout()
            });

          
    
            vm.getAbsoluteAndAverageIncidentsBySite = (dateRange) => {
                $q.all([
                    incidentsAnalyticsService.getAbsoluteAndAverageIncidentsBySite(dateRange)
                ]).then((response)=>{
                    layout = JSON.parse(JSON.stringify(vm.layout))
                    if (response[0][0].x[0]  == translateTag(3838)){
                        layout.showlegend = false
                    }
                    layout.margin={pad:15}
                    layout.xaxis.title.text = 'Site'
                    layout.yaxis.title.text= 'Average Incidents'
                    layout.yaxis2.title.text= translateTag(3853) //'Incident Count'
                    layout.legend.y=-0.7
                    Plotly.newPlot('get-absolute-incident-count-vs-average-incidents-by-site', response[0], layout,config)
                })
            }

            // Function to plot TRIFR and TRIR for Year to date and past 12 months
            vm.getRecordableIncInjYTD = () => {                
                $q.all([
                    incidentsAnalyticsService.getTRIFRAnalyticsData(),
                ]).then((data)=>{
                    vm.trifr_track_option = data[0].trifr_track_option
                    vm.trir_track_option = data[0].trir_track_option
                    if(!vm.trifr_track_option && !vm.trir_track_option){
                        vm.track_trifr = false
                    }else{
                        vm.track_trifr = true
                    }
                    layout = JSON.parse(JSON.stringify(vm.layout)) 
                    if(data[0].is_empty){
                        layout.showlegend = false
                        layout.xaxis.title.text= translateTag(1133) // Date Range
                        layout.yaxis.title.text= translateTag(2738) // Rate of Recordable injuries
                        layout.yaxis2.title.text= translateTag(2739) // Rate of Recordable incidents
                        Plotly.newPlot('get-recordable-injuries-incidents-year-to-date', data[0].rec_inc_inj_ytd[0], layout,config)
                        Plotly.newPlot('get-recordable-injuries-incidents-past-12-months', data[0].rec_inc_inj_past_12_months[0], layout,config)
                        
                    } else {  
                        layout.xaxis.title.text= translateTag(1133) // Date Range
                        layout.yaxis.title.text= translateTag(2738) // Rate of Recordable injuries
                        layout.yaxis2.title.text= translateTag(2739) // Rate of Recordable incidents
                        Plotly.newPlot('get-recordable-injuries-incidents-year-to-date', data[0].rec_inc_inj_ytd, layout,config)
                        Plotly.newPlot('get-recordable-injuries-incidents-past-12-months', data[0].rec_inc_inj_past_12_months, layout,config)
                    }
                })
            } 
            vm.getRecordableIncInjYTD()

            vm.getIncidentsBySiteMonthYear = (dateRange) => {
                $q.all([
                    incidentsAnalyticsService.getIncidentsBySiteMonthYear(dateRange)
                ]).then((response)=>{ 
                    layout = JSON.parse(JSON.stringify(vm.layoutIncidentsBySiteMonthYear)) 
                    if (response[0][0].x[0]  == translateTag(3838)){
                        
                        layout.showlegend = false
                    }     
                    layout.xaxis.title.text= translateTag(2050)
                    layout.yaxis.title.text= translateTag(3853) //'Incident Count'
                    layout.legend.y= -1.5
                    Plotly.newPlot('get-incident-by-site-month-year-currentyear', response[0], layout,config)
                }).then(()=>{
                    $scope.$emit('STOPSPINNER')
                })
            } 
            
            vm.getIncidenTypeBySiteMonthYear = (dateRange) => {  
                $q.all([
                    incidentsAnalyticsService.getIncidenTypeBySiteMonthYear(dateRange)
                ]).then((response)=>{ 
                    layout = JSON.parse(JSON.stringify(vm.layoutIncidentsBySiteMonthYear))  
                    if (response[0][0].x[0] == translateTag(3838)){
                        layout.showlegend = false
                    }
                    layout.xaxis.title.text= translateTag(2050)
                    layout.yaxis.title.text= translateTag(3853) //'Incident Count'
                    Plotly.newPlot('get-incident-type-by-site-month-and-year-currentyear-single', response[0], layout,config)
                }).then(()=>{
                    $scope.$emit('STOPSPINNER')
                })

            } 

            vm.getIncidentsVsHazardsCountByMonth = (dateRange) => {
                $q.all([
                    incidentsAnalyticsService.getIncidentsVsHazardsCountByMonth(dateRange)
                ]).then((response)=>{   
                                   
                    layout = JSON.parse(JSON.stringify(vm.layoutIncidentsBySiteMonthYear))
                    if (response[0][0].x[0]  == translateTag(3838)){
                        layout.showlegend = false
                    }
                    layout.xaxis.title.text = translateTag(2050)
                    layout.yaxis.title.text= translateTag(3853) //'Incident Count'
                    layout.yaxis2.title.text=translateTag(2128) //'Hazard Count'
                    layout.legend.y=-1.5
                    Plotly.newPlot('get-incidents-vs-hazards-count-by-month', response[0], layout,config)
                })
            }

            vm.getIncidentsVsHazardsCountByDayOfWeek = (dateRange) => {
                $q.all([
                    incidentsAnalyticsService.getIncidentsVsHazardsCountByDayOfWeek(dateRange)
                ]).then((response)=>{                    
                    layout = JSON.parse(JSON.stringify(vm.layout))
                    if (response[0][0].x[0]  == translateTag(3838)){
                        layout.showlegend = false
                    }
                    layout.xaxis.title.text = translateTag(2055) //"Week"
                    layout.yaxis.title.text= translateTag(3853) //'Incident Count'
                    layout.yaxis2.title.text= translateTag(2128) //'Hazard Count'
                    layout.legend.y=-1.5
                    Plotly.newPlot('get-incidents-vs-hazards-count-day-of-week', response[0], layout,config)
                })
            }

            vm.getAverageIncidentsByGeneration = (dateRange) => {
                $q.all([
                    incidentsAnalyticsService.getAverageIncidentsByGeneration(dateRange)
                ]).then((response)=>{      
                    layout = JSON.parse(JSON.stringify(vm.layout))      
                    Plotly.newPlot('get-average-incidents-by-generation', response[0],layout,config)
                })
            }

            vm.getIncidentCountByMonthAndYear = (dateRange) => {  
                $q.all([
                    incidentsAnalyticsService.getIncidentCountByMonthAndYear({"year":dateRange})
                ]).then((response)=>{
                    layout = JSON.parse(JSON.stringify(vm.layout)) 
                    if (response[0][0].x[0] == translateTag(3838)){
                        layout.showlegend = false
                    } 
                    layout.yaxis.title.text= translateTag(3853) //'Incident Count'
                    layout.xaxis.title.text = translateTag(2050)
                    Plotly.newPlot('get-incident-count-by-month-and-year-currentyear', response[0], layout, config)
                })
            }

            vm.getIncidentAndHazardCountsVsSubmissionCompliance = (dateRange) => {  
                $q.all([
                    incidentsAnalyticsService.getIncidentAndHazardCountsVsSubmissionCompliance(dateRange)
                ]).then((response)=>{ 
                    layout = JSON.parse(JSON.stringify(vm.layoutMultiple)) 
                
                    if (response[0][0].x[0] == translateTag(3838)){
                        layout.showlegend = false
                    } 
                    layout.automargin=false
                    layout.margin = {pad:50, l:100}
                    layout.xaxis.type = "category"

                   
                    layout.yaxis.title.text= translateTag(3853) //'Incident Count'  
                    layout.yaxis2.title.text= translateTag(2128) // 'Hazard Count'
                    layout.yaxis3.title.text = translateTag(8651) //'Submission Compliance'                  
                    layout.xaxis.title.text = translateTag(1133) // Date Range
                    Plotly.newPlot('get-incident-and-hazard-counts-vs-submission-compliance-default90', response[0], layout, config)
                })
            }

            vm.getAverageTrainingCompletedVsAverageIncidentsByPosition = (dateRange) => {
                $q.all([
                    incidentsAnalyticsService.getAverageTrainingCompletedVsAverageIncidentsByPosition(dateRange)
                ]).then((response)=>{                 
                    layout = JSON.parse(JSON.stringify(vm.layout))
                   
                    if (response[0][0].x[0]  == translateTag(3838)){
                        layout.showlegend = false
                    }
                    layout.xaxis.title.text = "Position"
                    layout.yaxis.title.text= 'Average Trainings'
                    layout.yaxis2.title.text='Average Incidents'
                    layout.legend.y=1
                    layout.margin={pad:5}
                    Plotly.newPlot('get-average-training-completed-vs-average-incidents-by-position', response[0], layout, config)
                })
            }

            vm.getAverageNumberOfValidTrainingsCompletedBySite = (dateRange) => {
                $q.all([
                    incidentsAnalyticsService.getAverageNumberOfValidTrainingsCompletedBySite(dateRange)
                ]).then((response)=>{                    
                    layout = JSON.parse(JSON.stringify(vm.layout))
                    if (response[0][0].x[0] == translateTag(3838)){
                        layout.showlegend = false
                    }
                    layout.xaxis.title.text = "Site"
                    layout.yaxis.title.text= 'Average Trainings'
                    layout.yaxis2.title.text='Average Incidents'
                    layout.margin={pad:5}
                    layout.legend.y=-2
                    Plotly.newPlot('get-average-trainings-completed-vs-average-incidents-by-site', response[0], layout,config)
                })
            }

            

            vm.filterCharts = (mode='graphs') => {
                filterObject.Jobs = vm.jobIdArray
                filterObject.Supervisors = vm.supervisorsArray
                filterObject.toggles = vm.toggles
                let startDate = vm.mainDateFilter.start_date
                let endDate = vm.mainDateFilter.end_date

                if (startDate)
                    filterObject.StartDate = startDate
                    filterObject.start_date = startDate //sarath
                if (endDate)
                    filterObject.EndDate = endDate
                    filterObject.end_date = endDate //sarath
                refreshFilters(filterObject, mode)
                dateRange={
                    "start_date": filterObject.StartDate,
                    "end_date": filterObject.EndDate,             
                }
                $scope.dateRange = dateRange
            }

            vm.showHelp = (id) => {
                $('.modal .scroll').scrollTop(0)
                modalService.Open(id)
            }

            let infoObjects = {
                incSiteMonthYear: {
                    title: translateTag(8646), // Incidents By Site, Month and Year
                    toolTip: translateTag(8767), // This graph shows the number of incidents per month at the selected sites for the desired year. Each bar in the chart represents a site.
                    list: [
                        {
                            label: translateTag(3853), // Incident Count
                            description: translateTag(8768) // The number of incidents at each site per month for the selected year at a specific site
                        },
                        {
                            label: translateTag(2050), // Month
                            description: translateTag(8769) // Month of the year grouping the incident count
                        },
                    ]
                },
                incTypeSiteMonthYear: {
                    title: translateTag(8648), // Incident Type By Site, Month and Year
                    toolTip: translateTag(8770), // This graph shows the number of incidents per month at the selected site for the desired year. Each bar in the chart represents an incident type.
                    list: [
                        {
                            label: translateTag(3853), // Incident Count
                            description: translateTag(8771) // The number of incidents by type per month for the selected year and site
                        },
                        {
                            label: translateTag(2050), // Month
                            description: translateTag(8769) // Month of the year grouping the incident count
                        },
                    ]
                },            
                incCountMonthYear: {
                    title: translateTag(8649), // Incident Count by Month and Year
                    toolTip: translateTag(8773), // This graph outlines the number of incidents submitted company wide each month for one or more years as selected. Each line in the chart represents one year.
                    list: [
                        {
                            label: translateTag(3853), // Incident Count
                            description: translateTag(8774) // Number of incidents submitted each month
                        },
                        {
                            label: translateTag(2050), // Month
                            description: translateTag(8769) // Month of the year grouping the incident count
                        },
                    ]
                },
                incHazardCount: {
                    title: translateTag(8650), // Incident and Hazard Counts vs. Submission Count
                    toolTip: translateTag(8775), // The graph compares the number of incident and hazard submissions with the number of total submissions per month for a given period of time.
                    list: [
                        {
                            label: translateTag(1133), // Date Range 
                            description: translateTag(8776) // The time period selected by the user
                        },
                        {
                            label: translateTag(3853), // Incident Count
                            description: translateTag(8777) // The total number of monthly incident submissions
                        },
                        {
                            label: translateTag(2128), // Hazard Count
                            description: translateTag(8778) // The total number of monthly hazard submissions
                        },
                        {
                            label: translateTag(8651), // Submission Compliance
                            description: translateTag(8779) // The total number of submissions company wide
                        }
                    ]
                },
                incHazardCountMonth: {
                    title: translateTag(8652), // Incidents vs Hazards Count by Month
                    toolTip: translateTag(8780), // This chart displays the number of incidents and hazards submitted each month for the time period selected. The chart may help identify periodic highs and lows in the number of monthly incident and hazard submissions.
                    list: [
                        {
                            label: translateTag(3853), // Incident Count
                            description: translateTag(8781) // Total number of incidents submitted within a specific month for the time period selected
                        },
                        {
                            label: translateTag(2128), // Hazard Count
                            description: translateTag(8782) // Total number of hazards submitted within a specific month for the time period selected
                        },
                        {
                            label: translateTag(2050), // Month
                            description: translateTag(8783) // Month of the year grouping the incident and hazard submission count
                        }
                    ]
                },
                incHazardCountWeek: {
                    title: translateTag(8654), // Incidents vs Hazards Count by Day of Week
                    toolTip: translateTag(8784), // This chart displays the number of incidents and hazards submitted each day for the time period selected. The chart may help identify periodic highs and lows in the number incident and hazard submissions within the days of the week.
                    list: [
                        {
                            label: translateTag(3853), // Incident Count
                            description: translateTag(8781) // Total number of incidents submitted within a specific month for the time period selected
                        },
                        {
                            label: translateTag(2128), // Hazard Count
                            description: translateTag(8782) // Total number of hazards submitted within a specific month for the time period selected
                        },
                        {
                            label: translateTag(2055), // Week
                            description: translateTag(8850) // Days of the week
                        },
                    ]
                },
                incByGeneration: {
                    title: translateTag(8653), // Percentage of Incidents by Generation
                    toolTip: translateTag(8785), // The chart looks at the age of the individuals mapped to an incident and displays the percentage of individuals in each age group
                    list: [
                        {
                            label: translateTag(3837), // By Generation
                            description: translateTag(8786) // Segment of individuals that belong to a certain generation group (Boomer, GenX, Millenial, GenZ)
                        }
                    ]
                },
                incTop10TypesCategories: {
                    title: translateTag(8655), // Top 10 Incidents Types and Categories
                    toolTip: translateTag(8787), // The list compares the data from the current time span selected with the data from the same period of time that preceded it. The list looks at the combination of incident types and categories and displays the most used combination. The trend shows the change in item position in the hierarchy between the current and previous time span.
                    list: [
                        {
                            label: "#", // #
                            description: translateTag(8761) // Order of items with the highest count at 1 and lowest count at 10
                        },
                        {
                            label: translateTag(8851), // Type - Category
                            description: translateTag(8788) // Combination of incident type and category values selected by the user in the preliminary incident form
                        },
                        {
                            label: translateTag(2157), // Trend
                            description: translateTag(8763) // The difference in position of item in current time period compared to previous time period
                        },
                        {
                            label: translateTag(3721), // Sentiment
                            description: translateTag(8764) // These values range from -1 to 1. If the value is negative the text is negative (ex. Worst day ever) and if the value is positive the text is outlining a positive sentiment (ex. Excellent effort everyone!).
                        },
                    ]
                },
                incTop10OneWord: {
                    title: translateTag(3684), // Top 10 One Word Themes
                    toolTip: translateTag(8854), // The list compares the data from the current time span selected with the data from the same period of time that preceded it. The word within the Incident Descriptions field with the highest count is displayed at the top of the list. The trend shows the change in item position in the hierarchy between the current and previous time span.
                    list: [
                        {
                            label: "#", // #
                            description: translateTag(8761) // Order of items with the highest count at 1 and lowest count at 10
                        },
                        {
                            label: translateTag(2159), // One Word Theme
                            description: translateTag(8789) // A single word that is commonly used in the Incident Description field
                        },
                        {
                            label: translateTag(2157), // Trend
                            description: translateTag(8763) // The difference in position of item in current time period compared to previous time period
                        },
                        {
                            label: translateTag(3721), // Sentiment
                            description: translateTag(8764) // These values range from -1 to 1. If the value is negative the text is negative (ex. Worst day ever) and if the value is positive the text is outlining a positive sentiment (ex. Excellent effort everyone!).
                        },
                    ]
                },
                incTop10TwoWord: {
                    title: translateTag(3685), // Top 10 Two Word Themes
                    toolTip: translateTag(8855), // The list compares the data from the current time span selected with the data from the same period of time that preceded it. The pair of words within the Incident Descriptions field with the highest count is displayed at the top of the list. The trend shows the change in item position in the hierarchy between the current and previous time span.
                    list: [
                        {
                            label: "#", // #
                            description: translateTag(8761) // Order of items with the highest count at 1 and lowest count at 10
                        },
                        {
                            label: translateTag(2161), // Two Word Theme
                            description: translateTag(8853) // A pair of words that is commonly used in the Incident Description field
                        },
                        {
                            label: translateTag(2157), // Trend
                            description: translateTag(8763) // The difference in position of item in current time period compared to previous time period
                        },
                        {
                            label: translateTag(3721), // Sentiment
                            description: translateTag(8764) // These values range from -1 to 1. If the value is negative the text is negative (ex. Worst day ever) and if the value is positive the text is outlining a positive sentiment (ex. Excellent effort everyone!).
                        },
                    ]
                }
            }

            vm.openInfoModal = (infoObject) => {
                vm.currentInfo = infoObjects[infoObject]
                modalService.Open('infoModalComponent')
            }

            $('#siteselection').mouseover(function() { 
                $(this).attr('title', vm.toolTipSites)
            })
           
            vm.getSiteSelectedTooltip = () =>{
                vm.toolTipSites = ''
                vm.siteList.forEach((rec) => {
                    if(vm.defaultselectedSites.indexOf(rec.rld_id) > -1){
                        vm.toolTipSites += rec.rld_name + '; '
                    }
                   
                })   
            }

        }])