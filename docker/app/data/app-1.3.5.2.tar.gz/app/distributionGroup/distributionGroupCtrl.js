﻿angular
    .module('safeToDo')
    .controller('distributionGroupCtrl', ['$compile','$sce', '$scope', '$rootScope', '$routeParams', '$window', '$timeout', 'formsService', 'signoffService', 'gridService', 'modalService', 'employeesService', 'profileService', 'menuService',
    function ($compile, $sce, $scope, $rootScope, $routeParams, $window, $timeout, formsService, signoffService, gridService, modalService, employeesService, profileService, menuService) {
            var vm = this
            vm.groupsSelected = []            
            // console.log("ctrl was called")
            profileService.getDistributionList()
            distributionList = profileService.readDistributionList()
            distributionGroupList = profileService.readdistributionGroupList()   
            $scope.$on('addDistributionGroup', (event ,args, distribution) => {

                let items = args.params.data.id.split(",")
                let findMe = args.params.data.id.replace("string:","")
                let idx = 0
                // Find the email list including teh comma in the distribution list.
                for(let i=0;i<distribution.length; i++){
                    if(distribution[i] == findMe){
                        idx = i
                    }
                }
                // console.log(args, i)
                // Remove the email string from the distribution list.
                distElementId = '#' + args.currentTarget.id

                if(items.length > 1){
                    distribution.splice(idx,1)
    
                    // Add them back in as individual emails if they dont already exist.
                    for(let i = 0 ; i < items.length; i++){
                        items[i] = items[i].replace("string:","")
                        if(!distribution.includes(items[i])){
                            distribution.push(items[i])
                        }
                    }      

                    disitems = items.concat($(distElementId).val())
                    newdisitems = []

                    // console.log("disitems (Ctrl calling): ", disitems)
                    for (let i in disitems){
                        if (disitems[i].includes(',')) {
                            currentGroup = distributionGroupList.filter(function (group) {
                                return group.email == disitems[i].replace("string:", "");
                            });
                            vm.groupsSelected.push(currentGroup)
    
                            // remove the currentGroup name from select list.
                            $(args.params.data.element).detach();
                            $(distElementId).trigger("change");
    
                        } else {
                            if (disitems[i].includes('string:')){
                                newdisitems.push(disitems[i])
                                continue
                            }
                            newdisitems.push("string:" + disitems[i])
                        }
                    }
                    if (newdisitems) {
                        $(distElementId).val(newdisitems).trigger('change').parent().find('label').addClass('filled')
                    }
                } else { 
                    // console.log(args)
                    AddOrRemoveIndividualFromList(args)
                }
                
            })        

            $scope.$on('removeDistributionGroup', (event, args) => {
                // console.log("was removed...")
                AddOrRemoveIndividualFromList(args)
            })

            function AddOrRemoveIndividualFromList(args){

                // Step1: compare all selected emails in the select list with the 
                // distribution groups.
                // Get a list of selected emils from the select list.
                let selectedEmails = []
                let distElementId = ''
                if(args){
                    distElementId = '#' + args.currentTarget.id
                    
                }
                

                selectedEmails = $(distElementId).select2('data');
                
                // step2: if the emails in the list are all contained in a distribution group then
                // remove the group from the select list.
    
                // Clean selected emails.
                for (let i in selectedEmails) {
                    selectedEmails[i] = selectedEmails[i]["id"].replace('string:', '')
                }   
                // loop through the groups list.
                for(let l=0;l<distributionGroupList.length;l++){
                    let group = distributionGroupList[l].email.split(",")
                    group.pop()
                    let groupName = distributionGroupList[l].name
                     // loop through the selected emails list in the group loop and 
                    // find the emails.
                    // console.log("distributionGroupCtrl.js...")
                    let found = group.every(val => selectedEmails.includes(val));

                    if(found){
                        // remove the group from the list.
                        $(distElementId + " option[label='" + groupName + "']").remove();
                    } else {
                        
                        // add the group back.
                        let opt = new Option(groupName,distributionGroupList[l].email)
                            
                        // only add the group name back if it is not already added.
                        let found2 = false
                        let opts = $(distElementId).find("option")
                        for(let c=0;c<opts.length;c++){
                            if(opts[c].text == distributionGroupList[l].name){
                                found2 = true
                            }
                        }
                        if(!found2){
                            $(distElementId).append(opt).change();
                        }
                    }
                
                }
            }    
    }
])