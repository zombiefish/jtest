angular
    .module('safeToDo')
    .controller('printCtrl', ['bowtieService','adminTrainingService', '$routeParams',
        function (bowtieService, adminTrainingService, $routeParams) {
            var vm = this;
            if($routeParams.report_title === 'bowtie'){
                if($routeParams.id){
                    bowtieService.getBowtieHtml($routeParams.id).then((response) => {      
                        // var win = window.open("about:blank", "_self");  
                        // win.document.write(response)
                        // win.focus();                     
                        $("#showHTML").append(response)
                    })
                } 
            }
            else if($routeParams.report_title === 'training_matrix'){
                payload = JSON.parse($routeParams.id)
                adminTrainingService.generateTrainingMatrixReport(payload).then((response) => {
                    if(response.status == 200){
                        $("#showHTML").append(response.data)                                      
                    }
                })
            }
            else{
                console.log(' end')
            }           

            vm.print = () => {
                var contents = document.getElementById('showHTML').innerHTML;
                var frame1 = document.createElement('iframe');
                frame1.name = "frame1";
                frame1.style.position = "absolute";
                frame1.style.top = "-1000000px";
                document.body.appendChild(frame1);
                var frameDoc = frame1.contentWindow ? frame1.contentWindow : frame1.contentDocument.document ? frame1.contentDocument.document : frame1.contentDocument;
                frameDoc.document.open();
                // frameDoc.document.write(`<html><head><title>ss</title>`);
                // frameDoc.document.write('</head><body>');
                frameDoc.document.write(contents);
                // frameDoc.document.write('</body></html>');
                frameDoc.document.close();
                setTimeout(function () {
                    console.log(' check here')
                    window.frames["frame1"].focus();
                    window.frames["frame1"].print();
                    document.body.removeChild(frame1);
                }, 500);
                return false;
            }            

            
    }
])