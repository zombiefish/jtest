﻿angular
    .module('safeToDo')
    .controller('SitesCtrl', ['$scope', '$compile', '$rootScope', '$timeout', '$q', '$location', '$window','$location', 'listService', 'profileService',  'sitesService', 'gridService', 'modalService', '$controller', 'complianceService', 'formsService',
        function ($scope, $compile, $rootScope, $timeout, $q, $location, $window,$location, listService, profileService, sitesService, gridService, modalService, $controller, complianceService, formsService) {
            let vm = this                       
            
            vm.targets = []
            vm.supervisors = []
            vm.frequencies = []
            vm.forms = []
            vm.hazards = []
            vm.jobIdArray = []
            vm.hazardCount = 0
            vm.actionCount = 0
            vm.potentialRiskCount = 0
            vm.actionTrendScore = 0
            vm.actionTrendAverage = 0
            vm.potentialRiskTrendScore = 0
            vm.potentialRiskTrendAverage = 0
            vm.hazardTrendScore = 0
            vm.hazardTrendAverage = 0  
            vm.curPage = "General" 
            vm.loadGraphsFilter = ""
            vm.loadTop10Filter = ""
            vm.loadGeneralFilter = {
                start_date: moment().subtract(90, 'days').format('YYYY-MM-DD'),
                end_date: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD')
            }
        
            vm.monthNamesLong = [{name:'January', short: 'Jan', number: '01'},
            {name: 'February', short: 'Feb', number: '02'} ,
            {name:'March', short: 'Mar', number:'03'} , 
            {name:'April', short: 'Apr', number:'04'}, 
            {name:'May', short: 'May', number:'05'}, 
            {name:'June', short: 'June', number:'06'}, 
            {name:'July', short: 'July', number:'07'}, 
            {name:'August', short: 'Aug', number:'08'}, 
            {name:'September', short: 'Sept', number:'09'}, 
            {name:'October', short: 'Oct', number:'10'}, 
            {name:'November', short: 'Nov', number:'11'}, 
            {name:'December', short: 'Dec', number:'12'}]
            vm.monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
            vm.years = [2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030]
            vm.options = gridService.getCommonOptions()
            vm.loadMessage = translateTag(3850) // "Loading hazard management page. Please wait."

            vm.currentInfo = {}

            vm.toggles = {
                by_frequency: true,
                by_score: false,
                by_type: true,
                by_form: false
            }

            let filterObject = {
                Jobs:[]
            }

            // this boolean variable restricts the vm.filterCharts function to load once on page load. 
            vm.loadedFlag = false


            function getMonthFromString(mon) {
                return new Date(Date.parse(mon + " 1, 2017")).getMonth() + 1;
            }
          
            // on Date change
            $scope.$on('DATERANGE', (range) => {                
                if($location.url() === '/a/sites'){
                    vm.mainDateFilter = {
                        start_date: `${moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD')} 00:00:00.000`,
                        end_date: `${moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')} 23:59:59.000`
                    }
                    $window.sessionStorage.setItem('start_month', moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('MM'))
                    $window.sessionStorage.setItem('start_year', moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY'))
                    $window.sessionStorage.setItem('end_month', moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('MM'))
                    $window.sessionStorage.setItem('end_year', moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY'))
                    $window.sessionStorage.setItem('start_date', `${moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD')} 00:00:00.000`)
                    $window.sessionStorage.setItem('end_date', `${moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')} 23:59:59.000`)
                    
                    if(vm.loadedFlag)
                        vm.filterCharts('start')
                    vm.loadedFlag = true
                    if (vm.curPage == "General"){
                        vm.loadGeneralFilter = vm.mainDateFilter
                    }
                    else if (vm.curPage == "Top10"){
                        vm.loadTop10Filter = vm.mainDateFilter
                    }
                    else if (vm.curPage == "Graphs"){
                        vm.loadGraphsFilter = vm.mainDateFilter
                    }
                }
            })

            // on Filters change 
            $scope.$on('job-filter-changed', (event, args) => {
                if($location.url() === '/a/sites'){
                    $scope.$emit('STARTSPINNER', vm.loadMessage)
                    vm.jobIdArray = args.jobIds
                    vm.supervisorsArray = args.supervisors
                    var path = $location.path();
                    if(vm.loadedFlag)
                        vm.filterCharts('start')
                    vm.loadedFlag = true
                }                 
            })

            var currentDate = new Date();
            let dateToday = moment(new Date(), 'YYYY-MM-DD')
            function getMonthName(month, type='long'){
                let theMonth = ''
               vm.monthNamesLong.forEach((mth)=>{
                   if(mth.number === month) {
                    theMonth =  type === 'long'? mth.name : nth.short
                   }
                })
                return theMonth
            }

            vm.dateFilter = {
                start_month: $window.sessionStorage.getItem("start_month") ? $window.sessionStorage.getItem("start_month") : dateToday.format("MM"),
                start_year: $window.sessionStorage.getItem("start_year") ? Number($window.sessionStorage.getItem("start_year")) : currentDate.getFullYear(),
                end_month: $window.sessionStorage.getItem("end_month") ? $window.sessionStorage.getItem("end_month") : dateToday.format("MM"),
                end_year: $window.sessionStorage.getItem("end_year") ? Number($window.sessionStorage.getItem("end_year")) : currentDate.getFullYear(),
                getFormattedRange: () => {
                    var start = getMonthName(vm.dateFilter.start_month) + " " + this.start_year
                    var end = getMonthName(vm.dateFilter.end_month) + " " + this.end_year
                    if (start == end) {
                        return start
                    }

                    return start + " - " + end;
                },
                validate: () => {
                    if (this.start_year > this.end_year) {
                        return false
                    }
                    if (this.start_year == this.end_year) {
                        if (getMonthFromString(this.start_month) > getMonthFromString(this.end_month)) {
                            return false
                        }
                    }

                    return true;
                }
            }

            vm.hazardData = sitesService.readHazardData()            
            vm.actionData = sitesService.readActionData()
            vm.potentialRiskData = sitesService.readPotentialRiskData()
            vm.hazardTrendData = sitesService.readHazardTrendData()
            vm.potentialRiskTrendData = sitesService.readPotentialRiskTrendData()
            vm.actionTrendData = sitesService.readActionTrendData()

            vm.topSearch = ""

            vm.hideDropdowns = () => {
                $('.filter-dropdown').removeClass('show')
            }

            function validateFilter(filter){
                if(!filter.Jobs)
                    filter.Jobs = [999999999]
                if(!filter.Supervisors)
                    filter.Supervisors = [999999999]                    
            }

            function checkForFilterChange(currentPageFilter, curPage) {
                if (vm.curPage != curPage){
                    vm.curPage = curPage

                    if (currentPageFilter['start_date'] == vm.mainDateFilter["start_date"] && currentPageFilter["end_date"] == vm.mainDateFilter["end_date"]) {
                    }
                    else {
                        vm.filterCharts()
                        return vm.mainDateFilter
                    }
                }
                return currentPageFilter
            }

            vm.loadTop10 = () => {
                vm.loadTop10Filter = checkForFilterChange(vm.loadTop10Filter, "Top10")               
            }

            vm.loadGraphs = () => {
                vm.loadGraphsFilter = checkForFilterChange(vm.loadGraphsFilter, "Graphs")
            }

            vm.loadGeneral = () => {
                vm.loadGeneralFilter = checkForFilterChange(vm.loadGeneralFilter, "General")
            }


            // refresh Filters after filterCharts changed
            function refreshFilters(filterObject, mode) {
                $scope.$emit('STARTSPINNER', vm.loadMessage)
                let hapFilter = {
                    start_date : filterObject.StartDate,
                    end_date : filterObject.EndDate,
                    users : filterObject.Supervisors,
                    jobs : filterObject.Jobs,
                    values : [],
                    mode: "",
                    toggle : filterObject.toggles
                }
                $window.sessionStorage.setItem('siteFilter', JSON.stringify(hapFilter))
                $window.sessionStorage.setItem('siteBackFilter', JSON.stringify(hapFilter))
                filterObject.users = filterObject.users ? filterObject.users:[99999999]
                filterObject.Jobs = filterObject.Jobs ? filterObject.Jobs:[999999]
                filterObject.Supervisors = filterObject.Supervisors ? filterObject.Supervisors:[999999]
                if(filterObject.Jobs.length == 0) {
                     filterObject.Jobs = [999999]
                }
                if(filterObject.Supervisors.length == 0) {
                    filterObject.Supervisors = [999999]
               }
                if(filterObject.Jobs.length > 0 && filterObject.Supervisors.length > 0)

                {
                validateFilter(filterObject)
                services = []
                if (vm.curPage === "Top10") {                    
                    services = [sitesService.getTop10HazardIdentifications(filterObject),
                        sitesService.getTop10OneWordHazard(filterObject),
                        sitesService.getTop10TwoWordHazard(filterObject),
                        sitesService.getTop10Supervisors(filterObject),
                        sitesService.getTop10ActionTakenWord(filterObject)]
                }
                else if (vm.curPage === "General") {
                    services = [
                    listService.getFrequenciesP(),
                    profileService.getAllEmployeeProfile(),
                    formsService.getTopFormDescriptionsP(),
                    sitesService.getHazardsFP(filterObject),
                    sitesService.getPotentialRisksFP(filterObject),
                    sitesService.getActionsFP(filterObject),
                    sitesService.gethazardTrendFP(filterObject),
                    sitesService.getPotentialRiskTrendFP(filterObject),
                    sitesService.getActionTrendFP(filterObject),
                    sitesService.getHazardsCountFP(filterObject),
                    sitesService.getPotentialRisksCountFP(filterObject),
                    sitesService.getActionsFPCount(filterObject),
                    complianceService.getComplianceByForm(filterObject)
                    ]
                }
                    $q.all(services).then(() => {
                            var forms = formsService.getTopFormDescriptions();
                            vm.forms.length = 0;
                            for (var i = 0; i < forms.A.length; i++) {
                                vm.forms.push(forms.A[i]);
                            }
                        let supervisors = profileService.readAllEmployeeProfile()
                            vm.supervisors.length = 0;
                            // for (var i = 0; i < supervisors.A.length; i++) {
                            //     vm.supervisors.push(supervisors.A[i]);
                            // } - Edited by Sarath
                            for (var i = 0; i < supervisors.length; i++) {
                                vm.supervisors.push(supervisors[i]);
                            }
                        let frequencies = listService.getFrequencies();
                            vm.frequencies.length = 0;
                            // for (var i = 0; i < frequencies.A.length; i++) {
                            //     vm.frequencies.push(frequencies.A[i]);
                            // } - Edited by Sarath
                            for (var i = 0; i < frequencies.length; i++) {
                                vm.frequencies.push(frequencies[i]);
                            }

                            if (vm.curPage == "General") {
                                vm.hazardData = sitesService.readHazardData()
                                vm.hazardCount = sitesService.readHazardCount()
                                vm.potentialRiskData = sitesService.readPotentialRiskData()
                                vm.potentialRiskCount = sitesService.readPotentialRiskCount()
                                vm.actionData = sitesService.readActionData()
                                vm.actionCount = sitesService.readActionCount()
                                vm.hazardTrendData = sitesService.readHazardTrendData()
                                vm.potentialRiskTrendData = sitesService.readPotentialRiskTrendData()
                                vm.actionTrendData = sitesService.readActionTrendData()
                                vm.actionTrendScore = sitesService.readActionTrendScore()
                                vm.hazardTrendScore = sitesService.readHazardTrendScore()
                                vm.potentialRiskTrendScore = sitesService.readPotentialRiskTrendScore()
                                let actionsCountFinal = sitesService.readActionsCountFinal()
                                let potentialRisksCountFinal = sitesService.readPotentialRisksCountFinal()
                                let hazardsCountFinal = sitesService.readHazardsCountFinal()
                                vm.actionTrendAverage = actionsCountFinal == 0 ? 0 : (vm.actionTrendScore / parseFloat(actionsCountFinal)).toFixed(1)
                                vm.potentialRiskTrendAverage = potentialRisksCountFinal == 0 ? 0 : (vm.potentialRiskTrendScore / parseFloat(potentialRisksCountFinal)).toFixed(1)
                                vm.hazardTrendAverage = hazardsCountFinal == 0 ? 0 : (vm.hazardTrendScore / parseFloat(hazardsCountFinal)).toFixed(1)                                
                                $scope.$emit('HAPDATERANGE', filterObject)
                                $scope.$emit('STOPSPINNER')
                            }
                            else if (vm.curPage == "Graphs") {
                                dateRange={
                                    "start_date": filterObject.StartDate,
                                    "end_date": filterObject.EndDate,
                                }
                                vm.getHapByTypeAndYearFunction(dateRange)
                                vm.getHapByMonthAndYearFunction(dateRange)
                                vm.getHapAvgCompletionTimeFunction(dateRange)
                                $scope.$emit('STOPSPINNER')
                            } else if (vm.curPage == "Top10") {
                                vm.top10HazardIdentificationsData = sitesService.readTop10HazardIdentifications()
                                vm.top10OneWordHazardData = sitesService.readTop10OneWordHazard()
                                vm.top10TwoWordHazardData = sitesService.readTop10TwoWordHazard()
                                vm.top10SupervisorsData = sitesService.readTop10Supervisors()
                                vm.top10ActionTakenWordData = sitesService.readTop10ActionTakenWord()

                                vm.loadWidgetComponent('top10HazardIdentifications', vm.top10HazardIdentificationsData, translateTag(2156), translateTag(510), "siteTop10HapId")
                                vm.loadWidgetComponent('top10OneWordHazard', vm.top10OneWordHazardData, translateTag(2158), translateTag(2159), "siteTop10HapOneWord")
                                vm.loadWidgetComponent('top10TwoWordHazard', vm.top10TwoWordHazardData, translateTag(2160), translateTag(2161), "siteTop10HapTwoWord")
                                vm.loadWidgetComponent('top10Supervisors', vm.top10SupervisorsData, translateTag(2162), translateTag(3556), "siteTop10HapSupervisors")
                                vm.loadWidgetComponent('top10ActionTaken', vm.top10ActionTakenWordData, translateTag(2163), translateTag(2159), "siteTop10HapActionTaken")
                                $scope.$emit('STOPSPINNER')
                            }
                        })
                    }
                else {
                    if(mode != 'start'){
                        $scope.$emit('STOPSPINNER')
                        toastr.error(translateTag(8626))
                    }
                }
            }

            vm.months = []
            for(let i in vm.monthNamesLong){
                vm.months.push(vm.monthNamesLong[i].name)
            }

            vm.loadWidgetComponent = (divId, data, title, subTitle, infoData) => {
                let widgetData = []
                data.forEach((item) => {
                    if(item.keyword=="No Data To Show"){
                        item.keyword=translateTag(3838)
                    }
                    else if(item.keyword=="N/A"){
                        item.keyword=translateTag(1381)
                    }
                    widgetData.push({id:item.id, keyword: item.keyword.toString().replaceAll("'","&#39"), trend:item.trend})
                })
                vm.newdata = JSON.stringify(widgetData)
                vm.newdata = vm.newdata.replaceAll("'", "|quote|") // To qualify the single quotes
                $('#'+divId).html($compile(`  
                    <top-ten-widget-form data='${vm.newdata}' title='${title.toString().replaceAll("'","&#39")}' sub-title='${subTitle.toString().replaceAll("'","&#39")}' info-data='${infoData}'></top-ten-widget-form>
                `)($scope))
            }


            vm.layout = {
                showlegend: true,
                legend: {"orientation": "h", 
                       "font":{
                         "family":"Arial", 
                         "size":18
                       },
                       "yanchor":"bottom",
                       "y":-1,
                       "xanchor":"center",
                       "x":0.5
                      },
                xaxis: {
                    title: {
                        text: "Hazard Type",
                        font: {
                            family:"Arial",
                        size: 14,
                        color: "Black"
                        },                          
                    },
                zeroline: false,
                showgrid:false
                },
                yaxis: {title: translateTag(2128),zeroline: false}, 
                barmode:'group'
            }
            var config = {displaylogo: false,responsive: true, locale: selectedLanguage}

            vm.dateRange={
                "start_date": filterObject.StartDate,
                "end_date": filterObject.EndDate,             
            }

            vm.getHapByTypeAndYearFunction = (dateRange) => {
                $q.all([
                    sitesService.getHapByTypeAndYear(dateRange)
                ]).then((response)=>{
                    layout = JSON.parse(JSON.stringify(vm.layout)) 
                    if (response[0][0].x[0] == 'No Data to Show'){
                        layout.showlegend = false
                    }
                    
                    layout.xaxis.title.text = translateTag(514)
                    layout.yaxis.title = translateTag(2128)


                    Plotly.newPlot('get-hap-by-type-and-year', response[0],layout,config)
                })
            }

            vm.getHapByMonthAndYearFunction = (dateRange) => {  
                $q.all([
                    sitesService.getHapByMonthAndYear(dateRange)
                ]).then((response)=>{ 
                    layout = JSON.parse(JSON.stringify(vm.layout)) 
                    if (response[0][0].x[0] == 'No Data to Show'){
                        layout.showlegend = false
                    } 
                    layout.xaxis.title.text = translateTag(2050)
                    layout.yaxis.title = translateTag(2128)
                    Plotly.newPlot('get-hap-by-month-and-year', response[0], layout,config)
                })
            }

             vm.getHapAvgCompletionTimeFunction = (dateRange) => {  
                $q.all([
                    sitesService.getHapAvgCompletionTime(dateRange)
                ]).then((response)=>{
                    layout = JSON.parse(JSON.stringify(vm.layout)) 
                    if (response[0][0].x[0] == 'No Data to Show'){
                        layout.showlegend = false
                    }
                    layout.xaxis.title.text = translateTag(2155)
                    layout.yaxis.title = translateTag(2128)
                    Plotly.newPlot('get-hap-average_completion_time', response[0], layout,config)
                })
            }

            var sitesCols = [
                {
                    field: "site",
                    headerName: "",
                    minWidth: 50,
                    maxWidth: 200,
                    suppressRowClickSelection: true,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab']
                }
            ]

            $scope.$on("$destroy", () => {
                $(window).off('resize')
                $(window).off('click')
                $('.sites').off('resize')
            })

            $(window).click((e) => {
                $('.filter-dropdown').removeClass('show')
            })

            $('.sites').scroll((e) => {
                $('.filter-dropdown').removeClass('show')
            })

            function handleChartClick(seriesName, queryParamName, otherlist) {
                let oList = []
                let filter_payload = {
                    start_date: vm.mainDateFilter.start_date,
                    end_date: vm.mainDateFilter.end_date,
                    values: [],
                    toggle: 'type',
                    mode: queryParamName,
                    jobs: vm.jobIdArray,
                    users: vm.supervisorsArray
                }
                if(vm.toggles.by_form == true)
                    filter_payload.toggle = 'form'                
                if(seriesName === translateTag(688)){
                    otherlist.forEach(ids => {
                        ids.forEach(element => {
                           filter_payload.values.push(element) 
                        });
                    });
                }
                else{
                    filter_payload.values = seriesName
                }
                    
                $window.sessionStorage.setItem('siteFilter', JSON.stringify(filter_payload))                
                $location.path('/a/haps');
               }


            vm.actionClicked = (clickEvent) => {
                seriesName = clickEvent.name === translateTag(688) ? clickEvent.name: clickEvent.id
                handleChartClick(seriesName, 'action_type', sitesService.otherActionsList)
            }

            vm.hazardClicked = (clickEvent) => {
                seriesName = clickEvent.name === translateTag(688) ? clickEvent.name: clickEvent.id
                handleChartClick(seriesName, 'hazard_identification', sitesService.otherHazardsList)
            }

            vm.potentialRiskClicked = (clickEvent) => {
                seriesName = clickEvent.name === translateTag(688) ? clickEvent.name: clickEvent.id
                handleChartClick(seriesName, 'potential_risk', sitesService.otherRisksList)
            }

            /*
                Toggle Stuff
            */
            vm.updateTypeToggle = () => {
                vm.hideDropdowns()
                if (vm.type_toggle == 'by type') {
                    vm.toggles.by_type = true
                    vm.toggles.by_form = false
                }
                else {
                    vm.toggles.by_type = false
                    vm.toggles.by_form = true
                }
                vm.filterCharts()
            }

            vm.frequency_toggle = 'by frequency'
            vm.type_toggle = 'by type'

            vm.updateFrequencyToggle = () => {
                vm.hideDropdowns()
                if (vm.frequency_toggle == 'by frequency') {
                    vm.toggles.by_frequency = true
                    vm.toggles.by_score = false
                }
                else {
                    vm.toggles.by_frequency = false
                    vm.toggles.by_score = true
                }
                vm.filterCharts()
            }

            vm.typeFilterMenu = ($event) => {
                $event.stopPropagation()
                vm.hideDropdowns()
                let y = $event.target.offsetTop + $event.target.offsetHeight
                let x = $window.innerWidth - ($event.target.offsetLeft + $event.target.offsetWidth) + $('.sites').scrollLeft()
                let actions = $('#typeChartFilterDropdown')
                actions.addClass('show')
                actions.css({ top: y, right: x })
            }

            vm.frequencyFilterMenu = ($event) => {
                $event.stopPropagation()
                vm.hideDropdowns()
                let y = $event.target.offsetTop + $event.target.offsetHeight
                let x = $window.innerWidth - ($event.target.offsetLeft + $event.target.offsetWidth) + $('.sites').scrollLeft()
                let actions = $('#frequencyChartFilterDropdown')
                actions.addClass('show')
                actions.css({ top: y, right: x })
            }

            /*
                Date filter Stuff
            */
            vm.getStartDate = () => {
                if (vm.dateFilter.start_month && vm.dateFilter.start_year) {
                    let monthNum = vm.dateFilter.start_month
                    let sd = vm.dateFilter.start_year + "-" + monthNum + "-01"
                    return sd
                }
                return null
            }

            vm.getEndDate = () => {
                if (vm.dateFilter.end_month && vm.dateFilter.end_year) {
                    let monthNum = vm.dateFilter.end_month
                    momentEndDate = moment(`${vm.dateFilter.end_year}-${monthNum}-01`,'YYYY-MM-DD')
                    let ed = `${vm.dateFilter.end_year}-${monthNum}-${momentEndDate.endOf('month').format('DD')}`
                    return ed
                }
                return null
            };

            function getLastOfMonth(ymdString) {
                var ymdSplit = ymdString.split('-')
                var snappedEndDate = new Date(ymdSplit[0], ymdSplit[1], 0) //month is 0-indexed on january so month extracted from string is already the correct +1
                return snappedEndDate.getFullYear() + '-' + (snappedEndDate.getMonth() + 1) + '-' + snappedEndDate.getDate() //add 1 back to month to negate 0-index
            }

            vm.getDateFilterDescription = () => {
                return vm.dateFilter.getFormattedRange()
            }

            vm.dateFilterMenu = ($event) => {
                $event.stopPropagation()
                vm.hideDropdowns()
                let y = 55
                let x = 195
                let actions = $('#dateFilterDropdown')
                actions.addClass('show')
                actions.css({ top: y, right: x })
            }

            vm.dateFilterValid = () => {
                return vm.dateFilter.validate()
            }

            /*
                Filter Stuff
            */

            vm.rightMenuClosed = true

            vm.filterCharts = (mode='normal') => {
                filterObject.Jobs = vm.jobIdArray
                filterObject.Supervisors = vm.supervisorsArray
                filterObject.toggles = vm.toggles
                let startDate = vm.mainDateFilter.start_date
                let endDate = vm.mainDateFilter.end_date

                if (startDate)
                    filterObject.StartDate = startDate
                    filterObject.start_date = startDate //sarath
                if (endDate)
                    filterObject.EndDate = endDate
                    filterObject.end_date = endDate //sarath
                // getWidegtData(filterObject, mode)
                refreshFilters(filterObject, mode)
                dateRange={
                    "start_date": filterObject.StartDate,
                    "end_date": filterObject.EndDate,             
                }
                $scope.dateRange = dateRange
            }

            vm.options.columnDefs = sitesCols
            vm.options.headerHeight = 55

            vm.options.onColumnResized = (params) => {
                vm.options.api.resetRowHeights()
            }

            $scope.$on('menu-width-changed', () => {
                $timeout(() => {
                    vm.options.api.sizeColumnsToFit()
                }, 500)
            })

            $(window).on('resize', () => {
                $timeout(() => {
                    if (vm.correctiveActionsGridOptions && vm.correctiveActionsGridOptions.api) {
                    vm.options.api.sizeColumnsToFit()
                    vm.options.api.resetRowHeights()
                    }
                })
            })
            
            vm.calculateRows = (forms) => {
                let compliance = []
                for (let i = 0; i < 3; i++) {
                    if (i == 0) {
                        let myRowObjectVariable = { site: "Company" }
                        for (let j = 0; j < forms.length; j++) {
                            let temp = forms[j].FormName
                            myRowObjectVariable[forms[j].FormID + ''] = vm.getCompanyCompliance(forms[j])
                        }
                        compliance.push(myRowObjectVariable)
                    }
                    else if (i == 1) {
                        let myRowObjectVariable = { site: "Filtered" + (vm.complianceMissingTargets ? " *" : "") }
                        for (let j = 0; j < forms.length; j++) {
                            let temp = forms[j].FormName
                            myRowObjectVariable[forms[j].FormID + ''] = vm.getFilteredCompliance(forms[j])
                        }
                        compliance.push(myRowObjectVariable)
                    }
                    else if (i == 2) {
                        let myRowObjectVariable = { site: "Variance" }
                        for (let j = 0; j < forms.length; j++) {
                            let temp = forms[j].FormName
                            let variance = vm.getVariance(forms[j]) + ''
                            if (!(variance + '').startsWith('-') && variance != 'N/A' && variance != '0') {
                                variance = '+' + variance
                            }
                            myRowObjectVariable[forms[j].FormID + ''] = variance
                        }
                        compliance.push(myRowObjectVariable)
                    }
                }
                vm.options.api.setRowData(compliance)
            }

            vm.noTargetMessage = 'No Target'

            vm.getCompanyCompliance = (form) => {
                let compliance = vm.complianceByForm.company.find(function (el, i) {
                    if (el.form == form.FormID)
                        return true
                })

                if (compliance != null)
                    return compliance.compliance
                else
                    return vm.noTargetMessage
            }

            vm.getFilteredCompliance = (form) => {
                let compliance = vm.complianceByForm.filtered.find((el, i) => {
                    if (el.form == form.FormID)
                        return true
                })

                if (compliance != null)
                    return compliance.compliance
                else
                    return vm.noTargetMessage
            }

            vm.getVariance = (form) => {
                let variance
                if (vm.getFilteredCompliance(form) != vm.noTargetMessage && vm.getCompanyCompliance(form) != vm.noTargetMessage)
                    variance = vm.getFilteredCompliance(form) - vm.getCompanyCompliance(form)
                else
                    variance = 'N/A'
                return variance
            }

            vm.showHelp = (id) => {
                $('.modal .scroll').scrollTop(0)
                modalService.Open(id)
            }

            vm.closeModal = (id) => {
                modalService.Close(id)
            }

            let infoObjects = {
                siteHapCountTypeYear: {
                    title: translateTag(2127), // Hazard Submission Count by Type and Year
                    toolTip: translateTag(8790), // Allows you to compare the number of hazards submitted each year. The hazards are grouped by type. Each year for the time period selected is represented by a bar.
                    list: [
                        {
                            label: translateTag(2128), // Hazard Count
                            description: translateTag(8791) // The total number of hazards submitted
                        },
                        {
                            label: translateTag(514), // Hazard Type
                            description: translateTag(8792) // The type of hazard submitted
                        },
                    ]
                },
                siteHapCountMonthYear: {
                    title: translateTag(2134), // Hazard Submission Count by Month and Year
                    toolTip: translateTag(8793), // The chart displays the total number of hazards submitted each month for the time period selected. If multiple years are selected, each year is represented by a different line.
                    list: [
                        {
                            label: translateTag(2128), // Hazard Count
                            description: translateTag(8791) // The total number of hazards submitted
                        },
                        {
                            label: translateTag(2050), // Month
                            description: translateTag(8794) // Displays the months contained in the time period selected.
                        }
                    ]
                },
                siteHapCompletionTime: {
                    title: translateTag(2147), // Hazard Count - Average Completion Time
                    toolTip: translateTag(8795), // The chart outlines the time taken to complete a hazard action. It groups the hazards into increasingly larger time buckets. Each hazard action will fall into a certain bucket depending on the amount of time elapsed between the creation and completion of each action
                    list: [
                        {
                            label: translateTag(2128), // Hazard Count
                            description: translateTag(8796) // The total number of completed hazards
                        },
                        {
                            label: translateTag(2155), // Time Buckets
                            description: translateTag(8797) // A span of time that a hazard action has been completed within
                        }
                    ]
                },
                siteTop10HapId: {
                    title: translateTag(2156), // Top 10 Hazard Identifications
                    toolTip: translateTag(8798), // The list compares the data from the current time span selected with the data from the same period of time that preceded it. The hazard type with the highest count is displayed at the top of the list. The trend shows the change in item position in the hierarchy between the current and previous time span.
                    list: [
                        {
                            label: "#", // #
                            description: translateTag(8761) // Order of items with the highest count at 1 and lowest count at 10
                        },
                        {
                            label: translateTag(510), // Hazard Identification
                            description: translateTag(8803) // Type of hazard
                        },
                        {
                            label: translateTag(2157), // Trend
                            description: translateTag(8763) // The difference in position of item in current time period compared to previous time period
                        }
                    ]
                },
                siteTop10HapOneWord: {
                    title: translateTag(2158), // Top 10 One Word Hazard Themes
                    toolTip: translateTag(8799), // The list compares the data from the current time span selected with the data from the same period of time that preceded it. The word with the highest count of mentions is displayed at the top of the list. The trend shows the change in item position in the hierarchy between the current and previous time span.
                    list: [
                        {
                            label: "#", // #
                            description: translateTag(8761) // Order of items with the highest count at 1 and lowest count at 10
                        },
                        {
                            label: translateTag(2159), // One Word Theme
                            description: translateTag(8804) // A single word that is commonly used in the Hazard Description field
                        },
                        {
                            label: translateTag(2157), // Trend
                            description: translateTag(8763) // The difference in position of item in current time period compared to previous time period
                        }
                    ]
                },
                siteTop10HapTwoWord: {
                    title: translateTag(2160), // Top 10 Two Word Hazard Themes
                    toolTip: translateTag(8800), // The list compares the data from the current time span selected with the data from the same period of time that preceded it. The pair of words with the highest count of mentions is displayed at the top and the lowest count at the bottom. The trend shows the change in item position in the hierarchy between the current and previous time span.
                    list: [
                        {
                            label: "#", // #
                            description: translateTag(8761) // Order of items with the highest count at 1 and lowest count at 10
                        },
                        {
                            label: translateTag(2161), // Two Word Theme
                            description: translateTag(8805) // A pair of words that is commonly used in the Hazard Description field
                        },
                        {
                            label: translateTag(2157), // Trend
                            description: translateTag(8763) // The difference in position of item in current time period compared to previous time period
                        }
                    ]
                },
                siteTop10HapSupervisors: {
                    title: translateTag(2160), // Top 10 Supervisors in Hazards
                    toolTip: translateTag(8801), // The list compares the data from the current time span selected with the data from the same period of time that preceded it. The supervisors with the most number of mentions is displayed at the top of the list. The trend shows the change in item position in the hierarchy between the current and previous time span.
                    list: [
                        {
                            label: "#", // #
                            description: translateTag(8761) // Order of items with the highest count at 1 and lowest count at 10
                        },
                        {
                            label: translateTag(3556), // Supervisor Name
                            description: translateTag(8805) // A pair of words that is commonly used in the Hazard Description field
                        },
                        {
                            label: translateTag(2157), // Trend
                            description: translateTag(8763) // The difference in position of item in current time period compared to previous time period
                        }
                    ]
                },
                siteTop10HapActionTaken: {
                    title: translateTag(2163), // Top 10 Action Taken One Word Theme
                    toolTip: translateTag(8799), // The list compares the data from the current time span selected with the data from the same period of time that preceded it. The word with the highest count of mentions is displayed at the top of the list. The trend shows the change in item position in the hierarchy between the current and previous time span.
                    list: [
                        {
                            label: "#", // #
                            description: translateTag(8761) // Order of items with the highest count at 1 and lowest count at 10
                        },
                        {
                            label: translateTag(2159), // One Word Theme
                            description: translateTag(8837) // A single word that is commonly used in the Action Taken field
                        },
                        {
                            label: translateTag(2157), // Trend
                            description: translateTag(8763) // The difference in position of item in current time period compared to previous time period
                        }
                    ]
                }
            }

            vm.openInfoModal = (infoObject) => {
                vm.currentInfo = infoObjects[infoObject]
                modalService.Open('infoModalComponent')
            }

            $scope.$on('OPEN_INFO_MODAL', (event, data) => {
                vm.openInfoModal(data)
            })

        }])