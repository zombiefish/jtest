﻿angular
    .module('safeToDo')
    .service('sitesService', ['$http',
        function ($http) {

       //   var colorArray = ['#E33E3E', '#4A90E2', '#D3D824', '#8EC229', '#F5A623', '#5EB500', '#666666', '#0E98E7']
          let colorArray = ['#0E6AC1', '#C0D7C5', '#64996B', '#097392', '#7FB5DB', '#FE9B56', '#B6D2EA', '#D55535', '#E59998', '#234234', '#FFF07C', '#D782B8', '#EF798A', '#20639B']
            let colors = {
                new: '#666666',
                inProgress: '#5EB500',
                imported: '#5EB500',
                received: '#0E98E7',
                inReview: '#F78200',
                released: '#F78200',
                pending: '#DF4343',
                sent: '#F78200',
                onHold: '#DF4343',
                complete: '#0E98E7',
                zeroState: '#eeeeee',
                red: '#E33E3E',
                blue: '#4A90E2',
                yellow: '#D3D824',
                green: '#8EC229',
                orange: '#F5A623'
            }

            let hazardTrendData = [
                [1495944000000, 1],
                [1496030400000, 3],
                [1496116800000, 2],
                [1496203200000, 4]
            ]

            let potentialRiskTrendData = [
                [1495944000000, 11],
                [1496030400000, 4],
                [1496116800000, 1],
                [1496203200000, 6]
            ]

            let actionTrendData = [
                [1495944000000, 11],
                [1496030400000, 2],
                [1496116800000, 11],
                [1496203200000, 1]

            ];

            let totalsFilter = {
                by_frequency: true,
                by_type: true,
                by_score: false,
                by_form: false                   
            }

            let getTop10HazardIdentificationsData = ''
            let getTop10OneWordHazardData = ''
            let getTop10TwoWordHazardData = ''
            let getTop10SupervisorsData = ''
            let getTop10ActionTakenWordData = ''

            let actionTrendScore = 0;
            let hazardTrendScore = 0;
            let potentialRiskTrendScore = 0;

            let actionsCountFinal = 0;
            let hazardsCountFinal = 0;
            let potentialRisksCountFinal = 0;

            let color_palette = ["#0072ce", "#66aae2", "#F7BD03","#00447c", "#6e94ba", "#7272ad", "#d8bd87", "#447259", "#474747", "#b3bccf", 
            "#99bcac", "#a9ddff", "#96a9aa", "#001e60", "#777777", "#005ba5", "#0087b3", "#002e52", "#99c7eb", "#a4a1d5", "#00445a", 
            "#378ddc", "#424686", "#fcecb3", "#9c6492", "#16492d", "#d193ae", "#eacfce", "#8a7fd0", "#616699", "#006586", "#ddab00", 
            "#c292cd", "#d6d3ff", "#5f3c79", "#00a9e0", "#ffb359", "#58cad3"]

            let noData = [{type:'bar', x: [translateTag(3838)], y: [0]}]

            let vars = {};
            vars.hazardCount = 0;
            vars.potentialRiskCount = 0;
            vars.actionCount = 0;
            vars.otherHazards = [];
            vars.otherActions = [];
            vars.otherRisks = [];
            vars.hazardData = [
                { name: 'Zero_state', y: 1, color: colors.zeroState }
            ]
            vars.potentialRiskData = [
                { name: 'Zero_state', y: 1, color: colors.zeroState }
            ]
            vars.actionData = [
                { name: 'Zero_state', y: 1, color: colors.zeroState }
            ]
            function sortNumber(a, b) {
                return b.y - a.y;
            }

            function updateData(data, countPropName, dataArrayPropName, otherListPropName) {
                vars[countPropName] = data.total

                let newData = []

                if (data.Zero_state > 0) {
                    newData.push({ name: 'Zero_state', y: data.Zero_state, color: colors.zeroState });
                }
                Object.keys(data.calculatedValues).forEach(function (key) {                                        
                    newData.push(
                        { 
                            name: key, 
                            id: data.calculatedValues[key]['id'].split(','),
                            y: data.calculatedValues[key]['value'], 
                            color: colorArray[Math.floor(Math.random() * 7)] 
                        });
                });
                var topN = 4;
                newData.sort(sortNumber);
                var rest = newData.slice(topN);
                newData = newData.slice(0, topN);
                var restTotal = 0
                vars[otherListPropName].length = 0;
                rest.forEach(function (datapoint) {
                    restTotal += datapoint.y;
                    vars[otherListPropName].push(datapoint.id);
                });

                if (restTotal > 0) {
                    newData.push({ name: translateTag(688), y: restTotal, color: colorArray[Math.floor(Math.random() * 7)] });
                }
                //Set colours
                newData.forEach(function (dp, index) {
                    if (dp.name.toLowerCase() == 'zero_state')
                        dp.color = colors.zeroState;
                    else
                        dp.color = colorArray[index];
                });

                vars[dataArrayPropName] = newData;
            }
            
            function updatehazardTrendData(data) {
                var newData = [];

                hazardTrendScore = data.total;

                data.dates.forEach(function (dateString, index) {
                    newData.push([
                        new Date(dateString).getTime(),
                        data.scores[index]
                    ]);
                });
                hazardTrendData = newData;
            }

            function updatePotentialRiskTrendData(data) {
                var newData = [];

                potentialRiskTrendScore = data.total;

                data.dates.forEach(function (dateString, index) {
                    newData.push([
                        new Date(dateString).getTime(),
                        data.scores[index]
                    ]);
                });
                potentialRiskTrendData = newData;
            }

            function updateActionTrendData(data) {
                var newData = [];

                actionTrendScore = data.total;

                data.dates.forEach(function (dateString, index) {
                    newData.push([
                        new Date(dateString).getTime(),
                        data.scores[index]
                    ]);
                });
                actionTrendData = newData;
            }

            return {
                getHazardsCountFP: function (filter) {
                    filter.by_frequency = true
                    filter.by_type = true
                    filter.by_score = false
                    filter.by_form = false  
                    return $http.post(`${__env.apiUrl}/api/hap/get-hazards-by-filter/`, filter).then((response) => {
                        hazardsCountFinal = response.data.total;
                    }, function (args) {
                        console.log('Failed to load hazard count.');
                    });
                },
                getPotentialRisksCountFP: function (filter) {
                    filter.by_frequency = true
                    filter.by_type = true
                    filter.by_score = false
                    filter.by_form = false
                    return $http.post(`${__env.apiUrl}/api/hap/get-potential-risk-by-filter/`, filter).then((response) => {
                        potentialRisksCountFinal = response.data.total;
                    }, function (args) {
                        console.log('Failed to load prs.');
                    });
                },
                getActionsFPCount: function (filter) {
                        filter.by_frequency = true
                        filter.by_type = true
                        filter.by_score = false
                        filter.by_form = false                   
                    return $http.post(`${__env.apiUrl}/api/hap/get-actions-by-filter/`, filter).then((response) => {
                        actionsCountFinal = response.data.total;
                    }, function (args) {
                        console.log('Failed to load acts.');
                    });
                },

                getHazardsFP: (filter) => {
                    filter.lang = selectedLanguage
                    return $http.post(`${__env.apiUrl}/api/hap/get-hazards-by-filter/`, filter).then((response) => {
                        updateData(response.data, 'hazardCount', 'hazardData', 'otherHazards')
                    }, (args) => {
                        console.log('Failed to load hazards.', args)
                    });

                },

                getPotentialRisksFP: (filter) => {
                    filter.lang = selectedLanguage                    
                    return $http.post(`${__env.apiUrl}/api/hap/get-potential-risk-by-filter/`, filter).then((response) => {
                          updateData(response.data, 'potentialRiskCount', 'potentialRiskData', 'otherRisks')
                        }, (args) => {
                          console.log('Failed to load Potential Risks.', args)
                      });
                    },

                  getActionsFP: (filter) => {
                    filter.lang = selectedLanguage
                    return $http.post(`${__env.apiUrl}/api/hap/get-actions-by-filter/`, filter).then((response) => {
                        updateData(response.data, 'actionCount', 'actionData', 'otherActions')
                      }, (args) => {
                        console.log('Failed to load Actions.', args)
                    })
                },

                gethazardTrendFP:(filter) => {
                    filter.lang = selectedLanguage
                    return $http.post(`${__env.apiUrl}/api/hap/get-hazards-by-jobs-supervisor-date/`, filter).then((response) => {
                        updatehazardTrendData(response.data)
                    }, (args) => {
                        console.log('Failed to load hazard trend data.', args)
                    })
                },

                getPotentialRiskTrendFP: (filter) => {
                    filter.lang = selectedLanguage
                    return $http.post(`${__env.apiUrl}/api/hap/get-potential-risk-trend/`, filter).then((response) => {
                        updatePotentialRiskTrendData(response.data)
                    }, (args) => {
                        console.log('Failed to load pot risk trend data.', args)
                    })
                },

                getActionTrendFP: (filter) => {
                    filter.lang = selectedLanguage
                    return $http.post(`${__env.apiUrl}/api/hap/get-actions-trend/`, filter).then((response) => {
                        updateActionTrendData(response.data)
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getHapByTypeAndYear: (dateRange) => {
                    dateRange.lang = selectedLanguage
                    return $http.post(`${__env.apiUrl}/api/hap/get-hap-by-type-and-year/`, dateRange).then((response) => { 
                        if (response.data == 'No Data to Show'){
                            return noData
                        }
                        else{
                            data=[]
                            for (year in response.data.hazard_series){
                                data.push({
                                    type: 'bar',
                                    x: response.data.hazard_categories,                               
                                    y: response.data.hazard_series[year].data,
                                    name: response.data.hazard_series[year].name,
                                    marker: {color: color_palette[year]},    
                                    }
                                )
                            }
                            return data 
                        }    
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getHapByMonthAndYear: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/hap/get-hap-by-month-and-year/`, dateRange).then((response) => { 
                        if (response.data == 'No Data to Show'){
                            return noData
                        }
                        else{
                            data=[]
                            curYear = ""
                            for (year in response.data){
                                month_name = translateTag(plotlyTags[response.data[year].hazard_month_name])
                                if (curYear == response.data[year].hazard_year) {
                                    data[data.length - 1].x.push(month_name)
                                    data[data.length - 1].y.push(response.data[year].hazard_count)
                                }
                                else{
                                    curYear = response.data[year].hazard_year
                                    data.push({
                                        type: 'line',
                                        x: [month_name],
                                        y: [response.data[year].hazard_count],                                
                                        name: response.data[year].hazard_year,
                                        marker: {color: color_palette[year]},
                                        }
                                    )
                                }
                            }

                            return data
                        }    
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },
                
                getHapAvgCompletionTime: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/hap/get-hap-avg-completion-time/`, dateRange).then((response) => {                         
                        if (response.data == 'No Data to Show'){
                            return noData
                        }
                        else{
                            data = [{
                                type: 'bar',
                                x: [],                               
                                y: [],
                                name: translateTag(2128),
                                marker: {color: color_palette[0]},
                            }]
                            
                            for (i in response.data){
                                data[0].x.push(translatePlotlyField(response.data[i].hazard_time_bucket))
                                data[0].y.push(response.data[i].hazard_count)
                            }
                            return data 
                        }                            
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getTop10HazardIdentifications: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/hap/get-top-10-hazard-identification/`, dateRange).then((response) => { 
                        getTop10HazardIdentificationsData = response.data
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },
       
                getTop10OneWordHazard: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/hap/get-top-10-one-word-hazards-themes/`, dateRange).then((response) => { 
                        getTop10OneWordHazardData = response.data
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getTop10TwoWordHazard: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/hap/get-top-10-two-word-hazards-themes/`, dateRange).then((response) => { 
                        getTop10TwoWordHazardData = response.data
                        return response.data                    
                        
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getTop10Supervisors: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/hap/get-top-10-supervisor-in-hazard-submissions/`, dateRange).then((response) => { 
                        getTop10SupervisorsData = response.data
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getTop10ActionTakenWord: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/hap/get-top-10-action-taken-one-word-themes/`, dateRange).then((response) => { 
                        getTop10ActionTakenWordData = response.data
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },


                readHazardData: () => {
                    return vars.hazardData
                },
                readHazardCount: () => {
                    return vars.hazardCount
                },
                readHazardTrendData: () => {
                    return hazardTrendData
                },
                readPotentialRiskData: () => {
                    return vars.potentialRiskData
                },
                readPotentialRiskCount: () => {
                    return vars.potentialRiskCount
                },
                readPotentialRiskTrendData: () => {
                    return potentialRiskTrendData
                },
                readActionData: () => {
                    return vars.actionData
                },
                readActionCount: () => {
                    return vars.actionCount
                },
                readActionTrendData: () => {
                    return actionTrendData
                },
                readActionTrendScore: () => {
                    return actionTrendScore
                },
                readHazardTrendScore: () => {
                    return hazardTrendScore
                },
                readPotentialRiskTrendScore: () => {
                    return potentialRiskTrendScore
                },
                readActionsCountFinal: () => {
                    return actionsCountFinal
                },
                readPotentialRisksCountFinal: () => {
                    return potentialRisksCountFinal
                },
                readHazardsCountFinal: () => {
                    return hazardsCountFinal
                },
                readTop10HazardIdentifications:()=>{
                    return getTop10HazardIdentificationsData
                },
                readTop10OneWordHazard:()=>{
                    return getTop10OneWordHazardData
                },
                readTop10TwoWordHazard:()=>{
                    return getTop10TwoWordHazardData
                },
                readTop10Supervisors:()=>{
                    return getTop10SupervisorsData
                },
                readTop10ActionTakenWord:()=>{
                    return getTop10ActionTakenWordData
                },                
               
                otherHazardsList: vars.otherHazards,
                otherActionsList: vars.otherActions,
                otherRisksList: vars.otherRisks
            }
        }
    ])