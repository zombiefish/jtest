﻿//import { Spinner } from '../../lib/spinjs/spin';

angular
    .module('safeToDo')
    .service('tirService', ['$http', 'menuService',
        function ($http, menuService) {
            let forms = menuService.getMenuItems();
            let opts = {
                lines: 10, // The number of lines to draw
                length: 4, // The length of each line
                width: 29, // The line thickness
                radius: 52, // The radius of the inner circle
                scale: 0.4, // Scales overall size of the spinner
                corners: 0.4, // Corner roundness (0..1)
                color: '#ffaf09', // CSS color or array of colors
                fadeColor: 'transparent', // CSS color or array of colors
                speed: 0.8, // Rounds per second
                rotate: 90, // The rotation offset
                animation: 'spinner-line-fade-more', // The CSS animation name for the lines
                direction: 1, // 1: clockwise, -1: counterclockwise
                zIndex: 2e9, // The z-index (defaults to 2000000000)
                className: 'spinner', // The CSS class to assign to the spinner
                top: '50%', // Top position relative to parent
                left: '50%', // Left position relative to parent
                shadow: '0 0 1px transparent', // Box-shadow for the lines
                position: 'absolute' // Element positioning
            }
          //  let spinner = new Spinner(opts)
            let preTasks = []
            let incidentHeader = []
            // let incidentSections = [
            //     'Incident Report',
            //     'Training Records',
            //     'PreTasks',
            //     'PreOps',
            //     'Risk Assessments and Procedures',
            //     'Pictures',
            //     'Statements',
            //     'Correspondence',
            //     'Other Info'
            // ]
          return {

            getTir: (filterObject) =>{
                return $http.post(`${__env.apiUrl}/api/incident-management/incident-list/`, filterObject)
                    .then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load tirs', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                           // toastr.error(errorParams.data.detail)
                           // window.location.href = "/";
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },

            getUnassignedIncidentForms: (filterObject) => {
                return $http.post(`${__env.apiUrl}/api/incident-management/unassigned-incident-list/`, filterObject)
                    .then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load unassigned forms',errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            window.location.href = "/";
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },

            getTirForms: () => {
                return $http.get(`${__env.apiUrl}/api/incident-management/incident-form-list/${selectedLanguage}`)
                    .then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load tir forms', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },

            getIncidentFormSubmissions: (formId, submissionHeaderIds) => {
                var tirFilter = { formId: formId, submissionIds: submissionHeaderIds, lang:selectedLanguage}
                return $http.post(`${__env.apiUrl}/api/incident-management/get-incident-form-submissions-by-header-ids/`, tirFilter )
                    .then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load IncidentFormSubmissions',errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                 })
            },

            getIncidentAttachments: (incidentId) => {
                return $http.post(`${__env.apiUrl}/api/incident-management/incident-attachments/`, {"incidentId": incidentId})
                    .then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load tir attachments', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },

            getIncidentActions: (incidentId) => {
                return $http.post(`${__env.apiUrl}/api/incident-management/get-incident-action-by-incident-id/`, {"incidentId": incidentId})
                    .then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load tir actions',errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },

            getIncidentHeader: (incidentId) => {
                return $http.get(`${__env.apiUrl}/api/incident-management/get-incident-header/${incidentId}/`)
                    .then((response) => {
                        incidentHeader = response.data                        
                    }, (errorParams) => {
                        console.log('Failed to load tir actions',errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },

            getIncidentSubmissionHeaderId: (incidentId) => {
                return $http.get(`${__env.apiUrl}/api/incident-management/get-incident-header-id/${incidentId}/`)
                    .then((response) => {
                        return response.data                      
                    }, (errorParams) => {
                        console.log('Failed to load tir actions',errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },

            renameIncidentAttachment: (att) => {
                return $http.post(`${__env.apiUrl}/api/incident-management/rename-incident-attachments/`, att)
                    .then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to rename tir attachment', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },

            uploadIncidentAttachments: (formData) =>{
               return $http.post(`${__env.apiUrl}/api/image-upload/`, formData, {
                    // this cancels AngularJS normal serialization of request
                    transformRequest: angular.identity,
                    // this lets browser set `Content-Type: multipart/form-data` 
                    // header and proper data boundary
                    headers: {'Content-Type': undefined}
                }).then(function(data){
                    return data
                }, (errorParams) => {
                    console.log('Failed to load unassigned forms', errorParams)
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    }
                    else if(errorParams.data.error)
                        toastr.error(errorParams.data.error)
                })
            },

            deleteIncidentAttachment: (id) => {
                return $http.post(`${__env.apiUrl}/api/incident-management/delete-incident-attachments/`, {"id": id})
                    .then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to delete Incident attachment', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },

            createNewIncident: (incidentNumber) => {
                var spinTarget = document.getElementById('staging-area')
                //spinner.spin(spinTarget)
                return $http.post(`${__env.apiUrl}/api/incident-management/insert-new-incident/`, {"IncidentNumber": incidentNumber})
                    .then((response) => {
                        //spinner.stop()
                        return response.data

                    }, (errorParams) => {
                        //spinner.stop()
                        console.log('Failed to create new incident', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },

            assignSubmissionsToIncident: (incidentId, SubmissionIDs) => {
                var spinTarget = document.getElementById('staging-area')
                //spinner.spin(spinTarget)
                return $http.post(`${__env.apiUrl}/api/incident-management/assign-submission-to-incident/`, {"incidentId": incidentId, "submissions":SubmissionIDs})
                    .then((response) => {
                        //spinner.stop()
                        return response.data
                    }, (errorParams) => {
                        //spinner.stop()
                        console.log('Failed to assign sbmissions to incident', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },

            removeSubmissionsFromIncident: (incidentId, SubmissionIDs) =>{
                if (SubmissionIDs.length == 0)
                    return
                var spinTarget = document.getElementById('staging-area')
                //spinner.spin(spinTarget)
                return $http.post(`${__env.apiUrl}/api/incident-management/remove-submissions-from-incident/`, {"incidentId": incidentId, "submissions":SubmissionIDs})
                    .then((response) => {
                        //spinner.stop()
                        return response.data
                            
                    }, (errorParams) => {
                        //spinner.stop()
                        console.log('Failed to remove submissions from incident', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },

            exportPdf: (exportArr, incident) => {
                let url1 = `${__env.apiUrl}/api/report-pdf/create-report-pdf/`
                let anySubmissions
                anySubmissions = exportArr.filter((val) => {
                    if (val.SubmissionIDs.length > 0)
                        return true
                });

                if (anySubmissions.length == 0)
                    return

                let spinTarget = document.getElementById('incident-viewer')
                //spinner.spin(spinTarget)
                $('.tir .incident-viewer .body').addClass('loading')
                return $http.post(url1, exportArr)
                    .then((response) => {
                        let downloadToken = response.data
                        console.log("This is the Download Token", downloadToken)
                        let hiddenElement = document.createElement('a')
                      //  hiddenElement.href = '/api/Reports/' + downloadToken + '/download?incident=' + incident
                       // hiddenElement.click()
                        //spinner.stop()
                        $('.tir .incident-viewer .body').removeClass('loading')
                    }, (errorParams) => {
                        console.log('Failed to generate pdfs', errorParams)
                        toastr.error('Failed to generate pdfs: ' + errorParams.statusText)
                        //spinner.stop()
                        $('.tir .incident-viewer .body').removeClass('loading')
                    })
            },

            getNameSummary: (submissions, fieldName) => {
                let supervisorSummary = ''
                    if (submissions == undefined || submissions.length < 1)
                        return ''

                    let flags = [], output = [], l = submissions.length, i
                    for (i = 0; i < l; i++) {
                        if ( flags[submissions[i][fieldName]]) continue
                        flags[submissions[i][fieldName]] = true
                        output.push(submissions[i][fieldName])
                    }
                 if(output[0]) {
                    output.forEach((name, index) => {
                        let fullname = name.split(",")

                        if (fullname.length == 1)
                            output[index] = fullname[0].trim()  //Pierre Belanger
                        else if (fullname.length > 1) // Belanger, Pierre
                            output[index] = fullname[1].trim() + " " + fullname[0].trim()
                    })
                    supervisorSummary = output.join(', ')
                 }
                    return supervisorSummary
            },


            getFieldSummary:  (submissions, fieldName) => {
                    if (submissions == undefined || submissions.length < 1)
                        return ''

                    let flags = [], output = [], l = submissions.length, i
                    for (i = 0; i < l; i++) {
                        if (flags[submissions[i][fieldName]]) continue
                        flags[submissions[i][fieldName]] = true
                        if (submissions[i][fieldName] != null)
                            output.push(submissions[i][fieldName])
                    }
                    output = output.map(function (el) {
                        if (Date.parse(el) > 0)
                            return el.split('T')[0]
                        return el
                    });
                    return output.join(', ')
            },


            getIncidentSections: () => {
                    return incidentSections
                },
              //  /api/incident-management/obtain-training-records/
            requestEmployeeRecords: (payload) => {
                return $http.post(`${__env.apiUrl}/api/incident-management/obtain-training-records/`, payload)
                    .then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to obtain training records', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },
            getAllPreTasks: () => {
                return $http.get(`${__env.apiUrl}/api/incident-management/get-all-pretasks/`)
                .then((response) => {
                    preTasks = response.data
                }, (errorParams) => {
                    console.log('Failed to obtain PreTasks records', errorParams)
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    }
                    else if(errorParams.data.error)
                        toastr.error(errorParams.data.error)
            })

            },
            readAllPreTasks : () =>{
                return preTasks
            }, 
            getAllPreOps: () => {
                return $http.get(`${__env.apiUrl}/api/incident-management/get-all-preops/`)
                .then((response) => {
                    preOps = response.data
                }, (errorParams) => {
                    console.log('Failed to obtain PreOps records', errorParams)
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    }
                    else if(errorParams.data.error)
                        toastr.error(errorParams.data.error)
                })

            },
            readAllPreOps : () =>{
                return preOps
            },
            preparePreTaskDocuments : (payload) => {
                return $http.post(`${__env.apiUrl}/api/incident-management/pretaskpdf/`, payload)
                    .then((response) => {
                        return "OK"
                    }, (errorParams) => {
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },
            preparePreOpDocuments : (payload) => {
                return $http.post(`${__env.apiUrl}/api/incident-management/preoppdf/`, payload)
                    .then((response) => {
                        return "OK"
                    }, (errorParams) => {
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },
            prepareRMMDocuments : (payload) => {
                return $http.post(`${__env.apiUrl}/api/incident-management/generate-ra-pdf/`, payload)
                .then((response) => {
                    return "OK"
                },(errorParams) => {
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    }
                    else if(errorParams.data.error)
                        toastr.error(errorParams.data.error)  
                })
            },
            validateSubmissionIdsExists: (payload) => {
                return $http.post(`${__env.apiUrl}/api/incident-management/get-headerids-exists-in-incidentsubmissions/`, payload)
                    .then((response) => {
                        return response.data.count
                    }, (errorParams) => {
                        console.log('Failed to load tir get-headerids-exists-in-incidentsubmissions',errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else if(errorParams.data.error)
                            toastr.error(errorParams.data.error)
                })
            },
            readIncidentHeader: () => {
                return incidentHeader
            },
        }
    }
])