﻿angular
    .module('safeToDo')
    .service('rootCauseAnalysisService', ['$http', 'gridService',  
        function ($http, gridService) {

            gridOptions = gridService.getCommonOptions()

            let defaultColDef = {
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                headerCheckboxSelection: (params) => {
                    let displayedColumns = params.columnApi.getAllDisplayedColumns()
                    let thisIsFirstColumn = displayedColumns[0] === params.column
                    return thisIsFirstColumn
                },
                checkboxSelection: (params) => {
                    let displayedColumns = params.columnApi.getAllDisplayedColumns()
                    let thisIsFirstColumn = displayedColumns[0] === params.column
                    return thisIsFirstColumn
                },
                minWidth: 150,
                maxWidth: 150,
                cellClass: 'tir-cell',
                cellRenderer: 'tippyCellRenderer',
            }
            
            let columnDefs = [
                { field: "dummyCheckbox", headerName: "", minWidth: 40, maxWidth: 40, suppressMenu: true, suppressSorting: true, cellRenderer: '' },
                {
                    field: "", headerName: "", minWidth: 50, maxWidth: 50, suppressMenu: true, suppressSorting: true,
                    cellRenderer: (params) => {
                        return `<span class="d-inline-flex"><span ng-if="'${params.data.status}' == 'complete'"  ng-click="tir.reviewIncidentAnalysis(data)" note="Review Submission" title="${translateTag(3431)}"" class="{{ data.rca_reviewed === 1 ? 'text-success ' : 'pointer'}}" /><i class="far fa-file-alt fa-lg"></i></span>`
                        + `<span ng-if="'${params.data.status}' == 'complete'" note="Review History" title="{{menu.translateLabels(3951)}}" class="ml-1 source" ng-class="{ transparent: (!data.rca_reviewed_count > 0), pointer: (data.rca_reviewed_count > 0) }" ng-click="tir.viewAcknowledgeHistory(data);">{{ data.rca_reviewed_count }}</span>`
                        + `</span>`
                    },
                },
                {
                    field: "", headerName: "", minWidth: 40, maxWidth: 40, suppressMenu: true, suppressSorting: true,
                    cellRenderer: (params) => {
                        return `<span class="pointer text-left" ng-click="tir.openReport($event,'${params.data.ReportURL}','${params.data.ID}')"><i class="fa fa-external-link-alt" title="${translateTag(3429)}"></i></span>`
                    },
                },
                {
                    field: "", headerName: " ", minWidth: 40, maxWidth: 40, suppressMenu: true, suppressSorting: true,
                    cellRenderer: (params) => {
                        return `<div style="display:inline-block;" class="pointer" ng-click="tir.editRootCauseAnalysisModal(data.ID, data)" ng-if="!tir.showClearSignOffs">`
                            + `<i class="fa fa-pen" notes="Edit" title= "${translateTag(1194)}"></i>`
                            + `</div>`
                    },
                },
                {
                    field: "ID",
                    headerName: " ",
                    sort: 'Desc',
                    hide: true,
                },
                {
                    field: "Cause",
                    headerName: "Cause(s)",
                    maxWidth: 100,
                    minWidth: 100,
                    cellRenderer: 'agGroupCellRenderer'
                },
                {
                    field: "SubmissionDate",
                    headerName: " ",
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "SubmittedBy",
                    headerName: " ",
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "EventDetails",
                    headerName: " ",
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "InvestigationFindings",
                    headerName: " ",
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "PreliminaryType",
                    headerName: " ",
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "ActualType",
                    headerName: " ",
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "PotentialLoss",
                    headerName: " ",
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "IncidentType",
                    headerName: " ",
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "PreliminaryIncidentTypeCategory",
                    headerName: " ",
                    minWidth: 300,
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "PreliminaryIncidentTypeDetail",
                    headerName: " ",
                    minWidth: 270,
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "ActualIncidentTypeCategory",
                    headerName: " ",
                    minWidth: 270,
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "ActualIncidentTypeDetail",
                    headerName: " ",
                    minWidth: 270,
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "LastUpdated",
                    headerName: " ",
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "LastUpdatedBy",
                    headerName: " ",
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "EmployeesInvolved",
                    headerName: " ",
                    cellRenderer: 'tippyCellRenderer',
                }
            ];

            gridOptions.columnDefs = columnDefs
            gridOptions.masterDetail = true
            gridOptions.animateRows = false
            gridOptions.paginationPageSize = 10
            gridOptions.detailCellRendererParams = {
                detailGridOptions: {
                    showToolPanel: false,
                    toolPanelSuppressRowGroups: true,
                    toolPanelSuppressValues: true,
                    toolPanelSuppressPivots: true,
                    toolPanelSuppressPivotMode: true,
                    toolPanelSuppressSideButtons: true,
                    suppressContextMenu: true,
                    defaultColDef: {
                        filter: 'agSetColumnFilter',
                        menuTabs: ['filterMenuTab'],
                        minWidth: 150,
                        maxWidth: 300,
                        cellClass: 'tir-cell',
                        //cellRenderer: 'tippyCellRenderer',
                        cellRenderer: (params) => {
                            if (params.value)
                                return '<span class="clip" title="' + params.value + '"">' + params.value + '</span>'
                            return ''
                        }
                    },
                    columnDefs: [
                        {
                            headerName: translateTag(3962),  //'Immediate Causes',
                            children: [
                                { field: 'ImmediateCauseType',headerName: translateTag(2014)}, // 'Cause Type'},
                                { field: 'ImmediateCause', headerName: translateTag(2015)},  //'Cause'},
                                { field: 'ImmediateCauseComments', headerName: translateTag(81)}, //'Comments'}
                                ]
                        },
                        {
                            headerName: translateTag(2016),  //'Basic Causes',
                            children: [
                                { field: 'BasicCauseType', headerName: translateTag(2014)}, // 'Cause Type'},
                                { field: 'BasicCauseCategory', headerName: translateTag(2017)}, //'Cause Category'},
                                { field: 'BasicCause', headerName: translateTag(2015)},  //'Cause'},
                                { field: 'BasicCauseComments', headerName: translateTag(81)}, //'Comments'}
                            ]
                        }
                    ],
                    rowHeight: 40,
                    headerHeight: 25,
                    localeText: sofvie_agGrid_languages[`${selectedLanguage}`]
                },
                getDetailRowData: (params) => {
                    params.successCallback(params.data.Causes)
                    gridOptions.api.forEachDetailGridInfo(function(detailGridInfo) {
                        detailGridInfo.api.sizeColumnsToFit()
                    })
                },
                
            }

            // dynamically assigning detail row height
            gridOptions.getRowHeight = function (params) {
            var isDetailRow = params.node.detail;
            
            // for all rows that are not detail rows, return nothing
            if (!isDetailRow) { return 40; }
            // otherwise return height based on number of rows in detail grid
            var detailPanelHeight = (params.data.Causes.length * 40) + 100;
            
            if(params.data.Causes.length == 1)
            {
              detailPanelHeight = (params.data.Causes.length * 40) + 105
            }  
            
            if(params.data.Causes.length <= 0) //Add extra when grid is empty
                detailPanelHeight += 60
  
            return detailPanelHeight;
        }                        

            return {
                getCommonOptions: () => {
                    let o = gridOptions //JSON.parse(JSON.stringify(gridOptions));
                    o.components = gridOptions.components
                    return o
                },

                getColumns:  () => {
                    return columnDefs
                },

                getDefaultColDef: () => {

                    return defaultColDef
                },

                upsertRootCauseAnalysis: (rca) => {
                    return $http.post(`${__env.apiUrl}/api/incident-management/upsert-root-cause-analysis/`,rca)
                        .then((response) => {
                            return response.data
                        }, (errorParams) => {
                            console.log('Failed to create rca',errorParams)
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                        })
                },                

                archiveRootCauseAnalyses: (rcaIDs) => {
                    if (rcaIDs.length == 0)
                        return
                    return $http.post(`${__env.apiUrl}/api/incident-management/archive-root-cause-analyses/`, {rootCauseAnalysesId: rcaIDs})
                        .then((response) => {
                            return response.data
                        }, (errorParams) => {
                            console.log('Failed to archive rcas',errorParams)
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                        });
                },

                getRootCauseAnalyses: (incidentID, selectedLanguage) => {
                    return $http.post(`${__env.apiUrl}/api/incident-management/get-incident-rca_by_incident_id/`, {"incidentId": incidentID, "lang" : selectedLanguage})
                        .then((response) => {
                            return response.data
                        }, (errorParams) => {
                            console.log('Failed to get rca',errorParams)
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                        })
                },

                getRootCauseAnalysis: (rootCauseID) => {
                    return $http.post(`${__env.apiUrl}/api/incident-management/get-root-cause-analysis-edit-rca-id/`, {"rootCauseId": rootCauseID})
                        .then((response) => {
                            return response.data
                        }, (errorParams) => {
                            console.log('Failed to get rca',errorParams)
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                        })
                },

                removeImmediateCause: (id) => {
                    return $http.post(`${__env.apiUrl}/api/incident-management/remove-immediate-cause/`,{"primary_id": id})
                    .then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to remove Immediate Cause', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else
                            toastr.error(errorParams.data.error)
                    })
                },

                removeBasicCause: (id) => {
                    return $http.post(`${__env.apiUrl}/api/incident-management/remove-basic-cause/`,{"primary_id": id})
                    .then((response) => {
                            return response.data
                        }, (errorParams) => {
                            console.log('Failed to remove Basic Cause', errorParams)
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                    })
                },

                reviewRca: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/incident-management/review-rca/`,payload).then((response) => {
                            return response
                        }, (errorParams) => {
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                    })
                },

                getRcaReviewers: (rca_id) => {
                    return $http.get(`${__env.apiUrl}/api/incident-management/get-rca-reviewers-list/${rca_id}/`).then((response) => {
                            return response
                        }, (errorParams) => {
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                    })
                },

            }
                
        }
    ]);