﻿angular
    .module('safeToDo')
    .controller('TirCtrl', ['$window', '$scope', '$rootScope', 'listService','$routeParams', '$timeout', '$q', '$http','$sce', 'gridService', 'select2Service', 'tirService', 'formsService', 'menuService', 'modalService', 'fileUploadService', 'listService', 'rootCauseAnalysisService', 'employeesService', 'tirSignoffService', 'hapsService', 'gapsService', 'profileService', 'actionManagementService','oraService', 'jraService','praService', 'bowtieService', 'signoffService', '$compile','$interval',
    function ($window, $scope, $rootScope,listService, $routeParams, $timeout, $q, $http,$sce, gridService, select2Service, tirService, formsService, menuService, modalService, fileUploadService, $listService, rootCauseAnalysisService, employeesService, tirSignoffService, hapsService, gapsService, profileService , actionManagementService, oraService, jraService, praService,bowtieService,signoffService, $compile, $interval) {
        let vm = this
        let rmmFilter = {}
        rmmFilter.start_date = '2010-01-01'
        rmmFilter.end_date = '2050-01-01'  
        vm.siteArray = []
        
        if ($routeParams.site) {
            vm.siteArray = $routeParams.site.split('|')
        }
        vm.token = JSON.parse(localStorage.getItem('token')).access

        $scope.$on('$locationChangeStart', () => {
            $window.sessionStorage.removeItem('user_sites')
        })
        vm.site_name = listService.readFullSites()
        vm.job_name = listService.readFullJobs()
        vm.unassignedIncidentSearch = ""
        vm.incidentSearch = ""
        vm.employeeSearch = ""
        vm.currentIncidentid = ''
        vm.uploadFiles = {}
        vm.fullEmployees = []
        vm.employeeList = []
        vm.fullEmployeeList = []
        vm.currentAcknowledgeHistory = []
        vm.userId = null
        vm.siteList = []
        vm.actionTypeList = []
        vm.decisionData = []
        vm.attachmentData = []
        vm.DecDataContext = {}
        vm.newAttachments = []
        vm.uploadFileList= []
        vm.link = ''
        vm.topSearch = ''
        vm.archiveCount = 0
        vm.deleteAttCount = 0
        vm.singleServeReportUrl = ['general_actions_parent', 'hazard_report'] 
        vm.actionDisabled = true
        vm.attActionDisabled = true
        vm.canArchiveSubmissions = true
        vm.canManageDecisionLog = true
        vm.decisionViewerOpen = false
        vm.hideingDecisionViewer = false
        vm.openingDecisionViewer = false
        vm.currentAcknowledge = null
        vm.loadMessage = translateTag(3674)
        vm.attachmentServer = __env.imageUrl
        vm.preOps=null
        vm.preTasks=null
        vm.oraAGData=null
        vm.jraAGData=null
        vm.praAGData=null
        vm.quickSignOffState = false
        vm.incidentModified = false

        // Each element in the incidentSections array refer to a tag.  
        vm.incidentSections = [
            1179, //Incident Report
            1034, //Training Records
            3666, //PreTasks
            3667, //PreOps
            3668, //Risk Assessments and Procedures
            741,  //Pictures
            3665, //Statements
            3669, //3669
            3670, //Other Info
        ]
        vm.activeSection = 1179 // 'Incident Report'
        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        function resetActiveSection() {
                vm.activeSection = 1179 //  'Incident Report'
        }

        vm.imageFileTypes = [".bmp", ".jpg", ".jpeg", ".gif", ".png", ".tif", ".emf"]
        vm.selectedSubmissionHeaderId = null
        vm.tirGridOptions = gridService.getCommonOptions()
        vm.existingIncidentsGridOptions = gridService.getCommonOptions()
        vm.unassignedTirGridOptions = gridService.getCommonOptions()
        vm.employeeGridOptions = gridService.getCommonOptions()

        vm.preTaskGrid = gridService.getCommonOptions()
        vm.preOpsGrid = gridService.getCommonOptions()

        
        vm.oraOptions = gridService.getCommonOptions()
        vm.jraOptions = gridService.getCommonOptions()
        vm.praOptions = gridService.getCommonOptions()
        vm.bowOptions = gridService.getCommonOptions()
        vm.rootCauseAnalysisGridOptions = rootCauseAnalysisService.getCommonOptions()
        vm.correctiveActionsGridOptions = gridService.getCommonOptions()
        vm.submissionImages = []
        vm.submissionImagesComments = []
        vm.unassignedIncidentsCount = 0
        vm.selectedHapId = 0
        vm.selectedGapId = 0
        vm.actionMode = 'new'
        vm.hazardEditData = {}
        vm.hazardActionModalID = "hazardActionModal"
        vm.generalEditData = {}
        vm.generalActionModalID = "generalActionModal"

        vm.mainDateFilter = {}

        vm.canArchiveSubmissions = false
        vm.canManageIncidents = false
        vm.canCreateHistoricalIncidents = false
        vm.canSignOff = false
        vm.canSaveManageSignOff = true
        vm.mobileDisabled = true
         
        vm.translateLabels = (key) =>{      
            return translateTag(key)
        }
        
        $rootScope.$on("MOBILE-LOADED", (event,result) => {
            vm.mobileDisabled = false
            $scope.$digest()
        })

        //Get permissions for the user
        menuService.getPagePermissions().then((data) => {
            vm.permissions = data           
            vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
            vm.canViewIncidents = vm.permissions.includes('Can View Incidents') ? true : false
            if(!vm.canViewIncidents)
                window.location.href = "/";
            vm.canManageIncidents = vm.permissions.includes('Can Manage Incidents') ? true : false
            vm.canCreateHistoricalIncidents = vm.permissions.includes('Can Create Historical Incident') ? true : false
            vm.canSignOff = vm.permissions.includes('Can Sign Off Incident') ? true : false
            vm.canManageIncidentSignOff = vm.permissions.includes('Can Manage Incident Sign-off') ? true : false
            vm.canClearIncidentSignOff = vm.permissions.includes('Can Clear Incident Signatures') ? true : false
            vm.canQuickSignoff = vm.permissions.includes('Can Quick Incident Signoff') ? true : false
            vm.canManageAllIncidentSubmissions = vm.permissions.includes('Can Manage All Incident Submissions') ? true : false
            vm.canManageActionItems = vm.permissions.includes('Can Manage Action Items') ? true : false
        })

        //Functions to manage searchs
        vm.unassignedIncidentSearchChanged = () => {
            vm.unassignedTirGridOptions.api.setQuickFilter(vm.unassignedIncidentSearch)
        }

        vm.incidentSearchChanged = () => {
            vm.tirGridOptions.api.onFilterChanged()
        }

        vm.employeeSearchChanged = () => {
            vm.employeeGridOptions.api.setQuickFilter(vm.employeeSearch)
        }        


        vm.preTaskSearchChanged = () => {
            vm.preTaskGrid.api.setQuickFilter(vm.preTaskSearch)
        } 
        vm.preOpsSearchChanged = () => {
            vm.preOpsGrid.api.setQuickFilter(vm.preOpsSearch)
        } 

        vm.tirGridOptions.isExternalFilterPresent = () => {
            return vm.incidentSearch !== ""
        }

        vm.tirGridOptions.doesExternalFilterPass = (gridRow) => {
            if (vm.incidentSearch.indexOf('?') === 0) {
            var submissionId = vm.incidentSearch.replace('?submissionId=', '')
            if (gridRow.data['ID'] == submissionId) {
                return true
            }
            return false
            } else {
            for (var property in gridRow.data) {
                if (gridRow.data.hasOwnProperty(property)) {
                //any property in the row matches search box
                if ((gridRow.data[property] + "").toLowerCase().indexOf(vm.incidentSearch.toLowerCase()) > -1) {
                    return true
                }
                }
            }
            return false
            }
        }

        let preliminaryInvestigationFormDescriptionId
        let tirStatementFormDescriptionId
        let preliminaryIncidentFormDescriptionId

        vm.preliminaryInvestigationGridOptions = gridService.getCommonOptions()
        vm.tirStatementGridOptions = gridService.getCommonOptions()
        vm.preliminaryIncidentGridOptions = gridService.getCommonOptions()
        
        vm.preliminaryInvestigationGridSections = []
        vm.tirStatementGridSections = []
        vm.preliminaryIncidentGridSections = []

        vm.incident; // Drill down to this incident
        vm.rootCauseAnalysis = { submissions: [], expanded: false }

        
        /* Incident Sign Off */
        vm.managerSignoffCheckbox = false
        vm.safetySignoffCheckbox = false
        vm.jhscSignoffCheckbox = false
        vm.signoffs = []

        vm.openRootCauseAnalysisModal = () => {
            if (!vm.allowRCAEdit) {
                toastr.error(translateTag(2785)) //"Unable to add new Incident Analysis after supervisor sign-off.")
            }
            else {
                vm.openModal('rootCauseAnalysisModal')
                $scope.$broadcast('CREATE_rootCauseAnalysisModal', [])
            }
        }

        vm.editRootCauseAnalysisModal = (id, data) => {
            vm.openModal('rootCauseAnalysisModal')
            $scope.$broadcast('EDIT_rootCauseAnalysisModal', [id, data])
        }

        vm.reviewIncidentAnalysis = (rec) =>{
            // check if already reviewd - in case show taostr - already reviewed
            // call confirm review modal
            // call reviewRCA endpoint
            // refresh rca grid
            
            if(rec.rca_reviewed) {
                toastr.success(translateTag(9576))  //"You have already Acknowleged this Decision"
                return
            }

            vm.review_ia = rec

            vm.modalElementsReview = {
                title: translateTag(3414), //"Decision Review?"
                message: `<div><p>${translateTag(3415)}</p></div>`, //"You are confirming that you have reviewed this decision. This cannot be undone. Continue?"
                buttons: 
                    `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('reviewIA')" note="Review">{{vm.componentTranslateLabels(1188)}}</button>
                    <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'IAREVIEWCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsReview)
        }

        $scope.$on("IAREVIEWCALLCONFIRMMODAL", (event,result) => {
            if (result=='reviewIA') {
                vm.addAcknowledge()
            }
        })

        vm.addAcknowledge = () => {
            let payload = {
                "rca_id" : vm.review_ia.ID
            }
            rootCauseAnalysisService.reviewRca(payload).then((response) => {
                fetchIncidentForms()                
                vm.rootCauseAnalysisGridOptions.api.setRowData(prepareRootGridData(vm.rootCauseAnalyses));
                vm.rootCauseAnalysisGridOptions.api.redrawRows();
                modalService.Close('confirmModal')
            })            
        }

        vm.viewAcknowledgeHistory = (data) =>{
            if(!data.rca_reviewed_count > 0)
                return
            rootCauseAnalysisService.getRcaReviewers(data.ID).then((response) => {
                $rootScope.$broadcast("CALLHISTORYMODAL",response.data,translateLabels(2768))

            })            
        }

        profileService.getPersonProfile().then((userData) => {
            let user = profileService.readPersonProfile()
            vm.currentUser = { employeeID: user.per_id, name: user.per_full_name }            
        })

        let defaultColDef = {
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            headerCheckboxSelection: (params) => {
                let displayedColumns = params.columnApi.getAllDisplayedColumns()
                let thisIsFirstColumn = displayedColumns[0] === params.column
                return thisIsFirstColumn
            },
            checkboxSelection: (params) => {
                let displayedColumns = params.columnApi.getAllDisplayedColumns()
                let thisIsFirstColumn = displayedColumns[0] === params.column
                return thisIsFirstColumn
            }
        }
        
        vm.unassignedTirGridOptions.defaultColDef = defaultColDef
        vm.rootCauseAnalysisGridOptions.defaultColDef = rootCauseAnalysisService.getDefaultColDef()
        vm.preliminaryInvestigationGridOptions.defaultColDef = defaultColDef
        vm.preliminaryInvestigationGridOptions.headerHeight = 35
        vm.preliminaryInvestigationGridOptions.paginationPageSize = 10
        vm.tirStatementGridOptions.defaultColDef = defaultColDef
        vm.tirStatementGridOptions.headerHeight = 35
        vm.tirStatementGridOptions.paginationPageSize = 10
        vm.preliminaryIncidentGridOptions.defaultColDef = defaultColDef
        vm.preliminaryIncidentGridOptions.headerHeight = 35
        vm.preliminaryIncidentGridOptions.paginationPageSize = 10
        vm.employeeGridOptions.defaultColDef = defaultColDef

        vm.preTaskGrid.defaultColDef = defaultColDef
        vm.preOpsGrid.defaultColDef = defaultColDef
        vm.oraOptions.defaultColDef = defaultColDef

        vm.praOptions.defaultColDef = defaultColDef
        vm.jraOptions.defaultColDef = defaultColDef
        vm.bowOptions.defaultColDef = defaultColDef
        
        let employeeColumnOptions = [
            { field: "dummyCheckbox", headerName: "", minWidth: 35, maxWidth: 35, suppressMenu: true, suppressSorting: true },
            {
                field: "per_full_name",
                headerName: " ",
                minWidth: 'calc(100% - 35px)',
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab']
            }
        ]

        vm.employeeGridOptions.columnDefs = employeeColumnOptions
        vm.employeeGridOptions.headerHeight = 35


        let preTaskColumnOptions = [
            { field: "dummyCheckbox", headerName: "", minWidth: 35, maxWidth: 35, suppressMenu: true, suppressSorting: true },
            {
                field: "submission_date",
                headerName: " ",
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab']
            },
            {
                field: "employee_name",
                headerName: " ",
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab']
            },
            {
                field: "workplace",
                headerName: " ",
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab'],
                minWidth: 150
            },
            {   
                field: "id",
                hide: true
            }

        ]

        vm.preTaskGrid.columnDefs = preTaskColumnOptions
        vm.preTaskGrid.headerHeight = 35

        let preOPsColumnOptions = [
            { field: "dummyCheckbox", headerName: "", minWidth: 35, maxWidth: 35, suppressMenu: true, suppressSorting: true },
            {
                field: "submission_date",
                headerName: " ",
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab']
            },
            {
                field: "employee_name",
                headerName: " ",
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab']
            },
            {
                field: "equipment_id",
                headerName: " ",
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab']
            },
            {
                field: "id",
                hide : true
            }

        ]

        vm.preOpsGrid.columnDefs = preOPsColumnOptions
        vm.preOpsGrid.headerHeight = 35

        vm.assignDisabled = true
        vm.unassignedTirGridOptions.onSelectionChanged = (params) => {
            vm.assignDisabled = vm.unassignedTirGridOptions.api.getSelectedRows().length === 0
            let selectedRows = vm.unassignedTirGridOptions.api.getSelectedRows()
            let urlParams = ""
            let ids = []
            for (let i = 0; i < selectedRows.length; i++) {
                urlParams += "&ids=" + selectedRows[i].SubmissionHeaderID
                ids.push(selectedRows[i].SubmissionHeaderID)
            }
            vm.SubmissionIDs = ids
            vm.reportInputs = urlParams
            $scope.$apply()
        }

        vm.preliminaryInvestigationGridOptions.onSelectionChanged = (params) => {
            vm.selectedSubmissionHeaderId = vm.calculateSelectedHeaderId()
            $scope.$apply()
        }

        vm.tirStatementGridOptions.onSelectionChanged = (params) => {
            vm.selectedSubmissionHeaderId = vm.calculateSelectedHeaderId()
            $scope.$apply()
        }

        vm.preliminaryIncidentGridOptions.onSelectionChanged = (params) => {
            vm.selectedSubmissionHeaderId = vm.calculateSelectedHeaderId()
            $scope.$apply()
        }

        vm.calculateSelectedHeaderId = () => {
            let selectedId
            let prelimIncidents = vm.preliminaryIncidentGridOptions.api.getSelectedRows()
            let tirStatements = vm.tirStatementGridOptions.api.getSelectedRows()
            let prelimInvestigations = vm.preliminaryInvestigationGridOptions.api.getSelectedRows()
            if ((prelimIncidents.length + tirStatements.length + prelimInvestigations.length) !== 1) {
                selectedId = null
                return selectedId
            }

            if (prelimIncidents.length == 1) {
                selectedId = prelimIncidents[0].ID
                return selectedId
            }
            if (tirStatements.length == 1) {
                selectedId = tirStatements[0].ID
                return selectedId
            }
            if (prelimInvestigations.length == 1) {
                selectedId = prelimInvestigations[0].ID
                return selectedId
            }
        }

        vm.rootCauseAnalysisGridOptions.onSelectionChanged = (params) => {
            vm.assignDisabled = vm.rootCauseAnalysisGridOptions.api.getSelectedRows().length === 0
            let selectedRows = vm.rootCauseAnalysisGridOptions.api.getSelectedRows()
            let urlParams = ""
            let ids = []
            for (let i = 0; i < selectedRows.length; i++) {
                urlParams += "&ids=" + selectedRows[i].SubmissionHeaderID
                ids.push(selectedRows[i].SubmissionHeaderID)
            }
            vm.SubmissionIDs = ids
            vm.reportInputs = urlParams
            $scope.$apply()
        }

        vm.previewImage = (fileName) => {
            vm.imagePreviewURL = `${__env.imageUrl}incident_attachments/${vm.incident.IncidentNumber}/${fileName}`
            vm.openModal('imagePreviewModal');
        }

        vm.prepExport = () => {
            let exportFields = [];
            for (let i = 0; i < vm.gridSections.length; i++) {
                if (vm.gridSections[i].children != undefined) {
                    for (let j = 0; j < vm.gridSections[i].children.length; j++) {
                        exportFields.push(vm.gridSections[i].children[j].field);
                    }
                }
            }

            return {
                onlySelected: true,
                columnKeys: exportFields,
                processCellCallback: (params) => {
                    if (!!params.column.colDef.isAttachment) {
                        return params.value.length;
                    }
                    return params.value;
                }
            };
        }

        //#region  Attachments
        $scope.fileNameChanged = (event)=> {

            let onlyImages = false
            if(vm.activeSection == 741)
                onlyImages = true

            let existingFileNames = []
            for(let i in vm.attachmentFiles) {
                existingFileNames.push(vm.attachmentFiles[i].rawFileName)
            }

            //Add newly selected files after checking for duplicates and correct file types
            let newFiles = fileUploadService.checkFileUpload(event.target.files, existingFileNames, onlyImages)

            let fd = new FormData()
            fd.append('section', vm.activeSection)
            fd.append('incidentId', vm.incident.ID)
            fd.append('incidentNumber', vm.incident.IncidentNumber)
            for (var i in newFiles) {
                fd.append("myfile", newFiles[i]);
            }      
            

            tirService.uploadIncidentAttachments(fd).then((response)=>{
                vm.incidentModified = true
                vm.getIncidentAttachments()
            })
        }

        vm.setActiveSection = (section) => {
            vm.activeSection = section
        }

        vm.attachmentFiles = []
        vm.attachmentSort = 'FileName'

        vm.getIncidentAttachments = () => {
            tirService.getIncidentAttachments(vm.incident.ID)
                .then(function (response) {
                    vm.attachmentFiles.length = 0
                    vm.attachmentFiles.push.apply(vm.attachmentFiles, response)
                    vm.attachmentFiles = vm.attachmentFiles.map((att) => {
                        att.newFileName = att.FileName
                        att.LastModified == null ? att.LastModified = Number.POSITIVE_INFINITY : att.LastModified = att.LastModified                        
                        if(att.FileName.substr(0,att.FileName.lastIndexOf('_')) !== '')                     
                            att.rawFileName = att.FileName.substr(0,att.FileName.lastIndexOf('_'))+att.FileType         
                        else
                            att.rawFileName = att.FileName
                        return att
                    })
                }, (args) => {
                    console.log("Error Getting Incident Attachments", args)
                 })
        }

        vm.deleteIncidentAttachment = (id) => {
            tirService.deleteIncidentAttachment(id)
                .then((fn) => {
                    vm.incidentModified = true
                    formsService.updateIncidentAssociated(vm.incident.ID)
                    vm.getIncidentAttachments();
                })
            vm.closeModal('confirmModal')
        }

        vm.downloadAttachment = (att) => {

        }
        vm.renameAttachment = (att) => {
            att.IncidentNumber = vm.incident.IncidentNumber
            checkRenameFile(att)
            tirService.renameIncidentAttachment(att).then(() => {
                vm.incidentModified = true
                vm.getIncidentAttachments();
            })
        }
        
        // make sure extension (jpg, pdf, png) is not changed - if changed rename with orignial extension. 
        function checkRenameFile(att) {
          let oldFile = att.FileName.toLowerCase().split('.')
          let newFile = att.rawFileName.toLowerCase().split('.')  
          oldext = oldFile[oldFile.length - 1]
          newext = newFile[newFile.length - 1]
          if(newFile.length > 1 && newext !== oldext) {
              let fixFile = ''
              for(let a=0; a < newFile.length -1; a++) {
                fixFile += `${newFile[a]}.`
              }
              att.rawFileName = `${fixFile}${oldext}`
          } 
          else {
                if(newFile[0]){
                    att.rawFileName = `${att.rawFileName}.${oldext}`
                }
                else {
                att.rawFileName = att.FileName
                }
          }
        }
        //#endregion

        vm.openModal = (id) => {
            if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                $scope.$apply()

            $('.modal .scroll').scrollTop(0)
            modalService.Open(id)
        }

        vm.closeModal = (id) => {
            modalService.Close(id)
        }
        
        vm.prepareDelete = (attachment) => {
            vm.attachment = attachment
            vm.modalElementsDelete = {
                title: translateTag(3739), //"DELETE FILE"
                message: `<div><p>${translateTag(3738)} ${vm.attachment.FileName}?</p></div>`, //"Are you sure you want to delete the file"
                buttons: `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="DELETE FILE">{{vm.componentTranslateLabels(3739)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'TIRDELETECALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsDelete)
        }

        $scope.$on("TIRDELETECALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.deleteIncidentAttachment(vm.attachment.ID)
            }
        })

        //Column settings for Incident Reports Ag-Grid on main page
        let tirColumns1 = [
            {
                field: "",
                headerName: "",
                minWidth: 40,
                maxWidth: 40,
                suppressMenu: true,
                cellRenderer: (params) => {
                    let reportURL = params.data.ReportURL
                    let showReportLink = !!reportURL
                    if (showReportLink)
                        return `<span class="pointer text-left" ng-click="tir.openIncidentReport($event, '${params.data.ReportURL}','${params.data.IncidentNumber}')"><i class="fa fa-external-link-alt" title="${translateTag(3429)}"></i></span>`
                    else
                        return '<div class="Aligner"></div>'

                }, filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab']
            },
            {
                field: 'ID',
                hide: true,
            },
            {
                field: "IncidentNumber",
                headerName: " ",
                minWidth: 100,
                maxWidth: 100,
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                sort: 'Desc',
            },
            {
                field: "CreatedDate",
                headerName: " ",
                minWidth: 150,
                maxWidth: 150,
                cellClass: 'tir-cell',
                cellRenderer: 'tippyCellRenderer',
                menuTabs: ['filterMenuTab'],
            },
            {
                field: "created_by_name",
                headerName: " ",
                minWidth: 150,
                maxWidth: 200,
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "LastModifiedDate",
                headerName: " ",
                minWidth: 150,
                maxWidth: 150,
                cellClass: 'tir-cell',
                cellRenderer: 'tippyCellRenderer',
                menuTabs: ['filterMenuTab'],
            },
            {
                field: "ModifiedBy",
                headerName: " ",
                minWidth: 150,
                maxWidth: 200,
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Description",
                headerName: " ",
                cellClass: 'tir-cell',
                minWidth: 200,
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },            
            {
                field: "HeaderDate",
                headerName: " ",
                minWidth: 120,
                maxWidth: 120,
                cellClass: 'tir-cell',
                cellRenderer: 'tippyCellRenderer',
                menuTabs: ['filterMenuTab']
            },
            {
                field: "Site",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Status",
                headerName: " ",
                minWidth: 90,
                maxWidth: 90,
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
        ]

        //Column settings for Existing Incident Forms Ag-Grid inside assign to dropdown main page        
        let existingIncidentColumns = [
            {
                field: "IncidentNumber",
                headerName: " ",
                minWidth: 100,
                maxWidth: 150,
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Site",
                headerName: " ",
                minWidth: 100,
                maxWidth: 250,
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Description",
                headerName: " ",
                minWidth: 200,
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
        ]

        //Function to open review confirmation modal
        vm.signoff = (headerData) => {
            vm.headerDataContext = headerData
            if (headerData.signed_by_per != null) {
                toastr.success(translateTag(2834)) //("You have already Acknowledged this submission")
            } 
            else {
                vm.modalElementsSignoff = {
                    title: translateTag(2171), //"Submission Review?"
                    message: `<div><p>${translateTag(2172)}</p></div>`, //"You are now confirming that you have reviewed this submission. This action cannot be undone. Continue?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="OK">{{vm.componentTranslateLabels(1405)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>` 
                }
                document.getElementById('confirmcallingform').innerHTML = 'FORMSIGNOFFCALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsSignoff)
            }
        }

        $scope.$on("FORMSIGNOFFCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.confirmSignoff(vm.headerDataContext)
            }
        })

        //Function to add review
        vm.confirmSignoff = (headerData) => {
            signoffService.addSignoff(headerData.SubmissionHeaderID)
            .then((newSignoffId) => {
                if (newSignoffId.Payload != null) {
                    headerData.signed_by_per = newSignoffId.Payload
                    headerData.signoff_count = headerData.signoff_count + 1
                }
                modalService.Close('confirmModal')
            })                 
        }

        //Function to open view review history modal
        vm.viewSignoffHistory = (rowData) => {
            if (!rowData.signoff_count) {
                return
            }
            vm.currentSignoffHistory = []
            signoffService.getSignoffsByHeader(rowData.SubmissionHeaderID).then((data) => {
                data.map((rec)=>{
                    rec.name = rec.SigningName
                    rec.reviewed_date=rec.SigningTimestamp
                    rec.pos=rec.sus_position
                    delete rec.SigningName
                    delete rec.SigningTimestamp
                    delete rec.sus_position
                  })
                vm.currentSignoffHistory = data
                $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentSignoffHistory,translateLabels(3733))  //"Submission Reviews"
            })
        }
        
        //Column settings for Unassigned Incidents Ag-Grid on main page
        let unassignedTirColumns = [
            { 
                field: "dummyCheckbox", 
                headerName: "", 
                minWidth: 50, 
                maxWidth: 50, 
                suppressMenu: true, 
                suppressSorting: true 
            },
            {
                field: "review",
                headerName: " ",
                minWidth: 100,
                maxWidth: 100,
                suppressMenu: true,
                cellRenderer: (params) => {                              
                return `<span
                                ng-click = 'tir.signoff(data)'
                                class="{{ data.signed_by_per != null ? 'text-success ' : 'pointer'}}" 
                                note="Review Submission" 
                                title="{{menu.translateLabels(3431)}}">
                                <i class="far fa-file-alt fa-lg"></i>
                        </span>`
                        + '<span note="Submission Review History" title="{{menu.translateLabels(3430)}}" class="source signoff-count" ng-class="{ transparent: !data.signoff_count, pointer: !!data.signoff_count }" ng-click="tir.viewSignoffHistory(data);">{{ data.signoff_count }}</span>'
                        + `<span class="pointer text-left" ng-click="tir.openReport($event, '${params.data.ReportURL}','${params.data.SubmissionHeaderID}')"><i class="fa fa-external-link-alt" title="${translateTag(3429)}"></i></span>` // Launch Report
                },
                valueGetter: function (params) {
                    return params.data.signoff_count
                },
            },            
            {
                field: 'SubmissionHeaderID',
                hide: true,
                sort: 'desc',
            },
            {
                field: "SubmissionDate",
                headerName: " ",
                minWidth: 150,
                maxWidth: 150,
                cellClass: 'tir-cell',
                cellRenderer: 'tippyCellRenderer',
                menuTabs: ['filterMenuTab'],                
            },
            {
                field: "SubmittedBy",
                headerName: " ",
                cellClass: 'tir-cell',              
                minWidth: 150,
                maxWidth: 200,
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "FormName",
                headerName: " ",                
                minWidth: 150,
                cellRenderer: 'tippyCellRenderer'
            },
            {
                field: "HeaderDate",
                headerName: " ",
                minWidth: 120,
                maxWidth: 120,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Site",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                cellClass: 'tir-cell',              
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer'
            },
            {
                field: "JobNumber",
                headerName: " ",
                minWidth: 130,
                maxWidth: 150,
                cellClass: 'tir-cell',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer'
            },            
        ]
        

        //Set Ag-Grid colum values/settings
        let oraColumns = [
            { 
                field: " ", 
                headerName: " ", 
                minWidth: 35, 
                maxWidth: 35, 
                suppressMenu: true, 
                suppressSorting: true 
            },
            {
                field: "rmm_ora_created_date",
                headerName: " ",
                minWidth: 100,
                maxWidth: 140,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
            },
            {
                field: "rmm_ora_created_by_per",
                headerName: " ",
                minWidth: 100,
                maxWidth: 220,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "rmm_ora_expiry_date",
                headerName: " ",
                minWidth: 120,
                maxWidth: 140,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: (params) => {
                    let expiryDate = new Date(params.data.rmm_ora_expiry_date)
                    let currentDate = new Date()
                    if (expiryDate < currentDate)
                        return '<div style="color: #D20000;">' + params.data.rmm_ora_expiry_date + '</div>'
                    else
                        return '<div>' + params.data.rmm_ora_expiry_date + '</div>'
                    }
            },
            {
                field: "rmm_ora_title",
                headerName: " ",
                minWidth: 150,
                maxWidth: 1000,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "rmm_ora_site",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "rmm_ora_revision_no",
                headerName: " ",
                minWidth: 120,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "rmm_ora_state",
                headerName: " ",
                maxWidth: 120,
                minWidth: 120,
                suppressMenu: false,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                valueGetter: (params) => {
                    if (params.data.rmm_ora_state === 'draft'){
                        return translateTag(1399)
                    }
                    if (params.data.rmm_ora_state === 'expired'){
                        return translateTag(3494)
                    } 
                    if (params.data.rmm_ora_state == 'review'){
                        return translateTag(1188)
                    } 
                    if (params.data.rmm_ora_state == 'active'){
                        return translateTag(3557)
                    }
                },
            },              
            {field:"hasReviewed", hide:true},
            {field:"participantsList", hide:true},
            {field:"reviewersList", hide:true},
            {field:"reviewedCount", hide:true},
            {field:"rmm_ora_is_submitted", hide:true},
            {field:"rmm_ora_executive_summary", hide:true},
            {field:"rmm_ora_other_participants", hide:true},
            {field:"approversList", hide:true},
            {field:"rmm_ora_revision_no", hide:true},
            {field:"rmm_ora_doc_version_number", hide:true},
            {field:"rmm_ora_document_number", hide:true},
            {field:"rmm_ora_id", hide:true},
            {field:"rmm_ora_date", hide:true},
            {field:"rmm_ora_scope", hide:true},
        ]
      
        vm.oraOptions.columnDefs = oraColumns

        let praColumns = [
            { 
                field: " ", 
                headerName: " ", 
                minWidth: 35, 
                maxWidth: 35, 
                suppressMenu: true, 
                suppressSorting: true 
            },
            {
                field: "rmm_pra_created_date",
                headerName: " ",
                minWidth: 100,
                maxWidth: 140,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
            },
            {
                field: "rmm_pra_created_by_per",
                headerName: " ",
                minWidth: 100,
                maxWidth: 220,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "rmm_pra_expiry_date",
                headerName: " ",
                minWidth: 120,
                maxWidth: 140,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: (params) => {
                    let expiryDate = new Date(params.data.rmm_pra_expiry_date)
                    let currentDate = new Date()
                    if (expiryDate < currentDate)
                        return '<div style="color: #D20000;">' + params.data.rmm_pra_expiry_date + '</div>'
                    else
                        return '<div>' + params.data.rmm_pra_expiry_date + '</div>'
                  }
            },
            {
                field: "rmm_pra_title",
                headerName: " ",
                minWidth: 150,
                maxWidth: 1000,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "rmm_pra_site",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "rmm_pra_revision_no",
                headerName: " ",
                minWidth: 120,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "rmm_pra_state",
                headerName: " ",
                maxWidth: 120,
                minWidth: 120,
                suppressMenu: false,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                valueGetter: (params) => {
                    if (params.data.rmm_pra_state === 'draft'){
                        return translateTag(1399)
                    }
                    if (params.data.rmm_pra_state === 'expired'){
                        return translateTag(3494)
                    } 
                    if (params.data.rmm_pra_state == 'review'){
                        return translateTag(1188)
                    } 
                    if (params.data.rmm_pra_state == 'active'){
                        return translateTag(3557)
                    }
                },
            },              
            {field:"hasReviewed", hide:true},
            {field:"participantsList", hide:true},
            {field:"reviewersList", hide:true},
            {field:"reviewedCount", hide:true},
            {field:"rmm_pra_is_submitted", hide:true},
            {field:"rmm_pra_executive_summary", hide:true},
            {field:"rmm_pra_other_participants", hide:true},
            {field:"approversList", hide:true},
            {field:"rmm_pra_revision_no", hide:true},
            {field:"rmm_pra_doc_version_number", hide:true},
            {field:"rmm_pra_document_number", hide:true},
            {field:"rmm_pra_id", hide:true},
            {field:"rmm_pra_date", hide:true},
            {field:"rmm_pra_scope", hide:true},
            {field:"ora_events", hide:true},
            {field:"rmm_pra_workplace", hide:true},
        ]

        vm.praOptions.columnDefs =praColumns

           //Set Ag-Grid colum values/settings
           let jraColumns = [
            {
                field: " ", 
                headerName: " ", 
                minWidth: 35, 
                maxWidth: 35, 
                suppressMenu: true, 
                suppressSorting: true 
            },
            {
                field: "rmm_jra_created_date",
                headerName: " ",
                minWidth: 100,
                maxWidth: 140,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                sort: 'desc',
            },
            {
                field: "rmm_jra_created_by_per",
                headerName: " ",
                minWidth: 100,
                maxWidth: 220,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "rmm_jra_expiry_date",
                headerName: " ",
                minWidth: 120,
                maxWidth: 140,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: (params) => {
                    let expiryDate = new Date(params.data.rmm_jra_expiry_date)
                    let currentDate = new Date()
                    if (expiryDate < currentDate)
                        return '<div style="color: #D20000;">' + params.data.rmm_jra_expiry_date + '</div>'
                    else
                        return '<div>' + params.data.rmm_jra_expiry_date + '</div>'
                  }
            },
            {
                field: "rmm_jra_title",
                headerName: " ",
                minWidth: 150,
                maxWidth: 1000,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "rmm_jra_site",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "rmm_jra_job",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "rmm_jra_revision_no",
                headerName: " ",
                minWidth: 120,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "rmm_jra_state",
                headerName: " ",
                maxWidth: 120,
                minWidth: 120,
                suppressMenu: false,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                valueGetter: (params) => {
                    if (params.data.rmm_jra_state === 'draft'){
                        return translateTag(1399)
                    }
                    if (params.data.rmm_jra_state === 'expired'){
                        return translateTag(3494)
                    } 
                    if (params.data.rmm_jra_state == 'review'){
                        return translateTag(1188)
                    } 
                    if (params.data.rmm_jra_state == 'active'){
                        return translateTag(3557)
                    }
                },
            },              
            {field:"hasReviewed", hide:true},
            {field:"participantsList", hide:true},
            {field:"reviewersList", hide:true},
            {field:"reviewedCount", hide:true},
            {field:"rmm_jra_is_submitted", hide:true},
            {field:"rmm_jra_executive_summary", hide:true},
            {field:"rmm_jra_other_participants", hide:true},
            {field:"approversList", hide:true},
            {field:"rmm_jra_revision_no", hide:true},
            {field:"rmm_jra_pra", hide:true},
            {field:"rmm_jra_workplace", hide:true},
            {field:"rmm_jra_doc_version_number", hide:true},
            {field:"rmm_jra_document_number", hide:true},
            {field:"rmm_jra_id", hide:true},
            {field:"applicable_line_items", hide:true},
            {field:"rmm_jra_date", hide:true},
            {field:"rmm_jra_scope", hide:true},
        ]
        vm.jraOptions.columnDefs = jraColumns


            //Set Ag-Grid colum values/settings
            let bowColumns = [
                { 
                    field: " ", 
                    headerName: " ", 
                    minWidth: 35, 
                    maxWidth: 35, 
                    suppressMenu: true, 
                    suppressSorting: true 
                },
                {
                    field: "rmm_bow_created_date",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 140,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                },
                {
                    field: "rmm_bow_created_by_per",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 220,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_bow_expiry_date",
                    headerName: " ",
                    minWidth: 120,
                    maxWidth: 140,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        let expiryDate = new Date(params.data.rmm_bow_expiry_date)
                        let currentDate = new Date()
                        if (expiryDate < currentDate)
                            return '<div style="color: #D20000;">' + params.data.rmm_bow_expiry_date + '</div>'
                        else
                            return '<div>' + params.data.rmm_bow_expiry_date + '</div>'
                      }
                },
                {
                    field: "rmm_bow_title",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 1000,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_bow_site",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_bow_revision_no",
                    headerName: " ",
                    minWidth: 120,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_bow_state",
                    headerName: " ",
                    maxWidth: 120,
                    minWidth: 120,
                    suppressMenu: false,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    valueGetter: (params) => {                        
                        if (params.data.rmm_bow_state === 'draft'){
                            return translateTag(1399)
                        }
                        if (params.data.rmm_bow_state === 'expired'){
                            return translateTag(3494)
                        } 
                        if (params.data.rmm_bow_state === 'review'){
                            return translateTag(1188)
                        } 
                        if (params.data.rmm_bow_state === 'active'){
                            return translateTag(3557)
                        }
                    },
                },              
                {field:"hasReviewed", hide:true},
                {field:"participantsList", hide:true},
                {field:"reviewersList", hide:true},
                {field:"reviewedCount", hide:true},
                {field:"rmm_bow_is_submitted", hide:true},
            ]
            vm.bowOptions.columnDefs = bowColumns



        vm.openReport = (e, report, id)=>{
            if(!e.ctrlKey){
                lang_number = localStorage.getItem('lang_id')
                vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${report}/${id}?lang=${lang_number}&t=${vm.token}`)
                $window.open(vm.reportURL, "_blank")
            }
        } 

        vm.back = ()=>{
            vm.reportURL = null
        }


        vm.initializeSelect2 = (parent)=> {
       
            setTimeout(()=>{
            $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} .modal-body`), escapeMarkup: function (text) { return text } })
                .on('select2:select', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list')){
                        $rootScope.$broadcast('distribution-list-added', event)
                    }

                    $(this).parent().find('label').addClass('filled')   
                })
                .on('select2:unselect', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list')){
                        $rootScope.$broadcast('distribution-list-removed', event)
                    }
                    $(this).parent().find('label').addClass('filled')
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()
            }, 500)
            if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
            $('.datepicker').pickadate({
                format: 'yyyy-mm-dd',
                onClose : function(){
                    this.$holder.blur()
                },
            }).removeAttr('readonly')
            .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                evt.preventDefault()
            })

            preventFutureDatePickerInit()

            let pickadateTranslations = sofvie_pickatime_languages[`${selectedLanguage}`]
            $('.timepicker').pickatime({
                donetext: pickadateTranslations.done,
                cleartext: pickadateTranslations.clear,
                twelvehour: true, 
                'default': '24:00'
            })
        }

        //Function to open modals
        vm.openHazardActionModal = (modalId, mode = 'new', id) => {
           
            vm.actionMode = mode           
            if(mode === 'edit' && modalId === 'hazardActionModal') {               
                openHazardEdit(id, modalId)
            }
            else
            {
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()            

                $('.modal .scroll').scrollTop(0)

                modalService.Open(modalId)
                vm.initializeSelect2(modalId)
            }            
        }

        // tir actions section
        vm.openActionEditModal = (modalId, id, status) => {            
            if(status.toLowerCase() === 'complete'){
                toastr.error(translateTag(3661)) // The selected incident has already been submitted
                return
            }

            vm.actionMode = 'edit'
            if(modalId === 'generalActionModal') {
                openGeneralEdit(id, modalId)
            }
            else if(modalId === 'hazardActionModal') {
                openHazardEdit(id, modalId)
            }
        }

        vm.getStatusLowerCase = (status) => {
            return status.charAt(0).toUpperCase() + status.slice(1,).toLowerCase()
        }

        vm.completeActionModal = (action) => {
            if(action.action_type === 'General') {   
                getGeneralActionData(action)
            } else {
                getHazardActionsData(action)
            } 
        }

      

        //Function to prepare data to edit a hazard action
        function openHazardEdit(id, modalId) {            
            actionManagementService.getHazardActionSingle({hap_id: id}).then ((response) => {
                vm.hazardEditData = response

                vm.hazardEditData.Site = parseInt(vm.hazardEditData.Site)
                vm.hazardEditData.JobNumber = parseInt(vm.hazardEditData.JobNumber)
                vm.hazardEditData.SiteLevel = parseInt(vm.hazardEditData.SiteLevel)
                vm.hazardEditData.Supervisor = vm.hazardEditData.Supervisor

                vm.hazardEditData.HeaderDate = moment(vm.hazardEditData.HeaderDate).format('YYYY-MM-DD')
                vm.hazardEditData.action_by_who =  parseInt(vm.hazardEditData.action_by_who)

                let i = 0
                let initialAtt = JSON.parse(JSON.stringify(vm.hazardEditData.attachments))
                initialAtt.forEach((att) => {
                    if(att.attachmenttype === 'FOLLOWUP')
                        vm.hazardEditData.attachments.splice(i, 1)
                    else
                        i++
                })
                
                vm.hazardEditData.attachments.forEach((att) => {
                    att.imageDir = `${__env.imageUrl}/`
                })
                
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()      


                $('.modal .scroll').scrollTop(0)
                modalService.Open(modalId)              
                vm.initializeSelect2(modalId)
                setTimeout(()=>{
                    $scope.$broadcast('HAZARD_EDIT_OPENED')
                },100)
            })
        }

        function openGeneralEdit(id, modalId) {
            actionManagementService.getGeneralActionSingle({sga_id: id}).then ((response) => {
                vm.generalEditData = response

                vm.generalEditData.Site = parseInt(vm.generalEditData.Site)
                vm.generalEditData.JobNumber = parseInt(vm.generalEditData.JobNumber)
                vm.generalEditData.SiteLevel = parseInt(vm.generalEditData.SiteLevel)
                vm.generalEditData.Supervisor = parseInt(vm.generalEditData.Supervisor)

                vm.generalEditData.HeaderDate = moment(vm.generalEditData.HeaderDate).format('YYYY-MM-DD')
                vm.generalEditData.sga_action_by_who_per_id = vm.generalEditData.sga_action_by_who_per

                let i = 0
                let initialAtt = JSON.parse(JSON.stringify(vm.generalEditData.attachments))
                initialAtt.forEach((att) => {
                    if(att.gaa_type === 'FOLLOWUP')
                        vm.generalEditData.attachments.splice(i, 1)
                    else
                        i++
                })
                
                vm.generalEditData.attachments.forEach((att) => {
                    att.imageDir = `${__env.imageUrl}/`
                })
                
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()            

                $('.modal .scroll').scrollTop(0)

                modalService.Open(modalId)
                vm.initializeSelect2(modalId, '.modal-body')
            })
        }

        //Funtion to convert employee ID to Name
        function getEmployeeName(value) {
            let name = value
            vm.fullEmployeeList.forEach((emp)=>{
                if(emp.per_id == value) {
                    name = emp.per_full_name
                }
            })
            return name
        }

        function getEmployeeID(value) {
            let nameID = value
            vm.fullEmployeeList.forEach((emp)=>{
                if(emp.per_full_name == value) {
                    nameID = emp.per_id
                }
            })
            return nameID
        }


        function getSiteName(value) {
            let name = value
            vm.site_name.forEach((s)=>{
                if(s.rld_id == value) {
                    name = s.rld_name
                }
            })
            return name
        }

        function getJobNumber(value) {
            let name = value
            vm.job_name.forEach((j)=>{
            if(j.rld_id == value) {
                name = j.rld_code
            }
            })
            return name
        }
     
        function getActionTypeName(value) {
            let name = value
            vm.actionTypeList.forEach((at)=>{
                if(at.rld_id == value) {
                    name = at.rld_name
                }
            })
        return name   
        }

        function getActionTypeID(value) {
            let nameID = value
            vm.actionTypeList.forEach((at)=>{
                if(at.rld_name == value) {
                    nameID = at.rld_id
                }
            })
            return nameID
        }



        vm.tirGridOptions.columnDefs = tirColumns1
        vm.tirGridOptions.headerHeight = 35
        vm.tirGridOptions.suppressHorizontalScroll = false
        vm.existingIncidentsGridOptions.columnDefs = existingIncidentColumns
        vm.existingIncidentsGridOptions.headerHeight = 35
        vm.unassignedTirGridOptions.columnDefs = unassignedTirColumns
        vm.unassignedTirGridOptions.headerHeight = 35
        vm.rootCauseAnalysisGridOptions.columnDefs = rootCauseAnalysisService.getColumns()
        vm.correctiveActionsGridOptions.headerHeight = 35
        vm.correctiveActionsGridOptions.paginationPageSize = 10
        vm.hapFollowupComponentModalId = "hapFollowupComponent";
        vm.gapFollowupComponentModalId = "gapFollowupComponent";
        
        //Hazard Action Followup
        function getHazardActionsData(action)  {
            vm.currentIncidentid = vm.incident.ID
            actionManagementService.getHazardActionSingle({hap_id: action.ID}).then((response)=>
            {                
                vm.followupAction = response                
                if(!vm.followupAction.action_completed_date){
                    vm.followupAction.action_completed_date = dateToday.format('YYYY-MM-DD')
                }
                vm.followupAction.action_complete_by_who = (vm.followupAction.action_complete_by_who && vm.followupAction.action_complete_by_who != 'None') ? parseInt(getEmployeeID(vm.followupAction.action_complete_by_who)) : null
                vm.followupAction.attachmentModalFiles = []
                vm.followupAction.followupAttachmentModalFiles = []
                vm.followupAction.action_status = vm.followupAction.action_status.toLowerCase() == translateTag(2045).toLowerCase() ? translateTag(2045): translateTag(5028) // 'INCOMPLETE'

                vm.followupAction.attachments.forEach((attRec) => {
                    if(attRec.attachmenttype === 'INITIAL')
                    {
                        attRec.imageDir = `${__env.imageUrl}/`
                        attRec.AttachmentFileName = attRec.attachmentfilename
                        vm.followupAction.attachmentModalFiles.push(attRec) 
                    }
                    else if(attRec.attachmenttype === 'FOLLOWUP')
                    {
                        attRec.imageDir = `${__env.imageUrl}/`
                        attRec.AttachmentFileName = attRec.attachmentfilename
                        vm.followupAction.followupAttachmentModalFiles.push(attRec) 
                    }
                })
                
                vm.followupAction.HapId = action.ID
                vm.followupAction.action_by_who_name = getEmployeeName(vm.followupAction.action_by_who)
                vm.followupAction.modalId = 'hapFollowupComponent'
                                
                vm.openModal('hapFollowupComponent')
                vm.initializeSelect2('hapFollowupComponent')
                setTimeout(()=>{
                    $scope.$broadcast('HAZARD_FOLLOWUP_OPENED')
                },100)
            })

        }


        //Functions to open complete/followup general action
        function getGeneralActionData(action) {

            actionManagementService.getGeneralActionSingle({sga_id: action.ID}).then((response)=>
            {
                vm.generalFollowup = response
                if(!vm.generalFollowup.sga_completed_action_date){
                    vm.generalFollowup.sga_completed_action_date = dateToday.format('YYYY-MM-DD')    
                }
                if(vm.generalFollowup.sga_completed_action_by_who_per != null)
                    vm.generalFollowup.sga_completed_action_by_who_per_id = getEmployeeID(vm.generalFollowup.sga_completed_action_by_who_per)
                vm.generalFollowup.attachment_files_initial = []
                vm.generalFollowup.attachment_files_followup = []
                vm.generalFollowup.sga_action_by_who_per_id = getEmployeeName( vm.generalFollowup.sga_action_by_who_per)

                vm.generalFollowup.attachments.forEach((attRec) => {
                    if(attRec.gaa_type == 'INITIAL')
                    {
                        attRec.imageDir = `${__env.imageUrl}/`
                        vm.generalFollowup.attachment_files_initial.push(attRec) 
                    }
                    else if(attRec.gaa_type == 'FOLLOWUP')
                    {
                        attRec.imageDir = `${__env.imageUrl}/`
                        vm.generalFollowup.attachment_files_followup.push(attRec) 
                    }
                })


                vm.openModal('completeGeneralActionModal')
                vm.initializeSelect2('completeGeneralActionModal')
                setTimeout(()=>{
                    $scope.$broadcast('GENERAL_FOLLOWUP_OPENED')
                },100) 
            })
        }

        // Show the Incident-Viewer; a.k.a. the details view for an Incident containing all related submissions.
        vm.tirGridOptions.onCellClicked = (params) => {
            vm.resetModal()
            vm.quickSignOffState = false
            vm.incidentModified = false
            if (!vm.canManageIncidents)
            {
                toastr.error(translateTag(3662)) // "You do not have permission to manage Incidents"
                return
            }
            if (params.colDef.headerName == "") {
                return
            }
            $scope.$emit('STARTSPINNER', translateTag(3589))  // Loading data...

            
            vm.incident = params.data
            vm.loadQuickSignOffInfo(vm.incident)
            
            if(vm.preOps == null){
               $q.all([tirService.getAllPreOps()]).then(() => {
                    vm.preOps = tirService.readAllPreOps()    
               }) 
            }
            if(vm.preTasks == null){
                $q.all([tirService.getAllPreTasks()]).then(() => {
                    vm.preTasks = tirService.readAllPreTasks() 
                }) 
             }
             if(vm.oraAGData == null){

                $q.all([oraService.getOraList(rmmFilter)]).then(() => {
                    vm.oraAGData = oraService.readOraList() 
                }) 
             }                  
             if(vm.preTasks == null){
                $q.all([jraService.getJraList(rmmFilter)]).then(() => {
                    vm.jraAGData = jraService.readJraList()
                }) 
             }
             if(vm.preTasks == null){
                $q.all([praService.getPraList(rmmFilter)]).then(() => {
                    vm.praAGData = praService.readPraList()
                }) 
             } 

            resetActiveSection()
            $scope.$apply()
            vm.getIncidentAttachments()
            vm.setUserRoleSignOffs()

        }

        vm.loadQuickSignOffInfo = (incident) => {

            if(incident.inc_is_quick_signoff == 1){
                let payload = {
                    "incident_id": incident.ID
                }

                tirSignoffService.quickSignOffInfo(payload).then(data => {
                    let signOffInfo = data.data.quicksignoff_info[0]
                    let lbl = `${signOffInfo.per_full_name} - ${signOffInfo.role_names} - ${moment(signOffInfo.iqn_created_date).format('YYYY-MM-DD hh:mm:ss A')}`
                    
                    vm.quickSignOffInfo = lbl
                    vm.quickSignOffNote = signOffInfo.iqn_note
                })
            }
             
        }


        vm.existingIncidentsGridOptions.onRowClicked = (params) => {
            $q.all([
               tirService.validateSubmissionIdsExists(vm.SubmissionIDs)
            ]).then((count) => {
                if(count>0){
                    modalService.Close("existingIncidentsModal")
                    vm.validationExistingSubIdsModal()
                }
                else
                    vm.assignToExistingIncident(params.data)
            })
        }

        vm.viewerClosed = true
        vm.showIncidentViewer = () => {
            if (vm.incident == null) {
                vm.viewerClosed = true
                return false
            }

            // fetch relevant incident form submissions
            if (vm.viewerClosed) {
                fetchIncidentForms();
            }
            return true
        }

        $scope.$on("Upsert_RootCauseAnalysis", (evt, data) => {
            vm.incidentModified = true
            fetchIncidentForms();
        })

        $scope.$on("CREATE_HAP", (evt, data) => {
            vm.getIncidentActions()
        })

        $scope.$on("GENERAL_REFRESHDATA", (evt, data) => {
            vm.incidentModified = true
            formsService.updateIncidentAssociated(vm.incident.ID)
            vm.getIncidentActions()
        })

        $scope.$on("HAP_REFRESHDATA", (evt, data) => {
            vm.incidentModified = true
            formsService.updateIncidentAssociated(vm.incident.ID)
            vm.getIncidentActions()
        })


        $scope.$on('UPDATE_FOLLOWUP', (event) => {
            vm.incidentModified = true
            formsService.updateIncidentAssociated(vm.incident.ID)           
            vm.getIncidentActions()
        })
     
      vm.getIncidentActions = () => {
            tirService.getIncidentActions(vm.incident.ID).then((data)=>{
                vm.incidentActions = []
                vm.incidentActions = data
                processIncidentActions()
                vm.correctiveActionsGridOptions.api.setRowData(vm.incidentActions);
                vm.correctiveActionsGridOptions.api.redrawRows();
                vm.correctiveActionsGridOptions.api.sizeColumnsToFit();
            })
        }

        function fetchIncidentForms(submissionHeaderIds) {
            vm.viewerClosed = false;
            if(!submissionHeaderIds){
                submissionHeaderIds = vm.incident.submissions.map(sub => sub.SubmissionHeaderID)
            }           
            $q.all([
                tirService.getIncidentFormSubmissions(preliminaryInvestigationFormDescriptionId, submissionHeaderIds)
                , tirService.getIncidentFormSubmissions(tirStatementFormDescriptionId, submissionHeaderIds)
                , tirService.getIncidentFormSubmissions(preliminaryIncidentFormDescriptionId, submissionHeaderIds)
                , rootCauseAnalysisService.getRootCauseAnalyses(vm.incident.ID, selectedLanguage)
                , tirService.getIncidentActions(vm.incident.ID)
                , tirService.getIncidentHeader(vm.incident.ID)
            ])
                .then(function (response) {
                    vm.preliminaryInvestigations = response[0]
                    vm.preliminaryInvestigationsCount = 0
                    vm.tirStatements = response[1]
                    vm.preliminaryIncidents = response[2]
                    vm.rootCauseAnalyses = []
                    vm.rootCauseAnalyses = response[3]
                    vm.incidentActions = []
                    vm.incidentActions = response[4]
                    vm.preliminaryInvestigationGridOptions.api.setColumnDefs(vm.preliminaryInvestigationGridSections)
                    vm.tirStatementGridOptions.api.setColumnDefs(vm.tirStatementGridSections)
                    vm.preliminaryIncidentGridOptions.api.setColumnDefs(vm.preliminaryIncidentGridSections)
                    vm.incidentHeader = tirService.readIncidentHeader()                   
                    updateIncidentGrids()
                    processIncidentActions()
                    processRootCauseAnalyses()
                    
                })
        }

        function updateIncidentGrids() {
            translateAgGridHeader(vm.preliminaryInvestigationGridOptions)
            vm.preliminaryInvestigationsCount = collateSubmissions(vm.preliminaryInvestigations)
            vm.preliminaryInvestigationGridOptions.api.setRowData(prepareInvestigationGridData(vm.preliminaryInvestigationsCount))
            vm.preliminaryInvestigationGridOptions.api.redrawRows()
            

            vm.tirStatementsCount = collateSubmissions(vm.tirStatements)
            translateAgGridHeader(vm.tirStatementGridOptions)
            vm.tirStatementGridOptions.api.setRowData(prepareStatementGridData(vm.tirStatementsCount));
            vm.tirStatementGridOptions.api.redrawRows();

            translateAgGridHeader(vm.preliminaryIncidentGridOptions)
            vm.preliminaryIncidentsCount = collateSubmissions(vm.preliminaryIncidents)
            vm.preliminaryIncidentGridOptions.api.setRowData(prepareIncidentGridData(vm.preliminaryIncidentsCount));
            vm.preliminaryIncidentGridOptions.api.redrawRows();
            
            translateAgGridHeader(vm.rootCauseAnalysisGridOptions)
            vm.rootCauseAnalysisGridOptions.api.setRowData(prepareRootGridData(vm.rootCauseAnalyses));
            vm.rootCauseAnalysisGridOptions.api.redrawRows();
            vm.rootCauseAnalysisGridOptions.api.sizeColumnsToFit();

            translateAgGridHeader(vm.correctiveActionsGridOptions)
            vm.correctiveActionsGridOptions.api.setRowData(prepareActionGridData(vm.incidentActions));            
            vm.correctiveActionsGridOptions.api.redrawRows();
            vm.correctiveActionsGridOptions.api.sizeColumnsToFit();
        }

        function collateSubmissions(submissions) {
            let myIDs = []
            let myRecs = []
            submissions.forEach((subs) => {
            if (!myIDs.includes(subs.ID)) {
                myIDs.push(subs.ID)
                let recdata = {
                Duration: subs.Duration,
                FormCreationDate: subs.FormCreationDate,
                FormSubmissionDate: subs.FormSubmissionDate,
                ID: subs.ID,
                MySignoffID: subs.MySignoffID,
                JobNumber: subs.JobNumber,
                Site: subs.Site,
                SiteLevel: subs.SiteLevel,
                SubmissionId: subs.SubmissionId,
                SubmittedBy: subs.SubmittedBy,
                Supervisor: subs.Supervisor,
                Workplace: subs.Workplace,
                signoffCount: subs.signoffCount,
                ReportURL: subs.ReportURL,
                ImageCount: 0,
                Images: []
                }
                myRecs.push(recdata)
            }
            })
            submissions.forEach((recsubs) => {
                let omit = ['site', 'job_number', 'level','workplace','supervisor']
                let filetypes = ['jpg','jpeg','jfif','png','gif']
                myRecs.forEach((recs) => {

                    if (recs.ID == recsubs.ID &&  omit.includes(recsubs.fieldKey) === false) {
                        if(recsubs.itemValueTag && !omit.includes(recsubs.fieldKey)){
                            recs[`${recsubs.fieldKey}_tag`] = recsubs.itemValueTag
                        } 
                        recs[recsubs.fieldKey] = recsubs.itemValue 
                        if(recsubs.itemValue) {
                            let checkImg = recsubs.itemValue.split(".")
                            if(checkImg.length === 2){
                                if(filetypes.includes(checkImg[1].toLowerCase())){
                                recs.Images.push({"AttachmentFileName":recsubs.itemValue,"imageDir": __env.imageUrl, "imageCom":recsubs.com_comment, "imageTime":moment(recsubs.sde_image_timestamp).format("YYYY-MM-DD hh:mm:ss a")})
                                recs['ImageCount']++ // not sure why the image count is being incremented.
                                }
                            }
                        }
                    } 
                })
            })
            return myRecs
        }

        //Function to prepare data for Ag-Grid/Tippy
        function prepareRootGridData(data) {
            if(data){
                let gridData = JSON.parse(JSON.stringify(data))
                gridData.forEach((rec) => {
                    rec.exceptionFields = ['Causes', 'Cause', 'ReportURL']

                    rec.LastUpdated = rec.LastUpdated===null?'': moment(rec.LastUpdated).format('YYYY-MM-DD')
                    rec.SubmissionDate = rec.SubmissionDate===null?'':moment(rec.SubmissionDate).format('YYYY-MM-DD')
                })
                return gridData                 
            }
            return 
            
        }

        //Function to prepare data for Ag-Grid/Tippy
        function prepareActionGridData(data) {
            let gridData = JSON.parse(JSON.stringify(data))
            gridData.forEach((rec) => {
                rec.exceptionFields = ['action_contextual_date', 'action_by_who_name', 'assigned_to', 'ReportURL']

                rec.action_by_when = moment(rec.action_by_when).format('YYYY-MM-DD')
                rec.tippy_assigned_to = rec.action_by_who_name
            })
            return gridData
        }

        //Function to prepare data for Ag-Grid/Tippy
        function prepareInvestigationGridData(data) {
            let gridData = JSON.parse(JSON.stringify(data))
            
            gridData.forEach((rec) => {
                rec.exceptionFields = ['ReportURL', 'Images', 'workplace_conditions_photos']
                rec.CreatedBy = getEmployeeName(rec.CreatedBy)
            })
            return gridData
        }

        //Function to prepare data for Ag-Grid/Tippy
        function prepareIncidentGridData(data) {
            let gridData = JSON.parse(JSON.stringify(data))
            gridData.forEach((rec) => {
                rec.exceptionFields = ['ReportURL', 'Images', 'incident_pictures', 'null']       
            })
            return gridData
        }

        //Function to prepare data for Ag-Grid/Tippy
        function prepareStatementGridData(data) {
            let gridData = JSON.parse(JSON.stringify(data))
            
            gridData.forEach((rec) => {
                rec.exceptionFields = ['ReportURL', 'Images', 'signature', 'incident_photos','durationlistpicker_81']
            })
            return gridData
        }

        vm.closeIncidentViewer = () => {
            vm.incidentReportURL = null
            vm.hideIncidentViewer = true
            vm.tirForms.forEach(function (form) {
                form.checked = false
                form.expanded = false
            });

            if(vm.quickSignOffState || vm.incidentModified){

                let filterObject = {}
                let startDate = vm.mainDateFilter.start_date
                let endDate = vm.mainDateFilter.end_date
                if (startDate)
                    filterObject.startDate = startDate
                if (endDate)
                    filterObject.endDate = endDate
                if (vm.getFilterType)
                    filterObject.filter = vm.getFilterType
                filterObject.language = selectedLanguage
                // start spinner
                $scope.$emit('STARTSPINNER', vm.loadMessage)
                $q.all([
                    tirService.getTir(filterObject),
               ]).then((data) => {
                    vm.tirs = data[0]
                    updateGrid()
                    $scope.$emit('STOPSPINNER')
                })

            }

            // The amount of seconds relates to the slide-down/fade out animation duration in tir.css
            $timeout(() => {
                vm.incident = null
                vm.hideIncidentViewer = false
            }, 400)
        };

        vm.clearFilters = () => {
            vm.getFilterType = 'None'
            vm.filterTir()
        }

        vm.filterTir = () => {
            let filterObject = {}
            if ($window.sessionStorage.getItem('homepageRedirect_incidentsFilter') == 'Person') {
                vm.getFilterType = 'Person'
            }
            else if ($window.sessionStorage.getItem('homepageRedirect_incidentsFilter') == 'Site') {
                vm.getFilterType = 'Site'
            }
            else if ($window.sessionStorage.getItem('homepageRedirect_incidentsFilter') == 'Company') {
                vm.getFilterType = 'Company'
            }
            else if ($window.sessionStorage.getItem('homepageRedirect_incidentsFilter') == 'homepage') {
                vm.getFilterType = 'homepage'
                vm.homePageJobList = $window.sessionStorage.getItem('homePageJobList')
                vm.homePageSiteList = $window.sessionStorage.getItem('homePageSiteList')
            }
            else {
                vm.getFilterType = 'None'
            }

            $window.sessionStorage.setItem('start_date', vm.mainDateFilter.start_date)
            $window.sessionStorage.setItem('end_date', vm.mainDateFilter.end_date)
            let startDate = vm.mainDateFilter.start_date
            let endDate = vm.mainDateFilter.end_date
            if (startDate)
                filterObject.startDate = startDate
            if (endDate)
                filterObject.endDate = endDate
            if (vm.getFilterType)
                filterObject.filter = vm.getFilterType
                if (vm.getFilterType == 'homepage'){
                    filterObject.site_ids = vm.homePageSiteList
                    filterObject.job_ids = vm.homePageJobList
                }
            filterObject.language = selectedLanguage            
            refreshFilters(filterObject)
        }

        vm.historicalIncidentNumber = null

        vm.createNewIncident = (mode="") => {
            $q.all([
               tirService.validateSubmissionIdsExists(vm.SubmissionIDs)
            ]).then((count) => {
                if(count>0){
                    vm.validationExistingSubIdsModal()
                }
                else{
                    vm.resetModal()
                    vm.hideDropdowns()
                    if(mode == "historical") {
                        document.getElementById("historical_incident_number").value = document.getElementById("historical_incident_number").value.trim() // Remove white space
                        if(validateFormFields('formHistoricalIncident')) {
                            newIncident()
                        } else {
                            vm.modalElements.message = translateTag(2183) //The form has fields that need attention. Please see fields marked in red.
                            vm.modalElements.buttons = `<button class='btn btn-primary btn-rounded' ng-click="tir.closeConfirmModal()" note="OK">{{tir.translateLabels(1405)}}</button>`
                    
                            $('#tirFormConfirmModal .buttons').html($compile(vm.modalElements.buttons)($scope))
                            modalService.Open('tirFormConfirmModal')
                        }
                    } else {
                        newIncident()
                    }
                }
            })
            
        }

        newIncident = () => {
            $q.when(tirService.createNewIncident(vm.historicalIncidentNumber), (incident) => {

                if (incident.message && incident.message == "Incident Exists") {
                    vm.modalElements.message = translateTag(9155) //An incident with this incident number already exists. Please assign this form to the existing incident instead.
                    vm.modalElements.buttons = `<button class='btn btn-primary btn-rounded' ng-click="tir.closeConfirmModal()" note="OK">{{tir.translateLabels(1405)}}</button>`
            
                    $('#tirFormConfirmModal .buttons').html($compile(vm.modalElements.buttons)($scope))
                    modalService.Open('tirFormConfirmModal')
                    document.getElementById("historical_incident_number").setCustomValidity(false)
                }
                else if (incident)
                {
                    vm.newIncident = incident[0][0]
                   $q.when(tirService.assignSubmissionsToIncident(vm.newIncident, vm.SubmissionIDs), (result) => {
                       vm.SubmissionIDs = []
                       vm.filterTir()
                       vm.closeHistoricIncidentsModal()
                       vm.assignDisabled = true
                   }, (error) => {
                       toastr.error(translateTag(3663), error) // "error creating new incident: ", error)
                       vm.SubmissionIDs = []
                       vm.filterTir()
                   })
                }
           },  (error) => {
               console.log("Error Creating New Incident", error)
           })
        }

        vm.openExistingIncidentsModal = () => {
            vm.hideDropdowns()
            vm.openModal('existingIncidentsModal')
            let existingIncidentsData = []
            let incidents_length = vm.tirs.data.length
            for (let index = 0; index < incidents_length; index++) {
                // check status of each record is status is open - ltr_tag = 2261 add to existingIncidentsData list
                if(vm.tirs.data[index].Status === "2261"){
                    existingIncidentsData.push(vm.tirs.data[index])
                }                
            }
            vm.existingIncidentsGridOptions.api.setRowData(prepareIncidentsGridData(existingIncidentsData))
            vm.existingIncidentsGridOptions.api.redrawRows()
            vm.existingIncidentsGridOptions.api.sizeColumnsToFit()
        }

        vm.openHistoricIncidentsModal = () =>{
            vm.hideDropdowns()
            vm.openModal('historicIncidentsModal')
        }

        vm.closeExistingIncdientsModal = () => {
            vm.closeModal('existingIncidentsModal')
        }

        vm.closeHistoricIncidentsModal = () => {
            vm.historicalIncidentNumber = null
            document.forms['formHistoricalIncident'].classList.remove('was-validated')
            vm.closeModal('historicIncidentsModal')
        }

        vm.assignToExistingIncident = (incident) => {
            vm.assignDisabled = true
            $q.when(tirService.assignSubmissionsToIncident(incident.ID, vm.SubmissionIDs), (result) => {
                vm.SubmissionIDs = []
                vm.filterTir()
                vm.closeExistingIncdientsModal()
            }, (error) => {
                toastr.error(translateTag(3663), error) // "Error creating new incident: ", error)
                vm.SubmissionIDs = []
                vm.filterTir()
                vm.closeExistingIncdientsModal()
            });
        }

        // Display values in summary for name fields: Supervisors, Submitted By, etc.
        vm.getNameSummary = (formObj, fieldName) => {
            if (formObj.formName2 == 1002) // 'preliminary investigation')
                return tirService.getNameSummary(vm.preliminaryInvestigations, fieldName)
            else if (formObj.formName.toLowerCase() == 'tir statement' || formObj.formId==221746) // 'incident statement')
                return tirService.getNameSummary(vm.tirStatements, fieldName)
            else if (formObj.formId ==  224335) // 'preliminary incident')
                return tirService.getNameSummary(vm.preliminaryIncidentsCount, fieldName)
        }

        // Display values in summary for normal fields (Site, Workplace, etc..)
        vm.getFieldSummary = (formObj, fieldName) => {
            if (formObj.formId ==  220234) // 'preliminary investigation')
                return tirService.getFieldSummary(vm.preliminaryInvestigations, fieldName)
            else if (formObj.formId == 221746) // 'incident statement')
                return tirService.getFieldSummary(vm.tirStatements, fieldName);
            else if (formObj.formId ==  224335) // 'preliminary incident')
                return tirService.getFieldSummary(vm.preliminaryIncidents, fieldName)
            else if (formObj.formId ==  'RCA') //'root cause analysis')
                return tirService.getFieldSummary(vm.rootCauseAnalyses, fieldName)
            else if (formObj.formName.toLowerCase() == translateTag(1060).toLowerCase()) // 'action')
                return tirService.getFieldSummary(vm.incidentActions, fieldName)
        }

        vm.getActionsData = () => {

        }

        function refreshFilters(filterObject) {     
           
            $scope.$emit('STARTSPINNER', vm.loadMessage)  
            $q.all([
                tirService.getTir(filterObject),
                tirService.getTirForms(),
                menuService.getMenuItems(),
                tirService.getUnassignedIncidentForms(filterObject),
                listService.getSelectListData('ref_job'),
                profileService.getAllEmployeeProfile(),
                tirService.getAllPreTasks(),
                tirService.getAllPreOps(),
                oraService.getOraList(rmmFilter),
                jraService.getJraList(rmmFilter),
                praService.getPraList(rmmFilter),
                listService.getFullSiteList(),

            ])
                .then((data) => {
                    vm.tirs = data[0]
                    vm.tirForms = data[1]
                    vm.forms = menuService.readMenuItems()
                    vm.unassignedTirForms = data[3]
                    vm.jobList=data[4]
                    vm.employeeList = profileService.readAllEmployeeProfile()
                    vm.preTasks = tirService.readAllPreTasks()
                    vm.preOps = tirService.readAllPreOps()
                    vm.oraAGData = oraService.readOraList()
                    vm.jraAGData = jraService.readJraList()
                    vm.praAGData = praService.readPraList()
                    
                    updateGrid()
                    vm.site_name = listService.readFullSites()
                    fetchIncidentFormDescriptions()
                    $scope.$emit('STOPSPINNER')
                    $window.sessionStorage.removeItem('homepageRedirect_incidentsFilter')
                    
                })
        }

        function updateGrid() {
          if (vm.tirGridOptions.api) {
            translateAgGridHeader(vm.tirGridOptions)
            let modelTir = vm.tirGridOptions.api.getFilterModel()
            vm.tirGridOptions.api.setRowData(prepareIncidentsGridData(vm.tirs.data))
            vm.tirGridOptions.api.redrawRows()
            vm.tirGridOptions.api.sizeColumnsToFit()
            vm.tirGridOptions.api.setFilterModel(modelTir)
          }

          vm.unassignedIncidentsCount = vm.unassignedTirForms.length
          if (vm.unassignedTirGridOptions.api) {
            translateAgGridHeader(vm.unassignedTirGridOptions)
            let modelUnassigned = vm.unassignedTirGridOptions.api.getFilterModel()
            vm.unassignedTirGridOptions.api.setRowData(prepareUnassignedIncidentsGridData(vm.unassignedTirForms))
            vm.unassignedTirGridOptions.api.redrawRows()
            vm.unassignedTirGridOptions.api.sizeColumnsToFit()
            vm.unassignedTirGridOptions.api.setFilterModel(modelUnassigned)
          }
        }

        //Function to prepare data for Incident Reports Ag-Grid/Tippy
        function prepareIncidentsGridData(data) {
            let incidentsGridData = JSON.parse(JSON.stringify(data))
            incidentsGridData.forEach((rec) =>{      
                rec.exceptionFields = ['submissions', 'ReportURL', 'CreatedBy', 'CreationDate', 'Date', 'SubmittedBy', 'counter', 'LastModified','inc_is_quick_signoff','inc_status']
                rec.HeaderDate = moment(rec.HeaderDate).format('YYYY-MM-DD')
                rec.CreatedDate = moment(rec.CreationDate).format('YYYY-MM-DD')
                // SOF-13562 - Including Modified by and Modified date in the Grid instead of submission date and submitted by
                rec.created_by_name = getEmployeeName(rec.CreatedByName)
                rec.LastModifiedDate = rec.LastModified ? moment(rec.LastModified).format('YYYY-MM-DD') : null
                rec.inc_status = rec.Status
                rec.Status = translateTag(rec.Status)
            })
            return incidentsGridData
        }

        //Function to prepare data for Incident Reports Ag-Grid/Tippy
        function prepareUnassignedIncidentsGridData(data) {
            let incidentsGridData = JSON.parse(JSON.stringify(data))
            incidentsGridData.forEach((rec) =>{
                rec.exceptionFields = ['ReportURL', 'signed_by_per', 'signoff_count']
                rec.prefix = ['SubmissionHeader']
                rec.HeaderDate = moment(rec.HeaderDate).format('YYYY-MM-DD')
                rec.SubmissionDate = moment(rec.SubmissionDate).format('YYYY-MM-DD')
            })
            return incidentsGridData
        }

        //Funtion to convert eployee ID to Name
        function getEmployeeName(value) {
            let name = value
            vm.employeeList.forEach((emp)=>{
              if(emp.per_id == value) {
                name = emp.per_full_name
              }
            })
            return name
        }

        vm.exportPressed = () => {
            $('#tirExportDropdown').addClass('show')
        }

        vm.assignToPressed = () => {
            $('#assignIncidentDropdown').addClass('show')
        }

        vm.showActionsDropDown = () => {
            $('#showActionsDropDown').addClass('show')
        }

        vm.showOptionsDropDown = () => {
            $('#showOptionsDropDown').addClass('show')
        }

        vm.selectSortBy = () => {
            $('#sortByDropdown').addClass('show')
        }

        $(window).click((e) => {
            removeExportDropdown()
            vm.hideDropdowns()
        })

        $(window).scroll((e) => {
            removeExportDropdown()
            vm.hideDropdowns()
        })

        function removeExportDropdown() {
            $('#tirExportDropdown').removeClass('show')
        }

        function prepExport() {
            let preliminaryInvestigationExportFields = []
            for (let i = 0; i < vm.preliminaryInvestigationGridSections.length; i++) {
                if (vm.preliminaryInvestigationGridSections[i].children != undefined) {
                    for (let j = 0; j < vm.preliminaryInvestigationGridSections[i].children.length; j++) {
                        preliminaryInvestigationExportFields.push(vm.preliminaryInvestigationGridSections[i].children[j].field)
                    }
                }
            }

            let tirStatementExportFields = [];
            for (let i = 0; i < vm.tirStatementGridSections.length; i++) {
                if (vm.tirStatementGridSections[i].children != undefined) {
                    for (let j = 0; j < vm.tirStatementGridSections[i].children.length; j++) {
                        tirStatementExportFields.push(vm.tirStatementGridSections[i].children[j].field)
                    }
                }
            }

            let preliminaryIncidentExportFields = [];
            for (let i = 0; i < vm.preliminaryIncidentGridSections.length; i++) {
                if (vm.preliminaryIncidentGridSections[i].children != undefined) {
                    for (let j = 0; j < vm.preliminaryIncidentGridSections[i].children.length; j++) {
                        preliminaryIncidentExportFields.push(vm.preliminaryIncidentGridSections[i].children[j].field)
                    }
                }
            }

            return {
                preliminaryInvestigation: {
                    onlySelected: true,
                    columnKeys: preliminaryInvestigationExportFields,
                    processCellCallback: (params) => {

                        if (!!params.column.colDef.isAttachment) {
                            return params.length
                        }
                        return params.value
                    },
                    fileName: 'Preliminary Investigations_' + vm.incident.IncidentNumber
                },
                tirStatement: {
                    onlySelected: true,
                    columnKeys: tirStatementExportFields,
                    processCellCallback: (params) => {
                        if (!!params.column.colDef.isAttachment) {
                            return params.length
                        }
                        return params.value
                    },
                    fileName: 'Incident Statements_' + vm.incident.IncidentNumber
                },
                preliminaryIncident: {
                    onlySelected: true,
                    columnKeys: preliminaryIncidentExportFields,                    
                    processCellCallback: (params) => {
                        if (!!params.column.colDef.isAttachment) {
                            return params.length
                        }
                        return params.value
                    },
                    fileName: 'Preliminary Incidents_' + vm.incident.IncidentNumber
                },
            }
        }

        vm.exportCSV = () => {
            removeExportDropdown()
            var exportOptions = prepExport()
            vm.tirForms.forEach((form, i) => {
                switch (form.formId) {  
                    case 220234: //'PRELIMINARY INVESTIGATION':
                        if (vm.preliminaryInvestigationGridOptions.api.getSelectedRows().length > 0)
                            vm.preliminaryInvestigationGridOptions.api.exportDataAsCsv(exportOptions.preliminaryInvestigation)
                        break
                    case 221746: // 'INCIDENT STATEMENT':
                        if (vm.tirStatementGridOptions.api.getSelectedRows().length > 0)
                            vm.tirStatementGridOptions.api.exportDataAsCsv(exportOptions.tirStatement)
                        break
                    case 224335: //'PRELIMINARY INCIDENT':
                        if (vm.preliminaryIncidentGridOptions.api.getSelectedRows().length > 0)
                            vm.preliminaryIncidentGridOptions.api.exportDataAsCsv(exportOptions.preliminaryIncident)
                        break
                    default:
                        break
                }
            })
            if(vm.rootCauseAnalysisGridOptions.api.getSelectedRows().length > 0)
            {
                exportRCA_CSV()
            }

        }

        function exportRCA_CSV () {
            vm.csvOutput = ''
            let rows = vm.rootCauseAnalysisGridOptions.api.getSelectedRows()
            vm.csvOutput += `${translateTag(2398)},${translateTag(124)},${translateTag(1168)},${translateTag(3832)},Investigation Findings,${translateTag(2007)},${translateTag(1144)},${translateTag(566)},${translateTag(2577)},${translateTag(2578)},${translateTag(2568)},${translateTag(2569)},${translateTag(1890)},${translateTag(2005)}, ${translateTag(2011)},${translateTag(2573)},${translateTag(2572)},Basic Cause Comments,${translateTag(2571)},${translateTag(2575)},Immediate Cause Comments,Immediate Cause Type \r\n`
            rows.forEach(rca => { 
                vm.csvOutput += `"${rca.ID}",`
                vm.csvOutput += `"${rca.SubmissionDate}",`
                vm.csvOutput += `"${rca.SubmittedBy}",` 
                vm.csvOutput += `"${rca.EventDetails}",` 
                vm.csvOutput += `"${rca.InvestigationFindings}",` 
                vm.csvOutput += `"${rca.PreliminaryType}",` 
                vm.csvOutput += `"${rca.PotentialLoss}",` 
                vm.csvOutput += `"${rca.IncidentType}",` 
                vm.csvOutput += `"${rca.PreliminaryIncidentTypeCategory}",` 
                vm.csvOutput += `"${rca.PreliminaryIncidentTypeDetail}",` 
                vm.csvOutput += `"${rca.ActualIncidentTypeCategory}",` 
                vm.csvOutput += `"${rca.ActualIncidentTypeDetail}",` 
                vm.csvOutput += `"${rca.LastUpdated}",` 
                vm.csvOutput += `"${rca.LastUpdatedBy}",` 
                vm.csvOutput += `"${rca.EmployeesInvolved}",`
                if(rca.Causes[0]){
                    vm.csvOutput += `"${rca.Causes[0].BasicCause}",` 
                    vm.csvOutput += `"${rca.Causes[0].BasicCauseCategory}",`
                    vm.csvOutput += `"${rca.Causes[0].BasicCauseType}",`
                    vm.csvOutput += `"${rca.Causes[0].ImmediateCause}",`
                    vm.csvOutput += `"${rca.Causes[0].ImmediateCauseComments}",`
                    vm.csvOutput += `"${rca.Causes[0].ImmediateCauseType}",`
                }
                vm.csvOutput += `\r\n`                                       
            })
            vm.csvOutput = vm.csvOutput.replace(/#/g, '').replace(/null/g, '').replace(/undefined/g, '')
            let anchor = angular.element('<a/>')
            anchor.attr({
                href: 'data:attachment/csv;charset=utf-8,' + encodeURI(vm.csvOutput),
                target: '_blank',
                download: 'IA.csv'
            })[0].click()
        }

        vm.removeFormFromIncident = () => {
            let formArr = []
            let rcaArr = []
            let incidentStatements = vm.tirStatementGridOptions.api.getSelectedRows()
            let preliminaryIncidents = vm.preliminaryIncidentGridOptions.api.getSelectedRows()
            let preliminaryInvestigations = vm.preliminaryInvestigationGridOptions.api.getSelectedRows()
            let rootCauseAnalyses = vm.rootCauseAnalysisGridOptions.api.getSelectedRows()
            let selectedFormsLength = incidentStatements.length + preliminaryIncidents.length + preliminaryInvestigations.length
            let allFormsLength = vm.preliminaryInvestigations.length + vm.preliminaryIncidents.length + vm.tirStatements.length

            let allFormsCount = vm.tirStatementGridOptions.api.getDisplayedRowCount() +  vm.preliminaryIncidentGridOptions.api.getDisplayedRowCount() +
                                vm.preliminaryInvestigationGridOptions.api.getDisplayedRowCount()
            
            if((selectedFormsLength == 1 && allFormsCount == 1) || allFormsCount == selectedFormsLength){
                vm.validationFormsModal()
                return
            }
            if (selectedFormsLength >= allFormsLength) {
                toastr.error(translateTag(3671)) //  ("Cannot remove all preliminary forms from incident.")
                return
            }

            formArr = formArr.concat(incidentStatements.map(function (sub) { return sub.ID }));
            formArr = formArr.concat(preliminaryIncidents.map(function (sub) { return sub.ID }));
            formArr = formArr.concat(preliminaryInvestigations.map(function (sub) { return sub.ID }));

            rcaArr = rootCauseAnalyses.map(function (sub) { return sub.ID });

            $q.all([
                tirService.removeSubmissionsFromIncident(vm.incident.ID, formArr)
                , rootCauseAnalysisService.archiveRootCauseAnalyses(rcaArr)
            ]).then(function (result) {
                vm.incident.submissions = vm.incident.submissions.filter(function (sub) {
                    if (formArr.includes(sub.SubmissionHeaderID))
                        return false;
                    return true;
                });
                fetchIncidentForms();
                vm.filterTir();
            }, function (error) {
                toastr.error(translateTag(3672), error); // Error removing Submissions from incodent.
                fetchIncidentForms();
                vm.filterTir();
            });
            removeExportDropdown();
        };

        vm.actionsDisabled = () => {
            let enabledActions = false
            enabledActions = (vm.preliminaryInvestigationGridOptions.api && vm.preliminaryInvestigationGridOptions.api.getSelectedRows().length > 0) ||
                (vm.tirStatementGridOptions.api && vm.tirStatementGridOptions.api.getSelectedRows().length > 0) ||
                (vm.preliminaryIncidentGridOptions.api && vm.preliminaryIncidentGridOptions.api.getSelectedRows().length > 0) ||
                (vm.preliminaryIncidentGridOptions.api && vm.rootCauseAnalysisGridOptions.api.getSelectedRows().length > 0) ||
                vm.selectedSubmissionHeaderId
            return !enabledActions
        }

        /* resize stuff */

        $scope.$on('menu-width-changed', () => {
            $timeout(() => {
                vm.tirGridOptions.api.sizeColumnsToFit()
                vm.unassignedTirGridOptions.api.sizeColumnsToFit()
            }, 500)
        })

        $scope.$on('GENTIRATTACHMENT', () => {
        })

        $(window).on('resize', () => {
            $timeout(() => {
              if (vm.tirGridOptions && vm.tirGridOptions.api) {
                vm.tirGridOptions.api.sizeColumnsToFit()
              }

              if (vm.unassignedTirGridOptions && vm.unassignedTirGridOptions.api) {
                vm.unassignedTirGridOptions.api.sizeColumnsToFit()
              }

              if (vm.correctiveActionsGridOptions && vm.correctiveActionsGridOptions.api) {
                vm.correctiveActionsGridOptions.api.sizeColumnsToFit()
              }

              if (vm.oraOptions && vm.oraOptions.api) {
                vm.oraOptions.api.sizeColumnsToFit()
              }
              if (vm.praOptions && vm.praOptions.api) {
                vm.praOptions.api.sizeColumnsToFit()
              }
            });
        })

        vm.openIncidentReport = (e, report, id)=>{
            if(!e.ctrlKey){
                lang_number = localStorage.getItem('lang_id')
                vm.incidentReportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${report}/${id}?lang=${lang_number}&t=${vm.token}`)
                $window.open(vm.incidentReportURL, "_blank")
            }
        } 

        vm.openIncidentActionReport = (e, report, id)=>{           

            if(!e.ctrlKey){
                lang_number = localStorage.getItem('lang_id')
                vm.incidentReportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${report}/${id}?lang=${lang_number}&t=${vm.token}`)                
                $window.open(vm.incidentReportURL, "_blank")
            }
        } 

        vm.backIncident = ()=>{
            vm.incidentReportURL = null
        }

        // Fetch form descriptions for each of the incident forms.
        function fetchIncidentFormDescriptions() {
           try {
            preliminaryInvestigationFormDescriptionId = vm.forms.filter((f) => {
                return f.report_id == '220234'
            })[0].formDescriptionId
            tirStatementFormDescriptionId = vm.forms.filter((f) => {
                return f.report_id == '221746'
            })[0].formDescriptionId
            preliminaryIncidentFormDescriptionId = vm.forms.filter((f) => {
                return f.report_id == '224335'
            })[0].formDescriptionId

            vm.preliminaryInvestigationGridOptions.defaultColDef = {
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                headerCheckboxSelection:(params) => {
                    var displayedColumns = params.columnApi.getAllDisplayedColumns()
                    var thisIsFirstColumn = displayedColumns[0] === params.column
                    return thisIsFirstColumn
                },
                checkboxSelection: (params) => {
                    var displayedColumns = params.columnApi.getAllDisplayedColumns()
                    var thisIsFirstColumn = displayedColumns[0] === params.column
                    return thisIsFirstColumn
                }
            }

            formsService.getFormFieldDescriptions(preliminaryInvestigationFormDescriptionId)
                .then((sections) => {
                    vm.preliminaryInvestigationGridSections = [];
                    vm.preliminaryInvestigationGridSections.push({ 
                        field: "dummyCheckbox", 
                        headerName: "",
                        width: 50, 
                        maxWidth: 50, 
                        suppressMenu: true, 
                        suppressSorting: true }); //checkbox column
                    vm.preliminaryInvestigationGridSections.push({ 
                        field: "", 
                        headerName: "",
                        width: 40, 
                        maxWidth: 40,
                        suppressMenu: true, 
                        cellRenderer: function (params) {
                            return `<span class="pointer text-left" ng-click="tir.openReport($event,'${params.data.ReportURL}','${params.data.ID}')"><i class="fa fa-external-link-alt" title="${translateTag(3429)}"></i></span>`
                        },
                        suppressSorting: true });
                    vm.preliminaryInvestigationGridSections.push({ 
                        field: "", 
                        headerName: "",
                        width: 40, 
                        maxWidth: 40,
                        suppressMenu: true, 
                        cellRenderer: function (params) {
                            return `<span class="fa-1x fa-stack mr-3 pr-2" style="width: 1.25em;" ng-hide="tir.showClearSignOffs" ng-class="{ transparent: ${!vm.canManageAllIncidentSubmissions}, pointer: ${vm.canManageAllIncidentSubmissions}}" ng-click="tir.editForm(${params.data.ID},'form-220234')"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title="{{menu.translateLabels(1194)}}"></i></span>`
                        },
                        suppressSorting: true,});

                    for (let j = 0; j < sections.length; j++) {
                        let section = {}
                        section.headerName =vm.translateLabels( sections[j].SectionName)
                        let fieldDescriptions = sections[j].Fields
                        let formColumns = []
                        for (let i = 0; i < fieldDescriptions.length; i++) {
                            if (!fieldDescriptions[i].Visible)
                                continue;

                            let colDescription = {
                                field: fieldDescriptions[i].Name,
                                headerName: vm.translateLabels( fieldDescriptions[i].Display),
                                headerTooltip:vm.translateLabels( fieldDescriptions[i].Display)
                            };
                            colDescription.cellRenderer = 'tippyCellRenderer';

                            if (fieldDescriptions[i].FieldType === 'MultiLineEntry') {
                                colDescription.filter = 'agTextColumnFilter'
                            }

                            if (fieldDescriptions[i].FieldType === 'ThreeState') {
                                colDescription.valueGetter = gridService.yesNoValueGetter
                            }

                            if (fieldDescriptions[i].FieldType === 'DatePicker') {
                                colDescription.cellRenderer = gridService.dateCellRenderer
                                colDescription.filter = 'agDateColumnFilter'
                                colDescription.filterParams = gridService.dateFilterParams
                            }

                            if (fieldDescriptions[i].FieldType === 'MultiPhotoPicker') {
                                colDescription.isAttachment = true
                                colDescription.suppressMenu = true
                                colDescription.fieldId = fieldDescriptions[i].ID
                                colDescription.cellRenderer = function (params) {
                                    vm.submissionImages = params.data.Images
                                    return `<span class="file-link"><span ng-click="tir.openSubmissionImagesModal(${params.rowIndex},'investigation')">${params.data.ImageCount} ${translateTag(3673)} <svg xmlns="http://www.w3.org/2000/svg" width="9" height="18" viewBox="0 0 9 18"><path fill="none" stroke="#0080D2" d="M851.045455,27.25 L851.045455,22.1363636 C851.045455,21.0072727 851.620227,20.0909091 852.75,20.0909091 C853.879773,20.0909091 854.454545,21.0072727 854.454545,22.1363636 L854.454545,28.6136364 C854.454545,30.3086364 853.421591,31.6818182 851.727273,31.6818182 C850.032955,31.6818182 849,30.3086364 849,28.6136364 L849,20.0909091 C849,17.8313636 850.490455,16 852.75,16 C855.009545,16 856.5,17.8313636 856.5,20.0909091 L856.5,26.2272727" transform="translate(-848 -15)" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span>`
                                }
                            }
                            
                            colDescription.valueFormatter = (params) => {
                                if(params.value === 'null' || params.value === undefined)
                                {
                                    return " "
                                }
                                else{ 
                                    return params.value  
                                                                }
                            }

                            formColumns.push(colDescription)
                        }
                        section.children = formColumns
                        vm.preliminaryInvestigationGridSections.push(section)
                    }
                })

            formsService.getFormFieldDescriptions(tirStatementFormDescriptionId)
                .then((sections) => {
                    vm.tirStatementGridSections = []
                    vm.tirStatementGridSections.push({ 
                        field: "dummyCheckbox", 
                        headerName: "",
                        width: 50, 
                        maxWidth: 50, 
                        suppressMenu: true, 
                        suppressSorting: true }); //checkbox column
                    vm.tirStatementGridSections.push({ 
                        field: "", 
                        headerName: "",
                        width: 40,
                        maxWidth: 40,
                        suppressMenu: true, 
                        cellRenderer: function (params) {
                            return `<span class="pointer text-left" ng-click="tir.openReport($event,'${params.data.ReportURL}','${params.data.ID}')"><i class="fa fa-external-link-alt" title="${translateTag(3429)}"></i></span>`
                        },
                        suppressSorting: true }); //checkbox column

                    for (let j = 0; j < sections.length; j++) {
                        let section = {}
                        section.headerName =vm.translateLabels(sections[j].SectionName)
                        let fieldDescriptions = sections[j].Fields
                        let formColumns = []
                        for (let i = 0; i < fieldDescriptions.length; i++) {
                            if (!fieldDescriptions[i].Visible)
                                continue

                                let colDescription = {
                                field: fieldDescriptions[i].Name,
                                headerName:vm.translateLabels(fieldDescriptions[i].Display),
                                headerTooltip:vm.translateLabels(fieldDescriptions[i].Display)
                            }
                            colDescription.cellRenderer = 'tippyCellRenderer'

                            if (fieldDescriptions[i].FieldType === 'MultiLineEntry') {
                                colDescription.filter = 'agTextColumnFilter'
                            }

                            if (fieldDescriptions[i].FieldType === 'ThreeState') {
                                colDescription.valueGetter = gridService.yesNoValueGetter
                            }

                            if (fieldDescriptions[i].FieldType === 'DatePicker') {
                                colDescription.cellRenderer = gridService.dateCellRenderer
                                colDescription.filter = 'agDateColumnFilter'
                                colDescription.filterParams = gridService.dateFilterParams
                            }

                            if (fieldDescriptions[i].FieldType === 'MultiPhotoPicker') {
                                colDescription.isAttachment = true
                                colDescription.suppressMenu = true
                                colDescription.fieldId = fieldDescriptions[i].ID
                                colDescription.cellRenderer = (params) => {
                                    vm.submissionImages = params.data.Images
                                    return `<span class="file-link"><span ng-click="tir.openSubmissionImagesModal(${params.rowIndex},'statement')">${JSON.stringify(params.data.ImageCount)} ${translateTag(3673)} <svg xmlns="http://www.w3.org/2000/svg" width="9" height="18" viewBox="0 0 9 18"><path fill="none" stroke="#0080D2" d="M851.045455,27.25 L851.045455,22.1363636 C851.045455,21.0072727 851.620227,20.0909091 852.75,20.0909091 C853.879773,20.0909091 854.454545,21.0072727 854.454545,22.1363636 L854.454545,28.6136364 C854.454545,30.3086364 853.421591,31.6818182 851.727273,31.6818182 C850.032955,31.6818182 849,30.3086364 849,28.6136364 L849,20.0909091 C849,17.8313636 850.490455,16 852.75,16 C855.009545,16 856.5,17.8313636 856.5,20.0909091 L856.5,26.2272727" transform="translate(-848 -15)" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span>`
                                }
                            }

                            colDescription.valueFormatter = (params) => {
                                if(params.value === 'null' || params.value === undefined)
                                {
                                    return " "
                                }
                                else
                                    return params.value
                            }

                            formColumns.push(colDescription)
                        }
                        section.children = formColumns
                        vm.tirStatementGridSections.push(section)
                    }
                 })

            formsService.getFormFieldDescriptions(preliminaryIncidentFormDescriptionId)
                .then(function (sections) {

                    vm.preliminaryIncidentGridSections = [];
                    vm.preliminaryIncidentGridSections.push({ 
                        field: "dummyCheckbox", 
                        headerName: "",
                        width: 50, 
                        maxWidth: 50, 
                        suppressMenu: true, 
                        suppressSorting: true }); //checkbox column

                    vm.preliminaryIncidentGridSections.push({ 
                        field: "", 
                        headerName: "",
                        width: 40, 
                        maxWidth: 40, 
                        suppressMenu: true, 
                        cellRenderer: function (params) {
                            return `<span class="pointer text-left" ng-click="tir.openReport($event, '${params.data.ReportURL}','${params.data.ID}')"><i class="fa fa-external-link-alt" title="${translateTag(3429)}"></i></span>`
                        },
                        suppressSorting: true }); //checkbox column

                    vm.preliminaryIncidentGridSections.push({ 
                        field: "", 
                        headerName: "",
                        width: 40, 
                        maxWidth: 40, 
                        suppressMenu: true, 
                        cellRenderer: function (params) {
                            return `<span class="fa-1x fa-stack mr-3 pr-2" style="width: 1.25em;" ng-hide="tir.showClearSignOffs" ng-class="{ transparent: ${!vm.canManageAllIncidentSubmissions}, pointer: ${vm.canManageAllIncidentSubmissions}}" ng-click="tir.editForm(${params.data.ID},'form-224335')"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title="{{menu.translateLabels(1194)}}"></i></span>`
                        },
                        suppressSorting: true });

                    for (var j = 0; j < sections.length; j++) {
                        var section = {};
                        section.headerName =vm.translateLabels( sections[j].SectionName);
                        var fieldDescriptions = sections[j].Fields;
                        var formColumns = []
                         
                        for (var i = 0; i < fieldDescriptions.length; i++) {
                            if (!fieldDescriptions[i].Visible)
                                continue;

                            let colDescription = {
                                field: fieldDescriptions[i].Name,
                                headerName:vm.translateLabels( fieldDescriptions[i].Display),
                                headerTooltip:vm.translateLabels( fieldDescriptions[i].Display)
                            };
                            colDescription.cellRenderer = 'tippyCellRenderer';

                            if (fieldDescriptions[i].FieldType === 'MultiLineEntry') {
                                colDescription.filter = 'agTextColumnFilter';
                            }

                            if (fieldDescriptions[i].FieldType === 'ThreeState') {
                                colDescription.valueGetter = gridService.yesNoValueGetter;
                            }

                            if (fieldDescriptions[i].FieldType === 'DatePicker') {
                                colDescription.cellRenderer = gridService.dateCellRenderer;
                                colDescription.filter = 'agDateColumnFilter';
                                colDescription.filterParams = gridService.dateFilterParams;
                            }

                            if (fieldDescriptions[i].FieldType === 'MultiPhotoPicker') {
                                colDescription.isAttachment = true;
                                colDescription.suppressMenu = true;
                                colDescription.fieldId = fieldDescriptions[i].ID;
                                colDescription.cellRenderer = (params) => {
                                    vm.submissionImages = params.data.Images
                                    return `<span class="file-link"><span ng-click="tir.openSubmissionImagesModal(${params.rowIndex},'incident')">${JSON.stringify(params.data.ImageCount)} ${translateTag(3673)}  <svg xmlns="http://www.w3.org/2000/svg" width="9" height="18" viewBox="0 0 9 18"><path fill="none" stroke="#0080D2" d="M851.045455,27.25 L851.045455,22.1363636 C851.045455,21.0072727 851.620227,20.0909091 852.75,20.0909091 C853.879773,20.0909091 854.454545,21.0072727 854.454545,22.1363636 L854.454545,28.6136364 C854.454545,30.3086364 853.421591,31.6818182 851.727273,31.6818182 C850.032955,31.6818182 849,30.3086364 849,28.6136364 L849,20.0909091 C849,17.8313636 850.490455,16 852.75,16 C855.009545,16 856.5,17.8313636 856.5,20.0909091 L856.5,26.2272727" transform="translate(-848 -15)" stroke-linecap="round" stroke-linejoin="round"/></svg></span></span>`
                                };
                            }

                            colDescription.valueFormatter = (params) => {
                                if(params.value === 'null' || params.value === undefined)
                                {
                                    return " "
                                }
                                else
                                    return params.value
                            }

                            formColumns.push(colDescription);
                        }
                        section.children = formColumns;
                        vm.preliminaryIncidentGridSections.push(section);
                    }
                })
            } catch(err) {
          }
        }

        vm.editForm = (sh_id,formModalId) => {
            if(vm.canManageAllIncidentSubmissions && !vm.showClearSignOffs){
                $scope.$broadcast(`EDITFORMBYSHID-${formModalId}`, sh_id)
                setTimeout(() => {
                    vm.initializeSelect2(formModalId)
                }, 800);
            }
        }

        vm.openForm = (activeFormID) =>{   
            if(['372298','131042'].includes(activeFormID)){
                if (!vm.allowRCAEdit) {
                    toastr.error(translateTag(3905)) //"Unable to add new Incident Actions after supervisor sign-off.")
                }
                else {
                    vm.actionMode = "new"
                    if(activeFormID=='372298'){
                        vm.gapModel = {}
                    }
                    else if(activeFormID=='131042'){
                        vm.hazardEditData = {}
                    }
                }
            }
            let message={activeFormID:null,incidentId:null,moduleId:null}  
            message.activeFormID=activeFormID
            message.incidentId=vm.incident.ID
            $rootScope.$broadcast("OPENMOBILEFRAME",message)
        }

        //Refresh grid when any form is submitted
        $scope.$on('REFRESH_FORMSUBMISSIONS', (event) => {
            vm.incidentModified = true
            formsService.updateIncidentAssociated(vm.incident.ID)
            submissionHeaderIds = vm.incident.submissions.map(sub => sub.SubmissionHeaderID) 
            let startTime = new Date().getTime();
            let checkInsertedSubmissionHeaderId = setInterval(() => { 
                tirService.getIncidentSubmissionHeaderId(vm.incident.ID).then((data) => {
                    let incidentSubmissionHeaderId=data.submissionheaderid
                    if(!submissionHeaderIds.includes(incidentSubmissionHeaderId)){
                        submissionHeaderIds.push(incidentSubmissionHeaderId)
                        clearInterval(checkInsertedSubmissionHeaderId)
                        fetchIncidentForms(submissionHeaderIds)                     
                        return
                    }
                    else{
                        if(new Date().getTime() - startTime > 15000){
                            clearInterval(checkInsertedSubmissionHeaderId);
                            return;
                        }
                    }   
                })
            },1000)
        })

        vm.openSubmissionImagesModal = (index,type) =>{
            switch (type){
                case "statement" : vm.submissionImages = vm.tirStatementsCount[index].Images
                break
                case "incident" : vm.submissionImages = vm.preliminaryIncidentsCount[index].Images
                break
                default : vm.submissionImages = vm.preliminaryInvestigationsCount[index].Images
                break

            }
                vm.openModal('submissionImageModal')
        }

        vm.closesubmissionImagesModal = () =>{
                vm.closeModal('submissionImageModal')
        }

        vm.requestTrainedEmployees = () => {
            vm.openEmployeesModal()
        }

        vm.requestAvailablePreOps = () =>{
            vm.openPreOpsModal()
        }

        vm.requestAvailablePreTasks = () => {
            vm.openPreTasksModal()
        }
        vm.click = false
        vm.submitEmployeesGenerate = () => {
            if(!vm.click) {
                vm.click = true
                let rows = vm.employeeGridOptions.api.getSelectedRows()
                let qString = []
                if (rows.length > 0) {
                    qString = rows.map(emp => emp.per_id)
                }
                let payload = {
                    incidentId: vm.incident.ID,
                    incidentNumber: vm.incident.IncidentNumber,
                    employees: qString
                }
                tirService.requestEmployeeRecords(payload).then((response) => {
                    toastr.success(`${translateTag(3904)} #${vm.incident.IncidentNumber}`) //  Generating Training Records for TIR #${vm.incident.IncidentNumber} )
                    vm.incidentModified = true
                    vm.employeeSearch = ""
                    vm.employeeSearchChanged()
                    vm.getIncidentAttachments()
                    vm.closeEmployeesModal()
                    vm.click = false
                })
            }

            

        }

        vm.openEmployeesModal = () => {
            vm.openModal('employeeSelectionModal')
            translateAgGridHeader(vm.employeeGridOptions)
            vm.employeeGridOptions.api.setRowData(vm.employees)
            vm.employeeGridOptions.api.redrawRows()
            vm.employeeGridOptions.api.sizeColumnsToFit()
        }

        vm.closeEmployeesModal = () => {
            vm.closeModal('employeeSelectionModal')
            

        }

        vm.openPreTasksModal = () => {
            vm.openModal('preTasksSelectionModal')
            translateAgGridHeader(vm.preTaskGrid)
            vm.preTaskGrid.api.setRowData(PreparePreTasksRowData())
            vm.preTaskGrid.api.redrawRows()
            vm.preTaskGrid.api.sizeColumnsToFit()
        }

        vm.closePreTasksModal = () => {
            vm.getIncidentAttachments()
            vm.closeModal('preTasksSelectionModal')
        }

        vm.openPreOpsModal = () => {
            vm.openModal('preOpsSelectionModal')
            vm.preOpsGrid.api.setRowData(PreparePreOpsRowData())
            translateAgGridHeader(vm.preOpsGrid)
            vm.preOpsGrid.api.redrawRows()
            vm.preOpsGrid.api.sizeColumnsToFit()
        }

        vm.GeneratePreTaskDocuments = () => {
          //get selected records.
            let payload = {}
            let selected = {}
            payload['incidentid'] = vm.incident.ID
            payload['incidentnumber'] = vm.incident.IncidentNumber
            payload['data'] = []
            let rows = vm.preTaskGrid.api.getSelectedRows()
            if (rows.length > 0) {

                rows.forEach((row)=>{
                    payload['data'].push(row['id'])
                })
            }

            if(payload['data'].length > 0){
                tirService.preparePreTaskDocuments(payload).then(()=> {
                    vm.incidentModified = true
                    vm.getIncidentAttachments()
                })
                vm.closePreTasksModal()
            }
            vm.preTaskSearch = ""
            vm.preTaskSearchChanged()
        }
        
        vm.GeneratePreOpDocuments = () => {
            let payload = {}
            let selected = {}
            payload['incidentid'] = vm.incident.ID
            payload['incidentnumber'] = vm.incident.IncidentNumber
            payload['data'] = []
            let rows = vm.preOpsGrid.api.getSelectedRows()
            if (rows.length > 0) {

                rows.forEach((row)=>{
                    payload['data'].push(row['id'])
                })
            }
            if(payload['data'].length > 0){
                tirService.preparePreOpDocuments(payload).then(() =>{
                    vm.incidentModified = true
                    vm.getIncidentAttachments()
                })
            }
            vm.preOpsSearch = ""
            vm.preOpsSearchChanged()
            vm.closePreOpsModal()
        }

        function PreparePreOpsRowData(){
            let rtrn = []
            vm.preOps.forEach((op) => {
                let obj = {
                    id: op.psh_submissionheader_id,
                    employee_name: op.person_name,
                    equipment_id: op.psh_pet_id__pet_equipment_identifier,
                    submission_date : op.psh_submissionheader_id__formsubmissiondate
                }
                rtrn.push(obj)
            })
            return rtrn

        }

        function PreparePreTasksRowData(){
            let rtrn = []
            
            vm.preTasks.forEach((op) => {
                
                let obj = {
                    id : op.id,
                    employee_name: op.person_name,
                    workplace : op.workplace,
                    submission_date : op.formsubmissiondate
                }
                rtrn.push(obj)
            })
            return rtrn

        }

        vm.closePreOpsModal = () => {
            vm.getIncidentAttachments()
            vm.closeModal('preOpsSelectionModal')
        }

        vm.requestAvailableRA = () => {
            vm.openRAModal()

        }
        //Function to prepare Ag-Grid data with string values
        function preparePraGridData() {
            let praGridData = JSON.parse(JSON.stringify(vm.praAGData))
            let rtrn = []
            praGridData.forEach((rec) =>{
                let newRec = rec

                newRec.exceptionFields = ['approvers','general_actions', 'hazard_actions', 'acknowledgements', 'participants', 'rmm_pra_enable','rmm_pra_ora']
                newRec.prefix = 'rmm_pra_'
                newRec.endfix = ['_per', '_rld']  
                newRec.rmm_pra_site = getSiteName(rec.rmm_pra_site)
                newRec.rmm_pra_created_date = moment(rec.rmm_pra_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                newRec.rmm_pra_expiry_date = rec.rmm_pra_expiry_date===null?'':moment(rec.rmm_pra_expiry_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                newRec.rmm_pra_is_submitted  = rec.rmm_pra_state == 'active' ||  rec.rmm_pra_state == 'expired' ? true : false
                newRec.rmm_pra_revision_no = `${appendLeadingZeros(rec.rmm_pra_document_number)}`+'.'+`${appendLeadingZeros(rec.rmm_pra_doc_version_number,3)}`
                newRec.reviewedCount = rec.reviewers.length
                let approversList = ''
                rec.approvers.forEach((app) => {
                     approversList += app.full_name + ','
                })
                newRec.approvers = approversList

                if(rec.dlo_enable.length !== 0){
                    newRec.dlo_status = rec.dlo_enable[0].dlo_enable
                    newRec.dlo_person = rec.dlo_enable[0].dlo_person
                }
                else{
                    newRec.dlo_status = true
                    newRec.dlo_person = null
                }
                
                let participantsList = ''
                rec.participants.forEach((par) => {
                    participantsList += par.full_name + ','
                })
                newRec.participants =  participantsList 
                if (rec.rmm_pra_state!='draft'){
                    rtrn.push(newRec)
                }
            })

            return rtrn
        }

        vm.openRAModal = () => {
            vm.openModal('RASelectionModal')
            vm.showORAGrid()

            vm.initializeSelect2('RASelectionModal');
        }
        vm.closeRAModal = () =>{
            vm.closeModal('RASelectionModal')
        }
        let oraShown = false
        let jraShown = false
        let praShown = false
        let bowShown = false
        vm.showORAGrid = () => {
            if(!oraShown){ 
                vm.oraOptions.paginationPageSize = 12
                translateAgGridHeader(vm.oraOptions)
                vm.oraOptions.api.setRowData(prepareOraGridData())
                vm.oraOptions.api.redrawRows()
                vm.oraOptions.api.sizeColumnsToFit()
                oraShown = true
            } 
        }

        vm.showJRAGrid = () => {
            if(!jraShown){
                vm.jraOptions.paginationPageSize = 12
                translateAgGridHeader(vm.jraOptions)
                vm.jraOptions.api.setRowData(prepareJraGridData())
                vm.jraOptions.api.redrawRows()
                vm.jraOptions.api.sizeColumnsToFit()
                jraShown=true
            }
        }

        vm.showPRAGrid = () => {
            if(!praShown){
                vm.praOptions.paginationPageSize = 12
                translateAgGridHeader(vm.praOptions)
                vm.praOptions.api.setRowData(preparePraGridData())
                vm.praOptions.api.redrawRows()
                vm.praOptions.api.sizeColumnsToFit() 
                praShown = true
            }
        }

        vm.GenerateRADocuments = () =>{
            // Get a list of checked items.
            let ORAselectedRows = vm.oraOptions.api.getSelectedRows()
            let PRAselectedRows = vm.praOptions.api.getSelectedRows()
            let JRAselectedRows = vm.jraOptions.api.getSelectedRows()
            // let BOWselectedRows = vm.bowOptions.api.getSelectedRows()
            
            // Prepare the payload.
            let payload = {}
            payload.ora = []
            payload.jra = []
            payload.pra = []
            payload.bow = []
            payload.incidentid = vm.incident.ID
            payload.incident_number = vm.incident.IncidentNumber
            if(ORAselectedRows){

                for(row of ORAselectedRows){
                    payload.ora.push(row.rmm_ora_id)
                }
                vm.oraOptions.api.deselectAll()
            }
            if(PRAselectedRows){
                for(row of PRAselectedRows){
                    payload.pra.push(row.rmm_pra_id)
                }
                vm.praOptions.api.deselectAll()
            }
            if(JRAselectedRows ){
                for(row of JRAselectedRows){
                    payload.jra.push(row.rmm_jra_id)
                }
                vm.jraOptions.api.deselectAll()
            }
            vm.closeModal('RASelectionModal')
            if(payload.ora.length > 0 ||payload.pra.length > 0 ||payload.jra.length > 0   ){
                tirService.prepareRMMDocuments(payload).then(() =>{
                    vm.incidentModified = true
                    vm.getIncidentAttachments()
                })
            }
        }

        //function to append leading zeros
        function appendLeadingZeros (num, size=6){
            var s = "000000000" + num;
            return s.substr(s.length-size);
        }

        //Function to prepare Ag-Grid data with string values
        function prepareJraGridData() {
            let jraGridData = JSON.parse(JSON.stringify(vm.jraAGData))
            let rtrn = []
            
            jraGridData.forEach((rec) =>{
                 
                let newRec = rec

                newRec.exceptionFields = ['approvers','general_actions', 'hazard_actions', 'acknowledgements', 'participants', 'rmm_jra_enable']
                newRec.prefix = 'rmm_jra_'
                newRec.endfix = ['_per', '_rld']
                newRec.rmm_jra_site = getSiteName(rec.rmm_jra_site)
                newRec.rmm_jra_job = getJobNumber(rec.rmm_jra_job)
                newRec.rmm_jra_created_date = moment(rec.rmm_jra_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                newRec.rmm_jra_expiry_date = rec.rmm_jra_expiry_date===null?'':moment(rec.rmm_jra_expiry_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                newRec.rmm_jra_is_submitted  = rec.rmm_jra_state == 'active' ||  rec.rmm_jra_state == 'expired' ? true : false
                newRec.rmm_jra_revision_no = `${appendLeadingZeros(rec.rmm_jra_document_number)}`+'.'+`${appendLeadingZeros(rec.rmm_jra_doc_version_number,3)}`
                newRec.reviewedCount = rec.reviewers.length
                let approversList = ''
                rec.approvers.forEach((app) => {
                    approversList += app.full_name + ','
                })
                newRec.approvers =  approversList

                if(rec.dlo_enable.length !== 0){
                    newRec.dlo_status = rec.dlo_enable[0].dlo_enable
                    newRec.dlo_person = rec.dlo_enable[0].dlo_person
                }
                else{
                    newRec.dlo_status = true
                    newRec.dlo_person = null
                }
                
                let participantsList = ''
                rec.participants.forEach((par) => {
                    participantsList += (`${getEmployeeName(par)} - `)
                })
                newRec.participants = participantsList  
                if (!(rec.rmm_jra_state == 'draft'))                 
                    rtrn.push(newRec)           
                
            })
            return rtrn
        }

        function prepareOraGridData() {
            let oraGridData = JSON.parse(JSON.stringify(vm.oraAGData))
            let rtrn = []

            oraGridData.forEach((rec) =>{
                let newRec = rec
                newRec.exceptionFields = ['approvers','general_actions', 'hazard_actions', 'acknowledgements', 'participants', 'rmm_ora_enable']
                newRec.prefix = 'rmm_ora_'
                newRec.endfix = ['_per', '_rld']
                newRec.rmm_ora_site = getSiteName(rec.rmm_ora_site)
                newRec.rmm_ora_created_date = moment(rec.rmm_ora_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                newRec.rmm_ora_expiry_date =  rec.rmm_ora_expiry_date===null?'':moment(rec.rmm_ora_expiry_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                newRec.rmm_ora_is_submitted  = rec.rmm_ora_state == 'active' ||  rec.rmm_ora_state == 'expired' ? true : false
                newRec.rmm_ora_revision_no = `${appendLeadingZeros(rec.rmm_ora_document_number)}`+'.'+`${appendLeadingZeros(rec.rmm_ora_doc_version_number,3)}`
                if(rec.dlo_enable.length !== 0){
                    newRec.dlo_status = rec.dlo_enable[0].dlo_enable
                    newRec.dlo_person = rec.dlo_enable[0].dlo_person
                }
                else{
                    newRec.dlo_status = true
                    newRec.dlo_person = null
                }

                let approversList = ''
                rec.approvers.forEach((app) => {
                    approversList += app.full_name + ','
                })
                newRec.approvers =  approversList
                
                let participantsList = ''
                rec.participants.forEach((par) => {
                    participantsList += (`${getEmployeeName(par)} - `)
                })
                newRec.participants = participantsList
                if(!(rec.rmm_ora_state=='draft')){
                    rtrn.push(newRec)
                }             
            })
             
            return rtrn
        }

        //Listen for the date range componet
        $scope.$on('DATERANGE', (range) => {
            vm.mainDateFilter = {
                start_date: `${moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD')} 00:00:00.000`,
                end_date: `${moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')} 23:59:59.999`
            }
            $window.sessionStorage.setItem('start_month', moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('MM'))
            $window.sessionStorage.setItem('start_year', moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY'))
            $window.sessionStorage.setItem('end_month', moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('MM'))
            $window.sessionStorage.setItem('end_year', moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY'))
            $window.sessionStorage.setItem('start_date', moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD'))
            $window.sessionStorage.setItem('end_date', moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD'))
            vm.filterTir()

        })

        vm.hideDropdowns = () => {
            $('.dropdown-menu').removeClass('show')
            $('.filter-dropdown').removeClass('show')
            $('#sortByDropdown').removeClass('show')
            $('#assignIncidentDropdown').removeClass('show')
        }

        // HAP Form
        // vm.hapModalId = "tirHapModal"
        vm.hapModalId = 'hazardActionModal'
        vm.hazardEditData = {}

        vm.startHap = () => {
            if (!vm.allowRCAEdit) {
                toastr.error(translateTag(3905)) //"Unable to add new Incident Actions after supervisor sign-off.")
            }
            else {
                vm.actionMode = "new"
                vm.hazardEditData = {}
                vm.openModal(vm.hapModalId)
                vm.initializeSelect2(vm.hapModalId)             
                vm.headerData = vm.incidentHeader   
                setTimeout(()=>{
                    $scope.$broadcast('HARZARD_NEW_INCIDENT')
                },100)
            }
        }

        vm.resetHaps = () => {
            let id = vm.incident.ID
        }

        vm.openHaps = () => {
            vm.caMode = 'haps'
        }

        vm.closeHaps = () => {
            vm.caMode = 'files'
        }


        // GAP Form
        vm.gapModalId = "generalActionModal"
        vm.gapModel = {}

        vm.startGap = () => {
            if (!vm.allowRCAEdit) {
                toastr.error(translateTag(3905)) //"Unable to add new Incident Actions after supervisor sign-off.")
            }
            else {
                vm.actionMode = "new"
                vm.headerData = vm.incidentHeader
                vm.gapModel = {}
                vm.openModal(vm.gapModalId)
                vm.initializeSelect2(vm.gapModalId)
                setTimeout(()=>{
                    $scope.$broadcast('GENERAL_NEW_INCIDENT')
                },100)

            }
        }

        vm.resetGaps = () => {
            let id = vm.incident.ID
        }

        vm.openGaps = () => {
            vm.caMode = 'gaps'
        }

        vm.closeGaps = () => {
            vm.caMode = 'files'
        }

        vm.allowRCAEdit = true
        vm.showClearSignOffs = false    

        vm.clearSignoffConfirmationModal = () => {
            vm.modalElementsClearSignoff = {
                title: translateTag(2748), //"Clear Signatures"
                message: `<div><p>${translateTag(2747)}</p></div>`, //"You are about to remove all the signatures applied to the incident. This action is permanent. Do you want to continue?"
                buttons: 
                    `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Ok">{{vm.componentTranslateLabels(1405)}}</button>
                    <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" notes="Cancel" >{{vm.componentTranslateLabels(1257)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'TIRCLEARSIGNCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsClearSignoff)
        }

        $scope.$on("TIRCLEARSIGNCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.clearSignOffs()
            }
        })

        /** 
         * Method name : validationFormsModal
         * Parameter   : 
         * Description : function created for opening the modal with the warning message 
         * Ticket No.  : SOF-12477
        */
        vm.validationFormsModal = () => {
            vm.modalElementsClearSignoff = {
                title: translateTag(2182), // "Warning"
                message: `<div><p>${translateTag(9402)}</p></div>`, //The incident report must have at least one form mapped to it.
                buttons: 
                    `<button class="btn btn-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Ok" >{{vm.componentTranslateLabels(1405)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'TIRCLEARSIGNCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsClearSignoff)
        }

        // validation warning modal if the submission ids already part of another incident
        vm.validationExistingSubIdsModal = () => {
            vm.modalSubmissionWarning = {
                title: translateTag(2182), // "Warning"
                message: `<div><p>${translateTag(9421)}</p></div>`, // One or more of the selected items have already been linked to an incident. Please retry the operation.
                buttons: 
                    `<button class="btn btn-primary btn-rounded m-0 mr-3" ng-click="vm.return('button1')" note="Ok" >{{vm.componentTranslateLabels(1405)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'SUBMISSIONSEXISTSWARNINGMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalSubmissionWarning)
        }

        
        $scope.$on("SUBMISSIONSEXISTSWARNINGMODAL", (event,result) => {
            if (result=='button1') {
                modalService.Close("confirmModal")
                vm.filterTir() // refresh/reset the tir page
            }
        })


        
        vm.openSignoffsModal = (selectedRole) => {
            tirSignoffService.validateSignOffs(selectedRole.iso_id).then((response)=>{  
                if(response.data.message === 'unsigned'){
                    vm.selectedSignOffRole = selectedRole 
                    vm.modalElementsSelectSignoff = {
                        title: translateTag(3640), //"Sign off"
                        message: `<div><p>${translateTag(2746)}</p></div>`, //"You are about to sign off the incident. This action is permanent. Do you want to continue?"
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Ok">{{vm.componentTranslateLabels(1405)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" notes="Cancel" >{{vm.componentTranslateLabels(1257)}}</button>`
                    }
                    document.getElementById('confirmcallingform').innerHTML = 'TIRSELECTSIGNOFFCALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsSelectSignoff)
                }
                else{
                    vm.validateString = getEmployeeName(response.data.per_id) + ' ' +  translateTag(1448) + ' ' +
                                        (response.data.iso_signoff_datetime?  moment(response.data.iso_signoff_datetime).format('YYYY-MM-DD hh:mm:ss A') : '')
                    
                    vm.modalElementsValidateSignoff = {
                        title: translateTag(2182), //"Warning"
                        message: `<div><p>${vm.validateString}</p></div>`, //"already signoff on this role at"
                        buttons: `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Ok">{{vm.componentTranslateLabels(1405)}}</button>`
                    }
                    document.getElementById('confirmcallingform').innerHTML = 'TIRVALIDATESIGNOFFCALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsValidateSignoff)
                }
                  
            })
        }

        $scope.$on("TIRSELECTSIGNOFFCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.setIncidentSignOff()
            }
            else if (result=='button2') {
                vm.roleUserList.forEach((obj)=>{
                    if(obj.aro_id == vm.selectedSignOffRole.aro_id){
                        obj.isSigned = false
                    }
                }) 
                modalService.Close('confirmModal')
            }
        })

        $scope.$on("TIRVALIDATESIGNOFFCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.resetSignOff()
            }
        })

        vm.resetSignOff = (modalId) => {
            vm.setUserRoleSignOffs()
            modalService.Close('confirmModal')
        }
        
        vm.clearSignOffs = () =>{
            tirSignoffService.clearSignOffs(vm.incident.ID).then((success) => {

                if (success) {
                    vm.incidentModified = true
                    vm.showClearSignOffs = false
                    vm.incident.inc_is_quick_signoff=0
                    vm.resetSignOff()
                    vm.quickSignOffState = true

                    // Change to open status
                    vm.incident.inc_status = 2261 
                }
                else {
                    $(".ui.checkbox.").checkbox('set checked', true)
                }
            })
        }

        vm.setUserRoleSignOffs = () => {
            vm.roleUserList = []
            // get all roles with default sign offs
            tirSignoffService.getAllManagedRoles().then(() => {
                vm.defaultSignoffList = tirSignoffService.readAllRoleList()
            }).then(()=> {
                profileService.getPersonProfile().then(() =>{               
                    vm.userprofile = profileService.readPersonProfile()
                    vm.current_user_roles = vm.userprofile.role_ids.split(',')   
                    vm.current_user_roles = vm.current_user_roles.map(obj => obj.trim())
                }).then(()=>{
                    // get all sign offs respect to incident
                    tirSignoffService.getSignoffs(vm.incident.ID).then((selectedRoleList) => {
                        selectedRoleList.forEach(selected => {
                            vm.defaultSignoffList.forEach(role => { 
                                if(selected.iso_role_id == role.aro_id){
                                    role.roleSelected = true
                                    role.isSigned = selected.iso_per_id == null? false:true
                                    role.userSignOffPermission =  vm.current_user_roles.includes(role.aro_id.toString())? true: false
                                    role.iso_per_id = selected.iso_per_id
                                    role.per_full_name = selected.per_full_name
                                    role.iso_signoff_datetime = selected.iso_signoff_datetime?  moment(selected.iso_signoff_datetime).format('YYYY-MM-DD hh:mm:ss A') : ''
                                    role.iso_id = selected.iso_id
                                    vm.roleUserList.push(role)
                                    if(vm.roleUserList.length > 0){
                                        length = vm.roleUserList.filter(function(item){
                                            return item.isSigned;
                                        }).length;
                                        // help to disable the IA and Action buttons 
                                        if(length>0 || vm.incident.inc_is_quick_signoff ==1){
                                            vm.showClearSignOffs = true
                                        } else {
                                            vm.showClearSignOffs = false 
                                        }
                                    }
                                }
                            })
                        })
                        // stopping the spinner
                        $scope.$emit('STOPSPINNER')
                    })
                })
            })
        }

        vm.setIncidentSignOff = () => {         
            roleuser = vm.selectedSignOffRole
            if(roleuser.iso_id){
                tirSignoffService.addSignoff(roleuser.iso_id).then((response)=>{                    
                    if(response.data === "Success"){
                        vm.showClearSignOffs = true
                        vm.setUserRoleSignOffs()
                        modalService.Close('confirmModal')
                    }
                })
            }
        }


        vm.manageSignOffs = () => {                     
            tirSignoffService.getAllManagedRoles().then(() => {
                vm.allRoleList = tirSignoffService.readAllRoleList()
                tirSignoffService.getSignoffs(vm.incident.ID).then((selectedRoleList) => {            
                    selectedRoleList.forEach(selected => {
                        vm.allRoleList.forEach(role => { 
                            if(selected.iso_role_id == role.aro_id){
                                role.roleSelected = true
                            }
                        })
                    })

                    vm.leftRoleList = vm.allRoleList.splice(0, (Math.ceil(vm.allRoleList.length/2)))
                    vm.rightRoleList = vm.allRoleList 
                    vm.toggleRole()
                })

            }).then(() =>{               
                vm.openModal('manageSignoffsModal')
            })            
        }

        vm.cancelModal = (modalId) => {
            modalService.Close(modalId)
        }
        
        vm.toggleRole = () => {
            let rolelList = []
            rolelList = rolelList.concat(vm.leftRoleList, vm.rightRoleList)
            length = rolelList.filter(function(item){
                        return item.roleSelected;
                    }).length;

            if(length >= 3)
                vm.canSaveManageSignOff = true
            else
                vm.canSaveManageSignOff = false

        }

        vm.saveManageSignOff = () => {
            let saveRoles = { "role_ids": [], 'incidentId': vm.incident.ID }     
            // disabling the save button from the enduser to click multiple times
            vm.canSaveManageSignOff = false 
            let finalList = []
            finalList = finalList.concat(vm.leftRoleList, vm.rightRoleList)
            finalList.forEach(role => {
              if(role.roleSelected){      
                saveRoles.role_ids.push(role.aro_id)      
              }
            })

            tirSignoffService.addIncidentRoles(saveRoles).then((response) => {
                vm.incidentModified = true
                vm.setUserRoleSignOffs()
                modalService.Close('manageSignoffsModal')
            })

        }
    

        profileService.getAllTrainingEmployeeProfile().then(() => {
            vm.employees = profileService.readAllTrainingEmployeeProfile()
        })

        profileService.getFullEmployeeProfile().then(() => {
            vm.fullEmployees = profileService.readFullEmployeeProfile()
        })

        function processIncidentActions() {
            if (vm.incidentActions) {
                vm.completedActions = vm.incidentActions.filter((action) => {
                    action.action_by_when = moment(action.action_by_when).format('YYYY-MM-DD')
                    if (action.status.toLowerCase() == 'complete')
                        return true
                    return false
                }).length
                vm.totalActions = vm.incidentActions.length
            }
        }

        function processRootCauseAnalyses() {
            if (vm.rootCauseAnalyses) {
                vm.completedRCA = vm.rootCauseAnalyses.filter((rca) => {
                    if (rca.status && rca.status.toLowerCase() == 'complete')
                        return true
                    return false
                }).length
                vm.totalRCA = vm.rootCauseAnalyses.length
            }
        }

        vm.signoffAllowed = () => {
            if (vm.completedActions != null) {
                if (vm.totalActions && vm.totalActions > 0)
                    if (vm.completedActions < vm.totalActions)
                        return false
            }
            if (vm.totalRCA == 0)
                return false

            if (vm.completedRCA != null) {
                if (vm.totalRCA && vm.totalRCA > 0)
                    if (vm.completedRCA < vm.totalRCA)
                        return false
            }
            return true
        }

        vm.getSignoffEmployeeName = (type) => {
            let currentSignoff = vm.signoffs.filter((s) => {
                return s.Type === type
            })[0]

            if (!currentSignoff || currentSignoff == undefined)
                return ''
            
            let empName = vm.fullEmployees.filter((emp) => {
                return emp.per_id === currentSignoff.EmployeeID
            })[0]
            if (empName == undefined){
                return ""
            }
            empName = empName.per_full_name

            return '(' + empName + ')'
        }

        function newSignoff(empId, type) {
            return {
                EmployeeID: empId,
                Type: type
            }
        }

        //View Incident Report
        vm.viewIncidentReport = (reportUrl, incidentId) => {
            window.open(reportUrl + '&IncidentNumber=' + incidentId, '_blank')
        } 

        vm.viewReports = (id=null, actiontype) =>{            
            if (actiontype == "General"){
                vm.link = vm.singleServeReportUrl[0];
            } else if (actiontype == "Hazard"){
                vm.link = vm.singleServeReportUrl[1];
            }
            lang_number = localStorage.getItem('lang_id')
            vm.incidentReportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.link}/${id}?lang=${lang_number}&t=${vm.token}`)
            $window.open(vm.incidentReportURL, "_blank")

        }

        listService.getSelectListData('ref_general_action').then((res) => {
            vm.actionTypeList = res
        })

        // Remove all quick signoff information.
        vm.cancelQuickSignOff = () => {
            // Close the quick sign off modal.
            vm.quickSignOffComment= ""
            document.forms['quickSignOff'].classList.remove('was-validated')
            modalService.Close('quickSignOffModal')


        }

        // Adds the quick sign off to the incident.
        vm.quickSignOff = () => {

            //validate the form.
            //Must populate comment before proceeding.
            if (validateFormFields('quickSignOff')){
                //prepare the quick sign off payload.
                let payload = {}
                payload.incident_id = vm.incident.ID
                payload.note = vm.quickSignOffComment
 
                //Call end point and quick sign off this incident.
                tirSignoffService.quickSignOff(payload).then(() =>{
                    vm.incidentModified = true
                    modalService.Close('quickSignOffModal')
                    vm.incident.inc_is_quick_signoff = 1
                    vm.loadQuickSignOffInfo(vm.incident)
                    vm.quickSignOffComment=''
                    vm.showClearSignOffs = true
                    vm.quickSignOffState = true
                })
            }  else {
                vm.modalElements.message = translateTag(2183) //The form has fields that need attention. Please see fields marked in red.
                vm.modalElements.buttons = `<button class='btn btn-primary btn-rounded' ng-click="tir.closeConfirmModal()" note="OK">{{tir.translateLabels(1405)}}</button>`
           
                $('#tirFormConfirmModal .buttons').html($compile(vm.modalElements.buttons)($scope))
                setTimeout(() => {
                    modalService.Open('tirFormConfirmModal');
                    $scope.$apply();
                }, 500)
            }

        }
 
        vm.closeConfirmModal = () => {
            modalService.Close('tirFormConfirmModal')
        }

        vm.resetModal = () => {
            vm.modalElements = {
              title: 'Modal Title',
              message: 'Modal Message',
              buttons: `<button class='btn btn-primary btn-lg' ng-click="tir.closeConfirmModal())" note="OK">{{tir.translateLabels(1405)}}</button>`
            }
        }

        // Clear any validation when opening the quick signoff form.
        vm.openQuickSignOffForm = () => {
            document.forms['quickSignOff'].classList.remove('was-validated')
            vm.openModal('quickSignOffModal') 
        }

    }]
)