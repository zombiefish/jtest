﻿angular
    .module('safeToDo')
    .service('tirSignoffService', ['$http',
        function ($http) {

            let rolesList = []

            return {
                getSignoffs: function (incidentId) {
                    return $http.post(`${__env.apiUrl}/api/incident-management/get-incident-signoffs/`, {"incidentId": incidentId})
                        .then(function (response) {
                            return response.data;
                        }, function (errorParams) {
                            console.log('Failed to load tir signoffs', errorParams);
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                        });
                },
              
                addSignoff: function (iso_id) {
                    var url = `${__env.apiUrl}/api/incident-management/add-incident-signoffs/`
                    return $http.post(url,  {"iso_id": iso_id})
                        .then(function (response) {
                            return response;
                        }, function (errorParams) {
                            console.log('Failed to create new signoff', errorParams);
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                        });
                },

                removeSignoff: function (incidentId, employeeId, type) {
                    return $http.post(`${__env.apiUrl}/api/incident-management/remove-incident-signoffs/`,{"incidentId": incidentId,"personId": employeeId,"type": type})
                        .then(function (response) {
                            return response;
                        }, function (errorParams) {
                            console.log('Failed to remove signoff', errorParams);
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                        });
                },

                clearSignOffs: function (incidentId) {
                    return $http.post(`${__env.apiUrl}/api/incident-management/clear-incident-signoffs/`,{"incidentId": incidentId})
                        .then(function (response) {
                            return response;
                        }, function (errorParams) {
                            console.log('Failed to remove signoff', errorParams);
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                        });
                },

                getAllManagedRoles: function () {
                    return $http.get(`${__env.apiUrl}/api/incident-management/incident-get-role-list/`).then((response) =>{
                        rolesList = response.data
                    }, (errParams) => {
                        var errorObj = {};
                        if (errParams.status == 404) {
                            errorObj.error = translateTag(3781) 
                        }
                        else if(errParams.status === 403 && errParams.data.detail) {
                            toastr.error(errParams.data.detail)
                        }
                        return errorObj;
                    })
                },

                
                addIncidentRoles: function (payload) {
                    var url = `${__env.apiUrl}/api/incident-management/add-incident-roles/`
                    return $http.post(url, payload)
                        .then(function (response) {
                            return response;
                        }, function (errorParams) {
                            console.log('Failed to create new signoff', errorParams);
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                        });
                },


                validateSignOffs: function (iso_id) {                    
                    return $http.post(`${__env.apiUrl}/api/incident-management/validate-signoff/`,{"iso_id": iso_id})
                        .then(function (response) {                           
                            return response;
                        }, function (errorParams) {
                            console.log('Failed to validate signoff', errorParams);
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                        });
                },

                readAllRoleList: () =>{
                    return rolesList
                },  

                quickSignOff: function(payload) {
                    let url = `${__env.apiUrl}/api/incident-management/create-quick-signoff/`
                    return $http.post(url, payload)
                        .then((response)  => {
                            return response
                        }, (errorParams) => {
                            console.log("Failed to Quick Sign-off incident", errorParams)
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                        })
                },

                quickSignOffInfo: function(payload){
                    let url = `${__env.apiUrl}/api/incident-management/get-quick-signoff-info/`
                    return $http.post(url, payload)
                        .then((response) => {
                            return response
                        }, (errorParams) => {
                            console.log("Failed to get quick signoff information", errorParams)
                            if(errorParams.status === 403 && errorParams.data.detail){
                                toastr.error(errorParams.data.detail)
                            }
                            else
                                toastr.error(errorParams.data.error)
                        })  
                }

            };
        }
    ]);