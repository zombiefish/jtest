angular
    .module('safeToDo')
    .service('documentLockService', ['$http',
        function($http){
            return {
                docLock(payload){
                    return $http.get(`${__env.apiUrl}/api/dl/get-document-lock-type/`).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load document lock details ', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                    })
                },
                docLock(payload){
                    return $http.post(`${__env.apiUrl}/api/dl/doc-lock/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load document lock details ', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                    })
                },                     
                closeDocLock(payload){
                    return $http.post(`${__env.apiUrl}/api/dl/close-doc-lock/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load document lock details ', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                    })
                },
                intervalDocLock(data){
                    payload = {}
                    payload.dlo_id = data
                    return $http.post(`${__env.apiUrl}/api/dl/interval-doc-lock/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load document lock details ', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                    })
                },
            }
        }        
    ])