﻿angular
    .module('safeToDo')
    .service('listService', ['$http', '$q',
        function ($http, $q) {
            let actionTypes = [];
            let frequencies = {
                A: [],
                O: {}
            };
            let employees = {
                A: [],
                O: {}
            };
            let hazardTypes = {
                A: [],
                O: {}
            };
            let hazardIdentifications = {
                A: [],
                O: {}
            };
            let potentialLoss = {
                A: [],
                O: {}
            };
            // Root Cause Analysis DDLs
            let preliminaryTypes = [];
            let actualTypes = [];
            let incidentTypes = [];
            let potentialLosses = [];
            let immediateCauses = [];
            let immediateCauseTypes = [];
            let basicCauses = [];
            let basicCauseTypes = [];
            let basicCauseCategories = [];
            let preliminaryIncidentTypeCategories = [];
            let preliminaryIncidentTypeDetails = [];
            let actualIncidentTypeCategories = [];
            let actualIncidentTypeDetails = [];
            //

            let jobs = [];
            let jobsListByDataVisibility = [];
            let sitesListByDataVisibility = [];            
            let sites = [];
            let fullSites = []
            let fullJobs = []
            let minIncidentYear = ''

            function storeList(listStorageObject, listArray) {
                for (let i = 0; i < listArray.length; i++) {
                    listStorageObject.O[listArray[i].rld_code + ''] = listArray[i];
                    listStorageObject.A.push(listArray[i]);
                }
            }

            $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_action_type", "language": selectedLanguage })
                .then((response) => {
                    // does not use storeList because action types don't use this A/O storage pattern
                    // TODO: refactor here and refactor consumers
                    actionTypes.length = 0;
                    for (let i = 0; i < response.data.length; i++) {
                        actionTypes.push(response.data[i])
                    }
                }, (args) => {
                    console.log('Failed to load Action Types list.',args);
                 })

            let freqPromise = $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_frequency", "language": selectedLanguage  })
              .then(function (response) {
                  storeList(frequencies, response.data);
                }, function (args) {
                    console.log('Failed to load Frequencies list.');
                    console.log(args);
                });

            let hazardTypesPromise = $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_hazard_type", "language": selectedLanguage  })
                .then(function (response) {
                    storeList(hazardTypes, response.data);
                }, function (args) {
                    console.log('Failed to load Hazard Types list.');
                    console.log(args);
                });

             let hazardIdentificationsPromise = $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_hazard_identification", "language": selectedLanguage  })
                .then(function (response) {
                    storeList(hazardIdentifications, response.data);
                }, function (args) {
                    console.log('Failed to load Hazard Identifications list.');
                    console.log(args);
                });

             let potentialLossPromise = $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_potential_loss", "language": selectedLanguage  })
                .then(function (response) {
                    storeList(potentialLoss, response.data);
                }, function (args) {
                    console.log('Failed to load Potential Loss list.');
                    console.log(args);
                });
 
            let jobsPromise = $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_job", "language": selectedLanguage  })
                .then(function (response) {
                    return response.data;
                }, function (args) {
                    console.log('Failed to load jobs list.');
                    console.log(args);
                });

            let sitesPromise = $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_site", "language": selectedLanguage  })
                .then(function (response) {
                    return response.data;
                }, function (args) {
                    console.log('Failed to load sites list.');
                    console.log(args);
                });

            return {
                getEmployeeList: function () {
                    return $http.get(`${__env.apiUrl}/api/employee/get-employee-list/`)
                        .then(function (response) {
                            return response.data;
                        }, function (errorParams) {
                            console.log('Failed to load reports');
                            console.log(errorParams);
                        });
                }, 
                getExternalContactList: function () {
                    return $http.get(`${__env.apiUrl}/api/edl/get-external-contact-list/`)
                        .then(function (response) {
                            return response.data;
                        }, function (errorParams) {
                            console.log('Failed to load External Contacts List');
                            console.log(errorParams);
                        });
                },                 
                getAllEmployeeList: function () {
                    return $http.get(`${__env.apiUrl}/api/employee/get-all-employee-list/`)
                        .then(function (response) {
                            return response.data;
                        }, function (errorParams) {
                            console.log('Failed to load reports');
                            console.log(errorParams);
                        });
                },                 
                getSelectListData: function (list) {
                    if(list==='ref_site'){
                        
                        return $http.get(`${__env.apiUrl}/api/employee/get-filtered-site-job/site/`,)
                            .then(function (response) {                                
                                return response.data.sites
                                //  return response.data;
                            }, function (errorParams) {
                                console.log('Failed to load reports');
                                console.log(errorParams);
                            });
                    }
                    else if(list==='ref_job'){
                        return $http.get(`${__env.apiUrl}/api/employee/get-filtered-site-job/job/`,)
                            .then(function (response) {
                            return response.data.jobs
                            //  return response.data;
                            }, function (errorParams) {
                                console.log('Failed to load reports');
                                console.log(errorParams);
                            });
                    }
                    else{
                        return $http.post(`${__env.apiUrl}/api/listmanifest/get-active-list-manifest-data-by-condition/`, { "validatorStr": list , "language": selectedLanguage })
                        .then(function (response) {
                            return response.data;
                        }, function (errorParams) {
                            console.log(`Failed to load ${list}`);
                            console.log(errorParams);
                        });
                    }                    
                }, 
                getFullSiteList: function () {                    
                    return $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": 'ref_site', "language": selectedLanguage  })
                        .then(function (response) {
                            fullSites = response.data
                          //  return response.data;
                        }, function (errorParams) {
                            console.log('Failed to load reports');
                            console.log(errorParams);
                        });
                },
                getFullJobList: function () {                    
                    return $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": 'ref_job', "language": selectedLanguage  })
                        .then(function (response) {
                            fullJobs = response.data
                          //  return response.data;
                        }, function (errorParams) {
                            console.log('Failed to load reports');
                            console.log(errorParams);
                        });
                },
                getJobList: function () {
                    return $http.get(`${__env.apiUrl}/api/employee/get-filtered-site-job/job/`,)
                        .then(function (response) {
                          jobsListByDataVisibility = response.data.jobs
                          //  return response.data;
                        }, function (errorParams) {
                            console.log('Failed to load reports');
                            console.log(errorParams);
                        });
                    // return $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_job" })
                    //     .then(function (response) {
                    //         jobs = response.data
                    //       //  return response.data;
                    //     }, function (errorParams) {
                    //         console.log('Failed to load reports');
                    //         console.log(errorParams);
                    //     });
                }, 
                
                getSiteList: function () {
                    // return $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_site" })
                    //     .then(function (response) {
                    //         sites = response.data
                    //       //  return response.data;
                    //     }, function (errorParams) {
                    //         console.log('Failed to load reports');
                    //         console.log(errorParams);
                    //     });                    
                    return $http.get(`${__env.apiUrl}/api/employee/get-filtered-site-job/site/`,)
                        .then(function (response) {
                            sitesListByDataVisibility = response.data.sites
                            //  return response.data;
                        }, function (errorParams) {
                            console.log('Failed to load reports');
                            console.log(errorParams);
                        });
                }, 

                getJobListByDataVisibility: function () {
                    return $http.get(`${__env.apiUrl}/api/employee/get-filtered-site-job/job/`,)
                        .then(function (response) {
                          jobsListByDataVisibility = response.data.jobs
                          //  return response.data;
                        }, function (errorParams) {
                            console.log('Failed to load reports');
                            console.log(errorParams);
                        });
                },

                getAllJobListByDataVisibility: function () {
                    return $http.get(`${__env.apiUrl}/api/employee/get-filtered-site-job/joball/`,)
                        .then(function (response) {
                          jobsListByDataVisibility = response.data.jobs
                          //  return response.data;
                        }, function (errorParams) {
                            console.log('Failed to load reports');
                            console.log(errorParams);
                        });
                },
                
                getSiteListByDataVisibility: function () {
                    return $http.get(`${__env.apiUrl}/api/employee/get-filtered-site-job/site/`,)
                        .then(function (response) {
                            sitesListByDataVisibility = response.data.sites
                          //  return response.data;
                        }, function (errorParams) {
                            console.log('Failed to load reports');
                            console.log(errorParams);
                        });
                }, 
         
                readJobs: () =>{
                   return jobs
                },
                readJobsByDataVisibility: () =>{
                    return jobsListByDataVisibility
                },
                readSitesByDataVisibility: () =>{
                    return sitesListByDataVisibility
                },                
                readSites: () =>{
                    return sites
                },                

                getActionTypes: function () {
                    return actionTypes;
                },
                getFrequenciesP: function () {
                    return freqPromise;
                },
                getFrequencies: function () {
                    return frequencies;
                },
                getEmployeesP: function () {
                    return employeePromise;
                },
                getEmployees: function () {
                    return employees;
                },
                getHazardTypesP: function () {
                    return hazardTypesPromise;
                },
                getHazardTypes: function () {
                    return hazardTypes;
                },
                getHazardIdentificationsP: function () {
                    return hazardIdentificationsPromise;
                },
                getHazardIdentifications: function () {
                    return hazardIdentifications;
                },
                getPotentialLossP: function () {
                    return potentialLossPromise;
                },
                getPotentialLoss: function () {
                    return potentialLoss;
                },
                getJobsP: function () {
                    return jobsPromise;
                },
                getJobs: function () {
                    return jobs;
                },
                getSitesP: function () {
                    return sitesPromise;
                },
                getSites: function () {
                    return sites;
                },
                readFullSites: function () {
                    return fullSites;
                },
                readFullJobs: function () {
                    return fullJobs;
                },
                // Root Cause Analysis DDLs
                getPreliminaryTypes: function () {
                    return preliminaryTypes;
                },
                getPotentialLosses: function () {
                    return potentialLosses;
                },
                getActualTypes: function () {
                    return actualTypes;
                },
                getIncidentTypes: function () {
                    return incidentTypes;
                },
                getImmediateCauses: function () {
                    return immediateCauses;
                },
                getImmediateCauseTypes: function () {
                    return immediateCauseTypes;
                },
                getBasicCauses: function () {
                    return basicCauses;
                },
                getBasicCauseTypes: function () {
                    return basicCauseTypes;
                },
                getBasicCauseCategories: function () {
                    return basicCauseCategories;
                },
                getActualIncidentTypeCategories: function () {
                    return actualIncidentTypeCategories;
                },
                getActualIncidentTypeDetails: function () {
                    return actualIncidentTypeDetails;
                },
                getPreliminaryIncidentTypeCategories: function () {
                    return preliminaryIncidentTypeCategories;
                },
                getPreliminaryIncidentTypeDetails: function () {
                    return preliminaryIncidentTypeDetails;
                },
                fetchRootCauseAnalysisLists: function () {
                    return $q.all([
                        $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_preliminary_incident_type", "language": selectedLanguage  }).then(function (response) { return response.data; }, function (error) { console.log(error); }),
                        $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_actual_type", "language": selectedLanguage  }).then(function (response) { return response.data; }, function (error) { console.log(error); }),
                        $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_potential_loss", "language": selectedLanguage  }).then(function (response) { return response.data; }, function (error) { console.log(error); }),
                        $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_immediate_cause", "language": selectedLanguage  }).then(function (response) { return response.data; }, function (error) { console.log(error); }),
                        $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_immediate_cause_type", "language": selectedLanguage  }).then(function (response) { return response.data; }, function (error) { console.log(error); }),
                        $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_basic_cause", "language": selectedLanguage  }).then(function (response) { return response.data; }, function (error) { console.log(error); }),
                        $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_basic_cause_type", "language": selectedLanguage  }).then(function (response) { return response.data; }, function (error) { console.log(error); }),
                        $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_basic_cause_category", "language": selectedLanguage  }).then(function (response) { return response.data; }, function (error) { console.log(error); }),
                        $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_incident_type", "language": selectedLanguage  }).then(function (response) { return response.data; }, function (error) { console.log(error); }),
                        $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_preliminary_incident_type_category", "language": selectedLanguage  }).then(function (response) { return response.data; }, function (error) { console.log(error); }),
                        $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_preliminary_incident_type_detail", "language": selectedLanguage  }).then(function (response) { return response.data; }, function (error) { console.log(error); }),
                        $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_actual_incident_type_category", "language": selectedLanguage  }).then(function (response) { return response.data; }, function (error) { console.log(error); }),
                        $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_actual_incident_type_detail", "language": selectedLanguage  }).then(function (response) { return response.data; }, function (error) { console.log(error); }),
                    ])
                        .then(function (responses) {
                        preliminaryTypes = responses[0];
                        actualTypes = responses[1];
                        potentialLosses = responses[2];
                        immediateCauses = responses[3];
                        immediateCauseTypes = responses[4];
                        basicCauses = responses[5];
                        basicCauseTypes = responses[6];
                        basicCauseCategories = responses[7];
                        incidentTypes = responses[8];
                        preliminaryIncidentTypeCategories = responses[9];
                        preliminaryIncidentTypeDetails = responses[10];
                        actualIncidentTypeCategories = responses[11];
                        actualIncidentTypeDetails = responses[12];
                    });
                },
            };
        }
    ]);