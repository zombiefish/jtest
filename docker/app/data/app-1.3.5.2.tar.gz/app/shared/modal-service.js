﻿angular
    .module('safeToDo')
    .service('modalService', [
        function () {
            let modals = [] // array of modals on the page
            let service = {}
            
            service.Add = (modal) => {
                // add modal to array of active modals
                modals.push(modal)
            }

            service.Remove = (id) => {
                // remove modal from array of active modals
                let newModals = []
                for (let i = 0; i < modals.length; i++) {
                    if (modals[i].id !== id) {
                        newModals.push(modals[i])
                    }
                }
                modals = newModals
            }

            service.Open = (id) => {
                // open modal specified by id
                for (let i = 0; i < modals.length; i++) {
                  if (modals[i].id === id) {
                        modals[i].open();
                    }
                }
            }
            
            service.Close = (id) => {
                // close modal specified by id
                for (let i = 0; i < modals.length; i++) {
                    if (modals[i].id === id) {
                        modals[i].close()
                    }
                }
            }

            return service
        }
    ])