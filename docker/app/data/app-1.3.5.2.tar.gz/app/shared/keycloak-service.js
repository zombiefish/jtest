angular
    .module('safeToDo')
    .service('keycloakService', ['$http', '$q', '$interval',
        function ($http, $q, $interval) {
			let keycloak = Keycloak('js/keycloak.json');
			function initializeKeycloak() {
				keycloak.init({
					onLoad: 'check-sso',
					silentCheckSsoRedirectUri: window.location.origin + '/silent-check-sso',
				}).then((authenticated) => {
					 if(authenticated){
						$.ajax({
							url: `${__env.apiUrl}/api/user/check-app/`,
							type: 'get',
							contentType: 'application/json',
							beforeSend: function(request) {
							  request.setRequestHeader("Authorization", `Bearer ${keycloak.token}`)
							},
							success: (data) => {
							},
							error: (data) => {
							  window.location = "/accessdenied.html"
							}
						})
	
						keycloak.loadUserInfo().then((user)=> {                  
						sessionId = keycloak.sessionId
						window.localStorage.setItem('sso_session_id', sessionId)
						let payload = {
							"session_id": sessionId
							}
						$http.delete(`${__env.apiUrl}/api/user/clear-legacy-session-sso/`, payload)
						session_token = {
							"access": keycloak.token,
							"refresh" : keycloak.refreshToken,
							"user_full_name" : user.name,
							"email":user.email
						}
						window.localStorage.setItem('KEYCLOAK_INITIALIZED', 'true')
						window.localStorage.setItem('token', JSON.stringify(session_token))
						autoRefreshToken = $interval(() => {
							currentToken = JSON.parse(window.localStorage.getItem('token'))
							if(keycloak.token) {
								keycloak.updateToken(10800).then(() => {
									currentToken.access = keycloak.token
									window.localStorage.setItem('token', JSON.stringify(currentToken))
									//initializeKeycloak() 
								}).catch((err) => {
									window.localStorage.removeItem('token')
									window.location.href = "/login.html"
								})
							}
							else {
								window.localStorage.removeItem('token')
								window.location.href = "/login.html"
							}
						},10000)
						})
					 }
					 else {
						window.localStorage.removeItem('token')
						window.location.href = "/login.html"
					 }
				   }).catch((err)=>{
						console.log("This is the Keycloak Error", err)
				   })


			}

			initializeKeycloak()  

			return {
				keycloakObj: () => {
					return keycloak
				},

				clearLegacySessionInSSO: () => {
					let payload = {
						"session_id": sessionId
					}
					$http.delete(`${__env.apiUrl}/api/user/clear-legacy-session-sso/`, payload).then((response) => {
						return true
					}, (errorParams) => {
						console.log('Failed to clear legacy session', errorParams)
						return false
					});
				}
			}
}])