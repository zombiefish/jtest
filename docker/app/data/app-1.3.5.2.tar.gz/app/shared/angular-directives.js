angular
    .module('safeToDo')
    .directive('htmlDecode', function() {
        return {
        require: 'ngModel',
        link: function(scope, element, attrs, modelCtrl) { 
            modelCtrl.$formatters.push(function (inputValue) {

                if(!inputValue || typeof inputValue != "string")
                    return inputValue

                let transformedInput = inputValue.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')

                if (transformedInput!=inputValue) {
                    modelCtrl.$setViewValue(transformedInput)
                    modelCtrl.$render()
                }
        
                return transformedInput
            })
        }
        }
    })