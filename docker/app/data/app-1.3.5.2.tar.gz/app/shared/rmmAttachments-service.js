angular
    .module('safeToDo')
    .service('rmmAttachmentsService', ['$http',
        function ($http) { 

            return {
                getRmmAttachments: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/attachments/get_rmm_attachments/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load rmm attachments', errorParams)
                    })
                },

                addRmmAttachments: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/attachments/add-rmm-attachments/`, payload,{
                        // this cancels AngularJS normal serialization of request
                        transformRequest: angular.identity,
                        // this lets browser set `Content-Type: multipart/form-data` 
                        // header and proper data boundary
                        headers: {'Content-Type': undefined}}).then((response) =>{
                        return response
                    }, (errorParams) => {
                        console.log('Failed to add rmm attachment', errorParams)
                    })
                },

                removeRmmAttachments: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/attachments/remove-rmm-attachments/`, payload).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to remove rmm attachments', errorParams)
                    })
                }, 

                //End
            }
            
        }
    ])