﻿// Came from the comments here:  https://gist.github.com/maruf-nc/5625869
angular
    .module('safeToDo')
    .filter('titlecase', function () {
      return function (input) {
        if(selectedLanguage=="en"){
            input = input || ''
                let ignoreWords = ['vfl', 'tir', 'ppe', 'sts', 'op', 'jhsc','a&m']
                if(input.toString().toLowerCase() === 'positive identification')
                {
                    input = 'Positive Recognition'
                }
                if(input.toLowerCase()  === 'procedure-phr audit'){
                    return 'Procedure-PHR Audit'
                }
                if(input.toLowerCase() === 'supervisor lineup audit'){
                    return 'Supervisor Lineup Audit'
                }
                if(input.toLowerCase() === 'task vs mtcu training audit'){
                    return 'Task vs MTCU Training Audit'
                }
                if(input.toLowerCase() === 'cap and powder mag audit'){
                    return 'Cap and Powder Mag Audit'
                }
                if(input.toLowerCase() === 'vale n.a.p.g. flha'){
                    return 'Vale N.A.P.G. FLHA'
                }
                if(input.toLowerCase() === 'pre-task'){
                    return 'Pre-Task'
                }
                if(input.toLowerCase() === 'sts'){
                    return 'STS'
                }
                if(input.toString().substring(0,4) == 'ref_')
                {
                    input = input.slice(4,).replace(/_/g, " ").toLowerCase().split(' ').map((s) => s.charAt(0).toUpperCase() + s.substring(1)).join(' ');
                    return input;
                }
                else if(input.toString().toLowerCase() == 'safety-jhs board audit') {
                    return "Safety-JHS Board Audit"
                }
                else if(input.toString().toLowerCase() == 'hot/cold evaluation') {
                    return "Hot/Cold Evaluation"
                }
                else if (input.toString().indexOf(' ') !== -1) {
                    var inputPieces,
                        i

                    input = input.toString().toLowerCase()
                    inputPieces = input.split(' ')

                    for (i = 0; i < inputPieces.length; i++) {
                        if (ignoreWords.indexOf(inputPieces[i]) == -1)
                            inputPieces[i] = capitalizeString(inputPieces[i])
                        else
                            inputPieces[i] = inputPieces[i].toString().toUpperCase()
                    }

                    return inputPieces.toString().replace(/,/g, ' ')
                }
                else if(input.toString().toLowerCase() == 'pre-op') {
                    return "Pre-OP"
                }
                else {
                    input = input.toString().toLowerCase()
                    return capitalizeString(input)
                }

                function capitalizeString(inputString) {
                    return inputString.toString().substring(0, 1).toUpperCase() + inputString.toString().substring(1)
                }
        }
        else {
            if(input.toLowerCase() === 'ssf'){
                return 'SSF'
            }
            if(input.toLowerCase() === 'sse'){
                return 'SSE'
            }            
            allLowerCase=input.toString().toLowerCase()
            firstCapital=allLowerCase.charAt(0).toUpperCase() + allLowerCase.slice(1)
            return firstCapital;
        }
    }
})

angular
    .module('safeToDo')
    .filter('htmlDecode', function() {
        return function (input) {

            if(!input || typeof input != "string")
                    return input

            let transformedInput = input.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
    
            return transformedInput
        }
    })
