angular
    .module('safeToDo')
    .service('select2Service', [function () {

        return {

            select2Tags: () => {
                //fires on all select2 multi selects to ensure X of X sticks, as it won't work correctly otherwise.
                $('.select-multiple').each((index, element)=>{
                    var selected = $(element).val().length;
                    var total = $(element).find("option").length;           
                    if (selected > 4) {
                        $(element).parent().find(".select2 .select2-selection ul").append("<li class='Select2CustomList'>" + selected + " " + translateTag(1131) + " " + total + "</li>")
                        $(element).parent().find(".select2-selection__rendered").addClass("mt-1")
                        $(element).parent().find('.select2-selection__choice').each(function() {$( this ).addClass( "d-none" )}) 
                    }

                })

                //fires on target select2 multi select
                $('.select-multiple').on('change', function (e) {
                    $('.select-multiple').each((index, element)=>{
                        var selected = $(element).val().length;
                        var total = $(element).find("option").length; 
                        setTimeout(() => {
                            if (selected > 4) {
                                if ($(element).parent().find(".Select2CustomList").length > 0){
                                    $(element).parent().find(".select2 .select2-selection ul .Select2CustomList").replaceWith("<li class='Select2CustomList'>" + selected + " " + translateTag(1131) + " " + total + "</li>")
                                } else {
                                    $(element).parent().find(".select2 .select2-selection ul").append("<li class='Select2CustomList'>" + selected + " " + translateTag(1131) + " " + total + "</li>")
                                }
                                $(element).parent().find(".select2-selection__rendered").addClass("mt-1")
                                $(element).parent().find('.select2-selection__choice').each(function() {$( this ).addClass( "d-none" )}) 
                            }
                        },0)
                    })    
                })

            },
            
            // select2 for the homepage with minimize more than 2 selected values and dropdown list contains SELECT ALL
            select2Tags_2_max: () => {
                //fires on all select2 multi selects to ensure X of X sticks, as it won't work correctly otherwise.
                $('.select-multiple').each((index, element)=>{
                    let selected = $(element).val().length;
                    let total = $(element).find("option").length - 1;           
                    if (selected > 2) {
                        $(element).parent().find(".select2 .select2-selection ul").append("<li class='Select2CustomList'>" + selected + " " + translateTag(1131) + " " + total + "</li>")
                        $(element).parent().find(".select2-selection__rendered").addClass("mt-1")
                        $(element).parent().find('.select2-selection__choice').each(function() {$( this ).addClass( "d-none" )}) 
                    }

                })

                //fires on target select2 multi select
                $('.select-multiple').on('change', function (e) {
                    $('.select-multiple').each((index, element)=>{
                        let selected = $(element).val().length;
                        let total = $(element).find("option").length-1; 
                        setTimeout(() => {
                            if (selected > 2) {
                                if ($(element).parent().find(".Select2CustomList").length > 0){
                                    $(element).parent().find(".select2 .select2-selection ul .Select2CustomList").replaceWith("<li class='Select2CustomList'>" + selected + " " + translateTag(1131) + " " + total + "</li>")
                                } else {
                                    $(element).parent().find(".select2 .select2-selection ul").append("<li class='Select2CustomList'>" + selected + " " + translateTag(1131) + " " + total + "</li>")
                                }
                                $(element).parent().find(".select2-selection__rendered").addClass("mt-1")
                                $(element).parent().find('.select2-selection__choice').each(function() {$( this ).addClass( "d-none" )}) 
                            }
                        },0)
                    })    
                })

            },
        }


}]);