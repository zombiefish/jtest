angular
    .module('safeToDo')
    .service('exportCSV', function() {
        return {       
          

          // function to ungroup data for - equipments, custom-forms, targets and training data
          split_nested_lists : (rows, category) =>{
            let modified_rows = []
            rows.forEach(row => {
              row[category].forEach(item => {
                  let temp_row = {}
                  for(let [key, value] of Object.entries(row)){
                      if(key != category)
                          temp_row[key] = value
                  }
                  for(let [key, value] of Object.entries(item)){
                      temp_row[key] = value
                  }
                  modified_rows.push(temp_row)
              });
            });
            return modified_rows
          },
          

          // function to generate csv for the selected data
          export_csv: (rows_data, title) => {
              
            let rows = JSON.parse(JSON.stringify(rows_data))

            rows.forEach(row => {
              if('distribution_emails' in row){                    
                row['distribution_emails'] = row['distribution_emails'] != undefined? row['distribution_emails'].join(',') : ''
              }
              if('dlo_enable' in row){
                delete row['dlo_enable']
                delete row['dlo_status']
                delete row['dlo_person']
              }
              // by default it will delete only if distribition is in row. as we have distribution_emails already existed. 
              // and distribution contains data with <table> html tags
              delete row['distribution'] 
            })             

            let csvOutput = ''

            // create list of header values from the selecte data
            let header_values_list = []
            rows.forEach(row => {
              for (let[key, value] of Object.entries(row)){
                if(!header_values_list.includes(key)){
                  header_values_list.push(key)
                }
              }
            });

            // generate translated data for header values.
            let th_values = {}
            header_values_list.forEach(value => {
              translated_value = translateAgGridField(value)
              th_values[value] = translated_value                  
            });

            // convert data to csv format
            csvOutput += convertToCSV(rows, th_values)
            

            // download converted data in csv format
            let anchor = angular.element('<a/>')
            blob = new Blob([csvOutput], { type: 'text/csv' })
            var csvUrl = URL.createObjectURL(blob)
            anchor.attr({
                href: csvUrl,
                target: '_blank',
                download: `${title}.csv`
            })[0].click()
                
          },
        }
        // JSON to CSV Converter
        function convertToCSV(rows, th_values) {
          let csv_data = ''          

          // create comma seprated list of header values to insert into csv
          // not including undefined values - if it's undefined i.e., translation is not available in agGridFiledTags.json file
          // and is not used in tippy or unsed data
          for (let [key, value] of Object.entries(th_values)) {
            if(value != undefined){
              csv_data += `"${th_values[key]}",`
            }
          }
          csv_data = csv_data.slice(0,-1)
          csv_data +='\r\n'

          // create comma seprated list for the values of selcted data 
          rows.forEach(row => {
            let csv_row = ''            
            for (let [key, value] of Object.entries(th_values)) {
              if(value != undefined){
                if(Object.keys(row).includes(key)){
                  let row_value = row[key]
                  if(row_value === undefined || row_value === null){
                    row_value = ' '
                  }                  
                  if(typeof row_value === 'string'){
                    // do not remove below line code - might need for future reference 
                    // - used to remove new line characters or line breaks from value of selected data
                    row_value = row_value.replace(/(\r\n|\n|\r|\s+|\t|&nbsp;)/gm,' ');
                    row_value = row_value.replace(/"/g, '""');
                    row_value = row_value.replace(/ +(?= )/g,'');
                    row_value = `"${row_value}"`
                  }
                  csv_row += `${row_value},`
                }
                else{
                  csv_row += `" ",`
                }
              }
            }
            csv_data += `${csv_row.slice(0, -1)}\r\n`
          })
          return csv_data;
        }
    })