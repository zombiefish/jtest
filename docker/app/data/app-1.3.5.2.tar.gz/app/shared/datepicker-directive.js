﻿angular
    .module('safeToDo')
    .directive('datepicker', function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            scope: {
                dateFormat: '@',
                noFuture: '@',
                minDate: '@'
            },
            link: function (scope, element, attrs, ctrl) {
                var datePickerOptions = {
                    dateFormat: !scope.dateFormat ? 'mm/dd/yy' : scope.dateFormat,
                    onSelect: function (date) {
                        ctrl.$setViewValue(date);
                        ctrl.$render();
                        scope.$apply();
                    },
                    beforeShow: function (element, datepicker) {
                        console.log("It is in the Directive.")
                        if (scope.noFuture) {
                            angular.element(element).datepicker("option", "maxDate", '+0D');
                        }
                        if (scope.minDate) {
                            var pcs = scope.minDate.split('-');
                            var dt = new Date(pcs[0], pcs[1]-1, pcs[2]);
                            angular.element(element).datepicker("option", "minDate", dt);
                        }
                    },
                };


                $(element).datepicker(datePickerOptions);
            }
        };
    });