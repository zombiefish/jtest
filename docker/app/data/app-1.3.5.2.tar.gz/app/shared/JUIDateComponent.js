﻿function JUIDateComponent() {

};

JUIDateComponent.prototype.init = function (params) {
    this.eGui = document.createElement('div');
    this.eGui.innerHTML = '<input class="date-input" type="text" />';
    this.eInput = this.eGui.querySelectorAll('input')[0];

    this.listener = params.onDateChanged;
    this.eInput.addEventListener('input', this.listener);

    var that = this;
    $(this.eInput).datepicker({
        dateFormat: 'mm/dd/yy',
        onSelect: function () {
            that.listener();
        }
    });
};

JUIDateComponent.prototype.getGui = function () {
    return this.eGui;
};

JUIDateComponent.prototype.getDate = function () {
    return $(this.eInput).datepicker("getDate");
};

JUIDateComponent.prototype.setDate = function (date) {
    $(this.eInput).datepicker("setDate", date);
};

JUIDateComponent.prototype.destroy = function () {
    this.eInput.removeEventListener('input', this.listener)
};

JUIDateComponent.prototype.afterGuiAttached = function () {
    $('#ui-datepicker-div').click(function (e) {
        e.stopPropagation();
    });
};