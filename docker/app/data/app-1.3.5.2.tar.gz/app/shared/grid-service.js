﻿angular
    .module('safeToDo')
    .service('gridService', [function () {
        var trues = [
            'yes', 'true', '1'
        ];
        var falses = [
            'no', 'false', '0'
        ];
        // get the translate file for AG-Grid
        localeText = sofvie_agGrid_languages[`${selectedLanguage}`]
        
        var gridOptions = {
          showToolPanel: false,
          toolPanelSuppressRowGroups: true,
          toolPanelSuppressValues: true,
          toolPanelSuppressPivots: true,
          toolPanelSuppressPivotMode: true,
          toolPanelSuppressSideButtons: true,
          enableFilter: true,
          enableSorting: true,
          pagination: true,
          gridAutoHeight: true,
          paginationPageSize: 15,
          rowHeight: 40, //material theme requirement
          rowSelection: 'multiple',
          headerHeight: 35,
          suppressMovableColumns: true,
          suppressHorizontalScroll: false,
          suppressRowClickSelection: true,
          animateRows: true,
          suppressContextMenu: true,
          localeText: localeText,
          getRowHeight: function (params) {
            return 28 * (Math.floor(params.data.latinText.length / 60) + 1);
          },
          icons: {
          sortAscending: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"7\" height=\"6\" viewBox=\"0 0 7 6\"><path fill=\"#979797\" fill-rule=\"evenodd\" d=\"M3.5 0L7 6H0z\"/></svg>",
          sortDescending: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"7\" height=\"6\" viewBox=\"0 0 7 6\"><path fill=\"#979797\" fill-rule=\"evenodd\" d=\"M3.5 0L7 6H0z\"/></svg>",
          menu: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"13\" height=\"11\" viewBox=\"0 0 13 11\"><g fill=\"none\" fill-rule=\"evenodd\" stroke-linecap=\"round\"><path d=\"M.5.5h12M.5 5.5h12M.5 10.5h12\"/></g></svg>",
          filter: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"18\" height=\"16\" viewBox=\"0 0 18 16\"><path fill=\"#979797\" fill-rule=\"evenodd\" d=\"M18 0H0l8 8v7.5l2-2V8z\"/></svg>",
          checkboxUnchecked: "<img src=\"images/checkbox.svg\" />",
          checkboxChecked: "<img src=\"images/checkbox-selected.svg\" />",
          checkboxIndeterminate: "<img src=\"images/checkbox-partial.svg\" />"
          },
          angularCompileRows: true,
          components: {
              tippyCellRenderer: TippyCellRenderer
          }
        };

      function getContextMenuItems(params) { return [{ name: 'copy' }, { name: 'copyWithHeaders' }, { name: 'separator' }, { name: 'export' }]; }

      function valToYesNo(value) {
            if (trues.indexOf((value + "").toLowerCase()) >= 0) {
                return 'YES';
            } else {
                if (falses.indexOf((value + "").toLowerCase()) >= 0) {
                    return 'NO';
                } else {
                    return 'N/A';
                }
            }
        }
        return {
            getCommonOptions: function () {
                var o = JSON.parse(JSON.stringify(gridOptions));
                o.components = gridOptions.components;
                o.columnDefs = [];
                return o;
            },
            photosCellRenderer: function (params) {
                if (params.value.length === 0)
                    return '';

                if (params.value.length === 1)
                    return '<svg xmlns="http://www.w3.org/2000/svg" width="9" height="18" viewBox="0 0 9 18"><path fill="none" stroke="#0080D2" d="M851.045455,27.25 L851.045455,22.1363636 C851.045455,21.0072727 851.620227,20.0909091 852.75,20.0909091 C853.879773,20.0909091 854.454545,21.0072727 854.454545,22.1363636 L854.454545,28.6136364 C854.454545,30.3086364 853.421591,31.6818182 851.727273,31.6818182 C850.032955,31.6818182 849,30.3086364 849,28.6136364 L849,20.0909091 C849,17.8313636 850.490455,16 852.75,16 C855.009545,16 856.5,17.8313636 856.5,20.0909091 L856.5,26.2272727" transform="translate(-848 -15)" stroke-linecap="round" stroke-linejoin="round"/></svg>';

                return '<svg xmlns="http://www.w3.org/2000/svg" width="9" height="18" viewBox="0 0 9 18"><path fill="none" stroke="#0080D2" d="M851.045455,27.25 L851.045455,22.1363636 C851.045455,21.0072727 851.620227,20.0909091 852.75,20.0909091 C853.879773,20.0909091 854.454545,21.0072727 854.454545,22.1363636 L854.454545,28.6136364 C854.454545,30.3086364 853.421591,31.6818182 851.727273,31.6818182 C850.032955,31.6818182 849,30.3086364 849,28.6136364 L849,20.0909091 C849,17.8313636 850.490455,16 852.75,16 C855.009545,16 856.5,17.8313636 856.5,20.0909091 L856.5,26.2272727" transform="translate(-848 -15)" stroke-linecap="round" stroke-linejoin="round"/></svg> ' + params.value.length;
            },
            dateCellRenderer: function (params) {
                if (!params.value)
                    return "";

                var parts = params.value.split('T')[0].split('-');

                if(parts[1] == null)
                    return params.value
                else
                    return parts[0] + '-' + parts[1] + '-' + parts[2];
            },
            getRowHeight: function (params) {
                //calculate row height based on the longest thing stored in the row
                var charactersPerRow = 20;
                var heightInPixelsPerRow = 26;
                var heightPadding = 10;
                var storedLength = 0;
                for (var property in params.data) {
                    if (params.data.hasOwnProperty(property)) {
                        if (typeof params.data[property] !== 'string' && typeof params.data[property] !== 'number')
                            continue;

                        var propString = params.data[property] + "";
                        if (propString.length > storedLength) {
                            storedLength = propString.length;
                        }
                    }
                }

                return heightInPixelsPerRow * (Math.floor(storedLength / charactersPerRow) + 1) + heightPadding;
            },
          dateFilterParams: {
            //wrap object date representation in date object to make filtering work
            comparator: function (filterLocalDateAtMidnight, cellValue) {
                var datePart = cellValue.split('T')[0];
                var cellDateUTC = new Date(cellValue);
                if (cellDateUTC < filterLocalDateAtMidnight) {
                    return -1;
                } else if (cellDateUTC > filterLocalDateAtMidnight) {
                    return 1;
                } else {
                    return 0;
                }
            },
                inRangeInclusive: true
          },

            yesNoValueGetter: function (params) {
                var val = params.data[params.colDef.field];
                return valToYesNo(val);
            },
            valToYesNo: valToYesNo
        
            
        };
    }]);