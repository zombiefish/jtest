﻿// function to act as a class
function TippyCellRenderer() { }

let exceptionFields = [] //['Duration', 'MySignoffID', 'prefix', 'endfix', 'exceptionFields', 'originalData', 'attachment_files', 'byWho', 'signoffCount', 'instruction_hints','show_instruction_hint','alternateFields']
let alternateFields = {}
// gets called once before the renderer is used
TippyCellRenderer.prototype.init = function (params) {

  //Add custom exception fields
    exceptionFields =  ['Duration', 'MySignoffID', 'prefix', 'endfix', 'exceptionFields', 'rmm_pra_workplace','originalData', 'attachment_files', 'byWho', 'signoffCount', 'instruction_hints','show_instruction_hint','alternateFields','lat_llm','lat_llm_show_check_box']
    exceptionFields = exceptionFields.concat(params.data.exceptionFields)
    
    //alternateFields - Used to substitute field names for custom fields.
    alternateFields = params.data.alternateFields
    
    // create the cell
    this.eGui = document.createElement('span');
    this.eGui.innerHTML = '<span class="clip" ng-non-bindable></span>';

    // get references to the elements we want
    this.eValue = this.eGui.querySelector('.clip');

    // set value into cell
    this.eValue.innerHTML = params.valueFormatted ? params.valueFormatted : params.value;
  if (params.value) { // no tooltip on null
        this.eGui.title = makeRecord(params.data)
        this.setTippy();
    }
};

TippyCellRenderer.prototype.destroyTippy = function () {
    if (!!this._tippy) {
        this._tippy.destroy();
    }
};

TippyCellRenderer.prototype.setTippy = function () {
  this.destroyTippy();
  this._tippy = tippy.one(this.eGui);
  this._tippy.options.delay = [1000,100]
};

// gets called once when grid ready to insert the element
TippyCellRenderer.prototype.getGui = function () {
    return this.eGui;
};

// gets called whenever the user gets the cell to refresh
TippyCellRenderer.prototype.refresh = function (params) {
    // set value into cell again
    this.eValue.innerHTML = params.valueFormatted ? params.valueFormatted : params.value;
    this.eGui.title = makeRecord(params.data)
    this.setTippy();
    // return true to tell the grid we refreshed successfully
    return true;
};

// gets called when the cell is removed from the grid
TippyCellRenderer.prototype.destroy = function () {
    this.destroyTippy();
};

function makeRecord(data) {

  let output = Object.entries(data).map(([key, value]) => ({ key, value }));
  let newOutput = []
  let recordData = '<table>'
  output.forEach((record) => {
  //  formObj.formName | titlecase    
    if (exceptionFields.indexOf(record.key) === -1) {
      if(record.value != null && record.value.toString().substring(0,3) == ' - ')
        record.value = record.value.slice(3)
       if (typeof(record.value) == 'string'){
          record.value = record.value.replace("</br>", "").trim()        
        }
      // Put the "False" in quotes to render (no) in the tippy
      if (record.value === '0' || record.value === "False" || record.value === false)
        val = translateTag(1380)
        // Put the "True" in quotes to render (yes) in the tippy
      else if (record.value === '1' || record.value === "True" || record.value === true)
        val = translateTag(1379)
      else if (record.value === '-1')
        val = translateTag(1381)
      else if (record.value === null || record.value === 'null' || record.value === undefined)
        val = ""
      
      else
        val = record.value.toString()
      if(alternateFields!=null)  {
        for(af of alternateFields){
          if(af.key == record.key){
            record.key = af.value  
          }
        }
      }
      newOutput.push({key: translateAgGridField(record.key), value: fixVal(val)})    
    }
  })

  //This sorts the tippy alphabetically if wanted
  //newOutput.sort((a, b) => a.key.localeCompare(b.key))

  newOutput.forEach((record) => {
    recordData += `<tr><td>${record.key}</td><td>${record.value}</td></tr>`
  })

  recordData += "</table>"
  return(recordData);
}

function fixTitle(input, prefix=null, endfix=null) {
  let splitData = ''  

  if(input != null && prefix != null)
  {
    if(input.toString().substring(0,prefix.length) == prefix)
      input = input.slice(prefix.length, input.length)
    else if(Array.isArray(prefix)){
      prefix.forEach((fix) => {
        if(input.toString().substring(0, fix.length) == fix)
          input = input.slice(fix.length, input.length)
      })
    }
  }

  if(input != null && endfix != null)
  {
    if(input.toString().substring(input.length - endfix.length, input.length) == endfix)
      input = input.slice(0, input.length - endfix.length)
    else if(Array.isArray(endfix)){
      endfix.forEach((fix) => {
        if(input.toString().substring(input.length - fix.length, input.length) == fix)
          input = input.slice(0, input.length - fix.length)
      }) 
    }   
  }    

  //Remove "_" and set first letter of each word capital
  if (input.includes("_")) {    
    temp = input.split("_")
    temp.forEach((tempdata) => {
      splitData += tempdata.charAt(0).toUpperCase() + tempdata.slice(1) + " "
    })
    return splitData
  }
  let output = ''
  //Set first letter of single word capital
  output = input.charAt(0).toUpperCase() + input.slice(1)
  //Add space between words
  output = output.replace(/([A-Z]+)/g, " $1").replace(/([A-Z][a-z])/g, " $1")

  output = output.trim()

  if(output.toString().substring(output.length - 2, output.length) == 'Id')
    output = output.toString().substring(0, output.length - 2) + 'ID'
  
  return output
};

function fixVal(input) {
  if(input === translateTag(1381) || input.length == 0)
    return input

  let output = ''
  //Set first letter of single word capital
  output = input.charAt(0).toUpperCase() + input.slice(1)
  //Add space between words
  output = output.replace(/([A-Z]+)/g, " $1").replace(/([A-Z][a-z])/g, " $1")
  
  output = output.trim()

  //Sanatize {{ }} from tippy
  output = cleanDoubleCurly(output)

  return output
};


