
//Creates the custom-on-change directive used to detect file uploads
safeToDo.directive('customOnChange', () => {
    return {
      restrict: 'A',
      link: (scope, element, attrs) => {
        var onChangeHandler = scope.$eval(attrs.customOnChange)
        element.on('change', onChangeHandler)
        element.on('$destroy', () => {
          element.off()
        })
      }
    }
})

angular
    .module('safeToDo')
    .service('fileUploadService', function() {
        // Image file types
        let allowedFileTypesImages = ['image/png', 'image/jpeg', 'image/bmp', 'image/gif', 'image/webp']
        // Other non image file types
        let allowedFileTypesOther = ['application/pdf', 'text/plain', 'text/csv', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/rtf',
        'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'text/calendar', 'message/rfc822', 'application/vnd.openxmlformats-officedocument.presentationml.slideshow', 'application/vnd.oasis.opendocument.text', 'application/vnd.oasis.opendocument.spreadsheet', 'application/vnd.oasis.opendocument.presentation']

        let allowedFileTypes = []

        return {
            checkFileUpload: function (files, existingFileNames=[], onlyImages=false, additionalFileTypes=[]) {
                if(!onlyImages)
                    allowedFileTypes = allowedFileTypesImages.concat(allowedFileTypesOther)
                else
                    allowedFileTypes = allowedFileTypesImages
                
                allowedFileTypes = allowedFileTypes.concat(additionalFileTypes)
                return checkFileTypes(files, existingFileNames)
            },
            getFileUploadData: function (files) {                
                let promises = [] 
                for (file of files) { // Collect all promises
                    if(file.type != 'link'){
                        promises.push(readFile(file));                        
                    }
                }
                return Promise.all(promises).then(results => { // Wait for the resolutions
                    let filesData = []
                    
                    for (result of results) {
                        if (!filesData.find(attach => attach.file === result.file)) { //Check if file already exists
                            filesData.push(result)
                        }
                    }

                    //Clears selected files from input
                    angular.forEach(
                        angular.element("input[type='file']"),
                        function(inputElem) {
                            angular.element(inputElem).val(null)
                        }
                    )

                    return filesData
                })                
            },
            getAllowedFileTypes: function (onlyImages=false) {
                if(!onlyImages)
                    return allowedFileTypesImages.concat(allowedFileTypesOther)
                return allowedFileTypesImages
            }
        }

        function checkFileTypes(files, existingFileNames) {
            let cleanFiles = []
            for (let h = 0; h < files.length; h++) {
                if(allowedFileTypes.includes(files[h].type)) {
                    cleanFiles.push(files[h])
                } else {
                    toastr.error(translateTag(3456)) // Invalid file type
                }
            }
            let dupFiles = checkForDuplicates(cleanFiles, existingFileNames)
           return dupFiles
        }

        function checkForDuplicates(files, existingFileNames) {
            let finalFiles = []
            files.forEach((data)=>{
                let found = false
                existingFileNames.forEach((fileName) => {
                    if(fileName === data.name) {
                        found = true
                    }
                })
                if(!found){
                    finalFiles.push(data)
                } else {
                    toastr.error(`${data.name} ${translateTag(3587)}`)  //is already loaded
                }
            })
            return finalFiles
        }

        function readFile(file) {
            return new Promise((resolve, reject) => {
                let reader = new FileReader();
                reader.onload = () => {
                    resolve({'url':reader.result,'timestamp':moment.unix(file.lastModified/1000).format('YYYY-MM-DD HH:mm:ss'),'file':file.name})
                }
                reader.readAsDataURL(file)
            })
        }
    })