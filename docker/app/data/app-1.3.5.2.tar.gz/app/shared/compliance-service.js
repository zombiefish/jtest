﻿angular
    .module('safeToDo')
    .service('complianceService', ['$http',
        function ($http) {
            var complianceByForm;
            var missingTargets;
            return {
                getComplianceByForm: function (filter) {
                    return $http.post('/api/compliance/byForm', filter)
                        .then(function (response) {
                            complianceByForm = response.data.complianceByForm;
                            missingTargets = response.data.missingTargets;
                            return complianceByForm;
                        }, function (errorParams) {
                            console.log('Failed to load compliance by form');
                            console.log(errorParams);
                        });
                },
                readComplianceByForm: function () {
                    return complianceByForm;
                },
                readMissingTargets: function () {
                    return missingTargets;
                }

                
            };
        }
    ]);