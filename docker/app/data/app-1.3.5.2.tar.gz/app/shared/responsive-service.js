﻿angular
    .module('safeToDo')
    .service('responsiveService', ['$rootScope', function ($rootScope) {

        function calcScreenMode() {
            if (window.matchMedia("(min-width: 1500px)").matches) {
                return 'lg';
            } else {
                return 'sm';
            }
        }

        function setScreenMode(screenMode) {
            $rootScope.screenMode = screenMode;
        }

        // Init
        setScreenMode(calcScreenMode());

        $(window).resize(function () {
            setScreenMode(calcScreenMode());
            $rootScope.$apply();
        });

        function select2Tags(){
            $('.select-multiple').on('change', function (e) {
                var selected = $(e.target).val().length
                var total = $(e.target).find("option").length      
                if(selected > 4){
                  $(e.target).parent().find(".select2 .select2-selection ul").append(selected + " " + translateTag(1131) + " " + total)
                  $(e.target).parent().find(".select2-selection__rendered").addClass("mt-1")
                  $(e.target).parent().find('.select2-selection__choice').each(function() {$( this ).addClass( "d-none" )})
                }
              });
        }
    }]);