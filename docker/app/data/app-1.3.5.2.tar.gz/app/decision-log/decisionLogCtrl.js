angular
    .module('safeToDo')
    .controller('decisionLogCtrl', ['$scope', '$timeout', '$q', '$window', '$sce', '$interval', 'gridService',
      'decisionLogService', 'listService', 'modalService', 'profileService', 'employeesService', 'menuService', 'select2Service', 'actionManagementService','$compile', 'documentLockService','$translate','$translatePartialLoader',"$rootScope", 'fileUploadService','exportCSV',
        function ($scope, $timeout, $q, $window, $sce, $interval, gridService, decisionLogService, listService, modalService, profileService, employeesService, menuService, select2Service, actionManagementService, $compile, documentLockService, $translate,$translatePartialLoader,$rootScope,fileUploadService, exportCSV) {            
            let vm = this
            
            let dateToday = moment(new Date(), 'YYYY-MM-DD')
            $translate.use(selectedLanguage)
            vm.employeeList = []
            vm.fullEmployeeList = []
            vm.currentAcknowledgeHistory = []
            vm.userId = null
            vm.siteList = []
            vm.actionTypeList = []
            vm.decisionData = []
            vm.attachmentData = []
            vm.DecDataContext = {}
            vm.uploadFileList= []
            vm.topSearch = ''
            vm.archiveCount = 0
            vm.deleteAttCount = 0
            vm.singleServeReportUrl = 'decision_log'
            vm.actionDisabled = true
            vm.attActionDisabled = true
            vm.canArchiveSubmissions = true
            vm.canManageDecisionLog = true
            vm.decisionViewerOpen = false
            vm.hideingDecisionViewer = false
            vm.openingDecisionViewer = false
            vm.generalEditData = {}
            vm.hazardEditData = {}
            vm.currentAcknowledge = null
            vm.loadMessage = translateTag(3418) //Loading decision logs. Please wait.
            vm.autosave = null
            vm.continueEditing = false
            vm.leaveEditing = false
            vm.idletime = 0
            vm.countdownSeconds = 60
            vm.dec_show_check_box = false

            //Get permissions for the user
            menuService.getPagePermissions().then((data) => {
                vm.permissions = data
                vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
                vm.canManageDecisionLog = vm.permissions.includes('Can Manage Decision Log') ? true : false
                vm.canManageActionItems = vm.permissions.includes('Can Manage Action Items') ? true : false
                vm.canCloseAllActions = vm.permissions.includes('Can Close All Actions') ? true : false
            })

            //Function for the top search bar
            vm.topSearchChanged = () =>{
                vm.decisionOptions.api.setQuickFilter(vm.topSearch)
            }

            $scope.$on('DATERANGE', (range) => {
                vm.mainDateFilter = {
                    start_date: moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD'),
                    end_date: moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')
                }
                refreshData()
              })
            //Function to clear the form feilds
            vm.resetForm = () => {
                resetFormFieldClassList('decisionForm')
                vm.attachmentData = []
                vm.submitted = false

                vm.dlo_id = null
                vm.docLockMessage = ''
                vm.docLockStatus = false
                vm.countdownSeconds = 60
                vm.lockCheckModal = false
                vm.continueEditing = false
                vm.leaveEditing = false
                vm.idletime = 0
                vm.dec_show_check_box = false
                
    
                vm.currentDecision = 
                {
                    dlm_id: null,
                    dlm_title: null,
                    dlm_due_date: dateToday.format("YYYY-MM-DD"),
                    dlm_site: null,
                    dlm_stakeholder: '',
                    dlm_description: '',
                    dlm_context: '',
                    dlm_is_submitted: false,
                    dlm_created_by_per_id: null,
                    dlm_date: dateToday.format("YYYY-MM-DD"),
                    dlm_submitted_date: dateToday.format("YYYY-MM-DD"),
                    dlm_submitted_by_per_id: null,
                    decision_makers: [],
                    acknowledgements: [],
                    actions: [],
                    general_actions: [],
                    hazard_actions: []
                }
            }

            vm.getFilteredEmployees = () =>{
                profileService.filterEmployeeListonSite(vm.currentDecision.dlm_site)
                vm.employeeList =  profileService.readFilterEmployeeListonJob()
            }

            $scope.fileUploadChanged = (event)=> {

                //Add newly selected files after checking for duplicates and correct file types
                vm.uploadFileList = vm.uploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, []))

                if(vm.uploadFileList.length > 0)
                    addAttachments()
            }

            //Function to open the Acknowledge History modal
            vm.viewAcknowledgeHistory = (DecData) => {
                 if(!DecData.reviewedCount > 0 || !DecData.dlm_is_submitted)
                    return
        
                vm.currentAcknowledgeHistory = []
                DecData.acknowledgements.forEach((rev) => {
                    if(rev != null)
                    {
                        let acknowledgment = {
                            name: getEmployeeName(rev.dla_per),
                            pos: rev.dla_position,
                            reviewed_date: rev.dla_modified_date
                        }
                        vm.currentAcknowledgeHistory.push(acknowledgment)
                    }
                })
                $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentAcknowledgeHistory,translateTag(2594))  //"Decision Reviews"
            }           


            //Function to open archive confirmation Modal
            vm.archiveConfirmationModal = () => {
                vm.archiveCount = vm.decisionOptions.api.getSelectedRows().length 
                vm.modalElementsArchive = {
                    title: translateTag(1337), //"Archive Decision?"
                    message: `<div><p>${translateTag(3580)} ${vm.archiveCount} ${translateTag(3584)}</p></div>`, //"You are about to archive {{decisionLogCtrl.archiveCount}} decisions. Undoing this will require IT support. Are you sure?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                }               
                document.getElementById('confirmcallingform').innerHTML = 'DLARCHIVECALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsArchive)
            }
            
            $scope.$on("DLARCHIVECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.archive()
                }
            })

            //Function to archive the selected rows
            vm.archive = () => {
                var rows = vm.decisionOptions.api.getSelectedRows()
                if (rows.length > 0) {
                    var ids = []
                    for (var i = 0; i < rows.length; i++) {
                        if (rows[i].dlo_status) {
                            ids.push({ dlm_id: rows[i].dlm_id})
                        }
                        else{
                            // You cannot Archive while Document is being edited
                            throwToastr('warning',translateTag(9116),2000)
                        }
                    }
                    decisionLogService.archiveDecision(ids).then((r) => {
                        refreshData()
                    })
                }
                modalService.Close('confirmModal')
            }

            //Funtion to export the selected rows to CSV file
            vm.exportCSV = () => {
                let rows = JSON.parse(JSON.stringify(vm.decisionOptions.api.getSelectedRows()))
                exportCSV.export_csv(rows, translateTag(1334))                
            }

            //Funtion to open a report in a new tab
            vm.viewReports = (e, id) =>{
                if(!e.ctrlKey)
                {
                    lang_number = localStorage.getItem('lang_id')
                    vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.singleServeReportUrl}/${id}?lang=${lang_number}`)
                    $window.open(vm.reportURL, "_blank")
                }
            }

            //Funtion to open a attachment file in a new tab
            vm.openAttachment = (name) => {
                vm.attachmentURL =  $sce.trustAsResourceUrl(`${__env.imageUrl}/decision_log/${name}`)
                $window.open(vm.attachmentURL, "_blank")
            }

            //Funtion to add an acknowledgment to a Decision via the Ag-Grid
            vm.signoff = (DecData) => {                
            vm.DecDataContext = DecData
            if(DecData.hasAcknowledged) {
                toastr.success(translateTag(8716))  //"You have already Acknowleged this Decision"
            } 
            else {
                vm.modalElementsReview = {
                    title: translateTag(3414), //"Decision Review?"
                    message: `<div><p>${translateTag(3415)}</p></div>`, //"You are confirming that you have reviewed this decision. This cannot be undone. Continue?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Review">{{vm.componentTranslateLabels(1188)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                }
                document.getElementById('confirmcallingform').innerHTML = 'DLREVIEWCALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsReview)
                }
            }
                        
            $scope.$on("DLREVIEWCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.addAcknowledge()
                }
                })
    
            vm.addAcknowledge = () => {
                let payload = {}
                payload.dla_dlm_id = vm.DecDataContext.dlm_id
                vm.currentAcknowledge = vm.DecDataContext
                decisionLogService.acknowledgeDecision(payload).then((response) => {  
                    refreshData()
                })
                modalService.Close('confirmModal')
            }

            //Function to check if the current user has Acknowledged
            function checkAcknowledged (DecData) {
                let response = false            
                DecData.acknowledgements.forEach((rev) => {
                    if(rev != null && rev.dla_per == vm.userId)
                    {
                        response = true
                    }
                })
                return response
            }

            //Funtion to convert employee ID to Name
            function getEmployeeName(value) {
                let name = value
                vm.fullEmployeeList.forEach((emp)=>{
                    if(emp.per_id == value) {
                        name = emp.per_full_name
                    }
                })
                return name
            }

            function getEmployeeNames(values  ) {
                if(values == null){
                    return ''
                } else {
                    let by_who = []
                    let len = values.length
                    for(let l = 0;l < len; l++) {
                        by_who.push(getEmployeeName(values[l]))
                    }
                    return by_who.join("; ")
                }
             }

            function getEmployeeID(value) {
                let nameID = value
                vm.fullEmployeeList.forEach((emp)=>{
                if(emp.per_full_name == value) {
                    nameID = emp.per_id
                }
            })
            return nameID
            }

            function getSiteName(value) {
                let name = value
                vm.site_name.forEach((s)=>{
                  if(s.rld_id == value) {
                    name = s.rld_name
                  }
                })
                return name
            }

            function getActionTypeName(value) {
                let name = value
                vm.actionTypeList.forEach((at)=>{
                if(at.rld_id == value) {
                name = at.rld_name
                }
            })
            return name
            }

            function getActionTypeID(value) {
                let nameID = value
                vm.actionTypeList.forEach((at)=>{
                if(at.rld_name == value) {
                nameID = at.rld_id
                }
            })
            return nameID
            }

            vm.decisionOptions = gridService.getCommonOptions()
            vm.attachmentOptions = gridService.getCommonOptions()
            //Function to disable action button if no rows are selected
            vm.decisionOptions.onSelectionChanged = () => {
            
                let selectedRows = vm.decisionOptions.api.getSelectedRows()
                vm.actionDisabled = selectedRows.length == 0
                $scope.$apply()
            }
            vm.attachmentOptions.onSelectionChanged = () => {
                let selectedRows = vm.attachmentOptions.api.getSelectedRows()
                vm.attActionDisabled = selectedRows.length == 0
                $scope.$apply()
            }

            //Set Ag-Grid colum values/settings
            let decisionColumns = [
                {
                    headerName: '',
                    field: 'dummyCheckbox',
                    maxWidth: 50,
                    minWidth: 50,
                    checkboxSelection: true,
                    suppressMenu: true,
                    suppressSorting: true,
                    headerCheckboxSelection: true,
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    field: '',
                    hide: true,                
                    valueGetter: function (params) {
                        if (params.data.dlm_is_submitted)
                            return '2_submitted'
                        else
                            return '1_Draft'
                    },
                    sort: 'asc',
                },
                {
                    field: "review",
                    headerName: " ",
                    maxWidth: 125,
                    minWidth: 125,
                    suppressMenu: true,
                    cellRenderer: (params) => {
                        return `<span ng-if="${params.data.dlm_is_submitted}" ng-click="decisionLogCtrl.signoff(data)" note="Review Submission" title="{{menu.translateLabels(3431)}}" class="{{ data.hasAcknowledged ? 'text-success ' : 'pointer'}}" /><i class="far fa-file-alt fa-lg"></i></span>`
                            + `<span class="fa-1x fa-stack" style="width: 1.25em;" ng-class="{ transparent: ${!vm.canManageDecisionLog}, pointer: ${vm.canManageDecisionLog}}" ng-hide="${params.data.dlm_is_submitted}" ng-click="decisionLogCtrl.openViewer('edit', ${params.data.dlm_id})"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title="{{menu.translateLabels(1194)}}"></i> <i ng-show="${!params.data.dlo_status}" class="fas fa-ban fa-stack-1x text-danger" note="is updating the document, please wait." title="${params.data.dlo_person} {{menu.translateLabels(3423)}}"></i></span>`
                            + `<span note="Submission Review History" title="{{menu.translateLabels(3430)}}" class="source signoff-count" ng-class="{ transparent: (!data.reviewedCount > 0 || !data.dlm_is_submitted), pointer: (data.reviewedCount > 0 && data.dlm_is_submitted) }" ng-click="decisionLogCtrl.viewAcknowledgeHistory(data);">{{ data.reviewedCount }}</span>`
                            + `<span class="pointer text-left" ng-click="decisionLogCtrl.viewReports($event, ${params.data.dlm_id})"><i class="fa fa-external-link-alt" note="Launch Report" title="{{menu.translateLabels(3429)}}"></i></span>`
                    },  
                    valueGetter: function (params) {
                        return params.data.reviewedCount
                    },
                },
                {
                    field: '',
                    headerName: "Status",
                    minWidth: 200,
                    maxWidth: 200,
                    hide: true,
                    valueGetter: function (params) {
                        let status = params.data.dlm_is_submitted
                        let dueDate = new Date(params.data.dlm_due_date)
                        let currentDate = new Date()
                        if (dueDate < currentDate && !status)
                            return '1_Overdue'
                        else if (!status)
                            return '2_Due'
                        else
                            return '3_Complete'
                    },
                   // sort: 'asc',
                  },
                {
                    field: "dlm_submitted_date",
                    headerName: " ",
                    minWidth: 180,
                    maxWidth: 180,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                    sort: 'desc',
                },
                {
                    field: "dlm_submitted_by_per",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                    
                },
                {
                    field: "dlm_due_date",
                    headerName: " ",
                    minWidth: 120,
                    maxWidth: 120,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                      let expiryDate = new Date(params.data.dlm_due_date)
                      let currentDate = new Date()
                      let status = params.data.dlm_is_submitted
                      if (expiryDate < currentDate && status == false)
                          return '<div style="color: #D20000;">' + params.data.dlm_due_date + '</div>'
                      else
                          return '<div>' + params.data.dlm_due_date + '</div>'
                    },
                   
                },
                {
                    field: "dlm_title",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "dlm_created_date",
                    headerName: " ",
                    minWidth: 120,
                    maxWidth: 120,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer'
                },
                {
                    field: "dlm_site",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',                
                },               
                {
                    field: "decision_makers",
                    headerName: " ",
                    minWidth: 200,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer'
                },
                {
                  field: "status",
                  headerName: " ",
                  maxWidth: 100,
                  minWidth: 100,
                  filter: 'agSetColumnFilter',
                  menuTabs: ['filterMenuTab'],
                  cellRenderer: (params) => {
                    let dueDate = new Date(params.data.dlm_due_date)
                    let currentDate = new Date()
                    let draft = translateTag(1399) //Draft
                    if (dueDate < currentDate)
                        draft = `<span style="color: #D20000;">${translateTag(1399)}</span>`    

                    return `<span>${params.data.dlm_is_submitted == false ? draft : translateTag(3557)}</span>`; //Active
                  },
                  filterValueGetter:(params)=>{                       
                    let draft = translateTag(1399)                   
                    return params.data.dlm_is_submitted == false ? draft : translateTag(3557) //Active
                        },
                    valueGetter:(params)=>{
                        return params.data.dlm_is_submitted == false ? translateTag(1399) : translateTag(3557) //Draft / Active
                    },
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],                        
                    width: 200,
                },
                {field: "dlm_created_by_per",hide:true},
                {field: "dlm_description",hide:true},
                {field: "dlm_enable",hide:true},
                {field: "dlm_id",hide:true},
                {field: "dlm_is_submitted",hide:true},
                {field: "dlm_modified_by_per",hide:true},
                {field: "dlm_modified_date",hide:true},
                {field: "dlm_site_rld",hide:true},
                {field: "dlm_stakeholder",hide:true},
                {field: "dlm_title",hide:true},
                {field: "exceptionFields",hide:true},
                {field: "hasAcknowledged", hide:true},
                {field: "reviewedCount",hide:true},
                {field: "reviewersList",hide:true},
            ]
            vm.decisionOptions.columnDefs = decisionColumns
            vm.decisionOptions.defaultColDef = {
                cellStyle : (params) =>{
                    if(params.data.dlm_is_submitted){
                        return { "cursor": "pointer !important"}
                    }
                } 
            }

            vm.decisionOptions.onCellClicked  = (params) => {
                if(params.column.colDef.field!=='review' && params.data.dlm_is_submitted){
                    vm.openViewer('view', params.data.dlm_id)
                }
            }
	        
            let attachmentColumns = [
                {
                    headerName: '',
                    field: 'dummyCheckbox',
                    maxWidth: 50,
                    minWidth: 50,
                    checkboxSelection: (params) =>{
                        return params.data.dat_dec_show_check_box
                    }, 
                    suppressMenu: true,
                    suppressSorting: true,
                    headerCheckboxSelection: true,
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    //Added the id to the Ag-Grid and hid it. Used to sort the grid to show newest submissions first
                    field: 'dat_id',
                    hide: true,
                    sort: 'desc',
                },
                {
                    field: "dat_created_by_per",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',                    
                },
                {
                    field: "dat_created_date",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "dat_file_name",
                    headerName: " ",
                    minWidth: 150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        return `<span class="pointer clip" ng-click='decisionLogCtrl.openAttachment(${cleanDoubleCurly(JSON.stringify(params.value))})'><a class="source" href="#" ng-non-bindable>${params.value}</a></span>`
                    }              
                }, 
                {
                    field:"comment",
                    headerName:"Comment",
                    minWidth:150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        if(params.data.com_id == null || params.data.com_comment=='' || params.data.com_comment==null){
                            return `<i class="far fa-comment pointer" note="Add Comment" title="{{menu.translateLabels(8921)}}" ng-click='decisionLogCtrl.AddComments(${cleanDoubleCurly(JSON.stringify(params.data))})'></i>`
                        } else {
                            return `<i class="fa fa-comment pointer" note="Edit Comment" title="{{menu.translateLabels(9043)}}" ng-click='decisionLogCtrl.AddComments(${cleanDoubleCurly(JSON.stringify(params.data))})'></i>`
                        }
                    } 
                }            
            ]
            vm.attachmentOptions.columnDefs = attachmentColumns

            vm.AddComments=(data) =>{
                document.getElementById('mode').innerHTML = data.com_id
                document.getElementById('comment').value =  data.com_comment ? data.com_comment.replaceAll("'","&#39") : null
                document.getElementById('callingform').innerHTML = 'CLOSEDLIMAGECOMMENTSMODAL'
                document.getElementById('savetomemory').innerHTML = "false"
                document.getElementById('parentform').innerHTML = 3
                document.getElementById('imageid').innerText = data.dat_id
                document.getElementById('comment_id').innerHTML = data.com_id
                $rootScope.$broadcast("RECIEVEROFCOMMENTS",data.com_comment )
            }

            $scope.$on('CLOSEDLIMAGECOMMENTSMODAL', (event) => {
                refreshAttachments(vm.currentDecision.dlm_id)
            })

            //Function to open the view to create/edit
            vm.openViewer = (mode='new', id) => {
                // Activate the autosave
                if(mode !== 'view') {
                    vm.autosave = $interval(() => {
                        vm.saveDecision('autosave')
                        vm.mode = vm.currentMode
                    }, 20000)
                }

                if(!vm.canManageDecisionLog)
                    return

                if(mode === 'new')
                {
                    vm.hideingDecisionViewer = false
                    vm.decisionViewerOpen = true
                    vm.openingDecisionViewer = true
                    vm.currentMode = 'new'
                    vm.initializeSelect2("decision-viewer")
                    refreshAttachments()
                }
                else if (mode === 'edit')
                {
                    vm.documentDetails = {}
                    vm.documentDetails.dlo_document_id = id
                    vm.documentDetails.dlo_dlt_id = 5 //DLM
                    $q.all([
                        documentLockService.docLock(vm.documentDetails)
                    ]).then((response) => {
                        vm.dlo_id = response[0].dlo_id
                        vm.docLockStatus = response[0].status
                        vm.docLockMessage = response[0].message
                        vm.docLockTime = response[0].time
                        if (!vm.docLockStatus){
                            throwToastr('warning',vm.docLockMessage,2000)
                        }   
                    }).then(() => {
                        if(vm.docLockStatus === true){
                            vm.currentMode = 'edit'
                            $scope.$emit('STARTSPINNER', translateTag(3427)) //Opening decision. Please wait.
                            vm.hideingDecisionViewer = false
                            vm.decisionViewerOpen = true
                            vm.openingDecisionViewer = true
        
                            vm.decisionData.forEach((decData)=>{
                                if(id == decData.dlm_id) {
                                    vm.currentDecision = JSON.parse(JSON.stringify(decData))
                                    vm.currentDecision.dlm_site = vm.currentDecision.dlm_site_rld                                    
                                    if(vm.currentDecision.dlm_site){
                                        vm.getFilteredEmployees(vm.currentDecision.dlm_site)
                                    }
                                    vm.currentDecision.decision_makers = []
                                    vm.currentDecision.participants.forEach ((rec) => {
                                        vm.currentDecision.decision_makers.push(rec.dlp_per)
                                    })
                                    vm.currentDecision.dlm_date = vm.currentDecision.dlm_date ? moment(vm.currentDecision.dlm_date, 'YYYY-MM-DD').format('YYYY-MM-DD') : ''
                                    vm.currentDecision.dlm_due_date = vm.currentDecision.dlm_due_date ? moment(vm.currentDecision.dlm_due_date, 'YYYY-MM-DD').format('YYYY-MM-DD') : ''
                                    
                                    vm.currentDecision.dlm_stakeholder = vm.currentDecision.dlm_stakeholder
                                    if(vm.currentDecision.dlm_is_submitted===0){
                                        vm.dec_show_check_box = true
                                    }
                                    refreshActions(decData.dlm_id)
                                    refreshAttachments(decData.dlm_id)
                                 
                                }
                            })
                            vm.initializeSelect2('newDecisionLog')

                            $timeout(() => {
                                $scope.$emit('STOPSPINNER')
                                vm.openingDecisionViewer = false                
                            }, 400)

                            //Zero the idle timer on mouse movement.
                            $('#newDecisionLog').mousemove(function (e) {
                                clearInterval(vm.lockModal)
                                vm.idletime = 0
                                startLockModal()
                            });

                            //Zero the idle timer on keypres event
                            $('#newDecisionLog').keypress(function (e) {
                                clearInterval(vm.lockModal)
                                vm.idletime = 0
                                startLockModal()
                            });

                            startUpdateDocLock() // Interval function to update to timestamp every 2 minutes
                            startLockModal() // Interval function after inactive page

                        }
                    })
                                        
                }
                else if(mode === 'view'){
                    $scope.$emit('STARTSPINNER', translateTag(3427)) //Opening decision. Please wait.
                    vm.hideingDecisionViewer = false
                    vm.decisionViewerOpen = true
                    vm.openingDecisionViewer = true

                    vm.decisionData.forEach((decData)=>{
                        if(id == decData.dlm_id) {
                            vm.currentDecision = JSON.parse(JSON.stringify(decData))
                            vm.currentDecision.decision_makers = []
                            vm.currentDecision.participants.forEach ((rec) => {
                                vm.currentDecision.decision_makers.push(rec.dlp_per)
                            })
                            vm.currentDecision.dlm_date = vm.currentDecision.dlm_date ? moment(vm.currentDecision.dlm_date, 'YYYY-MM-DD').format('YYYY-MM-DD') : ''
                            vm.currentDecision.dlm_due_date = vm.currentDecision.dlm_due_date ? moment(vm.currentDecision.dlm_due_date, 'YYYY-MM-DD').format('YYYY-MM-DD') : ''
                            vm.currentDecision.dlm_site = vm.currentDecision.dlm_site_rld
                            vm.currentDecision.dlm_stakeholder = vm.currentDecision.dlm_stakeholder

                            refreshActions(decData.dlm_id)
                            refreshAttachments(decData.dlm_id)
                            
                        }
                    })
                    vm.initializeSelect2('newDecisionLog')
                    $timeout(() => {
                        $scope.$emit('STOPSPINNER')
                        vm.openingDecisionViewer = false                
                    }, 400)
                }
            }

            // functions for document lock start__
            vm.continueEditingDL = () => {
                modalService.Close('confirmModal')
                vm.countdownSeconds = 60
                vm.content = "01:00"
                document.getElementById('inactiveTime').textContent = ''
                vm.lockCheckModal = false
                vm.continueEditing = true
                clearInterval(vm.lockModal)
                clearTimeout(vm.relieveLock)
                clearInterval(vm.countdownTimer)
                vm.idletime = 0
                startLockModal()
            }
           
            function startUpdateDocLock(){
                vm.updateDocLockInterval = setInterval(() => {
                    $q.all([
                        documentLockService.intervalDocLock(vm.dlo_id)
                    ]).then((response) => {
                    })
                }, 30 * 1000)
            }

            function startLockModal(){
                vm.lockModal = setInterval(() => {
                    vm.idletime = vm.idletime + 1 // 1 minute
                    if(vm.idletime === 5){ // after 5 minutes of idle time open lockcheck modal
                        vm.continueEditing = false
                        vm.leaveEditing = false                        
                        vm.modalElementsLock = {
                            title: translateTag(3419),   //"Page inactive for 5 minutes" 
                            message: `<div style="text-align: center;"><h1 id ="inactiveTime" ></h1><p> ${translateTag(3420)}</p></div>`,  //"The entry will automatically save and close if no action is taken"
                            buttons: 
                                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Continue Working">{{vm.componentTranslateLabels(3421)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Save and Close">{{vm.componentTranslateLabels(3422)}}</button>`
                        }
                        document.getElementById('confirmcallingform').innerHTML = 'DLLOCKCALLCONFIRMMODAL' 
                        $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsLock)
                        vm.lockCheckModal = true
                        startcountdownTimer()
                        vm.relieveLock = setTimeout(() => {
                            if (vm.lockCheckModal === true){
                                if (!vm.continueEditing && !vm.leaveEditing){
                                    vm.leaveEditing = true
                                    vm.saveDecision()
                                    vm.closeViewer()
                                }
                            }
                        }, 60 * 1000);
                    }                                        
                }, 60 * 1000);
            }

            $scope.$on("DLLOCKCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.continueEditingDL()
                }
                else if (result=='button2') {
                    vm.closeLockModal()
                }
            })

            vm.closeLockModal = () => {
                vm.saveDecision()
                vm.closeViewer()
            }

            function startcountdownTimer(){
                vm.countdownTimer = setInterval(() => {
                    if(vm.lockCheckModal === true && vm.countdownSeconds>=0){
                        vm.content = ''
                        if (vm.countdownSeconds === 60){
                            vm.content = "01:00"
                        }
                        else{
                            vm.content = "00:" + vm.countdownSeconds.toLocaleString('en-US', {
                                minimumIntegerDigits: 2,
                                useGrouping: false
                              }) 
                        }
                        document.getElementById('inactiveTime').textContent =  vm.content
                        vm.countdownSeconds = vm.countdownSeconds - 1   
                    }                                         
                }, 1000)
            }

            // functions for document lock end___ 

            //Function to refesh/get action data
            function refreshActions (id) {
                payload = {
                    dlm_id: id
                }
                vm.currentDecision.actions = []
                decisionLogService.getHazardActions(payload).then((response) => {
                    vm.currentDecision.hazard_actions = response.Hazard_Action
                    if(vm.currentDecision.hazard_actions != null) {
                        vm.currentDecision.hazard_actions.forEach((haz) => {
                            haz['can_close_action'] = vm.canCloseAllActions
                            if(!vm.canCloseAllActions){
                                if(haz.sha_created_by_per_id != vm.userId && !haz.action_by_who.includes(vm.userId)){
                                    haz['can_close_action'] = false
                                }else{
                                    haz['can_close_action'] = true
                                }
                            }
                            haz.lla_action_type = 'Hazard'
                            haz.action_by_who =  getEmployeeNames(haz.action_by_who)
                            vm.currentDecision.actions.push(haz)
                        })
                    }
                })
                decisionLogService.getGeneralActions(payload).then((response) => {
                    vm.currentDecision.general_actions = response.general_actions
                    if(vm.currentDecision.general_actions != null)
                    {
                        vm.currentDecision.general_actions.forEach((gen) => {
                            gen['can_close_action'] = vm.canCloseAllActions
                            if(!vm.canCloseAllActions){

                                if(gen.sga_created_by_per_id == vm.userId || gen.sga_action_by_who_per_id.includes(vm.userId)){
                                    gen['can_close_action'] = true
                                }else{
                                    gen['can_close_action'] = false
                                }
                            }                           
                            gen.lla_action_type = 'General'
                            gen.recommended_action = gen.sga_recommended_action
                            gen.action_by_who = getEmployeeNames(gen.sga_action_by_who_per_id)
                            gen.action_by_when = gen.sga_action_by_when
                            vm.currentDecision.actions.push(gen)
                        })
                    }
                })
            }

            //Function to refresh/get attachment data
            function refreshAttachments (id) {
                if(id)
                {
                    payload = {
                        dlm_id: id
                    }
                    decisionLogService.getDecisionAttachments(payload).then((response) => {
                        vm.attachmentData = response
                        if (vm.attachmentOptions.api) {
                            translateAgGridHeader (vm.attachmentOptions)
                            vm.attachmentOptions.paginationPageSize = 15
                            vm.attachmentOptions.api.setRowData(prepareAttachmentsGridData(vm.attachmentData))
                            vm.attachmentOptions.api.redrawRows()
                            vm.attachmentOptions.api.sizeColumnsToFit()
                        }
                    })
                }
                else if (vm.attachmentOptions.api) {
                    translateAgGridHeader (vm.attachmentOptions)
                    vm.attachmentOptions.paginationPageSize = 15
                    vm.attachmentOptions.api.setRowData([])
                    vm.attachmentOptions.api.redrawRows()
                    vm.attachmentOptions.api.sizeColumnsToFit()
                }
            }

            function prepareAttachmentsGridData(data) {
                let gridData = JSON.parse(JSON.stringify(data))
                gridData.forEach((rec) =>{
                    rec.exceptionFields = ['dat_dec_show_check_box', 'dat_enable', 'dat_dlm']
                    rec.prefix = ['dat_']
                    rec.endfix = ['per_id']
                    rec.com_comment = rec.com_comment ? rec.com_comment.replaceAll("'","&#39") : null
                    rec.dat_created_by_per = getEmployeeName(rec.dat_created_by_per)
                    rec.dat_modified_by_per = getEmployeeName(rec.dat_modified_by_per)
                    rec.dat_created_date = moment(rec.dat_created_date).format('YYYY-MM-DD')
                    rec.dat_modified_date = moment(rec.dat_modified_date).format('YYYY-MM-DD')
                    rec.dat_dec_show_check_box = vm.dec_show_check_box
                })
                return gridData
            }

            //Function to add attachments
            function addAttachments (att)
            {
                if(vm.currentMode === "new") {
                    if (validateFormFields('decisionForm', true)) {

                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentDecision)))
                        payload.dlm_is_submitted = false

                        decisionLogService.createDecision(payload).then((response) => {
                            vm.currentDecision.dlm_id = response.dlm_id
                            
                            resetFormFieldClassList('decisionForm')
                            let fd = new FormData()
                            for (let i in vm.uploadFileList) {
                                fd.append("dlm_id", vm.currentDecision.dlm_id)
                                fd.append("filename", vm.uploadFileList[i])
                            }
                            decisionLogService.addDecisionAttachments(fd).then((res) => {
                                refreshAttachments(vm.currentDecision.dlm_id)
                                vm.uploadFileList = []
                            })
                            refreshData()
                            vm.dec_show_check_box = true //
                        })
                    }
                    else{
                        $rootScope.$broadcast("CALLCONFIRMMODAL")
                    }
                }
                else {
                    let fd = new FormData()
                    for (let i in vm.uploadFileList) {
                        fd.append("dlm_id", vm.currentDecision.dlm_id)
                        fd.append("filename", vm.uploadFileList[i])
                    }
                    decisionLogService.addDecisionAttachments(fd).then((res) => {
                        refreshAttachments(vm.currentDecision.dlm_id)
                        vm.uploadFileList = []
                    })
                }                
            }

            //Function to open delete confirmation Modal
            vm.deleteAttachmentConfirmationModal = () => {
                vm.deleteAttCount = vm.attachmentOptions.api.getSelectedRows().length
                vm.modalElementsDel = {
                    title: translateTag(3416), //"Delete Attachment?"
                    message: `<div><p>${translateTag(3581)} ${vm.deleteAttCount} ${translateTag(3417)}</p></div>`, //"You are about to delete {{decisionLogCtrl.deleteAttCount}} attachments. Undoing this will require IT support. Are you sure?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                }
                document.getElementById('confirmcallingform').innerHTML = 'DLDELETECALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsDel)
            }

            $scope.$on("DLDELETECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.deleteAttachment()
                }
            })

            //Function to delete the selected attachment rows
            vm.deleteAttachment = () => {
                var rows = vm.attachmentOptions.api.getSelectedRows()
                if (rows.length > 0) {
                var ids = []
                for (var i = 0; i < rows.length; i++) {
                    ids.push({ dat_id: rows[i].dat_id})
                }
                decisionLogService.removeDecisionAttachment(ids).then((r) => {
                    refreshAttachments(vm.currentDecision.dlm_id)
                })
                }
    
                modalService.Close('confirmModal')
            }

            //Function to close the view
            vm.closeViewer = () => {
                modalService.Close('confirmModal')
                vm.employeeList = []
                vm.releaseDocument(vm.dlo_id).then((response) => {
                })
                clearInterval(vm.countdownTimer)
                clearInterval(vm.updateDocLockInterval)
                clearInterval(vm.lockModal)
                vm.hideingDecisionViewer = true
                // Terminate the autosave
                $interval.cancel(vm.autosave)
                vm.resetForm()
                refreshData()
                $timeout(() => {
                    vm.decisionViewerOpen = false
                }, 400)
            }

            // function to release document lock
            vm.releaseDocument = (id) => {
                payload = {}
                payload.dlo_id = id
                return (
                    $q.all([
                        documentLockService.closeDocLock(payload).then((response) => {
                        })
                    ])
                )
            }

            //Function to open modals
            vm.openModal = (modalId) => {
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()

                $('.modal .scroll').scrollTop(0)

                modalService.Open(modalId)
                vm.initializeSelect2(modalId, '.modal-body')
            }

            //Function to open the create action modals
            vm.openActionModal = (modalId) => {
                vm.actionMode = 'new'
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()

                $('.modal .scroll').scrollTop(0)

                if(vm.currentMode === "new") {
                    
                    if (vm.validateDecision()){
                        $scope.$emit('STARTSPINNER', translateTag(3426)) //Saving decision. Please wait.
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentDecision)))
                        payload.dlm_is_submitted = false

                        decisionLogService.createDecision(payload).then((response) => {
                            vm.currentDecision.dlm_id = response.dlm_id
                            
                            resetFormFieldClassList('decisionForm')
                            modalService.Open(modalId)
                            vm.initializeSelect2(modalId, '.modal-body')
                            refreshData()
                            $scope.$emit('STOPSPINNER')
                        })
                    } else {
                        $rootScope.$broadcast("CALLCONFIRMMODAL")
                    }
                }
                else{
                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId, '.modal-body')
                }
            }

            //Function to open the edit action modals
            vm.openActionEditModal = (modalId, id) => {
                vm.actionMode = 'edit'
                if(modalId === 'generalActionModal') {
                    openGeneralEdit(id, modalId)
                }
                else if(modalId === 'hazardActionModal') {
                    openHazardEdit(id, modalId)
                }
            }

            //Function to prepare data to edit a general action
            function openGeneralEdit(id, modalId) {
                actionManagementService.getGeneralActionSingle({sga_id: id}).then ((response) => {
                    vm.generalEditData = response
                    
                    vm.generalEditData.Site = parseInt(vm.generalEditData.Site)
                    vm.generalEditData.JobNumber = parseInt(vm.generalEditData.JobNumber)
                    vm.generalEditData.SiteLevel = parseInt(vm.generalEditData.SiteLevel)
                    vm.generalEditData.Supervisor = parseInt(vm.generalEditData.Supervisor)

                    vm.generalEditData.HeaderDate = moment(vm.generalEditData.HeaderDate).format('YYYY-MM-DD')
                    vm.generalEditData.sga_action_by_who_per_id = vm.generalEditData.sga_action_by_who_per

                    let i = 0
                    let initialAtt = JSON.parse(JSON.stringify(vm.generalEditData.attachments))
                    initialAtt.forEach((att) => {
                        if(att.gaa_type === 'FOLLOWUP')
                            vm.generalEditData.attachments.splice(i, 1)
                        else
                            i++
                    })
                    
                    vm.generalEditData.attachments.forEach((att) => {
                        att.imageDir = `${__env.imageUrl}/`
                    })
                    
                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()            

                    $('.modal .scroll').scrollTop(0)

                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId, '.modal-body')
                })
            }

            //Function to prepare data to edit a hazard action
            function openHazardEdit(id, modalId) {
                actionManagementService.getHazardActionSingle({hap_id: id}).then ((response) => {
                    vm.hazardEditData = response

                    vm.hazardEditData.Site = parseInt(vm.hazardEditData.Site)
                    vm.hazardEditData.JobNumber = parseInt(vm.hazardEditData.JobNumber)
                    vm.hazardEditData.SiteLevel = parseInt(vm.hazardEditData.SiteLevel)
                    vm.hazardEditData.Supervisor = parseInt(vm.hazardEditData.Supervisor)

                    vm.hazardEditData.HeaderDate = moment(vm.hazardEditData.HeaderDate).format('YYYY-MM-DD')

                    let i = 0
                    let initialAtt = JSON.parse(JSON.stringify(vm.hazardEditData.attachments))
                    initialAtt.forEach((att) => {
                        if(att.attachmenttype === 'FOLLOWUP')
                            vm.hazardEditData.attachments.splice(i, 1)
                        else
                            i++
                    })
                    
                    vm.hazardEditData.attachments.forEach((att) => {
                        att.imageDir = `${__env.imageUrl}/`
                    })
                    
                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()            

                    $('.modal .scroll').scrollTop(0)

                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId, '.modal-body') 
                })
            }

            //Function to open the complete action modals
            vm.completeActionModal = (action) => {

                if(action.lla_action_type === 'General') {
                    actionManagementService.getGeneralActionSingle({sga_id: action.sga_id}).then ((response) => {
                        vm.generalFollowup = response
                        vm.generalFollowup.sga_completed_action_date = dateToday.format('YYYY-MM-DD')

                        vm.generalFollowup.sga_action_by_who_per_id = getEmployeeNames(vm.generalFollowup.sga_action_by_who_per)
                        if(vm.generalFollowup.sga_completed_action_by_who_per != null)
                            vm.generalFollowup.sga_completed_action_by_who_per_id = parseInt(getEmployeeID(vm.generalFollowup.sga_completed_action_by_who_per))
                        vm.generalFollowup.attachment_files_initial = []
                        vm.generalFollowup.attachment_files_followup = []

                        vm.generalFollowup.attachments.forEach((attRec) => {
                            if(attRec.gaa_type == 'INITIAL')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                vm.generalFollowup.attachment_files_initial.push(attRec) 
                            }
                            else if(attRec.gaa_type == 'FOLLOWUP')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                vm.generalFollowup.attachment_files_followup.push(attRec) 
                            }
                        })

                        vm.openModal('completeGeneralActionModal')
                        setTimeout(()=>{
                            $scope.$broadcast('GENERAL_FOLLOWUP_OPENED')
                        },100) 
                    })
                }
                else
                {
                    actionManagementService.getHazardActionSingle({hap_id: action.id}).then ((response) => {
                        vm.followup = response
                        vm.followup.action_completed_date = dateToday.format('YYYY-MM-DD')
                        vm.followup.action_complete_by_who = (vm.followup.action_complete_by_who && vm.followup.action_complete_by_who != 'None') ? parseInt(getEmployeeID(vm.followup.action_complete_by_who)) : null
                        vm.followup.attachmentModalFiles = []
                        vm.followup.followupAttachmentModalFiles = []

                        vm.followup.attachments.forEach((attRec) => {
                            if(attRec.attachmenttype === 'INITIAL')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                attRec.AttachmentFileName = attRec.attachmentfilename
                                vm.followup.attachmentModalFiles.push(attRec) 
                            }
                            else if(attRec.attachmenttype === 'FOLLOWUP')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                attRec.AttachmentFileName = attRec.attachmentfilename
                                vm.followup.followupAttachmentModalFiles.push(attRec) 
                            }
                        })
                        
                        vm.followup.HapId = action.id
                        vm.followup.action_by_who_name = getEmployeeName(action.action_by_who)

                        vm.openModal('hapFollowupComponent')
                        setTimeout(()=>{
                            $scope.$broadcast('HAZARD_FOLLOWUP_OPENED')
                        },100)
                    })
                }
            }

            //Function to save the decision
            vm.saveDecision = (mode = 'normal') => {
                resetFormFieldClassList('decisionForm') 
                if (validateFormFields('decisionForm', true)){
                    if (mode === 'normal') {
                        $scope.$emit('STARTSPINNER', translateTag(3426)) //Saving decision. Please wait.
                    }
                    vm.submitted = true
                    if(vm.currentMode === "new") {
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentDecision)))
                        payload.dlm_is_submitted = 0

                        decisionLogService.createDecision(payload).then((response) => {
                            if (mode === 'normal') {
                                vm.closeViewer()
                            }
                            else {
                                vm.currentDecision.dlm_id = response.dlm_id
                                vm.currentMode = "edit"
                                vm.submitted = false
                                clearInterval(vm.lockModal)
                                clearInterval(vm.updateDocLockInterval)
                                startUpdateDocLock()
                                startLockModal()
                                autoSaveRefresh()
                            }

                        })
                    }
                    else{
                        let payload = preparePayload('edit', JSON.parse(JSON.stringify(vm.currentDecision)))
                        payload.dlm_is_submitted = 0
                        
                        decisionLogService.updateDecision(payload).then((response) => {
                            if (mode === 'normal') {
                                vm.closeViewer()
                            }
                            else {
                                autoSaveRefresh()
                                vm.submitted = false
                            }
                        })
                    }
                } else {
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }
            
            //Function to submit the decision
            vm.submitDecision = () => {
                if (vm.validateDecision()){
                    $scope.$emit('STARTSPINNER', translateTag(3428)) //Submitting decision. Please wait.
                    vm.submitted = true
                    if(vm.currentMode === "new") {
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentDecision)))
                        payload.dlm_is_submitted = 1
    
                        decisionLogService.createDecision(payload).then((response) => {
                            refreshData()
                            vm.closeViewer()
                        })
                    }
                    else{
                        let payload = preparePayload('edit', JSON.parse(JSON.stringify(vm.currentDecision)))
                        payload.dlm_is_submitted = 1
                        payload.dlm_submitted_by_per = vm.userId
    
                        decisionLogService.updateDecision(payload).then((response) => {
                            refreshData()
                            vm.closeViewer()
                        })
                    }
                } else {
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            //Function to prepare payload data
            function preparePayload(mode='new', payload) {
                let preparedPayload = {}
                if(mode == 'edit')
                {
                    preparedPayload.dlm_id = payload.dlm_id
                }

                preparedPayload.dlm_title = payload.dlm_title!=='' && payload.dlm_title!==undefined ? payload.dlm_title: null
                preparedPayload.dlm_site_rld = payload.dlm_site
                preparedPayload.dlm_date = payload.dlm_date ? moment(payload.dlm_date, 'YYYY-MM-DD').format('YYYY-MM-DD') : dateToday.format('YYYY-MM-DD')
                preparedPayload.dlm_due_date = payload.dlm_due_date ? moment(payload.dlm_due_date, 'YYYY-MM-DD').format('YYYY-MM-DD') : null
                preparedPayload.dlm_description = payload.dlm_description
                preparedPayload.dlm_context = payload.dlm_context
                preparedPayload.dlm_stakeholder = payload.dlm_stakeholder
                preparedPayload.decision_log_participants = payload.decision_makers
    
                return preparedPayload
            }

            //Function to add an action to a Decision
            vm.addAction = (actionData) => {
                payload = {}

                if('sga_id' in actionData) {
                    payload.dlg_dlm = vm.currentDecision.dlm_id
                    payload.dlg_sga = actionData.sga_id

                    decisionLogService.addDecisionGeneralAction(payload).then((response) => {
                        refreshActions(vm.currentDecision.dlm_id)
                    })                
                }  else if('ID' in actionData) {
                    payload.dlh_dlm =  vm.currentDecision.dlm_id
                    payload.dlh_sha = actionData.ID

                    decisionLogService.addDecisionHazardAction(payload).then((response) => {
                        refreshActions(vm.currentDecision.dlm_id)
                    })
                }            
            }

            //Function to remove completed actions from the grid
            vm.completeAction = (actionData) => {
                refreshActions(vm.currentDecision.dlm_id)
            }

            //Funtion to initialize select2
            vm.initializeSelect2 = (parent, section='') => {
                setTimeout(()=>{ 
                $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} ${section}`), escapeMarkup: function (text) { return text } })
                .on('select2:select', () => {
                    $(this).parent().find('label').addClass('filled')
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()
                if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
                $('.datepicker').pickadate({
                    format: 'yyyy-mm-dd',
                    onClose : function(){
                        this.$holder.blur()
                    },
                }).removeAttr('readonly')
                .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                    evt.preventDefault()
                })
                preventFutureDatePickerInit()
                }, 100)
            }

            //Listeners
            $scope.$on('CLOSEMODAL', (event) => {
                vm.initializeSelect2('newDecisionLog')
            })
            $scope.$on('ADDACTION', (event, data) => {
                if(data && vm.actionMode != 'edit')
                    vm.addAction(data)
                else{
                    refreshActions(vm.currentDecision.dlm_id)
                }
            })
            $scope.$on('COMPLETEACTION', (event, data) => {
                if(data)
                    vm.completeAction(data)
            })
            // Function to refresh while in autosave mode
            function autoSaveRefresh() {
                decisionLogService.getDecisionsList(vm.mainDateFilter).then((data) =>{
                    vm.decisionData = decisionLogService.readLDecisionsList()
                    if (vm.decisionOptions.api) {
                        translateAgGridHeader (vm.decisionOptions)
                        let model = vm.decisionOptions.api.getFilterModel()
                        vm.decisionOptions.paginationPageSize = 15
                        vm.decisionOptions.api.setRowData(prepareDecisionsGridData(vm.decisionData))
                        vm.decisionOptions.api.redrawRows()
                        vm.decisionOptions.api.sizeColumnsToFit()
                        vm.decisionOptions.api.sizeColumnsToFit()
                        vm.decisionOptions.api.setFilterModel(model)
                    } 
                })
            }

            //Function to refresh data and Ag-Grid
            function refreshData() {
                $scope.$emit('STARTSPINNER', vm.loadMessage)
                $q.all([
                    listService.getSelectListData('ref_site'),
                    employeesService.getPersonProfile(),
                    listService.getSelectListData('ref_general_action'),
                    profileService.getAllEmployeeProfile(),
                    profileService.getFullEmployeeProfile(),
                    decisionLogService.getDecisionsList(vm.mainDateFilter),
                    listService.getFullSiteList(),
                ]).then((data) => {
                    vm.siteList = data[0]
                    vm.userId = data[1].per_id
                    vm.actionTypeList = data[2]
                    vm.fullEmployeeList = profileService.readFullEmployeeProfile()                            
                    vm.decisionData = decisionLogService.readLDecisionsList()
                    vm.site_name = listService.readFullSites()
                }).then(() => {
                    
                    if (vm.decisionOptions.api) {
                        translateAgGridHeader (vm.decisionOptions)
                        let model = vm.decisionOptions.api.getFilterModel()
                        vm.decisionOptions.paginationPageSize = 15
                        vm.decisionOptions.api.setRowData(prepareDecisionsGridData(vm.decisionData))
                        vm.decisionOptions.api.redrawRows()
                        vm.decisionOptions.api.sizeColumnsToFit()
                        vm.decisionOptions.api.sizeColumnsToFit()
                        vm.decisionOptions.api.setFilterModel(model)
                    }                    
                    vm.actionDisabled = true
                    $scope.$emit('STOPSPINNER')
                })
            }
            vm.resetForm()
            vm.decisionViewerOpen = true
            vm.decisionViewerOpen = false
                     

            //Functions to prepare Ag-Grid data with string values
            function prepareDecisionsGridData(data) {
                let decisionGridData = JSON.parse(JSON.stringify(data))

                decisionGridData.forEach((rec) =>{
                    rec.exceptionFields = ['acknowledgements', 'participants' , 'dlm_site_rld', 'dlm_enable', 'dlo_enable', 'dlo_person', 'dlo_status']
                    
                    rec.dlm_site = getSiteName(rec.dlm_site_rld)
                    rec.dlm_created_by_per = getEmployeeName(rec.dlm_created_by_per)
                    rec.dlm_created_date = rec.dlm_created_date ? moment(rec.dlm_created_date).format('YYYY-MM-DD') : ""
                    rec.dlm_due_date = rec.dlm_due_date ? moment(rec.dlm_due_date).format('YYYY-MM-DD') : ""

                    rec.dlm_is_submitted = rec.dlm_is_submitted == 1 ? true : false
                    rec.dlm_submitted_by_per = getEmployeeName(rec.dlm_submitted_by_per)
                    rec.dlm_submitted_date = rec.dlm_is_submitted == true ? moment(rec.dlm_submitted_date).format('YYYY-MM-DD') : ''
                    rec.dlm_modified_by_per = getEmployeeName(rec.dlm_modified_by_per)
                    rec.dlm_modified_date = rec.dlm_modified_date == null?'': moment(rec.dlm_modified_date).format('YYYY-MM-DD')
                    
                    rec.hasAcknowledged = checkAcknowledged(rec)
                    rec.reviewedCount = rec.acknowledgements.length

                    if(rec.dlo_enable.length !== 0){
                        rec.dlo_status = rec.dlo_enable[0].dlo_enable
                        rec.dlo_person = rec.dlo_enable[0].dlo_person
                    }
                    else{
                        rec.dlo_status = true
                        rec.dlo_person = null
                    }
                    
                    rec.decision_makers = ""
                    rec.participants.forEach((par) => {
                        rec.decision_makers += getEmployeeName(par.dlp_per) + ' - '
                    })
                    if(rec.decision_makers.length >= 3)
                        rec.decision_makers = rec.decision_makers.slice(0, rec.decision_makers.length-3)
                    
                    rec.reviewers = ''
                    rec.acknowledgements.forEach((rev) => {
                        rec.reviewers += (` -  ${getEmployeeName(rev.dla_per)}`)
                    })
                })  
          
                return decisionGridData
            } 
        
            // Fuction to check if all modal feilds are valid
            vm.validateDecision = () => {
                return validateFormFields('decisionForm')
            }

            //Update Ag-Grid size when window is resized
            $(window).on('resize', () => {
                $timeout(function () {
                    if (vm.decisionOptions.api) {
                        vm.decisionOptions.api.sizeColumnsToFit()
                    }
                    if (vm.attachmentOptions.api) {
                        vm.attachmentOptions.api.sizeColumnsToFit()
                    }
                })
            })
        //END
        }
    ])