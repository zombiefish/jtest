angular
    .module('safeToDo')
    .service('decisionLogService', ['$http',
        function ($http) {
            let decisionsList = []

            return {
                getDecisionsList: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/dlm/get-decision-log-list/`,payload).then((response) => {                        
                        decisionsList = response.data
                    }, (errorParams) => {
                        console.log('Failed to load Decisions', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            decisionsList = []
                            window.location.href = "/";
                        }
                    })
                },
                getHazardActions: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/dlm/get-decision-log-hazard-actions/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load hazard actions', errorParams)
                    })
                },
                getGeneralActions: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/dlm/get-decision-log-general-actions/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load general actions', errorParams)
                    })
                },
                getDecisionAttachments: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/dlm/get-decision-log-attachments/`, payload).then((response) => {
                        // console.log(JSON.stringify(response.data))
                        return response.data
                     }, (errorParams) => {
                        console.log('Failed to load decision attachments', errorParams)
                    })
                },

                createDecision: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/dlm/add-decision-log/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create decision', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                updateDecision: (payload) => {                    
                    return $http.post(`${__env.apiUrl}/api/dlm/update-decision-log/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to Update decision', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                archiveDecision: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/dlm/decision-log-archive/`, payload).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to archive decision', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                acknowledgeDecision: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/dlm/decision-log-acknowledged/`, payload).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to acknowledge decision', errorParams)
                    })
                },
                unacknowledgeDecision: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/dlm/decision-log-unacknowledged/`, payload).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to unacknowledge decision', errorParams)
                    })
                },
                addDecisionGeneralAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/dlm/add-decision-log-general-action/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to add Decision general action', errorParams)
                    })
                },
                addDecisionHazardAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/dlm/add-decision-log-hazard-action/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to add Decision hazard action', errorParams)
                    })
                },
                addDecisionAttachments: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/dlm/add-decision-log-attachments/`, payload,{
                        // this cancels AngularJS normal serialization of request
                        transformRequest: angular.identity,
                        // this lets browser set `Content-Type: multipart/form-data` 
                        // header and proper data boundary
                        headers: {'Content-Type': undefined}}).then((response) =>{
                        return response
                    }, (errorParams) => {
                        console.log('Failed to add Decision attachment', errorParams)
                    })
                },
                removeDecisionAttachment: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/dlm/remove-decision-log-attachments/`, payload).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to delete attachments', errorParams)
                    })
                }, 

                

                // Returns list 
                readLDecisionsList: () => {
                    return decisionsList
                },

            }

            //END
        }
    ])