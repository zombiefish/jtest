﻿angular
    .module('safeToDo')
    .controller('AdminUserCtrl', ['$http','$scope', '$timeout', '$q', '$window', '$location',  'gridService', 'select2Service', 'modalService','adminUserService', 'profileService', 'menuService', 'i18nService', '$compile', '$rootScope', '$controller','exportCSV',
    function ($http, $scope, $timeout, $q, $window, $location, gridService, select2Service, modalService, adminUserService, profileService, menuService, i18nService, $compile, $rootScope, $controller, exportCSV) {
        let vm = this
        
        $controller('distributionGroupCtrl', {$scope: $scope})

        vm.employeeList = []
        vm.userOptions = gridService.getCommonOptions()
        vm.disConOptions = gridService.getCommonOptions()
        vm.disGrpOptions = gridService.getCommonOptions()
        vm.currentUser = []
        vm.fullEmployeeList = []
        vm.userEdit = []
        vm.users = []
        vm.disCon = []
        vm.disGrp = []
        vm.distributionList = []
        vm.usersLoaded = false
        vm.roles = []
        vm.positions = []
        vm.countries = []
        vm.provinces = []
        vm.selectedProvinces = []
        vm.positions = []
        vm.canManageUsers = false
        vm.canViewUsers = false
        vm.canArchiveSubmissions = false
        vm.jobs = []
        vm.sfilter = []
        vm.topSearch = ""
        vm.disConSearch = ""
        vm.disGrpSearch = ""
        vm.employeeEnable = true
        vm.emergencyContact_is_avail = false
        vm.resetPasswordChkBox = false
        vm.resetPassword = null
        vm.password = null
        vm.loadMessage = translateTag(8437)  //"Loading users and contacts. Please wait."
        vm.confirm_password = null
        vm.statusFilter = 3885 
        vm.warningMessage = null
        vm.typeOfPerson = null
        vm.activation_select = null
        vm.isEmployee=false
        vm.is_email_mandatory = false
        vm.activation_types = [{
          name: translateTag(8606), //'Manual activation',
          value: 'manual'
        },
        {
          name: translateTag(8607), //'Activate later',
          value: 'later'
        },
        {
          name: translateTag(1285), //'Send activation email',
          value: 'email'
        }]
        
        vm.passwdReset_options = [
          {
            name: translateTag(8608), // 'Update password manually',
            value: 'manual'
          },
          {
            name: translateTag(8609), //'Send password reset email',
            value: 'email'
          }
        ]

        vm.gender = [{
          name: translateTag(6454), //'Male',
          value: '6454'
        },
        {
          name: translateTag(8610), //'Female',
          value: '8610'
        },
        {
          name: translateTag(688), //'Other',
          value: '688'
        }]

        vm.actionUserDisabled = true
        vm.actionDisConDisabled = true
        vm.actionDisGrpDisabled = true

        vm.showAnotherDisCon = true
        vm.addAnotherDisCon = false

        vm.showAnotherDisGrp = true
        vm.addAnotherDisGrp = false

        vm.deleteCount = 0

        vm.selectedCurrentUserIsactive = false

        // Reset check boxes in modal
        vm.resetTriggers = () =>{
          vm.showActivationDropdown = false
          vm.showActivateChkBox = false
          vm.password = null
          vm.confirm_password = null
          vm.resetPasswordChkBox = false
          vm.resetPassword = null
          vm.emergencyContact_is_avail = false
          vm.activation_select = null
          
        }

        vm.hideUserVisibilty = false

        let token = JSON.parse(window.localStorage.getItem('token'))
        vm.currentuser = parseJwt(token.access).user_id
        
        function parseJwt (token) {
          var base64Url = token.split('.')[1]
          var base64 = base64Url.replace('-', '+').replace('_', '/')
          return JSON.parse(window.atob(base64))
        }

        //Get permissions for the user
        menuService.getPagePermissions().then((data) => {
          vm.permissions = data

          vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
          vm.canManageUsers = vm.permissions.includes('Can Manage Users') ? true : false
          vm.canViewUsers = vm.permissions.includes('Can View Users') ? true : false
          vm.canUpdateAccounts = vm.permissions.includes('Can Update Accounts') ? true : false

          vm.canUpdateAccounts = vm.canUpdateAccounts === true ? vm.canUpdateAccounts : vm.canManageUsers
        })

        //Function to update grid when User search is changed
        vm.topSearchChanged = () =>{
          vm.userOptions.api.setQuickFilter(vm.topSearch);
        }

        //Function to update grid when DisCon search is changed
        vm.topSearchDisConChanged = () =>{
          vm.disConOptions.api.setQuickFilter(vm.disConSearch) 
        }
        
        //Function to update grid when DisGrp search is changed
        vm.topSearchDisGrpChanged = () =>{
          vm.disGrpOptions.api.setQuickFilter(vm.disGrpSearch) 
        }

        vm.changeStatus = (status) => {
          // Users -Employees - Inactive - All
          vm.statusFilter = status
          vm.refreshScreen()
        }

        // function to reset data on user modal forms
        vm.createNewUser = () => {
          vm.submitted = false
          vm.is_email_mandatory = false
          vm.newUser = {
            per_id: null,
            per_first_name: null,
            per_middle_name: null,
            per_last_name: null,
            per_dob: null,
            per_sin: null,
            per_gender: null,
            per_enote: null,
            per_enable: false,
            users: [{
              id: null,
              email: null,
              is_active: false,
              roles: [],
              activation_type : 'later'
            }],
            address: {
              add_id: null,
              add_line_1: null,
              add_postal_code: null,
              add_city: null,
              add_prv: null,
              add_ctr: null,
              add_aty: 1
            }
            ,
            address_phone: {
              pho_id: null,
              pho_number: "",
              pho_pty: 1,
              pho_pty__pty_code: null,
              pho_pty__pty_id: 1,
              pho_pty__pty_description: "Home"
  
            },
            employees: [{
              emp_id: null,
              emp_enable: 1,
              emp_employee_number: null,
              emp_pos_id: null,
              emp_enable: true,
              employee_sites: [],
              employee_jobs: [],
              emp_data_visibility:"profile"
            }],
            emergency_contacts: [{
              pec_id: null,
              pec_per_id: null,
              pec_first_name: null,
              pec_last_name: null,
              pec_relationship: null,
              pec_mobile_phone: null,
              pec_work_phone: null,
              pec_home_phone: null,
              pec_email: null
            }],
            user_profile :{
              upr_language : null
            }
          }
        }
        
        // function to reset data on DisCon modal forms
        vm.resetCurrentDisCon = () => {
          vm.addAnotherDisCon = false
          vm.submitted = false
          vm.currentDisCon = {
            edl_id : null,
            edl_first_name: '',
            edl_last_name: '',
            edl_company_name: '',
            edl_email: '',
            edl_modified_by: null,
            edl_modified_date: '',
            edl_created_by: null,
            edl_created_date: '',
          }
        }

        vm.resetCurrentDisGrp = () => {
          vm.addAnotherGrp = false
          vm.submitted = false
          vm.currentDisGrp = {
            dig_id : null,
            dig_group_name : '',
            dig_created_date : '',
            dge_email : null,
            dig_created_by_per_id : '',
            dig_modified_by_per_id : ''
          }
        }

        //Funtion to export the DisGrp selected rows to CSV file
        vm.exportDisGrpCSV = () => {          
          let rows = JSON.parse(JSON.stringify(vm.disGrpOptions.api.getSelectedRows()))
          exportCSV.export_csv(rows, translateTag(8472))
        }

        //Funtion to export the DisCon selected rows to CSV file
        vm.exportDisConCSV = () => {          
          let rows = JSON.parse(JSON.stringify(vm.disConOptions.api.getSelectedRows()))
          exportCSV.export_csv(rows, translateTag(8412))          
        }

        //Funtion to export the Users selected rows to CSV file
        vm.exportUsersCSV = () => {
          let rows = JSON.parse(JSON.stringify(vm.userOptions.api.getSelectedRows()))

          rows.forEach(user => {
            for (let [key, value] of Object.entries(user)) {
              if(typeof value == 'object'){
                delete user[key]
              }
              delete user['per_modified_by_per_id']
            }
            if(!('per_middle_name' in user)){            
              user['per_middle_name'] = null
            }
          });

          exportCSV.export_csv(rows, 'UsersData')          
        }

        // function that matches values to the lable for a particular table
        vm.multiRenderer = (table, data, rid, name) => {
         let output = ''
         data.forEach((id, index)=>{
           table.forEach((tab, index) => {
              if(id === tab[rid]) {
                output += tab[name]
              }
           }) 
           if(index + 1 < data.length) {
            output += ', '
           }
         })
         return(output)
        }

        // Definition of User Columns for Main AG-Grid
        let userColumns = [
            {
                headerName: '',
                field: 'dummyCheckbox',
                maxWidth: 30,
                minWidth: 30,
                checkboxSelection: true,
                suppressMenu: true,
                suppressSorting: true,
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true

            },
            {
              field: 'ID',
              hide: true,
            },
            
            {
                field: "review", headerName: " ", minWidth: 80, maxWidth: 80, suppressMenu: true, suppressSorting: true,
                cellRenderer: function (params) {
                  let ID = params.data.ID                  
                  return `<div ng-if="admuser.canUpdateAccounts" class="pointer text-left" ng-click="admuser.openModal('UserEditModal','edit','${ID}')"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title={{menu.translateLabels(1194)}}></i></div>` 
                },                
            },
            {
                field: "per_last_name",
                headerName: " ",
                minWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                sort: 'asc',
                cellRenderer: 'tippyCellRenderer',
                valueGetter: function(params) {  
                  if(params.data.per_middle_name){                  
                    return params.data.per_last_name + ', ' + params.data.per_first_name + ' ' + params.data.per_middle_name;
                  }else{
                    return params.data.per_last_name + ', ' + params.data.per_first_name;
                  }                
                }
            },
            {
                field: "roles",
                headerName: " ",
                minWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                valueGetter: function (params) {
                if(params.data.users.length){
                    return(vm.multiRenderer(vm.roles, params.data.users[0].roles, 'aro_id','aro_name_trans'))              
                }
                },
                getQuickFilterText: function (params) {
                if(params.data.users.length){
                    return(vm.multiRenderer(vm.roles, params.data.users[0].roles, 'aro_id','aro_name_trans'))              
                }
                },             
            },
            {
                field: "userid",
                headerName: " ",
                minWidth: 100,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                valueGetter: function (params) {
                if(params.data.employees.length){
                    return params.data.employees[0].emp_employee_number
                }
                }
            },
            {
                field: "sites",
                headerName: " ",
                minWidth: 100,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                valueGetter: function (params) {
                if(params.data.employees.length){
                    return(vm.multiRenderer(vm.sites, params.data.employees[0].employee_sites, 'rld_id','rld_name'))              
                }
                },
                getQuickFilterText: function(params) {
                if(params.data.employees.length){
                    return(vm.multiRenderer(vm.sites, params.data.employees[0].employee_sites, 'rld_id','rld_name'))              
                }
                },
            },
            {
                field: "jobs",
                headerName: " ",
                minWidth: 100,
                cellRenderer: 'tippyCellRenderer',
                valueGetter: function (params) {
                    if(params.data.employees.length){
                    return(vm.multiRenderer(vm.jobs, params.data.employees[0].employee_jobs, 'rld_id','rld_code'))              
                    }
                },
                getQuickFilterText: function (params) {
                    if(params.data.employees.length){
                    return(vm.multiRenderer(vm.jobs, params.data.employees[0].employee_jobs, 'rld_id','rld_code'))              
                    }
                },
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab']
            },
            {
                field: "per_modified_date",
                headerName: " ",
                minWidth: 160,
                maxWidth: 160,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                valueGetter: function (params) {
                if(params.data.per_modified_date != null && params.data.per_modified_by_per != null)                  
                    return params.data.per_modified_date.substring(0,10)
                else 
                 return ""  
                
                },
            },
            {
                field: "modified_by",
                headerName: " ",
                minWidth: 150,
                maxWidth: 200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                valueGetter: function (params) {
                return(params.data.per_modified_by_per)
                },
            },
            {
              field: "last_login",
              headerName: " ",
              minWidth: 150,
              maxWidth: 200,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: 'tippyCellRenderer'
            },
            {
              field: "status",
              headerName: " ",
              maxWidth: 80,
              minWidth: 80,               
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: 'tippyCellRenderer',
              valueGetter: function (params) {
                return translateTag(getUserAccountStatus(params.data))         
              },
            },
            {field:"address.add_city",hide:true},
            {field:"tippy_address",hide:true},
            {field:"address.add_postal_code",hide:true},
            {field:"address.add_prv",hide:true},
            {field:"employee_ID",hide:true},
            {field:"employees.0.emp_id",hide:true},
            {field:"employees.0.emp_enable",hide:true},
            {field:"employees.0.emp_pos_id",hide:true},
            {field:"per_created_by_per",hide:true},
            {field:"tippy_date_of_birth",hide:true},
            {field:"tippy_sites",hide:true},
            {field:"tippy_position",hide:true },
            {field:"tippy_roles",hide:true},
            {field:"per_gender",hide:true},
            {field:"tippy_phone_number",hide:true},
            {field:"tippy_jobs",hide:true},
            {field:"tippy_email",hide:true},
            {field:"tippy_postal_code", hide:true},
            {field:"tippy_Language", hide:true},
            {field:"per_modified_by_per", hide:true},
            {field:"per_modified_by_per_id", hide:true},
            {field:"per_modified_date", hide:true},
            {field:"per_sin", hide:true},
            
        ]

        vm.userOptions.columnDefs = userColumns
        vm.userOptions.accentedSort = true
        // Definition of User Columns for Main AG-Grid
        let disConColumns = [
            {
                headerName: '',
                field: 'dummyCheckbox',
                maxWidth: 50,
                minWidth: 50,
                checkboxSelection: true,
                suppressMenu: true,
                suppressSorting: true,
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true
            },
            {
              field: 'edl_id',
              hide: true,
            },
            {
                field: "review", headerName: " ", minWidth: 80, maxWidth: 80, suppressMenu: true, suppressSorting: true,
                cellRenderer: function (params) {
                  return `<div ng-if="admuser.canManageUsers" class="pointer text-left" ng-click="admuser.openDisConModal('DisConModal','edit','${params.node.id}')"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title={{menu.translateLabels(1194)}}></i></div>` 
                },
            },
            {
                field: "edl_last_name",
                headerName: " ",
                // headerName: "Name",
                minWidth: 200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                sort: 'asc',
                cellRenderer: 'tippyCellRenderer',
                valueGetter: function(params) {
                return params.data.edl_last_name + ', ' + params.data.edl_first_name 
                }
            },
            {
                field: "edl_company_name",
                headerName: " ",
                // headerName: "Company",
                minWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "edl_email",
                headerName: " ",
                // headerName: "Email",
                minWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "edl_modified_date",
                headerName: " ",
                // headerName: "Date Last Modified",
                minWidth: 160,
                maxWidth: 160,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                valueGetter: function (params) {
                if(params.data.edl_modified_date != null)
                    return params.data.edl_modified_date.substring(0,10)
                },
            },
            {
                field: "edl_modified_by_per_id",
                headerName: " ",
                // headerName: "Modified By",
                minWidth: 150,
                maxWidth: 200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                valueGetter: function (params) {
                return(params.data.edl_modified_by_per_id)
                },
            },
            {field:"edl_created_date", hide:true},
            {field:"edl_created_by_per_id", hide:true},
        ]

        // Definition of Distributiion Groups for Main AG-Grid.
        let disGroupColumns = [
          {
            headerName: '',
            field: 'dummyCheckbox',
            maxWidth: 50,
            minWidth: 50,
            checkboxSelection: true,
            suppressMenu: true,
            suppressSorting: true,
            headerCheckboxSelection: true,
            headerCheckboxSelectionFilteredOnly: true
          },
          {
            field: 'dig_id',
            hide: true,
          },
          {
            field: "review", headerName: " ", minWidth: 80, maxWidth: 80, suppressMenu: true, suppressSorting: true,
            cellRenderer: function (params) {
              return `<div ng-if="admuser.canManageUsers" class="pointer text-left" ng-click="admuser.openDisGrpModal('DisGrpModal','edit','${params.node.id}')"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title={{menu.translateLabels(1194)}}></i></div>` 
            },
          },
          {
            field: "Group_Name",
            headerName: " ",
            minWidth: 200,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            sort: 'asc',
            cellRenderer: 'tippyCellRenderer',
          },
          {
            field: "Email",
            headerName: " ",
            minWidth: 150,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: 'tippyCellRenderer',
          },
          {
            field: "Date_Last_Modified",
            headerName: "Date Last Modified",
            minWidth: 160,
            maxWidth: 160,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: 'tippyCellRenderer',
          },
          {
            field: "Modified_By",
            headerName: " ",
            minWidth: 160,
            maxWidth: 160,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: 'tippyCellRenderer',
          } 
        ]

        vm.disConOptions.columnDefs = disConColumns
        vm.disGrpOptions.columnDefs = disGroupColumns
        vm.disGrpOptions.accentedSort = true
        vm.disConOptions.accentedSort = true

        //Disable action buttons when there are no rows selected
        vm.userOptions.onSelectionChanged = () => {          
          var selectedRows = vm.userOptions.api.getSelectedRows()
          vm.actionUserDisabled = selectedRows.length == 0
          $scope.$apply()
        }

        vm.userOptions.onCellClicked  = (params) => {
          if(vm.canManageUsers === false && vm.canViewUsers === true){
            vm.openModal('UserEditModal','view',params.data.ID)
          }          
        }

        vm.disConOptions.onSelectionChanged = () => {          
          var selectedRows = vm.disConOptions.api.getSelectedRows()
          vm.actionDisConDisabled = selectedRows.length == 0
          $scope.$apply()
        }

        vm.disGrpOptions.onSelectionChanged = () => {
          var selectedRows = vm.disGrpOptions.api.getSelectedRows()
          vm.actionDisGrpDisabled = selectedRows.length == 0
          $scope.$apply()
        }

        //Funtion to initialize select2
        vm.initializeSelect2 = (parent) => {
          setTimeout(()=>{ 
          $('.select-single, .select-multiple')
            .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} .modal-body`), escapeMarkup: function (text) { return text } })
            .on('select2:select', (event) => {
              if(event.target.parentNode.querySelector('.distribution-list')){
                $rootScope.$broadcast('distribution-list-added', event)
              }
               $(this).parent().find('label').addClass('filled') 
            })
            .on('select2:unselect', (event) => {
              if(event.target.parentNode.querySelector('.distribution-list'))
                  $rootScope.$broadcast('distribution-list-removed', event)
              $(this).parent().find('label').addClass('filled')
            })
            $('.select2-selection__arrow b').addClass("fa fa-caret-down")  // Add caret on selects
            select2Service.select2Tags()
            }, 100)
            today = new Date()
            if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
            $('.datepicker').pickadate({
            format: 'yyyy-mm-dd',
            onClose : function(){
              this.$holder.blur()
          },
            selectYears: 80,
            min: new Date(moment(today).subtract(90,'years').calendar()),
            max: new Date(moment(today).subtract(13,'years').calendar()),
          }).removeAttr('readonly')
          .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
            evt.preventDefault()
          })
        }

        // Function to get jobs from sites
        vm.getSiteJobs = () => {
        mainJob = JSON.parse(JSON.stringify(vm.jobs))
        vm.filteredJobs = []
          vm.currentUser.employees[0].employee_sites.forEach((site)=>{
            mainJob.forEach((job) => {
              if(job.rld_parent_detail_rld_id == site){
                if(!job.rld_is_active) {
                  job.rld_name += ` (${translateTag(3793)})`
                }
                vm.filteredJobs.push(job)
              }
            })
          })
          vm.filteredJobs.sort((a,b) => {
            let x = a.rld_code.toLowerCase()
            let y = b.rld_code.toLowerCase()
            return x < y ? -1 : x > y ? 1 : 0
          })
        }

        vm.showReset = () => {
          // when the employee check and the user check box are checked then show reset password. 
          // when the employee checkbox is checked and user is unchecked dont show the reset password. -new user
          if(vm.currentMode == 'edit'){
            if(vm.currentUser.employees[0].emp_enable == true && vm.currentUser.users[0].is_active == true){

              vm.showResetCheckbox = true 
            } else if(vm.currentUser.employees[0].emp_enable == true && vm.currentUser.users[0].is_active == false){
              vm.showResetCheckbox = false
            } else {

              vm.showResetCheckbox = false
            }
          } else {

            vm.showResetCheckbox = false
          }

        }

        vm.activate_employee = () => {
          vm.showActivationDropdown = vm.currentUser.employees[0].emp_enable
          vm.isEmployee = vm.currentUser.employees[0].emp_enable

          if(vm.isEmployee && vm.currentUser.users[0].is_active){
            vm.showActivationDropdown = false
          }
        }

        // When editing a user account, and the employee button is unchecked, uncheck
        vm.employeeCheck = () => {
          // when the employee check box is unchecked then uncheck the user account check box.
          if(vm.currentMode == 'edit'){
            if(vm.currentUser.employees[0].emp_enable == false){
              vm.currentUser.users[0].is_active = false
              vm.showActivationDropdown = false
              vm.resetPasswordChkBox = false
              
            } 
            else {              
              vm.showActivationDropdown = true
            }
        } else {
           if(vm.currentUser.employees[0].emp_enable==true) {
            vm.showActivationDropdown = true
            
           } else {
            vm.showActivationDropdown = false
            vm.resetPasswordChkBox = false
           }

        }

          vm.showReset()
          vm.resetPasswordField()
        }


        // Open the Create/Edit Modal
        vm.openModal = (modalId, mode="new", id) => {

          vm.accountsEditMode = mode
          
          if(mode === "new"){
            vm.isEmployee=true
            vm.currentMode = 'new'
            vm.submitted = false
            vm.showActivationDropdown = true
            vm.createNewUser()
            vm.currentUser = vm.newUser

            vm.showReset()
            vm.showActivationDropdown = true
            vm.activation_select = 'later'

            if(vm.languageList.length >0){
              vm.languageList.forEach((language) => {
                if(language.lng_default){                
                  vm.currentUser.upr_per_id = []
                  vm.currentUser.upr_per_id.push({upr_language : language.lng_name})                
                }
              })
            }          

            modalService.Open(modalId)
          }
          else if(mode === 'edit') {     
               
            vm.currentMode = 'edit'
            vm.showActivateChkBox = true
            vm.submitted = false                        
            vm.currentUser = JSON.parse(JSON.stringify(vm.user_list_data.find((data)=>parseInt(data.ID)===parseInt(id))))     
            vm.userEdit = JSON.parse(JSON.stringify(vm.currentUser))
            vm.activation_select = vm.currentUser.users[0].activation_type

            if(vm.currentUser.users[0].is_active == false && vm.currentUser.employees[0].emp_enable == true && vm.currentUser.users[0].activation_type === 'later'){
              vm.showActivationDropdown = true
              vm.showActivateChkBox = false 
            } else {
              vm.showActivationDropdown = false
              vm.showActivateChkBox = true
            }

            vm.showReset()
            if(vm.currentUser.emergency_contacts.length === 0){
              vm.currentUser.emergency_contacts.push({
                pec_id: null,
                pec_per_id: null,
                pec_first_name: null,
                pec_last_name: null,
                pec_relationship: null,
                pec_mobile_phone: null,
                pec_work_phone: null,
                pec_home_phone: null,
                pec_email: null
              })
            }
            let emergencyContact = vm.currentUser.emergency_contacts[0]
            if(emergencyContact.pec_first_name || emergencyContact.pec_last_name || emergencyContact.pec_relationship || emergencyContact.pec_mobile_phone || emergencyContact.pec_work_phone || emergencyContact.pec_home_phone || emergencyContact.pec_email){
              vm.emergencyContact_is_avail = true
            }
            if(vm.currentUser.address.add_ctr){
              vm.getSelectedProvinces(vm.currentUser.address.add_ctr)
            }
         
            modalService.Open(modalId)
            vm.getSiteJobs()
           
          }
          else if(mode === 'view'){

            const UPDATE_PARTIAL_FIELDS = ['address', 'country', 'province', 'city', 'zippostal', 'phonenumber', 'site', 'jobNumber', 'emergency_contact', 'emerg_first_name', 'emerg_last_name', 'emerg_relation', 'emerg_mobile', 'emerg_work_phone', 'emerg_home_phone', 'emerg_email', 'save_user', 'cancel_user']
            
            vm.currentUser = JSON.parse(JSON.stringify(vm.user_list_data.find((data)=>parseInt(data.ID)===parseInt(id))))     
            var form = document.getElementsByName('AdminUserForm')[0]
            var elements = form.elements;
            for (var i = 0, len = elements.length; i < len; ++i) {
              if(vm.canUpdateAccounts === true){
                if(!UPDATE_PARTIAL_FIELDS.includes(elements[i].name)){
                  elements[i].disabled = true;
                }
              }
              else{
                if(elements[i].name != 'cancel_user'){
                  elements[i].disabled = true;
                }
              }                
            }

            modalService.Open(modalId)
          }
                
          // function call - bind the grid for data visibility
          vm.selectDataVisibility() // set the user visibility 

          vm.dataVisibiltyGridBind(vm.currentUser.per_id)
          vm.selectedCurrentUserIsactive = vm.currentUser.users[0].is_active
          vm.isSelectedCurrentUserEmailEmpty = (vm.currentUser.users[0].email === undefined || vm.currentUser.users[0].email === null || vm.currentUser.users[0].email === '') ? true : false
          vm.initializeSelect2(modalId)
        }
    

        vm.selectDataVisibility=()=>{    
          if(vm.currentUser.employees[0].emp_data_visibility == 'custom'){
            vm.hideUserVisibilty = true
          }
          else{
            vm.hideUserVisibilty = false 
          }
        }

        vm.dataVisibilityOptions = gridService.getCommonOptions()

        vm.dataVisibiltyGridBind=(id)=>{          
          $q.all([            
             adminUserService.getSitesJobsByUser(id)     
          ]).then((values) => {
              vm.customSiteJob = values[0];
              if(vm.dataVisibilityOptions.api) {
                vm.dataVisibilityOptions.api.setRowData(prepareDataVisibilityGridData(vm.customSiteJob))
                vm.dataVisibilityOptions.api.redrawRows()
                vm.dataVisibilityOptions.api.sizeColumnsToFit()
              }
          })
        }  
        
        function prepareDataVisibilityGridData(data){
          vm.customSiteJob.forEach((item)=>{
            if(item.job_code !== undefined){
              item.full_job = item.job_code + ' (' +item.job_description+')'
            }            
          })
          return vm.customSiteJob 
        }

        function setEnable(params){   
          setTimeout(() => {
            let expand = false          
            if(params.node.allLeafChildren!==undefined){
              for (let index = 0; index < params.node.allLeafChildren.length; index++) {
                if(params.node.allLeafChildren[index].data.enable){
                  expand=true
                }
              }
            }          
            if(expand){
              params.node.setExpanded(true)            
              params.node.setExpanded(false)
            }            
          }, 1000);          
        }
        
        vm.columnDefs = [
          {
            headerName: '',
            field: 'dummyCheckbox',
            maxWidth: 50,
            minWidth: 50,
            checkboxSelection: true,
            cellRenderer: (params) => {            
              if(params) {                  
                  setEnable(params)                
              }
              if(params.data){
                params.node.setSelected(params.data.enable)
              }
            },
            cellStyle: () => {
              // to disable checkbox selection in view mode
              return vm.accountsEditMode === 'view' ? {'pointer-events': 'none'} : ''
            }                 
          },
          {
            headerName: "site_description", 
            field: "site_description",             
            hide:true, 
            rowGroup:true,
            width:100,
            cellRenderer: function(params){
              // looping through each child data of sites and check if job is returned for that site, 
              // if not i.e, the site has no jobs in system. hence setting child count to 0 to show count (0) on ag grid
              if(params.node.allLeafChildren[0].data.job_id === undefined){
                params.node.allChildrenCount = 0
              }
              return params.value
            }
          },                   
          {
            headerName: translateAgGridField("full_job"), 
            field: "full_job", 
            width: 300,           
            cellStyle: { "white-space": "nowrap !important" },
            tooltipField: 'full_job',          
          }
        ];
        vm.dataVisibilityOptions.columnDefs=vm.columnDefs
        vm.dataVisibilityOptions.rowSelection = 'multiple'
        vm.dataVisibilityOptions.groupSelectsChildren = true
        vm.dataVisibilityOptions.pagination= false
        vm.dataVisibilityOptions.onRowSelected = rowSelected
        vm.dataVisibilityOptions.autoGroupColumnDef = {                        
          cellRender : 'agGroupCellRenderer',          
          headerName: translateAgGridField('Site'), 
          cellStyle: { "white-space": "nowrap !important" },      
          tooltipField: 'site_description'    
        }

        function rowSelected(event) {  
          vm.customSiteJob.forEach((item) => {
            if(event.node.key===item.site_description){
              if(event.node.group===true){                
                if(event.node.selected===true){ 
                  item.enable=true                                
                }
                else{
                  event.node.allLeafChildren.forEach((child) => {                      
                    if(child.selected===true){
                      child.data.enable = true
                    }
                    if(child.selected===false){
                      child.data.enable = false
                    }
                  })
                }
              }                            
            }
            else {
              try{
                if(event.node.parent.key===item.site_description){
                  event.node.parent.allLeafChildren.forEach((child) => {                      
                    if(child.selected===true){
                      child.data.enable = true
                    }
                    if(child.selected===false){
                      child.data.enable = false
                    }
                  })
                } 
              } 
              catch(err){
                return false
              }
               
            }
                              
          })          
        }

        vm.openDisGrpModal = (modalId, mode="new", id) => {
          if(mode=="new"){
            vm.currentMode = 'new'
            vm.showAnotherDisGrp = true
            vm.resetCurrentDisGrp()
            modalService.Open(modalId)
          } else {
            vm.currentMode='edit'
            vm.showAnotherDisGrp = false
            vm.resetCurrentDisGrp()
            let data = vm.disGrpOptions.api.getRowNode(id).data
            let emails = []
            data.Email.split(",").forEach(element => {
              emails.push(element.trim())
            })
            let editGrp = {
              dig_id : data.ID,
              dig_group_name : data.Group_Name,
              
              email : emails

            }
            vm.currentDisGrp = editGrp
            modalService.Open(modalId)
          }
          vm.initializeSelect2(modalId)
        }

        // Open the DisCon Create/Edit Modal
        vm.openDisConModal = (modalId, mode="new", id) => {
          if(mode === "new"){
            vm.currentMode = 'new'
            vm.showAnotherDisCon = true
            vm.resetCurrentDisCon()
            modalService.Open(modalId)
          }
          else {
            vm.currentMode = 'edit'
            vm.showAnotherDisCon = false
            vm.resetCurrentDisCon()

            let data = vm.disConOptions.api.getRowNode(id).data
            let editContact = {
              edl_id: data.edl_id,
              edl_company_name:  data.edl_company_name,
              edl_first_name: data.edl_first_name,
              edl_last_name: data.edl_last_name,
              edl_email: data.edl_email
            }
            vm.currentDisCon = editContact
            modalService.Open(modalId) 
          }
          vm.initializeSelect2(modalId)
        }

        // close the modals
        vm.cancelUser = (id) => {
          vm.currentUser = vm.newUser
          vm.resetTriggers()
          modalService.Close(id) 
          resetFormFieldClassList('AdminUserForm')
        }

        vm.cancelDisGrp = (id) => {
          modalService.Close(id)
          resetFormFieldClassList('DisGrpForm')
        }

        vm.cancelDisCon = (id) => {
          modalService.Close(id) 
          resetFormFieldClassList('DisConForm')
        }

        // get the cookie
        function getCookie(name) {
          // Split cookie string and get all individual name=value pairs in an array 
          var cookieArr = document.cookie.split(";"); 
          // Loop through the array elements 
          for(var i = 0; i < cookieArr.length; i++) { var cookiePair = cookieArr[i].split("="); 
          /* Removing whitespace at the beginning of the cookie name and compare it with the given string */ 
          if(name == cookiePair[0].trim()) { 
            // Decode the cookie value and return 
            return decodeURIComponent(cookiePair[1]); } } // Return null if not found 
            return null; 
           }

        vm.populateUserActivityStatusMessage = (allCounts)=>{            
          let actionMainMessge = translateTag(8839)
          actionMainMessge = actionMainMessge.replace('first_name',vm.currentUser.per_first_name)
          actionMainMessge = actionMainMessge.replace('middle_name',vm.currentUser.per_middle_name)
          actionMainMessge = actionMainMessge.replace('last_name',vm.currentUser.per_last_name)
          actionMainMessge = actionMainMessge.replace('action_count',allCounts[0].action_items_count)          
          let actionSubMessge = translateTag(8840)

          let rmmMainMessge = translateTag(8841)
          rmmMainMessge = rmmMainMessge.replace('rmm_review_count',allCounts[0].approver_ra_count)
          rmmMainMessge = rmmMainMessge.replace('first_name',vm.currentUser.per_first_name)
          rmmMainMessge = rmmMainMessge.replace('middle_name',vm.currentUser.per_middle_name)
          rmmMainMessge = rmmMainMessge.replace('last_name',vm.currentUser.per_last_name)
          let rmmSubMessge = translateTag(8842)

          let targetMainMessge = translateTag(8843)
          targetMainMessge = targetMainMessge.replace('target_count',allCounts[0].target_count)
          targetMainMessge = targetMainMessge.replace('first_name',vm.currentUser.per_first_name)
          targetMainMessge = targetMainMessge.replace('middle_name',vm.currentUser.per_middle_name)
          targetMainMessge = targetMainMessge.replace('last_name',vm.currentUser.per_last_name)
          let targetSubMessge = translateTag(8844)

          let barColor = "'barLow': true"
          let textcolor = ''
          if(allCounts[0].action_items_count>0){
            barColor =   "'barExtreme': true"
            textcolor = 'text-danger'
          }

          messagedata =  `<div class="container-fluid overflow-auto">                                              
                            <div class="row position-relative userActivityBar" ng-class="{ `+ barColor +`}">                                             
                              <div class="pb-0">` + actionMainMessge + `</div>
                              <small ng-non-bindable class="`+ textcolor +` pl-3">` + actionSubMessge + `</small>
                            </div>                                              
                                                                    
                            <div class="row position-relative userActivityBar mt-3" ng-class="{ 'barLow': true}">                                             
                              <div class="pb-0">`+ rmmMainMessge +`</div>
                              <small ng-non-bindable class="pl-3">` + rmmSubMessge + `</small>
                            </div>                                              
                                                                    
                            <div class="row position-relative userActivityBar mt-3 mb-2" ng-class="{ 'barLow': true}">                                             
                              <div  class="pb-0">` + targetMainMessge+ `</div>
                              <small ng-non-bindable class="pl-3">` + targetSubMessge + `</small>                           
                            </div>                                              
                          </div>`

          return messagedata
        }

        vm.ActionRedirect=()=>{
          $window.sessionStorage.setItem('userAdminRedirect_actionsFilter', 'Deactivation')
          $window.sessionStorage.setItem('userAdminRedirect_userId', vm.currentUser.per_id)          
          $location.path('/a/action-management'); 

        }

        vm.userPendingAction = 0
        vm.flagOkay = 1
        vm.clickOkay = () => {
          vm.flagOkay = 0
          modalService.Close('confirmModal')
        }

        function viewUserActivityStatus()  {
          return new Promise((resolve,reject)=>{
            $q.all([            
              adminUserService.getCheckUserDeactivation(vm.currentUser.per_id)     
            ]).then((allCounts) => {
                vm.modalElementsUserActivity = {
                  title: translateTag(8838),  //"User Activity Status"
                  message: `<div><p>${vm.populateUserActivityStatusMessage(allCounts)}</p></div>`,
                }
                vm.userPendingAction = allCounts[0].action_items_count 
                if(allCounts[0].action_items_count == 0) {  
                  vm.modalElementsUserActivity.buttons = `<button class='btn btn-primary btn-rounded' ng-click="vm.return('button1')">{{vm.componentTranslateLabels(8846)}}</button>`
                } else { 
                  vm.modalElementsUserActivity.buttons = 
                                            `<button class='btn btn-primary btn-rounded' ng-click="vm.return('closeModal')">{{vm.componentTranslateLabels(1257)}}</button>
                                              <button class='btn btn-primary btn-rounded' ng-click="vm.return('button2')">{{vm.componentTranslateLabels(8845)}}</button>`
                }
                if(allCounts[0].action_items_count > 0 || allCounts[0].approver_ra_count  > 0 || allCounts[0].target_count ){
                  document.getElementById('confirmcallingform').innerHTML = 'ADMINUSERSTATUSCALLCONFIRMMODAL' 
                  $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsUserActivity)
                  return true
                }
                else{
                  vm.flagOkay = 0
                  vm.userPendingAction = 0
                  return false
                }
            }).then((pop_up_user_activity_modal)=>{
              if(pop_up_user_activity_modal){
                $scope.$on("ADMINUSERSTATUSCALLCONFIRMMODAL", (event,result) => {
                  if(result=='button1') {
                      vm.clickOkay()    
                      resolve(true)          
                  }
                  else if(result=='button2') {
                    vm.ActionRedirect()            
                  }
                  else if(result=='closeModal') {
                    vm.submitted = false
                    modalService.Close('confirmModal');
                  }
                })
              }else{
                resolve(true)
              }
            })
          })
        }
        
        
        vm.saveUser = () => {
            vm.is_email_mandatory = vm.currentMode !== "new" ? (!vm.currentUser.users[0].is_active && vm.isSelectedCurrentUserEmailEmpty === true ? false : true) : vm.is_email_mandatory
            let dataVisibilityGridData = vm.dataVisibilityOptions.api.getSelectedRows()
            document.getElementById("middlename").removeAttribute("required")
            vm.currentUser.emergency_contacts[0].pec_email = vm.currentUser.emergency_contacts[0].pec_email ? vm.currentUser.emergency_contacts[0].pec_email.trim().toLowerCase() : vm.currentUser.emergency_contacts[0].pec_email

            if(vm.ValidateUser(vm.currentMode)) {
                vm.submitted = true
                let language = getCookie("lang")

                if(language === undefined) {
                    language = window.navigator.language
                }
                if(vm.currentMode !== "new") {
                    if(vm.selectedCurrentUserIsactive != vm.currentUser.users[0].is_active && vm.currentUser.users[0].is_active == false) {
                        viewUserActivityStatus().then(() => {
                            updateUser()
                        })
                    } else {
                        vm.userPendingAction = 0
                        vm.flagOkay = 0
                        updateUser()
                    }
                } else {
                    $http.post(`${__env.apiUrl}/api/user/users/create/`, vm.prepareNewUserObject()).then(
                        (response) => {
                            // for edit and update the site and job grid
                            if(response.data.status === false) {
                                if(response.data.message == "You have signup before and you are already an active user") {
                                    toastr.error(translateTag(8587)) // 'Email Already In Use'
                                }
                                if(response.data.message == "You have not activated your account. We have send you link.") {
                                    toastr.error(translateTag(8587)) // 'Email Already In Use'
                                }
                                if(response.data.message == "Your account is not active. Please contact to admin") {
                                    toastr.error(translateTag(8913)) // 'Your account is not active please contact administrator'
                                }
                                vm.checkDuplicateName(response.data.message.split(","))
                            } else {
                                let newUserID = response.data.per_id
                                if(data.employee.emp_data_visibility === "custom" && newUserID) {
                                    adminUserService.createUpdateUserSiteJob(newUserID, dataVisibilityGridData)
                                }
                                vm.resetTriggers()
                                vm.usersLoaded = false
                                vm.refreshScreen("User")
                                modalService.Close("UserEditModal")
                                resetFormFieldClassList("AdminUserForm")
                            }
                        },
                        (errorParams) => {
                            if(errorParams.status === 403 && errorParams.data.detail) toastr.error(errorParams.data.detail)

                            if(errorParams.status === 400 && errorParams.data.email) {
                                toastr.error(errorParams.data.email)
                                vm.submitted = false
                            }
                        }
                    )
                    vm.currentUser = vm.newUser
                }
            } else {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        function updateUser () {
          let dataVisibilityGridData = vm.dataVisibilityOptions.api.getSelectedRows()
          if(vm.userPendingAction == 0 && vm.flagOkay == 0){
            vm.clickOkay()
            vm.submitted = true
              $http.post(`${__env.apiUrl}/api/person/persons/${vm.currentUser.per_id}/update/`, vm.prepareUpdateUserObject()).then((response) =>{
                if(response.data.status === false){
                  vm.checkDuplicateName(response.data.message.split(','))
                }
                else{
                    // for edit and update the site and job grid
                    if(data.employee.emp_data_visibility==='custom'){
                    adminUserService.createUpdateUserSiteJob(vm.currentUser.per_id, dataVisibilityGridData)
                    }

                    vm.resetTriggers()
                    vm.usersLoaded = false
                    vm.refreshScreen('User')
                    modalService.Close('UserEditModal')
                    resetFormFieldClassList('AdminUserForm')
                    // document.forms['AdminUserForm'].classList.remove('was-validated')
                }
              }, (errorParams) => {
                if(errorParams.status === 403 && errorParams.data.detail)
                  toastr.error(errorParams.data.detail)

                if(errorParams.status === 400 && errorParams.data.email){
                  toastr.error(errorParams.data.email)
                  vm.submitted = false
                }
              })
          }
        }

        vm.checkDuplicateName = (response) => {
          let status = response[1]
          vm.typeOfPerson = status == 'True' ? translateTag(3557) : status == 'False' ? translateTag(3793) : translateTag(3793)
          vm.modalElementsWarning = {
            title: translateTag(2182),  //"Warning"
            message: 
            ` <p ng-if=${response[0]=='middle_name_required'} note="An Active user with the name  already exists in the database.
            Please use the middle name field to make it easy to differentiate between the two individuals."><span ng-non-bindable>${translateTag(2769)} <strong>${vm.typeOfPerson}</strong> ${translateTag(2770)} <strong>${vm.currentUser.per_first_name} ${vm.currentUser.per_last_name}</strong> ${translateTag(2771)}<br>${translateTag(2773)}</span></p>
            <p ng-if=${response[0]=='full_name_exists'} note="An Active user with the name  already exists in the database.
            Please change one of the person's name to make it easy to differentiate between the two individuals."><span ng-non-bindable>${translateTag(2769)} <strong>${vm.typeOfPerson}</strong> ${translateTag(2770)} <strong>${vm.currentUser.per_first_name} ${vm.currentUser.per_middle_name} ${vm.currentUser.per_last_name}</strong> ${translateTag(2771)}<br>${translateTag(2772)}</span></p>`,
            buttons:  `<button class='btn btn-primary btn-rounded' ng-click="vm.closeModal()" note="OK">{{vm.componentTranslateLabels(1405)}}</button>` 
          }
          
          if(response[0]=="middle_name_required"){ 
            document.getElementById("middlename").setAttribute('required', "")            
          }
          $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsWarning)
          vm.submitted = false    
        }      

        // Function for saving the DisCon
        vm.saveDisCon = () => {          
          if(vm.validateDisCon()){
            vm.submitted = true
            if(vm.currentMode == 'new') {
              let payload = prepareDisConPayload('new', JSON.parse(JSON.stringify(vm.currentDisCon)))              
              adminUserService.createDistributionContact(payload).then((response) => {

                if(!vm.addAnotherDisCon)
                  modalService.Close('DisConModal')

                vm.addAnotherDisCon = false
                vm.resetCurrentDisCon()
                vm.refreshScreen('DisCon')
                resetFormFieldClassList('DisConForm')
              })
            }
            else {
              let payload = prepareDisConPayload('edit', JSON.parse(JSON.stringify(vm.currentDisCon)))
              adminUserService.updateDistributionContact(payload).then((response) => {

                vm.refreshScreen('DisCon')
                modalService.Close('DisConModal')
                resetFormFieldClassList('DisConForm')
              })         
            }
          } else {
            $rootScope.$broadcast("CALLCONFIRMMODAL")
          }
        }

        vm.saveDisGrp = () => {
          if(validateFormFields('DisGrpform')){
            if(vm.validateGroupName()){
              vm.submitted = true
              if(vm.currentMode == 'new') {
                
                // Add group.

                let payload = prepareDisGrpPayload('new',JSON.parse(JSON.stringify(vm.currentDisGrp)))
          
                adminUserService.createDistributionGroup(payload).then((response) =>{

                  if(!vm.addAnotherDisGrp)
                    modalService.Close('DisGrpModal')
  
                  vm.addAnotherDisGrp = false
                  vm.resetCurrentDisGrp()
                  vm.refreshScreen('DisGrp')
                  resetFormFieldClassList('DisGrpForm')
                })
                
              } else {
                // Update group.
                let payload = prepareDisGrpPayload('edit',JSON.parse(JSON.stringify(vm.currentDisGrp)))
                adminUserService.updateDistributionGroup(payload).then((response) =>{

                  if(!vm.addAnotherDisGrp)
                    modalService.Close('DisGrpModal')
                  vm.addAnotherDisGrp = false
                  vm.resetCurrentDisGrp()
                  vm.refreshScreen('DisGrp')
                  resetFormFieldClassList('DisGrpForm')
                })
              }
            } else {
              toastr.error(translateTag(8586)) // "This group name already exists"              
            }
          }  else {
            $rootScope.$broadcast("CALLCONFIRMMODAL")
          }
        }

        function prepareDisGrpPayload(mode = "new", payload){
          let preparedPayload = {}
          let emails = []
          if(mode=='new'){

            preparedPayload.dig_id = null
            preparedPayload.dig_group_name = payload.dig_group_name
            payload.email.forEach((e) => {
               emails.push(e)
            })
            preparedPayload.email = emails
          } else {
            preparedPayload.dig_id = payload.dig_id
            preparedPayload.dig_group_name = payload.dig_group_name
            payload.email.forEach((e) => {
              emails.push(e)
            })
            preparedPayload.email = emails
          }
          return preparedPayload
        }

        //Fuction to prepare DisCon payload
        function prepareDisConPayload(mode='new', payload) {
          let preparedPayload = {}
          if(mode == 'edit')
          {
            preparedPayload.edl_id  = payload.edl_id
          }
          preparedPayload.edl_first_name = payload.edl_first_name
          preparedPayload.edl_last_name = payload.edl_last_name
          preparedPayload.edl_email = payload.edl_email.trim().toLowerCase()
          preparedPayload.edl_company_name = payload.edl_company_name

          return preparedPayload
        }

        
        // deleteGroupConfirmationModal
        vm.deleteGroupConfirmationModal = () => {
          vm.deleteGroupCount = vm.disGrpOptions.api.getSelectedRows().length

          vm.modalElementsDeleteGroup = {
            title: translateLabels(8618),  //"Delete Distribution Group?"
            message: `<div>${translateLabels(3581)} ${vm.deleteGroupCount} ${translateLabels(8435)}. ${translateLabels(8434)}</div>`,   //"You are about to delete""group(s)" "Undoing this will require IT support. Are you sure?"
            buttons: 
              `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" notes="YES">{{vm.componentTranslateLabels(1379)}}</button>
              <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" notes="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
          }
  

          document.getElementById('confirmcallingform').innerHTML = 'ADMINGROUPDELETECALLCONFIRMMODAL' 
          $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsDeleteGroup)
        }       
        
        $scope.$on("ADMINGROUPDELETECALLCONFIRMMODAL", (event,result) => {
          if(result=='button1') {
              vm.deleteDisGrp()
          }
      })

        

        //Function to open archive confirmation Modal
        vm.deleteConfirmationModal = () => {
          vm.deleteCount = vm.disConOptions.api.getSelectedRows().length
 
          vm.modalElementsDelete = {
            title: translateLabels(8433),  //"Delete Distribution Contact?"
            message:`<div>${translateLabels(3581)} ${vm.deleteCount} ${translateLabels(8436)}. ${translateLabels(8434)}</div>`,   //"You are about to delete " " contact(s). Undoing this will require IT support. Are you sure?"
            buttons: 
              `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" notes="YES">{{vm.componentTranslateLabels(1379)}}</button>
              <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" notes="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
          }

          document.getElementById('confirmcallingform').innerHTML = 'ADMINUSERDELETECALLCONFIRMMODAL' 
          $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsDelete)
        }
       
        $scope.$on("ADMINUSERDELETECALLCONFIRMMODAL", (event,result) => {
          if(result=='button1') {
              vm.deleteDisCon()
          }
      })

        //Function to delete a DisCon
        vm.deleteDisCon = () => {
          let rows = vm.disConOptions.api.getSelectedRows()
          if(rows.length > 0) {
            var ids = []
            for (var i = 0; i < rows.length; i++) {
                ids.push(rows[i].edl_id)                    
            }
            adminUserService.deleteDistributionContact(ids).then((r) => {              
              vm.refreshScreen('DisCon')
            })
          }
          modalService.Close('confirmModal')
        }

        vm.deleteDisGrp = () => {
          let rows = vm.disGrpOptions.api.getSelectedRows()
          if(rows.length > 0) {
            var ids = []
            for (var i = 0; i < rows.length; i++) {
                ids.push(rows[i].ID)                    
            }
            adminUserService.deleteDistributionGroup(ids).then((r) => {              
              vm.refreshScreen('DisGrp')
            })
          }
          modalService.Close('confirmModal')
        }

        // Function to get the provinces in the given country
        vm.getSelectedProvinces = (ctr) => {
            vm.selectedProvinces = []
            vm.provinces.forEach (prov => {
                if(ctr == prov.prv_ctr)
                    vm.selectedProvinces.push(prov)
            })
        }

        // Function to get the all provinces in the given countries
        vm.getCountryProvinces = () => {
            vm.countries.forEach(ctr => {
                adminUserService.getProvinces(ctr.ctr_id).then((prov)=>{
                    vm.provinces = vm.provinces.concat(prov)
                })
            })
        }

        //Function to validate password
        function validatePassword(formVal){
          formVal.setCustomValidity("")

          if(strongPassword && vm.password != "" && vm.password === vm.confirm_password){
            return true
          }

          formVal.setCustomValidity("Invalid Password")

          return false
        }

        // Function to validate email string
        validateEmail = (email) => {
          return String(email)
            .toLowerCase()
            .match(
              /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
            )
        }

        // Function to check if all modal feilds are valid
        vm.ValidateUser = (mode) => { 
          resetFormFieldClassList('AdminUserForm')
          let validated = validateFormFields('AdminUserForm')
          let formVal = document.forms['AdminUserForm']
          for (let a = 0; a < formVal.length; a++) {
            if(formVal[a].getAttribute('id') == 'email' ) {
              vm.emailList.forEach((u)=>{
                if(u.email != null && vm.currentUser.users[0].email != null && vm.currentUser.users[0].email != "") {
                  if(u.email === vm.currentUser.users[0].email && u.user_per_id != vm.currentUser.per_id){
                    formVal[a].setCustomValidity(translateTag(8587))   // 'Email Already In Use'                    
                    validated = false                    
                    toastr.options.timeOut = 5000                    
                    toastr.error(translateTag(8587));  // 'Email Already In Use'
                  }         
                }
              })
            }

            if(formVal[a].getAttribute('id') == 'userid'){
              formVal[a].setCustomValidity("")
              if(vm.currentUser.employees[0].emp_employee_number != null && vm.currentUser.employees[0].emp_employee_number != ''){
                vm.allEmployeeNumbers.forEach((u)=>{  
                  if(u.employee_number == vm.currentUser.employees[0].emp_employee_number && u.per_id !=vm.currentUser.per_id){
                    formVal[a].setCustomValidity(translateTag(8590))
                    validated = false
                    toastr.options.timeOut = 20000
                    toastr.error(translateTag(8590)) // 'Employee ID Already Exists'
                  }
                })
              }
              

            }

            if(formVal[a].getAttribute('id') == 'man_passwd_reset' || formVal[a].getAttribute('id') == 'man_conf_passwd_reset' || formVal[a].getAttribute('id') == 'man_passwd' || formVal[a].getAttribute('id') == 'man_conf_passwd')
              validatePassword(formVal[a])

            if(!formVal[a].validity.valid) {
              validated = false
            }
            
            if(vm.currentUser.users[0].email !== null && vm.currentUser.users[0].email !== ""){
              if(formVal[a].getAttribute('id') == 'email' && !validateEmail(vm.currentUser.users[0].email)) {
                formVal[a].setCustomValidity("Invalid Email")
                validated = false
              }
            }
          }
          return validated
        }

        // Fuction to check if all modal feilds are valid
        vm.validateDisCon = () => {
          let formVal = document.forms['DisConForm']
          
          // formVal.classList.add('was-validated')
          let validated = validateFormFields('DisConForm')

          for (let a = 0; a < formVal.length; a++) {            

            // validate if email is already in use by another user in distribution contacts or sofvie users
            if(formVal[a].name === 'emailaddress') {
              formVal[a].setCustomValidity("")

              // checking email in distribution contacts.. if exists it will return user object else undefined
              check_email_distribution_contacts = vm.disCon.find(d=>d.edl_email===vm.currentDisCon.edl_email && d.edl_id != vm.currentDisCon.edl_id)

              // checking email in sofvie users.. if exists it will return user object else undefined
              check_email_sofvie_users = vm.emailList.find(u=>u.email===vm.currentDisCon.edl_email)
              
              // if check_email_distribution_contacts is not undefined and check_email_sofvie_users is not undefined then email is in use, throw error.
              if(vm.currentMode=='new' && (check_email_distribution_contacts !== undefined || check_email_sofvie_users !== undefined)) {
                formVal[a].setCustomValidity("Email Already In Use")
                toastr.error(translateTag(8587)) // 'Email Already In Use'
                validated = false
              }
            }            
            if(!formVal[a].validity.valid) {
              validated = false
            }
          }
          return validated
        }
        
        vm.validateGroupName = () => {
          let rtrn = true
          let groupName = vm.currentDisGrp.dig_group_name
          vm.disGrp.forEach((rec) => {
            if(rec.dig_group_name == groupName && rec.dig_id != vm.currentDisGrp.dig_id) {              
              rtrn = false
              document.forms['DisGrpForm'].classList.remove('was-validated')
             }
          }) 
          return rtrn

        }

       // Function to prepare and return payload for NewUser
        vm.prepareNewUserObject = () => {
            if (!vm.currentUser.employees[0].emp_pos_id) {
                vm.currentUser.employees[0].emp_pos_id = 0
            }
            if (!vm.currentUser.per_dob) {
                vm.currentUser.per_dob = null
            }

            if (vm.emergencyContact_is_avail === true) {
                emergency_contact = vm.currentUser.emergency_contacts[0]
            } else {
                emergency_contact = null
            }

            //Get activation settings based on activation select.
            let settings = vm.prepareActivationSettings()

            data = {
                "per_first_name": vm.currentUser.per_first_name,
                "per_middle_name": vm.currentUser.per_middle_name ? vm.currentUser.per_middle_name : null,
                "per_last_name": vm.currentUser.per_last_name,
                "per_dob": vm.currentUser.per_dob,
                "per_sin": vm.currentUser.per_sin,
                "per_gender": vm.currentUser.per_gender,
                "per_enote": vm.currentUser.per_enote,
                "email": vm.currentUser.users[0].email !== null && vm.currentUser.users[0].email !== "" ? vm.currentUser.users[0].email.trim().toLowerCase() : null,
                "roles": vm.currentUser.users[0].roles,
                "is_active": settings.is_active,
                "ref_sites": vm.currentUser.employees[0].employee_sites,
                "ref_jobs": vm.currentUser.employees[0].employee_jobs,
                "activation_type": vm.activation_select,
                "per_enable": settings.per_enable,
                "password": vm.password,
                "confirm_password": vm.confirm_password,
                "emergency_contact": vm.currentUser.emergency_contacts[0],
                "employee": {
                    "emp_employee_number": vm.currentUser.employees[0].emp_employee_number,
                    "emp_pos_id": vm.currentUser.employees[0].emp_pos_id,
                    "emp_data_visibility": vm.currentUser.employees[0].emp_data_visibility,
                    "emp_enable": settings.emp_enable,
                },
                "address_phone": {
                    "pho_number": vm.currentUser.address_phone.pho_number,
                    "pho_pty_id": 1,
                },
                "address": {
                    "add_line_1": vm.currentUser.address.add_line_1,
                    "add_postal_code": vm.currentUser.address.add_postal_code,
                    "add_city": vm.currentUser.address.add_city ? vm.currentUser.address.add_city : null,
                    "prv_id": vm.currentUser.address.add_prv,
                    "ctr_id": vm.currentUser.address.add_ctr,
                    "aty_id": vm.currentUser.address.add_aty,
                },
                "user_profile": {
                    "upr_language": vm.currentUser.upr_per_id[0].upr_language,
                },
            }
            return data
        }

        vm.prepareActivationSettings = () => {
          let settings= {}

          if(vm.activation_select === 'manual'){
            settings.emp_enable = true
            settings.is_active = true
            settings.per_enable = true
          }


          //email activation
          if(vm.activation_select ==='email'){
            settings.emp_enable = true
            settings.is_active = false
            settings.per_enable = false
          }

          //activate later
          if(vm.activation_select === 'later'){
            settings.emp_enable = true
            settings.is_active = false
            settings.per_enable = false
          }  
          return settings
        }

        vm.resetPasswordCheck = () =>{
          if(vm.resetPasswordChkBox === false){
            vm.resetPasswordField()
          }
        }

        vm.resetPasswordField = () =>{          
          vm.password = null
          vm.confirm_password = null
          vm.is_email_mandatory = vm.currentMode === "new" ? vm.activation_select !== "later" ? true : false : vm.is_email_mandatory
        }

        
        // Function to prepare and return payload for UpdateUser
        vm.prepareUpdateUserObject = () => {
            if(vm.currentUser.employees[0].emp_pos_id === null) {
                vm.currentUser.employees[0].emp_pos_id = 0
            }
            if(!vm.currentUser.per_dob) {
                vm.currentUser.per_dob = null
            }

            if(vm.emergencyContact_is_avail===true) {
                emergency_contact = vm.currentUser.emergency_contacts[0]
            } else {
                emergency_contact = null
            }
            
            data = {
                "per_id": vm.currentUser.per_id,
                "per_first_name": vm.currentUser.per_first_name,
                "per_middle_name": vm.currentUser.per_middle_name ? vm.currentUser.per_middle_name : null,
                "per_last_name": vm.currentUser.per_last_name,
                "per_dob": vm.currentUser.per_dob,
                "per_sin": 12345,
                "per_gender": vm.currentUser.per_gender,
                "per_enote": vm.currentUser.per_enote,
                "per_enable": vm.currentUser.users[0].is_active,
                "user": {
                    "id": vm.currentUser.users[0].id,
                    "email": vm.currentUser.users[0].email !== null && vm.currentUser.users[0].email !== "" ? vm.currentUser.users[0].email.trim().toLowerCase() : null,
                    "roles": vm.currentUser.users[0].roles,
                    "is_active": vm.currentUser.users[0].is_active,
                    "activate": vm.currentUser.users[0].is_active,
                    "activation_type": vm.resetPasswordChkBox ? vm.resetPassword : vm.activation_select,
                    "reset_password": vm.resetPasswordChkBox,
                    "password": vm.password,
                    "confirm_password": vm.confirm_password,
                },
                "employee": {
                    "emp_id": vm.currentUser.employees[0].emp_id,
                    "emp_pos_id": vm.currentUser.employees[0].emp_pos_id,
                    "emp_enable": vm.currentUser.users[0].is_active ? true : vm.currentUser.employees[0].emp_enable,
                    "emp_employee_number": vm.currentUser.employees[0].emp_employee_number,
                    "employee_sites": vm.currentUser.employees[0].employee_sites,
                    "employee_jobs": vm.currentUser.employees[0].employee_jobs,
                    "emp_data_visibility": vm.currentUser.employees[0].emp_data_visibility,
                },
                "emergency_contact": emergency_contact,
                "address_phone": {
                    "pho_id": vm.currentUser.address_phone.pho_id,
                    "pho_number": vm.currentUser.address_phone.pho_number ? vm.currentUser.address_phone.pho_number : " ",
                    "pho_pty__pty_code": null,
                    "pho_pty_id": 1,
                    "pho_pty__pty_description": "Home",
                },
                "address": {
                    "add_id": vm.currentUser.address.add_id,
                    "add_line_1": vm.currentUser.address.add_line_1,
                    "add_postal_code": vm.currentUser.address.add_postal_code,
                    "add_city": vm.currentUser.address.add_city ? vm.currentUser.address.add_city : null,
                    "prv_id": vm.currentUser.address.add_prv,
                    "ctr_id": vm.currentUser.address.add_ctr,
                    "aty_id": 1,
                },
                "user_profile": {
                    "upr_language": vm.currentUser.upr_per_id[0].upr_language,
                },
            }
            return data
        }


        vm.userCheck = () => {
            // when the user check box is checked, check the employee check box.
            if(vm.currentUser.users[0].is_active) {
              vm.is_email_mandatory = true
              vm.currentUser.employees[0].emp_enable = true
            } else {
              vm.is_email_mandatory = vm.currentMode !== 'new' ? (!vm.currentUser.users[0].is_active && vm.isSelectedCurrentUserEmailEmpty === true) ? false : true : vm.is_email_mandatory
            }
            vm.showReset()
            vm.resetPasswordField()
        }

        // Main function for retrieving data and populating the Main Training Grid
        vm.refreshScreen = (mode='All') => {

            $scope.$emit('STARTSPINNER', vm.loadMessage)
            let services = []
            if(mode == 'All')
            {
                services = [
                    adminUserService.getUsers({status: vm.statusFilter}),
                    adminUserService.getRoles(),
                    adminUserService.getPositions(selectedLanguage),
                    adminUserService.getCountries(),
                    adminUserService.getSites(selectedLanguage),
                    adminUserService.getJobs(selectedLanguage),
                    profileService.getAllEmployeeProfile(),
                    profileService.getFullEmployeeProfile(),
                    adminUserService.getDistributionContacts(),
                    adminUserService.getDistributionGroups(),
                    profileService.getDistributionList(),
                    i18nService.getLanguages(),
                    adminUserService.getEmailList(),
                ]
            }
            else if(mode == 'User'){
                services = [
                    adminUserService.getUsers({status: vm.statusFilter}),
                    adminUserService.getRoles(),
                    adminUserService.getPositions(selectedLanguage),
                    adminUserService.getCountries(),
                    adminUserService.getSites(selectedLanguage),
                    adminUserService.getJobs(selectedLanguage),
                    profileService.getAllEmployeeProfile(),
                    adminUserService.getEmailList()
                    
                ]
                vm.dataVisibilityOptions.api.deselectAll()
            }
            else if(mode == 'DisCon'){
                services = [
                    adminUserService.getDistributionContacts(),
                    adminUserService.getEmailList(),
                    profileService.getDistributionList(),
                    adminUserService.getDistributionGroups()
                ]
            } else if(mode== 'DisGrp'){
                services = [
                  adminUserService.getDistributionGroups(),
                  profileService.getDistributionList()
                ]
            }

            services.push(adminUserService.getAllEmployeeNumbers())

            $q.all(services).then(() => {
                vm.users = adminUserService.getUserList()
                fixUsers(vm.users)
                vm.disCon = adminUserService.getDisConList()
                vm.disGrp = adminUserService.getDisGrpList()
                vm.distributionList = profileService.readDistributionList()
                vm.sites = adminUserService.getSiteList()
                vm.jobs = adminUserService.getJobList()
                vm.roles = adminUserService.getRoleList()
                vm.positions = adminUserService.getPositionList()
                vm.languageList = i18nService.readLanguageList().languages
                vm.countries = adminUserService.getCountryList()
                vm.getCountryProvinces()
                vm.fullEmployeeList = profileService.readFullEmployeeProfile()
                vm.employeeList = profileService.readAllEmployeeProfile()                
                vm.usersLoaded = true
                vm.actionUserDisabled = true
                vm.actionDisConDisabled = true
                vm.actionDisGrpDisabled = true
                vm.emailList = adminUserService.readEmailList()
                vm.allEmployeeNumbers = adminUserService.readAllEmployeeNumbers()
            }).then (() =>  {
                setTimeout(()=>{
                    vm.resetGrid(vm.users)
                    $scope.$emit('STOPSPINNER')
                    translateAgGridHeader(vm.disConOptions)
                    translateAgGridHeader(vm.userOptions)
                    translateAgGridHeader(vm.disGrpOptions)
                },500)
            })
        }
        // Initial Refresh of Screen
        vm.refreshScreen('All')
        vm.resetTriggers()

        function fixUsers(users) {
            users.forEach((user)=>{
              if(user.users.length < 1){
                user.users.push({
                  email: "",
                  id: null,
                  is_active: false,
                  roles: [1],
                })
              }
              if(!('pho_id' in user.address_phone)) {
                user.address_phone.pho_id = null
              }

            })

        }

        // Function to reset Ag-Grids
        vm.resetGrid = () =>{
          let modelUser = vm.userOptions.api.getFilterModel()
          vm.userOptions.paginationPageSize = 10
          vm.userOptions.api.setRowData(prepareUsersGridData(vm.users))
          vm.userOptions.api.redrawRows()
          vm.userOptions.api.sizeColumnsToFit()
          vm.userOptions.api.setFilterModel(modelUser)

          let modelDisCon = vm.disConOptions.api.getFilterModel()
          vm.disConOptions.paginationPageSize = 10
          vm.disConOptions.api.setRowData(prepareDisConGridData())
          vm.disConOptions.api.redrawRows()
          vm.disConOptions.api.sizeColumnsToFit()
          vm.disConOptions.api.setFilterModel(modelDisCon)
        
          let modelDisGrp = vm.disGrpOptions.api.getFilterModel()
          vm.disGrpOptions.paginationPageSize = 10
          vm.disGrpOptions.api.setRowData(prepareDisGrpGridData())
          vm.disGrpOptions.api.redrawRows()
          vm.disGrpOptions.api.sizeColumnsToFit()
          vm.disGrpOptions.api.setFilterModel(modelDisGrp)        
        }

        function getUserAccountStatus(account){
          let acc_status
          let emp_acc = account.employees[0].emp_enable
          let user_is_active = account.users[0].is_active
          if(user_is_active){
            acc_status = 3885 // Active
          }else if(emp_acc && !user_is_active){
            acc_status = 190 // Employee
          }else{
            acc_status = 3793 // Inactive
          }
          return acc_status
        }

        //Function to prepare Ag-Grid data with nice values
        function prepareUsersGridData(data=vm.users) {
          let userGridData = JSON.parse(JSON.stringify(data))
          userGridData.forEach((rec) => {
            rec.exceptionFields = ['upr_per_id','per_dob', 'per_enote', 'per_sin', 'address_phone', 'employees', 'address', 'users', 'per_id', 'per_gender', 'emergency_contacts', 'per_modified_by_per_id','tippy_Language']
            rec.per_modified_date = rec.per_modified_date == null ? '' : moment(rec.per_modified_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
            
            rec.ID = rec.per_id
            rec.employee_ID = null
            rec.tippy_position = null
            let siteList = ''
            let jobList = ''
            if('employees' in rec && rec.employees.length>0){
              rec.employee_ID = rec.employees[0].emp_employee_number
              rec.tippy_position  = getPositionName(rec.employees[0].emp_pos_id)
              rec.employees[0].employee_sites.forEach((s) => {
                siteList += `${getSiteName(s)}, `
              })
              siteList = siteList.slice(0, -2)
              rec.tippy_sites = siteList
              rec.employees[0].employee_jobs.forEach((j) => {
                jobList += `${getJobName(j)}, `
              })
              jobList = jobList.slice(0, -2)
              rec.tippy_jobs = jobList
            }
              
            rec.tippy_address = `${rec.address.add_line_1 === null ? '':rec.address.add_line_1+', '}
            ${rec.address.add_city == null ? '':rec.address.add_city+', '}
            ${getProvinceName(rec.address.add_prv) == null ? '':getProvinceName(rec.address.add_prv)+', '}
            ${getCountryName(rec.address.add_ctr) == null ? '':getCountryName(rec.address.add_ctr)}`
            rec.tippy_postal_code = rec.address.add_postal_code
            rec.tippy_email = rec.users[0].email
            if(rec.address_phone.pho_number === ' '){
              rec.address_phone.pho_number = null
            }
            rec.tippy_phone_number = rec.address_phone.pho_number
            rec.tippy_date_of_birth = rec.per_dob
            rec.tippy_per_gender = translateTag(rec.per_gender)
            let roleList = ''
            rec.last_login = rec.users[0].last_login ? moment(rec.users[0].last_login, 'YYYY-MM-DDTHH:mm:ss').format('YYYY-MM-DD HH:mm:ss'): null
            rec.users[0].roles.forEach((r) => {
              roleList += `${getRoleName(r)}, `
            })
            roleList = roleList.slice(0, -2)
            rec.tippy_roles = roleList

            let userLanguage = ''
            vm.languageList.forEach((lang) => {

              if(rec.upr_per_id[0] != undefined && lang.lng_name == rec.upr_per_id[0].upr_language) {

                userLanguage = lang.lng_description_text
              }
            })           
            rec.tippy_Language = userLanguage 
          })

          vm.user_list_data =JSON.parse(JSON.stringify(userGridData))
          return userGridData
        }

        //Function to prepare Ag-Grid data with nice values
        function prepareDisConGridData() {
          let disConGridData = JSON.parse(JSON.stringify(vm.disCon))
          disConGridData.forEach((rec) =>{
            rec.exceptionFields = ['per_enote', 'edl_enable']
            rec.prefix = 'edl_'
            rec.endfix = ['_per_id']
            rec.edl_modified_by_per_id = getEmployeeName(rec.edl_modified_by_per_id)
            rec.edl_created_by_per_id = getEmployeeName(rec.edl_created_by_per_id)
            rec.edl_created_date = moment(rec.edl_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
            rec.edl_modified_date = rec.edl_modified_date == null ? '' : moment(rec.edl_modified_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
          })
          return disConGridData
        }

        function prepareDisGrpGridData(){
          let dg = JSON.parse(JSON.stringify(vm.disGrp))
          let res = []
          dg.forEach((rec) => {
            let grpData = {
              ID : rec.dig_id,
              Group_Name : rec.dig_group_name,
              Email : getEmails(rec.email),
              Modified_By : getEmployeeName(rec.dig_modified_by_per_id),
              Date_Last_Modified : rec.dig_modified_date == null ? '' : moment(rec.dig_modified_date, 'YYYY-MM-DD').format('YYYY-MM-DD')  
            }
            res.push(grpData)
          })
          return res
        }

        function getEmails(rec){
          let emails = ''
          rec.forEach((em) => {
            emails = emails + em + ", "
          })
          if(emails.length >= 2){
            emails = emails.substring(0, emails.length -2)
          }
          return emails
        }
        //Function to convert employee ID to Name
        function getEmployeeName(value) {
          let name = value
          vm.fullEmployeeList.forEach((emp)=>{
            if(emp.per_id == value) {
              name = emp.per_full_name
            }
          })
          return name
        }

        //Function to convert eployee Name to ID
        function getEmployeeID(value) {
          let nameId = value
          vm.fullEmployeeList .forEach((emp)=>{
            if(emp.per_full_name == value) {
              nameId = emp.per_id
            }
          })
          return nameId
        }

        //Function to convert country ID to Name
        function getCountryName(value) {
          let name = value
          vm.countries.forEach((c)=>{
            if(c.ctr_id == value) {
              name = c.ctr_description
            }
          })
          return name
        }

        //Function to convert province ID to Name
        function getProvinceName(value) {
          let name = value
          vm.provinces.forEach((p)=>{
            if(p.prv_id == value) {
              name = p.prv_description
            }
          })
          return name
        }

        //Function to convert Job ID to Name
        function getJobName(value) {
          let name = value
          vm.jobs.forEach((job)=>{
            if(job.rld_id == value) {
              name = job.rld_name
            }
          })
          return name
        }

        //Function to convert Site ID to Name
        function getSiteName(value) {
          let name = value
          vm.sites.forEach((site)=>{
            if(site.rld_id == value) {
              name = site.rld_name
            }
          })
          return name
        }

        //Function to convert Role ID to Name
        function getRoleName(value) {
          let name = value
          vm.roles.forEach((role)=>{
            if(role.aro_id == value) {
              name = role.aro_name_trans
            }
          })
          return name
        }

        //Function to convert Position ID to Name
        function getPositionName(value) {
          let name = value
        
          vm.positions.forEach((pos)=>{
          
            if(pos.rld_id == value) {
              name = pos.rld_name              
             
            }
          })
          return name
        }

        //Update Ag-Grid size when window is resized
        $(window).on('resize', function () {
          $timeout(function () {
            if(vm.userOptions.api)
              vm.userOptions.api.sizeColumnsToFit()
            if(vm.disConOptions.api)
              vm.disConOptions.api.sizeColumnsToFit()
            if(vm.disGrpOptions.api)  
              vm.disGrpOptions.api.sizeColumnsToFit()
          })
        })

        $scope.$on('distribution-list-added', (event, args) => {
          if(vm.currentDisGrp !== undefined)
            $scope.$emit('addDistributionGroup', args, vm.currentDisGrp.email)
        })
  
        $scope.$on('distribution-list-removed', (event, args) => {
          $scope.$emit('removeDistributionGroup', args)
        })

        //END
    }
])

