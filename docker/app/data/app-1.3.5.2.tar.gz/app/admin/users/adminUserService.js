angular
  .module('safeToDo')
  .service('adminUserService', ['$http', '$location','$window',
    function ($http, $location, $window) {

        let users= []
        let roles= []
        let positions = []
        let countries = []
        let provinces = []
        let sites = []
        let jobs = []
        let disConList = []
        let disGroupList = []
        let emailList = []

        let allEmployeeNumbers = []

    return {
        getEmailList: () => {
            return $http.get(`${__env.apiUrl}/api/user/get-email-list/`).then((response) =>{    
                emailList = response.data.emails_list            
            }, (errParams) => {                
                console.log(errParams)
                return errParams;
            })
        },
        getUsers: (payload) => {
            return $http.post(`${__env.apiUrl}/api/person/persons/`, payload).then((response) =>{
                
                users = response.data
                
            }, (errParams) => {
                var errorObj = {};
                if (errParams.status == 404) {
                    errorObj.error = translateTag(8597) //'Users not found - Contact a system administrator';
                }
                else if(errParams.status === 403 && errParams.data.detail){
                    toastr.error(errParams.data.detail)
                    users = []
                    window.location.href = "/"
                }
                return errorObj;
            })
        },
        getRoles: () => {
            return $http.get(`${__env.apiUrl}/api/sofvie-auth/get-role-list/active/`).then((response) =>{
                roles = response.data
            }, (errParams) => {
                var errorObj = {};
                if (errParams.status == 404) {
                    errorObj.error = translateTag(8597) //'Users not found - Contact a system administrator';
                }
                else if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                }
                return errorObj;
            })
        },
        getPositions: (lang) => {
            return $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`,{ "validatorStr": "ref_position", "language": lang }).then((response) =>{
                positions = response.data
            }, (errorParams) => {
                var errorObj = {};
                if (errorParams.status == 404) {
                    errorObj.error = translateTag(8598) //'Positions not found - Contact a system administrator';
                }
                else if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                }
                return errorObj;
            })
        },
        getCountries: () => {
            return $http.get(`${__env.apiUrl}/api/address/countries/`).then((response) =>{
                countries = response.data
            }, (errParams) => {
                var errorObj = {};
                if (errParams.status == 404) {
                    errorObj.error = translateTag(8599) //'Countries not found - Contact a system administrator';
                }
                else if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                }
                return errorObj;
            })
        },
        getProvinces: (prov) => {
            return $http.get(`${__env.apiUrl}/api/address/provinces?prv_ctr=${prov}`).then((response) =>{
                return response.data
            }, (errParams) => {
                var errorObj = {};
                if (errParams.status == 404) {
                    errorObj.error = translateTag(8599) //'Countries not found - Contact a system administrator';
                }
                else if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                }
                return errorObj;
            })
        },
        getSites: (lang) => {
            return $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`,{ "validatorStr": "ref_site", "language" : lang  }).then((response) =>{
                sites = response.data
            }, (errParams) => {
                var errorObj = {};
                if (errParams.status == 404) {
                    errorObj.error = translateTag(8600) //'Sites not found - Contact a system administrator';
                }
                else if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                }
                return errorObj;
            })
        },    
        getJobs: (lang) => {
            return $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`,{ "validatorStr": "ref_job", "language" : lang  }).then((response) =>{
                jobs = response.data
            }, (errParams) => {
                var errorObj = {};
                if (errParams.status == 404) {
                    errorObj.error = translateTag(8601) //'Jobs not found - Contact a system administrator';
                }
                else if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                }
                return errorObj;
            })
        },
        getSitesJobsByUser: (emp_id) => {
            let payload = {"emp_id": emp_id}
            // console.log('payload ---- ', payload)
            return $http.post(`${__env.apiUrl}/api/employee/get-custom-site-job-per-user/`, payload).then((response) => {
                return response.data
            }, (args) => {
                    console.log('Failed to load get-custom-site-job-per-user ', args)
            })
        },
        getDistributionContacts: () => {
            return $http.get(`${__env.apiUrl}/api/edl/get-external-contact-list/`).then((response) =>{
                disConList = response.data
            }, (errParams) => {
                var errorObj = {};
                if (errParams.status == 404) {
                    errorObj.error = translateTag(8602) //'Distribution Contacts not found - Contact a system administrator';
                }
                else if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                    disConList = []          
                    window.location.href = "/"  
                }
                return errorObj;
            })
        },
        createUpdateUserSiteJob: (emp_id, payload) => {
            // console.log("This is the createUpdateUserSiteJobpayload", JSON.stringify(payload))
            return $http.post(`${__env.apiUrl}/api/employee/create-or-update-custom-site-job-per-user/`+emp_id+`/`, payload).then((response) => {
                return response.data
            }, (errorParams) => {
                console.log('Failed to create create Update User Custom Site and Job Contact', errorParams)
                if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                }
            })
        },
        createDistributionContact: (payload) => {            
            return $http.post(`${__env.apiUrl}/api/edl/create-external-contact/`, payload).then((response) => {
                return response.data
            }, (errorParams) => {
                console.log('Failed to create Distribution Contact', errorParams)
                if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                }
            })
        },
        updateDistributionContact: (payload) => {            
            return $http.post(`${__env.apiUrl}/api/edl/update-external-contact/`, payload).then((response) => {
                return response.data
            }, (errorParams) => {
                console.log('Failed to update Distribution Contact', errorParams)
                if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                }
            })
        },
        deleteDistributionContact: (IdList) => {
            var patchList = []
            for (var i = 0; i < IdList.length; i++) {
                patchList.push({ edl_id: IdList[i]})
            }            
            return $http.post(`${__env.apiUrl}/api/edl/delete-external-contact/`, patchList).then((response) => {
                return response.data
            }, (errorParams) => {
                console.log('Failed to delete Distribution Contact', errorParams)
                if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                }
            })
        },
        getDistributionGroups:() => {
            return $http.get(`${__env.apiUrl}/api/distribution-group/get-all-distribution-group/`).then((response) =>{
                disGroupList = response.data
            }, (errParams) => {
                var errorObj = {};
                if (errParams.status == 404) {
                    errorObj.error = translateTag(8596) //'Distribution Groups not found - Contact a system administrator';
                }
                else if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                    disGroupList = []          
                    window.location.href = "/"  
                }
                return errorObj;
            })
        },
        createDistributionGroup: (payload) => {
            console.log("This is the create Distribution group payload", JSON.stringify(payload))
            return $http.post(`${__env.apiUrl}/api/distribution-group/create-distribution-group/`, payload).then((response) => {
                return response.data
            }, (errorParams) => {
                console.log('Failed to create Distribution Group', errorParams)
                if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                }
            })
        },
        updateDistributionGroup: (payload) => {
            return $http.post(`${__env.apiUrl}/api/distribution-group/update-distribution-group/`, payload).then((response) => {
                return response.data
            }, (errorParams) => {
                console.log('Failed to update Distribution Group', errorParams)
                if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                }
            })
        },
        deleteDistributionGroup: (IdList) => {
            var patchList
            patchList = {
                dig_id : IdList
            }
            return $http.post(`${__env.apiUrl}/api/distribution-group/delete-distribution-group/`, patchList).then((response) => {
                return response.data
            }, (errorParams) => {
                console.log('Failed to delete Distribution Contact', errorParams)
                if(errorParams.status === 403 && errorParams.data.detail){
                    toastr.error(errorParams.data.detail)
                }
            })
        },

        getCheckUserDeactivation: (per_id) => {
            let payload = {"per_id": per_id}
            return $http.post(`${__env.apiUrl}/api/user/get-check-user-for-deactivation/`, payload).then((response) => {
                return response.data
            }, (args) => {
                    console.log('Failed to load get-Check-User-Deactivation', args)
            })
        },

        getAllEmployeeNumbers: () => {
            return $http.get(`${__env.apiUrl}/api/user/get-all-employee-numbers/`,).then((response) => {
                allEmployeeNumbers = response.data
            }, (args) => {
                console.log("Failed to get employee numbers", args)
            })
        },

        
        // Functions to return data from the Ajax calls

        getUserList: () => {            
           return users;
        },
        getRoleList: () => {
            return roles;
        },  
        getPositionList: () => {
            return positions;
        },    
        getCountryList: () => {
            return countries;
        },    
        getProvinceList: () => {
            return provinces;
        }, 
        getSiteList: () => {
            return sites;
        },     
        getJobList: () => {
            return jobs;
        },
        getDisConList: () => {
            return disConList;
         },  
        getDisGrpList: () => {
            return disGroupList;
        },
        readEmailList: () => {
            return emailList
        },       
        readAllEmployeeNumbers: () => {
            return allEmployeeNumbers
        }

       };
    }
  ]);