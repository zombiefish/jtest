﻿angular
    .module('safeToDo')
    .controller('AdminListCtrl', ['$scope','$rootScope', '$timeout', '$q', '$window', '$compile', 'gridService', 'modalService', 'adminListService', '$filter', 'i18nService', 'menuService', 'exportCSV',
    function ($scope,$rootScope, $timeout, $q, $window, $compile, gridService, modalService, adminListService, $filter, i18nService, menuService, exportCSV) {
        let vm = this
        vm.currentList = {}
        vm.currentListItems = []
        vm.topSearch = ''
        vm.mainTopSearch = ''
        vm.customListTopSearch = ''
        vm.listSearch = ''
        vm.currentMultiList={}
        vm.parentSiteLabel = ''
        vm.listOptions = gridService.getCommonOptions()
        vm.customListOptions = gridService.getCommonOptions()
        vm.list = []
        vm.customLists = []
        vm.selectedSite = null
        vm.actionDisabled = true
        vm.customListActionDisabled = true
        vm.loadMessage = translateTag(8478) //Loading reference lists. Please wait.

        vm.isMultiList = false
        vm.currentItem = {}
        vm.infoEdited = false
        vm.itemChanged = false

        vm.listViewerOpen = false
        vm.hideingListViewer = false
        vm.openingListViewer = false
        vm.showWarnningMessage = false
        vm.hidedeleteicon = true
        vm.selected_display_name = ''
        vm.archiveEmployeeOptions = gridService.getCommonOptions()
        vm.header_list_object = {}
        vm.listMode = ''

        let deleteIds = []
        let deleteItemId = null

        menuService.getPagePermissions().then((data) => {
          vm.permissions = data

          vm.canManageCustomLists = vm.permissions.includes('Can Manage Custom Lists') ? true : false
          vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
        })
        
        //Function for the top search bar
        vm.mainTopSearchChanged = () => {
          vm.listOptions.api.setQuickFilter(vm.mainTopSearch);
        }
        vm.customListTopSearchChanged = () => {
          vm.customListOptions.api.setQuickFilter(vm.customListTopSearch);
        }
        
        //Function to disable actions button
        vm.listOptions.onSelectionChanged = () => {          
          var selectedRows = vm.listOptions.api.getSelectedRows()
          vm.actionDisabled = selectedRows.length == 0
          $scope.$apply()
        }

        vm.customListOptions.onSelectionChanged = () => {          
          var selectedRows = vm.customListOptions.api.getSelectedRows()
          vm.customListActionDisabled = selectedRows.length == 0
          $scope.$apply()
        }

        function resetCurrentSingleItem()
        {
          if(vm.listMode == 'ref') {
            vm.currentItem = {
              rld_rlh_id: null,
              rld_score: null,
              rld_code: null,
              rld_name: null,
              rld_description: null,
              rld_enable: 1,
              rld_is_active: 1,
              rld_parent_detail_rld_id: null,
              rld_created_by_per_id: null,
              rld_modified_by_per_id: null,
              rld_names: [],
              rld_descriptions: []
            }
          } else {
            vm.currentItem = {
              cld_clh_id: null,
              cld_id: null,
              cld_names: [],
            }
          }
          if (vm.currentList.rlh_name == 'ref_drilling_time_and_delays_code') {
            vm.currentItem['rld_total_hours_drilled'] = 0
          }
          if (vm.currentList.rlh_name == 'ref_drilling_code') {
            vm.currentItem['rld_drilling_code_value'] = 'na'
          }    
        }        

        function resetCurrentMultiItem()
        {
          vm.currentItem = {
            rld_rlh_id: null,
            rld_score: null,
            rld_code: null,
            rld_name: null,
            rld_description: null,
            rld_enable: 1,
            rld_is_active: 1,
            rld_parent_detail_rld_id: null,
            rld_created_by_per_id: null,
            rld_modified_by_per_id: null,
            rld_names: [],
            rld_descriptions: []
          }
        }
        

        // function that is run when a change detected when searching in employee
        vm.topSearchEmployeeChanged = () => {
          vm.archiveEmployeeOptions.api.setQuickFilter(vm.topSearchEmployee)
        }

        let employeeListColumns = [
          {
            field: "name",
            headerName: " ",
            minWidth: 500,
            maxWidth: 1000,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            
          }
        ]
        vm.archiveEmployeeOptions.columnDefs = employeeListColumns

        //#region Translations
        vm.currentTranslationMode = 'new'
        vm.currentTranslationList = []
        vm.systemLanguages = []

        vm.selectedLanguageID = 1
        vm.defaultLanguageID = 1

        vm.getCurrentTranslationList = (data) => {
            var currentTranList = []
            for(var lang in vm.systemLanguages)
            {
                lang = vm.systemLanguages[lang]
                if(!lang.lng_selected)
                    continue

                var tranObj = {
                    ltr_lng_id: lang.lng_id,
                    ltr_lng_name: lang.lng_name.toUpperCase(),
                    ltr_lng_description: lang.lng_description_text,                        
                    ltr_lng_default: lang.lng_default ? "*" : "",
                    ltr_text: new Array(data.length).fill(""),
                    ltr_translated:  new Array(data.length).fill(false)
                }
                
                for(var tranList in data)
                {
                    var tranIndex = tranList
                    tranList = data[tranList]
                    for (var tran in tranList)
                    {                        
                        tran = tranList[tran]
                        if(tran.ltr_lng_id == lang.lng_id)
                        {
                            tranObj.ltr_text[tranIndex] = tran.ltr_translated ? tran.ltr_text : ""
                            tranObj.ltr_translated[tranIndex] = tran.ltr_translated
                        }
                    }
                }

                currentTranList.push(tranObj)
            }

            return currentTranList
        }

        vm.getDisplayTranslation = (key, list) => {
            if(!list)
                return

            let defaultLanguageText = ""
            for(var tran in list[key])
            {
                tran = list[key][tran]                
                if(tran.ltr_lng_id == vm.defaultLanguageID)
                    defaultLanguageText = tran.ltr_text
                if(tran.ltr_lng_id == vm.selectedLanguageID && tran.ltr_text.trim() != "")
                    return tran.ltr_text
            }
            return defaultLanguageText
        }

        function getDefaultTranslation (key, list) {
            if(!list)
                return

            let defaultLanguageText = ""
            for(var tran in list[key])
            {
                tran = list[key][tran]                
                if(tran.ltr_lng_id == vm.defaultLanguageID)
                    defaultLanguageText = tran.ltr_text
            }
            return defaultLanguageText
        }

        function getSelectedLanguageID (name)
        {
            for(var lang in vm.systemLanguages)
            {
                lang = vm.systemLanguages[lang]
                if(lang.lng_name.toLowerCase() === name.toLowerCase())
                    return lang.lng_id
            }
            return 1
        }

        function getDefaultLanguageID ()
        {
            for(var lang in vm.systemLanguages)
            {
                lang = vm.systemLanguages[lang]
                if(lang.lng_default)
                    return lang.lng_id
            }
            return 1
        }
        //#endregion

        //Set Ag-Grid colum values/settings
        let listColumns = [
            {
              headerName: '',
              field: 'dummyCheckbox',
              maxWidth: 50,
              minWidth: 50,
              checkboxSelection: true,
              suppressMenu: true,
              suppressSorting: true,
              headerCheckboxSelection: true,
              headerCheckboxSelectionFilteredOnly: true,
            },
            {
              field: 'rlh_id',
              hide: true,
            },
            {
                field: "review", 
                headerName: " ",  
                minWidth: 60,
                maxWidth: 60,
                suppressMenu: true,
                suppressSorting: true,
                cellRenderer: function (params) {
                    return `<div class="pointer text-left" ng-click="admlist.openListViewer(${params.data.rlh_id})"><i class="fa fa-pen" note="Edit" title="{{menu.translateLabels(1194)}}"></i></div>`
                }
            },
            {
              field: "rlh_display_name", 
              headerName: " ",
              minWidth: 200, 
              maxWidth: 300,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              sort: 'asc',
              cellRenderer: "tippyCellRenderer",
              valueGetter: function (params) {
                return vm.getDisplayTranslation('rlh_display_names', params.data)
              },
            },
            {
              field: "rlh_description",
              headerName: " ",
              minWidth: 200,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: "tippyCellRenderer",
              valueGetter: function (params) {
                return vm.getDisplayTranslation('rlh_descriptions', params.data)
              },
            },
            {
              field: "rlh_rlt",
              headerName: " ",
              minWidth: 100,
              maxWidth: 100,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: "tippyCellRenderer"
            },
            {
              field: "dateLastModified",
              headerName: " ",
              minWidth: 160,
              maxWidth: 160,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              valueGetter: function (params) {
                return params.data.rlh_modified_date ? params.data.rlh_modified_date.substring(0,10) : ''
              },
            },
            {
              field: "modified_by",
              headerName: " ",
              minWidth: 150,
              maxWidth: 200,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
            },
            {
              field: "type",
              hide: true
            },
            {
              field: "mode",
              hide: true
            },
            {
              field: "fields",
              hide: true
            },
            {
              field: "id",
              hide: true
            }
        ]
        vm.listOptions.columnDefs = listColumns

        let customListColumns = [
          {
            headerName: '',
            field: 'dummyCheckbox',
            maxWidth: 50,
            minWidth: 50,
            checkboxSelection: true,
            suppressMenu: true,
            suppressSorting: true,
            headerCheckboxSelection: true,
            headerCheckboxSelectionFilteredOnly: true,
          },
          {
            field: 'clh_id',
            hide: true,
          },
          {
              field: "review", 
              headerName: " ",  
              minWidth: 60,
              maxWidth: 60,
              suppressMenu: true,
              suppressSorting: true,
              cellRenderer: function (params) {
                  return `<div ng-class="{ transparent: !admlist.canManageCustomLists, pointer: admlist.canManageCustomLists}" class="text-left" ng-click="admlist.openCustomListViewer(${params.data.clh_id})"><i class="fa fa-pen" note="Edit" title="{{menu.translateLabels(1194)}}"></i></div>`
              }
          },
          {
            field: "clh_display_name", 
            headerName: " ",
            minWidth: 200, 
            maxWidth: 300,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            sort: 'asc',
            cellRenderer: "tippyCellRenderer",
          },
          {
            field: "clh_description",
            headerName: " ",
            minWidth: 200,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: "tippyCellRenderer",
          },
          {
            field: "clh_modified_date",
            headerName: " ",
            minWidth: 160,
            maxWidth: 160,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
          },
          {
            field: "clh_modified_by_per",
            headerName: " ",
            minWidth: 150,
            maxWidth: 200,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
          },
      ]
      vm.customListOptions.columnDefs = customListColumns   

        //Function to export csv
        vm.exportCSV = () => {
          let rows = vm.listOptions.api.getSelectedRows()
          let promises = []
          for (list of rows) {
            promises.push(adminListService.getReferenceList(list.rlh_name))
          }
          
          Promise.all(promises).then(results => {
            results.forEach((res, index) => {
              res.forEach(element => {
                element['rld_rlh_id'] = vm.header_list_object[element['rld_rlh_id']]
                element['list_description'] = rows[index].rlh_description
              })
              exportCSV.export_csv(res, rows[index].rlh_name)
            })
          })
        }

        vm.exportCustomFormCSV = () => {
          let rows = JSON.parse(JSON.stringify(vm.customListOptions.api.getSelectedRows()))
          exportCSV.export_csv(rows, translateTag(9180))
        }

        function getParentListName (childId) {
          let name = null
          vm.list.forEach((list)=>{
            if(childId === list.rlh_id){
              name =  list.rlh_name
            }
          })
          return name
        }

        function findParentListLable(parentId) {
          vm.list.forEach((data)=>{
            if(parentId === data.rlh_id){
              vm.parentSiteLabel = vm.getDisplayTranslation('rlh_display_names', data)
            }
          })
        }

        //Function to build multi list
        vm.buildMultiCurrentList = () =>{
          let build = []
          let finalBuild = []
          findParentListLable(vm.currentList.rlh_parent_header_rlh_id)
          vm.parentList.forEach((parent, index)=>{
            build.push({
              parent: parent.rld_id,
              parentName: parent.rld_name,
              parentLabel: vm.parentSiteLabel,
              entry: []
            })
            vm.currentListItems.forEach((child)=>{
              if(parent.rld_id === child.rld_parent_detail_rld_id){
                build[index].entry.push(child)
              }
            })
          })
          build.forEach((final)=>{
            if(final.entry.length){
              finalBuild.push(final)
            }
          })        
          return finalBuild
        }

        vm.archiveListItem = (id, mode, position_display_name) => {
          adminListService.archiveListItem({rld_id: id, mode: mode}).then ((response) => {
            vm.selectedPosition = position_display_name
            
            if(response.Message){
              
              if(mode === 'warning'){
                vm.cancelPositionModal('DeletePositionModal')
              }
              loadListItems()
            }
            else{
              vm.positionId = id
              vm.openPositionModal('DeletePositionModal', response.employees_name)
            }
          })
        }
        // Open warning modal
        vm.openPositionModal = (modalId, data) =>{

          items = []
          data.forEach((emp) => {
            
            items.push({"name": emp})
          })        

          vm.archiveEmployeeOptions.paginationPageSize = 10
          vm.archiveEmployeeOptions.api.setRowData(items)
          vm.archiveEmployeeOptions.api.redrawRows()
          vm.archiveEmployeeOptions.api.sizeColumnsToFit()
          modalService.Open(modalId)

        }
        vm.cancelPositionModal = (modalId) =>{
          modalService.Close(modalId)

        }
        
        vm.deleteCustomListConfirmationModal = () => {
          if(!vm.canArchiveSubmissions)
            return

          deleteIds = []
          let deleteCustomlistData = vm.customListOptions.api.getSelectedRows()
          for (let i = 0; i < deleteCustomlistData.length; i++) {
            deleteIds.push(deleteCustomlistData[i].clh_id)
          }

          adminListService.deleteCustomListCheck({"clh_ids": deleteIds}).then((response) => {

            vm.modalElements = {
              title: translateTag(9231), // Delete Custom List?
              message: `<div>
                          <p note="You are about to delete this custom list. Undoing this will require IT support. Are you sure?">${translateTag(9230)}</p>
                        </div>`,
              buttons: `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            }

            if(response.custom_form_names) {
              vm.modalElements.message = `<div>
                                            <p note="You are about to delete this custom list. Undoing this will require IT support. Are you sure?">${translateTag(9230)}</p>
                                            <p note="The custom list is currently in use in custom forms. Performing this action will remove this custom list from the following custom forms.">${translateTag(9177)}</p>`

              for(let i = 0; i < response.custom_form_names.length; i++)
                vm.modalElements.message += `<small>${response.custom_form_names[i]}</small><br>`

              vm.modalElements.message += `</div>`
            }            

            document.getElementById('confirmcallingform').innerHTML = 'CLCALLCONFIRMMODAL'
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
          })
        }

        $scope.$on("CLCALLCONFIRMMODAL", (event,result) => {
          if (result=='button1') {
            adminListService.deleteCustomLists({"clh_ids": deleteIds}).then((response) => {
              vm.cancelModal('confirmModal')
              vm.refreshScreen()              
            })
          }
          else if (result=='button2') {
            vm.cancelModal('confirmModal')
          }
        })

        
        vm.archiveCustomListItem = (cld_id) => {
          if(!vm.canArchiveSubmissions)
            return

          if(vm.currentListItems.length == 1) {
            adminListService.deleteCustomListCheck({"cld_id": cld_id}).then((response) => {

              if(response.custom_form_names) {
                vm.deleteCustomListItemConfirmationModal(cld_id, response.custom_form_names)               
              } else {
                adminListService.deleteCustomListItem({"cld_id": cld_id}).then((response) => {
                  vm.cancelModal('confirmModal')
                  loadCustomListItems()
                })
              }               
            })
          } else {
            adminListService.deleteCustomListItem({"cld_id": cld_id}).then((response) => {
              vm.cancelModal('confirmModal')
              loadCustomListItems()
            })
          }
        }
                
        vm.deleteCustomListItemConfirmationModal = (cld_id, customFormNames) => {
          if(!vm.canArchiveSubmissions)
            return

          deleteItemId = cld_id
          
          vm.modalElements = {
            title: translateTag(2182), // Warning
            buttons: `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                      <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
          }
          vm.modalElements.message = `<div>
                                        <p note="Deleting all the items in the list may prevent users from submitting the following custom forms. If you would like to delete your list please go to Custom List Page.">${translateTag(9178)} ${translateTag(2257)}</p>`

          for(let i = 0; i < customFormNames.length; i++)
            vm.modalElements.message += `<small>${customFormNames[i]}</small><br>`

          vm.modalElements.message += `</div>`

          document.getElementById('confirmcallingform').innerHTML = 'CLICALLCONFIRMMODAL'
          $rootScope.$broadcast("CALLCONFIRMMODAL", vm.modalElements)          
        }

        $scope.$on("CLICALLCONFIRMMODAL", (event,result) => {
          if (result=='button1') {
            adminListService.deleteCustomListItem({"cld_id": deleteItemId}).then((response) => {
              vm.cancelModal('confirmModal')
              loadCustomListItems()
            })
          }
          else if (result=='button2') {
            vm.cancelModal('confirmModal')
          }
        })

        function loadListItems () {
          $scope.$emit('STARTSPINNER', translateTag(8479)) //Loading list. Please wait.
          vm.listSearch = ""

          adminListService.getReferenceListItems(vm.currentList.rlh_id).then((result)=>{
            vm.currentListItems = result
       
            // This is a child list of another list
            if(vm.currentList.rlh_parent_header_rlh_id) {
              vm.isMultiList = true
              vm.parentList = []
              adminListService.getReferenceList(getParentListName(vm.currentList.rlh_parent_header_rlh_id)).then((data)=> {
                
                vm.parentList = data.sort(function(a, b) {return a.rld_name.localeCompare(b.rld_name)}) //Sort Alphabetically
                vm.currentListItems = sortListItems(vm.buildMultiCurrentList())
                
                $scope.$emit('STOPSPINNER')
              })
            }
            else {
              vm.isMultiList = false
              vm.currentListItems = sortListItems(vm.currentListItems) //Sort Alphabetically
              $scope.$emit('STOPSPINNER')
            }
          })
        }

        function loadCustomListItems () {
          $scope.$emit('STARTSPINNER', translateTag(8479)) //Loading list. Please wait.
          vm.listSearch = ""

          adminListService.getCustomListDetail({cld_clh_id: vm.currentList.clh_id}).then((response) => {
            vm.currentListItems = response
            vm.currentListItems.sort(function(a, b) {return vm.getDisplayTranslation('cld_names', a).trim().localeCompare(vm.getDisplayTranslation('cld_names', b).trim())})
            $scope.$emit('STOPSPINNER')
          })
        }

        function sortListItems(list) {
          if(!vm.isMultiList) // Single List
          {
            if(vm.currentList.rlh_is_name_required)
              list.sort(function(a, b) {return vm.getDisplayTranslation('rld_names', a).trim().localeCompare(vm.getDisplayTranslation('rld_names', b).trim())})         // Sort Alphabetically by Name
            else if(vm.currentList.rlh_is_code_required)
              list.sort(function(a, b) {return a.rld_code.localeCompare(b.rld_code)})                                                                     // Sort Alphabetically by Code
          }
          else                // Multi List
          {
            list.sort(function(a, b) {return a.parentName.localeCompare(b.parentName)})                                                                   // Sort Alphabetically by Parent Name
            list.forEach((item) => {
              if(vm.currentList.rlh_is_name_required)
                item.entry.sort(function(a, b) {return vm.getDisplayTranslation('rld_names', a).trim().localeCompare(vm.getDisplayTranslation('rld_names', b).trim())}) // Sort Alphabetically by Name
              else if(vm.currentList.rlh_is_code_required)
                item.entry.sort(function(a, b) {return a.rld_code.localeCompare(b.rld_code)})                                                             // Sort Alphabetically by Code
            })
          }

          return list
        }

        vm.openListViewer = (id) => {
          vm.hideingListViewer = false
          vm.listViewerOpen = true
          vm.openingListViewer = true
          vm.listMode = 'ref'

          vm.list.forEach((listData)=>{
            if(id == listData.rlh_id) {
              vm.currentList = listData
            }
          })         
          
          loadListItems()          
        }

        vm.openCustomListViewer = (id=null) => {
          if(!vm.canManageCustomLists)
            return

          vm.hideingListViewer = false
          vm.listViewerOpen = true
          vm.openingListViewer = true
          vm.listMode = 'custom'

          if (id) {
            $scope.$emit('STARTSPINNER', translateTag(8479)) //Loading list. Please wait.
            adminListService.getCustomListHeader({clh_id: id}).then((response) => {
              vm.currentList = response
              loadCustomListItems()
            })
          }

        }

      vm.closeListViewer = () => {
          vm.hideingListViewer = true

          if(vm.infoEdited)
          {
            vm.infoEdited = false
            vm.refreshScreen()
          }

          $timeout(() => {
            vm.listViewerOpen = false
            vm.currentList = {}
            vm.currentListItems = []
            vm.isMultiList = false
          }, 400)
      }

      vm.openListItemTranslationModal = (mode, index, parentID) => {
        resetFormFieldClassList('listItemTranslationForm')
        vm.currentTranslationMode = mode

        if(mode == 'new') {
          if(!vm.isMultiList)         // Single List
            resetCurrentSingleItem()
          else                        // Multi List
          {
            resetCurrentMultiItem()
            vm.currentItem.rld_parent_detail_rld_id = parentID
          }

          if(vm.listMode == 'ref')
            vm.currentItem.rld_rlh_id = vm.currentList.rlh_id
          else
            vm.currentItem.cld_clh_id = vm.currentList.clh_id
        }
        else
        {        

          if(!vm.isMultiList)
          {         // Single List          
            vm.currentItem = JSON.parse(JSON.stringify(vm.currentListItems[index]))
            if(vm.currentList.rlh_name == 'ref_drilling_time_and_delays_code'){
              vm.existing_total_hours_drilled = vm.currentItem.rld_total_hours_drilled
            }
            if(vm.currentList.rlh_name == 'ref_drilling_code'){
              vm.existing_drilling_code_value = vm.currentItem.rld_drilling_code_value
            }
          }            
          else                        // Multi List
          {
            let parentIndex = 0
            vm.currentListItems.forEach((parent, index) => {
              if(parent.parent == parentID)
                parentIndex = index
            })
            vm.currentItem = JSON.parse(JSON.stringify(vm.currentListItems[parentIndex].entry[index]))
            vm.currentItem.rld_parent_detail_rld_id = parentID
           
          }

          if(vm.listMode == 'ref')
            vm.currentItem.rld_rlh_id = vm.currentList.rlh_id
          else
            vm.currentItem.cld_clh_id = vm.currentList.clh_id


          if(vm.currentItem.rld_rlh_id === 29) {
            vm.showWarnningMessage = true
          }else {
            vm.showWarnningMessage = false
          }
        }

        if(vm.listMode == 'ref' && (vm.currentList.rlh_is_description_required || vm.currentList.rlh_is_name_required))
        {
          let tranData = []
          if(vm.currentList.rlh_is_name_required)
            tranData.push(vm.currentItem['rld_names'])
          if(vm.currentList.rlh_is_description_required)
            tranData.push(vm.currentItem['rld_descriptions'])        
          vm.currentTranslationList = vm.getCurrentTranslationList(tranData)
        }
        else if(vm.listMode == 'custom')
        {
          let tranData = []
          tranData.push(vm.currentItem['cld_names'])
          vm.currentTranslationList = vm.getCurrentTranslationList(tranData)
        }
        
        modalService.Open('listItemTranslationModal')
        vm.initializeSelect2('listItemTranslationModal', '.modal-body')
      }

      vm.openListHeaderTranslationModal = () => {
        resetFormFieldClassList('listHeaderTranslationForm')
        vm.currentTranslationMode = vm.currentList.clh_id ? 'edit' : 'new'

        let tranData = []
        tranData.push(vm.currentList['clh_display_names'])
        tranData.push(vm.currentList['clh_descriptions'])
        vm.currentTranslationList = vm.getCurrentTranslationList(tranData)
        
        modalService.Open('listHeaderTranslationModal')
        vm.initializeSelect2('listHeaderTranslationModal', '.modal-body')
      }

      vm.saveListItem = () => {
        if(vm.validateListItem())
        {
          if(vm.listMode == 'ref' && vm.checkForItemDuplicates())
          {
            vm.submitted = true
            translationPayload = prepareListItemTranslationPayload(vm.currentTranslationList)
            
            vm.currentItem.rld_rlh_id = vm.currentList.rlh_id
            vm.currentItem.rld_names = translationPayload.rld_names
            vm.currentItem.rld_descriptions = translationPayload.rld_descriptions
            vm.currentItem.rld_deleted = 0
            vm.currentItem.rld_enable = 1
            vm.currentItem.rld_changed = vm.itemChanged

            delete vm.currentItem.parentdetail_name
            if(vm.currentTranslationMode == 'new')
            {
              adminListService.addListItem(vm.currentItem).then(() => {
                resetCurrentSingleItem()
                resetCurrentMultiItem()
                resetFormFieldClassList('listItemTranslationForm')
                modalService.Close('listItemTranslationModal')
                vm.showWarnningMessage = false
                vm.submitted = false

                //Refresh Items
                loadListItems()
              })
            }
            else
            {
              adminListService.updateListItem(vm.currentItem).then(() => {
                resetCurrentSingleItem()
                resetCurrentMultiItem()
                resetFormFieldClassList('listItemTranslationForm')
                modalService.Close('listItemTranslationModal')
                vm.showWarnningMessage = false
                vm.submitted = false

                //Refresh Items
                loadListItems()
              })
            } 
          } else if(vm.listMode == 'custom' && checkCustomListItemDuplicates()) {
            vm.submitted = true
            translationPayload = prepareCustomListItemTranslationPayload(vm.currentTranslationList)
            
            vm.currentItem.cld_clh_id = vm.currentList.clh_id
            vm.currentItem.cld_names = translationPayload.cld_names

            if(vm.currentTranslationMode == 'new')
            {
              adminListService.createCustomListDetail(vm.currentItem).then(() => {
                vm.currentItem = {}
                resetFormFieldClassList('listItemTranslationForm')
                modalService.Close('listItemTranslationModal')
                vm.submitted = false
                vm.currentTranslationList = []

                //Refresh Items
                loadCustomListItems()
              })
            }
            else
            {
              adminListService.updateCustomListDetail(vm.currentItem).then(() => {
                vm.currentItem = {}
                resetFormFieldClassList('listItemTranslationForm')
                modalService.Close('listItemTranslationModal')
                vm.submitted = false
                vm.currentTranslationList = []

                //Refresh Items
                loadCustomListItems()
              })
            } 

          }
        }
        else 
        {
          $rootScope.$broadcast("CALLCONFIRMMODAL")
        }
      }

      vm.saveListHeader = () => {
        if(validateFormFields('listHeaderTranslationForm'))
        {
          if(checkCustomListDuplicates()) //Check for duplicates
          {
            vm.submitted = true
            translationPayload = prepareCustomListHeaderTranslationPayload(vm.currentTranslationList)
            vm.currentList.clh_display_names = translationPayload.clh_display_names
            vm.currentList.clh_descriptions = translationPayload.clh_descriptions

            if(vm.currentTranslationMode == 'new')
            {
              adminListService.createCustomListHeader(vm.currentList).then((response) => {
                adminListService.getCustomListHeader({clh_id: response.clh_id}).then((response) => {
                  vm.currentList = response

                  resetFormFieldClassList('listHeaderTranslationForm')
                  modalService.Close('listHeaderTranslationModal')
                  vm.submitted = false
                  vm.infoEdited = true
                  vm.currentTranslationList = []
                })
              })
            }
            else
            {
              adminListService.updateCustomListHeader(vm.currentList).then(() => {
                adminListService.getCustomListHeader({clh_id: vm.currentList.clh_id}).then((response) => {
                  vm.currentList = response

                  resetFormFieldClassList('listHeaderTranslationForm')
                  modalService.Close('listHeaderTranslationModal')
                  vm.submitted = false
                  vm.infoEdited = true
                  vm.currentTranslationList = []
                })
              })
            }
          }
        }
        else
        {
          $rootScope.$broadcast("CALLCONFIRMMODAL")
        }
      }

      function prepareListItemTranslationPayload (data) {
        let rld_names = []
        let rld_descriptions = []        

        for(let tran in data) {
            tran = data[tran]
            if(vm.currentList.rlh_is_name_required)
            {
              let payloadTran = {
                  ltr_lng_id: tran.ltr_lng_id,
                  ltr_text: tran.ltr_text[0].trim()
              }
              if(payloadTran.ltr_text != "")
                rld_names.push(payloadTran)
            }

            if(vm.currentList.rlh_is_description_required)
            {
              payloadTran = {
                  ltr_lng_id: tran.ltr_lng_id,
                  ltr_text: tran.ltr_text[vm.currentList.rlh_is_name_required ? 1 : 0].trim()
              }
              if(payloadTran.ltr_text != "")
                rld_descriptions.push(payloadTran)
            }
        }

        let payload = {
            rld_names: rld_names,
            rld_descriptions: rld_descriptions,
        }
            
        return payload
      }

      function prepareCustomListHeaderTranslationPayload (data) {
        let payload = {
          clh_display_names: [],
          clh_descriptions: []
        }     

        for(let tran in data) {
          tran = data[tran]

          let payloadTran = {
              ltr_lng_id: tran.ltr_lng_id,
              ltr_text: tran.ltr_text[0].trim()
          }
          if(payloadTran.ltr_text != "")
            payload.clh_display_names.push(payloadTran)

          payloadTran = {
              ltr_lng_id: tran.ltr_lng_id,
              ltr_text: tran.ltr_text[1].trim()
          }
          if(payloadTran.ltr_text != "")
            payload.clh_descriptions.push(payloadTran)
        }

        return payload
      }

      function prepareCustomListItemTranslationPayload (data) {
        let payload = {
          cld_names: []
        }     

        for(let tran in data) {
          tran = data[tran]

          let payloadTran = {
              ltr_lng_id: tran.ltr_lng_id,
              ltr_text: tran.ltr_text[0].trim()
          }
          if(payloadTran.ltr_text != "")
            payload.cld_names.push(payloadTran)
        }

        return payload
      }

      vm.validateListItem = () => {
        return validateFormFields('listItemTranslationForm')
      }

      vm.checkForItemDuplicates = () => {
        let formVal = document.forms['listItemTranslationForm']
        let validated = true
        vm.itemChanged = false
          
        let nameExists = false
        let existingName = ""
        let codeExists = false
        let existingCode = ""

        let newNameValue = ""
        if(vm.currentList.rlh_is_name_required)
        {
          let newItem = {}
          newItem['rld_names'] = vm.currentTranslationList
          newNameValue = getDefaultTranslation('rld_names', newItem)[0]
        }
        if(!vm.isMultiList) //Single List
        {
          
          vm.currentListItems.forEach((existingItem) => {
            if(vm.currentList.rlh_is_name_required)
            {
              let existingNameValue = getDefaultTranslation('rld_names', existingItem)
              if(existingNameValue.toLowerCase().trim() === newNameValue.toLowerCase().trim() && vm.currentItem.rld_id != existingItem.rld_id)
              {
                nameExists = true
                existingName = newNameValue
              }
            }

            if(vm.currentList.rlh_is_code_required && existingItem.rld_code && existingItem.rld_code.toLowerCase().trim() === vm.currentItem.rld_code.toLowerCase().trim() && vm.currentItem.rld_id != existingItem.rld_id)
            {
              codeExists = true
              existingCode = vm.currentItem.rld_code
            }

            if(vm.currentItem.rld_id == existingItem.rld_id) //If the values entered are the same as before we dont want to update
            {             
              vm.currentTranslationList.forEach((tran, index) => {
                if(vm.currentList.rlh_is_name_required && ((!vm.currentItem.rld_names[index] && tran.ltr_text[0].trim() != "") || (vm.currentItem.rld_names[index] && tran.ltr_text[0].trim() != vm.currentItem.rld_names[index].ltr_text.trim()))){
                  vm.itemChanged = true // Names
                }
                else if(vm.currentList.rlh_is_description_required && ((!vm.currentItem.rld_descriptions[index] && tran.ltr_text[vm.currentList.rlh_is_name_required ? 1 : 0].trim() != "") || (vm.currentItem.rld_descriptions[index] && tran.ltr_text[vm.currentList.rlh_is_name_required ? 1 : 0].trim() != vm.currentItem.rld_descriptions[index].ltr_text.trim()))){
                  vm.itemChanged = true // Descriptions
                }
              })
              if(vm.currentList.rlh_is_code_required && existingItem.rld_code && existingItem.rld_code.trim() != vm.currentItem.rld_code.trim()){
                vm.itemChanged = true // Codes
              }
              else if (vm.currentList.rlh_is_score_required && existingItem.rld_score != vm.currentItem.rld_score){
                vm.itemChanged = true // Scores
              }
            }
          })
          if(vm.currentTranslationMode != 'new'){
            if(vm.currentList.rlh_name == 'ref_drilling_time_and_delays_code' && vm.existing_total_hours_drilled !== vm.currentItem.rld_total_hours_drilled){
              vm.currentItem.rld_total_hours_drilled_changed = true
            }
            if(vm.currentList.rlh_name == 'ref_drilling_code' && vm.existing_drilling_code_value !== vm.currentItem.rld_drilling_code_value){
              vm.currentItem.rld_drilling_code_value_changed = true
            }
          }
        }
        else //Multi List
        {
          formVal = document.forms['listGroupForm']
          let parentIndex = 0
          vm.currentListItems.forEach((parent, index) => {
            
            if(parent.parent == vm.currentItem.rld_parent_detail_rld_id)
              parentIndex = index
          })

          vm.currentListItems[parentIndex].entry.forEach((existingItem) => {

            if(vm.currentList.rlh_is_name_required)
            {
              let existingNameValue = getDefaultTranslation('rld_names', existingItem)

              if(existingNameValue.toLowerCase().trim() === newNameValue.toLowerCase().trim() && vm.currentItem.rld_id != existingItem.rld_id)
              {
                nameExists = true
                existingName = newNameValue
              }
            }

            if(vm.currentList.rlh_is_code_required && existingItem.rld_code && existingItem.rld_code.toLowerCase().trim() === vm.currentItem.rld_code.toLowerCase().trim() && vm.currentItem.rld_id != existingItem.rld_id)
            {
              codeExists = true
              existingCode = vm.currentItem.rld_code
            }

            if(vm.currentItem.rld_id == existingItem.rld_id) //If the values entered are the same as before we dont want to update
            {
              vm.currentTranslationList.forEach((tran, index) => {
                if(vm.currentList.rlh_is_name_required && ((!vm.currentItem.rld_names[index] && tran.ltr_text[0].trim() != "") || (vm.currentItem.rld_names[index].ltr_text && tran.ltr_text[0].trim() != vm.currentItem.rld_names[index].ltr_text.trim())))
                  vm.itemChanged = true // Names
                else if(vm.currentList.rlh_is_description_required && ((!vm.currentItem.rld_descriptions[index] && tran.ltr_text[vm.currentList.rlh_is_name_required ? 1 : 0].trim() != "") || (vm.currentItem.rld_descriptions[index] && tran.ltr_text[vm.currentList.rlh_is_name_required ? 1 : 0].trim() != vm.currentItem.rld_descriptions[index].ltr_text.trim())))
                  vm.itemChanged = true // Descriptions
              })

              if(vm.currentList.rlh_is_code_required && existingItem.rld_code && existingItem.rld_code.trim() != vm.currentItem.rld_code.trim())
                vm.itemChanged = true // Codes
              else if (vm.currentList.rlh_is_score_required && existingItem.rld_score.trim() != vm.currentItem.rld_score.trim())
                vm.itemChanged = true // Scores

            }
          })
        }

        if(vm.currentList.rlh_is_name_required && nameExists)
        {
          toastr.error(`${existingName} ${translateTag(8569)}`) //Already Exists
          resetFormFieldClassList('listItemTranslationForm')
          validated = false
        }
        if(vm.currentList.rlh_is_code_required && codeExists)
        {
          toastr.error(`${existingCode} ${translateTag(8569)}`) //Already Exists
          resetFormFieldClassList('listItemTranslationForm')
          formVal.classList.remove('was-validated')
          validated = false
        }

        return validated
      }

      checkCustomListDuplicates = () => {
        let validated = true

        let exists = false
        let existingName = ""

        let newList = {}
        newList['clh_display_names'] = vm.currentTranslationList
        newNameValue = getDefaultTranslation('clh_display_names', newList)[0]

        vm.customLists.forEach((existingList) => {
          let existingNameValue = existingList.clh_display_name
          if(existingNameValue.toLowerCase().trim() === newNameValue.toLowerCase().trim() && vm.currentList.clh_id != existingList.clh_id) {
            exists = true
            existingName = newNameValue
          }
        })

        if(exists) {
          toastr.error(`${existingName} ${translateTag(8569)}`) //Already Exists
          resetFormFieldClassList('listHeaderTranslationForm')
          validated = false
        }

        return validated
      }

      checkCustomListItemDuplicates = () => {
        let validated = true

        let exists = false
        let existingName = ""

        let newItem= {}
        newItem['cld_names'] = vm.currentTranslationList
        newNameValue = getDefaultTranslation('cld_names', newItem)[0]

        vm.currentListItems.forEach((existingItem) => {
          let existingNameValue = getDefaultTranslation('cld_names', existingItem)
          if(existingNameValue.toLowerCase().trim() === newNameValue.toLowerCase().trim() && vm.currentItem.cld_id != existingItem.cld_id) {
            exists = true
            existingName = newNameValue
          }
        })

        if(exists) {
          toastr.error(`${existingName} ${translateTag(8569)}`) //Already Exists
          resetFormFieldClassList('listItemTranslationForm')
          validated = false
        }

        return validated
      }

      vm.openListGroupModal = () => {
        resetFormFieldClassList('listGroupForm')
        resetCurrentMultiItem()

        vm.currentItem.rld_rlh_id = vm.currentList.rlh_id

        if(vm.currentList.rlh_is_description_required || vm.currentList.rlh_is_name_required)
        {
          var tranData = []
          if(vm.currentList.rlh_is_name_required)
            tranData.push(vm.currentItem['rld_names'])
          if(vm.currentList.rlh_is_description_required)
            tranData.push(vm.currentItem['rld_descriptions'])        
          vm.currentTranslationList = vm.getCurrentTranslationList(tranData)
        }

        modalService.Open('addListGroupModal')
        vm.initializeSelect2('addListGroupModal', '.modal-body')
      }

      vm.addListGroup = () => {
        if(vm.validateListGroup()) 
        {      
          if(!vm.groupExists() || vm.checkForItemDuplicates())
          {
            vm.submitted = true
            
            translationPayload = prepareListItemTranslationPayload(vm.currentTranslationList)
            vm.currentItem.rld_names = translationPayload.rld_names
            vm.currentItem.rld_descriptions = translationPayload.rld_descriptions
            vm.currentItem.rld_deleted = 0

            adminListService.addListItem(vm.currentItem).then((result) => {
              resetCurrentMultiItem()
              resetFormFieldClassList('listGroupForm')
              modalService.Close('addListGroupModal')
              vm.submitted = false

              //Refresh Items
              loadListItems()
            })
          } 
        }
        else 
        {
          $rootScope.$broadcast("CALLCONFIRMMODAL")
        }
      }

      vm.validateListGroup = () => {
        return validateFormFields('listGroupForm')
      }

      vm.groupExists = () => {
        let exists = false
        vm.currentListItems.forEach((group) => {
          if(group.parent === vm.currentItem.rld_parent_detail_rld_id)
            exists = true
        })
        return exists
      }

      vm.cancelModal = (modalId) => {
        modalService.Close(modalId)
      }

      vm.listSearchChanged = () => {
        let filter = vm.listSearch.toUpperCase()

        if(!vm.isMultiList) {
          // Loop through all list items, and hide those who don't match the search
          for (let i = 0; i < vm.currentListItems.length; i++) {
            let txtValueCode = ""
            let txtValueScore = ""
            let txtValueName = ""
            let txtValueDescription = ""
            
            // Ref Lists
            if(vm.currentList.rlh_is_code_required)
              txtValueCode = vm.currentListItems[i].rld_code || ""
            if(vm.currentList.rlh_is_score_required)
              txtValueScore = vm.currentListItems[i].rld_score || ""
            if(vm.currentList.rlh_is_name_required)
              txtValueName = vm.getDisplayTranslation('rld_names', vm.currentListItems[i]) || ""
            if(vm.currentList.rlh_is_description_required)
              txtValueDescription = vm.getDisplayTranslation('rld_descriptions', vm.currentListItems[i]) || ""

            // Custom Lists
            if(vm.currentList.clh_id)
              txtValueName = vm.getDisplayTranslation('cld_names', vm.currentListItems[i]) || ""
            
            if (txtValueCode.toUpperCase().indexOf(filter) > -1 || txtValueScore.toUpperCase().indexOf(filter) > -1 || txtValueName.toUpperCase().indexOf(filter) > -1 || txtValueDescription.toUpperCase().indexOf(filter) > -1) {
              vm.currentListItems[i].hide = false
            } else {
              vm.currentListItems[i].hide = true
            }
          }
        } else {
          for (let i = 0; i < vm.currentListItems.length; i++) {

            if(filter != "")
              vm.currentListItems[i].hide = true

            let txtValueParentName = vm.currentListItems[i].parentName || ""
            let hideParent = false
            if (txtValueParentName.toUpperCase().indexOf(filter) < 0) {
              hideParent = true
            }

            for (let j = 0; j < vm.currentListItems[i].entry.length; j++) {
              let txtValueCode = ""
              let txtValueScore = ""
              let txtValueName = ""
              let txtValueDescription = ""
              
              if(vm.currentList.rlh_is_code_required)
                txtValueCode = vm.currentListItems[i].entry[j].rld_code || ""
              if(vm.currentList.rlh_is_score_required)
                txtValueScore = vm.currentListItems[i].entry[j].rld_score || ""
              if(vm.currentList.rlh_is_name_required)
                txtValueName = vm.getDisplayTranslation('rld_names', vm.currentListItems[i].entry[j]) || ""
              if(vm.currentList.rlh_is_description_required)
                txtValueDescription = vm.getDisplayTranslation('rld_descriptions', vm.currentListItems[i].entry[j]) || ""
              
              if (!hideParent || txtValueCode.toUpperCase().indexOf(filter) > -1 || txtValueScore.toUpperCase().indexOf(filter) > -1 || txtValueName.toUpperCase().indexOf(filter) > -1 || txtValueDescription.toUpperCase().indexOf(filter) > -1) {
                vm.currentListItems[i].entry[j].hide = false
                vm.currentListItems[i].hide = false
              } else {
                vm.currentListItems[i].entry[j].hide = true
              }
            }
          }
        }
      }

        //Funtion to initialize select2
      vm.initializeSelect2 = (parent, section='') => {
          $timeout(() => {
          $('.select-single')
              .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} ${section}`), escapeMarkup: function (text) { return text } })
              .on('select2:select', () => {
              $(`#${parent}`).find('label').addClass('filled');
              })
          $('.select2-selection__arrow b').addClass("fa fa-caret-down");
          }, 100)
      }

      //Function to refresh all data
      vm.refreshScreen = () => {
        $scope.$emit('STARTSPINNER', vm.loadMessage)
        $q.all([
            adminListService.getMasterList(),
            i18nService.getLanguages(),
            adminListService.getCustomLists(),
        ]).then(() => {
            vm.list = adminListService.readMasterList()
            vm.systemLanguages = i18nService.readLanguageList().languages
            vm.customLists = adminListService.readCustomLists()
            vm.selectedLanguageID = getSelectedLanguageID(selectedLanguage)
            vm.defaultLanguageID = getDefaultLanguageID()
            translateAgGridHeader(vm.listOptions)
            let model = vm.listOptions.api.getFilterModel()
            vm.listOptions.api.setRowData(prepareGridData(vm.list))
            vm.listOptions.api.redrawRows()
            vm.listOptions.api.sizeColumnsToFit()
            vm.listOptions.api.sizeColumnsToFit()
            vm.listOptions.api.setFilterModel(model)

            translateAgGridHeader(vm.customListOptions)
            vm.customListOptions.api.setRowData(prepareCustomListGridData(vm.customLists))
            vm.customListOptions.api.redrawRows()
            vm.customListOptions.api.sizeColumnsToFit()
            vm.customListOptions.api.sizeColumnsToFit()

            $scope.$emit('STOPSPINNER')
        })
      }
      vm.refreshScreen()

      //Function to prepare list Data for the grid/tippy
      function prepareGridData(data=vm.list) {
          let listGridData = JSON.parse(JSON.stringify(data))
          listGridData.forEach((rec) =>{
              rec.exceptionFields = ['rlh_enable','rlh_is_code_required','rlh_is_description_required','rlh_is_name_required','rlh_is_score_required','rlh_enote', 'rlh_name', 'status_message', 'rlh_is_active_required', 'rlh_is_core_list', 'rlh_tag_type', 'rlh_descriptions', 'rlh_display_names', 'rlh_parent_header_rlh_id']

              rec.rlh_rlt === 1 ? rec.rlh_rlt = translateTag(8580) : rec.rlh_rlt = translateTag(8567) // Basic Advanced
              rec.rlh_created_date = moment(rec.rlh_created_date).format('YYYY-MM-DD')
              rec.rlh_modified_date = rec.rlh_modified_date == null ? '' : moment(rec.rlh_modified_date).format('YYYY-MM-DD')

              rec.rlh_display_name = vm.getDisplayTranslation('rlh_display_names', rec)
              rec.rlh_description = vm.getDisplayTranslation('rlh_descriptions', rec)
              vm.header_list_object[rec.rlh_id] = rec.rlh_display_name
          })
          return listGridData
      }

      function prepareCustomListGridData(data=vm.customLists) {
          let listGridData = JSON.parse(JSON.stringify(data))
          listGridData.forEach((rec) => {
              rec.exceptionFields = []

              rec.clh_created_date = moment(rec.clh_created_date).format('YYYY-MM-DD')
              rec.clh_modified_date = rec.clh_modified_date ? moment(rec.clh_modified_date).format('YYYY-MM-DD') : ""
          })
          return listGridData
      }

      //Update Ag-Grid size when window is resized
      $(window).on('resize', () => {
          $timeout(function () {
              if (vm.listOptions.api) {
                  vm.listOptions.api.sizeColumnsToFit()
              }
              if (vm.customListOptions.api) {
                vm.customListOptions.api.sizeColumnsToFit()
              }
          });
      })

      //END
    }
])