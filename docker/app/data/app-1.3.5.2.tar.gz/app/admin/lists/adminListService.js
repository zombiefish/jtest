angular
  .module('safeToDo')
  .service('adminListService', ['$http', '$location','$window',
    function ($http, $location, $window) {
        let masterList = []
        let customList = []
        return {
            getMasterList: () => {
                return $http.get(`${__env.apiUrl}/api/master-ref-list/masterlist/`).then((response) => {
                    masterList = response.data
                    if (response.data.Permission){
                        toastr.error(response.data.Permission)
                        window.location.href = "/";
                    }
                }, (errParams) => {
                    let errorObj = {}
                    if (errParams.status == 404) {
                        errorObj.error = 'Master List not found - Contact a system administrator'
                    }
                    return errorObj
                })
            },
            getReferenceList: (list) => {
              
                return $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`,{"validatorStr":list, "language": selectedLanguage}).then((response) =>{
                  
                    return response.data
                }, (errParams) => {
                    var errorObj = {};
                    if (errParams.status == 404) {
                        errorObj.error = `Reference List ${list} not found - Contact a system administrator`
                    }
                    return errorObj;
                })

            },  
            getReferenceListItems: (rld_rlh_id) => {
                
                 return $http.get(`${__env.apiUrl}/api/master-ref-list/get-reflist-items/${rld_rlh_id}/`).then((response) =>{
                     return response.data.data
                 }, (errParams) => {
                     var errorObj = {};
                     if (errParams.status == 404) {
                         errorObj.error = `Reference List items not found - Contact a system administrator`
                     }
                     return errorObj;
                 })
 
             }, 
            addListItem: (payload) =>{
              
                return $http.post(`${__env.apiUrl}/api/master-ref-list/add-reflist-items/`, payload).then((response) =>{
                   
                }, (errParams) => {
                    var errorObj = {};
                    if (errParams.status == 404) {
                        errorObj.error = `Reference List ${list} not found - Contact a system administrator`
                    }
                    return errorObj;
                })
            },
            updateListItem: (payload) =>{
             
                return $http.post(`${__env.apiUrl}/api/master-ref-list/update-reflist-items/`, payload).then((response) =>{
                 
                }, (errParams) => {
                    var errorObj = {};
                    if (errParams.status == 404) {
                        errorObj.error = `Reference List ${list} not found - Contact a system administrator`
                    }
                    return errorObj;
                })
            },
            archiveListItem: (data) => {
                return $http.post(`${__env.apiUrl}/api/master-ref-list/archive-reflist-items/`, data).then((response) => {
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to archive list item', errorParams)
                    return "Error Happened"
                });
            },
            getCustomLists: () => {
                return $http.get(`${__env.apiUrl}/api/custom-list/get-custom-lists/`).then((response) => {
                    customList = response.data
                }, (errParams) => {
                    return errParams
                })
            },
            getCustomListHeader: (payload) => {
                return $http.post(`${__env.apiUrl}/api/custom-list/get-custom-list-header/`, payload).then((response) => {
                    return response.data
                }, (errParams) => {
                    return errParams
                })
            },
            getCustomListDetail: (payload) => {
                return $http.post(`${__env.apiUrl}/api/custom-list/get-custom-list-detail/`, payload).then((response) => {
                    return response.data
                }, (errParams) => {
                    return errParams
                })
            },
            createCustomListHeader: (payload) => {
                return $http.post(`${__env.apiUrl}/api/custom-list/create-custom-list-header/`, payload).then((response) => {
                    return response.data
                }, (errParams) => {
                    return errParams
                })
            },
            updateCustomListHeader: (payload) => {
                return $http.post(`${__env.apiUrl}/api/custom-list/update-custom-list-header/`, payload).then((response) => {
                    return response.data
                }, (errParams) => {
                    return errParams
                })
            },
            createCustomListDetail: (payload) => {
                return $http.post(`${__env.apiUrl}/api/custom-list/create-custom-list-detail/`, payload).then((response) => {
                    return response.data
                }, (errParams) => {
                    return errParams
                })
            },
            updateCustomListDetail: (payload) => {
                return $http.post(`${__env.apiUrl}/api/custom-list/update-custom-list-detail/`, payload).then((response) => {
                    return response.data
                }, (errParams) => {
                    return errParams
                })
            },
            deleteCustomListCheck: (payload) => {
                return $http.post(`${__env.apiUrl}/api/custom-list/check-if-custom-list-is-being-used/`, payload).then((response) => {
                    return response.data
                }, (errParams) => {
                    return errParams
                })
            },
            deleteCustomLists: (payload) => {
                return $http.post(`${__env.apiUrl}/api/custom-list/archive-custom-lists/`, payload).then((response) => {
                    return response.data
                }, (errParams) => {
                    return errParams
                })
            },
            deleteCustomListItem: (payload) => {
                return $http.post(`${__env.apiUrl}/api/custom-list/remove-custom-list-detail/`, payload).then((response) => {
                    return response.data
                }, (errParams) => {
                    return errParams
                })
            },
            
            readMasterList: () => {
                return masterList
            },
            readCustomLists: () => {
                return customList
            }
        }
}

])