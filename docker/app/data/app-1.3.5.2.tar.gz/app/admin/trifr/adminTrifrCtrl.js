﻿angular
    .module('safeToDo')
    .controller('AdminTrifrCtrl', ['$scope','$rootScope', '$timeout', '$q', 'gridService', 'select2Service', 'menuService', 'modalService', 'listService', 'adminTrifrService', 'adminUserService', 'profileService', '$compile', 'exportCSV',
    function ($scope,$rootScope, $timeout, $q, gridService, select2Service, menuService, modalService, listService, adminTrifrService, adminUserService, profileService, $compile, exportCSV) {
        let vm = this
        
        vm.actionDisabled = true
        vm.addAnother = false
        vm.siteList = []
        vm.jobList = []
        vm.jobListSelect = []
        vm.currentMode = 'new'
        vm.levelOfDetail = null
        vm.canViewHoursLog = false
        vm.canManageHoursLog = false
        vm.canAddHoursLog = false
        vm.showSite  = false
        vm.showJob = false
        vm.refreshFlag = false
        vm.csvOutput = ''
        vm.removeID = null
        vm.refreshDates = false
        vm.trifr_track_option = false
        vm.trir_track_option = false
        vm.loadMessage = translateTag(3589) // Loading Data...


        // Function to reset Hours Log Modal and flags
        function resetHoursLogModal(){
          document.forms['hoursLogForm'].classList.remove('was-validated')
          vm.currentRecord = {
            whl_id: null,
            whl_hours_worked: 0,
            whl_site: null,
            whl_job: null,
            whl_level_of_detail: null,
            whl_start_date: null,
            whl_end_date: null,
            whl_modified_by_per_id: null,
            whl_modified_date: null
          },
          vm.currentMode = 'new'
          vm.addAnother = false
          vm.currentLastRecEndDate = null
          vm.diffDates = null
          vm.typeOfDiff = null
          vm.refreshDates = false
        }

        // Get permissions for TRIFR
        menuService.getPagePermissions().then((data) => {
          vm.permissions = data
          vm.canViewHoursLog = vm.permissions.includes('Can View TRIFR Manager') ? true : false
          vm.canManageHoursLog = vm.permissions.includes('Can Manage Hours Log') ? true : false
          vm.canAddHoursLog = vm.permissions.includes('Can Add Hours Log') ? true : false
          if(!vm.canViewHoursLog)
              window.location.href = "/";
        })

        vm.hoursLogAgOptions = gridService.getCommonOptions()

        //Recordable Incident Injury AG grid data
        vm.recIncAgOptions = gridService.getCommonOptions()
        vm.recInjAgOptions = gridService.getCommonOptions()
        vm.recIncAgOptions.pagination = false
        vm.recInjAgOptions.pagination = false

        //Function for the top search bar
        vm.mainTopSearchChanged = () => {
          vm.hoursLogAgOptions.api.setQuickFilter(vm.mainTopSearch);
        }

        //Function to disable actions button
        vm.hoursLogAgOptions.onSelectionChanged = () => {
          var selectedRows = vm.hoursLogAgOptions.api.getSelectedRows()
          vm.actionDisabled = selectedRows.length == 0
          $scope.$apply()
        }

        // Column defs
        let recIncColumn = [
          {
            field: "rld_id", 
            headerName: " ",
            minWidth: 1000, 
            maxWidth: 2000,
            suppressMenu: true,
            suppressSorting: true,
            sort: "asc"
          },
        ]

        let recInjColumn = [
          {
            field: "rld_id", 
            headerName: " ",
            minWidth: 1000, 
            maxWidth: 2000,
            suppressMenu: true,
            suppressSorting: true,
            sort: "asc"
          },
        ]

        let hoursLogColumns = [
            {
              headerName: '',
              field: 'dummyCheckbox',
              maxWidth: 50,
              minWidth: 50,
              checkboxSelection: true,
              suppressMenu: true,
              suppressSorting: true,
              headerCheckboxSelection: true,
              headerCheckboxSelectionFilteredOnly: true,
            },
            {
                field: "review", 
                headerName: " ",  
                minWidth: 125,
                maxWidth: 125,
                suppressMenu: true,
                suppressSorting: true,
                cellRenderer: function (params) {
                    return `<div class="pointer text-left" ng-if="trifr.canManageHoursLog" class="pointer" ng-click="trifr.editHoursLogModal('HoursLogModal',${params.data.whl_id})"><i class="fa fa-pen" note="Edit" title="{{menu.translateLabels(1194)}}"></i></div>`
                }
            },
            {
              field: "whl_site_name", 
              headerName: " ",
              minWidth: 220, 
              maxWidth: 500,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: "tippyCellRenderer"
            },
            {
              field: "whl_job_name",
              headerName: " ",
              minWidth: 220, 
              maxWidth: 500,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: "tippyCellRenderer"
            },
            {
              field: "whl_start_date",
              headerName: " ",
              minWidth: 150,
              maxWidth: 500,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: "tippyCellRenderer"
            },
            {
              field: "whl_end_date",
              headerName: " ",
              minWidth: 150,
              maxWidth: 500,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: "tippyCellRenderer"
            },
            {
              field: "whl_hours_worked",
              headerName: " ",
              minWidth: 150,
              maxWidth: 500,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: "tippyCellRenderer"
            },
            {
              field: "whl_modified_date",
              headerName: " ",
              minWidth: 200,
              maxWidth: 400,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
            },
            {
              field: "modified_by",
              headerName: "Modified By",
              minWidth: 200,
              maxWidth: 400,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: "tippyCellRenderer"
            },
            {
              field: "", 
              headerName: " ",  
              minWidth: 50,
              maxWidth: 60,
              suppressMenu: true,
              suppressSorting: true,
              cellRenderer: function (params) {
                  return `<div class="pointer text-left" ng-if="trifr.canManageHoursLog" ng-click="trifr.openRemoveRecordModal(${params.data.whl_id})"><i class="far fa-trash-alt" note="Delete" title="{{menu.translateLabels(3088)}}"></i></div>`
              }
          },
        ]
        vm.hoursLogAgOptions.columnDefs = hoursLogColumns        
        vm.recIncAgOptions.columnDefs = recIncColumn
        vm.recInjAgOptions.columnDefs = recInjColumn
        vm.recIncAgOptions.suppressHorizontalScroll = true
        vm.recInjAgOptions.suppressHorizontalScroll = true

        // Function to refresh grid data
        vm.refreshGridData = () => {
          $scope.$emit('STARTSPINNER', vm.loadMessage)
          $q.all([
            adminTrifrService.getHoursLogList()
          ]).then((data) => {
            resetHoursLogModal()
            disableGridColumns()
            vm.hoursLogList = data[0]
            if(vm.hoursLogList != null){
              translateAgGridHeader(vm.hoursLogAgOptions)
              vm.hoursLogAgOptions.api.setRowData(prepareHoursLogGridData(vm.hoursLogList))
              vm.hoursLogAgOptions.api.redrawRows()
              vm.hoursLogAgOptions.api.sizeColumnsToFit()
            }
            $scope.$emit('STOPSPINNER')
          })
        }

        // Function to refresh Recordable Incidents Injuries
        vm.refreshRecIncInjData = () => {
          return new Promise((resolve, reject)=>{
            $q.all([
              adminTrifrService.getRecordableIncidentInjury(2),
              adminTrifrService.getRecordableIncidentInjury(1),
              adminTrifrService.getTrirIncidentTypeOption(),
              adminTrifrService.getRecordableIncidentInjury(3),
            ]).then((data) => {
              vm.recIncs = data[0].rii_rld_id
              vm.recInjs = data[1].rii_rld_id
              vm.recIncClass = data[3].rii_rld_id
              vm.recIncMetric = data[0].sys_setting_value
              vm.recInjMetric = data[1].sys_setting_value
              vm.trirIncidentTypeOption = data[2].trir_incident_type_option
              if(vm.trirIncidentTypeOption === 2){
                vm.recIncGridList = vm.recIncs
              } else if(vm.trirIncidentTypeOption === 3){
                vm.recIncGridList = vm.recIncClass
              }
              prepareRecordableIncInjTypeList()
              prepareRecordableIncInjClassList()
              if(vm.recIncs != null){
                vm.recIncAgOptions.api.setRowData(prepareRecIncGridData(vm.recIncGridList))
              }
              vm.recIncAgOptions.api.redrawRows()
              vm.recIncAgOptions.api.sizeColumnsToFit()
                
              if(vm.recInjs != null){
                vm.recInjAgOptions.api.setRowData(prepareRecInjGridData(vm.recInjs))
              }
              vm.recInjAgOptions.api.redrawRows()
              vm.recInjAgOptions.api.sizeColumnsToFit()
              resolve(true)
            })            
          })
        }

        //Function to refresh all data
        vm.refreshScreen = () => {
          $scope.$emit('STARTSPINNER', vm.loadMessage)
          $q.all([
            listService.getSelectListData('ref_preliminary_incident_type'),
            listService.getSelectListData('ref_incident_type'),
            adminTrifrService.getHoursLogList(),
            adminTrifrService.getLevelOfDetail(),
            adminTrifrService.getRecordableIncidentInjury(2),
            adminTrifrService.getRecordableIncidentInjury(1),
            adminTrifrService.getRecordableIncidentInjury(3),
            adminTrifrService.getTrirIncidentTypeOption(),
            adminTrifrService.getTrifrTrirTrackOption(),
            adminUserService.getSites(selectedLanguage),
            adminUserService.getJobs(selectedLanguage),
            profileService.getFullEmployeeProfile(),
          ]).then((data) => {
            resetHoursLogModal()
            vm.IncidentTypeList = data[0]
            vm.IncidentClassList = data[1]
            vm.hoursLogList = data[2]
            vm.levelOfDetail = data[3]
            vm.recIncs = data[4].rii_rld_id
            vm.recInjs = data[5].rii_rld_id
            vm.recIncClass = data[6].rii_rld_id
            vm.recIncMetric = data[4].sys_setting_value
            vm.recInjMetric = data[5].sys_setting_value
            vm.trirIncidentTypeOption = data[7].trir_incident_type_option
            if(vm.trirIncidentTypeOption === 2){
              vm.recIncGridList = vm.recIncs
            } else if(vm.trirIncidentTypeOption === 3){
              vm.recIncGridList = vm.recIncClass
            }
            vm.trifr_track_option = data[8].trifr_track_option
            vm.trir_track_option = data[8].trir_track_option
            vm.siteList = adminUserService.getSiteList()
            vm.jobList = adminUserService.getJobList()
            vm.fullEmployeeList = profileService.readFullEmployeeProfile()
            vm.jobList.forEach((job)=>{
                job.fullJob = `(${job.rld_code}) - ${job.rld_name}`
            })
            disableGridColumns()
            prepareRecordableIncInjTypeList()
            prepareRecordableIncInjClassList()
            if(vm.hoursLogList != null){
              translateAgGridHeader(vm.hoursLogAgOptions)
              vm.hoursLogAgOptions.api.setRowData(prepareHoursLogGridData(vm.hoursLogList))
              vm.hoursLogAgOptions.api.redrawRows()
              setTimeout(() => {
                vm.hoursLogAgOptions.api.sizeColumnsToFit()
              }, 120); // Added a timeout for resizing the columns of the grid so that it gets applied properly.
            } 
            if(vm.recIncs != null){
              vm.recIncAgOptions.api.setRowData(prepareRecIncGridData(vm.recIncGridList))
            }
            vm.recIncAgOptions.api.redrawRows()
            vm.recIncAgOptions.api.sizeColumnsToFit()

            if(vm.recInjs != null){
              vm.recInjAgOptions.api.setRowData(prepareRecInjGridData(vm.recInjs))
            }
            vm.recInjAgOptions.api.redrawRows()
            vm.recInjAgOptions.api.sizeColumnsToFit()
              
            $scope.$emit('STOPSPINNER')
          })
        }
        vm.refreshScreen()        

        // Function to enable and disable Grid Column based on LOD (Level of Detail)
        function disableGridColumns () {
          var sort_lod_1 = [
            {
              colId: "whl_end_date",
              sort: "desc",
            },
          ];
          var sort_lod_2 = [
            {
              colId: "whl_site_name",
              sort: "asc",
            },
            {
              colId: "whl_end_date",
              sort: "desc",
            },
          ];
          var sort_lod_3 = [
            {
              colId: "whl_site_name",
              sort: "asc",
            },
            {
              colId: "whl_job_name",
              sort: "asc",
            },
            {
              colId: "whl_end_date",
              sort: "desc",
            },
          ];
          if (vm.levelOfDetail == 1){
            vm.hoursLogAgOptions.columnApi.setColumnVisible('whl_job_name', false)
            vm.hoursLogAgOptions.columnApi.setColumnVisible('whl_site_name', false)
            vm.hoursLogAgOptions.api.setSortModel(sort_lod_1)
          }else if (vm.levelOfDetail == 2){
            vm.hoursLogAgOptions.columnApi.setColumnVisible('whl_site_name', true)
            vm.hoursLogAgOptions.columnApi.setColumnVisible('whl_job_name', false)
            vm.hoursLogAgOptions.api.setSortModel(sort_lod_2)
          }else if (vm.levelOfDetail == 3){
            vm.hoursLogAgOptions.columnApi.setColumnVisible('whl_site_name', true)
            vm.hoursLogAgOptions.columnApi.setColumnVisible('whl_job_name', true)
            vm.hoursLogAgOptions.api.setSortModel(sort_lod_3)
          }
          vm.hoursLogAgOptions.api.sizeColumnsToFit()
        }

        // Function to prepare Ag grid for Recordable Incident / Injuries
        function prepareRecIncGridData (list) {
          let input_list = JSON.parse(JSON.stringify(list))
          let gridData = []
          input_list.forEach((rec) => {
            gridData.push({
              "rld_id": vm.trirIncidentTypeOption == 3 ? getIncidentClassName(rec) : getIncidentTypeName(rec)
            })
          });
          return gridData
        }

        // Function to prepare Ag grid for Recordable Incident / Injuries
        function prepareRecInjGridData (list) {
          let input_list = JSON.parse(JSON.stringify(list))
          let gridData = []
          input_list.forEach((rec) => {
            gridData.push({
              "rld_id": getIncidentTypeName(rec)
            })
          });
          return gridData
        }

        // Function to prepare Recordable Incident /Injuries Type list for the modal
        function prepareRecordableIncInjTypeList () {
          vm.recIncInjTypeList = []
          vm.IncidentTypeList.forEach(rld=>{
            let incTypeObj = JSON.parse(JSON.stringify(rld))
            if (vm.recIncs.find(rec=>rec===rld.rld_id)){
              incTypeObj['inc_selected'] = true
            }
            else{
              incTypeObj['inc_selected'] = false
            }
            if (vm.recInjs.find(rec=>rec===rld.rld_id)){
              incTypeObj['inj_selected'] = true
            }
            else{
              incTypeObj['inj_selected'] = false
            }
            vm.recIncInjTypeList.push(incTypeObj) 
          })
          vm.splitInjTypeList(vm.recIncInjTypeList).then((split_list)=>{
            vm.left_inc_inj_type_list = split_list["left_list"]
            vm.right_inc_inj_type_list = split_list["right_list"]
          })
          
        }

        // Function to prepare Recordable Incident /Injuries Class list for the modal
        function prepareRecordableIncInjClassList () {
          vm.recIncInjClassList = []
          vm.IncidentClassList.forEach(rld=>{
            let incClassObj = JSON.parse(JSON.stringify(rld))
            if (vm.recIncClass.find(rec=>rec===rld.rld_id)){
              incClassObj['inc_selected'] = true
            }
            else{
              incClassObj['inc_selected'] = false
            }
            vm.recIncInjClassList.push(incClassObj) 
          })
          vm.splitInjTypeList(vm.recIncInjClassList).then((split_list)=>{
            vm.left_inc_class_list = split_list["left_list"]
            vm.right_inc_class_list = split_list["right_list"]
          })
          
        }

        vm.splitInjTypeList = (recIncInjList) =>{
          return new Promise((resolve, reject)=>{
            let result = {
              left_list: null,
              right_list: null
            }
            let rec_inc_inj_list = JSON.parse(JSON.stringify(recIncInjList))
            let left_list = rec_inc_inj_list.splice(0, (Math.ceil(rec_inc_inj_list.length/2)))
            let right_list = rec_inc_inj_list
            result["left_list"] = left_list
            result["right_list"] = right_list
            resolve(result)
          })
          
        }

        // Function to get Incident type names
        function getIncidentTypeName (id) {
          rld_obj = vm.IncidentTypeList.find((rld) => rld.rld_id ===id)
          if (rld_obj) {
            return rld_obj.rld_name
          }
        }

        // Function to get Incident Class names
        function getIncidentClassName (id) {
          rld_obj = vm.IncidentClassList.find((rld) => rld.rld_id ===id)
          if (rld_obj) {
            return rld_obj.rld_name
          }
        }

        // Function to prepare Ag grid for Hours Log list
        function prepareHoursLogGridData (hoursLogList) {
          let gridData = JSON.parse(JSON.stringify(hoursLogList))
          gridData.forEach((rec) => {
            rec.exceptionFields = ['review','whl_created_by_per','person_full_name','whl_site','whl_job','whl_modified_by_per','whl_level_of_detail','whl_enable','whl_enote']
            rec.review = ''
            rec.created_by = rec.whl_created_by_per ? get_employee_name(rec.whl_created_by_per) : null
            rec.whl_modified_date = rec.whl_modified_date !== null ? moment(rec.whl_modified_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD') : null
            rec.whl_created_date = rec.whl_created_date !== null ? moment(rec.whl_created_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD') : null
            rec.whl_start_date = rec.whl_start_date !== null ? moment(rec.whl_start_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD') : null
            rec.whl_end_date = rec.whl_end_date !== null ? moment(rec.whl_end_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD') : null
            rec.modified_by = rec.whl_modified_by_per ? get_employee_name(rec.whl_modified_by_per) : null
          });
          vm.hoursLogGridData = gridData
          return gridData
        }

        //Function to get employee name
        function get_employee_name(id){
          return vm.fullEmployeeList.find(emp=>emp.per_id == id).per_full_name
        }

        // Function to Cancel Modal
        vm.cancelModal = (modalId) =>{
          modalService.Close(modalId)
          if(modalId==='HoursLogModal'){
            if(vm.refreshFlag){
              vm.refreshGridData()
            }else{
              resetHoursLogModal()
            }
          }
          if(modalId==='LevelOfDetailModal'){
            adminTrifrService.getLevelOfDetail().then(response=>{
              vm.levelOfDetail = response
            })
          }
          if(modalId==='confirmModal'){
            vm.removeID = null
          }
        }
          
        //Function to export csv
        vm.exportCSV = () => {
          let rows = JSON.parse(JSON.stringify(vm.hoursLogAgOptions.api.getSelectedRows()))
          if (rows.length==0){
            throwToastr('error',translateTag(3816))
            return 
          }
          exportCSV.export_csv(rows, translateTag(2723))
        }
          
        //Function to get Jobs & Levels for a site
        vm.getJobs = () => { 
          resetDatesAndFlags()  
          if(vm.currentMode === 'new'){
            if (vm.levelOfDetail == 2){
              vm.getLastEndDate() 
              return 
            }
          }else{
            if(vm.currentRecord.whl_level_of_detail === 2){
              return
            }
          }
          vm.jobListSelect = []
          if(vm.currentRecord.whl_site === undefined || vm.currentRecord.whl_site === null){
              vm.currentRecord.whl_job = null
              return
          } 
          vm.jobList.forEach((rec) => {
              if(rec.rld_parent_detail_rld_id === vm.currentRecord.whl_site)
                  vm.jobListSelect.push(rec)
          })
        }
        
        //Funcion to get the last end date as per level of detail
        vm.getLastEndDate = () => {
          resetDatesAndFlags()
          let sys_setting_type = vm.levelOfDetail
          let rld_id = 0
          if (vm.levelOfDetail == 3){
            rld_id = vm.currentRecord.whl_job ? parseInt(vm.currentRecord.whl_job) : 0
          }
          else if(vm.levelOfDetail == 2) {
            rld_id = vm.currentRecord.whl_site ? parseInt(vm.currentRecord.whl_site) : 0
          }
          adminTrifrService.getLastEndDate(sys_setting_type, rld_id).then((response) => {
            if (response && response.length>0) {
              vm.currentLastRecEndDate = moment(response[0].whl_end_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
            }
            else{
              vm.currentLastRecEndDate = null
            }
          })
        }

        // Function to reset dates and its flags when site and job changes as the notification message depends on site and job
        function resetDatesAndFlags() {
          if (!vm.refreshDates){
            if(vm.currentMode==='edit'){
              vm.refreshDates = true
            }else{
              vm.currentRecord.whl_start_date = null
              vm.currentRecord.whl_end_date = null
              vm.diffDates = null
              vm.typeOfDiff = null
            }
          }else{
            vm.currentRecord.whl_start_date = null
            vm.currentRecord.whl_end_date = null
            vm.diffDates = null
            vm.typeOfDiff = null
          }
        }

        // FUnction to enable/disable Site and Job as per Level Of Detail
        function changeFieldsAsPerLOD () {
          vm.showSite = false
          vm.showJob = false
          if(vm.currentMode==='new') {
            if(vm.levelOfDetail==2 || vm.levelOfDetail==3){
              vm.showSite = true
            }
            if(vm.levelOfDetail==3){
              vm.showJob = true
            }
            return
          }
          else{
            if(vm.currentRecord.whl_level_of_detail==2 || vm.currentRecord.whl_level_of_detail==3){
              vm.showSite = true
            }
            if(vm.currentRecord.whl_level_of_detail==3){
              vm.showJob = true
            }
            return
          }
        }
        
        // Function to open Modal for adding a record
        vm.openHoursLogModal = (modalId) => {
          resetHoursLogModal()
          vm.currentMode = 'new'
          changeFieldsAsPerLOD()
          if(vm.levelOfDetail==1){
            vm.getLastEndDate()
          }
          modalService.Open(modalId)
          vm.initializeSelect2(modalId)
        }

        // Function to open Modal for Level of detail
        vm.openLODModal = (modalId) => {
          modalService.Open(modalId)
        }

        // Function to open Modal for Recordable Incidents / Injuries
        vm.openRecordableIncInjModal = (modalId) => {
          vm.refreshRecIncInjData().then(()=>{
            modalService.Open(modalId)
          })
        }

        //Function to open Archive confirmation modal
        vm.openRemoveRecordModal = (id) =>{
          vm.removeID = id
          vm.modalElements = {
            title: translateLabels(4271),  //"Archive?"
            message: `<div><p>${translateTag(4272)}</p></div>`, //"You are about to archive. Undoing this will require IT support. Are you sure?"
            buttons: 
                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Yes">{{vm.componentTranslateLabels(1379)}}</button>
                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
          }
          document.getElementById('confirmcallingform').innerHTML = 'RETURNCOMMENTCONFIRMRESULT' 
          $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("RETURNCOMMENTCONFIRMRESULT", (event,result) => {
          if (result=='button1') {
              vm.removeRecord('confirmModal')
          }
        })

        vm.changeRecIncInjTrackOption = (track_type) => {
          let payload = {
            track_type: track_type,
            track: track_type === "TRACK TRIR" ? vm.trir_track_option : vm.trifr_track_option
          }
          adminTrifrService.updateTrifrTrirTrackOption(payload)
        }

        // Function to save Recordable Incidents / Injuries
        vm.saveRecIncInj = (modalId) => {
          let rii_type = null
          let sys_setting_type = null
          let type = null
          if(modalId==="RecordableInjModal"){
            type = 'inj_selected'
            rii_type = 1
            sys_setting_type = 1
          }
          else if(modalId==="RecordableIncModal"){
            type = 'inc_selected'
            rii_type = vm.trirIncidentTypeOption
            sys_setting_type = 2
          }
          
          let inputPayload = {
            "rii_type": rii_type,
            "rii_rld_id": [],
            "sys_setting_type": sys_setting_type,
            "sys_setting_value": sys_setting_type == 1 ? vm.recInjMetric : vm.recIncMetric
          }
          
          if (rii_type != '3') {
            let rec_inc_inj_list = vm.left_inc_inj_type_list.concat(vm.right_inc_inj_type_list)
            rec_inc_inj_list.forEach(obj=>{
              if(obj[type]){
                inputPayload['rii_rld_id'].push(obj.rld_id)
              }
            })
          }else{
            let rec_inc_inj_list = vm.left_inc_class_list.concat(vm.right_inc_class_list)
            rec_inc_inj_list.forEach(obj=>{
              if(obj[type]){
                inputPayload['rii_rld_id'].push(obj.rld_id)
              }
            })
          }
          
          
          adminTrifrService.updateRecordableIncidentInjury(inputPayload).then(response=>{
            if(response==='Failed'){
              throwToastr('error',translateTag(3857))
            }else{
              throwToastr('success',translateTag(4279))
            }
            modalService.Close(modalId)
            vm.refreshRecIncInjData()
          })
        }

        // Function to validate Hours worked field after the class 'was-validate' is added
        vm.validateWorkHoursField = () => {
          let formValCheck = document.forms['hoursLogForm']
          if(formValCheck.classList.contains('was-validated')){
            let whl_element = document.getElementById('whl_hours_worked')
            if (whl_element.value>9999999999999.99){
              whl_element.classList.add('invalid')
              whl_element.setCustomValidity(false)
            }else{
              whl_element.classList.remove('invalid')
              whl_element.setCustomValidity("")
            }
          } 
        }

        //Function to validate Record Hours Modal
        vm.validateRecordHours = () => {
          let formVal = document.forms['hoursLogForm']
          formVal.classList.add('was-validated')
          let validated = true
          for (let a = 0; a < formVal.length; a++) {
            if(formVal[a].id==="whl_hours_worked"){
              vm.validateWorkHoursField()
            }
            if (!formVal[a].validity.valid) {
                validated = false
            }
          } 
          return validated               
        }

        // Function to open Modal for editing a record
        vm.editHoursLogModal = (modalId, id) => {
          vm.currentMode = 'edit'
          $q.all([
            adminTrifrService.getSingleHoursLog(id)
          ]).then((data) => {
            vm.currentRecord = data[0]
            vm.currentRecord.whl_start_date = vm.currentRecord.whl_start_date !== null ? moment(vm.currentRecord.whl_start_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD') : null
            vm.currentRecord.whl_end_date = vm.currentRecord.whl_end_date !== null ? moment(vm.currentRecord.whl_end_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD') : null
            vm.currentRecord.whl_hours_worked = parseFloat(vm.currentRecord.whl_hours_worked)
            vm.getJobs()
            changeFieldsAsPerLOD()
            modalService.Open(modalId)
            vm.initializeSelect2(modalId)
          })
        }

        //Function to prepare individual object for grid data
        function prepareObjForGridData (rec) {
          rec.exceptionFields = ['review','whl_created_by_per','person_full_name','whl_site','whl_job','whl_modified_by_per','whl_modified_by_per_id','whl_level_of_detail']
          rec.review = ''
          rec.created_by = rec.person_full_name.created_by!==undefined ? rec.person_full_name.created_by : null
          rec.whl_modified_date = rec.whl_modified_date !== null ? moment(rec.whl_modified_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD') : null
          rec.whl_created_date = rec.whl_created_date !== null ? moment(rec.whl_created_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD') : null
          rec.whl_start_date = rec.whl_start_date !== null ? moment(rec.whl_start_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD') : null
          rec.whl_end_date = rec.whl_end_date !== null ? moment(rec.whl_end_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD') : null
          rec.modified_by = rec.person_full_name.modified_by!==undefined ? rec.person_full_name.modified_by : null
          return rec
        } 

        // Function to add record to Hours log AG grid data
        function addToHoursLogGridData (rec) {
          let model = vm.hoursLogAgOptions.api.getFilterModel()
          vm.hoursLogGridData.push(prepareObjForGridData(rec))
          vm.hoursLogAgOptions.api.setRowData(vm.hoursLogGridData)
          vm.hoursLogAgOptions.api.redrawRows()
          vm.hoursLogAgOptions.api.sizeColumnsToFit()
          vm.hoursLogAgOptions.api.setFilterModel(model)
        }

        // Function to remove a record
        vm.removeRecord = (modalId) => {
          adminTrifrService.removeHoursLog(vm.removeID).then((response) => {
            if(response==='Failed'){
              throwToastr('error',translateTag(3857))
              vm.cancelModal(modalId)
            }else{
              throwToastr('success',translateTag(4279))
              removeRecordFromHoursLogGridData(vm.removeID)
              vm.cancelModal(modalId)
            }
          })
        }

        // Function to remove record from Hours Log Grid data
        function removeRecordFromHoursLogGridData (id) {
          obj_index = vm.hoursLogGridData.findIndex(whl => whl.whl_id === id)
          vm.hoursLogGridData.splice(obj_index, 1)
          vm.hoursLogAgOptions.api.setRowData(vm.hoursLogGridData)
          vm.hoursLogAgOptions.api.redrawRows()
          vm.hoursLogAgOptions.api.sizeColumnsToFit()
        }

        // Function to save a record
        vm.saveHoursLog = () => {
          if(!vm.validateRecordHours()){
            $rootScope.$broadcast("CALLCONFIRMMODAL")
          }
          else{
            if (vm.currentMode === 'new'){
              vm.currentRecord.whl_level_of_detail = parseInt(vm.levelOfDetail)
              vm.currentRecord.whl_end_date = moment(vm.currentRecord.whl_end_date, 'YYYY-MM-DD').format('YYYY-MM-DDThh:mm')
              vm.currentRecord.whl_start_date = moment(vm.currentRecord.whl_start_date, 'YYYY-MM-DD').format('YYYY-MM-DDThh:mm')
  
              adminTrifrService.addHoursLog(JSON.parse(JSON.stringify(vm.currentRecord))).then((response) => {
                if(response==='Failed'){
                  throwToastr('error',translateTag(3857))
                  resetHoursLogModal()
                  modalService.Close('HoursLogModal')
                  return
                }
                addToHoursLogGridData(response)
                throwToastr('success',translateTag(4278))
                if(vm.addAnother){
                  vm.addAnother = false
                  vm.refreshFlag = true
                  document.forms['hoursLogForm'].classList.remove('was-validated')
                  resetHoursLogModal()
                  vm.initializeSelect2("HoursLogModal")
                }
                else{
                    document.forms['hoursLogForm'].classList.remove('was-validated')
                    modalService.Close('HoursLogModal')
                    vm.addAnother = false
                    vm.refreshFlag = false
                    resetHoursLogModal()
                }
              })
            }
            else{
              
              vm.currentRecord.whl_end_date = moment(vm.currentRecord.whl_end_date, 'YYYY-MM-DD').format('YYYY-MM-DDThh:mm')
              vm.currentRecord.whl_start_date = moment(vm.currentRecord.whl_start_date, 'YYYY-MM-DD').format('YYYY-MM-DDThh:mm')
              
              adminTrifrService.updateHoursLog(JSON.parse(JSON.stringify(vm.currentRecord))).then((response)=> {
                if(response==='Failed'){
                  throwToastr('error',translateTag(3857))
                  resetHoursLogModal()
                  modalService.Close('HoursLogModal')
                  return
                }
                updateHoursLogAgGrid(response)
                throwToastr('success',translateTag(4279))
                modalService.Close('HoursLogModal')
              })
            }
          }          
        }

        //Function to update a record in Hours Log Grid data
        function updateHoursLogAgGrid(rec) {
          obj_index = vm.hoursLogGridData.findIndex(whl => whl.whl_id === rec.whl_id)
          vm.hoursLogGridData.splice(obj_index, 1)
          let model = vm.hoursLogAgOptions.api.getFilterModel()
          vm.hoursLogGridData.push(prepareObjForGridData(rec))
          vm.hoursLogAgOptions.api.setRowData(vm.hoursLogGridData)
          vm.hoursLogAgOptions.api.redrawRows()
          vm.hoursLogAgOptions.api.sizeColumnsToFit()
          vm.hoursLogAgOptions.api.setFilterModel(model)
          resetHoursLogModal()
        }

        //Save Level of detail
        vm.saveLOD = (modalId) => {
          adminTrifrService.updateLevelOfDetail(vm.levelOfDetail).then(response=>{
            if(response==='Failed'){
              throwToastr('error',translateTag(3857))
              modalService.Close(modalId)
              return
            }
            throwToastr('success',translateTag(4279))
            disableGridColumns()
            modalService.Close(modalId)
          })
        }

        //Update Ag-Grid size when window is resized
        $(window).on('resize', () => {
          $timeout(function () {
              if (vm.hoursLogAgOptions.api) {
                vm.hoursLogAgOptions.api.sizeColumnsToFit()
              }
          })
        })

        //Funtion to initialize select2
        vm.initializeSelect2 = (parent)=> {
            setTimeout(()=>{ 
            $('.select-single, .select-multiple')
            .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} .modal-body`), escapeMarkup: function (text) { return text } })
            .on('select2:select', () => {
                $(this).parent().find('label').addClass('filled');
            })

            $('.select2-selection__arrow b').addClass("fa fa-caret-down");                  // Add caret on selects
            select2Service.select2Tags()
            }, 100)
          
            if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
            
            
            $('.end_datepicker').pickadate({
              format: 'yyyy-mm-dd',
              // Set min date for end date picker in edit mode
              onOpen: function () {
                if(vm.currentRecord.whl_start_date && vm.currentMode==='edit') {
                  end_picker.set("min", vm.currentRecord.whl_start_date)
                }
                if(vm.currentRecord.whl_end_date){
                  end_picker.set("highlight", vm.currentRecord.whl_end_date) 
                }
              },
              onClose : function(){
                this.$holder.blur()
            },
            }).removeAttr('readonly')
            .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
              evt.preventDefault()
            })

            var $end_picker_obj = $('.end_datepicker').pickadate()
            var end_picker = $end_picker_obj.pickadate('picker')

            //Start date picker for editing a hours log record
            $('.start_datepicker').pickadate({
              format: 'yyyy-mm-dd',
              onSet: function() {
                vm.currentRecord.whl_end_date = null                      // Resetting end_date if start_date changes
                if(vm.currentRecord.whl_start_date){                      // Setting min date for end_datepicker if start_date is not null
                  end_picker.set("min", vm.currentRecord.whl_start_date)
                }
                $scope.$apply();
              },
              onClose : function(){
                this.$holder.blur()
            },
            }).removeAttr('readonly')
            .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
              evt.preventDefault()
            })

            //Start date picker for adding a new hours log record
            $('.new_start_datepicker').pickadate({
              format: 'yyyy-mm-dd',
              // Highlighting the last recorded End date in the new start date picker
              onOpen: function () {
                if(!vm.currentRecord.whl_start_date) {
                  if (vm.currentLastRecEndDate){
                    new_start_picker.set("highlight", vm.currentLastRecEndDate) 
                  } else {
                    new_start_picker.set("highlight", new Date())
                  }
                }
              },
              onClose : function(){
                this.$holder.blur()
              },
              onSet: function() {
                vm.currentRecord.whl_end_date = null                      // Resetting end_date if start_date changes
                if(vm.currentRecord.whl_start_date){                      // Setting min date for end_datepicker if start_date is not null
                  end_picker.set("min", vm.currentRecord.whl_start_date)
                }
                
                // Below is the logic to display the gap / overlap between the last recorded end date and current start_date
                if(!vm.currentRecord.whl_start_date) {                     
                  vm.diffDates = null
                }else if (vm.currentLastRecEndDate){
                  vm.diffDates = moment(vm.currentRecord.whl_start_date).diff(moment(vm.currentLastRecEndDate), 'days')
                }else{
                  vm.diffDates = null
                }
                if(vm.diffDates > 1){
                  vm.typeOfDiff = 'gap'
                }else if(vm.diffDates < 0){
                  vm.typeOfDiff = 'overlap'
                }else {
                  vm.typeOfDiff = null
                }
                vm.diffDates = Math.abs(vm.diffDates)
                $scope.$apply();
              }
            }).removeAttr('readonly')
            .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
              evt.preventDefault()
            })

            var $new_start_picker_obj = $('.new_start_datepicker').pickadate()
            var new_start_picker = $new_start_picker_obj.pickadate('picker')
        }
      }
])