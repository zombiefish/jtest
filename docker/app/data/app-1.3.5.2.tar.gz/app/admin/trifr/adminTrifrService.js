angular
  .module('safeToDo')
  .service('adminTrifrService', ['$http', '$location','$window',
    function ($http, $location, $window) {
        return {
            getHoursLogList: () => {
                return $http.get(`${__env.apiUrl}/api/whl/get-all-work-hours-log`).then((response) => { 
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to load Hours log records', errorParams)
                });
            },
            addHoursLog: (payload) => {
                return $http.post(`${__env.apiUrl}/api/whl/add-work-hours-log/`, payload).then((response) => {
                    return response.data
                },(errorParams) => {
                    console.log('Failed to add hours log because of the error', errorParams.data)
                    return "Failed"
                });
            },
            updateHoursLog: (payload) => {
                return $http.put(`${__env.apiUrl}/api/whl/update-work-hours-log/${payload.whl_id}/`, payload).then((response) => {
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to update hours log because of the error', errorParams.data)
                    return "Failed"
                });
            },
            removeHoursLog: (whl_id) => {
                return $http.delete(`${__env.apiUrl}/api/whl/remove-work-hours-log/${whl_id}/`).then((response) => {
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to remove hours log record', errorParams)
                    return "Failed"
                });
            },
            getSingleHoursLog: (whl_id) => {
                return $http.get(`${__env.apiUrl}/api/whl/get-single-work-hours-log/${whl_id}`).then((response) => {                 
                    var hoursLog = response.data
                    return hoursLog
                }, (errorParams) => {
                    console.log('Failed to load single Hours log record', errorParams)
                });
            },
            getLastEndDate: (sys_setting_type, rld_id) => {
                return $http.get(`${__env.apiUrl}/api/whl/get-last-end-date/?sys_setting_type=${sys_setting_type}&rld_id=${rld_id}`).then((response) => {                 
                    var lastEndDate = response.data
                    return lastEndDate
                }, (errorParams) => {
                    console.log('Failed to get last recorded End date', errorParams)
                });
            },
            getLevelOfDetail: () => {
                return $http.get(`${__env.apiUrl}/api/whl/get-level-of-detail-setting/`).then((response) => { 
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to get level of detail', errorParams)
                });
            },
            getTRIFRData: (payload) => {
                return $http.post(`${__env.apiUrl}/api/whl/get-trifr-home-data/`, payload).then((response) => {
                    return response.data
                }, (args) => {
                    console.log('Failed to load TRIFR data', args)
                });
            },
            updateLevelOfDetail: (value) => {
                return $http.put(`${__env.apiUrl}/api/whl/update-level-of-detail-setting/${value}/`).then((response) => {                 
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to update level of detail because of the error', errorParams.data)
                    return "Failed"
                });
            },
            getRecordableIncidentInjury: (type) => {
                return $http.get(`${__env.apiUrl}/api/whl/get-recordable-incident-injury/${type}/`).then((response) => {                 
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to get Recordable Incident Injury data', errorParams)
                });
            },
            getTrirIncidentTypeOption: () => {
                return $http.get(`${__env.apiUrl}/api/whl/get-trir-incident-type-option/`).then((response) => {                 
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to get Recordable Incident Injury data', errorParams)
                });
            },
            getTrifrTrirTrackOption: () => {
                return $http.get(`${__env.apiUrl}/api/whl/get-trifr-trir-track-option/`).then((response) => {                 
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to get TRIFR TRIR Track option', errorParams)
                });
            },
            updateRecordableIncidentInjury: (payload) => {
                return $http.put(`${__env.apiUrl}/api/whl/update-recordable-incident-injury/${payload.rii_type}/`, payload).then((response) => {
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to update Recordable Incident Injury data because of the error', errorParams.data)
                    return "Failed"
                });
            },
            updateTrifrTrirTrackOption: (payload) => {
                return $http.put(`${__env.apiUrl}/api/whl/update-trifr-trir-track-option/${payload.track_type}/`, payload).then((response) => {
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to update TRIFR TRIR Track option because of the error', errorParams.data)
                    return "Failed"
                });
            },
        }
    }

])