angular
    .module('safeToDo')
    .service('adminTargetService', ['$http',
        function ($http) {
            let targetRecords = []
            let formRecords = []
            return {
                // Retrieves list of forms
                getFormList: (mode = "active") => {
                    return $http.get(`${__env.apiUrl}/api/form/get-all-top-forms/${mode}/`).then((response) => {
                        formRecords = response.data
                    }, (errorParams) => {
                        console.log('Failed to load Form Records', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            formRecords = []                            
                        }
                        else
                            toastr.error(errorParams.data.error)
                    })
                },                
                getTargetRecords: () => {
                    return $http.get(`${__env.apiUrl}/api/target/get-all-targets/`).then((response) => {
                        targetRecords = response.data
                    }, (errorParams) => {
                        console.log('Failed to retrieve Target Records', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            targetRecords = []        
                            window.location.href = "/";                    
                        }
                    })
                },
                saveTargetRecord: (payload) => {
                    // console.log("This is the add target payload", JSON.stringify(payload))
                    return $http.post(`${__env.apiUrl}/api/target/add-target/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to save Target Record', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else
                            toastr.error(errorParams.data.error)
                    })
                },
                updateTargetRecord: (payload) => {
                    // console.log("This is the update target payload",  JSON.stringify(payload))
                    return $http.post(`${__env.apiUrl}/api/target/add-target/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to update Target Record', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else
                            toastr.error(errorParams.data.error)
                    })
                },
                deleteTargetRecord: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/target/delete-target/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to delete Target Record', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else
                            toastr.error(errorParams.data.error)
                    })
                },
                deleteAllUserTargetRecords: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/target/delete-user-targets/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to delete Target Records', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        else
                            toastr.error(errorParams.data.error)
                    })
                },
                // Returns list of forms
                readFormList: () => {
                    return formRecords
                },
                readTargetRecords: () => {
                    return targetRecords
                }
            }
        }
    ])