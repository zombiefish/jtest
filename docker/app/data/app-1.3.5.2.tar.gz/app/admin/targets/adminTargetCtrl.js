﻿angular
    .module('safeToDo')
    .controller('AdminTargetsCtrl', ['$scope','$rootScope', '$filter', '$timeout', '$q', '$window', '$sce', 'gridService', 'select2Service', 'profileService', 
      'adminTargetService', 'listService', 'modalService', 'adminRoleService', '$compile', 'menuService','exportCSV',
      function ($scope,$rootScope, $filter, $timeout, $q, $window, $sce, gridService, select2Service, profileService, adminTargetService, listService, modalService, adminRoleService, $compile, menuService, exportCSV) {
        var vm = this
        
        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        vm.personProfile = []
        vm.targets = []
        vm.fullEmployeeList = []
        vm.frequencyList = []
        vm.formList = []
        vm.allFormList = []
        vm.addAnother = false
        vm.showAnother = true
        vm.fieldDisabled = true
        vm.deleteMsg = ''
        vm.deleteTargetModalData = null
        vm.topSearch = ''
        vm.targetData = []
        vm.actionDisabled = true
        vm.roles = []
        vm.loadMessage = translateTag(3891) //Loading user targets. Please wait.
        vm.singleServeReportUrl = 'targets_change_log'
        vm.deletingReason = ''
        vm.validateDelete = false

        //Get permissions for the user
        menuService.getPagePermissions().then((data) => {
            vm.permissions = data            
            vm.canArchiveSubmissions = vm.permissions.includes('Can Manage Targets') ? true : false 
        })

        //Function to reset new form
        vm.resetForm = () => {
            resetFormFieldClassList('targetRecords')
            document.forms['targetRecords'].classList.remove('was-validated')
            vm.submitted = false
            vm.currentTargetRecord = 
            {
                id: null,
                per_id: null,    
                fdformid: null,
                sta_fob_id:null,
                target: null,
                frequencyid: null,
                effectiveon: dateToday.format("YYYY-MM-DD"),
                modified_date: dateToday.format("YYYY-MM-DD"),
                modified_by: null,
                sta_context: null,
                stc_comment: null,
                currentMode:null
            }
        }  
        
        vm.targetOptions = gridService.getCommonOptions()
        vm.targetOptions.pagination = false

        // Calling a function to display the number of filtered records when filter changes
        vm.targetOptions.onFilterChanged = () => {
            setTotalRowsForMasterDetailGrid("total_number_records", vm.targetOptions.api.getDisplayedRowCount())
        }

        //Fucntion for the top search bar
        vm.topSearchChanged = () =>{
          vm.targetOptions.api.setQuickFilter(vm.topSearch)
          // Setting total number of displayed rows when filter changes
          setTotalRowsForMasterDetailGrid("total_number_records", vm.targetOptions.api.getDisplayedRowCount())
        }

        //Function to disable action button if no rows are selected
        vm.targetOptions.onSelectionChanged = () => {
            
          var selectedRows = vm.targetOptions.api.getSelectedRows()
          vm.actionDisabled = selectedRows.length == 0
          $scope.$apply()
        }

        //Funtion to open a report in a new tab
        vm.viewReports = (e, id) =>{
            let st_dt = new Date()
            let end_dt = new Date()
            end_dt.setDate(end_dt.getDate() + 30)
            let enddate = moment(end_dt, 'YYYY-MM-DD').format("MM/DD/YYYY")
            st_dt.setDate(st_dt.getDate() - 30)
            let startDate = moment(st_dt, 'YYYY-MM-DD').format("MM/DD/YYYY")
            if(!e.ctrlKey)
            {
                lang_number = localStorage.getItem('lang_id')
                vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.singleServeReportUrl}/${id}?lang=${lang_number}`)
              //  vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/pentaho/api/repos/%3A${window.__env.pentahoPath}%3A${vm.singleServeReportUrl}/viewer?userid=${__env.pentahoUserName}&password=${window.__env.pentahoPassword}&id=${id}&paramstartdate=${startDate}&paramenddate=${enddate}&paramurl=${__env.pentahoImagesUrl}&output-target=pageable/pdf`)
                $window.open(vm.reportURL, "_blank")
            }
        }

        //Set parget target Ag-Grid colum values/settings
        let targetColumns = [
            {
                headerName: '',
                field: 'dummyCheckbox',
                maxWidth: 60,
                minWidth: 60,
                checkboxSelection: true,
                suppressMenu: true,
                suppressSorting: true,
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
            },
            {
                field: "review",
                headerName: " ",
                maxWidth: 100,
                minWidth: 100,
                suppressMenu: true,
                suppressSorting: true,
                cellRenderer: (params) => {
                    return `<span class="pointer text-left" ng-click="admtargets.viewReports($event, ${params.data.per_id})"><i class="fa fa-external-link-alt" note="Launch Report" title="{{menu.translateLabels(3429)}}"></i></span>`
                },                    
            },
            {
                field: "per_name",
                headerName: " ",
                minWidth:200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                showRowGroup: true,
                cellRenderer:'agGroupCellRenderer',
                sort: 'asc',
                getQuickFilterText: function(params) {
                return params.value
                },
                cellRendererParams: {
                innerRenderer: (params) => {
                    return `<span class="clip" ng-non-bindable>${params.value}</span>`
                }
                }
            },            
            {
                field: "", maxWidth: 40, minWidth: 40, suppressMenu: true, suppressSorting: true,
                cellRenderer: (params) => {
                return `<div class="pointer text-left" ng-if="admtargets.canArchiveSubmissions" note="Delete Item" title="{{menu.translateLabels(3892)}}" ng-click="admtargets.deleteTargetModal(${params.data.per_id}, 'user')"><i class="far fa-trash-alt fa-lg"></i></div>`;
                }
            },
            {
                field: "search",
                hide: true,
                filter: 'agSetColumnFilter',
                getQuickFilterText: (params) => {
                let searchBlob = ''
                    params.data.targets.forEach((rec)=>{ 
                    searchBlob += `"${getFormName(rec.fdformid)}",`
                    searchBlob += `"${rec.target}",`
                    searchBlob += `"${getFrequencyName(rec.frequencyid)}",`
                    searchBlob += `"${rec.effectiveon}",`
                    searchBlob += `"${rec.modified_date}",`
                    searchBlob += `"${getEmployeeName(rec.modified_by)}"` 
                    })
                return searchBlob
                }            
            }
        ]
        
        vm.targetOptions.columnDefs = targetColumns
        vm.targetOptions.masterDetail = true
        vm.targetOptions.animateRows = false
        vm.targetOptions.suppressVerticalScroll = true
        vm.targetOptions.scrollbarWidth = 0

        //Set child Ag-Grid colum values/settings
        vm.targetOptions.detailCellRendererParams = {
            detailGridOptions: {

                enableSorting:true,
                enableFilter:true,
                animateRows: true,
                suppressMovableColumns: true,
                suppressHorizontalScroll: false,
                suppressVerticalScroll: true,
                scrollbarWidth: 0,
                suppressRowClickSelection: true,

                showToolPanel: false,
                rowBuffer:999999,
                toolPanelSuppressRowGroups: true,
                toolPanelSuppressValues: true,
                toolPanelSuppressPivots: true,
                toolPanelSuppressPivotMode: true,
                toolPanelSuppressSideButtons: true,
                suppressContextMenu: true,
                icons: {
                    sortAscending: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"7\" height=\"6\" viewBox=\"0 0 7 6\"><path fill=\"#979797\" fill-rule=\"evenodd\" d=\"M3.5 0L7 6H0z\"/></svg>",
                    sortDescending: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"7\" height=\"6\" viewBox=\"0 0 7 6\"><path fill=\"#979797\" fill-rule=\"evenodd\" d=\"M3.5 0L7 6H0z\"/></svg>",
                    menu: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"13\" height=\"11\" viewBox=\"0 0 13 11\"><g fill=\"none\" fill-rule=\"evenodd\" stroke-linecap=\"round\"><path d=\"M.5.5h12M.5 5.5h12M.5 10.5h12\"/></g></svg>",
                    filter: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"18\" height=\"16\" viewBox=\"0 0 18 16\"><path fill=\"#979797\" fill-rule=\"evenodd\" d=\"M18 0H0l8 8v7.5l2-2V8z\"/></svg>",
                    checkboxUnchecked: "<img src=\"images/checkbox.svg\" />",
                    checkboxChecked: "<img src=\"images/checkbox-selected.svg\" />",
                    checkboxIndeterminate: "<img src=\"images/checkbox-partial.svg\" />"
                },
                components: {
                    tippyCellRenderer: TippyCellRenderer
                },
                columnDefs: [
                {
                    field: "review", 
                    headerName: " ",  
                    minWidth: 60,
                    maxWidth: 60,
                    suppressMenu: true, 
                    suppressSorting: true,

                    cellRenderer: function (params) {
                    return `<div class="pointer text-left" ng-click="admtargets.openModal('targetModal','edit','${params.data.id}')"><i class="fa fa-pen" note="Edit" title="{{menu.translateLabels(1194)}}"></i></div>`;
                    },
                    pinned: true
                },
                {
                    field: "effectiveon",
                    headerName: " ",
                    minWidth:150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: "tippyCellRenderer"
                }, 
                {
                    field: "target_form_id",
                    headerName: " ",
                    minWidth:250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: "tippyCellRenderer" 
                },
                {
                    field: "target",
                    headerName: " ",
                    minWidth:100,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: "tippyCellRenderer"
                },
                {
                    field: "frequencyid",
                    headerName: " ",
                    minWidth:150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer:  "tippyCellRenderer"
                },
                {
                    field: "sta_modified_date",
                    headerName: " ",
                    minWidth: 160,
                    maxWidth: 160,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: gridService.dateCellRenderer
                },
                {
                    field: "sta_modified_by_per",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 200,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: "tippyCellRenderer"
                },
                {
                    field: "", 
                    minWidth: 40, 
                    maxWidth: 40, 
                    suppressMenu: true, 
                    suppressSorting: true,
                    headerName: "",
                    pinned: 'right',
                    cellRenderer: (params) => {
                    return `<div class="pointer text-left" ng-if="admtargets.canArchiveSubmissions" note="Delete Item" title="{{menu.translateLabels(3892)}}" ng-click="admtargets.deleteTargetModal(${params.data.id}, 'target')"><i class="far fa-trash-alt fa-lg"></i></div>`;
                    }
                }
                ],
                rowHeight: 40,
                headerHeight: 35,
                localeText: sofvie_agGrid_languages[`${selectedLanguage}`]
            },
            getDetailRowData: (params) => {
                params.successCallback(prepareDetailTargetGridData(params.data.targets))
                vm.targetOptions.api.forEachDetailGridInfo(function(detailGridInfo) {
                    translateAgGridHeader(detailGridInfo)
                    detailGridInfo.api.sizeColumnsToFit()
                })
            },
        }

        // functions to get the Na"me from ID
        function getEmployeeName(value) {
          let name = value
          vm.fullEmployeeList.forEach((emp)=>{
            if(emp.per_id == value) {
              name = emp.per_full_name
            }
          })
          return name
        }

        function getFormName(value) {
          let name = "No Form"
          vm.allFormList.forEach((f)=>{
            if(f.FormID == value) {
              name = f.FormName
            }
          })
          return name
        }
        
        function getFrequencyName(value) {
          let name = value
          vm.frequencyList.forEach((f)=>{
            if(f.rld_code == value) {
              name = f.rld_name
            }
          })
          return name
        }

        //Function to launch the report
        vm.viewReport = () =>{
            lang_number = localStorage.getItem('lang_id')
            let rows = vm.targetOptions.api.getSelectedRows() 
            let a = 0
            rows.forEach(emp => {  
                vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/vfl_audit/123${a}?lang=${lang_number}`)          
             //   vm.reportURL = $sce.trustAsResourceUrl(`${__env.pentahoUrl}/pentaho/api/repos/%3A${window.__env.pentahoPath}%3Avflaudit.prpt/viewer?userid=${__env.pentahoUserName}&password=${window.__env.pentahoPassword}&paramid=123${a}&paramurl=${__env.pentahoImagesUrl}&output-target=pageable/pdf`)
                $window.open(vm.reportURL, "_blank")
                a++
            })
        }
        
        //Function to export csv
        vm.exportCSV = () => {            
            let rows = JSON.parse(JSON.stringify(vm.targetOptions.api.getSelectedRows()))           

            rows.forEach(emp => {
                emp.targets.forEach(tr => {
                    tr['fdformid'] = getFormName(tr.fdformid)
                    tr['frequencyid'] = getFrequencyName(tr.frequencyid)
                    tr['sta_modified_by_per'] = getEmployeeName(tr.sta_modified_by_per)
                })
            })
            rows = exportCSV.split_nested_lists(rows, 'targets')            
            exportCSV.export_csv(rows, translateTag(3884))
        }

        //Function to submit a target
        vm.saveTargetRecord = (modalId) => {          
            if(vm.ValidateTargetRecord())
            {
                vm.submitted = true
                let selectedFormID = ''
                let selectedFobID = ''
                if(vm.formList){
                    vm.formList.forEach(form =>{
                        if(vm.currentTargetRecord.fdformid == form.FormID){
                            if(form.FormType == "Pre-Defined Categories"){
                                selectedFormID = form.FormID.split('-')[0]
                                selectedFobID = null
                            }
                            else {
                                selectedFobID = form.FormID.split('-')[0]
                                selectedFormID = null
                            }
                        }
                    })
                }
                if(vm.currentMode === 'new'){           
                    let newTargetRecord = JSON.parse(JSON.stringify(vm.currentTargetRecord)) 
                    newTargetRecord.fdformid = selectedFormID
                    newTargetRecord.sta_fob_id = selectedFobID
                                      
                    adminTargetService.saveTargetRecord(newTargetRecord).then((response)=>{
                        if(vm.addAnother){
                            // let user = vm.currentTargetRecord.per_id
                            vm.resetForm()
                            // vm.currentTargetRecord.per_id = user
                            refreshData()
                            vm.addAnother = false  
                            vm.initializeSelect2(modalId)
                        }
                        else{
                            modalService.Close(modalId)
                            refreshData()
                        }             
                    }) 
                }
                else{
                    // We will be deleting the Current REcord and Adding one so that Historically 
                    // we will be seeing the change in Targets
                    let newRecord = JSON.parse(JSON.stringify(vm.currentTargetRecord))
                    let addRecord = {
                        effectiveon: dateToday.format("YYYY-MM-DD"),
                        fdformid: selectedFormID,
                        sta_fob_id: selectedFobID,
                        frequencyid: newRecord.frequencyid,
                        id: null,
                        modified_by: null,
                        modified_date: dateToday.format("YYYY-MM-DD"),
                        per_id: newRecord.per_id,
                        target: newRecord.target,
                        sta_context: newRecord.sta_context,
                        stc_comment: newRecord.stc_comment,
                        currentMode: newRecord.id,

                    }
                    // removed for new system of removing then adding target for Historical Purposes
                    // adminTargetService.updateTargetRecord(vm.currentTargetRecord).then((response)=>{     
                    //     refreshData()
                    //     modalService.Close(modalId)
                    // }) 

                    adminTargetService.deleteTargetRecord({id: vm.currentTargetRecord.id, mode:'onUpdate',deletingReason: newRecord.stc_comment}).then((response) =>{
                        adminTargetService.saveTargetRecord(addRecord).then((response)=>{
                            modalService.Close(modalId)
                            refreshData() 
                        })
                    })
                }  
                vm.initializeSelect2(modalId)
            } 
            else {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
           
        }

        //Function to open create target modal
        vm.openModal = (modalId, mode='new', id) => {
            resetFormFieldClassList('targetRecords')

            if(mode === 'new')
            {            
                vm.currentMode = 'new'
                vm.showAnother = true
                vm.fieldDisabled = false
                vm.resetForm()

                let rows = vm.targetOptions.api.getSelectedRows()
                if(rows.length > 0)
                vm.currentTargetRecord.per_id = rows[0].per_id
            }
            else{ 
                      
                vm.currentMode = 'edit'
                vm.showAnother = false
                vm.fieldDisabled = true
                vm.resetForm()

                vm.targetData.forEach((main)=>{
                    main.targets.forEach((tar)=> {
                        if(id == tar.id) {
                            vm.currentTargetRecord = JSON.parse(JSON.stringify(tar))
                            vm.currentTargetRecord.per_id = main.per_id
                            vm.getUserForms()
                            if(vm.formList){
                                vm.formList.forEach(form => {
                                    if(form.FormType == tar.type && form.FormID.split('-')[0] == tar.target_form_id){
                                        vm.currentTargetRecord.fdformid = form.FormID                                     
                                    }
                                })
                            }
                        }
                    })
                })
                vm.currentTargetRecordOriginal = JSON.parse(JSON.stringify(vm.currentTargetRecord))
            }         

            modalService.Open(modalId)
            vm.initializeSelect2(modalId)
        }

        //Function to close modals
        vm.cancelModal = (id) => {
            modalService.Close(id)
            if (id === 'DeleteRecordConfirmationModal'){
                resetFormFieldClassList('DeleteRecordConfirmation')
                document.forms['DeleteRecordConfirmation'].classList.remove('was-validated')
            }
        } 

        //Function for delete target confermation
        vm.deleteTargetModal = (id, mode) => {
            vm.deleteTargetModalData = {id: id, mode: mode}
            // print('deleteTargetModalData -- ', vm.deleteTargetModalData)
            if(mode === 'user'){
                vm.deleteMsg = translateTag(3893) //Are you sure you want to delete all targets for this user?
            }
            else
            {
                vm.deleteMsg = translateTag(3946) //Are you sure you want to delete this target?
            }
            vm.deletingReason = ''    
            modalService.Open('DeleteRecordConfirmationModal')
        }

        //Function to delete a target
        vm.deleteTarget = (data) => {   
            resetFormFieldClassList('DeleteRecordConfirmation')
            if(vm.ValidateDeleteModal()){
                if(data.mode === 'user')
                {
                    adminTargetService.deleteAllUserTargetRecords({per_id: data.id, deletingReason : vm.deletingReason}).then((response) =>{
                    modalService.Close('DeleteRecordConfirmationModal')
                    refreshData()
                    })
                }
                else{
                    adminTargetService.deleteTargetRecord({id: data.id, mode:'direct', deletingReason : vm.deletingReason}).then((response) =>{
                    modalService.Close('DeleteRecordConfirmationModal')
                    refreshData()
                    })
                } 
            }
            else {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }

              
        }

        //Funtion to initialize select2
        vm.initializeSelect2 = (parent)=> {
          setTimeout(()=>{ 
          $('.select-single, .select-multiple')
            .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} .modal-body`), escapeMarkup: function (text) { return text } })
            .on('select2:select', () => {
                $(this).parent().find('label').addClass('filled')
            })
            $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
            select2Service.select2Tags()
          }, 100)
          today = new Date()
          if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
          $('.datepicker').pickadate({
            format: 'yyyy-mm-dd',
            onClose : function(){
                this.$holder.blur()
            },
            min: new Date(moment(today))
          }).removeAttr('readonly')
          .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
            evt.preventDefault()
          })
        }

        //Funtion to convert frequency list values to integers
        function convertFrequencyList (data) {
          let output = []
          data.forEach((rec)=>{
            output.push({rld_code: parseInt(rec.rld_code), rld_name: rec.rld_name})
          })
            return output
        }

        // Fuction to check if add target modal feilds are valid
        vm.ValidateTargetRecord = () => {
            let validated = validateFormFields('targetRecords')
            if(vm.currentMode === 'new')
            {
                //check if the Record is already in the list   
                vm.targetData.forEach((td)=> {
                    td.targets.forEach((t)=> {
                        if(t.sta_per == vm.currentTargetRecord.per_id && 
                            t.fdformid == vm.currentTargetRecord.fdformid){
                            validated = false
                            toastr.error(translateTag(3890)) //This target already exists for this user
                            resetFormFieldClassList('targetRecords')
                            formVal.classList.remove('was-validated')
                        }
                    })            
                })
            }

            vm.initializeSelect2('targetModal')          
            return validated
        }

        //Function to refresh data and Ag-Grid
        function refreshData() {
            $scope.$emit('STARTSPINNER', vm.loadMessage)
            $q.all([
                listService.getSelectListData('ref_frequency'),
                adminTargetService.getFormList(),
                adminTargetService.getTargetRecords(),
                adminRoleService.getRoles('targets'),
                profileService.getFullEmployeeProfile(),
                profileService.getActivePersonList(),
            ]).then((data) => {
                vm.fullEmployeeList = profileService.readFullEmployeeProfile()
                vm.activePersonList = profileService.readActivePersonList()
                vm.roles = adminRoleService.readRoles()
                vm.allFormList = adminTargetService.readFormList() 
                vm.targetData = prepareTargetGridData(adminTargetService.readTargetRecords())
                vm.frequencyList = convertFrequencyList(data[0])
                
                vm.deletingReason = ''
                if (vm.targetOptions.api) {
                    translateAgGridHeader(vm.targetOptions)
                    let model = vm.targetOptions.api.getFilterModel()
                    vm.targetOptions.api.setRowData(vm.targetData)              
                    vm.targetOptions.api.redrawRows()
                    vm.targetOptions.api.sizeColumnsToFit()
                    vm.targetOptions.api.setFilterModel(model)

                    // Reset total rows for master detail grid
                    vm.currentTotalRows =  vm.targetOptions.api.getDisplayedRowCount()
                    setTotalRowsForMasterDetailGrid("total_number_records", vm.currentTotalRows)
                }

                

                $scope.$emit('STOPSPINNER')
                vm.actionDisabled = true
            })                    
        }
        refreshData()

        vm.getUserForms = () => {
            let formList = []
            let finalFormList = []
            roles = getUserRoles(vm.currentTargetRecord.per_id)
            roles.forEach((rl) => {
                vm.roles.forEach((data) => {
                    if(data.aro_id == parseInt(rl)){
                        data.form_access.forEach((fa)=>{
                            if(!formList.includes(`${fa.id}-${fa.form_category}`)) {
                                if(fa.name !== 'CHECKLIST' && formExceptionList(fa.formID) && (fa.formID != null || fa.arf_fob_id != null)) {                                    
                                    formList.push(`${fa.id}-${fa.form_category}`)
                                    let form_id = null
                                    if(fa.formID){
                                        form_id = `${fa.formID}-${fa.form_type}`
                                    }
                                    else if(fa.arf_fob_id){
                                        form_id = `${fa.arf_fob_id}-${fa.form_type}`
                                    }

                                    finalFormList.push({
                                        FormID : form_id,
                                        FormName : $filter('titlecase')(fa.name),
                                        FormCategory: fa.form_category,
                                        FormType : fa.form_type
                                    })
                                }
                            }
                        })
                    }
                })
            })
            vm.formList = finalFormList.sort((a, b) => a.FormName.localeCompare(b.FormName))
        }

        function formExceptionList(formID){
            // Preliminary Incident     
            // Preliminary Investigation
            // Hazard Report            
            // Positive Identification  
            // Incident Satement        
            // Employee Discipline      
            // Employee Review Annual   
            // Employee 60 DAY Review   
            // General ACTION Report    
            // General ACTION Report    
            // GENERAL STATEMENT        
            // Employee Performance     
            // Employee Departure       
            // Custom Forms
            // Lineup                   
            let formExceptionFormIds = [224335, 220234,131042,166071,221746,248310,248322,339913,372298,131200,372308,372318,372328,777777,888888]

            if (formExceptionFormIds.indexOf(formID) !== -1){

                return false
            }
            else{

                return true
            }
        }

        function getUserRoles(per_id) {
            let roles = []
            vm.fullEmployeeList.forEach((rec)=>{
                if(rec.per_id == per_id){
                    roles = rec.roles.split(",")
                }
            })
            return roles
        }

        //Function to prepare Ag-Grid data
        function prepareTargetGridData(data) {
            let gridData = JSON.parse(JSON.stringify(data))
            gridData.forEach((rec) =>{
                rec.exceptionFields = ['per_id']
                rec.per_name = getEmployeeName(rec.per_id)               
            })
            return gridData
        }

        //Function to prepare Ag-Grid data
        function prepareDetailTargetGridData(data) {
            let gridData = JSON.parse(JSON.stringify(data))

            let rtrn = []
            gridData.forEach((rec) =>{
                let newRec = {}
                newRec.effectiveon=rec.effectiveon
                newRec.target_form_id = getFormName(rec.target_form_id)
                newRec.target=rec.target
                newRec.frequencyid = getFrequencyName(rec.frequencyid)
                newRec.sta_modified_date = rec.sta_modified_date == null ? '' : moment(rec.sta_modified_date).format('YYYY-MM-DD')
                newRec.sta_modified_by_per = getEmployeeName(rec.sta_modified_by_per)
                newRec.id = rec.id
                rtrn.push(newRec)
            })

            return rtrn
        }

        //Function to dynamically assigning detail row height
        vm.targetOptions.getRowHeight = function (params) {
            var isDetailRow = params.node.detail;
            
            // for all rows that are not detail rows, return nothing
            if (!isDetailRow) { return 40; }
            // otherwise return height based on number of rows in detail grid
            var detailPanelHeight = (params.data.targets.length * 40) + 85;
            
            if(params.data.targets.length == 1)
            {
                detailPanelHeight = (params.data.targets.length * 40) + 95
            }

            if(params.data.targets.length <= 0) //Add extra when grid is empty
                detailPanelHeight += 30
            

            return detailPanelHeight;
        }


        // Fuction to check if add target modal feilds are valid
        vm.ValidateDeleteModal = () => {
            let validated = validateFormFields('DeleteRecordConfirmation')
            vm.initializeSelect2('DeleteRecordConfirmationModal')          
            return validated
        }

        //Update Ag-Grid size when window is resized
        $(window).on('resize', () => {
            $timeout(function () {
                if (vm.targetOptions.api) {
                    vm.targetOptions.api.sizeColumnsToFit()

                vm.targetOptions.api.forEachDetailGridInfo(function(detailGridInfo) {
                    detailGridInfo.api.sizeColumnsToFit()
                })
                }
            })
        })
    }])