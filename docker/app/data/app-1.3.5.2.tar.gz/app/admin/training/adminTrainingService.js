angular
    .module('safeToDo')
    .service('adminTrainingService', ['$http',
        function ($http) {
            let trainingRecords = []
            let trainingCodes = []
            let trainingTypes = []
            let trainingInstitutions = []
            let trainingStatuses = []
            return {
                // Retrieves entire list of training records for main AG-Grid
                getTrainingRecords: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/training/get-all-employee-training-records/`, payload).then((response) => {
                        trainingRecords = response.data                        
                    }, (errorParams) => {
                        console.log('Failed to load Training Records', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            trainingRecords = []
                            window.location.href = "/";
                        }
                    })
                },
                // Send data to the Create Endpoint to Add or update training Record
                createTrainingRecord: (data) => {
                    return $http.post(`${__env.apiUrl}/api/training/create-training-record/`, data).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to create Training Records', errorParams)
                    })
                },
                // // Create bulk training records
                // createBulkTrainingRecord: (data) => {
                //     return $http.post(`${__env.apiUrl}/api/training/create-bulk-training-record/`, data).then((response) => {
                //         return response
                //     }, (errorParams) => {
                //         console.log('Failed to create Bulk Training Records', errorParams)
                //     })
                // },
                updateTrainingRecord: (data) => {
                    return $http.post(`${__env.apiUrl}/api/training/edit-training-record/`, data).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to update Training Records', errorParams)
                    })
                },
                createCodeRecord: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/master-ref-list/create-multi-list/`, payload).then((response) =>{
                        return response
                    }, (errorParams) => {
                        console.log('Failed to create Code Record', errorParams)
                    })
                },
                addTrainingRecordAttachments: (payload) => {
                    for (var pair of payload.entries()) {
                    }
                    return $http.post(`${__env.apiUrl}/api/training/add-training-attachments/`, payload,{
                        // this cancels AngularJS normal serialization of request
                        transformRequest: angular.identity,
                        // this lets browser set `Content-Type: multipart/form-data` 
                        // header and proper data boundary
                        headers: {'Content-Type': undefined}}).then((response) =>{
                        return response
                    }, (errorParams) => {
                        console.log('Failed to add attachment Record', errorParams)
                    })
                },
                updateTrainingRecordAttachments: (data) => {
                    return $http.post(`${__env.apiUrl}/api/training/update-training-attachment-list/`, data).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to update Training Records attachment', errorParams)
                    })
                },
                deleteTrainingRecordAttachment: (data) => {
                    return $http.post(`${__env.apiUrl}/api/training/delete-training-attachment-by-id/`, data).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to delete attachment', errorParams)
                    })
                },

                createTrainingRecordZipFile: (data) => {
                    // data = {
                    //     "emp_id": [1461, 1462]
                    // };
                    return $http.post(`${__env.apiUrl}/api/training/zip-training-files/`, data, {responseType: 'arraybuffer'
                }).then((response) => {
                       
                        return response
                    }, (errorParams) => {
                        console.log('Error creating the zip file', errorParams)
                    })
                },

                generateTrainingMatrixReport : (data) => {
                    return $http.post(`${__env.apiUrl}/api/training/employee-training-matrix/`, data).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to generate training matrix', errorParams)
                    }
                    )},
                getRefreshTrainingRecords: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/training/get-all-employee-training-records/`, payload).then((response) => {
                        // console.log("this is data refresh",  response.data )
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load Training Records', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            trainingRecords = []
                            window.location.href = "/";
                        }
                    })
                },
                getFullTrainingRefList : (rlh_name) =>{                    
                    return $http.get(`${__env.apiUrl}/api/training/full-training-code-list/${rlh_name}/`).then((response) => {   
                        if(rlh_name === 'ref_training_code')
                            trainingCodes = response.data
                        else if(rlh_name === 'ref_training_type')
                            trainingTypes = response.data
                        else if (rlh_name === 'ref_training_institution')
                            trainingInstitutions = response.data
                        else if(rlh_name === 'ref_training_status')
                            trainingStatuses = response.data
                    }, (errorParams) => {
                        console.log('Failed to generate training matrix', errorParams)
                    }
                    )
                },
                archiveTrainingRecord: (data) => {
                    return $http.post(`${__env.apiUrl}/api/training/archive-training-record/`, data).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to archive training record', errorParams)
                    })
                },
                

                //Returns training records on demand without reload
                readTrainingRecords: () => {
                    return trainingRecords
                },

                readTrainingCodeList: () => {
                    return trainingCodes
                },
                readTrainingTypeList: () => {
                    return trainingTypes
                },
                readTrainingInstitutionList: () => {
                    return trainingInstitutions
                },
                readtrainingStatusList : () => {
                    return trainingStatuses
                }

            }
        }  
    ])