﻿angular
    .module('safeToDo')
    .controller('AdminTrainingCtrl', ['$http', '$scope','$rootScope', '$timeout', '$q', '$window', '$sce', 'gridService', 'select2Service','modalService', 'profileService', 
                'listService', 'adminTrainingService', 'menuService','i18nService','adminListService','$compile','fileUploadService', 'exportCSV',
        function ($http, $scope,$rootScope, $timeout, $q, $window, $sce, gridService, select2Service, modalService, profileService, listService, adminTrainingService, menuService, i18nService, adminListService, $compile, fileUploadService, exportCSV) {
            let vm = this
            
            let dateToday = moment(new Date(), 'YYYY-MM-DD')
            vm.employeeList = []
            vm.allEmployeeList = []
            vm.fullEmployeeList = []
            vm.institutionList = []
            vm.trainingTypeList = []
            vm.trainingCodeList = []
            vm.trainingStatus = []
            vm.uploadFileList = []
            vm.currentTrainingRecordOriginal = []
            vm.addAnother = false
            vm.topSearch = ''
            vm.showAnother = true
            vm.loadMessage = translateTag(8644) // "Loading training records. Please wait."
            vm.actionDisabled = true
            vm.statusDisplay = translateTag(3557)// "Active"
            vm.canViewTrainingRecords = false
            vm.canManageTrainingRecords = false
            vm.canArchiveTrainingRecords = true
            vm.canManageTrainingStatus = false
            vm.singleServeReportUrl = "employee_training_records?report_selection=107&"
            vm.employeeSearchMatrix = null
            vm.trainingCodeSearchMatrix = null
            vm.selectedTrainingRecord = null
            vm.viewTrainingOnly = false
            vm.showValidator = false
            vm.loading = false
            vm.currentItem = {}
            vm.currentTranslationList = []
            vm.systemLanguages = []
            vm.selectedLanguageID = 1
            vm.defaultLanguageID = 1

            vm.isLinkButton = false
            vm.linkUrl = null
            vm.showDatePickers = 0
            vm.mobileDisabled = true  
           	vm.completeTag = 1 // 2045               
           	vm.retiredTag = 2 //1442               
           	vm.neededTag = 3 //1464               
           	vm.inProgressTag = 4 //8919               
           	vm.scheduledTag  = 5 //1463

            vm.hideAllButtonOnIntegrated = false // flag to set for hiding all other buttons if click on the integrated records
            vm.isEnableTrainingStatus = false
            vm.fileTypesImages = ['PNG', 'JPEG', 'BMP', 'GIF', 'WEBP', 'JPG']

            vm.openAttachment = (data) => {
                $window.open($sce.trustAsResourceUrl(`${data}`), "_blank")
            }

            $rootScope.$on("MOBILE-LOADED", (event,result) => {
                vm.mobileDisabled = false
                $scope.$digest()
            })

            vm.getCurrentTranslationList = (data) => {
                var currentTranList = []    
                for(var lang in vm.systemLanguages)
                {
                    lang = vm.systemLanguages[lang]
                    if(!lang.lng_selected)
                        continue    
                    var tranObj = {
                        ltr_lng_id: lang.lng_id,
                        ltr_lng_name: lang.lng_name.toUpperCase(),
                        ltr_lng_description: lang.lng_description_text,                        
                        ltr_lng_default: lang.lng_default ? "*" : "",
                        ltr_text: new Array(data.length).fill(""),
                        ltr_translated:  new Array(data.length).fill(false)
                    }
                    
                    for(var tranList in data)
                    {
                        var tranIndex = tranList
                        tranList = data[tranList]
                        for (var tran in tranList)
                        {                        
                            tran = tranList[tran]
                            if(tran.ltr_lng_id == lang.lng_id)
                            {
                                tranObj.ltr_text[tranIndex] = tran.ltr_translated ? tran.ltr_text : ""
                                tranObj.ltr_translated[tranIndex] = tran.ltr_translated
                            }
                        }
                    }    
                    currentTranList.push(tranObj)
                }
    
                return currentTranList
            }

            function resetCurrentMultiItem()
            {
              vm.currentItem = {
                rld_rlh_id: null,
                rld_score: null,
                rld_code: null,
                rld_name: null,
                rld_description: null,
                rld_enable: 1,
                rld_is_active: 1,
                rld_parent_detail_rld_id: null,
                rld_created_by_per_id: null,
                rld_modified_by_per_id: null,
                rld_names: [],
                rld_descriptions: []
              }
            }
            profileService.getPersonProfile().then(() =>{   
                vm.userprofile = profileService.readPersonProfile()
                vm.currentUserRoles = vm.userprofile.role_ids.split(', ')  
                if(vm.currentUserRoles.includes('8')){
                    vm.userIsAdmin = true
                } else{
                    vm.userIsAdmin = false
                }  
                menuService.getPagePermissions().then((data) => {
                    vm.permissions = data
                    vm.canViewTrainingRecords = vm.permissions.includes('Can View Training Records') ? true : false
                    vm.canManageTrainingRecords = vm.permissions.includes('Can Manage Training Records') ? true : false
                    vm.canArchiveTrainingRecords = vm.userIsAdmin
                    vm.canManageTrainingStatus = vm.permissions.includes('Can Manage Training Status') ? true : false
                    if(!vm.canViewTrainingRecords)
                        window.location.href = "/"
                })

            })

            vm.trainingOptions = gridService.getCommonOptions()
            vm.trainingOptions.pagination = false
            
            // Calling a function to display the number of filtered records when filter changes
            vm.trainingOptions.onFilterChanged = () => {
                setTotalRowsForMasterDetailGrid("total_number_records", vm.trainingOptions.api.getDisplayedRowCount())
            }

            //Function for the top search bar
            vm.topSearchChanged = () =>{
                vm.trainingOptions.api.setQuickFilter(vm.topSearch)
                // Setting total number of displayed rows when filter changes
                setTotalRowsForMasterDetailGrid("total_number_records", vm.trainingOptions.api.getDisplayedRowCount())
            }

            //Function to disable action button if no rows are selected
            vm.trainingOptions.onSelectionChanged = () => {                
                var selectedRows = vm.trainingOptions.api.getSelectedRows()
                vm.actionDisabled = selectedRows.length == 0
                $scope.$apply()
            }
            
            //Function to toggle expiry date value to "N/A" if it is non expiry
            vm.toggleNonExpiry = () => {    
                if(vm.currentTrainingRecord.etr_no_expiry_date == 1)
                {
                    vm.currentTrainingRecord.etr_expiry_date = null
                   
                }
            }
            
            // function to reset data on modal forms  
            vm.resetForm = () => {
                vm.stepsModel = []
                vm.uploadFileList = []
                vm.currentTrainingRecordOriginal = []
                document.getElementById('docAttFile').value= null;
                vm.showAnother = true
                vm.hideAllButtonOnIntegrated = false
                vm.isLinkButton = false
                resetFormFieldClassList('trainingRecords')
                resetFormFieldClassList('trainingCodes')
                vm.submitted = false
                vm.currentTrainingRecord = 
                {
                    "isBulk": false,
                    "etr_understand_bulk_attachments": 0,
                    "etr_id": null,
                    "etr_training_type": null,
                    "etr_training_institution": null,
                    "etr_training_code": null,
                    "etr_training_status": null,
                    "etr_no_expiry_date": 0,                    
                    "etr_completion_date": dateToday.format("YYYY-MM-DD"),
                    "etr_expiry_date": dateToday.format("YYYY-MM-DD"),
                    "attachments": []
                }
                vm.currentCode = 
                {
                    rld_rlh_id: 51,
                    rld_code: null,
                    rld_name: null,
                    rld_description: null,
                    rld_enable: 1,
                    rld_parent_detail_rld_id: null,
                    rld_created_by_per_id: null,
                    rld_modified_by_per_id: null
                }
                vm.trainingMatrix = {
                    employees : null,
                    training_code : null
                }
            }
            
            $scope.fileUploadChanged = (event)=> {

                let existingFileNames = []
                for(let i in vm.uploadFileList) {
                    existingFileNames.push(vm.uploadFileList[i].name)
                }

                //Add newly selected files after checking for duplicates and correct file types
                vm.uploadFileList = vm.uploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, existingFileNames))
                for (let index = 0; index < vm.uploadFileList.length; index++) {   
                    if(vm.uploadFileList[index].type != 'link'){
                        let split_file_name = vm.uploadFileList[index].name.split('.')
                        let file_extension = split_file_name[split_file_name.length - 1]
                        vm.uploadFileList[index]['file_extension'] = '.'+file_extension
                    }           
                }


                //Get data from files to display in html
                fileUploadService.getFileUploadData(vm.uploadFileList).then((filesData) => {
                    vm.stepsModel = filesData

                    for (let i = 0; i < (vm.stepsModel.length); i++) {
                        vm.uploadFileList[i].imageUrl = vm.stepsModel[i]
                        if(!vm.uploadFileList[i].comments)
                            vm.uploadFileList[i].comments = vm.uploadFileList[i].name
                    }

                    $scope.$apply() // Update html bindings
                })
            }
            
            // function to get the Employee Name
            function getEmployeeName(value) {
                let name = value

                vm.allEmployeeList.forEach((emp)=>{
                    if(emp.per_id == value) {
                        name = emp.per_full_name
                    }
                })
                return name
            }

            function getEmployeeNamePerID(value) {
                let name = value

                vm.allEmployeeList.forEach((emp)=>{
                    if(emp.per_id == value) {
                        name = emp.per_full_name
                    }
                })
                return name
            }

            function getEmpIdFromPerID(per){
                for(let i = 0;i< vm.allEmployeeList.length;i++){
                    if(vm.allEmployeeList[i].per_id==per){
                        return vm.allEmployeeList[i].emp_id
                    }
                }

            }

            function getPerIdFromEmpID(emp){
                for(let i = 0;i< vm.allEmployeeList.length;i++){
                    if(vm.allEmployeeList[i].emp_id==emp){
                        return vm.allEmployeeList[i].per_id
                    }
                }

            }

            // function to get the Training Type Name
            function getTrainingTypeName(value) {
                let type = value
                vm.fullTrainingTypeList.forEach((ty)=>{
                    if(ty.rld_id === value) {
                        type = ty.name
                    }
                })
                return type
            }

            // function to get the Training Institution Name
            function getTrainingInstitutionName(value) {
                let inst = value
                vm.fullTrainingInstitutionList.forEach((ins)=>{
                    if(ins.rld_id === value) {
                        inst = ins.name
                    }
                })
                return inst
            }

            // function to get the Training Code Name
            function getTrainingCodeName(value) {
                let code = value                           
                vm.fullTrainingCodeList.forEach((cd)=>{                    
                    if(cd.rld_id === value) {
                        code = {code: cd.rld_code, training_value: cd.name, training_description: cd.description}
                    }
                })
                return code
            }

            vm.changeStatus = (status) =>{
                vm.statusDisplay = status
                vm.refreshData()

            }

            function strikeThroughEtr(params) {
                let training_status_option = vm.getTrainingStatusOption(params.data.etr_training_status)
                // Retired
                if (training_status_option == vm.retiredTag) {
                    return {textDecoration: 'line-through'};
                }
                return null;
            }

            vm.trainingOptions.suppressHorizontalScroll = true
            // Main Training Grid Initialization and options      
            vm.trainingOptions.detailCellRendererParams = {
                detailGridOptions: {
                rowBuffer:999999,
                toolPanelSuppressRowGroups: true,
                toolPanelSuppressValues: true,
                toolPanelSuppressPivots: true,
                toolPanelSuppressPivotMode: true,
                toolPanelSuppressSideButtons: true,
                suppressContextMenu: true,
                enableSorting:true,
                enableFilter:true,
                animateRows: true,
                showToolPanel: false,
                suppressMovableColumns: true,
                suppressHorizontalScroll: false,
                suppressRowClickSelection: true,
                animateRows: true,
                suppressContextMenu: true,
                icons: {
                    sortAscending: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"7\" height=\"6\" viewBox=\"0 0 7 6\"><path fill=\"#979797\" fill-rule=\"evenodd\" d=\"M3.5 0L7 6H0z\"/></svg>",
                    sortDescending: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"7\" height=\"6\" viewBox=\"0 0 7 6\"><path fill=\"#979797\" fill-rule=\"evenodd\" d=\"M3.5 0L7 6H0z\"/></svg>",
                    menu: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"13\" height=\"11\" viewBox=\"0 0 13 11\"><g fill=\"none\" fill-rule=\"evenodd\" stroke-linecap=\"round\"><path d=\"M.5.5h12M.5 5.5h12M.5 10.5h12\"/></g></svg>",
                    filter: "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"18\" height=\"16\" viewBox=\"0 0 18 16\"><path fill=\"#979797\" fill-rule=\"evenodd\" d=\"M18 0H0l8 8v7.5l2-2V8z\"/></svg>",
                    checkboxUnchecked: "<img src=\"images/checkbox.svg\" />",
                    checkboxChecked: "<img src=\"images/checkbox-selected.svg\" />",
                    checkboxIndeterminate: "<img src=\"images/checkbox-partial.svg\" />"
                },
                components: {
                    tippyCellRenderer: TippyCellRenderer
                },
                columnDefs: [
                    {
                        field: "review", 
                        headerName: " ",  // Review
                        minWidth: 50,
                        maxWidth: 50,
                        menuTabs: ['filterMenuTab'],
                        suppressMenu: true,
                        suppressSorting: true,
                        cellStyle: params => strikeThroughEtr(params),
                        cellRenderer: function (params) {
                            if(params.data.Is_Integrated)                            
                                return `<div ng-class="{ transparent: ${!vm.canManageTrainingRecords && !vm.canViewTrainingRecords},pointer: ${vm.canManageTrainingRecords || vm.canViewTrainingRecords}}" ng-click="admtraining.openModal('TrainingEditModal','integrated','${params.data.Train_ID}')"><i class="fa fa-lock" note="Integrated" title="{{menu.translateLabels(9051)}}"></i></div>`;
                            else 
                                return `<div ng-class="{ transparent: ${!vm.canManageTrainingRecords && !vm.canViewTrainingRecords}, pointer: ${vm.canManageTrainingRecords || vm.canViewTrainingRecords}}" ng-click="admtraining.openModal('TrainingEditModal','edit','${params.data.Train_ID}')"><i class="fa fa-pen" note="Edit" title="{{menu.translateLabels(1194)}}"></i></div>`;

                        },
                        pinned: true
                    },
                    {
                        field: 'status',
                        headerName: " ",//  status
                        minWidth: 200,
                        maxWidth: 200,
                        menuTabs: ['filterMenuTab'],
                        hide: true,
                        valueGetter: function (params) {
                            let expiryDate = new Date(params.data.Expiry_Date)
                            let noExpiry = params.data.No_Expiry
                            let currentDate = new Date()
                            //if(params.data.etr_retire!==0){
                            let training_status_option = vm.getTrainingStatusOption(params.data.etr_training_status)
                            if(training_status_option ==vm.retiredTag){
                                return '0_Retired' // Retired
                            }
                            if (expiryDate < currentDate && !noExpiry)
                                return '1_Expired'
                            else if (!noExpiry)
                                return '2_Active'
                            else
                                return '3_NoExpiry'
                        },
                        sort: 'asc',
                    },
                    { 
                        field: 'Completion_Date',
                        headerName: ' ', // Completion Date
                        minWidth: 160,
                        maxWidth: 160,
                        menuTabs: ['filterMenuTab'],
                        cellRenderer: (params) =>  {
                            let training_status_option = vm.getTrainingStatusOption(params.data.etr_training_status)
                            if (training_status_option == vm.neededTag  || 
                                training_status_option == vm.inProgressTag || 
                                training_status_option == vm.scheduledTag){
                                return '' 
                            } else {
                               return params.data.Completion_Date
                            }
                        },
                        cellStyle: params => strikeThroughEtr(params)
                    },                    
                    { 
                        field: 'Expiry_Date',
                        headerName: ' ',
                        minWidth: 160,
                        maxWidth: 160,
                        menuTabs: ['filterMenuTab'],
                        cellStyle: params => strikeThroughEtr(params),
                        cellRenderer: (params) =>
                        {                
                            let expiryDate = new Date(params.data.Expiry_Date)
                            let currentDate = new Date()
                            let warningDate = new Date(expiryDate)

                            if(params.data.No_Expiry == 1)
                                return translateTag(1381) // "N/A"
 
                            warningDate.setMonth(warningDate.getMonth() -1)
                            if(params.data.Expiry_Date === null){
                               
                                return '<div></div>'
                            }
                            else if (expiryDate < currentDate)
                                return '<div class="text-danger">' + params.data.Expiry_Date + '</div>'
                            else if(warningDate < currentDate) { 
                                // colour the badge yellow.
                                return '<div class="text-warning">' + params.data.Expiry_Date + '</div>'
                            } else {
                                if(params.data.Expiry_Date === null || params.data.Expiry_Date === undefined){
                                    return '<div></div>'
                                } else {
                                    return '<div>' + moment(params.data.Expiry_Date).format('YYYY-MM-DD')  + '</div>'
                                }
                            }
                        },
                        sort: 'asc',
                    },
                    { 
                        field: 'Type',
                        headerName: ' ', // type
                        minWidth: 150,
                        maxWidth: 200,
                        menuTabs: ['filterMenuTab'],
                        cellRenderer: "tippyCellRenderer",
                        cellStyle: params => strikeThroughEtr(params) 
                    },
                    { 
                        field: 'Institution',
                        headerName: ' ',
                        minWidth: 150,
                        maxWidth: 200,
                        menuTabs: ['filterMenuTab'],
                        cellRenderer: "tippyCellRenderer",
                        cellStyle: params => strikeThroughEtr(params)
                    },
                    { 
                        field: 'Training_Code',
                        headerName: ' ', // Code
                        minWidth: 150,
                        maxWidth: 200,
                        menuTabs: ['filterMenuTab'],
                        cellRenderer: "tippyCellRenderer",
                        cellStyle: params => strikeThroughEtr(params),
                        valueGetter:  function (params) {
                            if (params.data.Training_Code == null)
                                return ''
                            else
                                return params.data.Training_Code
                        }
                    },
                    { 
                        field: 'Value',
                        headerName: ' ', // Value
                        minWidth: 300,       
                        menuTabs: ['filterMenuTab'],     
                        cellRenderer: "tippyCellRenderer",
                        cellStyle: params => strikeThroughEtr(params)
                    },
                    { 
                        field: 'Modified_By',
                        headerName: ' ', // Modified by
                        minWidth: 150,
                        maxWidth: 200,
                        menuTabs: ['filterMenuTab'],
                        cellRenderer: "tippyCellRenderer",
                        cellStyle: params => strikeThroughEtr(params)
                    },
                    { 
                        field: 'Modified_Date',
                        headerName: ' ', // Modified Date
                        minWidth: 150,
                        maxWidth: 200,
                        menuTabs: ['filterMenuTab'],
                        cellRenderer: "tippyCellRenderer",
                        cellStyle: params => strikeThroughEtr(params)
                    },
                    { 
                        field: 'Status',
                        minWidth: 150,
                        maxWidth: 150,
                        menuTabs: ['filterMenuTab'],
                        cellStyle: params => strikeThroughEtr(params),
                        cellRenderer: "tippyCellRenderer"
                    },
                    {
                        field: "", headerName: "",  minWidth: 50, maxWidth: 50, suppressMenu: true, suppressSorting: true, pinned: 'right',
                        cellRenderer: (params) => {
                            return `<div ng-class="{ transparent: ${!vm.canArchiveTrainingRecords}, pointer: ${vm.canArchiveTrainingRecords}}" class="text-left" note="Archive" title="{{menu.translateLabels(1224)}}" ng-click="admtraining.confirmTrainingArchive('${params.data.Train_ID}')">
                            <i class="far fa-trash-alt fa-lg"></i>
                            </div>`
                        }
                    },
                    {field:'Training_Description',hide:true}
                    
                ],
                rowHeight: 40,
                headerHeight: 35,
                localeText: sofvie_agGrid_languages[`${selectedLanguage}`]
                },
                    getDetailRowData: (params) => {
                        params.successCallback(prepareDetailTrainingGridData(params.data))
                        vm.trainingOptions.api.forEachDetailGridInfo(function(detailGridInfo) {
                            translateAgGridHeader(detailGridInfo)
                            detailGridInfo.api.sizeColumnsToFit()
                        })
                },
            }
            vm.trainingOptions.masterDetail = true

            // Parent Training Grid Initialization and options
            let trainingColumns = [
                {
                    headerName: '',
                    field: 'dummyCheckbox',
                    maxWidth: 60,
                    minWidth: 60,
                    checkboxSelection: true,            
                    suppressMenu: true,
                    suppressSorting: true,
                    headerCheckboxSelection: true,
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    field: "review",
                    headerName: " ", // Review
                    maxWidth: 125,
                    minWidth: 125,
                    suppressMenu: true,
                    suppressSorting: true,
                    cellRenderer: (params) => {
                        return `<span class="pointer text-left" ng-click="admtraining.viewReports($event, ${params.data.emp_per_id})"><i class="fa fa-external-link-alt" title="${translateTag(3429)}"></i></span>`
                    },                    
                },
                {
                    field: "id",
                    headerName: " ", // id
                    minWidth: 50,
                    hide:true,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                },
                {
                    field: "emp_name",
                    headerName: " ", // Name
                    minWidth: 150,
                    showRowGroup: true,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer:'agGroupCellRenderer',
                    sort: 'asc',
                    getQuickFilterText: function(params) {
                    return params.value
                    },
                },
                {
                    field: "search",
                    hide: true,
                    filter: 'agSetColumnFilter',
                    getQuickFilterText: (params) => {
                        let searchBlob = ''
                        params.data.training.forEach((rec)=>{                  
                            searchBlob += `${getTrainingTypeName(rec.etr_training_type)}, `
                            searchBlob += `${getTrainingInstitutionName(rec.etr_training_institution)}, `
                            searchBlob += `${getTrainingCodeName(rec.etr_training_code).code}, `
                            searchBlob += `${getTrainingCodeName(rec.etr_training_code).training_value}, `
                            searchBlob += `${getTrainingCodeName(rec.etr_training_code).training_description}, `
                            searchBlob += `${rec.etr_completion_date} , `
                            searchBlob += `${rec.etr_expiry_date} , `
                        })
                        return searchBlob
                    }
                }
            ]
            vm.trainingOptions.columnDefs = trainingColumns
            vm.trainingOptions.animateRows = false
            
            //Funtion to open reports in a new tab
            vm.viewReports = (e, id) =>{
                if(!e.ctrlKey)
                {
                    lang_number = localStorage.getItem('lang_id')
                    vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.singleServeReportUrl}per_ids=${id}&apply=1&lang=${lang_number}`)
                    $window.open(vm.reportURL, "_blank")
                }
            }

            //Funtion to launch a report in a new tab
            vm.viewReport = () =>{                
                let rows = vm.trainingOptions.api.getSelectedRows()       
                let a = 0
                let anchor = []
                rows.forEach(emp => {          
                    vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/pentaho/api/repos/%3A${window.__env.pentahoPath}%3Avflaudit.prpt/viewer?userid=${__env.pentahoUserName}&password=${window.__env.pentahoPassword}&paramid=123${a}&paramurl=${__env.pentahoImagesUrl}&output-target=pageable/pdf`)
                    anchor[a] = angular.element('<a/>');
                    $window.open(vm.reportURL, "_blank")
                    a++
                })
            }

            //Function to export csv
            vm.exportCSV = () => {
                let rows = JSON.parse(JSON.stringify(vm.trainingOptions.api.getSelectedRows()))
                rows.forEach(emp => {
                    emp.training.forEach(tr => {
                        tr['etr_training_type'] = vm.trainingTypeObject[tr.etr_training_type] != undefined ? vm.trainingTypeObject[tr.etr_training_type] : ''
                        tr['etr_training_institution'] = vm.trainingInstitutionObject[tr.etr_training_institution] != undefined ? vm.trainingInstitutionObject[tr.etr_training_institution] : ''
                        tr['etr_training_value'] = vm.trainingCodeNameObject[tr.etr_training_code] != undefined ? vm.trainingCodeNameObject[tr.etr_training_code] : ''
                        tr['etr_training_code'] = vm.trainingCodeObject[tr.etr_training_code] != undefined ? vm.trainingCodeObject[tr.etr_training_code] : ''
                        tr['etr_training_status'] = vm.trainingStatusName[tr.etr_training_status] != undefined ? vm.trainingStatusName[tr.etr_training_status] : ''
                    })
                })
                rows = exportCSV.split_nested_lists(rows, 'training')
                exportCSV.export_csv(rows, translateTag(1034))                
            }

            vm.cancelBulkUpdateModal = () =>{
                vm.updateModal = false
                modalService.Close("confirmModal")
            }            

            vm.saveBulkTrainingRecords = (modalId) => {
                vm.updateModal = false
                vm.duplicateFlag = false
                let payload = JSON.parse(JSON.stringify(vm.currentTrainingRecord))
                payload.emp_id = payload.etr_emp
                adminTrainingService.createTrainingRecord(payload).then((result) => {
                        async function sendFiles(){
                            let index = 0
                            vm.tmp_trainingRecords.push(result.data.requested_data)   
                            for(let objEmpEtr of result.data.emp_training){
                                for(const file of vm.uploadFileList){
                                    let  attPayload = vm.attachmentBulkFormData(objEmpEtr.etr_id, [getPerIdFromEmpID(objEmpEtr.emp_id)],  file, true)
                                    await  adminTrainingService.addTrainingRecordAttachments(attPayload)
                                }     
                                index ++                                                                                             
                            }
                                             
                        }
                        sendFiles().then(() =>{
                            if(vm.addAnother){
                                vm.showDatePickers = 0
                                vm.refreshFlag = true
                                vm.addAnother = false                                
                                vm.resetForm()
                                vm.isBulk = true
                                vm.currentTrainingRecord.isBulk = true
                                $scope.$apply()
                                vm.initializeSelect2("TrainingEditModal")
                            } else {
                                vm.refreshTrainingRecords()
                                vm.tmp_trainingRecords = []
                                vm.refreshFlag = false
                                modalService.Close(modalId)
                                vm.addAnother = false
                                resetFormFieldClassList('trainingRecords')
                            }    
                        })
                })
            }
            
            //Function for Saving or Updating the training record
            vm.saveTrainingRecord = (id = null, modalId) => {    
                vm.isLinkButton = false
                vm.duplicateRecordExists = false
                if(vm.ValidateTrainingRecord()){
                    vm.submitted = true
                    if(vm.currentMode === "new") {
                        let payload = JSON.parse(JSON.stringify(vm.currentTrainingRecord))
                        payload.emp_per = [payload.emp_per]
                        adminTrainingService.createTrainingRecord(payload).then((result) => {
                        vm.tmp_trainingRecords.push(result.data.requested_data)
                        async function sendFiles () {
                            for (const file of vm.uploadFileList){
                                let  attPayload = vm.attachmentBulkFormData(result.data.emp_training[0].etr_id,payload.emp_per, file)
                                await adminTrainingService.addTrainingRecordAttachments(attPayload)
                            }                          
                        }
                        sendFiles().then(() =>{
                            if(vm.addAnother)
                            {
                                vm.refreshFlag = true
                                vm.addAnother = false
                                vm.resetForm()
                                vm.showDatePickers = false
                                vm.currentTrainingRecord.etr_expiry_date = null
                                vm.currentTrainingRecord.etr_completion_date = null

                                vm.initializeSelect2("TrainingEditModal")
                                $scope.$apply()
                            }
                            else {
                                vm.refreshTrainingRecords()
                                vm.tmp_trainingRecords = []
                                vm.refreshFlag = false
                                modalService.Close(modalId)
                                vm.addAnother = false
                                resetFormFieldClassList('trainingRecords')
                            }    
                        })
                        }) 
                    } else {
                        let payload = JSON.parse(JSON.stringify(vm.currentTrainingRecord))
                        payload.etr_expiry_date = payload.etr_expiry_date === undefined?null:payload.etr_expiry_date
                        payload.emp_per = [payload.emp_per]
                        if(payload.etr_expiry_date == "N/A" || payload.etr_expiry_date == translateTag(1381)){
                            payload.etr_expiry_date = dateToday.format("YYYY-MM-DD")
                        }
                        payload.emp_id = getEmpIdFromPerID(payload.emp_per)                        
                        adminTrainingService.updateTrainingRecord(payload).then((result) => {  
                            
                            attPayload = vm.currentTrainingRecord.attachments
                            adminTrainingService.updateTrainingRecordAttachments(attPayload).then((result) => {
                                async function sendFiles () {
                                    for (const file of vm.uploadFileList){
                                        let  attPayload = vm.attachmentFormData(vm.currentTrainingRecord.etr_id, file)
                                        await adminTrainingService.addTrainingRecordAttachments(attPayload)
                                    }
                                }
                                sendFiles().then(() =>{   
                                    vm.refreshTrainingRecords()
                                    vm.refreshFlag = false
                                    modalService.Close(modalId)
                                    resetFormFieldClassList('trainingRecords')
                                })    
                            })                     
                        })
                    }
                }  else {
                    if(!vm.duplicateRecordExists){
                        $rootScope.$broadcast("CALLCONFIRMMODAL")
                    }
                    
                }
            }

            function prepareListItemTranslationPayload (data) {
                var rld_names = []
                var rld_descriptions = []        
        
                for(var tran in data) {
                    tran = data[tran]

                    if (typeof tran.ltr_text !== 'undefined') {
                        if(tran.ltr_text.length != 0){
                            var rldNameTran = {
                                ltr_lng_id: tran.ltr_lng_id,
                                ltr_text: tran.ltr_text.trim()
                            }
                            if(rldNameTran.ltr_text != "")
                                rld_names.push(rldNameTran)
                        }
                    }
                    if (typeof tran.description !== 'undefined') {
                        if(tran.description.trim() != ''){
                            var rldDescTran = {
                                ltr_lng_id: tran.ltr_lng_id,
                                ltr_text: tran.description.trim()
                            }
                            if(rldDescTran.ltr_text != "")
                                rld_descriptions.push(rldDescTran)  
                        }
                    }                    

                                   
                }
        
                var payload = {
                    rld_names: rld_names,
                    rld_descriptions: rld_descriptions,
                }
                    
                return payload
              }
            
            //Function for saving the Code Record
            vm.saveCodeRecord = (modalId) => {
                resetFormFieldClassList('trainingCodes')
                if(validateFormFields('trainingCodes'))
                {
                    if(vm.ValidateTrainingCode()){
                        vm.submitted = true
                        translationPayload = prepareListItemTranslationPayload(vm.currentTranslationList)
                        vm.currentItem.rld_rlh_id =  51
                        vm.currentItem.rld_names = translationPayload.rld_names
                        vm.currentItem.rld_descriptions = translationPayload.rld_descriptions
                        vm.currentItem.rld_deleted = 0
                        vm.currentItem.rld_enable = 1
                        vm.currentItem.rld_changed = false

                        adminListService.addListItem(vm.currentItem).then(() => {                       
                            resetCurrentMultiItem()
                            resetFormFieldClassList('trainingCodes')
                            modalService.Close('listItemTranslationModal')
                            vm.submitted = false
            
                            //Refresh Items
                            vm.refreshData()
                            vm.refreshFlag = false
                        })
                    }

                }
                else 
                {
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            // convert the JSON Data for FormData
            vm.attachmentFormData = (etr_id, att) =>{
                let fd = new FormData()
                fd.append('etr_id', etr_id)
                fd.append('etr_emp',getEmpIdFromPerID(vm.currentTrainingRecord.emp_per))
                fd.append('comment', att.comments)
                fd.append('type', att.type)
                fd.append('filename', att.name)
                fd.append("attfile", att)
                return fd
            }

             // convert the JSON Data for FormData
             vm.attachmentBulkFormData = (etr_id, emp_per, att) =>{
                let fd = new FormData()
                let emp = []
                for(let e of emp_per){
                    emp.push(getEmpIdFromPerID(e))
                }
                fd.append('etr_id', etr_id)
                fd.append('etr_emp', emp)
                fd.append('comment', att.comments)
                fd.append('type', att.type)
                fd.append('filename', att.name)
                fd.append("attfile", att)
                return fd
            }

            // function to hide the 'retired' status on new mode
            function trainingStatusListHideShow(){
                let i = 0
                currentTrainingStatusList = JSON.parse(JSON.stringify(vm.trainingStatus))
                currentTrainingStatusList.forEach((status) => {                                     
                    if(status.rld_name === vm.retiredTag && vm.currentMode === 'new')
                        status['status_enable']  = 0 
                    else
                        status['status_enable']  = 1                        
                })
                vm.trainingStatus = currentTrainingStatusList   
            }

            

            // Open the Add/Edit training Modal
            vm.openModal = (modalId, mode="new", id, bulkFlag) => {
                vm.resetForm()
                resetCurrentMultiItem()
                let selectMode = mode
                vm.isEnableTrainingStatus = (selectMode === 'integrated')? true: false
                vm.viewTrainingOnly = vm.canManageTrainingStatus
                if(!vm.canManageTrainingRecords && vm.canViewTrainingRecords){
                    mode = "changetrainingstatus"
                } else 
                    vm.viewTrainingOnly = false
                

                if(mode === "new"){
                    vm.showDatePickers = false
                    
                    vm.tmp_trainingRecords = []
                    if (bulkFlag === 'Bulk'){
                        vm.isBulk = true
                        vm.currentTrainingRecord.isBulk = true
                    } else {
                        vm.isBulk = false
                    }
                    vm.currentMode = 'new'
                    trainingStatusListHideShow() 
                    if(modalId=='generalActionModal'){
                        let message={activeFormID:null,incidentId:null,moduleId:null}
                        message.activeFormID='372298'
                        $rootScope.$broadcast("OPENMOBILEFRAME", message)
                    }
                    else{
                        modalService.Open(modalId)
                        vm.initializeSelect2(modalId)
                    }                  

                    var tranData = []
                    vm.currentTranslationList = vm.getCurrentTranslationList(tranData)          
                  
                }
  
                else{
                    vm.currentMode = 'edit'
                    if(mode === 'integrated' || mode === 'changetrainingstatus'){
                        vm.currentMode = 'integrated'   
                        vm.hideAllButtonOnIntegrated = true
                    }   
                    vm.showAnother = false
                    vm.isBulk = false
                    vm.trainingRecords.forEach((main)=>{
                        main.training.forEach((train)=> {
                            if(id == train.etr_id) {
                                let emp_id = getEmpIdFromPerID(main.emp_per_id)
                                vm.currentTrainingRecord = JSON.parse(JSON.stringify(train))
                                vm.currentTrainingRecord.etr_training_status
                                vm.currentTrainingRecord.emp_id = emp_id
                            }
                        })
                    })

                    modifyCurrentTrainingRecordAttachments(id)
                    vm.currentTrainingRecordOriginal = JSON.parse(JSON.stringify(vm.currentTrainingRecord))
                    trainingStatusListHideShow()
                    
                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId)
                    vm.toggleNonExpiry()
                    vm.performStatusEvent()
                }                
            }

            modifyCurrentTrainingRecordAttachments = (id) => {
                vm.currentTrainingRecord.attachments.forEach((doc)=>{
                    if(doc.eta_attachment_type == 2){
                        doc.eta_etr_url = doc.eta_attachment_name
                        doc.file_type = 'link'
                    }
                    else{
                        findExt = doc.eta_attachment_name.split(".")
                        let ext = findExt[findExt.length -1].toUpperCase()
                        doc.eta_etr_extension = ext
                        doc.file_type = vm.fileTypesImages.includes(ext) ? 'image' : 'document'
                        doc.eta_etr_url = `${__env.imageUrl}training_attachments/employee_id_${vm.currentTrainingRecord.emp_id}/training_id_${id}/${doc.eta_attachment_name}`
                    }
                })
            }

            // TRAINING MAIRX CODE
            vm.openTrainingMatrixModal = (modalId) => {
                lang_number = localStorage.getItem('lang_id')
                vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${'training_matrix_summary?report_selection=110'}&training_codes=1&lang=${lang_number}`)
                $window.open(vm.reportURL, "_blank")

            }

            // TRAINING MATRIX CODE ENDS

            

            function getThumbnailIcon(ext){
                switch(ext.toUpperCase()) {
                case "PDF": return `imagecontainer pdf_thumbnail`
                default: return `style="background-image: url(https://placehold.it/500x700);"`
                }
            }   

            //Functions to delete attachments         
            vm.deleteInitialAttachment = (index) =>{ 
                vm.stepsModel.splice(index, 1)
                vm.uploadFileList.splice(index, 1)
            }

            //Functions to delete attachments         
            vm.deleteAttachmentCurrentTraining = (index) =>{ 
                vm.stepsModel.splice(index, 1)
                vm.currentTrainingRecord.attachments[index].eta_enable = false
            }

            //Function to close the modal
            vm.cancelRecord = (id) => {
                vm.resetForm()
                modalService.Close(id);
                vm.addAnother = false
                resetFormFieldClassList('trainingCodes')
                resetFormFieldClassList('trainingRecords')
                if (vm.refreshFlag){ 
                    vm.refreshFlag = false
                    vm.refreshTrainingRecords()
                }
            }

            //Function to open confirm archive training record modal
            vm.confirmTrainingArchive = (id) => {
                if(!vm.canArchiveTrainingRecords)
                    return
                vm.selectedTrainingRecord = id
                vm.modalElementsArchive = {
                    title: translateTag(9076), //"Archive Training Record?"
                    message: `<div><p>${translateTag(9077)}</p></div>`, //"You are about to archive this training record. Undoing this will require IT support. Are you sure?"
                    buttons: 
                    `<button class="btn btn-primary btn-rounded" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                    <button class="btn btn-outline-primary btn-rounded" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                }     
                document.getElementById('confirmcallingform').innerHTML = 'ADMINTRAININGARCHIVECALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsArchive)
            }

            $scope.$on("ADMINTRAININGARCHIVECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.archiveTraining()
                }
                else if(result=='button2'){
                    vm.confirmArchiveCancel()
                }
            })

            //Function to archive training record
            vm.archiveTraining = () =>{
                if(!vm.canArchiveTrainingRecords) {
                    toastr.error(translateTag(3822)) //You do not have permission
                    return
                }
                adminTrainingService.archiveTrainingRecord ({etr_id: vm.selectedTrainingRecord}).then (() => {
                    vm.refreshTrainingRecords()
                    modalService.Close('confirmModal')
                })
            }

            //Function to close confirm archive training record modal
            vm.confirmArchiveCancel = () => {
                vm.selectedTrainingRecord = null
                modalService.Close('confirmModal')
            }

            //Funtion to initialize select2
            vm.initializeSelect2 = (parent)=> {
                setTimeout(()=>{ 
                $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} .modal-body`), escapeMarkup: function (text) { return text } })
                .on('select2:select', () => {
                    $(this).parent().find('label').addClass('filled');
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down");                  // Add caret on selects
                select2Service.select2Tags()
                }, 100)
                today = new Date()
                if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
                $('.datepicker').pickadate({
                format: 'yyyy-mm-dd',
                onClose : function(){
                    this.$holder.blur()
                },
                selectYears: 80,
                min: new Date(moment(today).subtract(40,'years').calendar()),
                max: new Date(moment(today).add(40,'years').calendar()),
                }).removeAttr('readonly')
                .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                    evt.preventDefault()
                })
            }

        // Refresh Training records 
        vm.refreshTrainingRecords = () => {
            $scope.$emit('STARTSPINNER', vm.loadMessage)
            adminTrainingService.getTrainingRecords({status: vm.statusDisplay.toLowerCase()}).then((data) => {
                    vm.trainingRecords = prepareTrainingGridData(adminTrainingService.readTrainingRecords())
                    if(vm.trainingRecords != null)
                    try{
                        translateAgGridHeader(vm.trainingOptions)
                        vm.trainingOptions.api.setRowData(vm.trainingRecords)
                        vm.trainingOptions.api.redrawRows()
                        vm.trainingOptions.api.sizeColumnsToFit()
                    }catch(e){}

                    vm.resetForm()
                    vm.actionDisabled = true
                    $scope.$emit('STOPSPINNER')    
            })
        }

        function getSelectedLanguageID (name)
        {
            for(var lang in vm.systemLanguages)
            {
                lang = vm.systemLanguages[lang]
                if(lang.lng_name.toLowerCase() === name.toLowerCase())
                    return lang.lng_id
            }
            return 1
        }

        function getDefaultLanguageID ()
        {
            for(var lang in vm.systemLanguages)
            {
                lang = vm.systemLanguages[lang]
                if(lang.lng_default)
                    return lang.lng_id
            }
            return 1
        }

        // main function for retrieving data and populating the Main Training Grid
        vm.refreshData = (clear=false) =>{  
            if(!vm.loading){
            if(clear){    
                vm.loading = true                    
                $q.all([
                    listService.getEmployeeList(),                
                    listService.getSelectListData('ref_training_institution'),
                    listService.getSelectListData('ref_training_type'),
                    listService.getSelectListData('ref_training_code'),
                    listService.getAllEmployeeList(),
                    adminTrainingService.getFullTrainingRefList('ref_training_code'),
                    adminTrainingService.getFullTrainingRefList('ref_training_type'),
                    adminTrainingService.getFullTrainingRefList('ref_training_institution'),
                    adminTrainingService.getFullTrainingRefList('ref_training_status'),
                    profileService.getFullEmployeeProfile(),
                    ]).then((data) => {
                        vm.trainingCodeList = data[3]
                        vm.fullTrainingCodeList = adminTrainingService.readTrainingCodeList()
                        vm.fullTrainingTypeList = adminTrainingService.readTrainingTypeList()
                        vm.fullTrainingInstitutionList = adminTrainingService.readTrainingInstitutionList()
                        vm.trainingTypeList = data[2]
                        vm.institutionList = data[1]
                        vm.employeeList = data[0]
                        vm.allEmployeeList = data[4] 
                        vm.fullEmployeeList = profileService.readFullEmployeeProfile()  
                        vm.trainingStatus = adminTrainingService.readtrainingStatusList()   
                        vm.trainingStatusName = vm.getTrainingObject(vm.trainingStatus, value = "name")  
                        vm.trainingCodeObject = vm.getTrainingObject(vm.fullTrainingCodeList, value = "rld_code")
                        vm.trainingCodeNameObject = vm.getTrainingObject(vm.fullTrainingCodeList, value = "name")  
                        vm.trainingTypeObject = vm.getTrainingObject(vm.fullTrainingTypeList, value = "name")
                        vm.trainingInstitutionObject = vm.getTrainingObject(vm.fullTrainingInstitutionList, value="name")
                        clear?vm.resetForm():''
                        vm.actionDisabled = true    
                    })
             }
            else{
                       
                // existing code part for reload back data
                $scope.$emit('STARTSPINNER', vm.loadMessage)
                vm.loading = true
                $q.all([
                listService.getEmployeeList(),                
                listService.getSelectListData('ref_training_institution'),
                listService.getSelectListData('ref_training_type'),
                listService.getSelectListData('ref_training_code'),
                listService.getAllEmployeeList(),
                adminTrainingService.getTrainingRecords({status: vm.statusDisplay.toLowerCase()}),
                adminTrainingService.getFullTrainingRefList('ref_training_code'),
                adminTrainingService.getFullTrainingRefList('ref_training_type'),
                adminTrainingService.getFullTrainingRefList('ref_training_institution'),
                adminTrainingService.getFullTrainingRefList('ref_training_status'),
                i18nService.getLanguages(),
                profileService.getFullEmployeeProfile(),
                ]).then((data) => {
                    vm.fullTrainingCodeList = adminTrainingService.readTrainingCodeList()
                    vm.fullTrainingTypeList = adminTrainingService.readTrainingTypeList()
                    vm.fullTrainingInstitutionList = adminTrainingService.readTrainingInstitutionList()
                    vm.trainingCodeList = data[3]
                    vm.trainingTypeList = data[2]
                    vm.institutionList = data[1]
                    vm.employeeList = data[0]
                    vm.allEmployeeList = data[4]
                    vm.fullEmployeeList = profileService.readFullEmployeeProfile() 
                    vm.tmp_trainingRecords = []
                    
                    vm.trainingRecords = prepareTrainingGridData(adminTrainingService.readTrainingRecords())
                   
                    vm.systemLanguages = i18nService.readLanguageList().languages
                    vm.selectedLanguageID = getSelectedLanguageID(selectedLanguage)
                    vm.defaultLanguageID = getDefaultLanguageID()
                    vm.trainingStatus = adminTrainingService.readtrainingStatusList()  

                    vm.trainingStatusName = vm.getTrainingObject(vm.trainingStatus, value = "name")  
                    vm.trainingCodeObject = vm.getTrainingObject(vm.fullTrainingCodeList, value = "rld_code")
                    vm.trainingCodeNameObject = vm.getTrainingObject(vm.fullTrainingCodeList, value = "name")  
                    vm.trainingTypeObject = vm.getTrainingObject(vm.fullTrainingTypeList, value = "name")
                    vm.trainingInstitutionObject = vm.getTrainingObject(vm.fullTrainingInstitutionList, value="name")
                    try{
                     translateAgGridHeader(vm.trainingOptions)
                        if(vm.trainingRecords != null)
                            vm.trainingOptions.api.setRowData(vm.trainingRecords)
                            
                        vm.trainingOptions.api.redrawRows()
                        vm.trainingOptions.api.sizeColumnsToFit()
                        // Reset total rows for master detail grid
                        vm.currentTotalRows =  vm.trainingOptions.api.getDisplayedRowCount()
                        setTotalRowsForMasterDetailGrid("total_number_records", vm.currentTotalRows)
                    } catch(e){}

                    clear?vm.resetForm():''
                    vm.actionDisabled = true
                    
                    $scope.$emit('STOPSPINNER')
                    vm.loading = false
                })
            }
            }

        }
        vm.trainingOptions.onGridReady = () => {
            vm.refreshData()
        }

            //Function to prepare Ag-Grid data
            function prepareTrainingGridData(data) {
                let gridData = JSON.parse(JSON.stringify(data))
                gridData.forEach((rec) =>{
                    rec.exceptionFields = ['emp_per_id']
                    rec.prefix = []
                    rec.endfix = []
                    rec.emp_name = getEmployeeName(rec.emp_per_id)

                })
                return gridData
            }

            vm.getTrainingObject = (list, value) =>{
                let training_object = {}
                list.forEach(element => {
                    training_object[element['rld_id']] = element[value]
                });
                return training_object
            }
            // Prepares the data for the sub grid and the tippy.
            // need to update and correctly accommodate the status.
            function prepareDetailTrainingGridData(data){
                let gridData = JSON.parse(JSON.stringify(data))
                let rtrn = []
                gridData.training.forEach((train) =>{
                    let sts;
                    let expiryDate = new Date(train.etr_expiry_date)
                    let currentDate = new Date()
                    let warningDate = new Date(expiryDate)
                    let expDate;  
                    
                    sts = translateLabels(vm.getTrainingStatus(train.etr_training_status))
                    
                    let training_status_option = vm.getTrainingStatusOption(train.etr_training_status)

                    // needed - in progress -  Scheduled
                    if( training_status_option== vm.neededTag || training_status_option==  vm.inProgressTag || training_status_option== vm.scheduledTag ){
                        sts = translateLabels(vm.getTrainingStatus(train.etr_training_status))
                    }                    
                    else if(training_status_option==vm.retiredTag){
                        sts = translateLabels(vm.getTrainingStatus(train.etr_training_status)) // Retired
                        expDate =  train.etr_expiry_date
                    }
                    else{
                        if(train.etr_no_expiry_date == 1){
                            sts=  translateTag(3557) //"Active"
                            expDate =  translateTag(1381) // 'N/A'
                        } 
                        else{
                            warningDate.setMonth(warningDate.getMonth() -1)
                            if (expiryDate < currentDate){
                                sts= translateTag(3494) //'Expired'
                                expDate =  train.etr_expiry_date
                            }
                            else if(warningDate < currentDate) {
                                sts= translateTag(8865) //'About to Expire'
                                expDate =  train.etr_expiry_date
                            }
                            else{
                                sts= translateTag(3557) //'Active'
                                expDate = train.etr_expiry_date
                            }
                        }
                    }
                    let trainData = {
                        Emp_ID : train.etr_emp,
                        Train_ID : train.etr_id,
                        Training_Code :getTrainingCodeName(train.etr_training_code).code,
                        Completion_Date: train.etr_completion_date,
                        Expiry_Date : expDate,
                        Type : getTrainingTypeName(train.etr_training_type),
                        Institution : getTrainingInstitutionName(train.etr_training_institution),
                        Value : getTrainingCodeName(train.etr_training_code).training_value,
                        Training_Description: getTrainingCodeName(train.etr_training_code).training_description,
                        Status: sts,
                        No_Expiry : train.etr_no_expiry_date,
                        etr_training_status: train.etr_training_status,
                        Modified_By: getEmployeeNamePerID(train.etr_modified_by_per),
                        Modified_Date: train.etr_modified_date==null ? '':  moment(train.etr_modified_date).format('YYYY-MM-DD'),
                        Is_Integrated : train.etr_is_integrated ,
                    }
                    trainData.exceptionFields = ['No_Expiry', 'Emp_ID', 'Train_ID', 'etr_training_status', 'Is_Integrated']
                    rtrn.push(trainData)
                }) 
                return rtrn
            }

            //Fuctions to check if all modal feilds are valid
            vm.ValidateTrainingCode = () => {
                let validated = validateFormFields('trainingCodes')
                //check if the Code is already in the list
                vm.trainingCodeList.forEach((e)=>{
                    if(e.rld_name && e.rld_code && vm.currentItem.rld_code)
                    {
                        if(e.rld_code.toUpperCase() === vm.currentItem.rld_code.toUpperCase()){

                            validated = false
                            resetFormFieldClassList('trainingCodes')
                            toastr.error(translateTag(8686))
                        }
                    }
                })
                
                return validated
            }
            vm.ValidateTrainingMatrix = () => {
                return validateFormFields('trainingMatrix')
            }


            vm.updateBulkTrainingRecords = () => {
                modalService.Close("confirmModal")
                vm.saveBulkTrainingRecords('TrainingEditModal')
            }



            vm.validateBulkTrainingRecords = () => {
                resetFormFieldClassList('trainingRecords')
                let validated = validateFormFields('trainingRecords')
                vm.duplicateFlag = false
                if (!validated) {
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
                else{
                    if (vm.isBulk){
                        if(vm.addAnother || vm.refreshFlag) {
                            vm.currentTrainingRecord.emp_per.forEach((per)=>{
                                vm.tmp_trainingRecords.forEach((t)=> {
                                    if( (t.emp_per.find(e => per===e)) &&  
                                        t.etr_training_code == vm.currentTrainingRecord.etr_training_code){
                                        vm.duplicateFlag = true
                                    }
                                })
                            })
                        } 
                        vm.currentTrainingRecord.emp_per.forEach((per)=>{
                            vm.trainingRecords.forEach((tr)=> {
         
                                tr.training.forEach((t)=> {
                                    if( t.emp_per == per &&
                                        t.etr_training_code == vm.currentTrainingRecord.etr_training_code ) {
                                        vm.duplicateFlag = true
                                    }
                                })            
                            })
                        })
                        if (vm.duplicateFlag) {
                            vm.updateModal = true
                            vm.modalElementsUpdate = {
                                title: translateTag(3708),  //"Update"
                                message: `<div><p>${translateTag(8639)}</p></div>`, //"Some training records already exist and need to be updated."
                                buttons: 
                                    `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                            }
                            document.getElementById('confirmcallingform').innerHTML = 'UPDATESBULKTRAININGCALLCONFIRMMODAL' 
                            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsUpdate)
                        } else {
                            vm.saveBulkTrainingRecords('TrainingEditModal')
                        }
                    }
                }  
            }

            $scope.$on("UPDATESBULKTRAININGCALLCONFIRMMODAL", (event,result) => {
                 if (result=='button2') {
                    vm.cancelBulkUpdateModal()
                }
            })

            vm.ValidateTrainingRecord = () => {
                resetFormFieldClassList('trainingRecords')
                let formVal = document.forms['trainingRecords']
                let validated = validateFormFields('trainingRecords', false , {filename_1:['//'], filename_2:['//'] })
                if(!validated)
                    return validated
                if(vm.addAnother || vm.refreshFlag) {
                    vm.tmp_trainingRecords.forEach((t)=> {
                        if( t.etr_emp == vm.currentTrainingRecord.emp_per &&
                            t.etr_training_code == vm.currentTrainingRecord.etr_training_code )
                            {
                                validated = false
                                vm.duplicateRecordExists = true 
                                toastr.error(translateTag(8685)) // note="This exact record already exists"
                                return validated
                            }
                    }) 
                }
                
                if(!validated)
                    return validated

                //check if the Record is already in the list
                if(vm.currentTrainingRecordOriginal.etr_emp != vm.currentTrainingRecord.etr_emp || 
                vm.currentTrainingRecordOriginal.etr_training_code != vm.currentTrainingRecord.etr_training_code ){
                    vm.trainingRecords.forEach((tr)=> {
                        tr.training.forEach((t)=> {
                            if(t.emp_per ==  vm.currentTrainingRecord.emp_per && 
                            t.etr_training_code == vm.currentTrainingRecord.etr_training_code){
                                validated = false
                                formVal[0].validity.valid = false
                                formVal[1].validity.valid = false
                                formVal[2].validity.valid = false
                                formVal[3].validity.valid = false
                                resetFormFieldClassList('trainingRecords')
                                vm.duplicateRecordExists = true 
                            }
                        })            
                    })
                }
                if(!validated && vm.duplicateRecordExists){
                    toastr.error(translateTag(8685)) // note="This exact record already exists"
                }
                vm.initializeSelect2('TrainingEditModal')
                return validated
            }

            //Function to dynamically assigning detail row height
            vm.trainingOptions.getRowHeight = function (params) {
                var isDetailRow = params.node.detail;
                
                // for all rows that are not detail rows, return nothing
                if (!isDetailRow) { return 40; }
                // otherwise return height based on number of rows in detail grid
                var detailPanelHeight = (params.data.training.length * 40) + 100
                
                if(params.data.training.length == 1){
                    detailPanelHeight = (params.data.training.length * 40) + 100
                }

                if(params.data.training.length <= 0) //Add extra when grid is empty
                    detailPanelHeight += 30

                return detailPanelHeight;
            }

            // Creating training record zip
            vm.createTrainingRecordZip= () =>{            
                // create the object
                let payload = {}
                // select the grid items
                let rows = vm.trainingOptions.api.getSelectedRows()
      
                // create empty array to store the emp_id
                let empId = []

                // loop through the rows and append the emp_id into empId variable
                rows.forEach(emp =>{                  
                    empId.push(emp.emp_per_id)                    
                })
                // assigning the emp_id to payload
                payload.emp_id = empId             

                adminTrainingService.createTrainingRecordZipFile(payload).then((response) => {                     
                        var blob = new Blob([response.data], { type: response.headers('Content-Type')})                        
                        let filename = "training_record.zip" //response.headers.get('Content-Disposition').split(";")[1].split("=")[1];
                        var link = document.createElement('a');
                        link.href = window.URL.createObjectURL(blob);
                        link.download = filename;
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                })
            }

            //Update Ag-Grid size when window is resized
            $(window).on('resize', () => {
                $timeout(function () {
                    if (vm.trainingOptions.api) {
                        vm.trainingOptions.api.sizeColumnsToFit()

                        vm.trainingOptions.api.forEachDetailGridInfo(function(detailGridInfo) {
                        detailGridInfo.api.sizeColumnsToFit()
                        })
                    }
                });
            });

            vm.showLinkControls = () =>{
                vm.isLinkButton = true
            }

            vm.hideLinkControls = () => {
                vm.isLinkButton = false
                vm.linkUrl = null
            }

            // method for uploading the url/links to the uploadfilelist 
            vm.addLinktoUploadFileList = () => {  
                let element = document.getElementById('linkUrl')
                // if you call direct validateText function you just need to pass array of allowedValues
                if(validateText(vm.linkUrl, ['//'])){ 
                    element.classList.remove('invalid')
                    element.setCustomValidity("")
                    if(vm.linkUrl != null){
                        link = {
                            comments : vm.linkUrl,
                            imageUrl : vm.linkUrl,
                            name : vm.linkUrl,
                            type : "link"                    
                        }
                        vm.uploadFileList.push(link)
                        vm.linkUrl = null

                    }

                } else {

                    element.classList.add('invalid')
                    element.setCustomValidity(false)
                }

            }
            


            // method to show and hide the datepickers if its not completed in status.
            vm.performStatusEvent = () =>{                            
                let selectedStatus = ''
                vm.trainingStatus.forEach( status => {
                    if(status.rld_id === vm.currentTrainingRecord.etr_training_status){
                        selectedStatus = status.rld_option
                    }
                })

                // complete or retired
                if(selectedStatus === vm.completeTag || selectedStatus === vm.retiredTag){    
                    async function showDate () {
                        vm.showDatePickers = 1 
                    }
                    showDate().then(() =>{            
                        vm.initializeSelect2('TrainingEditModal')
                        $scope.$apply()
                    })      
                }
                else{

                    vm.currentTrainingRecord.etr_completion_date = null
                    vm.currentTrainingRecord.etr_expiry_date = null
                    vm.showDatePickers = 0
                }

                
            }

            // function to get the training status name
            vm.getTrainingStatus = (rld_id) =>{
                let selectedStatus = ''
                vm.trainingStatus.forEach( status => {
                    if(status.rld_id === rld_id){
                        selectedStatus = status.name
                    }
                })
                return selectedStatus
            }

            // function to get the training status option
            vm.getTrainingStatusTag = (rld_id) =>{
                let selectedStatus = ''
                vm.trainingStatus.forEach( status => {
                    if(status.rld_id === rld_id){
                        selectedStatus = status.rld_name
                    }
                })
                return selectedStatus
            }

            // Return the training options based on the rld_id.
            vm.getTrainingStatusOption = (rld_id) =>{
                let selectedOption = ''
                vm.trainingStatus.forEach( status => {
                    if(status.rld_id === rld_id){
                        selectedOption = status.rld_option
                    }
                })
                return selectedOption
            }
        // End of AdminTrainingCtrl
        }
    ])
