﻿angular.module('safeToDo')
.controller('EquipmentCtrl', ['$scope', '$rootScope', '$routeParams', '$timeout', '$q', 'equipmentService', 'gridService', 'select2Service', 'modalService', '$compile' ,'i18nService', 'menuService','exportCSV','adminUserService',
    function ($scope, $rootScope, $routeParams, $timeout, $q, equipmentService, gridService, select2Service, modalService, $compile, i18nService, menuService, exportCSV, adminUserService) {
        let vm = this
        
        vm.equipmentTypes = []
        vm.measureTypes = []
        vm.equipmentDelete = false
        vm.removeType = ''
        vm.newEquipmentType = null        
        vm.addAnotherEquipment = false
        vm.addAnotherCheckpoint= false
        vm.addAnotherType= false
        vm.rowResize = true
        vm.actionDisabled = true
        vm.newEquipmentQuestionList = []
        vm.showCheckedOnly = false
        vm.showCheckLableDisplay = translateTag(3945) //All Checkpoints
        vm.questions = []
        vm.pem_measure_rld_id = []
        vm.equipmentList = []
        vm.bulkUpdateEquipList = []
        vm.bulkUpdateList = []
        vm.loadMessage = translateTag(3911) //Loading preop equipment list. Please wait.
        vm.submitted = false
        vm.editingEquipment = false
        vm.addingEquipCheckpoint = false

        vm.topSearch = ""
        vm.equipCheckpointSearch = ""
        vm.addQuestionSearch = ""
        vm.addTypeSearch = ""
        vm.bulkUpdateSearch = ""

        vm.equipmentTypeViewerOpen = false
        vm.hideingEquipmentTypeViewer = false
        vm.openingEquipmentTypeViewer = false

        vm.checkpointViewerOpen = false
        vm.hideingCheckpointViewer = false
        vm.openingCheckpointViewer = false

        vm.equipmentViewerOpen = false
        vm.hideingEquipmentViewer = false
        vm.openingEquipmentViewer = false

        vm.bulkUpdateViewerOpen = false
        vm.hideingBulkUpdateViewer = false
        vm.openingBulkUpdateViewer = false
        vm.selectedCheckpoint = null

        vm.sites = null
        vm.jobs = null

        vm.questionTypeList = [
            {
                questionTypeName: translateTag(1380), //No
                questionTypeId: 1
            },
            {
                questionTypeName: translateTag(1379), //Yes
                questionTypeId: 2
            }         
        ]

        //Function to reset new equipment
        function startNewEquipment(){
            vm.submitted = false
            vm.newEquipment = {
                EquipmentID: '',
                EquipmentType: null,
                pem_measure_rld_id: null,
                questions: [],
                equipment_site:null,
                equipment_jobs:[]
            }
            vm.newEquipmentQuestionList = []
        }
        
        //Function to reset selected equipment
        function selectedEquipment(){
            vm.submitted = false
            vm.selectedEquipment = {
                EquipmentID: '',
                EquipmentType: null,
                questions: [],
                pem_measure_rld_id: [],
                peq_pet_id: null
            }
        }

        //Get permissions for the user
        menuService.getPagePermissions().then((data) => {
            vm.permissions = data  
            vm.canManagePreOps = vm.permissions.includes('Can Manage Equipment Preops') ? true : false
        })

        //#region Translation

        vm.currentTranslationMode = 'new'
        vm.currentTranslationList = []
        vm.systemLanguages = []

        vm.selectedLanguageID = 1
        vm.defaultLanguageID = 1

        vm.getCurrentTranslationList = (data) => {
            var currentTranList = []
            
            for(var lang in vm.systemLanguages)
            {
                lang = vm.systemLanguages[lang]
                if(!lang.lng_selected)
                    continue

                var tranObj = {
                    ltr_lng_id: lang.lng_id,
                    ltr_lng_name: lang.lng_name.toUpperCase(),
                    ltr_lng_description: lang.lng_description_text,                        
                    ltr_lng_default: lang.lng_default ? "*" : "",
                    ltr_text: new Array(data.length).fill(""),
                    ltr_translated:  new Array(data.length).fill(false)
                }
                
                for(var tranList in data)
                {
                    var tranIndex = tranList
                    tranList = data[tranList]
                    for (var tran in tranList)
                    {                        
                        tran = tranList[tran]
                        if(tran.ltr_lng_id == lang.lng_id)
                        {
                            tranObj.ltr_text[tranIndex] = tran.ltr_translated ? tran.ltr_text : ""
                            tranObj.ltr_translated[tranIndex] = tran.ltr_translated
                        }
                    }
                }

                currentTranList.push(tranObj)
            }

            return currentTranList
        }

        vm.getDisplayTranslation = (key, list) => {
            if(!list)
                return

            for(var tran in list[key])
            {
                tran = list[key][tran]                
                if(tran.ltr_lng_id == vm.defaultLanguageID)
                    defaultLanguageText = tran.ltr_text
                if(tran.ltr_lng_id == vm.selectedLanguageID && tran.ltr_text.trim() != "")
                    return tran.ltr_text
            }
            return defaultLanguageText
        }

        function getDefaultTranslation (key, list) {
            if(!list)
                return

            for(var tran in list[key])
            {
                tran = list[key][tran]                
                if(tran.ltr_lng_id == vm.defaultLanguageID)
                    defaultLanguageText = tran.ltr_text
            }
            return defaultLanguageText
        }

        function getSelectedLanguageID (name)
        {
            for(var lang in vm.systemLanguages)
            {
                lang = vm.systemLanguages[lang]
                if(lang.lng_name.toLowerCase() == name.toLowerCase())
                    return lang.lng_id
            }
            return 1
        }

        function getDefaultLanguageID ()
        {
            for(var lang in vm.systemLanguages)
            {
                lang = vm.systemLanguages[lang]
                if(lang.lng_default)
                    return lang.lng_id
            }
            return 1
        }

        //#endregion

        //#region AG-Grid

        vm.equipmentOptions = gridService.getCommonOptions()
        vm.equipmentQuestions = gridService.getCommonOptions()
        vm.addEquipmentTypes = gridService.getCommonOptions()
        vm.addQuestionToList = gridService.getCommonOptions()
        vm.addEquipmentQuestions = gridService.getCommonOptions()     
        vm.equipmentOptions.pagination = false
        vm.equipmentQuestions.pagination = false
        vm.addEquipmentTypes.pagination = false
        vm.addQuestionToList.pagination = false
        vm.addEquipmentQuestions.pagination = false
        vm.equipmentOptions.masterDetail = true
        vm.equipmentOptions.animateRows = false

        //Set parget Ag-Grid colum values/settings
        vm.equipmentOptions.detailCellRendererParams = {
            detailGridOptions: {
                showToolPanel: false,
                toolPanelSuppressRowGroups: true,
                toolPanelSuppressValues: true,
                toolPanelSuppressPivots: true,
                toolPanelSuppressPivotMode: true,
                toolPanelSuppressSideButtons: true,
                suppressContextMenu: true,
                columnDefs: [
                    {
                        field: 'fieldType',
                        headerName: ' ',
                        minWidth: 150,
                        maxWidth: 250,
                        cellRenderer: function (params) {                       
                            return `<span class="clip" ng-non-bindable>${params.data.fieldType}</span>`
                        },
                    },    
                    { 
                        field: 'questionName',
                        headerName: ' ',
                        minWidth:300,
                        cellRenderer: function (params) {
                            return `<span class="clip" ng-non-bindable>${params.value}</span>`
                        },
                    }
                ],
                rowHeight: 40,
                headerHeight:35,
                flex: 1,    
                localeText: sofvie_agGrid_languages[`${selectedLanguage}`]
            },
            getDetailRowData: (params) => {
                params.successCallback(params.data.Questions)
                vm.equipmentOptions.api.forEachDetailGridInfo(function(detailGridInfo) {
                    translateAgGridHeader(detailGridInfo)
                    detailGridInfo.api.sizeColumnsToFit()
                })
            },
            //  onFirstDataRendered: onFirstDataRendered,
        }

        //Set child Ag-Grid colum values/settings
        let equipmentColumns = [
            {
                headerName: '',
                field: 'selected',
                minWidth: 50,
                maxWidth: 50,
                checkboxSelection: true,
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
            },
            {
                field: 'PreOpEquipmentID',
                hide: true,
            },
            {
                field: "review", headerName: " ",  minWidth: 60, maxWidth: 60, suppressMenu: true, suppressSorting: true,
                cellRenderer: (params) => {
                return `<div ng-if="equip.canManagePreOps" class="pointer text-left" ng-click="equip.openEquipmentViewer('edit', '${params.data.PreOpEquipmentID}', '${params.data.EquipmentIdentifier}')">
                    <i class="fa fa-pen" note="Edit" title="{{menu.translateLabels(1194)}}"></i>
                    </div>`;
                }
            },
            {
                field: "NumQuestions",
                headerName: " ",
                minWidth: 100,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                cellRenderer: 'agGroupCellRenderer'
                
            },
            {
                field: "EquipmentIdentifier",
                minWidth: 100,
                maxWidth: 150,
                headerName: " ",
                filter: 'agSetColumnFilter',
                cellRenderer: 'tippyCellRenderer'
                
            },
            {
                field: "EquipDesc",
                headerName: " ",
                minWidth: 100,
                filter: 'agSetColumnFilter',
                cellRenderer: 'tippyCellRenderer',
                sort: 'asc'
            },
            {
                field: "Site",
                headerName: " ",
                minWidth: 100,
                filter: 'agSetColumnFilter',
                cellRenderer: 'tippyCellRenderer',
                sort: 'asc'
            },
            {
                field: "JobNumber",
                headerName: " ",
                minWidth: 100,
                filter: 'agSetColumnFilter',
                cellRenderer: 'tippyCellRenderer',
                sort: 'asc'
            },
            {
                field: "LastModifiedDate",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "ModifiedBy",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "", minWidth: 50, maxWidth: 50, suppressMenu: true, suppressSorting: true,
                cellRenderer: (params) => {
                return `<div ng-if="equip.canManagePreOps" class="pointer text-left" note="Delete Item" title="{{menu.translateLabels(3892)}}" ng-click="equip.confirmDelete('${params.data.EquipmentIdentifier.replace("'","\\'")}','${params.data.PreOpEquipmentID}','${params.data.peq_pet_id}')">
                    <i class="far fa-trash-alt fa-lg"></i>
                    </div>`;
                }
            },
        ]

        vm.equipmentOptions.columnDefs = equipmentColumns;

        //Function to disable action button if no rows are selected
        vm.equipmentOptions.onSelectionChanged = () => {
            var selectedRows = vm.equipmentOptions.api.getSelectedRows()
            vm.actionDisabled = selectedRows.length == 0
            $scope.$apply()
        }

        //Set equipmentQuestion Ag-Grid colum values/settings
        let equipmentQuestionColumns = [
            {
                headerName: 'Selected',
                field: 'selected',
                minWidth: 50,
                maxWidth: 50,
                checkboxSelection: true,
            },
            {
                field: "PreOpQuestion",
                minWidth: 100,
                headerName: "Question",
                filter: 'agSetColumnFilter',
                cellRenderer: function (params) {
                    return `<span class="clip" ng-non-bindable>${params.value}</span>`
                },
            }
        ]

        //Set addQuestion Ag-Grid colum values/settings
        let addQuestionColumns = [
            {
                headerName: '',
                field: 'selected',
                minWidth: 50,
                maxWidth: 50,
                checkboxSelection: true,
                cellRenderer: () => {
                    return null
                }
            },
            {
                field: "poq_preop_question",
                minWidth: 100,
                headerName: "Question",
                filter: 'agSetColumnFilter',
                cellRenderer: function (params) {
                    return `<span class="clip" ng-non-bindable>${params.value}</span>`
                }
            },
            {
                field: "QuestionID",
                hide: true,
            }
        ]

        //Set addQuestionToList Ag-Grid colum values/settings
        let addQuestionToListColumns = [
            {
                field: "checkpoint_field_type",
                minWidth: 150,
                maxWidth: 250,
                headerName: "",
                filter: 'agSetColumnFilter',
                cellRenderer: function (params) {
                    return `<span class="clip" ng-non-bindable>${params.value}</span>`
                }
            },
            // 
            {
                field: "poq_preop_question",
                minWidth: 100,
                headerName: "Question",
                filter: 'agSetColumnFilter',
                cellRenderer: function (params) {
                    return `<span class="clip" ng-non-bindable>${params.value}</span>`
                }
            },
            {
                field: "PreOpQuestionID",
                hide: true,
            },
            {
                field: "", headerName: "",  minWidth: 50, maxWidth: 50, suppressMenu: true, suppressSorting: true,
                cellRenderer: (params) => {
                    return `<div class="pointer text-left" ng-click="equip.openCheckpointTranslationModal('edit', ${params.data.poq_id})"><i class="fa fa-pen" style="color: #212529 !important;" note="Edit" title="{{menu.translateLabels(1194)}}"></i></div>`;
                }
            },
            {
                field: "", headerName: "",  minWidth: 50, maxWidth: 50, suppressMenu: true, suppressSorting: true,
                cellRenderer: (params) => {
                    return `
                    <div class="pointer text-left" note="Delete Item" title="{{menu.translateLabels(3892)}}" ng-click="equip.confirmCheckpointDelete('${params.data.poq_id}')">
                    <i class="far fa-trash-alt fa-lg"></i>
                    </div>`;                                              
                  
                }
            }
        ]

        //Set addEquipmentType Ag-Grid colum values/settings
        let addEquipmentTypeColumns = [
            {
                field: "EquipDesc",
                minWidth: 200,
                headerName: "Equipment Type",
                filter: 'agSetColumnFilter',
            },
            {
                field: "PreOpEquipmentID",
                hide: true,
            },
            {
                field: "", headerName: "",  minWidth: 50, maxWidth: 50, suppressMenu: true, suppressSorting: true,
                cellRenderer: (params) => {
                    return `<div class="pointer text-left" ng-click="equip.openEquipmentTypeTranslationModal('edit', ${params.data.poe_id})"><i class="fa fa-pen" style="color: #212529 !important;" note="Edit" title="{{menu.translateLabels(1194)}}"></i></div>`;
                }
            }
            
        ]

        vm.equipmentQuestions.columnDefs = equipmentQuestionColumns
        vm.equipmentQuestions.headerHeight = 0
        vm.addEquipmentQuestions.columnDefs = addQuestionColumns
        vm.addEquipmentQuestions.headerHeight = 0
        vm.addEquipmentTypes.columnDefs = addEquipmentTypeColumns
        vm.addEquipmentTypes.headerHeight = 0
        vm.addEquipmentTypes.rowHeight = 45
        vm.addQuestionToList.columnDefs = addQuestionToListColumns
        vm.addQuestionToList.headerHeight = 0     

        //#endregion        

        vm.actionPressed = (tag) => {
            $(`#${tag}`).addClass('show')
        }

        $(window).click((e) => {
            $('#myDropdown').removeClass('show')
            $('#myActionDropdown').removeClass('show')
        })

        // Calling a function to display the number of filtered records when filter changes
        vm.equipmentOptions.onFilterChanged = () => {
            setTotalRowsForMasterDetailGrid("total_number_records", vm.equipmentOptions.api.getDisplayedRowCount())
        }
        
        //#region Functions for the search bars
        vm.topSearchChanged = () => {
            vm.equipmentOptions.api.setQuickFilter(vm.topSearch)
            // Setting total number of displayed rows when filter changes
            setTotalRowsForMasterDetailGrid("total_number_records", vm.equipmentOptions.api.getDisplayedRowCount())
        }
        
        vm.editQuestionModalSearchChanged = () =>{
            vm.addQuestionToList.api.setQuickFilter(vm.addQuestionSearch);
        }
        vm.equipCheckpointsSearchChanged = () =>{
            let filter = vm.equipCheckpointSearch.toUpperCase();
            let li = document.getElementById("sortable").getElementsByTagName('li');

            // Loop through all list items, and hide those who don't match the search
            for (i = 0; i < li.length; i++) {
                let nameText = li[i].querySelector('.check_search');

                let txtValueName = nameText.textContent || nameText.innerText;

                if (txtValueName.toUpperCase().indexOf(filter) > -1) {
                    li[i].style.display = "";
                } else {
                    li[i].style.display = "none";
                }
            }
        }
        vm.addTypeSearchChanged = () =>{
            vm.addEquipmentTypes.api.setQuickFilter(vm.addTypeSearch)
        }

        vm.bulkUpdateSearchChanged = () =>{
            let filter = vm.bulkUpdateSearch.toUpperCase();
            let li = document.getElementById("bulkUpdateList").getElementsByTagName('li');

            // Loop through all list items, and hide those who don't match the search
            for (i = 0; i < li.length; i++) {
                let nameText = li[i].querySelector('.bulkCheck_search');

                let txtValueName = nameText.textContent || nameText.innerText;

                if (txtValueName.toUpperCase().indexOf(filter) > -1) {
                    li[i].style.display = "";
                } else {
                    li[i].style.display = "none";
                }
            }
        }

        vm.refreshSearch = () => {
            vm.equipCheckpointSearch = ""
            vm.addQuestionSearch = ""
            vm.addTypeSearch = ""
            vm.bulkUpdateSearch = ""

            vm.editQuestionModalSearchChanged()
            vm.equipCheckpointsSearchChanged()
            vm.addTypeSearchChanged()
            vm.bulkUpdateSearchChanged()
        }
        //#endregion

        //Functions for export csv     
        vm.prepExport = () => {
            var exportFields = [];
            for (var i = 0; i < vm.sections.length; i++) {
                for (let b = 0; b < vm.sections[i].Fields.length; b++) {
                exportFields.push(vm.sections[i].Fields[b].Name);
                }
            }
            return {
                onlySelected: true,
                columnKeys: exportFields,
                processCellCallback: (params) => {
                    if (!!params.column.colDef.isAttachment) {
                    // return params.value.length;
                    }
                    return params.value;
                }
            }
        }
        vm.exportCSV = () => {            
            let rows = JSON.parse(JSON.stringify(vm.equipmentOptions.api.getSelectedRows()))
            rows = exportCSV.split_nested_lists(rows, 'Questions')           
            exportCSV.export_csv(rows, translateTag(429))            
        }

        //Function to get equipment questions data
        vm.getEquipmentQuestions = (mode='', newCheckpointID=null) => {
            vm.newEquipmentQuestionList = []
            if(vm.newEquipment.EquipmentType == null)
                return
            
            equipmentService.getEquipmentTypeQuestions(vm.newEquipment).then((res)=>{
                vm.questions.forEach((q)=>{
                    q.selected = false
                    q.SortOrder = Number.POSITIVE_INFINITY
                    if(mode === 'edit') {
                        let question = vm.newEquipment.questions.filter(e => e.questionName === q.poq_preop_question )  
                        if(question.length)
                        {
                            q.selected = true
                            q.SortOrder = question[0].SortOrder
                        }
                    }
                    else if(mode != 'edit'  && res != null && res.some( e => e.peq_id === q.poq_id) && res.some( e => e.freq >= 0.75 )  )
                    {
                        q.selected = true
                    }

                    if(newCheckpointID && newCheckpointID == q.poq_id)
                    {
                        q.selected = true
                    }
                    vm.newEquipmentQuestionList.push(q)
                })

                vm.newEquipmentQuestionList = vm.newEquipmentQuestionList.sort((a, b) => (a.SortOrder > b.SortOrder) ? 1 : -1) // Sort questions by SortOrder
                $timeout(() => {
                    dragAndSort()
                }, 1000)
            })
        } 
       
        //Function to confirm remove an equipment
        vm.confirmDelete = (equipmentID, equipmentType, peq_pet_id) => {
            selectedEquipment()
            vm.selectedEquipment.EquipmentID = equipmentID
            vm.selectedEquipment.EquipmentType = equipmentType
            vm.selectedEquipment.peq_pet_id = peq_pet_id
            vm.ModalElementsEquipment = {
                title: translateTag(3909), //"Confirm Deletion"
                message: `<div><p>${translateTag(3910)}</p></div>`, //"You are about to delete this record. Undoing this will require IT support. Are you sure?"
                buttons: 
                `<button class="btn btn-primary btn-rounded" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                <button class="btn btn-outline-primary btn-rounded" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`         
            }
            document.getElementById('confirmcallingform').innerHTML = 'EQUIPMENTDELETECALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.ModalElementsEquipment)
        }

        $scope.$on("EQUIPMENTDELETECALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.removeEquipment()
            }
            else if(result=='button2') {
                vm.confirmCancel()
            }
        })
        
        //Function to remove an equipment
        vm.removeEquipment = () => {
            equipmentService.removeEquipment(vm.selectedEquipment).then(() => {
                vm.refresh()
                toastr.success(translateTag(3940)) //Equipment Deleted
                modalService.Close('confirmModal');
            })
        }

        //Function to confirm remove checkpoints
        vm.confirmCheckpointDelete = (id) => {         
            vm.selectedCheckpoint = id
            vm.modalElementsCheckpoints = {
                title: translateTag(3909), //"Confirm Deletion"
                message: `<div><p>${translateTag(2820)}</p></div>`, //"The checkpoint will be removed from all equipment Pre-OP lists it is currently being used on. This action is permanent. Do you want to proceed?"
                buttons: 
                `<button class="btn btn-primary btn-rounded" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                <button class="btn btn-outline-primary btn-rounded" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`         
            }
            document.getElementById('confirmcallingform').innerHTML = 'CHECKPOINTCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsCheckpoints)
        }

        $scope.$on("CHECKPOINTCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.removeCheckpoint()
            }
            else if(result=='button2') {
                vm.confirmCheckpointCancel()
            }
        })

        // checkpoint model for deleting 
        vm.removeCheckpoint = () =>{
            equipmentService.archiveCheckPoint ({PreOpQuestionID:vm.selectedCheckpoint}).then (() => {
                refreshCheckpoints ()
                toastr.success(translateTag(8708)) //Checkpoint Deleted
                modalService.Close('confirmModal');
            })
        }
        // checkpoint modal cancel
        vm.confirmCheckpointCancel = () => {
            vm.selectedCheckpoint = null
            modalService.Close('confirmModal');
        }

        //Function to cancel remove equipment
        vm.confirmCancel = () => {
            selectedEquipment()
            modalService.Close('confirmModal');
        }

        //Function for questions Ag-Grid filter
        vm.showChecked =(mode) =>{
            if(mode === 'SHOW CHECKED ITEMS ONLY') {
                vm.showCheckedOnly = true
                vm.showCheckLableDisplay = translateTag(3944) //Selected Checkpoints
            }
            else 
            {
                vm.showCheckedOnly = false
                vm.showCheckLableDisplay = translateTag(3945) //All Checkpoints
            }
        }        
        
        vm.openEquipmentTypeViewer = () => {            
            vm.hideingEquipmentTypeViewer = false
            vm.equipmentTypeViewerOpen = true
            vm.openingEquipmentTypeViewer = true
            vm.refreshSearch()
            vm.addEquipmentTypes.api.setRowData(vm.equipmentTypes)
            vm.addEquipmentTypes.api.sizeColumnsToFit()
            vm.addEquipmentTypes.api.redrawRows()
        }

        vm.closeEquipmentTypeViewer = () => {
            vm.hideingEquipmentTypeViewer = true

            $timeout(() => {
                vm.equipmentTypeViewerOpen = false
            }, 400)
        }

        vm.openEquipmentTypeTranslationModal = (mode, id) => {
            vm.submitted = false
            resetFormFieldClassList('equipmentTypeTranslationForm')
            if(mode == 'new')
            {
                vm.newEquipmentType = {
                    preop_equipment_id: null,
                    equipment_type_names: null
                }
            }
            else
            {
                vm.equipmentTypes.forEach((equipType) =>
                {
                    if(equipType.poe_id == id)
                    {
                        vm.newEquipmentType = {
                            preop_equipment_id: equipType.poe_id,
                            equipment_type_names: equipType.equipment_descriptions
                        }
                    }
                })
            }

            var tranData = []
            tranData.push(vm.newEquipmentType['equipment_type_names'])
            vm.currentTranslationList = vm.getCurrentTranslationList(tranData)

            vm.currentTranslationMode = mode
            modalService.Open('equipmentTypeTranslationModal')
            vm.initializeSelect2('equipmentTypeTranslationModal', '.modal-body')
        }

        vm.saveEquipmentType = () => {
            if(vm.validateEquipmentType())
            {
                vm.submitted = true
                vm.newEquipmentType['equipment_type_names'] = prepareEquipmentTypeTranslationPayload(vm.currentTranslationList)

                if(vm.currentTranslationMode == 'new')
                {
                    equipmentService.addEquipmentType(vm.newEquipmentType).then(() => {
                        modalService.Close('equipmentTypeTranslationModal')
                        vm.currentTranslationList = []
                        vm.newEquipmentType = {}
                        vm.submitted = false

                        refreshEquipTypes()
                    })
                }
                else
                {
                    if(!vm.valueChanged) //If the values entered are the same as before we dont want to update
                    {
                        modalService.Close('equipmentTypeTranslationModal')
                        vm.currentTranslationList = []
                        vm.newEquipmentType = {}
                        vm.submitted = false

                        refreshEquipTypes()
                    }
                    else
                    {
                        equipmentService.updateEquipmentType(vm.newEquipmentType).then(() => {
                            modalService.Close('equipmentTypeTranslationModal')
                            vm.currentTranslationList = []
                            vm.newEquipmentType = {}
                            vm.submitted = false

                            refreshEquipTypes()
                        })
                    }
                }
            }
            else{
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        function prepareEquipmentTypeTranslationPayload (data) {
            var payload = []

            for(var tran in data) {
                tran = data[tran]
                var payloadTran = {
                    ltr_lng_id: tran.ltr_lng_id,
                    ltr_text: tran.ltr_text[0].trim()
                }

                if(payloadTran.ltr_text != "")
                    payload.push(payloadTran)
            }
                
            return payload
        }

        vm.openCheckpointViewer = () => {            
            vm.hideingCheckpointViewer = false
            vm.checkpointViewerOpen = true
            vm.openingCheckpointViewer = true
            vm.refreshSearch()
            vm.addQuestionToList.api.setRowData(vm.questions)
            vm.addQuestionToList.api.sizeColumnsToFit()
            vm.addQuestionToList.api.redrawRows()
        }

        vm.closeCheckpointViewer = () => {
            vm.hideingCheckpointViewer = true

            $timeout(() => {
                vm.checkpointViewerOpen = false
            }, 400)
        }

        vm.addEquipCheckpoint = () => {
            vm.addingEquipCheckpoint = true
            vm.openCheckpointTranslationModal('new')
        }

        vm.openCheckpointTranslationModal = (mode, id) => {
            vm.submitted = false
            resetFormFieldClassList('checkpointTranslationForm')
            if(mode == 'new')
            {
                vm.newQuestion = {
                    preop_question_type: 1,
                    poq_pct_id :1,
                    preop_questions: []
                }
            }
            else
            {
                vm.questions.forEach((checkpoint) =>
                {
                    if(checkpoint.poq_id == id)
                    {
                        vm.newQuestion = {
                            preop_question_id: checkpoint.poq_id,
                            preop_questions: checkpoint.preop_questions,
                            preop_question_type: checkpoint.poq_preop_questionmode_id,
                            poq_pct_id: checkpoint.poq_pct_id
                            
                        }
                    }
                })  
            }

            var tranData = []
            tranData.push(vm.newQuestion['preop_questions'])
            vm.currentTranslationList = vm.getCurrentTranslationList(tranData)

            vm.currentTranslationMode = mode
            modalService.Open('checkpointTranslationModal')
            vm.initializeSelect2('checkpointTranslationModal', '.modal-body')
        }

        vm.saveCheckpoint = () => {
            if(vm.validateCheckpoint())
            {
                vm.submitted = true

                vm.newQuestion['preop_questions'] = prepareCheckpointTranslationPayload(vm.currentTranslationList)

                if(vm.currentTranslationMode == 'new')
                {
                    equipmentService.addCheckpoint(vm.newQuestion).then((response) => {
                        modalService.Close('checkpointTranslationModal')
                        vm.currentTranslationList = []
                        vm.newQuestion = {}
                        vm.submitted = false

                        refreshCheckpoints(response.ID)              
                    })
                }
                else
                {
                    if(!vm.valueChanged) //If the values entered are the same as before we dont want to update
                    {
                        modalService.Close('checkpointTranslationModal')
                        vm.currentTranslationList = []
                        vm.newQuestion = {}
                        vm.submitted = false
                        refreshCheckpoints()
                    }
                    else
                    {
                        equipmentService.updateCheckpoint(vm.newQuestion).then(() => {
                            modalService.Close('checkpointTranslationModal')
                            vm.currentTranslationList = []
                            vm.newQuestion = {}
                            vm.submitted = false
                            refreshCheckpoints()
                        })
                    }
                }
            }
            else{
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        function prepareCheckpointTranslationPayload (data) {
            var payload = []

            for(var tran in data) {
                tran = data[tran]
                var payloadTran = {
                    ltr_lng_id: tran.ltr_lng_id,
                    ltr_text: tran.ltr_text[0].trim()
                }

                if(payloadTran.ltr_text != "")
                    payload.push(payloadTran)
            }
                
            return payload
        }        

        vm.openEquipmentViewer = (mode, EquipmentTypeID, EquipmentIdentifier, pem_measure_rld_id) => {
            resetFormFieldClassList('equipmentInfoForm')
            vm.hideingEquipmentViewer = false
            vm.equipmentViewerOpen = true
            vm.openingEquipmentViewer = true
            vm.addAnotherEquipment = false
            
            vm.refreshSearch()
            
            if(mode == 'edit')
            {
                vm.editingEquipment = true
                vm.equipmentList.forEach((equip) => {
                    if(equip.PreOpEquipmentID == EquipmentTypeID && equip.EquipmentIdentifier == EquipmentIdentifier)
                    {
                        vm.newEquipment = {
                            EquipmentID: EquipmentIdentifier,
                            EquipmentType: parseInt(EquipmentTypeID),
                            pem_measure_rld_id:equip.pem_measure_rld_id,
                            questions: equip.Questions,
                            equipment_site:equip.equipment_site,
                            equipment_jobs:equip.equipment_jobs,
                            peq_pet_id:equip.peq_pet_id
                        }
                    }
                })
                vm.getEquipmentQuestions('edit')
                vm.getSiteJobs()
            }         
            else
            {
                vm.editingEquipment = false

                startNewEquipment()
            }

            vm.initializeSelect2('equipment-viewer')
        }

        vm.openCopyEquipmentViewer = (mode) => {
           
            
            if(mode == 'copy'){
                var rows = vm.equipmentOptions.api.getSelectedRows()
                vm.selectedRecordCount = rows.length 
                if (vm.selectedRecordCount === 0){
                    toastr.warning(translateTag(3816)) // No Rows Selected
                    return
                }
                if (vm.selectedRecordCount > 1) {
                    toastr.warning(translateTag(3488))
                    return
                }
                if (vm.selectedRecordCount === 1){   
                    resetFormFieldClassList('equipmentInfoForm')
                    vm.hideingEquipmentViewer = false
                    vm.equipmentViewerOpen = true
                    vm.openingEquipmentViewer = true
                    vm.addAnotherEquipment = false
                    vm.editingEquipment = false
                    
                    vm.refreshSearch()

                    EquipmentTypeID = rows[0].PreOpEquipmentID
                    EquipmentIdentifier = rows[0].EquipmentIdentifier

                    vm.equipmentList.forEach((equip) => {
                        if(equip.PreOpEquipmentID == EquipmentTypeID && equip.EquipmentIdentifier == EquipmentIdentifier)
                        {
                            vm.newEquipment = {
                                EquipmentID: EquipmentIdentifier,
                                EquipmentType: parseInt(EquipmentTypeID),
                                pem_measure_rld_id: equip.pem_measure_rld_id,
                                questions: equip.Questions,
                                equipment_site:equip.equipment_site,
                                equipment_jobs:equip.equipment_jobs
                            }
                        }
                    })   
                    
                    vm.newEquipment.EquipmentID = ''
                    vm.getEquipmentQuestions('edit')
                    vm.getSiteJobs()
                }
            }
            vm.initializeSelect2('equipment-viewer')
        }
        
        vm.closeEquipmentViewer = () => {
            vm.hideingEquipmentViewer = true

            $timeout(() => {
                vm.equipmentViewerOpen = false
                vm.newEquipmentQuestionList = []
            }, 400)
        }

        vm.saveEquipment = () => {
            if(vm.editingEquipment)
            {
                vm.submitted = true
                vm.newEquipment.questions = []
                vm.newEquipmentQuestionList.forEach((check) => {
                    if(check.selected == true){
                        let sortCheck = {
                            ID: check.poq_id,
                            SortOrder: check.SortOrder
                        }
    
                        vm.newEquipment.questions.push(sortCheck)
                    }
                })

                equipmentService.updateEquipment(vm.newEquipment).then((res) => {
                    vm.closeEquipmentViewer()
                    toastr.success(translateTag(3912)) //Equipment Edit Saved
                    vm.refresh()
                    vm.submitted = false
                })
            } 
            else
            {
                if (vm.ValidateEquipment() && vm.CheckEquipmentNotExist()) {
                    vm.newEquipment.questions = []
                    vm.newEquipment.EquipmentID = vm.newEquipment.EquipmentID.toString().toUpperCase()

                    vm.newEquipmentQuestionList.forEach((check) => {
                        if(check.selected == true){
                            let sortCheck = {
                                ID: check.poq_id,
                                SortOrder: check.poq_sort_order
                            }        
                            vm.newEquipment.questions.push(sortCheck)
                        }
                    })
                    if (vm.newEquipment.questions.length>0){
                        vm.submitted = true
                        equipmentService.addEquipment(vm.newEquipment).then((res) => {
                            toastr.success(translateTag(3939)) //Equipment Added
                            if(!vm.addAnotherEquipment)
                            {
                                vm.closeEquipmentViewer()
                                vm.refresh()
                            }
                            else
                            {
                                startNewEquipment()
                                resetFormFieldClassList('equipmentInfoForm')
                                vm.initializeSelect2('equipment-viewer')
                            }
                            vm.submitted = false
                        })
                    }else{
                        toastr.error(translateTag(8909)) // Please have at least one checkpoint selected
                    }
                } 
                else
                {
                    if(!vm.ValidateEquipment()){
                        $rootScope.$broadcast("CALLCONFIRMMODAL")
                    }
                }
            }
        }

        vm.openBulkUpdateViewer = () => {
            let selectedRows = vm.equipmentOptions.api.getSelectedRows()

            if(selectedRows.length <= 0)
            {
                toastr.warning(translateTag(3816)) // No Rows Selected
                return
            }

            vm.hideingBulkUpdateViewer = false
            vm.bulkUpdateViewerOpen = true
            vm.openingBulkUpdateViewer = true
            
            selectedRows.forEach((row) => {
                vm.bulkUpdateEquipList.push({
                    "PreOpEquipmentID": row.PreOpEquipmentID,
                    "EquipmentIdentifier": row.EquipmentIdentifier
                })
            })
            vm.bulkUpdateList = getBulkUpdateCheckpoints()
        }

        function getBulkUpdateCheckpoints () {
            let bulkUpdateCheckpoints = []
            vm.questions.forEach((check) => {
                bulkCheck = {
                    PreOpQuestionID: check.poq_id,
                    PreOpQuestion: check.poq_preop_question,
                    update: 0
                }
                bulkUpdateCheckpoints.push(bulkCheck)
            })

            return bulkUpdateCheckpoints
        }

        vm.closeBulkUpdateViewer = () => {
            vm.hideingBulkUpdateViewer = true

            $timeout(() => {
                vm.bulkUpdateViewerOpen = false
                vm.bulkUpdateEquipList = []
                vm.bulkUpdateList = []
            }, 400)
        }

        vm.saveBulkUpdate = () => {
            vm.submitted = true
            $scope.$emit('STARTSPINNER', translateTag(8714)) //Applying bulk updates

            let add = []
            let remove = []
            vm.bulkUpdateList.forEach((check) => {
                if(check.update == 1)
                    add.push(check.PreOpQuestionID)
                else if(check.update == -1)
                    remove.push(check.PreOpQuestionID)
            })

            let payload = {
                EquipmentIDs: vm.bulkUpdateEquipList,
                PreOpQuestionIDs_Add: add,
                PreOpQuestionIDs_Remove: remove
            }

            equipmentService.bulkUpdate(payload).then((res) => {
                vm.submitted = false
                $scope.$emit('STOPSPINNER')

                vm.closeBulkUpdateViewer()
                vm.refresh()
            })
        }

        vm.cancelModal = (modalId) => {
            modalService.Close(modalId)
            vm.addingEquipCheckpoint = false
        }

        function refreshEquipTypes () {
            $scope.$emit('STARTSPINNER', translateTag(3589)) //Loading data...
            $q.all([
                equipmentService.getEquipmentTypeList()
            ]).then(() => {
                vm.equipmentTypes = equipmentService.readEquipmentTypes()
                if(vm.addEquipmentTypes.api)
                {
                    vm.refreshSearch()
                    vm.addEquipmentTypes.api.setRowData(vm.equipmentTypes)
                    vm.addEquipmentTypes.api.sizeColumnsToFit()
                    vm.addEquipmentTypes.api.redrawRows()
                }
                $scope.$emit('STOPSPINNER')
            })
        }
        function prepareQuestionsData(){
            vm.questions.forEach((rec) =>{
               let tag = vm.fieldTypeList.filter(obj => {  return obj.pct_id === rec.poq_pct_id  })        
               rec.checkpoint_field_type = tag[0].pct_field_label
            })
        }

        function refreshCheckpoints (newCheckpointID=null) {
            $scope.$emit('STARTSPINNER', translateTag(3589)) //Loading data...
            $q.all([
                equipmentService.getAllQuestions()
            ]).then(() => {
                vm.questions = equipmentService.readAllQuestions()
                prepareQuestionsData()
                if(vm.addQuestionToList.api)
                {
                    vm.refreshSearch()
                    vm.addQuestionToList.api.setRowData(vm.questions)
                    vm.addQuestionToList.api.sizeColumnsToFit()
                    vm.addQuestionToList.api.redrawRows()
                }

                if(vm.addingEquipCheckpoint && newCheckpointID)
                {
                    vm.addingEquipCheckpoint = false
                    vm.getEquipmentQuestions('edit', newCheckpointID)
                    vm.getSiteJobs()
                }

                $scope.$emit('STOPSPINNER')
            })
        }

        //Function to refresh data
        vm.refresh = () => {
            $scope.$emit('STARTSPINNER', vm.loadMessage)
            $q.all([
                equipmentService.getFieldTypeList(),
                equipmentService.getEquipment(),
                equipmentService.getEquipmentTypeList(),
                equipmentService.getAllQuestions(),
                equipmentService.getMeasureTypes(),
                i18nService.getLanguages(),
                adminUserService.getSites(selectedLanguage),
                adminUserService.getJobs(selectedLanguage),
            ]).then(() => {
                vm.sites = adminUserService.getSiteList()
                vm.jobs = adminUserService.getJobList()
            }    
            ).then(() => {
                vm.fieldTypeList = equipmentService.readFieldTypeList()
                vm.equipmentTypes = equipmentService.readEquipmentTypes()
                vm.questions = equipmentService.readAllQuestions()
                prepareQuestionsData()
                vm.equipmentList = collateSubmissions(equipmentService.readEquipment())
                vm.measureTypes = equipmentService.readMeasureTypes()
                vm.systemLanguages = i18nService.readLanguageList().languages
                vm.selectedLanguageID = getSelectedLanguageID(selectedLanguage)
                vm.defaultLanguageID = getDefaultLanguageID()
                
              
                translateAgGridHeader(vm.equipmentOptions)
                let model = vm.equipmentOptions.api.getFilterModel()
                vm.equipmentOptions.api.setRowData(vm.equipmentList)            
                vm.equipmentOptions.api.redrawRows()
                vm.equipmentOptions.api.sizeColumnsToFit()
                vm.equipmentOptions.api.setFilterModel(model)
                }).then(() => {
                vm.equipmentOptions.api.sizeColumnsToFit()
                vm.equipmentOptions.api.redrawRows()
                vm.topSearchChanged()
                $scope.$emit('STOPSPINNER')
                
                // Reset total rows for master detail grid
                vm.currentTotalRows =  vm.equipmentOptions.api.getDisplayedRowCount()
                setTotalRowsForMasterDetailGrid("total_number_records", vm.currentTotalRows)
            })
        }
        vm.refresh()

        //Function to prepare data for Ag-Grid
        function collateSubmissions(submissions) {
            let myIDs = []
            let myRecs = []
            submissions[0].forEach((subs) => {
                if (!myIDs.includes(`${subs.peq_pet_id__pet_equipment_identifier}${subs.peq_pet_id__pet_poe_id}`)) {
                    myIDs.push(`${subs.peq_pet_id__pet_equipment_identifier}${subs.peq_pet_id__pet_poe_id}`)
                    let recdata = {
                        EquipDesc: subs.equipment_desc,
                        EquipmentIdentifier:subs. peq_pet_id__pet_equipment_identifier.toString().toUpperCase(),
                        LastModifiedDate: subs.last_modified_date ? moment(subs.last_modified_date).format('YYYY-MM-DD') : '',
                        ModifiedBy: subs.last_modified_last_name ? `${subs.last_modified_last_name}, ${subs.last_modified_first_name}` : '',
                        NumQuestions: 0,
                        PreOpEquipmentID: subs.peq_pet_id__pet_poe_id,
                        TransCount: subs.TransCount,
                        Questions:[],
                        pem_measure_rld_id:[],
                        peq_pet_id : subs.peq_pet_id,
                        equipment_site:null,
                        equipment_jobs:[],
                        Site:null,
                        JobNumber:null
                    }
                    myRecs.push(recdata)
                }
            })

            siteJobs = []
            if (submissions[2] != null) { 
               siteJobs = submissions[2]
            }

            myRecs.forEach((recs) => {
                submissions[0].forEach((recsubs) => {
                   
                    if (`${recs.EquipmentIdentifier}${recs.PreOpEquipmentID}` === `${recsubs.peq_pet_id__pet_equipment_identifier}${recsubs.peq_pet_id__pet_poe_id}`) {
                        recs.Questions.push({   questionName: recsubs.peq_poq_id__poq_preop_question, 
                                                SortOrder: recsubs.peq_sort_order ? recsubs.peq_sort_order : '',
                                                fieldType : vm.getFieldType(recsubs.peq_poq_id__poq_pct_id)
                                            })
                        recs.NumQuestions++
                    }
                })


                recs.Questions = recs.Questions.sort((a, b) => (a.SortOrder > b.SortOrder) ? 1 : -1) // Sort questions by SortOrder

                submissions[1].forEach((recsubs) => {
                    if (`${recs.EquipmentIdentifier}${recs.PreOpEquipmentID}` === `${recsubs.pem_pet_id__pet_equipment_identifier}${recsubs.pem_pet_id__pet_poe_id}`) {
                        recs.pem_measure_rld_id.push(recsubs.pem_rld_measure_id)           
                    }
                    
                })

                /* find the site and job */
                let siteJobsData = siteJobs.filter(element => element.psj_pet_id === recs.peq_pet_id)
                if(siteJobsData && siteJobsData.length > 0){
                    recs.equipment_site = siteJobsData[0].psj_rld_site_id
                    recs.Site = vm.getSiteName(recs.equipment_site)

                    let jobname=[]
                    siteJobsData.forEach((job)=>{
                        if(job.psj_rld_job_id){
                            recs.equipment_jobs.push(job.psj_rld_job_id)
                            jobname.push(vm.getJobName(job.psj_rld_job_id))
                        }
                    })

                    recs.JobNumber=jobname.join('; ')
                }
                recs.exceptionFields = ['TransCount', 'Questions', 'PreOpEquipmentID','pem_measure_rld_id', 'peq_pet_id', 'equipment_site','equipment_jobs']
            })
            return myRecs
        }

        vm.getFieldType = (value) => {
            let fieldLabel = value
            vm.fieldTypeList.forEach((type)=>{
              if(type.pct_id == value) {
                fieldLabel = type.pct_field_label
              }
            })
            return fieldLabel
        }

        //Function to dynamically assigning detail row height
        vm.equipmentOptions.getRowHeight = function (params) {
            var isDetailRow = params.node.detail;
            
            // for all rows that are not detail rows, return set height
            if (!isDetailRow) { return 40; }
            // otherwise return height based on number of rows in detail grid
            var detailPanelHeight = (params.data.Questions.length * 40) + 100;

            if(params.data.Questions.length <= 0) //Add extra when grid is empty
                detailPanelHeight += 30


            return detailPanelHeight;
        }

        //Update Ag-Grid size when window is resized
        $(window).on('resize', () => {
            $timeout(function () {
                if (vm.equipmentOptions.api)
                {
                    vm.equipmentOptions.api.sizeColumnsToFit()
                    vm.equipmentOptions.api.forEachDetailGridInfo(function(detailGridInfo) {
                        detailGridInfo.api.sizeColumnsToFit()
                    })
                }
                if (vm.addEquipmentTypes.api)
                    vm.addEquipmentTypes.api.sizeColumnsToFit()
                if (vm.addQuestionToList.api)
                    vm.addQuestionToList.api.sizeColumnsToFit()
                if (vm.equipmentQuestions.api)
                    vm.equipmentQuestions.api.sizeColumnsToFit()
            })
        })

        
        function dragAndSort(){
            if($("#sortable").hasClass("ui-sortable"))
            {
                $( "#sortable" ).sortable('destroy')
                $( "#sortable" ).unbind()
            }

            $( "#sortable" ).sortable({
                items: "li:not(.ui-state-disabled)",
                containment: 'window',               
                
                stop: function( event, ui ) {
                    let itemCount = 1
                    vm.newEquipmentQuestionList.forEach((val, index) => {
                        elementId = event.target.children[index].firstElementChild

                        if(elementId != null ){
                            rowIndex = parseInt(elementId.id.split('-').pop());

                         if(vm.newEquipmentQuestionList[rowIndex].selected == true){
                            vm.newEquipmentQuestionList[rowIndex].SortOrder = itemCount
                            itemCount = itemCount + 1 
                         }
                        }
                    });

                    $scope.$apply()
                },
                create: function( event, ui ) {
                    let itemCount = 1
                    vm.newEquipmentQuestionList.forEach((val, index) => {
                        elementId = event.target.children[index].firstElementChild

                        if(elementId != null ){
                            rowIndex = parseInt(elementId.id.split('-').pop());

                         if(vm.newEquipmentQuestionList[rowIndex].selected == true){
                            vm.newEquipmentQuestionList[rowIndex].SortOrder = itemCount
                            itemCount = itemCount + 1
                         }
                        }
                    });

                    $scope.$apply()
                }
            });
            $( "#sortable" ).sortable({ handle: '.handle'})
            $( "#sortable" ).disableSelection()
        }

        //Function to initialize select2
        vm.initializeSelect2 = (parent, section='') => {
            $timeout(() => {
            $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} ${section}`), escapeMarkup: function (text) { return text } })
                .on('select2:select', () => {
                    $(this).parent().find('label').addClass('filled');
                })
            $('.select2-selection__arrow b').addClass("fa fa-caret-down");
            select2Service.select2Tags()
            }, 100)
        }

        // Fuction to check if all equipment modal feilds are valid
        vm.ValidateEquipment = () => {
            return validateFormFields('equipmentInfoForm')
        }

        // check if the Equipment is already in the list
        vm.CheckEquipmentNotExist = () => {
            let equipmentNotExist = true
            vm.equipmentList.forEach((equip) => {
                if(equip.PreOpEquipmentID == parseInt(vm.newEquipment.EquipmentType) && equip.EquipmentIdentifier === vm.newEquipment.EquipmentID)
                {
                    toastr.error(translateTag(3941)) //Equipment Already Exists
                    equipmentNotExist = false
                }
            })
            return equipmentNotExist
        }

        // Fuction to check if all question modal feilds are valid
        vm.validateCheckpoint = () => {

            let validated = validateFormFields("checkpointTranslationForm")

            if(validated)
            {
                vm.valueChanged = false
                let checkpointExists = false

                let newCheckpoint = {}
                newCheckpoint['preop_questions'] = vm.currentTranslationList
                let newValue = getDefaultTranslation('preop_questions', newCheckpoint)[0]
                
                vm.questions.forEach((existingCheckpoint) => {
                    if(existingCheckpoint.preop_questions === "N/A")
                        return
                    
                    let existingValue = getDefaultTranslation('preop_questions', existingCheckpoint)

                    if(vm.newQuestion.preop_question_id == existingCheckpoint.poq_id) //If the values entered are the same as before we dont want to update
                    {
                        vm.currentTranslationList.forEach((tran, index) => {
                            if((!existingCheckpoint.preop_questions[index] && tran.ltr_text[0].trim() != "") || (existingCheckpoint.preop_questions[index] && tran.ltr_text[0].trim() != existingCheckpoint.preop_questions[index].ltr_text.trim()))
                                vm.valueChanged = true
                        })
                        if(vm.newQuestion.preop_question_type != existingCheckpoint.poq_preop_questionmode_id)
                            vm.valueChanged = true 
                    }
                    else if(existingValue.toLowerCase().trim() === newValue.toLowerCase().trim())
                    {
                        checkpointExists = true
                    }
                })

                if(checkpointExists)
                {
                    toastr.error(translateTag(3942)) //Checkpoint Already Exists
                    formVal.classList.remove('was-validated')
                    validated = false
                }
            }
            
            return validated
        }

        // Fuction to check if all equipment type modal feilds are valid
        vm.validateEquipmentType = () => {
            let validated = validateFormFields('equipmentTypeTranslationForm')

            if(validated)
            {
                vm.valueChanged = false
                let typeExists = false

                let newType = {}
                newType['equipment_descriptions'] = vm.currentTranslationList
                let newValue = getDefaultTranslation('equipment_descriptions', newType)[0]

                vm.equipmentTypes.forEach((existingType) => {
                    let existingValue = getDefaultTranslation('equipment_descriptions', existingType)

                    if(vm.newEquipmentType.preop_equipment_id == existingType.poe_id) //If the values entered are the same as before we dont want to update
                    {
                        vm.currentTranslationList.forEach((tran, index) => {
                            if((!existingType.equipment_descriptions[index] && !tran.ltr_text[0].trim()) || (existingType.equipment_descriptions[index] && tran.ltr_text[0].trim() != existingType.equipment_descriptions[index].ltr_text.trim()) || !existingType.equipment_descriptions[index].ltr_translated)
                            {
                                vm.valueChanged = true
                            }
                        })
                    }
                    else if(existingValue.toLowerCase().trim() === newValue.toLowerCase().trim())
                    {
                        typeExists = true
                    }
                })

                if(typeExists)
                {
                    toastr.error(translateTag(3943)) //Equipment Type Already Exists
                    resetFormFieldClassList('equipmentTypeTranslationForm')
                    validated = false
                }
            }
            return validated
        }

        // Function to get jobs from sites
        vm.getSiteJobs = () => {
            let mainJob = JSON.parse(JSON.stringify(vm.jobs))
            vm.filteredJobs = []
            mainJob.forEach((job) => {
                if(job.rld_parent_detail_rld_id == vm.newEquipment.equipment_site){
                    if(!job.rld_is_active) {
                        job.rld_name += ` (${translateTag(3793)})`
                    }
                    vm.filteredJobs.push(job)
                }
            })

            vm.filteredJobs.sort((a,b) => {
                let x = a.rld_code.toLowerCase()
                let y = b.rld_code.toLowerCase()
                return x < y ? -1 : x > y ? 1 : 0
            })
        }

        // find Site name
        vm.getSiteName=(rldId)=>{
            let rtnValue = ''
            if(rldId!= null){
                let sitelen = vm.sites.length
                for(let i= 0; i< sitelen; i++){
                    if(vm.sites[i].rld_id===rldId){
                        rtnValue = vm.sites[i].rld_name
                    } 
                }
            }  
            return rtnValue
        }

        // find Job name
        vm.getJobName=(rldId)=>{
            let rtnValue = ''
            if(rldId!= null){            
                let joblen = vm.jobs.length
                for(let i= 0; i< joblen; i++){
                    if(vm.jobs[i].rld_id===rldId){
                        rtnValue = vm.jobs[i].rld_name
                    } 
                }
            }  
            return rtnValue
        }
        
    //End
    }
])