﻿angular
    .module('safeToDo')
    .service('equipmentService', ['$http',
      function ($http) {
        let equipmentList = []
        let equipmentType = []
        let allEquipmentTypes = []
        let questionList = []
        let addQuestionList = []
        let equipmentListSummary = []
        let equipmentListSiteJob = []
        let measureTypesList = []
        let fieldTypeList = []
        let allPreopEquipments = []
        let fullEquipmentList = []

        return {
          getEquipment: () => {
            return $http.get(`${__env.apiUrl}/api/equipment/list-all-equipment/`)
              .then((response) => {
                equipmentList = response.data
              }, (errorParams) => {
                console.log('Failed to load Equipment Records', errorParams)
              });
          },
          getEquipmentSummary: () => {
            return $http.get(`${__env.apiUrl}/api/equipment/list-all-equipment-summary/${selectedLanguage}`)
              .then((response) => {
                equipmentListSummary = response.data
              }, (errorParams) => {
                console.log('Failed to load Equipment Records', errorParams)
              });
          },          
          addEquipment: (data) => {
            return $http.post(`${__env.apiUrl}/api/equipment/add-equipment/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                return "Error Happened"
                console.log('Failed to add Equipment Record', errorParams)
              });
          },
          updateEquipment: (data) => {
            return $http.post(`${__env.apiUrl}/api/equipment/update-equipment/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                return "Error Happened"
                console.log('Failed to update Equipment Record', errorParams)
              });
          },
          archiveCheckPoint: (data) => {
            return $http.post(`${__env.apiUrl}/api/equipment/delete-checkpoint/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to delete checkpoint', errorParams)
                return "Error Happened"
              });
          },
          removeEquipment: (data) => {
            return $http.post(`${__env.apiUrl}/api/equipment/remove-equipment/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to Remove Equipment Record', errorParams)
                if(errorParams.status === 403 && errorParams.data.detail)
                  toastr.error(errorParams.data.detail)
              });
          },
          getEquipmentQuestions: (data) => {
            return $http.post(`${__env.apiUrl}/api/equipment/equipment-questions/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to load Questions', errorParams)
              });
          },
          getEquipmentTypeQuestions: (data) => {
            return $http.post(`${__env.apiUrl}/api/equipment/list-equipment-questions/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to load Questions', errorParams)
              });
          },
          getAllQuestions: () => {
            return $http.get(`${__env.apiUrl}/api/equipment/list-all-questions/`)
              .then((response) => {
                questionList = response.data
              }, (errorParams) => {
                console.log('Failed to load Questions', errorParams)
              });
          },
          getMeasureTypes: () => {
            return $http.get(`${__env.apiUrl}/api/equipment/get-list-preop-measuretype/`)
              .then((response) => {
                measureTypesList = response.data
              }, (errorParams) => {
                console.log('Failed to load Measure Types', errorParams)
              });
          },
          // Justs adds a Question to the Main Question Table     
          addCheckpoint: (data) => {
            return $http.post(`${__env.apiUrl}/api/equipment/insert-question/`, data)
              .then((response) => {
                return response.data
               }, (errorParams) => {
                console.log('Failed to add Checkpoint', errorParams)
              });
          },
          updateCheckpoint: (data) => {
            return $http.post(`${__env.apiUrl}/api/equipment/update-question/`, data)
              .then((response) => {
               }, (errorParams) => {
                console.log('Failed to update Checkpoint', errorParams)
              });
          },
          addQuestionsList: (data) => {
            return $http.post('/api/equipment/questionslist', data)
              .then((response) => {
                addQuestionList = response.data
              }, (errorParams) => {
                console.log('Failed to load Questions', errorParams)
              });
          },
          getEquipmentTypeList: () => {
            return $http.get(`${__env.apiUrl}/api/equipment/list-equipment-type/`)
              .then((response) => {
                equipmentType = response.data
              }, (errorParams) => {
                console.log('Failed to load Equipment Types', errorParams)
              });
          },
          addEquipmentType: (data) => {
            return $http.post(`${__env.apiUrl}/api/equipment/add-equipment-type/`, data)
              .then((response) => {
                equipmentType = response.data
              }, (errorParams) => {
                console.log('Failed to add Equipment Type', errorParams)
              });
          },
          updateEquipmentType: (data) => {
            return $http.post(`${__env.apiUrl}/api/equipment/update-equipment-type/`, data)
              .then((response) => {
                equipmentType = response.data
              }, (errorParams) => {
                console.log('Failed to update Equipment Type', errorParams)
              });
          },
          getAllEquipmentTypesList: () => {
            return $http.get(`${__env.apiUrl}/api/equipment/list-equipment-type/`)
              .then((response) => {
                allEquipmentTypes = response.data
              }, (errorParams) => {
                console.log('Failed to load Equipment Types', errorParams)
              });
          },
          bulkUpdate: (data) => {
            return $http.post(`${__env.apiUrl}/api/equipment/preop-bulk-edit/`, data)
              .then((response) => {
               }, (errorParams) => {
                console.log('Failed to update Checkpoint', errorParams)
              });
          },

          getFieldTypeList: () => {
            return $http.get(`${__env.apiUrl}/api/equipment/get-checkpoint-item-type/`)
              .then((response) => {
                fieldTypeList = response.data
              }, (errorParams) => {
                fieldTypeList = []
              });
          },  

          getPreopEquipmentList: (mode = 'active') => {            
            return $http.get(`${__env.apiUrl}/api/equipment/get-preop-equipment-list/${mode}/`)
              .then((response) => {
                allPreopEquipments = response.data
              }, (errorParams) => {
                console.log('Failed to load Equipment Types', errorParams)
              });
          },
          getEquipmentSiteJob: () => {
            return $http.get(`${__env.apiUrl}/api/equipment/get-list-all-equipment-site-job/`)
              .then((response) => {
                equipmentListSiteJob = response.data
              }, (errorParams) => {
                console.log('Failed to load Equipment Records', errorParams)
              });
          }, 

          getFullEquipmentList: () => {
            return $http.get(`${__env.apiUrl}/api/equipment/get-full-equipment-list/`)
              .then((response) => {
                fullEquipmentList = response.data
              }, (errorParams) => {
                console.log('Failed to load Equipment Records', errorParams)
              });
          }, 

          readListPreopEquipments:() => {
            return allPreopEquipments
          },

          readEquipment: () => {
            return equipmentList
          },
          readEquipmentSummary: () => {
            return equipmentListSummary
          },  
          readEquipmentSiteJobList: () => {
            return equipmentListSiteJob
          },
          readQuestions: () => {
            return questionList
          },
          readAllQuestions: () => {
            return questionList
          },          
          readAddQuestionsList: () => {
            return addQuestionList
          },
          readEquipmentTypes: () => {
            equipmentType = equipmentType.sort((a, b) => (a.EquipDesc > b.EquipDesc) ? 1 : -1)
            return equipmentType
          },
          readAllEquipmentTypes: () => {
            return allEquipmentTypes
          },
          readMeasureTypes: () => {
            return measureTypesList
          },
          readFieldTypeList: () => {
            return fieldTypeList
          },
          readFullEquipmentList: () => {
            return fullEquipmentList
          },

        }
      }
    ]);