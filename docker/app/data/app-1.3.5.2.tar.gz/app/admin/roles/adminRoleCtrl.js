﻿angular
  .module('safeToDo')
  .controller('AdminRoleCtrl', ['$scope','$rootScope', '$timeout', '$q', '$window', '$filter', 'gridService', 'adminRoleService', 'modalService', 'menuService', 'profileService', 'i18nService', '$compile','exportCSV',
    function ($scope,$rootScope, $timeout, $q, $window, $filter, gridService, adminRoleService, modalService, menuService, profileService, i18nService, $compile, exportCSV) {
      let vm = this
      
      vm.topSearch = ""
      vm.topSearchForm = ""
      vm.topSearchRoles = ""
      vm.topSearchEmployee = ""
      vm.roleAccessOptions = gridService.getCommonOptions()
      vm.roleFormOptions = gridService.getCommonOptions()
      vm.rolesListOptions = gridService.getCommonOptions()
      vm.archiveEmployeeOptions = gridService.getCommonOptions()

      vm.rolesListOptions.rowSelection = 'single'
      // Disabeling pagination for master detail record
      vm.roleAccessOptions.pagination = false
      vm.roleFormOptions.pagination = false
      vm.loadMessage = translateTag(8438)  // "Loading roles and permissions. Please wait."
      vm.roles = []
      vm.permissionList = []
      vm.formList = []
      vm.selectedRole = []
      vm.employeeList = []
      vm.fullEmployeeList = []
      vm.actionAccessDisabled = true
      vm.actionFormDisabled = true
      vm.currentRole = { "aro_id": null, "aro_names": [] }
      vm.actionDisabled = true
      vm.canManageRoles = false
      //Get permissions for the user
      menuService.getPagePermissions().then((data) => {
        vm.permissions = data       
        vm.canManageRoles = vm.permissions.includes('Can Manage Access') ? true : false
        vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false        
      })

      //#region Translations
      vm.currentTranslationMode = 'new'
      vm.currentTranslationList = []
      vm.systemLanguages = []

      vm.selectedLanguageID = 1
      vm.defaultLanguageID = 1

      vm.getCurrentTranslationList = (data) => {
          var currentTranList = []
          
          for(var lang in vm.systemLanguages)
          {
              lang = vm.systemLanguages[lang]
              if(!lang.lng_selected)
                  continue

              var tranObj = {
                  ltr_lng_id: lang.lng_id,
                  ltr_lng_name: lang.lng_name.toUpperCase(),
                  ltr_lng_description: lang.lng_description_text,
                  ltr_lng_default: lang.lng_default ? "*" : "",
                  ltr_text: new Array(data.length).fill(""),
                  ltr_translated:  new Array(data.length).fill(false)
              }
              
              for(var tranList in data)
              {
                  var tranIndex = tranList
                  tranList = data[tranList]
                  for (var tran in tranList)
                  {                        
                      tran = tranList[tran]
                      if(tran.ltr_lng_id == lang.lng_id)
                      {
                          tranObj.ltr_text[tranIndex] = tran.ltr_translated ? tran.ltr_text : ""
                          tranObj.ltr_translated[tranIndex] = tran.ltr_translated
                      }
                  }
              }

              currentTranList.push(tranObj)
          }

          return currentTranList
      }

      vm.getDisplayTranslation = (key, list) => {
          if(!list)
              return

          let defaultLanguageText = ""
          for(var tran in list[key])
          {
              tran = list[key][tran]                
              if(tran.ltr_lng_id == vm.defaultLanguageID)
                  defaultLanguageText = tran.ltr_text
              if(tran.ltr_lng_id == vm.selectedLanguageID && tran.ltr_text.trim() != "")
                  return tran.ltr_text
          }
          return defaultLanguageText
      }

      function getDefaultTranslation (key, list) {
          if(!list)
              return

          let defaultLanguageText = ""
          for(var tran in list[key])
          {
              tran = list[key][tran]                
              if(tran.ltr_lng_id == vm.defaultLanguageID)
                  defaultLanguageText = tran.ltr_text
          }
          return defaultLanguageText
      }

      function getSelectedLanguageID (name)
      {
          for(var lang in vm.systemLanguages)
          {
              lang = vm.systemLanguages[lang]
              if(lang.lng_name.toLowerCase() == name.toLowerCase())
                  return lang.lng_id
          }
          return 1
      }

      function getDefaultLanguageID ()
      {
          for(var lang in vm.systemLanguages)
          {
              lang = vm.systemLanguages[lang]
              if(lang.lng_default)
                  return lang.lng_id
          }
          return 1
      }
      //#endregion

      // Creating Detail Paramaters for permissions
      vm.roleAccessOptions.detailCellRendererParams = {
        detailGridOptions: {
          showToolPanel: false,
          toolPanelSuppressRowGroups: true,
          toolPanelSuppressValues: true,
          toolPanelSuppressPivots: true,
          toolPanelSuppressPivotMode: true,
          toolPanelSuppressSideButtons: true,
          suppressVerticalScroll: true,
          scrollbarWidth: 0,
          suppressContextMenu: true,
          columnDefs: [
            {
              field: translateTag(649), //'name'
              minwidth: 300,
              cellRenderer: function (params) {
                let lable = params.data.name.toLowerCase().replace("can", "")
                return `<span class="clip" ng-non-bindable>${$filter('titlecase')(lable)}</span>`
              },
            }
          ],
          rowHeight: 40,
          headerHeight: 35,
          localeText: sofvie_agGrid_languages[`${selectedLanguage}`]
        },
        getDetailRowData: (params) => {
          params.successCallback(params.data.permissions)
          vm.roleAccessOptions.api.forEachDetailGridInfo(function (detailGridInfo) {
            detailGridInfo.api.sizeColumnsToFit()
          })
        }
      }
      vm.roleAccessOptions.masterDetail = true

      // Creating Detail Paramaters for forms
      vm.roleFormOptions.detailCellRendererParams = {
        detailGridOptions: {
          showToolPanel: false,
          toolPanelSuppressRowGroups: true,
          toolPanelSuppressValues: true,
          toolPanelSuppressPivots: true,
          toolPanelSuppressPivotMode: true,
          toolPanelSuppressSideButtons: true,
          suppressVerticalScroll: true,
          scrollbarWidth: 0,
          suppressContextMenu: true,
          columnDefs: [
            {
              field: translateTag(649), //'name'
              minwidth: 300,
              cellRenderer: function (params) {
                return `<span class="clip" ng-non-bindable>${$filter('titlecase')(params.data.name)}</span>`
              },
            }
          ],
          rowHeight: 40,
          headerHeight: 35,
          localeText: sofvie_agGrid_languages[`${selectedLanguage}`]
        },
        getDetailRowData: (params) => {
          params.successCallback(params.data.form_access)
          vm.roleFormOptions.api.forEachDetailGridInfo(function (detailGridInfo) {
            detailGridInfo.api.sizeColumnsToFit()
          })
        },
      }
      vm.roleFormOptions.masterDetail = true

      // Calling a function to display the number of filtered records when filter changes for Role Access Grid
      vm.roleAccessOptions.onFilterChanged = () => {
        setTotalRowsForMasterDetailGrid("total_number_records_role_access", vm.roleAccessOptions.api.getDisplayedRowCount())
      }

      // Calling a function to display the number of filtered records when filter changes for Form Access Grid
      vm.roleFormOptions.onFilterChanged = () => {
        setTotalRowsForMasterDetailGrid("total_number_records_role_form", vm.roleFormOptions.api.getDisplayedRowCount())
      }

      // function that is run when a change detected when searching in permissions
      vm.topSearchChanged = () => {
        vm.roleAccessOptions.api.setQuickFilter(vm.topSearch)
        // Setting total number of displayed rows when filter changes
        setTotalRowsForMasterDetailGrid("total_number_records_role_access", vm.roleAccessOptions.api.getDisplayedRowCount())
      }

      // function that is run when a change detected when searching in forms
      vm.topSearchFormChanged = () => {
        vm.roleFormOptions.api.setQuickFilter(vm.topSearchForm)
        // Setting total number of displayed rows when filter changes
        setTotalRowsForMasterDetailGrid("total_number_records_role_form", vm.roleFormOptions.api.getDisplayedRowCount())
      }

      // function that is run when a change detected when searching in roles
      vm.topSearchRoleChanged = () => {
        vm.rolesListOptions.api.setQuickFilter(vm.topSearchRoles)
      }

      // function that is run when a change detected when searching in employee
      vm.topSearchEmployeeChanged = () => {
        vm.archiveEmployeeOptions.api.setQuickFilter(vm.topSearchEmployee)
      }




      // Used for Geting the Value based on the Id of Pul Down Lists
      vm.multiRenderer = (table, data, rid, name) => {
        let output = ''
        data.forEach((id, index) => {
          output += `<p> ${$filter('filter')(table, { [rid]: id.id })[0][name]}</p>`
        })
        return (output)
      }

      //Functions to export toCSV file
      vm.exportFormCSV = () => {        
        let rows = JSON.parse(JSON.stringify(vm.roleFormOptions.api.getSelectedRows()))
        rows.forEach(row => {
          row['forms_list'] = ''
          row.form_access.forEach(form => {
            row['forms_list'] += `${form.name},`
          });
          row['forms_list'] = row['forms_list'].slice(0, -1)         
        });
        exportCSV.export_csv(rows, translateTag(8709))        
      }

      //Functions to export Roles to CSV file
      vm.exportRolesCSV = () => {        
        let rows = JSON.parse(JSON.stringify(vm.rolesListOptions.api.getSelectedRows()))
        exportCSV.export_csv(rows, translateTag(8710))
      }

      vm.exportPermissionCSV = () => {        
        let rows = JSON.parse(JSON.stringify(vm.roleAccessOptions.api.getSelectedRows()))
        rows.forEach(row => {
          row['permissions_list'] = ''
          row.permissions.forEach(permission => {
            row['permissions_list'] += `${permission.name},`
          });
          row['permissions_list'] = row['permissions_list'].slice(0, -1)         
        });
        exportCSV.export_csv(rows, translateTag(8711))        
      }

      //Function to dynamically assigning detail row height for Permissions
      vm.roleAccessOptions.getRowHeight = function (params) {
        let isDetailRow = params.node.detail

        // for all rows that are not detail rows, return nothing
        if (!isDetailRow) { return 40 }
        // otherwise return height based on number of rows in detail grid                    
        let detailPanelHeight = (params.data.permissions.length * 40) + 85

        if (params.data.permissions.length == 1) {
          detailPanelHeight = (params.data.permissions.length * 40) + 90
        }

        if(params.data.permissions.length <= 0) //Add extra when grid is empty
          detailPanelHeight += 30

        return detailPanelHeight
      }

      vm.openAccessPermission = (aro_id) =>{
        vm.submitted = false
        vm.openModal('PermissionRoleModal',aro_id)
      }

      //Function to dynamically assigning detail row height for Form Access
      vm.roleFormOptions.getRowHeight = function (params) {
        let isDetailRow = params.node.detail

        // for all rows that are not detail rows, return nothing
        if (!isDetailRow) { return 40 }
        // otherwise return height based on number of rows in detail grid
        let detailPanelHeight = (params.data.form_access.length * 40) + 85

        if (params.data.form_access.length == 1) {
          detailPanelHeight = (params.data.form_access.length * 40) + 90
        }

        if(params.data.form_access.length <= 0) //Add extra when grid is empty
            detailPanelHeight += 30

        return detailPanelHeight
      }

      //Set Ag-Grid colum values/settings for roles
      let roleAccessColumns = [
        {
          headerName: '',
          field: 'dummyCheckbox',
          maxWidth: 60,
          minWidth: 60,
          checkboxSelection: true,
          suppressMenu: true,
          suppressSorting: true,
          headerCheckboxSelection: true,
          headerCheckboxSelectionFilteredOnly: true,
        },
        {
          field: 'aro_id',
          hide: true,
        },
        {
          field: "review",
          headerName: " ",
          minWidth: 50,
          maxWidth: 50,
          suppressMenu: true,
          suppressSorting: true,
          cellRenderer: function (params) {
            if(params.data.aro_id !== 8) {
              return `<div ng-if="admrole.canManageRoles" note="Edit" class="pointer text-left" ng-click="admrole.openAccessPermission(${params.data.aro_id})"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title={{menu.translateLabels(1194)}}></i></div>`
            }
          },
          getQuickFilterText: function (params) {
            if (params.data) {
              return (params.data.aro_name_trans)
            }
          },
        },
        {
          field: "role_trans",
          headerName: " ",
          minWidth: 200,
          filter: 'agSetColumnFilter',
          cellRenderer: 'agGroupCellRenderer',
          sort: 'asc'
        },
        {
          field: "search",
          hide: true,
          filter: 'agSetColumnFilter',
          getQuickFilterText: (params) => {
            let searchBlob = ''
            params.data.permissions.forEach((rec) => {
              searchBlob += `${rec.name}, `
            })
            return searchBlob
          }
        },
        {
          field: "date_last_modified",
          headerName: " ",
          minWidth: 160,
          maxWidth: 160,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        },
        {
          field: "modified_by",
          headerName: " ",
          minWidth: 150,
          maxWidth: 250,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        },
        { field: "created_by", hide: true }
      ]

      // Setup columns for Master Form Access
      let roleFormColumns = [
        {
          headerName: '',
          field: 'dummyCheckbox',
          maxWidth: 60,
          minWidth: 60,
          checkboxSelection: true,
          suppressMenu: true,
          suppressSorting: true,
          headerCheckboxSelection: true,
          headerCheckboxSelectionFilteredOnly: true,
        },
        {
          field: 'aro_id',
          hide: true,
        },
        {
          field: "review",
          headerName: " ",
          minWidth: 50,
          maxWidth: 50,
          suppressMenu: true,
          suppressSorting: true,
          cellRenderer: function (params) {
            if(params.data.aro_id !== 8) {
              return `<div ng-if="admrole.canManageRoles" note="Edit" class="pointer text-left" ng-hide="${params.data.aro_can_be_modified}" ng-click="admrole.openFormModal('FormRoleModal',${params.data.aro_id})"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title={{menu.translateLabels(1194)}}></i></div>`
            }
          }
        },
        {
          field: "role_trans",
          headerName: " ",
          minWidth: 200,
          filter: 'agSetColumnFilter',
          cellRenderer: 'agGroupCellRenderer',
          sort: 'asc'
        },
        {
          field: "search",
          hide: true,
          filter: 'agSetColumnFilter',
          getQuickFilterText: (params) => {
            let searchBlob = ''
            params.data.form_access.forEach((rec) => {
              searchBlob += `${rec.name}, `
            })
            return searchBlob
          }
        },
        {
          field: "date_last_modified",
          headerName: " ",
          minWidth: 160,
          maxWidth: 160,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        },
        {
          field: "modified_by",
          headerName: " ",
          minWidth: 150,
          maxWidth: 200,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        }
      ]

      let roleListColumns = [
        {
          headerName: '',
          field: 'dummyCheckbox',
          maxWidth: 50,
          minWidth: 50,
          checkboxSelection: true,
          suppressMenu: true,
          suppressSorting: true,
          headerCheckboxSelection: true,
          headerCheckboxSelectionFilteredOnly: true
        },
        {
          field: 'ID',
          hide: true,
        },
        {
          field: "review", headerName: " ", minWidth: 60, maxWidth: 60, suppressMenu: true, suppressSorting: true,
          cellRenderer: function (params) {            
            if (params.data.aro_can_be_modified === translateTag(1380)){              
              return `<div></div>`
            }
            else{
              return `<div ng-if="admrole.canManageRoles" class="pointer text-left" ng-click="admrole.openRoleModal('edit','${params.data.aro_id}')"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title={{menu.translateLabels(1194)}}></i></div>`;            
            }                         
          },
        },
        {
          field: "aro_name_trans",
          headerName: " ",
          minWidth: 300,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        },
        {
          field: "aro_modified_date",
          headerName: " ",
          minWidth: 200,
          maxWidth: 260,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
          valueGetter: function (params) {
            if (params.data.aro_modified_date != null)
              return params.data.aro_modified_date.substring(0, 10)
          },
        },
        {
          field: "aro_modified_by_per_id",
          headerName: " ",
          minWidth: 200,
          maxWidth: 260,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
          valueGetter: function (params) {
            return params.data.aro_modified_by_per_id = getEmployeeName(params.data.aro_modified_by_per_id)

          },
        }
      ]
      vm.rolesListOptions.columnDefs = roleListColumns

      let employeeListColumns = [
        {
          field: "aur_user_id",
          headerName: " ",
          minWidth: 500,
          maxWidth: 1000,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
          valueGetter: function (params) {
            return getEmployeeNameByUserID(params.data.aur_user_id)

          },
        }
      ]
      vm.archiveEmployeeOptions.columnDefs = employeeListColumns

      //Function to disable action button if no rows are selected
      vm.roleAccessOptions.onSelectionChanged = () => {
        var selectedRows = vm.roleAccessOptions.api.getSelectedRows()
        vm.actionAccessDisabled = selectedRows.length == 0
        $scope.$apply()
      }

      vm.roleFormOptions.onSelectionChanged = () => {
        var selectedRows = vm.roleFormOptions.api.getSelectedRows()
        vm.actionFormDisabled = selectedRows.length == 0
        $scope.$apply()
      }

      vm.rolesListOptions.onSelectionChanged = () => {
        var selectedRows = vm.rolesListOptions.api.getSelectedRows()
        vm.actionDisabled = selectedRows.length == 0
        $scope.$apply()
      }

      function getSelectedRole(id) {
        let selectedData = []
        vm.roles.forEach((data) => {
          if (data.aro_id == id) {
            selectedData = data
          }
        })
        return selectedData
      }

      function getEmployeeName(value) {
        let name = value
        vm.fullEmployeeList.forEach((emp) => {
          if (emp.per_id == value) {
            name = emp.per_full_name
          }
        })
        return name
      }

      function getEmployeeNameByUserID(value) {
        let name = value
        vm.fullEmployeeList.forEach((emp) => {
          if (emp.user_id == value) {
            name = emp.per_full_name
          }
        })
        return name
      }

     

      vm.setPermissionControl = (listofdata, all) => {
        listofdata.forEach(parent => {
          if (parent.child !== undefined) {
            // there is child - loop through the child
            parent.child.forEach(child => {
              if (child.sub_child !== undefined) {     // if there is a sub-child 
                child.sub_child.forEach(sub_child => { // loop through sub-child
                  if (all.includes(sub_child.ape_id)) { // if sub-child id is in all - i.e., selected
                    sub_child.subchildSelected = true //select sub-child, child and parent
                    child.childSelected = true
                    parent.parentSelected = true
                  }
                  else { // if sub-child is not in all - i.e., not selected, check child is selected
                    if (all.includes(child.ape_id)) { // if child is selected
                      child.childSelected = true //select child and parent
                      parent.parentSelected = true
                    }
                    else { // if child is not selected
                      if (all.includes(parent.ape_id)) { 
                        parent.parentSelected = true } //check parent is in all and set true if selected
                    }
                  }
                })

              }
              else { // if there is no sub-child
                if (all.includes(child.ape_id)) { // check if child is selected
                  child.childSelected = true //set child and parent to true
                  parent.parentSelected = true
                }
                else { // if child is not selected  - check parent and set to true
                  if (all.includes(parent.ape_id)) { 
                    parent.parentSelected = true 
                  }
                }
              }
            });
          }
          else { // if there is no child - check if parent is selected and set to true. 
            if (all.includes(parent.ape_id)) { 
              parent.parentSelected = true 
            }
          }
        });
        return listofdata

      }

      // function helps to manage the rules for the Admin or any particular roles
      // having specified condition to follow.
      vm.rulesRolePermission = (inputArray , aro_id) =>{
        vm.defaultAccessPermission = []
        inputArray.forEach((parent) => {
          if (parent.child !== undefined) {
            parent.child.forEach(child => {
              child['visibility'] = true
              if(aro_id === 8){ // for Admin
                if(child.ape_name=== 'Can View Users'){        
                  vm.defaultAccessPermission.push(child.ape_id)   
                  child['visibility'] = false
                }
                else if(child.ape_name === 'Can View Access'){        
                  vm.defaultAccessPermission.push(child.ape_id)    
                  child['visibility'] = false
                }
              }
              else{
                if(child.ape_name === 'Can Manage Users'){
                  child['visibility'] = false 
                }
                if(child.ape_name === 'Can Manage Access'){         
                  child['visibility'] = false 
                }
              }
            })
          }
        })
        return inputArray
      }

      vm.setDefaultPermissions =(permissions, role_id)=>{        
        // get role object matching with role_id
        let role = vm.roles.find(role => role.aro_id === role_id)        
        // set 'Can Sign Off Incident' visbility to false for each permission if aro_signoff_default is true for arole
        // get 'Can View Incidents' permission
        let canViewIncidents = permissions.find(permission => permission.ape_name === 'Can View Incidents')
        let accessAdminstration = permissions.find(permission => permission.ape_name === 'Access Administration')      
        if(role.aro_signoff_default){
          canViewIncidents.child.forEach(child => {            
            // check if child has subchild
            if(child.sub_child !== undefined){
              // loop through subchild
              child.sub_child.forEach(sub_child => {                    
                sub_child['visibility'] = true
                if(sub_child.ape_name === 'Can Sign Off Incident'){
                  vm.defaultAccessPermission.push(child.ape_id)
                  sub_child['visibility'] = false
                }
              })
            }                
          })
        }
        if(role_id === 8 && accessAdminstration.child != undefined){
          accessAdminstration.child.forEach(permission => {
            permission['visibility'] = true
            if(permission.ape_name === 'Can Manage Access'){
              vm.defaultAccessPermission.push(permission.ape_id)
              permission['visibility'] = false
            }            
          });
        }
        
        return permissions
      }

      // function to perform disabling the 'Manage Training Status' permission, the role having the permission 
      // for the 'Manage Training Records'
      vm.performDisableRules = () => {
        vm.left_modules.forEach(module => {
          if(module.display_name == "Access Administration"){
            module.child.forEach(childObj => {
              if(childObj.ape_name == "Can View Training Records"){
                childObj.sub_child.forEach(subChildObj => {
                  if(subChildObj.ape_name === "Can Manage Training Records" && subChildObj.subchildSelected){
                    document.getElementById("firstmodulessub_child_74").disabled = true
                  }
                })
              }
            })
          }
        })
        vm.right_modules.forEach(module => {
          if(module.display_name == "Access Administration"){
            module.child.forEach(childObj => {
              if(childObj.ape_name == "Can View Training Records"){
                childObj.sub_child.forEach(subChildObj => {
                  if(subChildObj.ape_name === "Can Manage Training Records" && subChildObj.subchildSelected){
                    document.getElementById("firstmodulessub_child_74").disabled = true
                  }
                })
              }
            })
          }
        })

      }

      // Opening Modal for Permissions
      vm.openModal = (modalId, id) => {
        vm.selectedRole = getSelectedRole(id)
        vm.rolePermissions = JSON.parse(JSON.stringify(vm.permissionList))
        allPermissions = []
        vm.selectedRole.permissions.forEach((per) => {
          allPermissions.push(per.id)
        })         

        if(modalId ==='PermissionRoleModal'){           
          vm.global = vm.setPermissionControl(vm.rolePermissions.global, allPermissions) 
          moduleObjects = vm.setPermissionControl(vm.rolePermissions.modules, allPermissions)
          vm.modules = vm.rulesRolePermission(moduleObjects, id)          
          vm.preserved_modules = JSON.parse(JSON.stringify(vm.modules))
          vm.modules = vm.setDefaultPermissions(JSON.parse(JSON.stringify(vm.modules)), id)
          vm.left_modules = vm.modules.splice(0, (Math.ceil(vm.modules.length/2)))
          vm.right_modules = vm.modules 
          vm.submissions = vm.setPermissionControl(vm.rolePermissions.submissions, allPermissions)
          vm.preserved_submissions = JSON.parse(JSON.stringify(vm.submissions))         
        }
        modalService.Open(modalId)
        setTimeout(() => { 
        vm.performDisableRules()}, 1000)
      }

      // This function disables the child nodes, if the parent node change to toggle OFF
      vm.toggleParentPermission = (parentlist, parentId) => {
        parentlist.forEach(parent => {
          if(parent.ape_id === parentId){  
            if(parent.child !==undefined) {
              parent.child.forEach(child => {
                child.childSelected = false
                if(child.sub_child !==undefined) {
                  child.sub_child.forEach(sub_child => {
                    sub_child.subchildSelected = false
                  })
                }             
              })
            }
          }
        })
      }

      // This function disables the subchild nodes, if the child node change to toggle OFF
      vm.toggleChildPermission = (childList, childId) => {       

        let permission = childList.child.filter(item => {
          return item.ape_id === childId
        })[0]
        
        if(permission.childSelected === false && permission.sub_child !== undefined){
          permission.sub_child.forEach(element => {
            element.subchildSelected = false
          });
        }        
      }   
      
      vm.toggleSubChildPermission = (child, subChild, subChildId) => {        
        if(subChild.ape_name == "Can Manage Training Records" && subChild.subchildSelected){
            child.sub_child.forEach(element => {
              if(element.ape_id == 74){
                element.subchildSelected = true
                document.getElementById("firstmodulessub_child_74").disabled = true
              }
            });
        }
        else if(subChild.ape_name == "Can Manage Training Records" && !subChild.subchildSelected){
          document.getElementById("firstmodulessub_child_74").disabled = false
        }
      }

      // Opening modal for Form Access
      vm.openFormModal = (modalId, roledata) => {
        vm.roleFormsCategory= JSON.parse(JSON.stringify(vm.formList))        
        allRoles = []
        let allFormsPDC = []        
        let allFormsCC = []
        let allFormsPD_CC = []
        vm.selectedRole = getSelectedRole(roledata)     
        vm.selectedRole.form_access.forEach((frm) => {
          if(frm.form_type==="Pre-Defined Categories")
            allFormsPDC.push(parseInt(frm.id))
          else if(frm.form_type=== "Custom Categories")
            allFormsCC.push(parseInt(frm.id))
          else if(frm.form_type === 'Custom-Form-Pre-Defined Categories')
            allFormsPD_CC.push(parseInt(frm.id))
        })
        for(let [key, value] of Object.entries(vm.roleFormsCategory)){
          value.forEach(cat => {
            if(cat.form_data !== undefined){
              cat.form_data.forEach(form => {                          
                if((allFormsPDC.includes(form.mobileformid) && key === 'pre_defined_categories')){
                  form.selected = true
                  cat.category_selected = true
                }
                else if(allFormsCC.includes(form.FormID) && key === 'custom_categories'){
                  form.selected = true
                  cat.category_selected = true
                }
                else if(allFormsPD_CC.includes(form.FormID) && key === 'pre_defined_categories' && form.type == 'custom-predefined_form'){
                  form.selected = true
                  cat.category_selected = true
                }
                else{
                  form.selected = false
                }
              })
            }
          })
          let half_length = Math.ceil(value.length/2)
          if(key === 'pre_defined_categories'){
            vm.left_form_category_pdc = value.splice(0,half_length)
            vm.right_form_category_pdc = value
          }
          else if (key === 'custom_categories'){
            vm.left_form_category_cc = value.splice(0,half_length)
            vm.right_form_category_cc = value
          }          
        }        
        modalService.Open(modalId)
      }

      vm.toggleFormCategorty = (category_list, category_name) => {  
        category_list.forEach(cat => {
          if(category_name === cat.category){ 
            if(cat.form_data !== undefined){
              cat.form_data.forEach(form => {
                form.selected = false
              })
            }                      
          }
        })
      }

      // Opening modal for role list
      vm.openRoleModal = (mode, aro_id=null) => {
        resetFormFieldClassList('roleForm')

        if(mode == 'new')
        {
          vm.currentRole.aro_id = null
          vm.currentRole.aro_names = []
          var tranData = []
          tranData.push(vm.currentRole['aro_names'])
          vm.currentTranslationList = vm.getCurrentTranslationList(tranData)
        }
        else{
          vm.currentRole.aro_id = aro_id
          vm.currentRole.aro_names = []

          vm.rolesList.forEach((role) => {
            if(role.aro_id == aro_id)
              vm.currentRole.aro_names = role.aro_names
          })
          
          var tranData = []
          tranData.push(vm.currentRole['aro_names'])
          vm.currentTranslationList = vm.getCurrentTranslationList(tranData)
        }   
        
        vm.currentTranslationMode = mode
        modalService.Open('roleModal')
      }

      // Opening Archive modal
      vm.openArchiveRoleModal = (modalId) => {
        selectedcellvalue = vm.rolesListOptions.api.getSelectedRows()
        vm.selectedRole = selectedcellvalue[0].aro_name_trans
        if (selectedcellvalue.find(rec=>rec.aro_can_be_modified === 'No')) {
          throwToastr('error', translateTag(8409), 5000) // 'Default role cannot archive'
        }
        else {
          adminRoleService.GetEmployeeByRole({ "aro_id": selectedcellvalue[0].aro_id }).then((response) => {
            vm.archiveEmployeeOptions.paginationPageSize = 10
            vm.archiveEmployeeOptions.api.setRowData(response)
            vm.archiveEmployeeOptions.api.redrawRows()
            vm.archiveEmployeeOptions.api.sizeColumnsToFit()
            modalService.Open(modalId)
          })
        }

      }


      // Closing Modal on Cancel
      vm.cancelRole = (modalId) => {
        modalService.Close(modalId)
      }

      // Function for saving Permissions
      vm.saveRolePermissions = () => {
        vm.saveRoles = { "permissions": [] }    
        
        let finalList = [] // 1 - Basic Access always turn ON
        finalList = finalList.concat(vm.global, vm.left_modules, vm.right_modules, vm.submissions)   

        finalList.forEach(parent => {
          if(parent.parentSelected === true){      
            vm.saveRoles.permissions.push(parent.ape_id)      
          }
      
          if(parent.child!==undefined){      
              parent.child.forEach(child => {      
                  if(child.childSelected === true){      
                    vm.saveRoles.permissions.push(child.ape_id)      
                  }      
                  if(child.sub_child!==undefined){      
                      child.sub_child.forEach(sub_child => {      
                          if(sub_child.subchildSelected===true){   
                            vm.saveRoles.permissions.push(sub_child.ape_id)      
                          }      
                      })    
                  }      
              })      
          }      
        })
        if(vm.defaultAccessPermission.length > 0)
          vm.saveRoles.permissions.concat(vm.defaultAccessPermission)

        vm.saveRoles.permissions.push(1) // 1 - Basic Access always turn ON
        if (vm.saveRoles.permissions.length > 0) { 
          vm.submitted = true  
               
          let rmm_id = 47
          let incindent_id = 18
          let loto_id = 75

          vm.accessRMM = vm.checkForFormAccessChange(rmm_id, finalList, vm.preserved_modules)
          
          vm.accessIncident = vm.checkForFormAccessChange(incindent_id, finalList, vm.preserved_modules)
          vm.accessLOTO = vm.checkForFormAccessChange(loto_id, finalList, vm.preserved_modules)
          
          vm.accessDailyLog = vm.checkForFormAccessChange(7, finalList, vm.preserved_submissions)
          vm.accessManagementSubmissions = vm.checkForFormAccessChange(9, finalList, vm.preserved_submissions)
          vm.accessHRSubmissions = vm.checkForFormAccessChange(11, finalList, vm.preserved_submissions) 

          vm.accessIncidentSubmission  = vm.checkForFormAccessChange(68, finalList, vm.preserved_submissions)
          if(vm.accessRMM !='' || 
          vm.accessIncident !='' || 
          vm.accessDailyLog != '' || 
          vm.accessManagementSubmissions !='' || 
          vm.accessDailyLog !='' || 
          vm.accessHRSubmissions !='' ||
          vm.accessIncidentSubmission !='' ||
          vm.accessLOTO != ''){
            modalService.Open('ChangePermission')
          } else {
            adminRoleService.saveRolePermissions(vm.saveRoles, vm.selectedRole.aro_id).then((data) => {
              vm.refreshScreen()
              modalService.Close('PermissionRoleModal')

              vm.submitted = false
            })
          }
        } else {
          toastr.error(translateTag(8408)) // 'Must have at least 1 permission selected'
        }
      }

      vm.validateAccess = (access) => {
        if(access === 'ON')
          return 'ON'
        else if (access ==='OFF')
          return 'OFF'
        else 
          return ''
      }

      vm.permitRolePermission = (permission) => {
          adminRoleService.saveRolePermissions(vm.saveRoles, vm.selectedRole.aro_id).then((data) => {

            modalService.Close('ChangePermission')
            modalService.Close('PermissionRoleModal')
            vm.submitted = false
            if(permission){  

              let rmmFlag =vm.validateAccess( vm.accessRMM )
              let lotoFlag = vm.validateAccess(vm.accessLOTO)
              
              let incidentFlag = ''
              let incidentSub =  vm.validateAccess(vm.accessIncidentSubmission)
              let incidentModule = vm.validateAccess(vm.accessIncident )

              // if either incidentsub or incidentmodule is on/off then turn on/off.
              // if the end user turns one on and the other off at the same time
              // then there is no change.
              if (incidentSub === incidentModule){
                incidentFlag = incidentSub
              } else if(incidentSub.length === 0 && incidentModule.length > 0){
                incidentFlag = incidentModule
              } else if(incidentSub.length > 0 && incidentModule.length === 0){
                incidentFlag = incidentSub
              }

              let dailylogFlag = vm.validateAccess(vm.accessDailyLog)
              let managementFlag = vm.validateAccess(vm.accessManagementSubmissions) 
              let hrFlag = vm.validateAccess(vm.accessHRSubmissions)
              let curPayload = {"aro_id": vm.selectedRole.aro_id, 
                                 "rmm":rmmFlag, 
                                 "incident":incidentFlag,
                                 "dailylog": dailylogFlag,
                                 "management": managementFlag,
                                 "hr": hrFlag,
                                 "loto": lotoFlag
                                }
              adminRoleService.AddFormAccessPermissionToRole(curPayload).then((response) =>{
                vm.refreshScreen()
              })
              
            } else {
              vm.refreshScreen()
            }
          })
      }
      
      vm.cancelRolePermission = () => {
        modalService.Close('ChangePermission')
        vm.submitted = false
      }

      vm.checkForFormAccessChange = (id, finalList, preserved_settings) => {
        

        // Check to see if any of the settings have been changed.
        // preserved_modules are the original modules selected when the modal opens.
        // This object is checked against the final list to determine if there are changes.
        // If there are changes, then return either "ON" or "OFF", if no changes,
        // return a blank string.

        for(let i = 0;i<preserved_settings.length;i++){
          if(preserved_settings[i].ape_id == id){
            for(let j=0;j<finalList.length;j++){
              if(finalList[j].ape_id == id){
                if(preserved_settings[i].parentSelected != finalList[j].parentSelected){
                  if(finalList[j].parentSelected){
                    return "ON"
                  } else {
                    return "OFF"
                  }
                } 
              }
            }
          }
        }
        return ""
      }

      // Function for saving Form access
      vm.saveRoleForms = () => {
        let saveForms = { 
          "pre_defined_forms": [],
          "custom_category_forms": [] 
        }        
        vm.roleFormsCategory_pdc = vm.left_form_category_pdc.concat(vm.right_form_category_pdc)
        vm.roleFormsCategory_pdc.forEach(cat => {
          if(cat.form_data !== undefined){
            cat.form_data.forEach(form => {
              if(form.selected === true){
                if(form.type === 'custom-predefined_form'){
                  saveForms.custom_category_forms.push(form.FormID)
                }
                else{
                  saveForms.pre_defined_forms.push(form.mobileformid)
                }
              }
            })
          }          
        })
        vm.roleFormsCategory_pdc = vm.left_form_category_cc.concat(vm.right_form_category_cc)        
        vm.roleFormsCategory_pdc.forEach(cat => {
          if(cat.form_data !== undefined){
            cat.form_data.forEach(form => {
              if(form.selected === true){
                saveForms.custom_category_forms.push(form.FormID)
              }
            })
          }          
        })
        // add custom forms id (46) to saveForms.pre_defined_forms if any custom for is selected
        if(saveForms.custom_category_forms.length > 0){
          saveForms.pre_defined_forms.push(46)
        }
        if (saveForms.pre_defined_forms.length > 0 && saveForms.custom_category_forms.length > 0) {
          vm.submitted = true
          adminRoleService.saveRoleForms(saveForms, vm.selectedRole.aro_id).then((data) => {
            vm.refreshScreen()
            modalService.Close('FormRoleModal')
            vm.submitted = false
          })
        }
        else {
          vm.submitted = true
          adminRoleService.saveRoleForms(saveForms, vm.selectedRole.aro_id).then((data) => {
            vm.refreshScreen()
            modalService.Close('FormRoleModal')
            vm.submitted = false
          })
        }
        modalService.Close('FormRoleModal')
      }

      // Function for saving role
      vm.saveRole = () => {
        resetFormFieldClassList('roleForm')
        if (validateFormFields('roleForm')) {

          let payload = vm.currentRole
          payload.aro_names = prepareRoleTranslationPayload(vm.currentTranslationList)

          if (vm.currentTranslationMode == 'edit') {  //    Update                
            vm.submitted = true
            

            adminRoleService.UpdateRole(payload).then((data) => {
              if (data.error.length > 0) {
                // toastr.error(data.error)
                vm.submitted = false
              }
              else {
                vm.refreshScreen()
                modalService.Close('roleModal')
                vm.currentTranslationList = []
                vm.submitted = false              
              }
            })
          }
          else {  // New            
            vm.submitted = true
            adminRoleService.CreateRole(payload).then((data) => {
              if (data.error.length > 0) {
                // toastr.error(data.error)
                vm.submitted = false
              }
              else {
                vm.refreshScreen()
                modalService.Close('roleModal')
                vm.currentTranslationList = []
                vm.submitted = false
              }
            })
          }
          
        } else {
          $rootScope.$broadcast("CALLCONFIRMMODAL")
        }

      }

      function prepareRoleTranslationPayload (data) {
        var payload = []

        data.forEach((tran) => {
            var payloadTran = {
                ltr_lng_id: tran.ltr_lng_id,
                ltr_text: tran.ltr_text[0].trim()
            }

            if(payloadTran.ltr_text != "")
                payload.push(payloadTran)
        })
            
        return payload
      }

      // Function for Archive Role
      vm.ArchiveRole = () => {

        selectedcellvalue = vm.rolesListOptions.api.getSelectedRows()
        vm.selectedRole = selectedcellvalue[0].aro_name_trans
        if (!selectedcellvalue[0].aro_can_be_modified) {
          toastr.error(translateTag(8409)) // 'Default role cannot archive'
        }
        else {
          adminRoleService.ArchiveRole({ "aro_id": selectedcellvalue[0].aro_id }).then((response) => {
            vm.refreshScreen()
            modalService.Close('ArchiveRoleModal')
            vm.submitted = false
          })
        }
      }


      vm.roleAccessOptions.columnDefs = roleAccessColumns
      vm.roleAccessOptions.animateRows = false
      vm.roleFormOptions.columnDefs = roleFormColumns
      vm.roleFormOptions.animateRows = false

      //Function used to remove an element from an array
      Array.prototype.remove = function () {
        var what, a = arguments, L = a.length, ax
        while (L && this.length) {
          what = a[--L]
          while ((ax = this.indexOf(what)) !== -1) {
            this.splice(ax, 1)
          }
        }
        return this;
      }

      // Main Function for Refreshing AG-Grids
      vm.refreshScreen = () => {
        $scope.$emit('STARTSPINNER', vm.loadMessage)
        $q.all([
          adminRoleService.getRoles('admin'),
          adminRoleService.GetAllPermissionsWithParents(),
          adminRoleService.getFormListCategory(),

          adminRoleService.getAllRoleList(),
          profileService.getFullEmployeeProfile(),
          i18nService.getLanguages()
        ]).then(() => {
          vm.systemLanguages = i18nService.readLanguageList().languages
          vm.selectedLanguageID = getSelectedLanguageID(selectedLanguage)
          vm.defaultLanguageID = getDefaultLanguageID()

          vm.roles = adminRoleService.readRoles()

          vm.permissionList = adminRoleService.readAllPermissionList()
          vm.formList = adminRoleService.readFormList()


          let modelRoleAccess = vm.roleAccessOptions.api.getFilterModel()
          vm.roleAccessOptions.api.setRowData(prepareAccessGridData(vm.roles))
          translateAgGridHeader(vm.roleAccessOptions)

          let modelRoleForm = vm.roleFormOptions.api.getFilterModel()
          vm.roleFormOptions.api.setRowData(prepareFormGridData(vm.roles))

          vm.fullEmployeeList = profileService.readFullEmployeeProfile()

          vm.rolesList = adminRoleService.readRoleList()

          vm.rolesListOptions.paginationPageSize = 10
          translateAgGridHeader(vm.rolesListOptions)
          let modelRolesList = vm.rolesListOptions.api.getFilterModel()
          vm.rolesListOptions.api.setRowData(prepareUserRoleGridData(vm.rolesList))          
          vm.roleAccessOptions.api.setFilterModel(modelRoleAccess)
          vm.roleFormOptions.api.setFilterModel(modelRoleForm)
          vm.rolesListOptions.api.setFilterModel(modelRolesList)
        }).then(() => {
          vm.roleAccessOptions.api.sizeColumnsToFit()
          vm.roleAccessOptions.api.redrawRows()
          vm.roleFormOptions.api.sizeColumnsToFit()
          vm.roleFormOptions.api.redrawRows()

          vm.rolesListOptions.api.sizeColumnsToFit()
          vm.rolesListOptions.api.redrawRows()
          SizeColumnsMasterDetail()
          translateAgGridHeader (vm.roleFormOptions) 
          
          // Reset total rows for master detail grid
          vm.currentTotalRowsAccessRole =  vm.roleAccessOptions.api.getDisplayedRowCount()
          setTotalRowsForMasterDetailGrid("total_number_records_role_access", vm.currentTotalRowsAccessRole)


          // Reset total rows for master detail grid
          vm.currentTotalRowsRoleForm =  vm.roleFormOptions.api.getDisplayedRowCount()
          setTotalRowsForMasterDetailGrid("total_number_records_role_form", vm.currentTotalRowsRoleForm)

          $scope.$emit('STOPSPINNER')
        })
      }
      vm.refreshScreen()

      //Function to prepare access Data for the grid/tippy
      function prepareAccessGridData(data) {
        let accessGridData = JSON.parse(JSON.stringify(data))
        accessGridData.forEach((rec) => {
          rec.exceptionFields = ['aro_enable', 'aro_tag_type', 'aro_signoff_default', 'aro_enote', 'form_access', 'permissions', 'role_modified_date', 'role_modified_by', 'role_modified_by', 'form_modified_date', 'form_modified_by']
          rec.prefix = ['aro_']

          if (rec.permissions.length > 0 && rec.permissions != undefined) {
            rec.created_date = moment(rec.permissions[0].created_date).format('YYYY-MM-DD')
            rec.created_by = rec.permissions[0].created_by
            rec.date_last_modified = rec.role_modified_date
            rec.modified_by = rec.role_modified_by
          }
          else {
            rec.created_date = ''
            rec.created_by = ''
            rec.date_last_modified = ''
            rec.modified_by = ''
          }
        })

        return accessGridData
      }

      //Function to prepare form Data for the grid/tippy
      function prepareFormGridData(data) {
        let formGridData = JSON.parse(JSON.stringify(data))
        formGridData.forEach((rec) => {
          rec.exceptionFields = ['aro_enable', 'aro_tag_type', 'aro_signoff_default', 'aro_enote', 'form_access', 'permissions', 'role_modified_date', 'role_modified_by', 'form_modified_date', 'form_modified_by']
          rec.prefix = ['aro_']
          rec.date_last_modified =rec.form_modified_date
          rec.modified_by = rec.form_modified_by
          if (rec.form_access.length > 0 && rec.form_access != undefined) {
            rec.created_date = moment(rec.form_access[0].created_date).format('YYYY-MM-DD')
            rec.created_by = rec.form_access[0].created_by
          }
          else {
            rec.created_date = ''
            rec.created_by = ''
          }
        })

        return formGridData
      }

      //Function to prepare form Data for the grid/tippy
      function prepareUserRoleGridData(data) {
        let formGridData = JSON.parse(JSON.stringify(data))
        formGridData.forEach((rec) => {

          rec.exceptionFields = ['aro_enable','aro_names','aro_signoff_default']
          rec.prefix = ['aro_']

          rec.aro_modified_date = moment(rec.aro_modified_date).format('YYYY-MM-DD')
          rec.aro_modified_by_per_id = getEmployeeName(rec.aro_modified_by_per_id)
          rec.aro_can_be_modified = rec.aro_can_be_modified === true ? translateTag(1379) : translateTag(1380)
        })

        return formGridData
      }

      //Function for sizing master detail columns
      function SizeColumnsMasterDetail() {
        $timeout(() => {
          if (vm.rolesListOptions.api) {  
            vm.rolesListOptions.api.sizeColumnsToFit()
          }
          if (vm.roleAccessOptions.api) {  
            vm.roleAccessOptions.api.sizeColumnsToFit()
          }
          if (vm.roleFormOptions.api) {
            vm.roleFormOptions.api.sizeColumnsToFit()
          }
          if (vm.roleAccessOptions.api != null) {
            vm.roleAccessOptions.api.forEachDetailGridInfo((detailGridInfo) => {
              detailGridInfo.api.sizeColumnsToFit()
            })
            vm.roleFormOptions.api.forEachDetailGridInfo((detailGridInfo) => {
              detailGridInfo.api.sizeColumnsToFit()
            })
          }
        })
      }

      // make sure that Ag-grid renders properly when the window is resized
      $(window).on('resize', () => {
        SizeColumnsMasterDetail()
      })

      //End
    }
  ])