angular
  .module('safeToDo')
  .service('adminRoleService', ['$http', '$location','$window',
    function ($http, $location, $window) {
        let roles = []
        let formList = []
        let permissionList = []
        let allpermissionList = []

        let rolesList = []
        
        return {
            getRoles: (module) => {
                return $http.get(`${__env.apiUrl}/api/sofvie-auth/roles/${module}/`).then((response) =>{
                    roles = response.data
                }, (errParams) => {
                    var errorObj = {};
                    if (errParams.status == 404) {
                        errorObj.error = translateTag(8459) //'Roles not found - Contact a system administrator'
                    }
                    else if(errParams.status === 403 && errParams.data.detail)
                    {
                        toastr.error(errParams.data.detail)
                    }
                    return errorObj;
                })
            },
            getFormListCategory: () => {
                return $http.get(`${__env.apiUrl}/api/form/get-form-category/`).then((response) =>{
                    formList = response.data                    
                }, (errParams) => {
                    var errorObj = {};
                    if (errParams.status == 404) {
                        errorObj.error = translateTag(8460) //'Form List not found - Contact a system administrator'
                    }
                    else if(errParams.status === 403 && errParams.data.detail)
                    {
                        toastr.error(errParams.data.detail)
                        formList = []
                        window.location.href = "/";
                    }
                    return errorObj;
                })
            },            
            saveRolePermissions: (permissions, role) => {
                return $http.post(`${__env.apiUrl}/api/sofvie-auth/roles/${role}/add-permissions/`, permissions).then((response) =>{
                    return response
                }, (errParams) => {
                    var errorObj = {};
                    if (errParams.status == 404) {
                        errorObj.error = translateTag(8462) // 'Could not Update Permissions - Contact a system administrator'
                    }
                    else if(errParams.status === 403 && errParams.data.detail)
                    {
                        toastr.error(errParams.data.detail)
                    }
                    return errorObj;
                })
            },    
            saveRoleForms: (forms, role) => {
                return $http.post(`${__env.apiUrl}/api/sofvie-auth/roles/${role}/add-update-form-access/`, forms).then((response) =>{
                    return response
                }, (errParams) => {
                    var errorObj = {};
                    if (errParams.status == 404) {
                        errorObj.error = translateTag(8463) // 'Could not Update Forms - Contact a system administrator'
                    }
                    else if(errParams.status === 403 && errParams.data.detail)
                    {
                        toastr.error(errParams.data.detail)
                    }
                    return errorObj;
                })
            },  
            getAllRoleList: (mode = "active") => {                
                return $http.get(`${__env.apiUrl}/api/sofvie-auth/get-role-list/${mode}/`).then((response) =>{
                    rolesList = response.data
                }, (errParams) => {
                    var errorObj = {};
                    if (errParams.status == 404) {
                        errorObj.error = translateTag(8463) // 'Could not Update Forms - Contact a system administrator'
                    }
                    else if(errParams.status === 403 && errParams.data.detail)
                    {
                        toastr.error(errParams.data.detail)
                    }
                    return errorObj;
                })
            }, 

            UpdateRole: (payload) => {
                return $http.post(`${__env.apiUrl}/api/sofvie-auth/update-role/`, payload).then((response) => {
                    return response.data
                                      
                }, (errParams) => {
                    console.log('Failed to perform update', errParams)
                })
            },

            CreateRole: (payload) => {
                return $http.post(`${__env.apiUrl}/api/sofvie-auth/create-role/`, payload).then((response) => {
                    return response.data
                                      
                }, (errorParams) => {
                    console.log('Failed to perform update', errorParams)
                })
            },

            GetEmployeeByRole: (payload) => {
                return $http.post(`${__env.apiUrl}/api/sofvie-auth/get-employee-by-role/`, payload).then((response) => {
                    return response.data
                                      
                }, (errorParams) => {
                    console.log('Failed to perform employee list by role', errorParams)
                })
            },

            ArchiveRole: (payload) => {
                return $http.post(`${__env.apiUrl}/api/sofvie-auth/archive-role/`, payload).then((response) => {
                    return response.data
                                      
                }, (errorParams) => {
                    console.log('Failed to perform employee list by role', errorParams)
                })
            },

            GetAllPermissionsWithParents: (payload) => {
                return $http.get(`${__env.apiUrl}/api/sofvie-auth/permissions-category/`).then((response) => {
                    allpermissionList = response.data
                                      
                }, (errorParams) => {
                    console.log('Failed to perform get all permissions with parents', errorParams)
                })
            },

            AddFormAccessPermissionToRole: (payload) => {
                return $http.post(`${__env.apiUrl}/api/sofvie-auth/add-form-access-permission-to-role/`,payload).then((response) => {
                   return response.data
                                      
                }, (errorParams) => {
                    console.log('Failed to add permission to the forms access', errorParams)
                }) 
            },

            readRoles: () => {
                return roles
            },
            readPermissionList: () =>{
                return permissionList
            },
            readFormList: () =>{
                return formList
            },
            readRoleList: () =>{
                return rolesList
            },    
            readAllPermissionList: () =>{
                return allpermissionList
            }           

        
        
        }
    }
])