﻿angular
    .module('safeToDo')
    .service('formBuilderService', ['$http',
      function ($http) {
     
        let formBuilderDataList = []
        let formBuilderCategoryList = []
        let fieldTypeList = []
        let listTypeList = []
        let formCategoryList = []

        return {
          getFormBuilderCategoryList: () => {
            return $http.get(`${__env.apiUrl}/api/form-builder/list-create-form-builder-category/`)
              .then((response) => {
                formBuilderCategoryList = response.data
              }, (errorParams) => {
                console.log('Failed to load form builder category Records', errorParams)
              });
          },
          
          getFormListCategoryFormBuilder: () => {
            return $http.get(`${__env.apiUrl}/api/form/get-form-category-formbuilder/`).then((response) =>{
              formCategoryList = response.data                
            }, (errParams) => {
                var errorObj = {};
                if(errParams.status === 400 && errParams.data.message)
                {
                    toastr.error(errParams.data.detail)
                    formCategoryList = []                    
                }
                return errorObj;
            })
        }, 
          
          addFormBuilderCategory: (data) => {
            return $http.post(`${__env.apiUrl}/api/form-builder/list-create-form-builder-category/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to add form builder category Record', errorParams)
                return "Error Happened"
              });
          },

          updateFormBuilderCategory: (data) => {
            return $http.post(`${__env.apiUrl}/api/form-builder/update-form-builder-category/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to update form builder category Record', errorParams)
                return "Error Happened"
              });
          },

          getFormBuilderDataList: () => {
            return $http.get(`${__env.apiUrl}/api/form-builder/list-form-builder/`)
              .then((response) => {
                formBuilderDataList = response.data
              }, (errorParams) => {
                formBuilderDataList = []
                console.log('Failed to load form builder Records', errorParams)
              });
          },  

          getFieldTypeList: () => {
            return $http.get(`${__env.apiUrl}/api/form-builder/get-form-field-type/`)
              .then((response) => {
                fieldTypeList = response.data
              }, (errorParams) => {
                fieldTypeList = []
                console.log('Failed to load Field Type List', errorParams)
              });
          },  

          createFormBuilder: (data) => {
            return $http.post(`${__env.apiUrl}/api/form-builder/create-form-builder/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to add form builder category Record', errorParams)
                return "Error Happened"
              });
          },

          updateFormBuilder: (data) => {
            return $http.post(`${__env.apiUrl}/api/form-builder/update-form-builder/${data.fob_slug}/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to add form builder category Record', errorParams)
                return "Error Happened"
              });
          },

          getSingleFormBuilderData: (data) => {
            return $http.post(`${__env.apiUrl}/api/form-builder/get-single-form-builder/${data}/`)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to load single form builder data', errorParams)
              });
          },  

          archiveFormBuilder: (data) => {
            return $http.post(`${__env.apiUrl}/api/form-builder/delete-form-builder/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to delete form builder', errorParams)
                return "Error Happened"
              });
          },

          archiveFormBuilderItem: (data) => {
            return $http.post(`${__env.apiUrl}/api/form-builder/delete-form-builder-item/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to delete form builder item', errorParams)
                return "Error Happened"
              });
          },

          createFormBuilderItem: (data) => {
            return $http.post(`${__env.apiUrl}/api/form-builder/create-form-builder-item/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to add form builder category Record', errorParams)
                return "Error Happened"
              });
          },

          updateFormBuilderItem: (data) => {
            return $http.post(`${__env.apiUrl}/api/form-builder/update-form-builder-item/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to update form builder item', errorParams)
                return "Error Happened"
              });
          },
          
          updateItemSortOrder : (data) => {
            return $http.post(`${__env.apiUrl}/api/form-builder/update-form-builder-item-sort/`, data)
              .then((response) => {
                return response.data
              }, (errorParams) => {
                console.log('Failed to update form builder item sort order', errorParams)
                return "Error Happened"
              });
          },

          getListTypeList: (data) => {
            return $http.get(`${__env.apiUrl}/api/form-builder/get-form-builder-lists/`)
              .then((response) => {
                listTypeList = response.data
              }, (errorParams) => {
                console.log('Failed to get list types', errorParams)
              });
          },

          archiveFomrCategory: (categoryId) => {
            return $http.delete(`${__env.apiUrl}/api/form-builder/archive-form-category/${categoryId}/`)
              .then((response) => {
                return response
              }, (errorParams) => {
                console.log('Failed to get list types', errorParams)
              });
          },


          readFormBuilderCategoryList: () => {
            return formBuilderCategoryList
          },
          readFormCategoryList : () =>{
            return formCategoryList
          },

          readFormBuilderDataList: () => {
            return formBuilderDataList
          },

          readFieldTypeList: () => {
            return fieldTypeList
          },

          readListTypeList: () => {
            return listTypeList
          },

        }
      }
    ]);