﻿angular.module('safeToDo')
.controller('formBuilderCtrl', ['$scope','$rootScope', '$routeParams', '$timeout', '$q', '$window', '$compile', '$location',  'gridService', 'modalService', 'profileService', 'formBuilderService','menuService', 'i18nService', 'exportCSV',
    function ($scope,$rootScope, $routeParams, $timeout, $q, $window, $compile, $location, gridService, modalService, profileService,formBuilderService,menuService, i18nService, exportCSV) {
        let vm = this       
        
        vm.loadMessage = translateTag(9118) //Loading custom forms. Please wait.
        
        vm.topSearch = ""    
        vm.formBuilderSearch = ""
        vm.updateModified = true
        vm.formBuilderCategoryList = []
        vm.formBuilderCategoryListDisplay = []
        vm.formBuilderDataList = []

        vm.currentCategory = {}
        vm.currentCustomForm = {}
        vm.currentItem = {}
        vm.formBuilderCategoryObj  = ""
        vm.fieldTypeList = []
        vm.listTypeList = []

        vm.actionDisabled = true
        vm.canViewFormBuilder = false
        vm.canManageFormBuilder = false        

        vm.categoryViewerOpen = false
        vm.hideingCategoryViewer = false
        vm.openingCategoryViewer = false

        vm.formBuilderViewerOpen = false
        vm.hideingFormBuilderViewer = false
        vm.openingFormBuilderViewer = false

        vm.valueChanged = false
        vm.edited = false

        vm.selectedFormCategory = null

        //Function to reset new list
        function newCategory() {
            vm.currentCategory = newCustomFormCategory()
        }

        function newCustomForm() {
            vm.currentCustomForm = newCustomFormObj()
        }

        function newItem() {
            vm.currentItem = newCustomFormItem()
        }

        menuService.getPagePermissions().then((data) => {
            vm.permissions = data

            vm.canViewFormBuilder = vm.permissions.includes('Can View Custom Forms') ? true : false
            vm.canManageFormBuilder = vm.permissions.includes('Can Manage Custom Forms') ? true : false
        })
  

        function newCustomFormObj() {
            return {  
                fob_id : null,
                fob_name : null,
                fob_slug : null,
                fob_description : null,
                form_category_id : null,
                form_category_type:null,
                fob_created_date : null,
                fob_modified_date : null,
                fob_enable : true,
                fob_enote : null,
                fob_created_by_per : null,
                fob_modified_by_per : null,
                fob_names : null,
                fob_descriptions : null,
                items :  []
            }
        }

        function newCustomFormCategory() {
            return {            
                fbc_id : null,
                fbc_name : null,
                fbc_slug : null,
                fbc_created_date : null,
                fbc_created_by_per : null,
                fbc_modified_date : null,
                fbc_modified_by_per_id : null,
                fbc_enable : true,
                fbc_names : null
            }
        }    

        function newCustomFormItem() {
            return {
                fbi_id: null,
                fbi_fob_id: null,
                fbi_fft: null,
                fbi_field_label: null,
                fbi_list_type_rlh_id: null,
                fbi_list_type_clh_id: null,
                fbi_list_type_flo_id: null,
                fbi_list_type: null,
                fbi_required: false,
                fbi_additional_info_label: null,
                fbi_additional_info_type: 1,
                fbi_additional_info_required: 0,
                fbi_sort: 1,
                fbi_enable: true,
                fbi_field_labels: [],
                fbi_additional_info_labels: []
            }
        }

        //#region Translations
        vm.currentTranslationMode = 'new'
        vm.currentTranslationList = []
        vm.currentAdditionalInfoTranslationList = []
        vm.systemLanguages = []

        vm.selectedLanguageID = 1
        vm.defaultLanguageID = 1

        vm.getCurrentTranslationList = (data) => {
            var currentTranList = []
            for(var lang in vm.systemLanguages)
            {
                lang = vm.systemLanguages[lang]
                if(!lang.lng_selected)
                    continue

                var tranObj = {
                    ltr_lng_id: lang.lng_id,
                    ltr_lng_name: lang.lng_name.toUpperCase(),
                    ltr_lng_description: lang.lng_description_text,
                    ltr_lng_default: lang.lng_default ? "*" : "",
                    ltr_text: new Array(data.length).fill(""),
                    ltr_translated:  new Array(data.length).fill(false)
                }
                
                for(var tranList in data)
                {
                    var tranIndex = tranList
                    tranList = data[tranList]
                    for (var tran in tranList)
                    {                        
                        tran = tranList[tran]
                        if(tran.ltr_lng_id == lang.lng_id)
                        {
                            tranObj.ltr_text[tranIndex] = tran.ltr_translated ? tran.ltr_text : ""
                            tranObj.ltr_translated[tranIndex] = tran.ltr_translated
                        }
                    }
                }

                currentTranList.push(tranObj)
            }
            return currentTranList
        }

        vm.getDisplayTranslation = (key, list) => {
            if(!list)
                return

            let defaultLanguageText = ""
            for(var tran in list[key])
            {
                tran = list[key][tran]                
                if(tran.ltr_lng_id == vm.defaultLanguageID)
                    defaultLanguageText = tran.ltr_text
                if(tran.ltr_lng_id == vm.selectedLanguageID && tran.ltr_text.trim() != "")
                    return tran.ltr_text
            }
            return defaultLanguageText
        }

        function getDefaultTranslation (key, list) {
            if(!list)
                return

            let defaultLanguageText = ""
            for(var tran in list[key])
            {
                tran = list[key][tran]                
                if(tran.ltr_lng_id == vm.defaultLanguageID)
                    defaultLanguageText = tran.ltr_text
            }
            return defaultLanguageText
        }

        function getSelectedLanguageID (name)
        {
            for(var lang in vm.systemLanguages)
            {
                lang = vm.systemLanguages[lang]
                if(lang.lng_name.toLowerCase() == name.toLowerCase())
                    return lang.lng_id
            }
            return 1
        }

        function getDefaultLanguageID ()
        {
            for(var lang in vm.systemLanguages)
            {
                lang = vm.systemLanguages[lang]
                if(lang.lng_default)
                    return lang.lng_id
            }
            return 1
        }
        //#endregion

        vm.formBuilderOptions = gridService.getCommonOptions()  
        vm.formBuilderOptions.pagination = false
        vm.formBuilderOptions.masterDetail = true
        vm.formBuilderOptions.animateRows = false

        //Set parget Ag-Grid colum values/settings
        vm.formBuilderOptions.detailCellRendererParams = {
            detailGridOptions: {
                showToolPanel: false,
                toolPanelSuppressRowGroups: true,
                toolPanelSuppressValues: true,
                toolPanelSuppressPivots: true,
                toolPanelSuppressPivotMode: true,
                toolPanelSuppressSideButtons: true,
                suppressContextMenu: true,
                suppressMovableColumns: true,
                columnDefs: [
                    {
                        field: '',
                        headerName: ' ',
                        minWidth: 40,
                        maxWidth: 40,
                        suppressMenu: true,
                        cellRenderer: function (params) {
                            return `<i class="${vm.itemIcon(params.data.fbi_fft)}" style="color: #9e9e9e !important;"></i>`
                        },
                    },
                    {
                        field: 'fieldType',
                        headerName: ' ',
                        minWidth: 150,
                        maxWidth: 250,
                        cellRenderer: function (params) {
                            return `<span class="clip" ng-non-bindable>${params.data.fieldType}</span>`
                        },
                    },
                    {
                        field: 'fbi_field_label',
                        headerName: ' ',
                        minWidth: 300,
                        cellRenderer: function (params) {
                            return `<span class="clip" ng-non-bindable>${params.data.fbi_field_label}</span>`
                        },
                    },
                    {
                        field: 'fbi_additional_info_required',
                        headerName: ' ',
                        minWidth: 200,
                        maxWidth: 200,
                        valueGetter: function(params) {
                            if (params.data.fbi_additional_info_required > 0) {
                                return translateTag(1379) //Yes
                            } else {
                                return translateTag(1380) //No
                            }
                        },
                    }
                ],
                rowHeight: 40,
                headerHeight:35,
                defaultColDef: {
                flex: 1,
                localeText: sofvie_agGrid_languages[`${selectedLanguage}`]
                },
            },
            getDetailRowData: (params) => {
                params.successCallback(params.data.items)
                vm.formBuilderOptions.api.forEachDetailGridInfo(function(detailGridInfo) {
                    translateAgGridHeader(detailGridInfo)
                    detailGridInfo.api.sizeColumnsToFit()
                    detailGridInfo.api.sizeColumnsToFit()
                })
            },
            //  onFirstDataRendered: onFirstDataRendered,
        }

        //Set child Ag-Grid colum values/settings
        let formBuilderColumns = [
            {
                headerName: '',
                field: 'selected',
                minWidth: 50,
                maxWidth: 50,
                checkboxSelection: true,
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
            },
            {
                field: 'fob_id',
                hide: true,
            },
            {
                field: "review", headerName: " ",  minWidth: 60, maxWidth: 60, suppressMenu: true, suppressSorting: true,
                cellRenderer: (params) => {
                return `<div ng-class="{ transparent: !formbuilder.canManageFormBuilder, pointer: formbuilder.canManageFormBuilder}" text-left" ng-click="formbuilder.openFormBuilderViewer('edit', '${params.data.fob_slug}', '${params.data.type}', '${params.data.fob_fbc}', '${params.data.fob_fca}')">
                    <i class="fa fa-pen" note="Edit" title="{{menu.translateLabels(1194)}}"></i>
                    </div>`;
                }
            },
            {
                field: "noOfItems",
                headerName: " ",
                minWidth: 100,
                maxWidth: 125,
                suppressMenu: true,
                filter: 'agSetColumnFilter',
                cellRenderer: 'agGroupCellRenderer'
                
            },
            {
                field: "fob_category_name",
                headerName: " ",
                minWidth: 200,
                maxWidth: 300,
                filter: 'agSetColumnFilter',
                cellRenderer: 'tippyCellRenderer',
                sort: 'asc'
            },
            {
                field: "fob_name",
                minWidth: 200,
                maxWidth: 250,
                headerName: " ",
                filter: 'agSetColumnFilter',
                cellRenderer: 'tippyCellRenderer'
                
            },
           
            {
                field: "fob_created_by_per",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                suppressMenu: true,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "fob_created_date",
                headerName: " ",
                minWidth: 100,
                maxWidth: 150,
                suppressMenu: true,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "fob_modified_by_per",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                suppressMenu: true,
                filter: 'agSetColumnFilter',
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "fob_modified_date",
                headerName: " ",
                minWidth: 100,
                suppressMenu: true,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            
        ]

        vm.formBuilderOptions.columnDefs = formBuilderColumns;

        //Function to disable action button if no rows are selected
        vm.formBuilderOptions.onSelectionChanged = () => {
            var selectedRows = vm.formBuilderOptions.api.getSelectedRows()
            vm.actionDisabled = selectedRows.length == 0
            $scope.$apply()
          }

        vm.actionPressed = (tag) => {
            $(`#${tag}`).addClass('show')
        }

        $(window).click((e) => {
            $('#myDropdown').removeClass('show')
            $('#myActionDropdown').removeClass('show')
        })
        
        //#region Functions for the search bars
        vm.topSearchChanged = () => {
            vm.formBuilderOptions.api.onFilterChanged();
            // Setting total number of displayed rows when filter changes
            setTotalRowsForMasterDetailGrid("total_number_records", vm.formBuilderOptions.api.getDisplayedRowCount())
        }

        // Calling a function to display the number of filtered records when filter changes
        vm.formBuilderOptions.onFilterChanged = () => {
            setTotalRowsForMasterDetailGrid("total_number_records", vm.formBuilderOptions.api.getDisplayedRowCount())
        }

        vm.formBuilderSearchChanged = () => {
            let filter = vm.formBuilderSearch.toUpperCase();
            let li = document.getElementById("sortable").getElementsByTagName('li');

            // Loop through all list items, and hide those who don't match the search
            for (i = 0; i < li.length; i++) {
                let typeText = li[i].querySelector('.type_search');
                let nameText = li[i].querySelector('.name_search');

                let txtValueType = typeText ? typeText.textContent || typeText.innerText : "";
                let txtValueName = nameText ? nameText.textContent || nameText.innerText : "";

                if (txtValueType.toUpperCase().indexOf(filter) > -1 || txtValueName.toUpperCase().indexOf(filter) > -1) {
                    li[i].style.display = "";
                } else {
                    li[i].style.display = "none";
                }
            }
        }

        vm.itemIcon = (fft_id) => {
            let iconClass = ""

            switch (fft_id) {
                case 1: iconClass = "fas fa-dot-circle"
                    break
                case 2: iconClass = "fa fa-font"
                    break
                case 3: iconClass = "fas fa-dot-circle"
                    break
                case 4: iconClass = "fas fa-check-square"
                    break
                case 5: iconClass = "fa fa-font"
                    break
                case 6: iconClass = "fas fa-calendar-alt"
                    break
                case 7: iconClass = "fas fa-caret-square-down"
                    break
                case 8: iconClass = "fas fa-caret-square-down"
                    break
                case 9: iconClass = "fas fa-images"
                    break
                case 10: iconClass = "fas fa-signature"
                    break
                case 11: iconClass = "fas fa-heading"
                    break
                case 12: iconClass = "fas fa-minus"
                    break
                case 13: iconClass = "fas fa-info-circle"
                    break
                case 14: iconClass = "fas fa-clock"
                    break
                default:
                    break
            }

            return iconClass
        }
        
        vm.exportCSV = () => {            
            let rows = JSON.parse(JSON.stringify(vm.formBuilderOptions.api.getSelectedRows()))
            rows = exportCSV.split_nested_lists(rows, 'items')
            exportCSV.export_csv(rows, translateTag(9133))
        }


        //Functions for Ag-Grid filters
     
        vm.formBuilderOptions.isExternalFilterPresent = () => {
            vm.sfilter = vm.topSearch.split(' ')
            return vm.sfilter !== ""
        }

        vm.formBuilderOptions.doesExternalFilterPass = (gridRow) => {
            let pass = false
            if (vm.topSearch.indexOf('?') === 0) {
                var submissionId = vm.topSearch.replace('?submissionId=', '')
                if (gridRow.data['ID'] == submissionId) {
                return true
                }
                return false
            }
            else {
                if (vm.sfilter[0] === '')
                    pass = true

                let searchArray = []
                for (var property in gridRow.data) {
                    if (gridRow.data.hasOwnProperty(property)) {
                        //any property in the row matches search box
                        vm.sfilter.forEach((data) => {
                        if ((gridRow.data[property] + "").toLowerCase().indexOf(data.toLowerCase()) > -1) {
                            searchArray[data] = 1
                        }
                        })
                    }
                }
                let a = 0
                for (data in searchArray)
                    a++

                if (a === vm.sfilter.length)
                    pass = true

                return pass
            }
        }

        // close modal        
        vm.closeModal = (modalid) => {
            newList()
            modalService.Close(modalid)
        }

        vm.cancelModal = (modalId) => {
            modalService.Close(modalId)
        }

        //Function to remove new single list item
        vm.removeNewListItem = (index) =>{
            vm.newList.splice(index, 1);

            if(vm.newList.length == 0){
                vm.newList.push(newCustomFormCategory())
            }
        }
        
        vm.archiveAgGridConfirmationModal = (list) => {
            vm.formBuilderCategoryObj = list
            vm.archiveCount = vm.formBuilderOptions.api.getSelectedRows().length
            vm.modalElements = {
                title: translateLabels(3580),  //"You are about to archive"
                message: `<div><p>${translateTag(3580)} ${vm.archiveCount} ${translateTag(3582)}</p></div>`, //"submissions. Undoing this will require IT support. Are you sure?"
                buttons: 
                    `<button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" notes="Cancel" >{{vm.componentTranslateLabels(1257)}}</button>        
                     <button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" notes="Yes">{{vm.componentTranslateLabels(1379)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'FORMBUILDERCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }  

        $scope.$on("FORMBUILDERCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.formBuilderArchive()
            }
        })

        vm.formBuilderArchive = () => {
            var rows = vm.formBuilderOptions.api.getSelectedRows()
            if (rows.length > 0) {
                var ids = []
                for (var i = 0; i < rows.length; i++) {
                    ids.push(rows[i].fob_slug)
                }
                formBuilderService.archiveFormBuilder(ids).then((r) => {
                    refreshData()
                    $rootScope.$broadcast('refresh-dataflyout') // Refreshing the Data Flyout
                })
            }
            modalService.Close('confirmModal')
        }

        vm.removeFormBuilderItem = (id) =>{
            $scope.$emit('STARTSPINNER', translateTag(3589)) //Loading data...
            formBuilderService.archiveFormBuilderItem ({fbi_id: id, updateModified: vm.updateModified}).then (() => {
                refreshFormBuilder(vm.currentCustomForm.fob_slug)                
            })
        }

        refreshData()

        function refreshData(){
            
            $scope.$emit('STARTSPINNER', vm.loadMessage)
            $q.all([      
                profileService.getFullEmployeeProfile(),
                formBuilderService.getFormBuilderCategoryList(),
                formBuilderService.getFormBuilderDataList(),
                formBuilderService.getFieldTypeList(),
                formBuilderService.getListTypeList(),
                formBuilderService.getFormListCategoryFormBuilder(),
                i18nService.getLanguages()
            ]).then(() => {
                vm.systemLanguages = i18nService.readLanguageList().languages
                vm.selectedLanguageID = getSelectedLanguageID(selectedLanguage)
                vm.defaultLanguageID = getDefaultLanguageID()
                
                vm.fullEmployeeList = profileService.readFullEmployeeProfile()
                vm.formBuilderCategoryListDisplay = prepareFormBuilderCategoryDisplay(formBuilderService.readFormCategoryList())
                vm.formBuilderDataList = formBuilderService.readFormBuilderDataList()
                vm.fieldTypeList = formBuilderService.readFieldTypeList()
                vm.listTypeList = formBuilderService.readListTypeList()
                if (vm.formBuilderOptions.api) {
                    translateAgGridHeader(vm.formBuilderOptions)
                    let model = vm.formBuilderOptions.api.getFilterModel()
                    vm.formBuilderOptions.api.setRowData(prepareFormBuilderGridData())           
                    vm.formBuilderOptions.api.redrawRows()
                    vm.formBuilderOptions.api.sizeColumnsToFit()
                    vm.formBuilderOptions.api.setFilterModel(model)
                }
            }).then(() => {
                try{
                    vm.formBuilderOptions.api.sizeColumnsToFit()
                    vm.formBuilderOptions.api.redrawRows()
                    vm.topSearchChanged()

                    // Reset total rows for master detail grid
                    vm.currentTotalRows =  vm.formBuilderOptions.api.getDisplayedRowCount()
                    setTotalRowsForMasterDetailGrid("total_number_records", vm.currentTotalRows)
                }catch(e){ $scope.$emit('STOPSPINNER')}
                $scope.$emit('STOPSPINNER')
            })
        }

        //Function to prepare Ag-Grid data with string values
        function prepareFormBuilderGridData() {

            let formBuilderGridData = JSON.parse(JSON.stringify(vm.formBuilderDataList))
            formBuilderGridData.forEach((rec) =>{
                rec.exceptionFields = ['url', 'fob_fbc', 'type','fob_fca','fob_slug','items','fob_created_by_per_id','fob_modified_by_per_id', 'fob_description_tag_id', 'fob_name_tag_id', 'fob_tag_type', 'fob_enable','fob_archived_date','fob_archived_by_per_id','fob_enote']
                rec.fob_category_name = ''
                rec.fob_category_name = vm.getCategory(vm.modifiedFormCategoryId(rec.type, rec.fob_fbc, rec.fob_fca))                              
                rec.fob_created_by_per = vm.getEmployeeName(rec.fob_created_by_per_id)
                rec.fob_modified_by_per = vm.getEmployeeName(rec.fob_modified_by_per_id)
                rec.fob_modified_date = rec.fob_modified_date ? moment(rec.fob_modified_date).format('YYYY-MM-DD') : ""
                rec.fob_created_date = moment(rec.fob_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                if(rec.items){
                    rec.noOfItems = rec.items.length
                    
                    rec.items.forEach((item) =>{
                        item.fieldType = vm.getFieldType(item.fbi_fft)
                    })
                }
            })

            return formBuilderGridData
        }

        function prepareFormBuilderCategoryDisplay(data)
        {
            let formBuilderCategoryDisplayData = []
            data.forEach((rec) =>{
                if(rec.category_id){
                    let obj = {
                        category_id: `${rec.category_id.toString()}-${rec.type.replace(' ','-')}`,
                        category_name: rec.category,
                        type: rec.type
                    }
                    formBuilderCategoryDisplayData.push(obj)
                }
            })
            return formBuilderCategoryDisplayData
        }

        vm.getCategory = (value) => {
            let categoryName = ""        
            vm.formBuilderCategoryListDisplay.forEach((type)=>{
              if(type.category_id == value) {
                categoryName = type.category_name
                return true
              }
            })
            return categoryName
        }

        vm.modifiedFormCategoryId = (type, customId, preDefinedId) => {
            let id = ''
            customId = customId == 'null' ? null : customId
            preDefinedId = preDefinedId == 'null' ? null: preDefinedId
            if(customId !== null){
                id = `${customId.toString()}-${type.replace(' ','-')}`
            }
            else if(preDefinedId !== null){
                id = `${preDefinedId.toString()}-${type.replace(' ','-')}`
            }
            return id
        }

        vm.getFieldType = (value) => {
            let fieldLabel = value
            vm.fieldTypeList.forEach((type)=>{
              if(type.fft_id == value) {
                fieldLabel = type.fft_field_label
              }
            })
            return fieldLabel
        }

        vm.getEmployeeName = (value) => {
            let name = value
            vm.fullEmployeeList.forEach((emp)=>{
              if(emp.per_id == value) {
                name = emp.per_full_name
              }
            })
            return name
        }

        vm.multiRequiredChanged = (bit) => {
            vm.currentItem.fbi_additional_info_required = updateBit(vm.currentItem.fbi_additional_info_required, bit, vm.currentItem.fbi_additional_info_required_multi[bit])
        }

        function updateBit(number, bitPosition, bitValue) {
            const bitValueNormalized = bitValue ? 1 : 0
            const clearMask = ~(1 << bitPosition)
            return (number & clearMask) | (bitValueNormalized << bitPosition)
        }

        vm.showRequired = (fbi_fft) => {
            let returnVal = false
            vm.fieldTypeList.forEach((type) => {
                if(type.fft_id == fbi_fft)
                    returnVal = type.fft_required
            })
            return returnVal
        }

        vm.showAdditionalInfo = (fbi_fft) => {
            let returnVal = false
            vm.fieldTypeList.forEach((type) => {
                if(type.fft_id == fbi_fft)
                    returnVal = type.fft_additional_info
            })
            return returnVal
        }

        vm.fieldTypeChanged = () => {
            vm.currentItem.fbi_required = false
            vm.currentItem.fbi_additional_info_required = 0
            vm.currentItem.fbi_list_type = null
            if(vm.currentItem.fbi_additional_info_required_multi)
                vm.currentItem.fbi_additional_info_required_multi = []

            vm.initializeSelect2('formBuilderItemTranslationModal', '.modal-body')
        }

        //Function to dynamically assigning detail row height
        vm.formBuilderOptions.getRowHeight = function (params) {
            var isDetailRow = params.node.detail;
            
            // for all rows that are not detail rows, return set height
            if (!isDetailRow) { return 40; }
            // otherwise return height based on number of rows in detail grid
            var detailPanelHeight = (params.data.items.length * 40) + 100;
            
            if(params.data.items.length <= 0) //Add extra when grid is empty
                detailPanelHeight += 30

            return detailPanelHeight;
        }

        //Update Ag-Grid size when window is resized
        $(window).on('resize', () => {
            $timeout(function () {
                if (vm.formBuilderOptions.api) {
                  vm.formBuilderOptions.api.sizeColumnsToFit()       
                
                  vm.formBuilderOptions.api.forEachDetailGridInfo(function(detailGridInfo){
                    detailGridInfo.api.sizeColumnsToFit()
                  })
                }
            })        
        })

        vm.openCustomList = () => {
            $location.path('/admin/list#customListSection');
        }
        
        function loadCategories () {
            $scope.$emit('STARTSPINNER', translateTag(3589)) //Loading data...
            $('#singleTableSearch').dataTable().fnClearTable();
            $('#singleTableSearch').dataTable().fnDestroy();

            $q.all([
                formBuilderService.getFormBuilderCategoryList(),
                formBuilderService.getFormListCategoryFormBuilder(),
            ]).then(() => {                
                vm.formBuilderCategoryList = formBuilderService.readFormBuilderCategoryList()   
                vm.formBuilderCategoryListDisplay = prepareFormBuilderCategoryDisplay(formBuilderService.readFormCategoryList())
                $scope.$emit('STOPSPINNER')
            }).then (() => {
                vm.initializeSelect2("category-viewer", '', 'singleTableSearch')
            })
        }

        vm.openCategoryViewer = () => {
            if(!vm.canManageFormBuilder)
                return

            vm.hideingCategoryViewer = false
            vm.categoryViewerOpen = true
            vm.openingCategoryViewer = true

            loadCategories()
        }

        vm.closeCategoryViewer = () => {
            vm.hideingCategoryViewer = true

            if(vm.edited)
            {
                vm.edited = false
                refreshData()
            }

            $timeout(() => {
                vm.categoryViewerOpen = false
            }, 400)
        }

        vm.openCategoryTranslationModal = (mode, index) => {
            resetFormFieldClassList('categoryTranslationForm')
            
            if(mode == 'new')
            {
                newCategory()
                var tranData = []
                tranData.push(vm.currentCategory['fbc_names'])
                vm.currentTranslationList = vm.getCurrentTranslationList(tranData)
            }
            else
            {
                vm.currentCategory = vm.formBuilderCategoryList[index]
                var tranData = []
                tranData.push(vm.currentCategory['fbc_names'])
                vm.currentTranslationList = vm.getCurrentTranslationList(tranData)
            }

            vm.currentTranslationMode = mode
            modalService.Open('categoryTranslationModal')
            vm.initializeSelect2('categoryTranslationModal', '.modal-body')
        }

        vm.archiveFormCategory = (index) => {
            // check if any forms under this category
            // show archive confirmation model
            // call archive endpoint
            let categoryId = vm.formBuilderCategoryList[index]['fbc_id']
            let formsExisting = vm.formBuilderDataList.some(t => t.fob_fbc === categoryId)

            // if formsExisting = false - proceed to show archive confirmation model
            // if formsExisting = true - proceed to show not archiving model with message

            if(!formsExisting){
                formBuilderService.archiveFomrCategory(categoryId).then ((response) => {
                    if(response.status == 200){
                        loadCategories()
                    }
                })
            }
            else {
                vm.cannotArchiveModal(index)
            }
        }        

        vm.cannotArchiveModal = (index) => {
            let categoryName = vm.formBuilderCategoryList[index]['fbc_name']
            let archiveMessage = translateLabels(9515)
            vm.modalElements = {
                title: `${translateLabels(1224)} ${translateLabels(9121)} -  ${categoryName}` ,
                message: `<div><p>${archiveMessage}</p></div>`,
                buttons: 
                    `<button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" notes="Cancel" >{{vm.componentTranslateLabels(1257)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'FORMBUILDERCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }  

        vm.saveCategory = () => {    
            resetFormFieldClassList('categoryTranslationForm')         
            if(validateFormFields('categoryTranslationForm'))
            {
                if(checkDuplicateCategory())
                {
                    vm.submitted = true
                    if(vm.currentTranslationMode == 'new')
                    {
                        var payload = {}
                        payload.fbc_names = prepareCategoryTranslationPayload(vm.currentTranslationList)  
                        formBuilderService.addFormBuilderCategory(payload).then((result) => {
                            loadCategories()

                            modalService.Close('categoryTranslationModal')
                            vm.currentTranslationList = []
                            vm.currentCategory = {}
                            vm.submitted = false

                            $rootScope.$broadcast('refresh-dataflyout') // Refreshing the Data Flyout
                        })
                    }
                    else
                    {
                        vm.edited = true
                        var payload = {}
                        payload.fbc_id = vm.currentCategory.fbc_id
                        payload.fbc_name = vm.currentCategory.fbc_name
                        payload.fbc_slug = vm.currentCategory.fbc_slug
                        payload.fbc_names = prepareCategoryTranslationPayload(vm.currentTranslationList) 

                        if(!vm.valueChanged) //If the values entered are the same as before we dont want to update
                        {
                            modalService.Close('categoryTranslationModal')
                            vm.currentTranslationList = []
                            vm.currentCategory = {}
                            vm.submitted = false
                        }
                        else
                        {
                            formBuilderService.updateFormBuilderCategory(payload).then((result) => {
                                loadCategories()
        
                                modalService.Close('categoryTranslationModal')
                                vm.currentTranslationList = []
                                vm.currentCategory = {}
                                vm.submitted = false 

                                $rootScope.$broadcast('refresh-dataflyout') // Refreshing the Data Flyout
                            })
                        }
                    }                    
                }
            }
            else 
            {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        function prepareCategoryTranslationPayload (data) {
            var payload = []

            for(var tran in data) {
                tran = data[tran]
                var payloadTran = {
                    ltr_lng_id: tran.ltr_lng_id,
                    ltr_text: tran.ltr_text[0].trim()
                }

                if(payloadTran.ltr_text != "")
                    payload.push(payloadTran)
            }
                
            return payload
        }

        function checkDuplicateCategory () {
            let formVal = document.forms['categoryTranslationForm']
            let validated = true
            vm.valueChanged = false
            let categoryExists = false
            let catgoryNameExists = ""
            let isPredefined = false

            let newCategory = {}
            newCategory['fbc_names'] = vm.currentTranslationList
            let newValue = getDefaultTranslation('fbc_names', newCategory)[0]
            
            vm.formBuilderCategoryList.forEach((existingCategory) => {
                let existingValue = getDefaultTranslation('fbc_names', existingCategory)

                if(vm.currentCategory.fbc_id == existingCategory.fbc_id) //If the values entered are the same as before we dont want to update
                {
                    vm.currentTranslationList.forEach((tran, index) => {
                        if((!existingCategory.fbc_names[index] && tran.ltr_text[0].trim() != "") || (existingCategory.fbc_names[index] && tran.ltr_text[0].trim() != existingCategory.fbc_names[index].ltr_text.trim()))
                            vm.valueChanged = true
                    })
                }
                else if(existingValue.toLowerCase().trim() === newValue.toLowerCase().trim())
                {
                    categoryExists = true
                    catgoryNameExists = existingValue
                }
            })

            // validating the newly entered category is exists in predefined categories
            vm.formBuilderCategoryListDisplay.forEach((category) => {
                let existingValue = category.category_name
                let existingtype = category.type
                if(existingValue && existingValue.toString().toLowerCase().trim() === newValue.toLowerCase().trim() && existingtype == "Pre-Defined Categories"){
                    categoryExists = true
                    catgoryNameExists = existingValue
                    isPredefined = true
                }
            })
            
            if(categoryExists)
            {
                if(isPredefined)
                    throwToastr('error',catgoryNameExists + " - " + translateTag(9260) +" " + translateTag(8569)) 
                else
                    throwToastr('error',catgoryNameExists + " - " + translateTag(4276)) //Category Already Exists
                formVal.classList.remove('was-validated')
                validated = false
            }

            return validated
        }

        function refreshFormBuilder (slug) {
            $scope.$emit('STARTSPINNER', translateTag(3589)) //Loading data...
            formBuilderService.getSingleFormBuilderData(slug).then((singleCustomForm) => {
                vm.currentCustomForm = singleCustomForm
                dragAndSort()
                vm.selectedFormCategory = vm.modifiedFormCategoryId(vm.currentCustomForm.type, vm.currentCustomForm.fob_fbc, vm.currentCustomForm.fob_fca)                
                $scope.$emit('STOPSPINNER')
            })
        }

        vm.openFormBuilderViewer = (mode='new', slug, type, c_id, pd_id) => {
            if(!vm.canManageFormBuilder)
                return
            vm.hideingFormBuilderViewer = false
            vm.formBuilderViewerOpen = true
            vm.openingFormBuilderViewer = true

            if(mode == 'new')
            {
                vm.updateModified = false
                vm.selectedFormCategory = null
                newCustomForm()
            }
            else
            {
                vm.updateModified = true
                vm.selectedFormCategory = vm.modifiedFormCategoryId(type, c_id, pd_id)              


                refreshFormBuilder(slug)
            }
            
            vm.initializeSelect2("form-builder-viewer")
        }

        vm.closeFormBuilderViewer = () => {
            vm.hideingFormBuilderViewer = true

            if(vm.edited)
            {
                vm.edited = false
                refreshData()
            }

            $timeout(() => {
                vm.formBuilderViewerOpen = false                
                vm.currentCustomForm = {}
            }, 400)
        }

        vm.openFormBuilderInfoTranslationModal = () => {
            resetFormFieldClassList('formBuilderInformationTranslationForm')
            vm.currentTranslationMode = vm.selectedFormCategory == null ? 'new' : 'edit'
            vm.currentCustomForm.form_category_id = vm.selectedFormCategory

            let tranData = []
            tranData.push(vm.currentCustomForm['fob_names'])
            tranData.push(vm.currentCustomForm['fob_descriptions'])

            vm.currentTranslationList = vm.getCurrentTranslationList(tranData)

            modalService.Open('formBuilderInformationTranslationModal')
            vm.initializeSelect2('formBuilderInformationTranslationModal', '.modal-body')
        }

        vm.saveFormBuilderInfo = () => {
            resetFormFieldClassList('formBuilderInformationTranslationForm')
            if(vm.validateCustomFormInfo())
            {
                if(checkDuplicateCustomForm())
                {
                    vm.edited = true
                    vm.submitted = true

                    let translationPayload = prepareFormBuilderInfoTranslationPayload(vm.currentTranslationList)
                    vm.currentCustomForm['fob_names'] = translationPayload.fob_names
                    vm.currentCustomForm['fob_descriptions'] = translationPayload.fob_descriptions
                    let type_id = vm.currentCustomForm['form_category_id'].split(/-(.*)/s)
                    vm.currentCustomForm['form_category_id'] = parseInt(type_id[0])
                    vm.currentCustomForm['form_category_type'] = type_id[1]

                    if(vm.currentTranslationMode == 'new')
                        delete vm.currentCustomForm.fob_id
                    if(vm.currentTranslationMode == 'new')
                    {
                        formBuilderService.createFormBuilder(vm.currentCustomForm).then((result) => {
                            modalService.Close('formBuilderInformationTranslationModal')
                            vm.updateModified = false
                            vm.currentTranslationList = []
                            vm.submitted = false
                            vm.currentCustomForm.fob_id = result.Output.fob_id
                            refreshFormBuilder(result.Output.fob_slug)
                            $rootScope.$broadcast('refresh-dataflyout') // Refreshing the Data Flyout
                        })
                    }
                    else
                    {
                        formBuilderService.updateFormBuilder(vm.currentCustomForm).then((result) => {
                            modalService.Close('formBuilderInformationTranslationModal')
                            vm.currentTranslationList = []
                            vm.submitted = false
                            refreshFormBuilder(result.new_slug)
                            $rootScope.$broadcast('refresh-dataflyout') // Refreshing the Data Flyout
                        })
                    }
                }
            }
            else 
            {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        function prepareFormBuilderInfoTranslationPayload (data) {
            var fob_names = []
            var fob_descriptions = []
            for(var tran in data) {
                tran = data[tran]
                var payloadTran = {
                    ltr_lng_id: tran.ltr_lng_id,
                    ltr_text: tran.ltr_text[0].trim()
                }
                if(payloadTran.ltr_text != "")
                    fob_names.push(payloadTran)
                payloadTran = {
                    ltr_lng_id: tran.ltr_lng_id,
                    ltr_text: tran.ltr_text[1].trim()
                }
                if(payloadTran.ltr_text != "")
                    fob_descriptions.push(payloadTran)
            }

            var payload = {
                fob_names: fob_names,
                fob_descriptions: fob_descriptions,
            }
                
            return payload
        }

        vm.validateCustomFormInfo = () => {
            return validateFormFields('formBuilderInformationTranslationForm')
        }

        function checkDuplicateCustomForm () {
            let formVal = document.forms['formBuilderInformationTranslationForm']
            let validated = true
            let nameExists = false
            let nameExistsValue = ""
            let newCustomForm = {}
            newCustomForm['fob_names'] = vm.currentTranslationList
            let newValue = getDefaultTranslation('fob_names', newCustomForm)[0]
            
            vm.formBuilderDataList.forEach((existingCustomForm) => {
                let existingValue = existingCustomForm.fob_name
                
                if(existingValue && existingValue.toString().toLowerCase().trim() === newValue.toLowerCase().trim() && vm.currentCustomForm.fob_id != existingCustomForm.fob_id)
                {
                    nameExists = true
                    nameExistsValue = existingValue
                }
            })
            
            if(nameExists)
            {
                throwToastr('error',nameExistsValue + " - " + translateTag(8569)) // already exists
                formVal.classList.remove('was-validated')
                validated = false
            }

            return validated
        }

        vm.openFormBuilderItemTranslationModal = (mode, index) => {
            resetFormFieldClassList('formBuilderItemTranslationForm')
            if(mode == 'new')
            {
                newItem()
            }
            else
            {
                vm.currentItem = vm.currentCustomForm.items[index]

                // Set list type index
                vm.currentItem.fbi_list_type = vm.getListTypeIndex(vm.currentItem)

                // Single additional info required
                if(vm.currentItem.fbi_additional_info_required <= 1 && vm.currentItem.fbi_fft != 1 && vm.currentItem.fbi_fft != 3)
                    vm.currentItem.fbi_additional_info_required = vm.currentItem.fbi_additional_info_required == 1 ? true : false
                else { // Multi additional info required
                    vm.currentItem.fbi_additional_info_required_multi = vm.currentItem.fbi_additional_info_required.toString(2).split('').reverse().map(function(s) { 
                        return parseInt(s) == 1 ? true : false
                    })
                }
            }

            var tranData = []
            tranData.push(vm.currentItem['fbi_field_labels'])
            vm.currentTranslationList = vm.getCurrentTranslationList(tranData)

            var tranDataAdditionalInfo = []
            tranDataAdditionalInfo.push(vm.currentItem['fbi_additional_info_labels'])
            vm.currentAdditionalInfoTranslationList = vm.getCurrentTranslationList(tranDataAdditionalInfo)

            vm.currentTranslationMode = mode
            modalService.Open('formBuilderItemTranslationModal')
            vm.initializeSelect2('formBuilderItemTranslationModal', '.modal-body')
        }

        vm.getListTypeIndex = (item) => {
            let listTypeId = null
            let listType = 0

            if(item.fbi_list_type_rlh_id) {
                listTypeId = item.fbi_list_type_rlh_id
                listType = 0
            } else if(item.fbi_list_type_flo_id) {
                listTypeId = item.fbi_list_type_flo_id
                listType = 1
            } else {
                listTypeId = item.fbi_list_type_clh_id
                listType = 2
            }

            for(let i = 0; i < vm.listTypeList.length; i++) {
                if(vm.listTypeList[i].id == listTypeId && vm.listTypeList[i].list_type == listType)
                    return i
            }
        }

        vm.saveCustomFormItem = () => {
            resetFormFieldClassList('formBuilderItemTranslationForm')
            if(vm.validateCustomFormItem())
            {
                vm.edited = true
                vm.submitted = true

                vm.currentItem['fbi_field_labels'] = prepareFormBuilderItemTranslationPayload(vm.currentTranslationList)

                if(vm.currentItem.fbi_additional_info_required > 0)
                    vm.currentItem['fbi_additional_info_labels'] = prepareFormBuilderItemTranslationPayload(vm.currentAdditionalInfoTranslationList)
                else
                    vm.currentItem['fbi_additional_info_labels'] = []

                if(vm.currentTranslationMode == 'new')
                {
                    delete vm.currentItem.fbi_id
                    vm.currentItem.fbi_fob_id = vm.currentCustomForm.fob_id
                }

                // Handle list type
                if(vm.currentItem.fbi_fft == 7 || vm.currentItem.fbi_fft == 8) {
                    let listType = vm.listTypeList[vm.currentItem.fbi_list_type]

                    vm.currentItem.fbi_list_type_rlh_id = null
                    vm.currentItem.fbi_list_type_flo_id = null
                    vm.currentItem.fbi_list_type_clh_id = null

                    if(listType.list_type == 0)
                        vm.currentItem.fbi_list_type_rlh_id = listType.id
                    else if(listType.list_type == 1)
                        vm.currentItem.fbi_list_type_flo_id = listType.id
                    else
                        vm.currentItem.fbi_list_type_clh_id = listType.id
                }

                let payload = vm.currentItem
                payload.updateModified = vm.updateModified

                if(vm.currentTranslationMode == 'new')
                {
                    formBuilderService.createFormBuilderItem(payload).then((result) => {
                        modalService.Close('formBuilderItemTranslationModal')
                        vm.currentTranslationList = []
                        vm.currentAdditionalInfoTranslationList = []
                        vm.currentItem = {}
                        vm.submitted = false

                        refreshFormBuilder(vm.currentCustomForm.fob_slug)
                    })
                }
                else
                {
                    formBuilderService.updateFormBuilderItem(payload).then((result) => {
                        modalService.Close('formBuilderItemTranslationModal')
                        vm.currentTranslationList = []
                        vm.currentAdditionalInfoTranslationList = []
                        vm.currentItem = {}
                        vm.submitted = false

                        refreshFormBuilder(vm.currentCustomForm.fob_slug)
                    })
                }
            }
            else 
            {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        function prepareFormBuilderItemTranslationPayload (data) {
            var payload = []

            for(var tran in data) {
                tran = data[tran]
                var payloadTran = {
                    ltr_lng_id: tran.ltr_lng_id,
                    ltr_text: tran.ltr_text[0].trim()
                }

                if(payloadTran.ltr_text != "")
                    payload.push(payloadTran)
            }
                
            return payload
        }

        vm.validateCustomFormItem = () => {
            return validateFormFields('formBuilderItemTranslationForm')
        }
                      
        function dragAndSort(){
            $( "#sortable" ).sortable({
                items: "li:not(.ui-state-disabled)",
                axis: "y",
                cursorAt: { top: 20 },
                opacity: 0.9,

                start: function(event, ui){
                    ui.placeholder.height(ui.item.height())
                    ui.placeholder.css("visibility", "visible")
                    ui.placeholder.css("background-color", "grey")
                    ui.placeholder.css("opacity", "0.3")
                },

                stop: function( event, ui ) {
                    let itemCount = 1
                    vm.currentCustomForm.items.forEach((val, index) => {
                        elementId = event.target.children[index].firstElementChild

                        if(elementId != null ){
                            rowIndex = parseInt(elementId.id.split('-').pop());

                         if(vm.currentCustomForm.items[rowIndex].fbi_enable == true){
                            vm.currentCustomForm.items[rowIndex].fbi_sort = itemCount
                            itemCount = itemCount + 1
                         }
                        }
                    });

                    updateSort()
                    $scope.$apply()                    
                }
            });
            $( "#sortable" ).sortable({ handle: '.handle'})
            $( "#sortable" ).disableSelection()
        }

        function updateSort () {
            vm.edited = true
            let payload = {form_builder_item_sort: []}
            payload.fob_id = vm.currentCustomForm['fob_id']
            payload.updateModified = vm.updateModified
            vm.currentCustomForm.items.forEach((item, index) => {
                let sortItem = {
                    fbi_id: item.fbi_id,
                    fbi_sort: item.fbi_sort
                }

                payload.form_builder_item_sort.push(sortItem)
            });
            formBuilderService.updateItemSortOrder (payload)
        }

        // initializeSelect2       
        vm.initializeSelect2 = (parent, section='', table=null)=>{
            setTimeout(()=>{ 
              $('.select-single')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} ${section}`), escapeMarkup: function (text) { return text }})
                .on('select2:select', () => {
                    $(this).parent().find('label').addClass('filled');
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down"); // Add caret on selects
                
                if(table)
                {
                    $(`#${table}`).DataTable({
                        destroy: true,
                        "searching": true,
                        "paging": false,
                        "ordering": false,
                        "info": false,
                        language: {
                            search: "_INPUT_",
                            searchPlaceholder: translateTag(2346), //Search...
                            zeroRecords: translateTag(8295) //No matching records found
                        },
                        initComplete: function () {
                            $('#singletablearea .dataTables_wrapper>.row').addClass('mx-0')
                            $('#formBuilderTablearea .dataTables_wrapper>.row').addClass('mx-0')
                            $('.dataTables_wrapper>.row:first-child>div:first-child').addClass('d-none')
                            $('.dataTables_wrapper>.row:first-child>div:last-child').removeClass('col-sm-12 col-md-6').addClass('col-12')
                            $('.dataTables_filter label').addClass('w-100 md-form p-0')
                            $('.dataTables_filter input[type="search"]').removeClass('form-control').css({ 'width': '100%', 'display': 'inline-block', 'margin':'0' })
                        }
                    })
                }
            }, 100)
        }
    }
])