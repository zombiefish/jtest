angular.module('safeToDo')
.controller('i18nCtrl', ['$scope', '$routeParams', '$timeout', '$q', '$compile',  'gridService', 'modalService', 'profileService', 'i18nService','menuService',
    function ($scope, $routeParams, $timeout, $q, $compile, gridService, modalService, profileService,i18nService,menuService) {
        let vm = this
        
        vm.topSearch = ""
        vm.filters = "All Values"
        vm.filterValues=['All Values',
                        'Equipment Pre-Op Values',
                        'Values Missing Translations',
                        'List Values',
                        'Role Definition Values',
                        'Training Record Values']
        vm.loadMessage = translateTag(3589)
        vm.defaultLanguage = null
        vm.selectedLanguages = []
        vm.submitted = false
        vm.gridData = []
        vm.currentTranslation = {}

        vm.i18nOptions = gridService.getCommonOptions()

        //Get permissions for the user
        menuService.getPagePermissions().then((data) => {
            vm.permissions = data

            vm.canViewInternationalisation = vm.permissions.includes('Can View Internationalization') ? true : false
            if(!vm.canViewInternationalisation){
                window.location.href = "/";
            }
            vm.canManageAdvancedSettings = vm.permissions.includes('Can Manage Advanced Settings') ? true : false
        })

        //Set Ag-Grid colum values/settings
        let i18nDefaultColumns = [
            {
                field: "review",
                headerName: " ",
                // minWidth: 240,
                // maxWidth: 1000,
                suppressMenu: true,
                suppressSorting: true,
                cellRenderer: (params) => {
                    tag = params.data.ltr_tag
                    return `<span class="fa-1x fa-stack" style=" width: 1.25em;" ng-class="{ transparent: false, pointer: true}"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" ng-click="i18n.openUserValuesEditModal(${tag})" title={{menu.translateLabels(1194)}}></i></span>`
                },

            },
            {
                field: "ltr_tag",
                headerName: " ",
                // minWidth: 240,
                // maxWidth: 1000,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                sort: 'asc',
            }
        ]

        vm.topSearchChanged = () => {
            vm.i18nOptions.api.setQuickFilter(vm.topSearch)
        }

        //Function to prevent changing the default lang when there are missing translation for that language
        vm.preventRadioSelection = function(e) {
            vm.resetSelectedLanguaged()
            var changeDefaultlang = parseInt(e.delegateTarget.defaultValue)
            vm.changeDefaultlang_displayName = vm.languageList.find(lang=> lang.lng_id===changeDefaultlang).lng_description_text
            vm.changeLang_fieldKey = vm.languageList.find(lang=> lang.lng_id===changeDefaultlang).lng_name
            if(vm.missingTranslationsCount[changeDefaultlang]>0){
              e.preventDefault();
              e.stopPropagation();
              vm.missingTransMode = "default"
              modalService.Open('missingTranslationsModal');
            }
            else{
                vm.defaultLanguage = changeDefaultlang
                var elements_checkedLanguages = document.getElementsByName("selected_languages_checkbox");
                elements_checkedLanguages.forEach((elem)=>{
                    if (parseInt(elem.defaultValue)===parseInt(vm.defaultLanguage)){
                        elem.checked = true
                        elem.disabled = true
                    }
                    else{
                        elem.disabled = false
                    }
                })
            }
        }

        function setFilterToMissingValues () {
            if (vm.i18nOptions.api){
                var hardcodedFilter = {}
                // console.log("Field Key", vm.changeLang_fieldKey)
                hardcodedFilter[vm.changeLang_fieldKey] = {
                    filterType: 'set',
                    values: [null],
                }
                if (hardcodedFilter) {
                    vm.i18nOptions.api.setFilterModel(hardcodedFilter);
                }
                // console.log("Filter Model", vm.i18nOptions.api.getFilterModel())
            }
        }
        
        vm.navigateToMissingTranslations = () =>{
            vm.filters='Values Missing Translations'
            vm.cancelModal('missingTranslationsModal')
            $timeout(function() {
                angular.element('#navUserValues').trigger('click');
            });
            setTimeout(() => {
                setFilterToMissingValues()
            }, 1200);
        }
       
        vm.i18nOptions.columnDefs = i18nDefaultColumns
        function generateLanguageColumns () {
            var fieldDef ={}
            vm.translationList.languages.forEach((lang)=>{
                fieldDef ={}
                fieldDef.field = lang.lng_name,
                fieldDef.headerName = " ",
                // fieldDef.minWidth = 240,
                // fieldDef.maxWidth = 1000,
                fieldDef.filter = 'agSetColumnFilter',
                fieldDef.menuTabs = ['filterMenuTab'],
                fieldDef.cellRenderer = 'tippyCellRenderer'
                i18nColumns.push(fieldDef)
            })
        }
        vm.refreshData = (filters) => {
            $scope.$emit('STARTSPINNER', vm.loadMessage)
            $q.all([
                i18nService.getTranslationList(vm.filters),
                i18nService.getLanguages(),
                i18nService.getMissingLanguageSettings()
            ]).then((response) =>{
                vm.translationList = i18nService.readTranslationList()
                vm.languageList =  i18nService.readLanguageList().languages
                vm.missingTranslationsCount = i18nService.readMissingTransLanguageList().missingTrans
                vm.defaultLanguage=vm.languageList.find(lang=> lang.lng_default).lng_id
                if (vm.i18nOptions.api) {
                    if (!filters)
                        i18nColumns = []
                    angular.copy(i18nDefaultColumns, i18nColumns)
                    generateLanguageColumns()
                    vm.i18nOptions.api.setColumnDefs(i18nColumns)
                    translateAgGridHeader (vm.i18nOptions)
                    let model = vm.i18nOptions.api.getFilterModel()
                    vm.i18nOptions.paginationPageSize = 15
                    vm.i18nOptions.api.setRowData(prepareGridData())
                    vm.i18nOptions.api.redrawRows()
                    vm.i18nOptions.api.sizeColumnsToFit()
                    vm.i18nOptions.api.setFilterModel(model)
                }
                $scope.$emit('STOPSPINNER')
            })
        }
        vm.refreshData(false)

        vm.openUserValuesEditModal = (ltr_tag) => {
            resetFormFieldClassList('userValuesEditModalForm')
            vm.currentTranslation =JSON.parse(JSON.stringify(vm.gridData.find((data) => data.ltr_tag === ltr_tag)))
            modalService.Open('userValuesEditModal')
        }

        vm.cancelModal=(modalId)=>{
            modalService.Close(modalId)
        }

        vm.saveTranslations = (modalId) => {
            if(vm.validateTranslationInfo()){
                vm.submitted=true
                var translations=[]
                trans_keys = Object.keys(vm.currentTranslation)
                vm.languageList.forEach((lang)=>{
                    trans_keys.forEach((key)=>{
                        if(key===lang.lng_name){
                            obj = {
                                "ltr_lng_id":lang.lng_id,
                                "ltr_text":vm.currentTranslation[key],
                            }
                            if(vm.currentTranslation[key]===""){
                                obj['ltr_translated'] = false
                                defaultLanguage_name=vm.languageList.find(lang=> lang.lng_default).lng_name
                                obj["ltr_text"] = vm.currentTranslation[defaultLanguage_name]
                            }else{
                                obj['ltr_translated'] = true
                            }
                            translations.push(obj)
                        }
                    })
                })
                let payload = {
                    "ltr_tag": vm.currentTranslation.ltr_tag,
                    "translations":JSON.parse(JSON.stringify(translations))
                }
                preparedPayload = JSON.parse(JSON.stringify(payload))
                i18nService.saveAdminTranslations(preparedPayload).then((response)=>{   
                    if (response.message==='success'){
                        vm.refreshData(true)  
                        vm.cancelModal(modalId)
                    }else{
                        throwToastr('error',translateTag(3858),2000)
                    }
                    
                })
            }
            else{
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
            vm.submitted=false
        }
        

        vm.validateTranslationInfo = () => {
            return validateFormFields('userValuesEditModalForm')
        }

        vm.saveAdvancedSettings = () =>{
            toastr.options.progressBar = true
            throwToastr('success',translateTag(4279),2000)
            vm.setSelectedLanguages()
            let payload = {
                "lng_default": parseInt(vm.defaultLanguage),
                "selected": vm.selectedLanguages
            }
            i18nService.saveAdminLanguageSettings(payload).then((response)=>{   
                if (!response.message==='success'){
                    throwToastr('error',translateTag(3858),2000)
                }
            })
        }

        vm.setSelectedLanguages = () => {
            var elements_checkedLanguages = document.getElementsByName("selected_languages_checkbox");
            vm.selectedLanguages = []
            elements_checkedLanguages.forEach((elem)=>{
                if (parseInt(elem.defaultValue)===parseInt(vm.defaultLanguage)){
                    elem.checked = true
                }
                if (elem.checked){
                    vm.selectedLanguages.push(parseInt(elem.defaultValue))
                }
            })
        }

        vm.resetSelectedLanguaged = () => {
            var elements_checkedLanguages = document.getElementsByName("selected_languages_checkbox");
            elements_checkedLanguages.forEach((elem)=>{
                if (vm.checkSelectedLanguages(parseInt(elem.defaultValue))){
                    elem.checked = true
                }else{
                    elem.checked = false
                }
            })
        }

        vm.alertMissingTransForSelectedLanguage = (e) => {
            if (e.currentTarget.checked){
                var changeAvailableLang = parseInt(e.currentTarget.defaultValue)
                vm.changeAvailableLang_displayName = vm.languageList.find(lang=> lang.lng_id===changeAvailableLang).lng_description_text
                vm.defaultLanguage_displayName=vm.languageList.find(lang=> lang.lng_default).lng_description_text
                if(vm.missingTranslationsCount[changeAvailableLang]>0){
                    vm.missingTransMode = "available"
                    modalService.Open('missingTranslationsModal');
                } 
            }
        }

        vm.checkSelectedLanguages = (lng) => {
            return vm.languageList.find(lang=> lang.lng_id===lng).lng_selected
        }

        //Search function in AG Grid
        vm.topSearchChanged = () => {
            vm.i18nOptions.api.setQuickFilter(vm.topSearch);
        }

        vm.changeFilters = (filter) =>{
            vm.filters = filter
            vm.refreshData(true)
        }


        // function to reset toastr options
        function resetToastrOptions() {
            toastr.options.progressBar = false,
            toastr.options.positionClass = 'toast-top-right'
            toastr.options.timeOut= "5000"
        }
        //function to throw toastr with time interval
        function throwToastr(type,message,time){
            toastr.options.timeOut = time
            toastr.options.positionClass = 'rmm-toast-custom'
            switch (type) {
                case 'success':
                    toastr.success(message)
                    break;
                case 'warning':
                    toastr.warning(message)
                    break;
                case 'error':
                    toastr.error(message)
                    break;
                case 'info':
                    toastr.info(message)
                    break;
            }
            resetToastrOptions()
        }

        function prepareGridData () {
            let gridData = JSON.parse(JSON.stringify(vm.translationList.tags))
            let isTranslated = JSON.parse(JSON.stringify(vm.translationList.translated))
            gridData.forEach((rec) => {
                rec.exceptionFields = ['review']
                rec.review = ''
                Object.keys(rec).forEach((rec_key)=>{
                    translatedFlag = isTranslated.find((trans)=> trans.ltr_lng__lng_name===rec_key && trans.ltr_tag===rec['ltr_tag'])
                    if(translatedFlag && !(translatedFlag.ltr_translated)){
                        rec[rec_key] = ''
                    }
                })
            });
            vm.gridData = gridData
            return gridData
        }
        //Update Ag-Grid size when window is resized
        $(window).on('resize', () => {
            $timeout(function () {
                if (vm.i18nOptions.api) {
                    vm.i18nOptions.api.sizeColumnsToFit()
                }
            })
        })
    }
])