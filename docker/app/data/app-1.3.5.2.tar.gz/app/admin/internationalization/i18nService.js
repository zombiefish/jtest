angular
    .module('safeToDo')
    .service('i18nService', ['$http',
      function ($http) {
          let translationList = []
        //   let languageList = []
          let missingTranslanguageList = []
        return {
            getTranslationList: (payload) => {
            return $http.get(`${__env.apiUrl}/api/language/get_translation_list/${payload}/`)
                .then((response) => {
                translationList = response.data
                return translationList
                }, (errorParams) => {
                console.log('Failed to Translation Records', errorParams)
                });
            },

            getMissingLanguageSettings: () => {
                return $http.get(`${__env.apiUrl}/api/language/get_language_settings/`)
                    .then((response) => {
                    // console.log('response.data -- ', response.data)
                    missingTranslanguageList = response.data
                    return missingTranslanguageList
                    }, (errorParams) => {
                    console.log('Failed to Language Records', errorParams)
                    });
                },
            
            getLanguages: () => {
                return $http.get(`${__env.apiUrl}/api/language/get-language-list/`)
                    .then((response) => {                 
                        languageList = response.data
                        return languageList
                    }, (errorParams) => {
                    console.log('Failed to Language Records', errorParams)
                    });
            },
            
            saveAdminLanguageSettings: (payload) => {
                return $http.post(`${__env.apiUrl}/api/language/update_language_settings/`, payload)
                    .then((response) => {
                    // console.log('response.data -- ', response.data.status)
                    return response.data
                    }, (errorParams) => {
                    console.log('Failed to Update Language Settings', errorParams)
                    });
                },
            
            saveAdminTranslations: (payload) => {
                return $http.post(`${__env.apiUrl}/api/language/update_translation/`, payload)
                    .then((response) => {
                    console.log('response.data -- ', response.data)
                    return response.data
                    }, (errorParams) => {
                    console.log('Failed to Update Language Settings', errorParams)
                    });
                },

            readTranslationList: () => {
                return translationList
            },
            readMissingTransLanguageList: () => {
                return missingTranslanguageList
            },
            readLanguageList: () => {
                return languageList
            }
         }
      }
    ]);