﻿// enter license key.
agGrid.LicenseManager.setLicenseKey("Minalytix_SafeToDo_1Devs23_August_2018__MTUzNDk3ODgwMDAwMA==72f709bc3f78747c84e8c7d568297c64");
//Prep AG-Grid for angular.
agGrid.initialiseAgGridWithAngular1(angular);

//Init Angular module.
var safeToDo = angular.module('safeToDo', ['ngRoute', 'ngAnimate', 'ngCookies', 'agGrid', 'pascalprecht.translate','angularTranslateApp']);