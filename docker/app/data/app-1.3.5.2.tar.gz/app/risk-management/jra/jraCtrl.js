angular
    .module('safeToDo')
    .controller('jraCtrl', ['$compile', '$rootScope','$scope', '$timeout', '$q', '$window', '$interval', '$sce', 'gridService', 'select2Service',
      'jraService', 'listService', 'modalService', 'profileService', 'employeesService','menuService', 'actionManagementService', 'praService', 'documentLockService','$translate','$translatePartialLoader','rmmAttachmentsService','fileUploadService','exportCSV',
        function ($compile, $rootScope,$scope, $timeout, $q, $window, $interval, $sce, gridService, select2Service, jraService, listService,
            modalService, profileService, employeesService, menuService, actionManagementService,praService, documentLockService,$translate,$translatePartialLoader,rmmAttachmentsService,fileUploadService, exportCSV) {
            var vm = this;
              
            let dateToday = moment(new Date(), 'YYYY-MM-DD')
            $translate.use(selectedLanguage)
            vm.employeeList = []
            vm.fullEmployeeList = []
            vm.currentAcknowledgeHistory = []
            vm.userId = null
            vm.siteList = []
            vm.jobList = []
            vm.jobListSelect = []
            vm.actionTypeList = []
            vm.singleServeReportUrl = 'job_risk_assessment'
            vm.jraReviewDataContext = {}
            vm.topSearch = ''
            vm.archiveCount = 0
            vm.deleteAttCount = 0
            vm.jraAGData = []
            vm.attachmentData = []
            vm.newAttachments = []
            vm.uploadFileList= []
            vm.actionDisabled = true
            vm.attActionDisabled = true
            vm.canArchiveSubmissions = false
            vm.jraViewerOpen = false
            vm.hideingJraViewer = false
            vm.openingJraViewer = false
            vm.currentAcknowledge = null
            vm.generalEditData = {}
            vm.hazardEditData = {}
            vm.tmpDeletedStepCategories = []
            vm.tmpDeletedThreat = []
            vm.likelyHoodList = []
            vm.severityList = []
            vm.performActionMode = ''
            vm.selectedRecordCount = 0
            vm.rmm_jra_doc_revision_no = null
            vm.updatingRecord = false
            vm.jra_pra_threat_list = []
            vm.blueLineSearch = ''
            vm.oraBlueLineAGData = []
            vm.praBlueLineAGData = []
            vm.currentJra_blueLine = []
            vm.userInApprovers = false
            vm.praList = []            
            vm.changesInForm = false
            vm.praSiteList = []
            vm.currentUserSigned = false
            vm.selectedDocumentNo = ''
            vm.canViewJRA = false
            vm.canManageJRA = true
            vm.autosave = null
            vm.autoSaveActive = false

            vm.jra_show_check_box = false
            vm.mod_id = 13   //module jra
            vm.currentAttachment = null

            vm.loadMessage = translateTag(3875)
            setTimeout(()=>{                
                vm.alara = [
                    {
                    id: 1,
                    label: translateTag(1379)
                    },
                    {
                    id: 0,
                    label: translateTag(1380)
                    }
                ]
            }, 500)

            vm.continueEditing = false
            vm.leaveEditing = false
            vm.idletime = 0
            vm.countdownSeconds = 60

            //Get permissions for the user
            menuService.getPagePermissions().then((data) => {
                vm.permissions = data
                vm.canViewJRA = vm.permissions.includes('Can View JRA') ? true : false
                vm.canManageJRA = vm.permissions.includes('Can Manage JRA') ? true : false
                vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false 
                vm.canManageActionItems = vm.permissions.includes('Can Manage Action Items') ? true : false
                vm.canCloseAllActions = vm.permissions.includes('Can Close All Actions') ? true : false

            })

            $scope.$on('DATERANGE', (range) => {
                vm.mainDateFilter = {
                    start_date: moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD'),
                    end_date: moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')
                }
                refreshData()
            })

            //Function to clear the form feilds
            vm.resetForm = () => {
                resetFormFieldClassList('jraForm')
                vm.jobListSelect = []
                vm.attachmentData = []
                vm.tmpDeletedStepCategories = []
                vm.tmpDeletedThreat = []
                vm.saved = false
                vm.submitted = false
                vm.rmm_jra_doc_revision_no = null
                vm.updatingRecord = false
                vm.oraBlueLineAGData = []
                vm.praBlueLineAGData = []
                vm.changesInForm = false
                vm.currentUserSigned = false
                
                vm.dlo_id = null
                vm.docLockMessage = ''
                vm.docLockStatus = false
                vm.countdownSeconds = 60
                vm.lockCheckModal = false
                vm.continueEditing = false
                vm.idletime = 0
                vm.leaveEditing = false
                vm.jra_show_check_box = false
                
                vm.currentJra =
                {
                    rmm_jra_id: null,
                    rmm_jra_document_number: null,
                    rmm_jra_doc_version_number: null,
                    rmm_jra_title: null,
                    rmm_jra_scope: null,
                    rmm_jra_expiry_date: null,
                    rmm_jra_site: null,
                    rmm_jra_job: null,
                    rmm_jra_workplace: null,
                    rmm_jra_pra: null,
                    rmm_jra_other_participants: null,
                    rmm_jra_state: null,
                    rmm_jra_date: dateToday.format("YYYY-MM-DD"),
                    rmm_jra_created_by_per_id: null,
                    participants: [],
                    approvers: [],
                    rmm_jra_is_submitted: false,
                    rmm_jra_revision_no:null,
                    step_categories: [newStepCategory()],
                    approversList:[],
                    rmm_jra_executive_summary: null,
                    rmm_jra_submitted_date: null,
                    applicable_line_items:[],
                    hazard_actions:[],
                    general_actions:[],

                }       
            }

            vm.getFilteredEmployees = () =>{            
                profileService.filterEmployeeListonJob(vm.currentJra.rmm_jra_job)
                vm.employeeList =  profileService.readFilterEmployeeListonJob()
                profileService.filterRmmApproverEmployeesOnJob(vm.currentJra.rmm_jra_job)
                vm.rmmApproversEmployee = profileService.readFilterApproversList()
            }

            // Function for a new step category object
            function newStepCategory() {
                return {
                    rmm_jsc_step: null,
                    rmm_jsc_id: null,
                    rmm_jsc_sort: 1,
                    rmm_jsc_enable: true,
                    threats: [newThreat()]
                }
            }

            // Function for a threat object
            function newThreat() {
                return {
                    rmm_jth_id: null,
                    rmm_jth_jsc: null,
                    rmm_jth_threat: null,
                    rmm_jth_outcome: null,
                    applicable_line_items: [],
                    rmm_jth_severity_category: null,
                    rmm_jth_likelyhood_preliminary: null,
                    rmm_jth_severity_preliminary: null,
                    rmm_jth_preliminary_risk: null,
                    rmm_jth_preliminary_risk_text: null,
                    rmm_jth_risk_alara_preliminary: null,
                    rmm_jth_likelyhood_residual: null,
                    rmm_jth_severity_residual: null,
                    rmm_jth_residual_risk: null,
                    rmm_jth_residual_risk_text: null,
                    rmm_jth_risk_alara_residual: null,
                    rmm_jth_created_by_per: null,
                    rmm_jth_modified_date: null,
                    rmm_jth_modified_by_per: null,
                    rmm_jth_enable: true,
                    rmm_jth_enote: null,
                    control_measures: [],
                    additional_control_measures:[]
                }
            }

            // Function for a tag object
            function newTag() {
                return {
                    rmm_jta_id: null,
                    rmm_jta_jth: null,
                    tag: null,
                    rmm_jta_tag_name:null,    
                    rmm_jta_blueline: false,
                    rmm_jta_enable: true
                }
            }

            //Function to add a new step category
            vm.addStepCategory = function () {
                let stepCatagories = vm.currentJra.step_categories
                let newCat = newStepCategory()
                newCat.rmm_jsc_sort = stepCatagories.length + 1
                vm.currentJra.step_categories.push(newCat)
                setTimeout(()=>{
                    vm.initializeTagsAndPulldowns()
                },100)
            }

            //Function to add a Threat category
            vm.addThreat = function (ec_index) {
                vm.currentJra.step_categories[ec_index].threats.push(newThreat())
                setTimeout(()=>{
                    vm.initializeTagsAndPulldowns()
                },100)
            }

            //Function to delete an step category
            vm.deleteStepCategory = function (rm_index) {
                let tmp_ec_obj = {}
                vm.currentJra.step_categories[rm_index].rmm_jsc_enable = false
                tmp_ec_obj = vm.currentJra.step_categories.splice(rm_index,1)[0]
                vm.currentJra.step_categories.forEach((val, index) => {
                   val.rmm_jsc_sort = index+1
                });
                vm.tmpDeletedStepCategories.push(tmp_ec_obj)
                if (vm.currentJra.step_categories.length === 0){
                    vm.addStepCategory()
                    return
                }
                vm.initializeSelect2('newJra')
            }

            //Function to delete an event
            vm.deleteEvent = function (rm_ev_index,rm_ec_index) {
                let tmp_ev_obj = {}
                vm.currentJra.step_categories[rm_ec_index].threats[rm_ev_index].rmm_jth_enable = false
                tmp_ev_obj = vm.currentJra.step_categories[rm_ec_index].threats.splice(rm_ev_index,1)[0]
                vm.tmpDeletedThreat.push(tmp_ev_obj)
                if (vm.currentJra.step_categories[rm_ec_index].threats.length === 0){
                    vm.addThreat(rm_ec_index)
                    return
                }
                vm.initializeSelect2('newJra')
            }

            // Function to Evaluate Preliminary Risk
            function evalRisk (severity,likelyhood) {
                let Extreme = ['31','41','51','42','52','53']
                let High = ['21','22','32','33','43','44','54','55']
                let Medium = ['11','12','23','34','45']
                let Low = ['13','14','15','24','25','35']
                let code = `${severity}${likelyhood}`
                let risk = null
                if (Extreme.find(o => o === code)){
                    risk = 3626
                }
                if (High.find(o => o === code)){
                    risk = 3622
                }
                if (Medium.find(o => o === code)){
                    risk = 3627
                }
                if (Low.find(o => o === code)){
                    risk = 3628
                }
                return risk
            }

            //Function to get Score for a given Ref ID
            function getScoreForRisk (ref_id,type) {
                let score = null
                switch(type){
                    case "likelyHood":
                        vm.likelyHoodList.forEach((val, index) => {
                            if (val.rld_id === ref_id){
                                score = val.rld_score
                            }
                        })
                        break;
                    case "severity":
                        vm.severityList.forEach((val, index) => {
                            if (val.rld_id === ref_id){
                                score = val.rld_score
                            }
                        })
                        break; 
                }
                return score
            }

            // Function to Evaluate Preliminary Risk
            vm.evalPrelimRisk = (ev_index, ec_index) => {                
                    let severity = parseInt(getScoreForRisk(vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_severity_preliminary,'severity'))
                    let likelyhood = parseInt(getScoreForRisk(vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_likelyhood_preliminary,'likelyHood'))
                    if (vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_risk_alara_preliminary !== 0){
                        vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_risk = evalRisk(severity,likelyhood)
                    }
                    
                    vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_preliminary_risk = evalRisk(severity,likelyhood)
                    vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_preliminary_risk_text = translateTag(evalRisk(severity,likelyhood))
            }

            // Function to Evaluate Residual Risk
            vm.evalResidualRisk = (ev_index, ec_index) => {
                let severity= parseInt(getScoreForRisk(vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_severity_residual,'severity'))
                let likelyhood = parseInt(getScoreForRisk(vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_likelyhood_residual,'likelyHood'))
                vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_risk = evalRisk(severity,likelyhood)
                vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_residual_risk = evalRisk(severity,likelyhood)
                vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_residual_risk_text = translateTag(vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_residual_risk)
            }

            // Function to change ALARA
            vm.changeALARA = (ev_index, ec_index) => {
                if (vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_risk_alara_preliminary === 0){
                    vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_risk =null
                    setTimeout(()=>{
                        vm.initializeTagsAndPulldowns()
                    },100)
                }
                else{
                    vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_severity_residual = null
                    vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_likelyhood_residual = null
                    vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_risk = vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_preliminary_risk
                    vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_residual_risk = null
                    vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_residual_risk_text = null
                    vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_risk_alara_residual = null
                    vm.currentJra.step_categories[ec_index].threats[ev_index].additional_control_measures=[]
                }

                if (vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_risk_alara_preliminary === undefined){
                    vm.currentJra.step_categories[ec_index].threats[ev_index].rmm_jth_risk_alara_preliminary = null
                }
            }

            $scope.fileUploadChanged = (event)=> {

                //Add newly selected files after checking for duplicates and correct file types
                vm.uploadFileList = vm.uploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, []))

                if(vm.uploadFileList.length > 0)
                    addAttachments()
            }

            //Function for the top search bar
            vm.topSearchChanged = () =>{
                vm.jraOptions.api.setQuickFilter(vm.topSearch)
            }

            //Function to open archive confirmation Modal
            vm.archiveConfirmationModal = () => {
                let archiveSelectedRecords = vm.jraOptions.api.getSelectedRows()
                vm.archiveCount = archiveSelectedRecords.length
                if (vm.archiveCount > 0) {
                    if(!vm.canArchiveSubmissions){
                        for (var i = 0; i < vm.archiveCount; i++) {
                            if(archiveSelectedRecords[i].rmm_jra_state!=="draft" || archiveSelectedRecords[i].rmm_jra_created_by_per_id!==vm.userId){
                                throwToastr('error',translateTag(1456),3000)
                                return
                            }
                        }
                    }
                }
                vm.modalElementsArchive = {
                    title: translateTag(3631), //"Archive JRA?"
                    message: `<div><p>${translateTag(3632)}</p></div>`, //"You are about to archive this job risk assessment. Undoing this will require IT support. Are you sure?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                } 
                document.getElementById('confirmcallingform').innerHTML = 'JRAARCHIVECALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsArchive)
            }

            $scope.$on("JRAARCHIVECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.jraArchive()
                }
                else if (result=='button2') {
                    vm.cancelModal('confirmModal')
                }
            })

            //Function to archive the selected rows
            vm.jraArchive = () => {
                var rows = vm.jraOptions.api.getSelectedRows()
                if (rows.length > 0) {
                    var ids = []
                    for (var i = 0; i < rows.length; i++) {
                        if (rows[i].dlo_status === 'Yes') {
                            ids.push(rows[i].rmm_jra_id)
                        }
                        else{
                            // You cannot Archive while Document is being edited
                            throwToastr('warning',translateTag(9116),2000)
                        }
                    }

                    jraService.archiveJra(ids).then((r) => {
                        refreshData()
                    })
                }
                modalService.Close('confirmModal')
            }

            //Function to open archive confirmation Modal
            vm.copyRevisionConfirmationModal= (mode='') => {
                vm.performActionMode = mode
                var rows = vm.jraOptions.api.getSelectedRows()
                vm.selectedRecordCount = rows.length
                if (vm.selectedRecordCount === 0){
                    throwToastr('warning', translateTag(3861),2500)
                    return
                }
                if (vm.selectedRecordCount > 1) {
                    throwToastr('warning',translateTag(3862),2500)
                    return
                }
                if (rows[0].rmm_jra_state === 'draft' && vm.performActionMode==='revision'){
                    throwToastr('error',translateTag(3865),3000)
                    return
                }

                if (vm.selectedRecordCount === 1){ 
                    vm.selectedDocumentNo = ''      
                    let dispTitle = ''
                    if(rows[0].rmm_jra_title){
                        dispTitle = ' - ' + rows[0].rmm_jra_title
                    }
                                 
                    if(rows[0].rmm_jra_revision_no !== ''){
                        vm.selectedDocumentNo = rows[0].rmm_jra_revision_no + dispTitle
                    }
                }

                let duplicateFlag = false
                if ((rows[0].rmm_jra_state === 'active' || rows[0].rmm_jra_state === 'expired') && vm.performActionMode==='revision'){
                    vm.jraAGData.forEach((val)=>{
                        if (duplicateFlag){
                            return
                        }
                      
                        if (val.rmm_jra_document_number === rows[0].rmm_jra_document_number){
                            if (val.rmm_jra_state === 'review' || val.rmm_jra_state === 'draft'){
                                vm.version_number = `${appendLeadingZeros(val.rmm_jra_document_number)}`+'.'+`${appendLeadingZeros(val.rmm_jra_doc_version_number,3)}`
                                vm.message = translateTag(4316)+" "+val.rmm_jra_state+" "+translateTag(3866)+" ("+ vm.version_number+"). "+translateTag(3867)+" "+val.rmm_jra_state+" "+translateTag(3868)                             
                                throwToastr('error', vm.message, 2500)
                                duplicateFlag = true
                            }
                        }
                        
                    })
                }
                if (!duplicateFlag){
                    vm.modalElementsCopy = {
                        title: capitalizeFirstLetter(vm.performActionMode), //
                        message: 
                        `<div>
                            <p ng-if=${vm.performActionMode==='copy'} note="You are about to make a copy of this Job Risk Assessment. Are you sure?">${translateTag(2256)} ${vm.selectedDocumentNo}. ${translateTag(2257)}</p>
                            <p ng-if=${vm.performActionMode==='revision'} note="You are about to make a revision of this Job Risk Assessment. Are you sure?">${translateTag(2258)} ${vm.selectedDocumentNo}. ${translateTag(2257)}</p>
                        </div>`,
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                    } 
                    document.getElementById('confirmcallingform').innerHTML = 'JRACOPYCALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsCopy)
                }                
            }

            $scope.$on("JRACOPYCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.jraCopyRevision()
                }
                else if (result=='button2') {
                    vm.cancelModal('confirmModal')
                }
            })

            //Function to copy or revision the selected rows
            vm.jraCopyRevision = () => {
                var rows = vm.jraOptions.api.getSelectedRows()
                if (rows.length > 0) {              
                    let payload = {}
                    payload.rmm_jra_id =  rows[0].rmm_jra_id
                    payload.mode = vm.performActionMode

                    jraService.copyRevisionJra(payload).then((r) => {
                        refreshData()
                    })
                }
                modalService.Close('confirmModal')
            }

            //Funtion to export the selected rows to CSV file
            vm.exportCSV = () => {                
                let rows = JSON.parse(JSON.stringify(vm.jraOptions.api.getSelectedRows()))
                exportCSV.export_csv(rows, translateTag(2253))
            }

            //Funtion to open a report in a new tab
            vm.viewReports = (e, id) =>{
                if(!e.ctrlKey){                    
                    lang_number = localStorage.getItem('lang_id')
                    vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.singleServeReportUrl}/${id}?lang=${lang_number}`)
                    $window.open(vm.reportURL, "_blank")
                }
            }

            //#region Funtions to convert ID to Name
            vm.getEmployeeName = (value) => {
                let name = value 
                vm.fullEmployeeList.forEach((emp)=>{
                    if(emp.per_id == value) {
                        name = emp.per_full_name
                    }
                })
                return name
              }

            function getEmployeeID(value) {
                let nameID = value
                vm.fullEmployeeList.forEach((emp)=>{
                if(emp.per_full_name == value) {
                    nameID = emp.per_id
                }
            })
            return nameID
            }

            function getHapActionTypeName(value) {
                let name = value
                vm.hapActionTypeList.forEach((at)=>{
                    if(at.rld_id == value) {
                    name = at.rld_name
                    }
                })
                return name
            }

            function getActionTypeName(value) {
                let name = value
                vm.actionTypeList.forEach((at)=>{
                if(at.rld_id == value) {
                name = at.rld_name
                }
            })
            return name
            }

            function getActionTypeID(value) {
                let nameID = value
                vm.actionTypeList.forEach((at)=>{
                if(at.rld_name == value) {
                nameID = at.rld_id
                }
            })
            return nameID
            }

            function getSiteName(value) {
                let name = value
                vm.site_name.forEach((s)=>{
                if(s.rld_id == value) {
                    name = s.rld_name
                }
                })
                return name
            }

            function getJobNumber(value) {
                let name = value
                vm.job_name.forEach((j)=>{
                if(j.rld_id == value) {
                    name = j.rld_code
                }
                })
                return name
            }
         

            vm.jraOptions = gridService.getCommonOptions()
            vm.jraOraBlueLineOptions = gridService.getCommonOptions()
            vm.jraPraBlueLineOptions = gridService.getCommonOptions()
            vm.attachmentOptions = gridService.getCommonOptions()

            //Function to disable action button if no rows are selected
            vm.jraOptions.onSelectionChanged = () => {
                var selectedRows = vm.jraOptions.api.getSelectedRows()
                vm.actionDisabled = selectedRows.length == 0
                $scope.$apply()
            }

            vm.attachmentOptions.onSelectionChanged = () => {
                var selectedRows = vm.attachmentOptions.api.getSelectedRows()
                vm.attActionDisabled = selectedRows.length == 0
                $scope.$apply()
            }

            vm.jraOraBlueLineOptions.onSelectionChanged = () => {
                var selectedRows = vm.jraOraBlueLineOptions.api.getSelectedRows()
                vm.oraBlueLineactionDisabled = selectedRows.length == 0
                $scope.$apply()
            }

            vm.jraPraBlueLineOptions.onSelectionChanged = () => {
                var selectedRows = vm.jraPraBlueLineOptions.api.getSelectedRows()
                vm.praBlueLineactionDisabled = selectedRows.length == 0
                $scope.$apply()
            }

            //Set Ag-Grid colum values/settings
            let jraColumns = [
                {
                    headerName: '',
                    field: 'dummyCheckbox',
                    maxWidth: 50,
                    minWidth: 50,
                    checkboxSelection: true,
                    suppressMenu: true,
                    suppressSorting: true,
                    headerCheckboxSelection: true,
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    field: "review",
                    headerName: " ",
                    minWidth: 125,
                    maxWidth: 125,
                    suppressMenu: true,
                    cellRenderer: (params) => {
                    return `<span ng-show="${params.data.rmm_jra_is_submitted === translateTag(1379)}" ng-click="jraCtrl.signoff(data)" class="{{ data.hasReviewed === '${translateTag(1379)}' ? 'text-success ' : 'pointer'}}" note="Review Submission" title={{menu.translateLabels(3431)}}><i class="far fa-file-alt fa-lg pr-1""></i></span>`
                        + `<span class="fa-1x fa-stack" style=" width: 1.25em;" ng-class="{ transparent: ${!vm.canManageJRA}, pointer: ${vm.canManageJRA}}"  ng-show="'${params.data.rmm_jra_state}'==='draft'" ng-click="jraCtrl.openViewer('edit', ${params.data.rmm_jra_id})"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title={{menu.translateLabels(1194)}}></i><i ng-show="${params.data.dlo_status === translateTag(1380)}" class="fas fa-ban fa-stack-1x text-danger" notes="Person is updating the document, please wait." title="${params.data.dlo_person} {{menu.translateLabels(3423)}}"></i></span>`
                        + `<span ng-class="{ transparent: ${!vm.canManageJRA}, pointer: ${vm.canManageJRA}}"  ng-show="'${params.data.rmm_jra_state}'==='review'" ng-click="jraCtrl.openViewer('view', ${params.data.rmm_jra_id})"><i class="fas fa-lock pr-2 text-primary" note="Review" title={{menu.translateLabels(1188)}}></i></span>`                        
                        + `<span  note="Review History" title={{menu.translateLabels(3951)}} class="source signoff-count" ng-class="{ transparent: (!data.reviewedCount > 0 || data.rmm_jra_is_submitted === '{{menu.translateLabels(1380)}}'), pointer: (data.reviewedCount > 0 && data.rmm_jra_is_submitted === '{{menu.translateLabels(1379)}}') }" ng-click="jraCtrl.viewAcknowledgeHistory(data);">{{ data.reviewedCount }}</span>`
                        + `<span class="pointer text-left" ng-click="jraCtrl.viewReports($event, ${params.data.rmm_jra_id})"><i class="fa fa-external-link-alt" note="Launch Report" title={{menu.translateLabels(3429)}}></i></span>`
                    },
                    valueGetter: function (params) {
                        return params.data.reviewedCount
                    },
                },
                {
                    field: '',
                    hide: true,
                    valueGetter: function (params) {
                        if (params.data.rmm_jra_state === 'draft')
                            return '1_Draft'
                        if (params.data.rmm_jra_state === 'review')
                            return '2_Review'
                        if (params.data.rmm_jra_state === 'active')
                            return '3_Active'
                        if (params.data.rmm_jra_state === 'expired')
                            return '4_Expired'
                    },
                    sort: 'asc',
                },
                {
                    field: "rmm_jra_created_date",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 140,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    sort: 'desc',
                },
                {
                    field: "rmm_jra_created_by_per",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 220,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_jra_expiry_date",
                    headerName: " ",
                    minWidth: 120,
                    maxWidth: 140,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        let expiryDate = new Date(params.data.rmm_jra_expiry_date)
                        let currentDate = new Date()
                        if (expiryDate < currentDate)
                            return '<div style="color: #D20000;">' + params.data.rmm_jra_expiry_date + '</div>'
                        else
                            return '<div>' + params.data.rmm_jra_expiry_date + '</div>'
                      }
                },
                {
                    field: "rmm_jra_title",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 1000,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_jra_site",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_jra_job",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_jra_revision_no",
                    headerName: " ",
                    minWidth: 120,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_jra_state",
                    headerName: " ",
                    maxWidth: 120,
                    minWidth: 120,
                    suppressMenu: false,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                    valueGetter: function (params) {
                        return translateStatus(params.data.rmm_jra_state)                        
                    },
                },              
                {field:"hasReviewed", hide:true},
                {field:"participantsList", hide:true},
                {field:"reviewersList", hide:true},
                {field:"reviewedCount", hide:true},
                {field:"rmm_jra_is_submitted", hide:true},
                {field:"rmm_jra_executive_summary", hide:true},
                {field:"rmm_jra_other_participants", hide:true},
                {field:"approversList", hide:true},
                {field:"rmm_jra_revision_no", hide:true},
                {field:"rmm_jra_pra", hide:true},
                {field:"rmm_jra_workplace", hide:true},
                {field:"rmm_jra_doc_version_number", hide:true},
                {field:"rmm_jra_document_number", hide:true},
                {field:"rmm_jra_id", hide:true},
                {field:"applicable_line_items", hide:true},
                {field:"rmm_jra_date", hide:true},
                {field:"rmm_jra_scope", hide:true},
            ]

            vm.jraOptions.columnDefs = jraColumns

            vm.jraOptions.defaultColDef = {
                cellStyle : (params) =>{
                    if(params.data.rmm_jra_state === 'active' || params.data.rmm_jra_state === 'expired' || params.data.rmm_jra_state === 'review'){
                        return { "cursor": "pointer !important"}
                    }
                } 
            }

            vm.jraOptions.onCellClicked  = (params) => {
                if(params.column.colDef.field !== 'review' && (params.data.rmm_jra_state === 'active' || params.data.rmm_jra_state === 'expired' || params.data.rmm_jra_state === 'review')){
                    vm.openViewer('view', params.data.rmm_jra_id)
                }
            }

            vm.viewOnlyCheck = () => {
                // For autosave so that the fields do not react to this function
                if(!vm.autoSaveActive) {
                    if(vm.currentJra.rmm_jra_state === 'active' || vm.currentJra.rmm_jra_state === 'expired' || vm.currentJra.rmm_jra_state === 'review' || vm.updatingRecord)
                        return true
                    return false
                }
            }


            //Set Blue Line Ag-Grid colum values/settings
            let blueLineColumns = [
                {
                    field: "event",
                    headerName: 'Applicable line item',
                    rowGroup: true,
                    hide:true,
                    filter: 'agSetColumnFilter',
                    tooltipField: 'event',
                    menuTabs: ['filterMenuTab'],
                },
                {
                    field: "tag",
                    headerName: "Tags",
                    cellStyle: { "white-space": "nowrap !important"},
                    wrapText: true,
                    autoHeight: true,
                    checkboxSelection: true,                    
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    tooltipField: 'tag',
                    
                }
            ]

            // Blue Line  - JRAORA
            vm.jraOraBlueLineOptions.columnDefs = blueLineColumns
            vm.jraOraBlueLineOptions.animateRows = true
            vm.jraOraBlueLineOptions.groupSelectsChildren =  true,
            vm.jraOraBlueLineOptions.autoGroupColumnDef = {
                cellRender : 'agGroupCellRenderer',
                headerName: 'Applicable line item', 
                cellStyle: { "white-space": "nowrap !important" },
                tooltipValueGetter: function (params) {
                    let count = params.node.allChildrenCount
                    if (count != null) {
                        return params.value + ' (' + count + ')'
                    }
                    return params.value
                }
            }
            vm.jraOraBlueLineOptions.rowSelection = 'multiple'
            vm.jraOraBlueLineOptions.groupSelectsChildren = true
            vm.jraOraBlueLineOptions.suppressRowClickSelection = true
            vm.jraOraBlueLineOptions.suppressAggFuncInHeader = true
            vm.jraOraBlueLineOptions.groupDefaultExpanded = -1

            // Blue Line  - JRAPRA
            vm.jraPraBlueLineOptions.columnDefs = blueLineColumns
            vm.jraPraBlueLineOptions.animateRows = true
            vm.jraPraBlueLineOptions.groupSelectsChildren =  true,
            vm.jraPraBlueLineOptions.autoGroupColumnDef = {
                cellRender : 'agGroupCellRenderer',
                headerName: 'Applicable line item', 
                cellStyle: { "white-space": "nowrap !important" },
                tooltipValueGetter: function (params) {
                    let count = params.node.allChildrenCount
                    if (count != null) {
                        return params.value + ' (' + count + ')'
                    }
                    return params.value
                }
            }
            vm.jraPraBlueLineOptions.rowSelection = 'multiple'
            vm.jraPraBlueLineOptions.groupSelectsChildren = true
            vm.jraPraBlueLineOptions.suppressRowClickSelection = true
            vm.jraPraBlueLineOptions.suppressAggFuncInHeader =  true
            vm.jraPraBlueLineOptions.groupDefaultExpanded = -1

            vm.signoff = (jraReviewData) => {
                vm.jraReviewDataContext = jraReviewData
                if(jraReviewData.hasReviewed === translateTag(1379)) {
                    throwToastr('info',translateTag(3869),2500)
                }
                else {
                    vm.modalElementsReview = {
                        title: translateTag(3633), //"Job Risk Assessment Review?"
                        message: `<div><p>${translateTag(3634)}</p></div>`, //"You are confirming that you have reviewed this assessment. This cannot be undone. Continue?"
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Review">{{vm.componentTranslateLabels(1188)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                    } 
                    document.getElementById('confirmcallingform').innerHTML = 'BTREVIEWCALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsReview)
                 }
            }

            $scope.$on("BTREVIEWCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.addAcknowledge()
                }
                else if (result=='button2') {
                    vm.cancelModal('confirmModal')
                }
            })

            let attachmentColumns = [
                {
                    headerName: '',
                    field: 'dummyCheckbox',
                    maxWidth: 50,
                    minWidth: 50,
                    checkboxSelection: (params) =>{
                        return params.data.rat_jra_show_check_box
                    }, 
                    suppressMenu: true,
                    suppressSorting: true,
                    headerCheckboxSelection: true,
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    //Added the id to the Ag-Grid and hid it. Used to sort the grid to show newest submissions first
                    field: 'rat_id',
                    hide: true,
                    sort: 'desc',
                },
                {
                    field: "rat_created_by_per",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',                    
                },
                {
                    field: "rat_created_date",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rat_file_name",
                    headerName: " ",
                    minWidth: 150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        return `<span class="pointer clip" ng-click='jraCtrl.openAttachment(${cleanDoubleCurly(JSON.stringify(params.value))})'><a class="source" href="#" ng-non-bindable>${params.value}</a></span>`
                    }              
                },   
                {
                    field:"comment",
                    headerName:"Comment",
                    minWidth:150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        if(params.data.com_id == null || params.data.com_comment=='' || params.data.com_comment==null){
                            return `<i class="far fa-comment pointer" note="Add Comment" title="{{menu.translateLabels(8921)}}" ng-click='jraCtrl.AddComments(${cleanDoubleCurly(JSON.stringify(params.data))})'></i>`
                        } else {
                            return `<i class="fa fa-comment pointer" note="Edit Comment" title="{{menu.translateLabels(9043)}}" ng-click='jraCtrl.AddComments(${cleanDoubleCurly(JSON.stringify(params.data))})'></i>`
                        }
                        
                    } 
                }      
            ]

            vm.attachmentOptions.columnDefs = attachmentColumns

            //Function to open a attachment file in a new tab
            vm.openAttachment = (name) => {
                vm.attachmentURL =  $sce.trustAsResourceUrl(`${__env.imageUrl}/${name}`)
                $window.open(vm.attachmentURL, "_blank")
            }

            vm.AddComments=(data) =>{
                document.getElementById('mode').innerText = data.com_id
                document.getElementById('comment').value = data.com_comment ? data.com_comment.replaceAll("'","&#39") : null 
                document.getElementById('callingform').innerHTML= 'JRACALLIMAGECOMMENTSMODAL'
                document.getElementById('savetomemory').innerHTML = "false"
                document.getElementById('parentform').innerHTML = vm.mod_id
                document.getElementById('imageid').innerText = data.rat_id  
                document.getElementById('viewOnly').innerText = vm.viewOnlyCheck()
                vm.currentAttachment=data.rat_id 
                document.getElementById('comment_id').innerHTML = data.com_id 
                $rootScope.$broadcast("RECIEVEROFCOMMENTS", data.com_comment ) 
            }

            $scope.$on('JRACALLIMAGECOMMENTSMODAL', (event, data) => {
                vm.refreshAttachmentsRowData(data)
            })

            vm.refreshAttachmentsRowData = (data) => {
                let rowData = []
                vm.attachmentOptions.api.forEachNode((node) => rowData.push(node.data))
                rowData.forEach((node) => {
                    if (node.rat_id == vm.currentAttachment) {
                        node.com_comment=data.com_comment
                        node.com_id=data.com_id
                    }
                }) 
                vm.attachmentOptions.api.setRowData(rowData)
            }

            //Function to refresh/get attachment data
            function refreshAttachments (id) {
                if(id)
                {
                    payload = {
                        rmm_id: id,
                        mod_id: vm.mod_id
                    }
                    rmmAttachmentsService.getRmmAttachments(payload).then((response) => {
                        vm.attachmentData = response
                    
                        if (vm.attachmentOptions.api) {
                            translateAgGridHeader (vm.attachmentOptions)
                            vm.attachmentOptions.paginationPageSize = 15
                            vm.attachmentOptions.api.setRowData(prepareAttachmentsGridData(vm.attachmentData))
                            vm.attachmentOptions.api.redrawRows()
                            vm.attachmentOptions.api.sizeColumnsToFit()
                        }
                    })
                }
                else if (vm.attachmentOptions.api) {
                    translateAgGridHeader (vm.attachmentOptions)
                    vm.attachmentOptions.paginationPageSize = 15
                    vm.attachmentOptions.api.setRowData([])
                    vm.attachmentOptions.api.redrawRows()
                    vm.attachmentOptions.api.sizeColumnsToFit()
                }
            }

            function prepareAttachmentsGridData(data) {
                let gridData = JSON.parse(JSON.stringify(data))
                gridData.forEach((rec) =>{
                    rec.exceptionFields = ['rat_enable','rat_rmm_id','rat_mod_id','com_id','rat_id','rat_jra_show_check_box']
                    rec.com_comment = rec.com_comment ? rec.com_comment.replaceAll("'","&#39") : null
                    rec.rat_created_by_per = vm.getEmployeeName(rec.rat_created_by_per)
                    rec.rat_modified_by_per = vm.getEmployeeName(rec.rat_modified_by_per)
                    rec.rat_created_date = moment(rec.rat_created_date).format('YYYY-MM-DD')
                    rec.rat_modified_date = rec.rat_modified_date? moment(rec.rat_modified_date).format('YYYY-MM-DD') : '' 
                    rec.rat_jra_show_check_box = vm.jra_show_check_box
                })
                return gridData
            }

            //Function to add attachments
            function addAttachments (att)            
            {
                if(vm.currentMode === "new") {
                    if (validateFormFields('jraForm', true)) {
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentJra)))
                        payload.rmm_jra_is_submitted = false

                        jraService.createJra(payload).then((response) => {
                            vm.currentJra.rmm_jra_id = response.rmm_jra_id
                            vm.openViewer('edit', vm.currentJra.rmm_jra_id)
                            resetFormFieldClassList('jraForm')
                            let fd = new FormData()
                            for (let i in vm.uploadFileList) {
                                fd.append("rmm_id", vm.currentJra.rmm_jra_id)
                                fd.append("mod_id", vm.mod_id)
                                fd.append("rmm_files", vm.uploadFileList[i])
                            }
                            rmmAttachmentsService.addRmmAttachments(fd).then((res) => {
                                refreshAttachments(vm.currentJra.rmm_jra_id)
                                vm.uploadFileList = []
                            })
                            refreshData()
                            vm.jra_show_check_box = true  
                            toastr.success(translateTag(4278)) //Saved Successfully                          
                        })
                    }
                    else{
                        $rootScope.$broadcast("CALLCONFIRMMODAL")
                    }
                }
                else {
                    let fd = new FormData()
                    for (let i in vm.uploadFileList) {
                        fd.append("rmm_id", vm.currentJra.rmm_jra_id)
                        fd.append("mod_id", vm.mod_id)
                        fd.append("rmm_files", vm.uploadFileList[i])
                    }
                    rmmAttachmentsService.addRmmAttachments(fd).then((res) => {
                        refreshAttachments(vm.currentJra.rmm_jra_id)
                        vm.uploadFileList = []
                    })
                }                
            }

            //Function to open delete confirmation Modal
            vm.deleteAttachmentConfirmationModal = () => {
                vm.deleteAttCount = vm.attachmentOptions.api.getSelectedRows().length
                vm.modalElementsDelete = {
                    title: translateTag(3416), //"Delete Attachment?"
                    message: `<div><p>${translateTag(3581)} ${vm.deleteAttCount} ${translateTag(3417)}</p></div>`, //"You are about to delete {{jraCtrl.deleteAttCount}} attachments. Undoing this will require IT support. Are you sure?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Yes">{{vm.componentTranslateLabels(1379)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                }
                document.getElementById('confirmcallingform').innerHTML = 'JRADELETEATTACHCALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsDelete)
            }

            $scope.$on("JRADELETEATTACHCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.deleteAttachment()
                }
            })

            //Function to delete the selected attachment rows
            vm.deleteAttachment = () => {
                var rows = vm.attachmentOptions.api.getSelectedRows()
                if (rows.length > 0) {
                var ids = []
                for (var i = 0; i < rows.length; i++) {
                    ids.push(rows[i].rat_id)
                }
                payload={rat_id: ids, mod_id: vm.mod_id}
                rmmAttachmentsService.removeRmmAttachments(payload).then((r) => {
                    refreshAttachments(vm.currentJra.rmm_jra_id)
                })
                }    
                modalService.Close('confirmModal')
            }

            //Function to add/remove an acknowledgment to a assessment via the Ag-Grid
            vm.addAcknowledge = () => {
                let payload = {}
                payload.rmm_jra_id = vm.jraReviewDataContext.rmm_jra_id
                vm.currentAcknowledge = vm.jraReviewDataContext
                    jraService.reviewJra(payload).then (() => {
                        refreshData()
                        modalService.Close('confirmModal')
                    })
            }

            //Function to open the Acknowledge History modal
            vm.viewAcknowledgeHistory = (jraData) => {
                if(!jraData.reviewedCount > 0 || !jraData.rmm_jra_is_submitted)
                    return

                vm.currentAcknowledgeHistory = []
                jraData.reviewers.forEach((rev) => {
                    let acknowledgment = {
                        name: vm.getEmployeeName(rev.rmm_jre_per_id),
                        pos: rev.rmm_jre_position_name,
                        reviewed_date: rev.rmm_jre_created_date
                    }
                    vm.currentAcknowledgeHistory.push(acknowledgment)
                })
                $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentAcknowledgeHistory,translateLabels(1297)) //"Reviews"
            }

            //Function to check if the current user has review the jra assessment
            function checkAcknowledged (jraData) {
                let response = false
                jraData.reviewers.forEach((rev) => {
                        if(rev.rmm_jre_per_id == vm.userId){
                            response = true
                        }
                    })
                    return response
            }

            //Function used to close modals
            vm.cancelModal = (modalId) => {
                modalService.Close(modalId)
                vm.initializeSelect2('newJra')
            }

            //Function to Push Tags to CM and close Modal
            function pushTagstoCMAndCloseModal (unique_tags,ec_index,th_index) {                
                angular.copy(vm.currentJra, vm.currentJra_blueLine)
                unique_tags.forEach((tag)=>{
                    blueLineCMObj = newTag()
                    blueLineCMObj.tag = tag
                    blueLineCMObj.rmm_jta_blueline = true
                    vm.currentJra_blueLine.step_categories[ec_index].threats[th_index].control_measures.push(blueLineCMObj)
                })
                vm.cancelModal('blueLineControlsModal')
                vm.currentJra = Object.assign({}, vm.currentJra_blueLine); 
                return true
            }

            // Function to add tags to control measures
            vm.addTagsToCM = (ec_index,th_index) =>{
                var oraRows = vm.jraOraBlueLineOptions.api.getSelectedRows()
                var praRows = vm.jraPraBlueLineOptions.api.getSelectedRows()
                var rows = oraRows.concat(praRows)
                if (rows.length > 0) {
                    let unique_tags = []
                    let dupeFlag = false
                    rows.forEach(row => {
                        if (unique_tags.find(tag => tag === row.tag)){
                            dupeFlag = true
                        }
                        if (!dupeFlag){
                            unique_tags.push(row.tag)
                        }else{
                            dupeFlag = false
                        }
                    });
                    $q.all([
                        pushTagstoCMAndCloseModal(unique_tags,ec_index,th_index),
                        setbackAccordian()
                    ]).then(()=>{
                        setTimeout(()=>{
                            vm.initializeTags()
                             setTimeout(() => {
                                vm.initializeBlueline()
                            }, 1000);
                            vm.changesInForm = true
                        },1000)
                    })
                }else{
                    vm.cancelModal('blueLineControlsModal')
                }
            }

            //Function to load Blueline AGGrid Options
            vm.loadAGgridOptions = (oraAGgridData,praAGgridData) => {
                if (vm.jraOraBlueLineOptions.api) {
                    translateAgGridHeader(vm.jraOraBlueLineOptions)
                    vm.jraOraBlueLineOptions.paginationPageSize = 10
                    vm.jraOraBlueLineOptions.api.setRowData(oraAGgridData)
                    vm.jraOraBlueLineOptions.api.redrawRows()
                    vm.jraOraBlueLineOptions.api.sizeColumnsToFit()
                }
                vm.oraBlueLineactionDisabled = true

                if (vm.jraPraBlueLineOptions.api) {
                    translateAgGridHeader(vm.jraPraBlueLineOptions)
                    vm.jraPraBlueLineOptions.paginationPageSize = 10
                    vm.jraPraBlueLineOptions.api.setRowData(praAGgridData)
                    vm.jraPraBlueLineOptions.api.redrawRows()
                    vm.jraPraBlueLineOptions.api.sizeColumnsToFit()
                }
                vm.praBlueLineactionDisabled = true
            }

            //Function for the Blue Line search bar
            vm.blueLineSearchChanged = () =>{
                vm.jraOraBlueLineOptions.api.setQuickFilter(vm.blueLineSearch)
                vm.jraPraBlueLineOptions.api.setQuickFilter(vm.blueLineSearch)
            }

            //function to get Bluelines
            vm.getJraBluelines = (pth_ids, pra_id) => {
                var payload = {rmm_pec_id:pth_ids,rmm_pra_id:pra_id}
                if (pth_ids!==null && pth_ids !== undefined){
                    jraService.getBluelinesList(payload).then((response) => {
                        vm.jra_bluelines = JSON.parse(JSON.stringify(response))
                        vm.oraBlueLineAGData = vm.jra_bluelines.rmm_ora_bluelines
                        vm.praBlueLineAGData = vm.jra_bluelines.rmm_pra_bluelines
                    })
                }else{
                    vm.pra_bluelines = []
                    vm.currentJra.applicable_line_items = []
                }
            }

            //function to get PRA ORA Titles
            vm.getJraPraTitles = () => {
                jraService.getJraPraList().then((response) => {
                    vm.praList = JSON.parse(JSON.stringify(response))
                })
                vm.initializeSelect2("newJra")
            }

            //function to get JRA PRA threat List
            vm.getJraPraThreatList = (id) => {
                if (id!==null && id !== undefined){
                    jraService.getJraPraThreatList(id).then((response) => {
                        vm.jra_pra_threat_list = JSON.parse(JSON.stringify(response))
                    })
                }else{
                    vm.jra_pra_threat_list = []                   
                    vm.currentJra.applicable_line_items = []
                }
                setTimeout(() => {
                    vm.initializeBlueline()                    
                }, 1000);
            }

            //Function to open the viewer
            vm.openViewer = (mode='new', id) => {
                if(!vm.canManageJRA)
                    return

                // Start the autosave
                if(mode !== 'view') {
                    vm.autosave = $interval(() => {                        
                        vm.saveJra('autosave')
                        }, 60000)
                }
                vm.getJraPraTitles()  
                if(mode === 'new') {
                    vm.currentMode = 'new'
                    vm.initializeTagsAndPulldowns()
                    destroyTables().then(()=>{
                        initiateTables()
                    })
                    vm.userInApprovers = true
                    vm.hideingJraViewer = false
                    vm.jraViewerOpen = true
                    vm.openingJraViewer = true
                    $timeout(() => {
                        vm.openingJraViewer = false
                        $('#newJra').data('serialize',$('#newJra').serialize())
                    }, 400)
                    refreshAttachments()
                }
                else if(mode === 'edit') {
                    vm.documentDetails = {}
                    vm.documentDetails.dlo_document_id = id
                    vm.documentDetails.dlo_dlt_id = 2
                    $q.all([
                        documentLockService.docLock(vm.documentDetails)
                    ]).then((response) => {
                        vm.dlo_id = response[0].dlo_id
                        vm.docLockStatus = response[0].status
                        vm.docLockMessage = response[0].message
                        vm.docLockTime = response[0].time
                        if (!vm.docLockStatus){
                            throwToastr('warning',vm.docLockMessage,2000)
                        }   
                    }).then(() => {
                            if(vm.docLockStatus === true){
                                vm.currentMode = 'edit'
                                vm.saved = true       
                                toastr.options.progressBar = true    
                                $scope.$emit('STARTSPINNER', translateTag(3870))         
                                vm.getSingleDetailRec(id).then(() => {
                                    vm.initializeTagsAndPulldowns()
                                    vm.validateCurrentUserInApprovers()
                                    vm.hideingJraViewer = false
                                    vm.jraViewerOpen = true
                                    vm.openingJraViewer = true
                            //        refreshActions(vm.currentJra.rmm_jra_id)
                                    if(!vm.currentJra.rmm_jra_is_submitted){
                                        vm.jra_show_check_box = true
                                    }
                                    refreshAttachments(vm.currentJra.rmm_jra_id)
                                    $timeout(() => {
                                        vm.openingJraViewer = false
                                        $('#newJra').data('serialize',$('#newJra').serialize())
                                        $scope.$emit('STOPSPINNER')
                                    }, 400)
                                })

                            startUpdateDocLock()
                            startLockModal()
                        }
                    })
                    
                }
                else if(mode === 'view') {
                    $scope.$emit('STARTSPINNER', translateTag(3870))
                    vm.getSingleDetailRec(id).then(() => {
                        vm.initializeTagsAndPulldowns()
                        vm.validateCurrentUserInApprovers()
                        vm.hideingJraViewer = false
                        vm.jraViewerOpen = true
                        vm.openingJraViewer = true
                        refreshAttachments(vm.currentJra.rmm_jra_id)
                        $timeout(() => {
                            vm.openingJraViewer = false
                            $('#newJra').data('serialize',$('#newJra').serialize())
                            $scope.$emit('STOPSPINNER')
                        }, 400)
                    })
                }
            }

            // functions for document lock start___

            //Zero the idle timer on mouse movement.
            $('#newJra').mousemove(function (e) {
                clearInterval(vm.lockModal)                
                vm.idletime = 0
                startLockModal()
            })

            //Zero the idle timer on keypres event
            $('#newJra').keypress(function (e) {
                clearInterval(vm.lockModal)
                vm.idletime = 0
                startLockModal()
            })

            vm.continueEditingJra = () => {
                vm.cancelModal('confirmModal')
                vm.countdownSeconds = 60
                vm.lockCheckModal = false
                vm.continueEditing = true
                document.getElementById('inactiveTime').textContent = ''
                clearInterval(vm.lockModal)
                clearInterval(vm.countdownTimer)
                clearTimeout(vm.relieveLock)
                vm.idletime = 0
                startLockModal()

            }
           
            function startUpdateDocLock(){
                vm.updateDocLockInterval = setInterval(() => {
                    $q.all([
                        documentLockService.intervalDocLock(vm.dlo_id)
                    ])
                }, 30 * 1000)
            }

            function startLockModal(){
                vm.lockModal = setInterval(() => {
                    vm.idletime = vm.idletime + 1 // 1 minute
                    if(vm.idletime === 5){ // after 5 minutes of idle time open lockcheck modal
                        vm.continueEditing = false
                        vm.leaveEditing = false
                        vm.modalElementsLock = {
                            title: translateTag(3419),   //"Page inactive for 5 minutes" 
                            message: `<div style="text-align: center;"><h1 id ="inactiveTime" ></h1><p> ${translateTag(3420)}</p></div>`,  //"The entry will automatically save and close if no action is taken"
                            buttons: 
                                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Continue Working">{{vm.componentTranslateLabels(3421)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Save and Close">{{vm.componentTranslateLabels(3422)}}</button>`
                        }
                        document.getElementById('confirmcallingform').innerHTML = 'JRALOCKCALLCONFIRMMODAL' 
                        $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsLock)
                        vm.lockCheckModal = true
                        startcountdownTimer()
                        vm.relieveLock = setTimeout(() => {
                            if (vm.lockCheckModal === true){
                                if (!vm.continueEditing && !vm.leaveEditing){
                                    vm.leaveEditing = true
                                    vm.saveAndCloseJra()
                                }
                            }
                        }, 60 * 1000);
                    }                                        
                }, 60 * 1000);
            }

            $scope.$on("JRALOCKCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.continueEditingJra()
                }
                else if (result=='button2') {
                    vm.saveAndCloseJra()
                }
            })

            function startcountdownTimer(){
                vm.countdownTimer = setInterval(() => {
                    if(vm.lockCheckModal === true && vm.countdownSeconds>=0){
                        vm.content = ''
                        if (vm.countdownSeconds === 60){
                            vm.content = "01:00"
                        }
                        else{
                            vm.content = "00:" + vm.countdownSeconds.toLocaleString('en-US', {
                                minimumIntegerDigits: 2,
                                useGrouping: false
                              }) 
                        }
                        document.getElementById('inactiveTime').textContent =  vm.content
                        vm.countdownSeconds = vm.countdownSeconds - 1   
                    }                                           
                }, 1000)
            }

            // functions for document lock end___

            // Function to validate approvers for sign
            vm.validateCurrentUserInApprovers = () => {
                vm.userInApprovers = false
                if (vm.currentJra.approvers) {
                    if (vm.currentJra.approvers.length > 0){
                        vm.currentJra.approvers.forEach((app) => {
                            if (app === vm.userId){
                                vm.userInApprovers = true
                                return
                            }
                        })
                    }
                }
            }

            // An abstrect function to initialize the dropdowns and tags
            vm.initializeTagsAndPulldowns = () =>{
                    vm.initializeSelect2('newJra')
                    vm.initializeTags() 
                    setTimeout(() => {
                        vm.initializeBlueline()
                    }, 1000); 
            }

            // function to get single detail record
            vm.getSingleDetailRec = (id) =>{
                vm.tmpDeletedStepCategories = []
                vm.tmpDeletedThreat = []
                return (
                    $q.all([
                        jraService.getJraSIngleDetailRec(id).then((response) => {
                            vm.currentJra = []
                            vm.currentJra = JSON.parse(JSON.stringify(response))
                            vm.prepResponseSingleDetail()
                        }),
                    ])
                )
            }

            // An abstrect function to prepare response payload for single detail record
            vm.prepResponseSingleDetail = () =>{     
                vm.currentJra.approversList = []           
                angular.copy(vm.currentJra.approvers,vm.currentJra.approversList)
                vm.currentJra.approvers = getApprovers(vm.currentJra.approvers)
                vm.currentJra.rmm_jra_created_date = moment(vm.currentJra.rmm_jra_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                vm.currentJra.rmm_jra_date = vm.currentJra.rmm_jra_date===null?null:moment(vm.currentJra.rmm_jra_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                vm.currentJra.rmm_jra_expiry_date = vm.currentJra.rmm_jra_expiry_date===null?null:moment(vm.currentJra.rmm_jra_expiry_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                if(vm.currentJra.rmm_jra_job){
                    vm.getFilteredEmployees()
                }

                // load PRAs from the selected site
                vm.getJraPraTitles()
                vm.getJobsBySite(vm.currentJra.rmm_jra_site)
                vm.getJraPraThreatList(vm.currentJra.rmm_jra_pra)

                if (vm.currentJra.applicable_line_items !== [] || vm.currentJra.applicable_line_items.length > 0){
                    vm.getJraBluelines(vm.currentJra.applicable_line_items, vm.currentJra.rmm_jra_pra)
                }
                vm.currentJra.step_categories.forEach((ec)=>{
                    ec.threats.forEach((ev)=>{

                        ev.rmm_jth_residual_risk_text = translateTag(ev.rmm_jth_residual_risk)
                        ev.rmm_jth_preliminary_risk_text = translateTag(ev.rmm_jth_preliminary_risk)

                        if (ev.rmm_jth_risk_alara_preliminary!==null) {
                            ev.rmm_jth_risk_alara_preliminary = ev.rmm_jth_risk_alara_preliminary === true ? 1 : 0
                        }
                        if (ev.rmm_jth_risk_alara_residual!==null) {
                            ev.rmm_jth_risk_alara_residual = ev.rmm_jth_risk_alara_residual === true ? 1 : 0
                        }
                        ev.rmm_jth_risk = ev.rmm_jth_risk_alara_preliminary === 0 ? ev.rmm_jth_residual_risk : ev.rmm_jth_preliminary_risk
                    })
                })
                vm.rmm_jra_doc_revision_no = `${appendLeadingZeros(vm.currentJra.rmm_jra_document_number)}`+'.'+`${appendLeadingZeros(vm.currentJra.rmm_jra_doc_version_number,3)}`
                vm.uneditedCurrentJra = []
                angular.copy(vm.currentJra, vm.uneditedCurrentJra);
                setTimeout(() => {
                    vm.initializeBlueline()                    
                }, 1000);
                refreshActions(vm.currentJra.rmm_jra_id)
            }

            //Function to refresh the action data
            function refreshActions (id) {
                payload = {
                    rmm_jra_id: id
                }
                $q.all([
                    jraService.getGaHaActions(payload).then((response) => {
                        vm.currentJra.general_actions = actionManagementService.addCanCloseActionPermission(response.general_actions, 'general', vm.canCloseAllActions, vm.userId)
                        vm.currentJra.hazard_actions = actionManagementService.addCanCloseActionPermission(response.hazard_actions, 'hazard', vm.canCloseAllActions, vm.userId)
                        
                        vm.immediateActions(id)
                    })
                ]).then(()=>{
                    destroyTables().then(()=>{
                        initiateTables()
                    })
                })
            }

            vm.immediateActions = () =>{
                vm.currentJra.hazard_actions.forEach((data)=>{
                    if(!data.further_action_required && data.immediate_action_required_and_performed) {
                        data.action_complete_by_who = data.created_by
                        data.recommended_action = data.immediate_action_taken
                        data.action_by_when = moment(data.sha_created_date).format('YYYY-MM-DD')
                    }
                })
            }

            //Function to force close the viewer
            vm.forceCloseViewer = () => {
                vm.cancelModal('confirmModal')                           
                vm.cancelModal('signJraSuccessModal')
                vm.cancelModal('signJraFailureModal')
                vm.employeeList = []
                vm.releaseDocument(vm.dlo_id).then((response) => {
                })
                clearInterval(vm.updateDocLockInterval)
                clearInterval(vm.lockModal)
                clearInterval(vm.countdownTimer)
                // Stop the autosave
                $interval.cancel(vm.autosave)
                vm.hideingJraViewer = true
                vm.resetForm()
                refreshData()
                $timeout(() => {
                    vm.jraViewerOpen = false
                }, 400)
            }
            
            //Function to close the viewer
            vm.closeViewer = () => {
                hasFormChanged()
                if (!vm.currentUserSigned){
                    if (vm.changesInForm && !vm.openingOraViewer == true){
                        vm.modalElementsChange = {
                            title: translateTag(2273), //"Confirm Changes"
                            message: `<div><p>${translateTag(2274)}</p></div>`, //"Any unsaved changes made on this document would be lost! Do you want to proceed ?"
                            buttons: 
                                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="SAVE & CLOSE">{{vm.componentTranslateLabels(2276)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note= "CLOSE ANYWAY">{{vm.componentTranslateLabels(2275)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button3')" note= "Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                        } 
                        document.getElementById('confirmcallingform').innerHTML = 'BTCHANGECALLCONFIRMMODAL' 
                        $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsChange)
                        return
                    }
                }
                vm.releaseDocument(vm.dlo_id).then((response) => {
                })
                clearInterval(vm.updateDocLockInterval)
                clearInterval(vm.lockModal)
                           
                vm.cancelModal('signJraSuccessModal')
                vm.cancelModal('signJraFailureModal')
                // Stop the autosave
                $interval.cancel(vm.autosave)
                clearInterval(vm.countdownTimer)
                vm.hideingJraViewer = true
                vm.resetForm()
                refreshData()
                $timeout(() => {
                    vm.jraViewerOpen = false
                }, 400)
            }

            $scope.$on("BTCHANGECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.saveAndCloseJra()
                }
                else if (result=='button2') {
                    vm.forceCloseViewer()
                }
                else if (result=='button3') {
                    vm.cancelModal('confirmModal')
                }
            })

             //Function to save and close the JRA
             vm.saveAndCloseJra = () => {
                vm.cancelModal('confirmModal')
                vm.saveJra()
                setTimeout(()=>{
                    vm.forceCloseViewer()
                },4700)  
            }

            vm.releaseDocument = (id) => {
                payload = {}
                payload.dlo_id = id
                return (
                    $q.all([
                        documentLockService.closeDocLock(payload)
                    ])
                )
            }

            // function to reset toastr options
            function resetToastrOptions() {
                toastr.options.progressBar = false,
                toastr.options.positionClass = 'toast-top-right'
                toastr.options.timeOut= "5000"
            }

            //function to throw toastr with time interval
            function throwToastr(type,message,time){
                toastr.options.timeOut = time
                toastr.options.positionClass = 'rmm-toast-custom'
                switch (type) {
                    case 'success':
                        toastr.success(message)
                        break;
                    case 'warning':
                        toastr.warning(message)
                        break;
                    case 'error':
                        toastr.error(message)
                        break;
                    case 'info':
                        toastr.info(message)
                        break;
                }
                resetToastrOptions()
            }

            //Function to open modals
            vm.openModal = (modalId) => {
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()

                $('.modal .scroll').scrollTop(0)
                modalService.Open(modalId)
                vm.initializeSelect2(modalId, '.modal-body')
            }

            // Function to open Blue line control modal
            vm.openBlueLineControlModal = (th_index,ec_index) => {
                if (vm.currentJra.applicable_line_items === [] || vm.currentJra.applicable_line_items === undefined || vm.currentJra.applicable_line_items === null) {
                    throwToastr('error',translateTag(3855),2000)
                    return
                }
                if (vm.currentJra.applicable_line_items.length === 0){
                    throwToastr('error',translateTag(3855),2000)
                    return
                }
                var payload = {rmm_pec_id:vm.currentJra.applicable_line_items,rmm_pra_id:vm.currentJra.rmm_jra_pra}
                jraService.getBluelinesList(payload).then((response) => {
                    vm.jra_bluelines = JSON.parse(JSON.stringify(response))
                    vm.oraBlueLineAGData = vm.jra_bluelines.rmm_ora_bluelines
                    vm.praBlueLineAGData = vm.jra_bluelines.rmm_pra_bluelines
                    setTimeout(() => {
                        getShowAccordianIds()
                    }, 500);
                    vm.blueLine_ec_index = ec_index
                    vm.blueLine_th_index = th_index
                    vm.current_ora_blueline = []
                    vm.current_pra_blueline = []
                    angular.copy(vm.oraBlueLineAGData,vm.current_ora_blueline)
                    angular.copy(vm.praBlueLineAGData,vm.current_pra_blueline)
                    vm.currentJra.step_categories[ec_index].threats[th_index].control_measures.forEach((cm)=>{
                        
                        let new_ora_blueLine = []
                        for (let i = 0; i < vm.current_ora_blueline.length; i++) {
                            if(cm.tag.trim().toLowerCase() !== vm.current_ora_blueline[i].tag.trim().toLowerCase() ){
                                new_ora_blueLine.push(vm.current_ora_blueline[i]) 
                            }
                        }
                        vm.current_ora_blueline = new_ora_blueLine
    
                        let new_pra_blueLine = []
                        for (let i = 0; i < vm.current_pra_blueline.length; i++) {
                            if(cm.tag.trim().toLowerCase()  !== vm.current_pra_blueline[i].tag.trim().toLowerCase() ){
                                new_pra_blueLine.push(vm.current_pra_blueline[i]) 
                            }
                        }
                        vm.current_pra_blueline = new_pra_blueLine
                    })
                    vm.loadAGgridOptions(vm.current_ora_blueline,vm.current_pra_blueline)
                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()
                    $('.modal .scroll').scrollTop(0)
                    modalService.Open("blueLineControlsModal")
                    vm.initializeSelect2("blueLineControlsModal", '.modal-body')
                })
            }

            vm.openActionModal = (modalId) => {
                resetFormFieldClassList('jraForm')
                if (validateFormFields('jraForm', true)){
                    vm.actionMode = 'new'
                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()
                    $('.modal .scroll').scrollTop(0)
                
                    if(vm.currentMode === "new") {                                                      // Save the Document before opening an action modal
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentJra)))
                        payload.rmm_jra_is_submitted = false
                        vm.updatingRecord = true
                        toastr.options.progressBar = true
                        throwToastr('info',translateTag(3856)+"...",5000)
                        jraService.createJra(payload).then((response) => {
                            if (response.rmm_jra_id){
                                vm.getSingleDetailRec(response.rmm_jra_id).then(() => {
                                    $q.all([
                                        vm.initializeTagsAndPulldowns()
                                    ]).then((data) => {
                                        vm.rmm_jra_doc_revision_no = `${appendLeadingZeros(vm.currentJra.rmm_jra_document_number)}`+'.'+`${appendLeadingZeros(vm.currentJra.rmm_jra_doc_version_number,3)}`
                                        vm.validateCurrentUserInApprovers()
                                        $('#newJra').data('serialize',$('#newJra').serialize())
                                        resetFormFieldClassList('jraForm')
                                        modalService.Open(modalId)
                                        vm.initializeSelect2(modalId, '.modal-body')
                                    })
                                })
                                refreshData()
                            }
                            if (!response){
                                throwToastr("error",translateTag(3857), 2000)
                            }
                            vm.updatingRecord = false
                        })
                        
                    }
                    else{
                        modalService.Open(modalId)
                        vm.initializeSelect2(modalId, '.modal-body')
                    }
                }else{
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            //Function to open the edit action modals
            vm.openActionEditModal = (modalId, id) => {
                vm.actionMode = 'edit'
                if(modalId === 'generalActionModal') {
                    openGeneralEdit(id, modalId)
                    refreshActions(vm.currentJra.rmm_jra_id)
                }
                else if(modalId === 'hazardActionModal') {
                    openHazardEdit(id, modalId)
                    refreshActions(vm.currentJra.rmm_jra_id)
                }
            }

            //Function to prepare data to edit a general action
            function openGeneralEdit(id, modalId) {
                actionManagementService.getGeneralActionSingle({sga_id: id}).then ((response) => {
                    vm.generalEditData = response

                    vm.generalEditData.Site = parseInt(vm.generalEditData.Site)
                    vm.generalEditData.JobNumber = parseInt(vm.generalEditData.JobNumber)
                    vm.generalEditData.SiteLevel = parseInt(vm.generalEditData.SiteLevel)
                    vm.generalEditData.Supervisor = parseInt(vm.generalEditData.Supervisor)

                    vm.generalEditData.HeaderDate = moment(vm.generalEditData.HeaderDate).format('YYYY-MM-DD')
                    vm.generalEditData.sga_action_by_who_per_id = vm.generalEditData.sga_action_by_who_per

                    let i = 0
                    let initialAtt = JSON.parse(JSON.stringify(vm.generalEditData.attachments))
                    initialAtt.forEach((att) => {
                        if(att.gaa_type === 'FOLLOWUP')
                            vm.generalEditData.attachments.splice(i, 1)
                        else
                            i++
                    })
                    
                    vm.generalEditData.attachments.forEach((att) => {
                        att.imageDir = `${__env.imageUrl}/`
                    })

                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()

                    $('.modal .scroll').scrollTop(0)

                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId, '.modal-body')
                })
            }

            //Function to prepare data to edit a hazard action
            function openHazardEdit(id, modalId) {
                actionManagementService.getHazardActionSingle({hap_id: id}).then ((response) => {
                    vm.hazardEditData = response

                    vm.hazardEditData.Site = parseInt(vm.hazardEditData.Site)
                    vm.hazardEditData.JobNumber = parseInt(vm.hazardEditData.JobNumber)
                    vm.hazardEditData.SiteLevel = parseInt(vm.hazardEditData.SiteLevel)
                    vm.hazardEditData.Supervisor = parseInt(vm.hazardEditData.Supervisor)

                    vm.hazardEditData.HeaderDate = moment(vm.hazardEditData.HeaderDate).format('YYYY-MM-DD')

                    let i = 0
                    let initialAtt = JSON.parse(JSON.stringify(vm.hazardEditData.attachments))
                    initialAtt.forEach((att) => {
                        if(att.attachmenttype === 'FOLLOWUP')
                            vm.hazardEditData.attachments.splice(i, 1)
                        else
                            i++
                    })
                    
                    vm.hazardEditData.attachments.forEach((att) => {
                        att.imageDir = `${__env.imageUrl}/`
                    })

                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()

                    $('.modal .scroll').scrollTop(0)

                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId, '.modal-body')
                })
            }

            //Function to open the complete action modals
            vm.completeActionModal = (action, type) => {
                if(type === 'General')
                {
                    actionManagementService.getGeneralActionSingle({sga_id: action.sga_id}).then ((response) => {
                        vm.generalFollowup = response
                        vm.generalFollowup.sga_completed_action_date = dateToday.format('YYYY-MM-DD')
                        vm.generalFollowup.sga_action_by_who_per_id = vm.getEmployeeName(vm.generalFollowup.sga_action_by_who_per)
                        if(vm.generalFollowup.sga_completed_action_by_who_per != null)
                            vm.generalFollowup.sga_completed_action_by_who_per_id = parseInt(getEmployeeID(vm.generalFollowup.sga_completed_action_by_who_per))
                        vm.generalFollowup.attachment_files_initial = []
                        vm.generalFollowup.attachment_files_followup = []

                        vm.generalFollowup.attachments.forEach((attRec) => {
                            if(attRec.gaa_type == 'INITIAL')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                vm.generalFollowup.attachment_files_initial.push(attRec)
                            }
                            else if(attRec.gaa_type == 'FOLLOWUP')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                vm.generalFollowup.attachment_files_followup.push(attRec)
                            }
                        })

                        vm.openModal('completeGeneralActionModal')
                        setTimeout(()=>{
                            $scope.$broadcast('GENERAL_FOLLOWUP_OPENED')
                        },100) 
                    })
                }
                else
                {
                    actionManagementService.getHazardActionSingle({hap_id: action.id}).then ((response) => {
                        vm.followup = response
                        vm.followup.action_completed_date = dateToday.format('YYYY-MM-DD')
                        vm.followup.action_complete_by_who = (vm.followup.action_complete_by_who && vm.followup.action_complete_by_who != 'None') ? parseInt(getEmployeeID(vm.followup.action_complete_by_who)) : null
                        vm.followup.attachmentModalFiles = []
                        vm.followup.followupAttachmentModalFiles = []

                        vm.followup.attachments.forEach((attRec) => {
                            if(attRec.attachmenttype === 'INITIAL')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                attRec.AttachmentFileName = attRec.attachmentfilename
                                vm.followup.attachmentModalFiles.push(attRec)
                            }
                            else if(attRec.attachmenttype === 'FOLLOWUP')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                attRec.AttachmentFileName = attRec.attachmentfilename
                                vm.followup.followupAttachmentModalFiles.push(attRec)
                            }
                        })

                        vm.followup.HapId = action.id
                        vm.followup.action_by_who_name = vm.getEmployeeName(action.action_by_who)

                        vm.openModal('hapFollowupComponent')
                        setTimeout(()=>{
                            $scope.$broadcast('HAZARD_FOLLOWUP_OPENED')
                        },100)
                    })
                }
            }
            
            //Function to validate for Sign modal
            vm.validateForSign = () => {
                vm.noOfExtremes = 0
                vm.noOfHighs = 0
                vm.noOfRiskAlara = 0
                vm.noOfHaps = 0
                vm.signFlag = true
                vm.currentJra.step_categories.forEach((ec)=>{
                    ec.threats.forEach((ev)=>{
                        if (ev.rmm_jth_risk_alara_preliminary === 0){
                            if (ev.rmm_jth_risk_alara_residual === 0){
                                vm.noOfRiskAlara += 1
                                vm.signFlag = false
                            }
                        }
                        // Extreme = 3626 
                        if (ev.rmm_jth_risk == 3626){
                            vm.noOfExtremes += 1
                        }
                        // High = 3622
                        if (ev.rmm_jth_risk == 3622){
                            vm.noOfHighs += 1
                        }
                    })
                })
                vm.currentJra.hazard_actions.forEach((hap)=> {
                    if (hap.action_status !== 1){
                        vm.noOfHaps += 1
                        vm.signFlag = false
                    }
                })
                return vm.signFlag
            }

             // Function to verify if form has changed
             function hasFormChanged() {
                if($('#newJra').serialize() != $('#newJra').data('serialize')){
                    $('#newJra').data('serialize',null)
                    vm.changesInForm = true
                }
            }

            //Function to open the complete action modals
            vm.signActionModal = () => {
                hasFormChanged()
                if (vm.changesInForm) {
                    vm.saveJra()
                }
                vm.validateJra().then((res)=>{
                    if(res.val && res.chip){
                        if (vm.validateForSign()){
                            vm.currentUserSigned = false
                            vm.currentJra.approversList.forEach((app) => {
                                if (app.rmm_jap_per === vm.userId && app.rmm_jap_approved){
                                    vm.currentUserSigned = true 
                                }
                            })
                            vm.openModal('signJraSuccessModal')
                        } else {
                            vm.openModal('signJraFailureModal')
                        }
                    } else {
                        if(!res.val)
                            $rootScope.$broadcast("CALLCONFIRMMODAL")
                    }
                })
            }

            //Function to save the Jra
            vm.saveJra = (mode='normal') => {
                resetFormFieldClassList('jraForm')
                if (validateFormFields('jraForm', true)){
                    // for autosave so that is does not show the spinner
                    if (mode === 'normal') {
                        $scope.$emit('STARTSPINNER', translateTag(3873))
                    }
                    else {
                        vm.autoSaveActive = true
                    }
                    $('#newJra').data('serialize',$('#newJra').serialize())
                    vm.changesInForm = false
                    if(vm.currentMode === "new") {
                        vm.updatingRecord = true
                        vm.saved = true
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentJra)))
                        payload.rmm_jra_is_submitted = false
                        jraService.createJra(payload).then((response) => {                     
                            if (response.rmm_jra_id){
                                // for Autosave to not interupt the user with refreshing
                                if(mode === 'normal') {
                                    vm.getSingleDetailRec(response.rmm_jra_id).then(() => {
                                        $q.all([
                                            vm.initializeTagsAndPulldowns()
                                        ]).then((data) => {
                                            vm.rmm_jra_doc_revision_no = `${appendLeadingZeros(response.rmm_jra_document_number)}`+'.'+`${appendLeadingZeros(response.rmm_jra_doc_version_number,3)}`
                                            vm.validateCurrentUserInApprovers()  
                                            vm.updatingRecord = false       
                                            $scope.$emit('STOPSPINNER')    
                                            refreshData()
                                        })
                                    })
                                }
                                else {
                                    // Update everything needed for the AG- Grid - Autosave
                                    reloadAutoSave(response.rmm_jra_id)
                                }
                            }
                            else {
                                vm.updatingRecord = false
                            }
                            if (!response){
                                throwToastr("error",translateTag(3857), 2000)
                            }
                        })
                    }
                    else{
                        vm.updatingRecord = true
                        let payload = preparePayload('edit', JSON.parse(JSON.stringify(vm.currentJra)))
                        payload.rmm_jra_is_submitted = false
                        vm.tmpDeletedStepCategories = []
                        vm.tmpDeletedThreat = []
                        jraService.updateJra(payload).then((response) => {
                            if (response.rmm_jra_id){
                                // for Auto Save to not interupt the user with refreshing
                                if(mode === 'normal') {
                                    vm.getSingleDetailRec(response.rmm_jra_id).then(() => {
                                        $q.all([
                                            vm.initializeTagsAndPulldowns()
                                        ]).then((data) => {
                                            vm.rmm_jra_doc_revision_no = `${appendLeadingZeros(vm.currentJra.rmm_jra_document_number)}`+'.'+`${appendLeadingZeros(vm.currentJra.rmm_jra_doc_version_number,3)}`
                                            vm.validateCurrentUserInApprovers()
                                            vm.updatingRecord = false
                                            $scope.$emit('STOPSPINNER')
                                            refreshData()
                                        })
                                    })
                                }
                                else {
                                    // Update everything needed for the AG- Grid - Autosave
                                    reloadAutoSave(response.rmm_jra_id)
                                }
                            }


                            if (!response){                           
                                throwToastr("error",translateTag(3858), 2000)                            
                            }
                        })
                    }
                }else{
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            // This is used to Update the Current JRA with the latest IDS and 
            // Relevent data but not the active input lines so that there is nothing impeding the user
            function reloadAutoSave(id) {
                // Update everything needed for the AG- Grid - Autosave
                jraService.getJraSIngleDetailRec(id).then((res) => {
                    vm.currentJra.approversList = []
                    angular.copy(res.approvers,vm.currentJra.approversList)
                    vm.currentJra.approvers = getApprovers(res.approvers)
                    vm.currentJra.rmm_jra_id =  res.rmm_jra_id
                    vm.currentJra.rmm_jra_state =  res.rmm_jra_state
                    vm.currentJra.rmm_jra_doc_version_number = res.rmm_jra_doc_version_number
                    vm.currentJra.rmm_jra_document_number = res.rmm_jra_document_number
                    vm.rmm_jra_doc_revision_no = `${appendLeadingZeros(vm.currentJra.rmm_jra_document_number)}`+'.'+`${appendLeadingZeros(vm.currentJra.rmm_jra_doc_version_number,3)}`
                    // Loop through all the data and update the ID/s
                    vm.currentJra.step_categories.forEach((cat,catindex) => {
                        if(res.step_categories[catindex]){
                            cat.rmm_jsc_id = res.step_categories[catindex].rmm_jsc_id
                            cat.rmm_jsc_pra = res.step_categories[catindex].rmm_jsc_pra
                            cat.rmm_jsc_sort = res.step_categories[catindex].rmm_jsc_sort
                        }
                        cat.threats.forEach((thr, thrindex) => {
                            if(res.step_categories[catindex].threats[thrindex]) {
                                thr.rmm_jth_id = res.step_categories[catindex].threats[thrindex].rmm_jth_id
                                thr.rmm_jth_pec = res.step_categories[catindex].threats[thrindex].rmm_jth_pec
                            }
                            thr.control_measures.forEach((cm, cmindex)=>{
                                if(res.step_categories[catindex].threats[thrindex].control_measures[cmindex]){
                                    cm.rmm_jta_id = res.step_categories[catindex].threats[thrindex].control_measures[cmindex].rmm_jta_id
                                    cm.rmm_jta_created_by_per = res.step_categories[catindex].threats[thrindex].control_measures[cmindex].rmm_jta_created_by_per
                                    cm.rmm_jta_enable = res.step_categories[catindex].threats[thrindex].control_measures[cmindex].rmm_jta_enable
                                    cm.rmm_jta_parent_tag_name = res.step_categories[catindex].threats[thrindex].control_measures[cmindex].rmm_jta_parent_tag_name
                                    cm.rmm_jta_pth = res.step_categories[catindex].threats[thrindex].control_measures[cmindex].rmm_jta_pth
                                }
                            })
                            thr.additional_control_measures.forEach((acm, acmindex) => {
                                if(res.step_categories[catindex].threats[thrindex].additional_control_measures[acmindex]) {
                                    acm.rmm_jta_id = res.step_categories[catindex].threats[thrindex].additional_control_measures[acmindex].rmm_jta_id
                                    acm.rmm_jta_created_by_per = res.step_categories[catindex].threats[thrindex].additional_control_measures[acmindex].rmm_jta_created_by_per
                                    acm.rmm_jta_enable = res.step_categories[catindex].threats[thrindex].additional_control_measures[acmindex].rmm_jta_enable
                                    acm.rmm_jta_parent_tag_name = res.step_categories[catindex].threats[thrindex].additional_control_measures[acmindex].rmm_jta_parent_tag_name
                                    acm.rmm_jta_pth = res.step_categories[catindex].threats[thrindex].additional_control_measures[acmindex].rmm_jta_pth
                                }
                            })
                        })
                    })
                    vm.validateCurrentUserInApprovers()
                    vm.updatingRecord = false
                    vm.uneditedCurrentJra = []
                    angular.copy(vm.currentJra, vm.uneditedCurrentJra)
                })
            }

            //Function to sign the JRA
            vm.signJra = (modalId) => {
                if(validateText(vm.currentJra.rmm_jra_executive_summary,"")) {
                    $scope.$emit('STARTSPINNER', translateTag(3874)) 
                    payload = {
                        rmm_jra_id: vm.currentJra.rmm_jra_id,
                        rmm_jra_executive_summary: vm.currentJra.rmm_jra_executive_summary ? vm.currentJra.rmm_jra_executive_summary : ""
                    }
                    vm.currentUserSigned = true
                    vm.cancelModal(modalId)
                    jraService.signJra(payload).then((response) => {
                        // Stop the Autosave
                        $interval.cancel(vm.autosave)
                        vm.autoSaveActive = false
                        if (response.message === "Document Signed"){
                            vm.currentUserSigned = true
                            vm.currentJra.rmm_jra_state = response.rmm_jra_state
                            vm.currentJra.approversList.forEach((app) => {       
                                //Setting the approved flag of current approver to true
                                if (app.rmm_jap_per === vm.userId){
                                    app.rmm_jap_approved = true
                                }
                            })
                            vm.changesInForm = false
                        }
                        refreshData()
                        $scope.$emit('STOPSPINNER')
                        vm.cancelModal(modalId)
                    })
                }
                else{
                    document.getElementById('rmm_jra_executive_summary').classList.add('invalid')
                    document.getElementById('rmm_jra_executive_summary').setCustomValidity(false)
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            function newApprover(){
                return(
                    {
                        rmm_jap_per: null,
                        rmm_jap_approved: false,
                        rmm_jap_approved_date: null,
                        full_name: null
                    })
            }

            //Function to prepare payload data
            function preparePayload(mode='new', payload) {
                let preparedPayload = payload
                if (mode === "new"){
                    preparedPayload.rmm_jra_state = 'draft'       
                    preparedPayload.rmm_jra_created_date = moment(payload.rmm_jra_created_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_jra_date = (preparedPayload.rmm_jra_date===null || preparedPayload.rmm_jra_date===undefined)?null:moment(payload.rmm_jra_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_jra_expiry_date = (preparedPayload.rmm_jra_expiry_date===null || preparedPayload.rmm_jra_expiry_date===undefined) ? null:moment(payload.rmm_jra_expiry_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    
                    payload.step_categories.forEach((ec, index) => {
                        ec.threats.forEach((ev, index) => {
                            tmp_cm = []
                            tmp_additional = []
                            ev.control_measures.forEach((val, index) => {
                                newCMObj = newTag()
                                newCMObj.tag = val.tag
                                newCMObj.rmm_jta_blueline = val.rmm_jta_blueline
                                tmp_cm.push(newCMObj)
                            })
                            ev.additional_control_measures.forEach((val, index) => {
                                newAdditionalCMObj = newTag()
                                newAdditionalCMObj.tag = val.tag
                                tmp_additional.push(newAdditionalCMObj)
                            })
                            ev.control_measures = tmp_cm
                            ev.additional_control_measures = tmp_additional
                        })
                    })
                }else{
                    preparedPayload.rmm_jra_created_date = moment(payload.rmm_jra_created_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_jra_date = (preparedPayload.rmm_jra_date===null || preparedPayload.rmm_jra_date===undefined)?null:moment(payload.rmm_jra_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_jra_expiry_date = (preparedPayload.rmm_jra_expiry_date===null || preparedPayload.rmm_jra_expiry_date===undefined) ?null:moment(payload.rmm_jra_expiry_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.approvers = payload.approvers != undefined ?  payload.approvers : []
                    preparedPayload.participants = payload.participants != undefined ? payload.participants : []

                    //Title and scope
                    preparedPayload.rmm_jra_title = payload.rmm_jra_title ? payload.rmm_jra_title : null
                    preparedPayload.rmm_jra_scope = payload.rmm_jra_scope ? payload.rmm_jra_scope : null
                    preparedPayload.rmm_jra_site = payload.rmm_jra_site ? payload.rmm_jra_site : null
                    preparedPayload.rmm_jra_job = payload.rmm_jra_job ? payload.rmm_jra_job : null
                    payload.step_categories.forEach((ec, index) => {
                        ec.rmm_jsc_step = ec.rmm_jsc_step !== undefined ? ec.rmm_jsc_step : null
                        ec.threats.forEach((ev, index) => {
                            ev.rmm_jth_threat = ev.rmm_jth_threat ? ev.rmm_jth_threat : null
                            ev.rmm_jth_outcome = ev.rmm_jth_outcome ? ev.rmm_jth_outcome : null
                            tmp_cm = []
                            tmp_additional = []
                            ev.control_measures.forEach((cm, index) => {
                                if (!cm.rmm_jta_id || cm.rmm_jta_id === null){
                                    newCMObj = newTag()
                                    newCMObj.tag = cm.tag
                                    newCMObj.rmm_jta_blueline = cm.rmm_jta_blueline
                                    tmp_cm.push(newCMObj)
                                }else{
                                    tmp_cm.push(cm)
                                }
                            })
                            ev.additional_control_measures.forEach((add, index) => {
                                if (!add.rmm_jta_id){
                                    newAdditionalCMObj = newTag()
                                    newAdditionalCMObj.tag = add.tag
                                    tmp_additional.push(newAdditionalCMObj)
                                }else{
                                    tmp_additional.push(add)
                                }
                            })
                            ev.control_measures = tmp_cm
                            ev.additional_control_measures = tmp_additional

                            ev.rmm_jth_likelyhood_preliminary = ev.rmm_jth_likelyhood_preliminary !== undefined ? ev.rmm_jth_likelyhood_preliminary : null
                            ev.rmm_jth_severity_preliminary = ev.rmm_jth_severity_preliminary !== undefined ? ev.rmm_jth_severity_preliminary : null
                            ev.rmm_jth_preliminary_risk = ev.rmm_jth_preliminary_risk !== undefined ? ev.rmm_jth_preliminary_risk : null
                            ev.rmm_jth_risk_alara_preliminary = ev.rmm_jth_risk_alara_preliminary !== undefined ? ev.rmm_jth_risk_alara_preliminary : null
                            ev.rmm_jth_likelyhood_residual = ev.rmm_jth_likelyhood_residual ? ev.rmm_jth_likelyhood_residual : null
                            ev.rmm_jth_severity_residual = ev.rmm_jth_severity_residual !== undefined ? ev.rmm_jth_severity_residual : null
                            ev.rmm_jth_residual_risk = ev.rmm_jth_residual_risk !== undefined ? ev.rmm_jth_residual_risk : null
                            ev.rmm_jth_risk_alara_residual = ev.rmm_jth_risk_alara_residual !== undefined ? ev.rmm_jth_risk_alara_residual : null
                        })
                    })
                    vm.uneditedCurrentJra.step_categories.forEach((uec, index) => {
                        uec.threats.forEach((uev, index) => {
                            uev.control_measures = uev.control_measures ? uev.control_measures : []
                            uev.control_measures.forEach((ucm, index) => {
                                payload.step_categories.forEach((ec, index) => {
                                    ec.threats.forEach((ev, index) => {
                                        if (uev.rmm_jth_id===ev.rmm_jth_id && !ev.control_measures.find(cm => cm.rmm_jta_id === ucm.rmm_jta_id)){
                                            ucm.rmm_jta_enable = false
                                            ev.control_measures.push(ucm)
                                        }
                                    }) 
                                })
                            })
                            uev.additional_control_measures = uev.additional_control_measures ? uev.additional_control_measures : []
                            uev.additional_control_measures.forEach((uadd, index) => {
                                payload.step_categories.forEach((ec, index) => {
                                    ec.threats.forEach((ev, index) => {
                                        if (uev.rmm_jth_id===ev.rmm_jth_id && !ev.additional_control_measures.find(add => add.rmm_jta_id === uadd.rmm_jta_id)){
                                            uadd.rmm_jta_enable = false
                                            ev.additional_control_measures.push(uadd)
                                        }
                                    }) 
                                })
                            })
                        })
                    })

                    vm.tmpDeletedStepCategories.forEach((dec) => {
                        preparedPayload.step_categories.push(dec) 
                    })
                    
                    vm.tmpDeletedThreat.forEach((dev) => {
                        preparedPayload.step_categories.forEach((ec) => {
                            if (dev.rmm_jth_jsc === ec.rmm_jsc_id) {
                                ec.threats.push(dev)
                            }
                        })
                    })
                }
                return preparedPayload
            }

            //Function to add an general action or hazard action
            vm.addAction = (actionData) => {
                payload = {}
                if('sga_id' in actionData){
                    payload.rmm_jga_jra = vm.currentJra.rmm_jra_id
                    payload.rmm_jga_sga = actionData.sga_id
                    jraService.addJraGeneralAction(payload).then((response) => {
                        refreshActions(vm.currentJra.rmm_jra_id)
                    })
                }
                else if('ID' in actionData){
                    payload.rmm_jha_jra =  vm.currentJra.rmm_jra_id
                    payload.rmm_jha_sha = actionData.ID
                    jraService.addJraHazardAction(payload).then((response) => {
                        refreshActions(vm.currentJra.rmm_jra_id)
                    })
                }
            }

            //Function to remove completed actions from the grid
            vm.completeAction = (actionData) => {
                refreshActions(vm.currentJra.rmm_jra_id)
            }

            //Funtion to initialize select2
            vm.initializeSelect2 = (parent, section='')=> {
                setTimeout(()=>{
                $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} ${section}`), escapeMarkup: function (text) { return text } })
                .on('select2:select', () => {
                    $(this).parent().find('label').addClass('filled')
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()

                today = new Date()
                if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
                $('.datepicker').pickadate({
                    format: 'yyyy-mm-dd',
                    onClose : function(){
                        this.$holder.blur()
                    },
                    min: new Date(moment(today).calendar()),
                }).removeAttr('readonly')
                .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                    evt.preventDefault()
                })
                preventFutureDatePickerInit()
                }, 500)
            }

            //Listeners
            $scope.$on('CLOSEMODAL', (event) => {
                vm.initializeSelect2('newJra')
            })

            $scope.$on('ADDACTION', (event, data) => {
                if(data && vm.actionMode != 'edit'){
                    vm.addAction(data)
                }else{
                    refreshActions(vm.currentJra.rmm_jra_id)
                }
            })

            $scope.$on('COMPLETEACTION', (event, data) => {
                if(data)
                    vm.completeAction(data)
            })

            //Function to refresh data and Ag-Grid
            function refreshData() {
                $scope.$emit('STARTSPINNER', vm.loadMessage)
                $q.all([
                    listService.getSelectListData('ref_site'),
                    listService.getSelectListData('ref_job'),
                    listService.getSelectListData('ref_general_action'),
                    employeesService.getPersonProfile(),
                    profileService.getAllEmployeeProfile(),
                    profileService.getFullEmployeeProfile(),
                    listService.getSelectListData('ref_likelihood'),
                    listService.getSelectListData('ref_severity'),
                    listService.getSelectListData('ref_step'),
                    listService.getActionTypes(),
                    jraService.getJraList(vm.mainDateFilter), 
                    listService.getFullSiteList(),
                    listService.getFullJobList(),
                    profileService.getRmmApproverEmployees('rmm-jra'),



                ]).then((data) => {
                    vm.siteList = data[0]
                    vm.jobList = data[1]
                    vm.jobList.forEach((job)=>{
                        job.fullJob = `(${job.rld_code}) - ${job.rld_name}`
                    })
                    vm.actionTypeList = data[2]
                    vm.userId = data[3].per_id
                    vm.fullEmployeeList = profileService.readFullEmployeeProfile()
                    vm.likelyHoodList = data[6]
                    vm.severityList = data[7]
                    vm.eventCategoryList = data[8]
                    vm.hapActionTypeList = data[9]
                    vm.jraAGData = jraService.readJraList()
                    vm.tmpDeletedStepCategories = []
                    vm.tmpDeletedThreat = []
                    vm.site_name = listService.readFullSites()
                    vm.job_name = listService.readFullJobs()

                    if (vm.jraOptions.api) {
                        translateAgGridHeader (vm.jraOptions)
                        let model = vm.jraOptions.api.getFilterModel()
                        vm.jraOptions.paginationPageSize = 15
                        vm.jraOptions.api.setRowData(prepareJraGridData())
                        vm.jraOptions.api.redrawRows()
                        vm.jraOptions.api.sizeColumnsToFit()
                        vm.jraOptions.api.setFilterModel(model)
                    }
                    vm.actionDisabled = true
                    $scope.$emit('STOPSPINNER')
                })
            }

            vm.resetForm()
            vm.jraViewerOpen = true
            vm.initializeSelect2('newJra')
            vm.jraViewerOpen = false

            //function to append leading zeros
            function appendLeadingZeros (num, size=6){
                var s = "000000000" + num;
                return s.substr(s.length-size);
            }

            
            //Function to prepare sitelist by filter
            function mapSitesFilter (siteList, prasiteList)
            {
                vm.siteList = []
                siteList.forEach ((rec) => {
                    if(prasiteList.includes(rec.rld_id))
                    vm.siteList.push(rec)
                })
                return
            }

            //Function to prepare Ag-Grid data with string values
            function prepareJraGridData() {
                let jraGridData = JSON.parse(JSON.stringify(vm.jraAGData))
                jraGridData.forEach((rec) =>{
                    rec.exceptionFields = ['approvers','general_actions', 'hazard_actions', 'acknowledgements', 'participants', 'rmm_jra_enable', 'dlo_enable', 'reviewers','rat_jra_show_check_box','rmm_jra_created_by_per_id']
                    rec.rmm_jra_site = getSiteName(rec.rmm_jra_site)
                    rec.rmm_jra_job = getJobNumber(rec.rmm_jra_job)
                    rec.rmm_jra_created_date = moment(rec.rmm_jra_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                    rec.rmm_jra_expiry_date = rec.rmm_jra_expiry_date===null?'':moment(rec.rmm_jra_expiry_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                    rec.rmm_jra_is_submitted  = translateTrueFalse(rec.rmm_jra_state == 'active' ||  rec.rmm_jra_state == 'expired' ? true : false)
                    rec.rmm_jra_revision_no = `${appendLeadingZeros(rec.rmm_jra_document_number)}`+'.'+`${appendLeadingZeros(rec.rmm_jra_doc_version_number,3)}`
                    rec.reviewedCount = rec.reviewers.length
                    rec.hasReviewed = translateTrueFalse(checkAcknowledged(rec))
                    rec.reviewersList = ''
                    rec.reviewers.forEach((rev) => {
                        rec.reviewersList += (`${vm.getEmployeeName(rev.rmm_jre_per_id)} - `)
                    })
                    rec.reviewersList =  rec.reviewersList.replace(/ -\s*$/, "")

                    rec.approversList = ''
                    rec.approvers.forEach((app) => {
                        rec.approversList += (`${vm.getEmployeeName(app.rmm_jap_per)} - `)
                    })
                    rec.approvers =  rec.approversList.replace(/ -\s*$/, "")
                    rec.approversList =  rec.approversList.replace(/ -\s*$/, "")

                    if(rec.dlo_enable.length !== 0){
                        rec.dlo_status = translateTrueFalse(rec.dlo_enable[0].dlo_enable)
                        rec.dlo_person = rec.dlo_enable[0].dlo_person
                    }
                    else{
                        rec.dlo_status = translateTrueFalse(true)
                        rec.dlo_person = null
                    }
                    
                    rec.participantsList = ''
                    rec.participants.forEach((par) => {
                        rec.participantsList += (`${vm.getEmployeeName(par)} - `)
                    })
                    rec.participants = rec.participantsList.replace(/ -\s*$/, "")
                    rec.participantsList = rec.participantsList.replace(/ -\s*$/, "")
                })
                return jraGridData
            }

            //Function to prepare Participants
            function getParticipants (values)
            {
                let participants = []
                values.forEach ((rec) => {
                    participants.push(rec.llp_per)
                })
                return participants
            }

            function translateStatus(status) {
                if (status === 'draft'){
                    return translateTag(1399)
                }
                if (status === 'expired'){
                    return translateTag(3494)
                } 
                if (status == 'review'){
                    return translateTag(1188)
                } 
                if (status == 'active'){
                    return translateTag(3557)
                }
            }
            function 
            translateTrueFalse(val) {
                return val ? translateTag(1379): translateTag(1380)
            }

            //Function to prepare Approvers
            function getApprovers (values)
            {
                let approvers = []
                values.forEach ((rec) => {
                    approvers.push(rec.rmm_jap_per)
                })
                return approvers
            }

            // Fuction to check if all modal feilds are valid
            vm.validateJra = () => {
                return new Promise(resolve =>{
                    let validated = validateFormFields('jraForm')

                    asyncChips().then((res)=>{
                        resolve({val:validated, chip:res})
                    })
                })
            }

            function validateChips(){
                return new Promise(resolve => {
                    let chipVal = true
                    vm.currentJra.step_categories.forEach((cat)=> {
                        cat.threats.forEach((threat)=>{
                            if(threat.control_measures.length == 0) {
                                chipVal = false
                                throwToastr('error',`${translateTag(2262)}: ${cat.rmm_jsc_step}  - ${translateTag(2115)}: ${threat.rmm_jth_threat} - ${translateTag(2478)} ${translateTag(1464)}`,5000)
                                resolve(chipVal)
                            }
                        })
                    })
                    resolve(chipVal)
                })
            }

            async function asyncChips() {
                dat = await validateChips();
                return dat
            }

            //Update Ag-Grid size when window is resized
            $(window).on('resize', () => {
                $timeout(function () {
                    if (vm.jraOptions.api) {
                        vm.jraOptions.api.sizeColumnsToFit()
                    }
                    if (vm.attachmentOptions.api) {
                        vm.attachmentOptions.api.sizeColumnsToFit()
                    }
                })
            })

            function getShowAccordianIds(){
                var expanded_elements = document.getElementsByClassName('collapse show')
                vm.exp_ids = []
                for (let i = 0; i < expanded_elements.length; i++) {
                    vm.exp_ids.push(expanded_elements[i].id)
                }
            }

            function setbackAccordian(){
                setTimeout(() => {
                    var accordian_elements = document.getElementsByClassName('collapse')
                    for (let i = 0; i < accordian_elements.length; i++) {
                        if(!vm.exp_ids.includes(accordian_elements[i].id)){
                            var removeClass_id = "#"+accordian_elements[i].id
                            $(removeClass_id).removeClass('show')
                        } 
                    }
                }, 500);
            }

            vm.initializeBlueline = () => {
                vm.currentJra.step_categories.forEach((ec_val, i) => {
                    ec_index = ec_val.rmm_jsc_sort                   
                    ec_val.threats.forEach((th_val, j) =>{
                        th_val.control_measures.forEach((cm)=>{

                            id = "control_measure-"+j+"-"+ec_index
                            let cmObjsWebElements = document.getElementById(id).getElementsByClassName('chip')
                            if (cmObjsWebElements.length > 0){
                                for (let index = 0; index < cmObjsWebElements.length; index++) {
                                    let chipText = cmObjsWebElements[index].innerText
                                    if (chipText===cm.tag){
                                        if (cm.rmm_jta_blueline){
                                            cmObjsWebElements[index].classList.add("chip-blueline")
                                        }
                                    }
                                } 
                            } 
                        })
                        
                    })
                })
            }


            // Function to initialize tags
            vm.initializeTags = () => {
                setTimeout(()=>{
                    vm.currentJra.step_categories.forEach((ec_val, i) => {
                        ec_index = ec_val.rmm_jsc_sort                          
                        ec_val.threats.forEach((ev_val, j) =>{
                            id = "#control_measure-"+j+"-"+ec_index
                            $(id).materialChip({
                                placeholder: '+ ' + translateTag(2478),
                                secondaryPlaceholder: translateTag(2109),
                                data: ev_val.control_measures
                            }).on('chip.add',(e, chip)=>{
                                for (let index = 0; index < ev_val.control_measures.length-1; index++) {
                                    if (ev_val.control_measures[index].tag.trim().toLowerCase() === chip.tag.trim().toLowerCase()){
                                        throwToastr('error',translateTag(3859),2000)
                                        ev_val.control_measures.pop()
                                        break;
                                    }
                                }
                                vm.changesInForm = true
                            }).on('chip.delete',()=>{
                                vm.changesInForm = true
                            });
                        })
                    }); 
                    vm.currentJra.step_categories.forEach((ec_val, i) => {
                        ec_index = ec_val.rmm_jsc_sort                          
                        ec_val.threats.forEach((ev_val, j) =>{
                            id = "#additional_measure-"+j+"-"+ec_index
                            $(id).materialChip({
                                placeholder: '+ ' + translateTag(3952), //Additional Control
                                secondaryPlaceholder: translateTag(2116),
                                data: ev_val.additional_control_measures
                            }).on('chip.add',(e, chip)=>{
                                for (let index = 0; index < ev_val.additional_control_measures.length-1; index++) {
                                    if (ev_val.additional_control_measures[index].tag.trim().toLowerCase() === chip.tag.trim().toLowerCase()){
                                        throwToastr('error',translateTag(3860),2000)
                                        ev_val.additional_control_measures.pop()
                                        break;
                                    }
                                }
                                vm.changesInForm = true
                            }).on('chip.delete',()=>{
                                vm.changesInForm = true
                            });
                        })
                    })
                },500)
            }

            // Move the elements in an array
            function array_move(arr, old_index, new_index) {
                if (new_index >= arr.length) {
                    var k = new_index - arr.length + 1;
                    while (k--) {
                        arr.push(undefined);
                    }
                }
                arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
                return arr;
            };


            function dragAndSort(){
                $( "#sortable" ).sortable({
                    items: "li:not(.ui-state-disabled)",
                    stop: function( event, ui ) {
                        vm.currentJra.step_categories.forEach((val, index) => {
                            tmp = parseInt(event.target.children[index].firstElementChild.id.split('-').pop());
                            vm.currentJra.step_categories[tmp].rmm_jsc_sort = index+1
                        });
                        let tmp_step_categories = []
                        vm.currentJra.step_categories.forEach((val, index) => {
                            let new_index = val.rmm_jsc_sort-1
                            tmp_step_categories.splice(new_index,0,val)
                        });
                        vm.currentJra.step_categories = tmp_step_categories
                        $scope.$apply();
                    }
                });
                $( "#sortable" ).sortable({ handle: '.handle'});
                $( "#sortable" ).disableSelection();
            }

            function destroyTables() {
                return new Promise((resolve, reject)=>{
                    if($.fn.DataTable) {
                        if ($.fn.DataTable.isDataTable(".data-table")) {
                            $('.data-table').DataTable().clear().destroy()
                            resolve(true)
                        }
                        else{
                            resolve(true)  
                        }
                    }
                })
            }

            //Function to get Jobs & Levels for a site
            vm.getJobsBySite = (mode) => {
                let mainSite = null
                vm.jobListSelect = []     
                vm.jobList.forEach((rec) => {
                    if(rec.rld_parent_detail_rld_id == vm.currentJra.rmm_jra_site)
                        vm.jobListSelect.push(rec)
                })
            }

            function initiateTables() {
                setTimeout(() =>{
                    $('.data-table').DataTable({
                        "searching": false,
                        "bSort": false,
                        "bLengthChange": false,
                        "pagingType": "numbers",
                        "pageLength": 5,
                        "language": {
                            "url": `/locales/datatables/i18n/${selectedLanguage}.json`
                        }
                    });
                    $('.dataTables_length').addClass('bs-select');
                    $(".dataTables_wrapper div:last-of-type div").removeClass("col-md-5 col-md-7");
                },500)
            }

            $(document).ready(function() {
                vm.initializeTags()
                dragAndSort()
            });
        //END
    }
])