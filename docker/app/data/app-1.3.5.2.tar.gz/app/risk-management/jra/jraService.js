angular
    .module('safeToDo')
    .service('jraService', ['$http',
        function ($http) {
            let lessonsList = []
            let jraList = []
            let praSiteList = []

            return {
                getJraList: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/jra-get-list/`, payload).then((response) => {
                        jraList = response.data
                    }, (errorParams) => {
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            jraList = []
                            window.location.href = "/";
                        }
                    })
                },

                getPraSiteList: () => {
                    return $http.get(`${__env.apiUrl}/api/rmm/jra-get-active-pra-sites/`).then((response) => {
                        praSiteList = response.data
                    }, (errorParams) => {
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            jraList = []
                            window.location.href = "/";
                        }
                    })
                },

                
                getJraSIngleDetailRec: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/jra-get-detail/${payload}/`).then((response) => {
                        jraDetail = response.data
                        return jraDetail
                    }, (errorParams) => {
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            jraDetail = null
                            window.location.href = "/";
                        }
                    })
                },
                getJraPraList: () => {
                    return $http.get(`${__env.apiUrl}/api/rmm/jra-pra-title-list/`).then((response) => {
                        return response.data.data
                    }, (errorParams) => {
                         if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            window.location.href = "/";
                        }
                    })
                },
                getBluelinesList: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/jra-bluelines/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            window.location.href = "/";
                        }
                    })
                },
                getGaHaActions: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/jra-get-gaha-detail/${payload.rmm_jra_id}/`).then((response) => {
                        if(response.data.accessMsg){
                            toastr.error(response.data.accessMsg)
                            return []
                        }
                        else
                            return response.data
                    }, (errorParams) => {
                        // console.log('Failed to load general actions', errorParams)
                    })
                },             

                createJra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/jra-insert/`, payload).then((response) => {
                       return response.data
                    }, (errorParams) => {
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                updateJra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/jra-update/${payload.rmm_jra_id}/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                signJra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/jra-sign/`, payload).then((response) => {
                       return response.data
                    }, (errorParams) => {
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                archiveJra: (IdList) => {
                    var patchList = []
                    for (var i = 0; i < IdList.length; i++) {
                        patchList.push({ rmm_jra_id: IdList[i]})
                    }
                    return $http.post(`${__env.apiUrl}/api/rmm/jra-archive/`, patchList).then((response) => {
                        return response
                    }, (errorParams) => {
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
             
                addJraGeneralAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/jra-insert-general-action/`, payload).then((response) => {
                        if(response.data.accessMsg){
                        toastr.error(response.data.accessMsg)
                        return []
                        }
                        else
                            return response.data

                    }, (errorParams) => {
                    })
                },
                addJraHazardAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/jra-insert-hazard-action/`, payload).then((response) => {
                        if(response.data.accessMsg){
                        toastr.error(response.data.accessMsg)
                        return []
                        }
                        else
                            return response.data

                    }, (errorParams) => {
                    })
                },               
             
                copyRevisionJra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/jra-copy-revision/${payload.rmm_jra_id}/${payload.mode}/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                getJraPraThreatList: (payload) => {
                    payload = {                    
                                "rmm_pra_id": payload                
                            }
              
                    return $http.post(`${__env.apiUrl}/api/rmm/jra-pra-threat-list/`, payload).then((response) => {
                        return response.data.data
                    }, (errorParams) => {
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                reviewJra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/jra-review/${payload.rmm_jra_id}/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },



                // Returns list 
                readLessonsList: () => {
                    return lessonsList
                },

                readJraList: () => {
                    return jraList
                },
                readPraJraList: () => {
                    return praSiteList
                },

            //End
            }
        }
    ])