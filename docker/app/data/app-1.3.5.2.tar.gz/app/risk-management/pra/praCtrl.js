angular
    .module('safeToDo')
    .controller('praCtrl', ['$rootScope','$scope', '$timeout', '$q', '$compile', '$window', '$interval', '$sce', 'gridService', 'select2Service',
      'praService', 'listService', 'modalService', 'profileService', 'employeesService','menuService', 'actionManagementService', 'documentLockService','rmmAttachmentsService','fileUploadService', 'exportCSV',
        function ($rootScope,$scope, $timeout, $q, $compile, $window, $interval, $sce, gridService, select2Service, praService, listService,
            modalService, profileService, employeesService, menuService, actionManagementService, documentLockService,rmmAttachmentsService,fileUploadService, exportCSV) {
            var vm = this;
            
            let dateToday = moment(new Date(), 'YYYY-MM-DD')
            vm.employeeList = []
            vm.fullEmployeeList = []
            vm.currentAcknowledgeHistory = []
            vm.userId = null
            vm.siteList = []
            vm.jobList = []
            vm.jobListSelect = []
            vm.actionTypeList = []
            vm.singleServeReportUrl = 'project_risk_assessment'
            vm.bowtieReportUrl = 'bowtie'
            vm.praDataContext = {}
            vm.topSearch = ''
            vm.archiveCount = 0
            vm.deleteAttCount = 0
            vm.praAGData = []
            vm.blueLineAGData = []
            vm.attachmentData = []
            vm.newAttachments = []
            vm.uploadFileList= []
            vm.actionDisabled = true
            vm.attActionDisabled = true
            vm.blueLineactionDisabled = true
            vm.canArchiveSubmissions = false
            vm.praViewerOpen = false
            vm.hideingPraViewer = false
            vm.openingPraViewer = false
            vm.currentAcknowledge = null
            vm.generalEditData = {}
            vm.hazardEditData = {}
            vm.tmpDeletedElements = []
            vm.tmpDeletedThreats = []
            vm.likelyHoodList = []
            vm.severityList = []
            vm.riskCategoryList = []
            vm.performActionMode = ''
            vm.selectedRecordCount = 0
            vm.rmm_pra_doc_revision_no = null
            vm.updatingRecord = false
            vm.autosave = null
            vm.autoSaveActive = false
            vm.pra_ora_titles = []
            vm.pra_ora_events_list = []
            vm.pra_bluelines = []
            vm.userInApprovers = false
            vm.changesInForm = false
            vm.blueLineSearch = ''
            vm.blueLine_ec_index = null
            vm.blueLine_th_index = null
            vm.currentPra_blueLine = []
            vm.canViewPRA = false
            vm.canManagePRA = true
            vm.currentUserSigned = false
            vm.selectedDocumentNo = ''
            vm.pra_bowties=[]
            vm.loadMessage = translateTag(3872) 
            vm.alara = [
                {
                  id: 1,
                  label: translateTag(1379)
                },
                {
                  id: 0,
                  label: translateTag(1380)
                }
            ]

            vm.requireBowtie = [
                {
                  id: 1,
                  label: translateTag(1379)
                },
                {
                  id: 0,
                  label: translateTag(1380)
                }
            ]

            vm.continueEditing = false
            vm.leaveEditing = false
            vm.idletime = 0
            vm.countdownSeconds = 60

            vm.pra_show_check_box = false
            vm.mod_id = 15   //module pra
            vm.currentAttachment = null


            //Get permissions for the user   
            menuService.getPagePermissions().then((data) => {
                vm.permissions = data
                vm.canViewPRA = vm.permissions.includes('Can View PRA') ? true : false
                vm.canManagePRA = vm.permissions.includes('Can Manage PRA') ? true : false
                vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
                vm.canManageActionItems = vm.permissions.includes('Can Manage Action Items') ? true : false
                vm.canCloseAllActions = vm.permissions.includes('Can Close All Actions') ? true : false

            })

            $scope.$on('DATERANGE', (range) => {
                vm.mainDateFilter = {
                    start_date: moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD'),
                    end_date: moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')
                }
                refreshData()
            })

            //Function to clear the form feilds
            vm.resetForm = () => {
                resetFormFieldClassList('praForm')
                vm.jobListSelect = []
                vm.attachmentData = []
                vm.tmpDeletedElements = []
                vm.tmpDeletedThreats = []
                vm.saved = false
                vm.submitted = false
                vm.rmm_pra_doc_revision_no = null
                vm.updatingRecord = false
                vm.changesInForm = false
                vm.blueLineAGData = []
                vm.currentUserSigned = false

                vm.dlo_id = null
                vm.docLockMessage = ''
                vm.docLockStatus = false
                vm.countdownSeconds = 60
                vm.lockCheckModal = false
                vm.continueEditing = false
                vm.idletime = 0
                vm.leaveEditing = false
                vm.pra_show_check_box = false

                vm.currentPra =
                {
                    rmm_pra_id: null,
                    rmm_pra_document_number: null,
                    rmm_pra_doc_version_number: null,
                    rmm_pra_title: null,
                    rmm_pra_scope: null,
                    rmm_pra_expiry_date: null,
                    rmm_pra_site: null,
                    rmm_pra_ora: null,
                    rmm_pra_other_participants: null,
                    rmm_pra_state: null,
                    rmm_pra_date: dateToday.format("YYYY-MM-DD"),
                    rmm_pra_created_date: dateToday.format("YYYY-MM-DD"),
                    rmm_pra_created_by_per_id: null,
                    ora_events: [],
                    participants: [],
                    approvers: [],
                    rmm_pra_is_submitted: false,
                    element_categories: [newElementCategory()],
                    approversList:[],
                    rmm_pra_executive_summary: null,
                    hazard_actions:[],
                    general_actions: []
                }
                vm.pra_bowties = []
            }

            // Function for a new event category object
            function newElementCategory() {
                return {
                    rmm_pec_element: null,
                    rmm_pec_id: null,
                    rmm_pec_sort: 1,
                    rmm_pec_enable: true,
                    threats: [newThreat()]
                }
            }

            // Function for a Unwanted major event object
            function newThreat() {
                return {
                    rmm_pth_id: null,
                    rmm_pth_pec: null,
                    rmm_pth_risk_category: null,
                    rmm_pth_severity_to_risk: null,
                    rmm_pth_severity_to_risk_label: null,
                    rmm_pth_enable: true,
                    rmm_pth_threat: null,
                    rmm_pth_likelyhood_preliminary: null,
                    rmm_pth_severity_preliminary: null,
                    rmm_pth_preliminary_risk: null,
                    rmm_pth_preliminary_risk_text: null,
                    rmm_pth_risk_alara_preliminary: null,
                    rmm_pth_require_bowtie: null,
                    rmm_pth_likelyhood_residual: null,
                    rmm_pth_severity_residual: null,
                    rmm_pth_residual_risk: null,
                    rmm_pth_residual_risk_text: null,
                    rmm_pth_risk: null,
                    rmm_pth_risk_alara_residual: null,
                    rmm_pth_outcome: null,
                    control_measures: [],
                    additional_control_measures:[]
                }
            }

            // Function for a tag object
            function newTag() {
                return {
                    rmm_pta_id: null,
                    rmm_pta_pth: null,
                    tag: null,
                    rmm_pta_tag_name:null,    
                    rmm_pta_blueline: false,
                    rmm_pta_enable: true
                }
            }

            //Function to add a new event category
            vm.addElementCategory = function () {
                let elementCatagories = vm.currentPra.element_categories
                let newCat = newElementCategory()
                newCat.rmm_pec_sort = elementCatagories.length + 1
                vm.currentPra.element_categories.push(newCat)
                setTimeout(()=>{
                    vm.initializeTagsAndPulldowns()
                },100)
            }

            //Function to add a new unwanted event category
            vm.addThreat = function (ec_index) {
                vm.currentPra.element_categories[ec_index].threats.push(newThreat())
                setTimeout(()=>{
                    vm.initializeTagsAndPulldowns()
                },100)
            }

            //Function to delete an event category
            vm.deleteElementCategory = function (rm_index) {
                let tmp_ec_obj = {}
                vm.currentPra.element_categories[rm_index].rmm_pec_enable = false
                tmp_ec_obj = vm.currentPra.element_categories.splice(rm_index,1)[0]
                vm.currentPra.element_categories.forEach((val, index) => {
                   val.rmm_pec_sort = index+1
                });
                vm.tmpDeletedElements.push(tmp_ec_obj)
                if (vm.currentPra.element_categories.length === 0){
                    vm.addElementCategory()
                    return
                }
                vm.initializeSelect2('newPra')
            }

            //Function to delete an event
            vm.deleteThreat = function (rm_th_index,rm_ec_index) {
                let tmp_th_obj = {}
                vm.currentPra.element_categories[rm_ec_index].threats[rm_th_index].rmm_pth_enable = false
                tmp_th_obj = vm.currentPra.element_categories[rm_ec_index].threats.splice(rm_th_index,1)[0]
                vm.tmpDeletedThreats.push(tmp_th_obj)
                if (vm.currentPra.element_categories[rm_ec_index].threats.length === 0){
                    vm.addThreat(rm_ec_index)
                    return
                }
                vm.initializeSelect2('newPra')
            }

            // Function to Evaluate Preliminary Risk
            function evalRisk (severity,likelyhood) {
                let Extreme = ['31','41','51','42','52','53']
                let High = ['21','22','32','33','43','44','54','55']
                let Medium = ['11','12','23','34','45']
                let Low = ['13','14','15','24','25','35']
                let code = `${severity}${likelyhood}`
                let risk = null
                if (Extreme.find(o => o === code)){
                    risk = 3626
                }
                if (High.find(o => o === code)){
                    risk = 3622
                }
                if (Medium.find(o => o === code)){
                    risk = 3627
                }
                if (Low.find(o => o === code)){
                    risk = 3628
                }
                return risk
            }

            //Function to get Score for a given Ref ID
            function getScoreForRisk (ref_id,type) {
                let score = null
                switch(type){
                    case "likelyHood":
                        vm.likelyHoodList.forEach((val, index) => {
                            if (val.rld_id === ref_id){
                                score = val.rld_score
                            }
                        })
                        break;
                    case "severity":
                        vm.severityList.forEach((val, index) => {
                            if (val.rld_id === ref_id){
                                score = val.rld_score
                            }
                        })
                        break; 
                }
                return score
            }

            // Function to Evaluate Preliminary Risk
            vm.evalPrelimRisk = (th_index, ec_index) => {
                let severity = parseInt(getScoreForRisk(vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_severity_preliminary,'severity'))
                let likelyhood = parseInt(getScoreForRisk(vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_likelyhood_preliminary,'likelyHood'))
                if (vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_risk_alara_preliminary !== 0){
                    vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_risk = evalRisk(severity,likelyhood)
                }
                vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_preliminary_risk = evalRisk(severity,likelyhood)
                vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_preliminary_risk_text = translateTag(evalRisk(severity,likelyhood))
            }

            // Function to Evaluate Residual Risk
            vm.evalResidualRisk = (th_index, ec_index) => {
                let severity= parseInt(getScoreForRisk(vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_severity_residual,'severity'))
                let likelyhood = parseInt(getScoreForRisk(vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_likelyhood_residual,'likelyHood'))
                vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_risk = evalRisk(severity,likelyhood)
                vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_residual_risk = evalRisk(severity,likelyhood)
                vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_residual_risk_text = translateTag(vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_residual_risk)

            }

            // Function to change ALARA
            vm.changeALARA = (th_index, ec_index) => {
                if (vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_risk_alara_preliminary === 0){
                    vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_risk = null
                    setTimeout(()=>{
                        vm.initializeTagsAndPulldowns()
                    },100)
                }else{
                    vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_severity_residual = null
                    vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_likelyhood_residual = null
                    vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_risk = vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_preliminary_risk
                    vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_residual_risk = null
                    vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_residual_risk_text = null
                    vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_risk_alara_residual = null
                    vm.currentPra.element_categories[ec_index].threats[th_index].additional_control_measures=[]
                }
                if (vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_risk_alara_preliminary === undefined){
                    vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_risk_alara_preliminary = null
                }
            }

            // Function to change severity category
            vm.changeLabel = (th_index, ec_index) => {
                let risk_label = null
                let risk_Id = vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_risk_category
                vm.riskCategoryList.forEach((val)=>{
                    if (val.rld_id === risk_Id){
                        risk_label = val.rld_name
                    }
                }) 
                vm.currentPra.element_categories[ec_index].threats[th_index].rmm_pth_severity_to_risk_label =  risk_label  
            }

            $scope.fileUploadChanged = (event)=> {

                //Add newly selected files after checking for duplicates and correct file types
                vm.uploadFileList = vm.uploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, []))

                if(vm.uploadFileList.length > 0)
                    addAttachments()
            }

            //Function for the top search bar
            vm.topSearchChanged = () =>{
                vm.praOptions.api.setQuickFilter(vm.topSearch)
            }

            //Function to open archive confirmation Modal
            vm.archiveConfirmationModal = () => {
                let archiveSelectedRecords = vm.praOptions.api.getSelectedRows()
                vm.archiveCount = archiveSelectedRecords.length
                if (vm.archiveCount > 0) {
                    if(!vm.canArchiveSubmissions){
                        for (var i = 0; i < vm.archiveCount; i++) {
                            if(archiveSelectedRecords[i].rmm_pra_state!=="draft" || archiveSelectedRecords[i].rmm_pra_created_by_per_id!==vm.userId){
                                throwToastr('error',translateTag(1456),3000)
                                return
                            }
                        }
                    }

                }
                vm.modalElementsArchive = {
                    title: translateTag(3660), //"Archive PRA?"
                    message: `<div><p>${translateTag(3580)} ${vm.archiveCount} ${translateTag(8349)}</p></div>`, //"You are about to archive X PRA(s). Undoing this will require IT support. Are you sure?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                } 
                document.getElementById('confirmcallingform').innerHTML = 'PRAARCHIVECALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsArchive)
            }

            $scope.$on("PRAARCHIVECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.praArchive()
                }
                else if (result=='button2') {
                    vm.cancelModal('confirmModal')
                }
            })

            //Function to archive the selected rows
            vm.praArchive = () => {
                var rows = vm.praOptions.api.getSelectedRows()
                if (rows.length > 0) {
                    var ids = []

                    for (var i = 0; i < rows.length; i++) {
                        if (rows[i].dlo_status === 'Yes') {
                            ids.push(rows[i].rmm_pra_id)
                        }
                        else{
                            // You cannot Archive while Document is being edited
                            throwToastr('warning',translateTag(9116),2000)
                        }
                    }

                    praService.archivePra(ids).then((r) => {
                        refreshData()
                    })
                }

                modalService.Close('confirmModal')
            }

            // function to reset toastr options
            function resetToastrOptions() {
                toastr.options.progressBar = false,
                toastr.options.positionClass = 'toast-top-right'
                toastr.options.timeOut= "5000"
            }

            //function to throw toastr with time interval
            function throwToastr(type,message,time){
                toastr.options.timeOut = time
                toastr.options.positionClass = 'rmm-toast-custom'
                switch (type) {
                    case 'success':
                        toastr.success(message)
                        break;
                    case 'warning':
                        toastr.warning(message)
                        break;
                    case 'error':
                        toastr.error(message)
                        break;
                    case 'info':
                        toastr.info(message)
                        break;
                }
                resetToastrOptions()
            }

            //Function to open archive confirmation Modal
            vm.copyRevisionConfirmationModal= (mode='') => {
                vm.performActionMode = mode
                var rows = vm.praOptions.api.getSelectedRows()
                vm.selectedRecordCount = rows.length
                if (vm.selectedRecordCount === 0){
                    throwToastr('warning',translateTag(3861),2500)
                    return
                }
                if (vm.selectedRecordCount > 1) {
                    throwToastr('warning',translateTag(3864),2500)
                    return
                }
                if (rows[0].rmm_pra_state === 'draft' && vm.performActionMode==='revision'){
                    throwToastr('error',translateTag(3865),3000)
                    return
                }

                if (vm.selectedRecordCount === 1){
                    vm.selectedDocumentNo = ''
                    let dispTitle = ''
                    if(rows[0].rmm_pra_title){
                        dispTitle = ' - ' + rows[0].rmm_pra_title
                    }
                                 
                    if(rows[0].rmm_pra_revision_no !== ''){
                        vm.selectedDocumentNo = rows[0].rmm_pra_revision_no + dispTitle
                    }
                }

                let duplicateFlag = false
                if ((rows[0].rmm_pra_state === 'active' || rows[0].rmm_pra_state === 'expired') && vm.performActionMode==='revision'){
                    vm.praAGData.forEach((val)=>{
                        if (duplicateFlag)
                            return
                        if (val.rmm_pra_document_number === rows[0].rmm_pra_document_number){
                            if (val.rmm_pra_state === 'review' || val.rmm_pra_state === 'draft'){
                                vm.version_number = `${appendLeadingZeros(val.rmm_pra_document_number)}`+'.'+`${appendLeadingZeros(val.rmm_pra_doc_version_number,3)}`
                                vm.message = translateTag(4316)+" "+val.rmm_pra_state+" "+translateTag(3866)+" ("+ vm.version_number+"). "+translateTag(3867)+" "+val.rmm_pra_state+" "+translateTag(3868)
                                // vm.message = val.rmm_pra_state + ' version of this document already exists with document number '+ vm.version_number
                                throwToastr('error', vm.message, 2500)
                                duplicateFlag = true
                            }
                        }
                    })
                }

                if (!duplicateFlag){
                    vm.modalElementsCopy = {
                        title: capitalizeFirstLetter(vm.performActionMode), //
                        message: 
                        `<div>
                            <p ng-if=${vm.performActionMode==='copy'} note="You are about to make a copy of this Project/Process Risk Assessment. Are you sure?">${translateTag(9534)} ${vm.selectedDocumentNo}. ${translateTag(2257)}</p>
                            <p ng-if=${vm.performActionMode==='revision'} note="You are about to make a revision of this Project/Process Risk Assessment. Are you sure?">${translateTag(9537)} ${vm.selectedDocumentNo}. ${translateTag(2257)}</p>
                        </div>`,
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                    } 
                    document.getElementById('confirmcallingform').innerHTML = 'PRACOPYCALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsCopy)
                }
            }

            $scope.$on("PRACOPYCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.praCopyRevision()
                }
                else if (result=='button2') {
                    vm.cancelModal('confirmModal')
                }
            })

            //Function to copy or revision the selected rows
            vm.praCopyRevision = () => {
                var rows = vm.praOptions.api.getSelectedRows()
                if (rows.length > 0) {              
                    let payload = {}
                    payload.rmm_pra_id =  rows[0].rmm_pra_id
                    payload.mode = vm.performActionMode

                    praService.copyRevisionPra(payload).then((r) => {
                        refreshData()
                    })
                }
                modalService.Close('confirmModal')
            }

            //Funtion to export the selected rows to CSV file
            vm.exportCSV = () => {                
                let rows = JSON.parse(JSON.stringify(vm.praOptions.api.getSelectedRows()))
                exportCSV.export_csv(rows, translateTag(2259))
            }

            //Funtion to open a report in a new tab
            vm.viewReports = (e, id, doc='PRA') =>{
                if(!e.ctrlKey){       
                    lang_number = localStorage.getItem('lang_id')                    
                    if(doc==="PRA"){
                        vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.singleServeReportUrl}/${id}?lang=${lang_number}`)
                    }
                    else if (doc==="BOWTIE"){
                        vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.bowtieReportUrl}/${id}?lang=${lang_number}`)
                    }
                    
                    $window.open(vm.reportURL, "_blank")
                }
            }

            //#region Funtions to convert ID to Name
            vm.getEmployeeName = (value) => {
                let name = value
                vm.fullEmployeeList.forEach((emp)=>{
                    if(emp.per_id == value) {
                       name = emp.per_full_name
                    }
                })
                return name
              }

            function getEmployeeID(value) {
                let nameID = value
                vm.fullEmployeeList.forEach((emp)=>{
                if(emp.per_full_name == value) {
                    nameID = emp.per_id
                }
            })
            return nameID
            }

            function getHapActionTypeName(value) {
                let name = value
                vm.hapActionTypeList.forEach((at)=>{
                    if(at.rld_id == value) {
                    name = at.rld_name
                    }
                })
                return name
            }

            function getActionTypeName(value) {
                let name = value
                vm.actionTypeList.forEach((at)=>{
                if(at.rld_id == value) {
                name = at.rld_name
                }
            })
            return name
            }

            function getActionTypeID(value) {
                let nameID = value
                vm.actionTypeList.forEach((at)=>{
                if(at.rld_name == value) {
                nameID = at.rld_id
                }
            })
            return nameID
            }

            function getSiteName(value) {
                let name = value
                vm.site_name.forEach((s)=>{
                if(s.rld_id == value) {
                    name = s.rld_name
                }
                })
                return name
            }

            function getJobNumber(value) {
                let name = value
                vm.jobList.forEach((j)=>{
                if(j.rld_id == value) {
                    name = j.rld_code
                }
                })
                return name
            }
            //#endregion        

            vm.praOptions = gridService.getCommonOptions()
            vm.praBlueLineOptions = gridService.getCommonOptions()
            vm.attachmentOptions = gridService.getCommonOptions()

            //Function to disable action button if no rows are selected
            vm.praOptions.onSelectionChanged = () => {
                var selectedRows = vm.praOptions.api.getSelectedRows()
                vm.actionDisabled = selectedRows.length == 0
                $scope.$apply()
            }

            vm.attachmentOptions.onSelectionChanged = () => {
                var selectedRows = vm.attachmentOptions.api.getSelectedRows()
                vm.attActionDisabled = selectedRows.length == 0
                $scope.$apply()
            }

            vm.praBlueLineOptions.onSelectionChanged = () => {
                var selectedRows = vm.praBlueLineOptions.api.getSelectedRows()
                vm.blueLineactionDisabled = selectedRows.length == 0
                $scope.$apply()
            }

            //Set Ag-Grid colum values/settings
            let praColumns = [
                {
                    headerName: '',
                    field: 'dummyCheckbox',
                    maxWidth: 50,
                    minWidth: 50,
                    checkboxSelection: true,
                    suppressMenu: true,
                    suppressSorting: true,
                    headerCheckboxSelection: true,
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    field: "review",
                    headerName: " ",
                    minWidth: 125,
                    maxWidth: 125,
                    suppressMenu: true,
                    cellRenderer: (params) => {
                    return `<span ng-show="${params.data.rmm_pra_is_submitted === translateTag(1379)}" ng-click="praCtrl.signoff(data)" class="{{ data.hasReviewed === '${translateTag(1379)}'? 'text-success ' : 'pointer'}}" note="Review Submission" title={{menu.translateLabels(3431)}}><i class="far fa-file-alt fa-lg pr-2""></i></span>` 
                        + `<span class="fa-1x fa-stack" style=" width: 1.25em;" ng-class="{ transparent: ${!vm.canManagePRA}, pointer: ${vm.canManagePRA}}"  ng-show="'${params.data.rmm_pra_state}'==='draft'" ng-click="praCtrl.openViewer('edit', ${params.data.rmm_pra_id})"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title={{menu.translateLabels(1194)}}></i> <i ng-show="${params.data.dlo_status === translateTag(1380)}" class="fas fa-ban fa-stack-1x text-danger" notes="Person is updating the document, please wait." title="${params.data.dlo_person} {{menu.translateLabels(3423)}}"></i></span>`                        
                        + `<span ng-class="{ hidden: ${!vm.canManagePRA}, pointer: ${vm.canManagePRA}}"  ng-show="'${params.data.rmm_pra_state}'==='review'" ng-click="praCtrl.openViewer('view', ${params.data.rmm_pra_id})"><i class="fas fa-lock pr-2 text-primary" note="Review" title={{menu.translateLabels(1188)}}></i></span>`                        
                        + `<span note="Review History" title={{menu.translateLabels(3951)}} class="source signoff-count" ng-class="{ transparent: (!data.reviewedCount > 0 || data.rmm_pra_is_submitted === '{{menu.translateLabels(1380)}}'), pointer: (data.reviewedCount > 0 && data.rmm_pra_is_submitted === '{{menu.translateLabels(1379)}}') }" ng-click="praCtrl.viewAcknowledgeHistory(data);">{{ data.reviewedCount }}</span>`
                        + `<span class="pointer text-left" ng-click="praCtrl.viewReports($event, ${params.data.rmm_pra_id})"><i class="fa fa-external-link-alt" note="Launch Report" title={{menu.translateLabels(3429)}}></i></span>`
                    },
                    valueGetter: function (params) {
                        return params.data.reviewedCount
                    },
                },
                {
                    field: '',
                    hide: true,
                    valueGetter: function (params) {
                        if (params.data.rmm_pra_state === 'draft')
                            return '1_Draft'
                        if (params.data.rmm_pra_state === 'review')
                            return '2_Review'
                        if (params.data.rmm_pra_state === 'active')
                            return '3_Active'
                        if (params.data.rmm_pra_state === 'expired')
                            return '4_Expired'
                    },
                    sort: 'asc',
                },
                {
                    field: "rmm_pra_created_date",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 140,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    sort: 'desc',
                },
                {
                    field: "rmm_pra_created_by_per",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 220,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_pra_expiry_date",
                    headerName: " ",
                    minWidth: 120,
                    maxWidth: 140,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        let expiryDate = new Date(params.data.rmm_pra_expiry_date)
                        let currentDate = new Date()
                        if (expiryDate < currentDate)
                            return '<div style="color: #D20000;">' + params.data.rmm_pra_expiry_date + '</div>'
                        else
                            return '<div>' + params.data.rmm_pra_expiry_date + '</div>'
                      }
                },
                {
                    field: "rmm_pra_title",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 1000,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_pra_site",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_pra_revision_no",
                    headerName: " ",
                    minWidth: 120,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_pra_state",
                    headerName: " ",
                    maxWidth: 120,
                    minWidth: 120,
                    suppressMenu: false,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                    valueGetter: function (params) {
                        return translateStatus(params.data.rmm_pra_state)                        
                    },
                },              
                {field:"hasReviewed", hide:true},
                {field:"participantsList", hide:true},
                {field:"reviewersList", hide:true},
                {field:"reviewedCount", hide:true},
                {field:"rmm_pra_is_submitted", hide:true},
                {field:"rmm_pra_executive_summary", hide:true},
                {field:"rmm_pra_other_participants", hide:true},
                {field:"approversList", hide:true},
                {field:"rmm_pra_revision_no", hide:true},
                {field:"rmm_pra_doc_version_number", hide:true},
                {field:"rmm_pra_document_number", hide:true},
                {field:"rmm_pra_id", hide:true},
                {field:"rmm_pra_date", hide:true},
                {field:"rmm_pra_scope", hide:true},
                {field:"ora_events", hide:true},
                {field:"rmm_pra_workplace", hide:true},
            ]

            vm.praOptions.columnDefs = praColumns
            vm.praOptions.defaultColDef = {
                cellStyle : (params) =>{
                    if(params.data.rmm_pra_state === 'active' || params.data.rmm_pra_state === 'expired' || params.data.rmm_pra_state === 'review'){
                        return { "cursor": "pointer !important"}
                    }
                } 
            }

            vm.praOptions.onCellClicked  = (params) => {
                if(params.column.colDef.field !== 'review' && (params.data.rmm_pra_state === 'active' || params.data.rmm_pra_state === 'expired' || params.data.rmm_pra_state === 'review')){
                    vm.openViewer('view', params.data.rmm_pra_id)
                }
            }

            vm.viewOnlyCheck = () => {
                // For autosave so that the fields do not react to this function
                if(!vm.autoSaveActive) {
                    if(vm.currentPra.rmm_pra_state === 'active' || vm.currentPra.rmm_pra_state === 'expired' || vm.currentPra.rmm_pra_state === 'review' || vm.updatingRecord)
                        return true
                    return false
                }
            }

            //Set Blue Line Ag-Grid colum values/settings
            let blueLineColumns = [
                {
                    field: "event",
                    headerName: 'Applicable line item',
                    rowGroup: true,
                    hide:true,
                    filter: 'agSetColumnFilter',
                    tooltipField: 'event',
                    menuTabs: ['filterMenuTab'],
                },
                {
                    field: "tag",
                    headerName: "Tags",
                    cellStyle: { "white-space": "nowrap !important"},
                    wrapText: true,
                    autoHeight: true,
                    checkboxSelection: true,                    
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    tooltipField: 'tag',
                    
                }
            ]


            // Blue Line
            vm.praBlueLineOptions.columnDefs = blueLineColumns
            vm.praBlueLineOptions.groupSelectsChildren =  true,
            vm.praBlueLineOptions.autoGroupColumnDef = {
                cellRender : 'agGroupCellRenderer',
                headerName: 'Applicable line item',      
                cellStyle: { "white-space": "nowrap !important" },                    
                tooltipValueGetter: function (params) {
                    let count = params.node.allChildrenCount;
                    if (count != null) {
                        return params.value + ' (' + count + ')'
                    }
                    return params.value
                }
            }
            vm.praBlueLineOptions.rowSelection = 'multiple'
            vm.praBlueLineOptions.groupSelectsChildren = true
            vm.praBlueLineOptions.suppressRowClickSelection = true
            vm.praBlueLineOptions.suppressAggFuncInHeader =  true
            vm.praBlueLineOptions.groupDefaultExpanded = -1  

            vm.signoff = (praData) => {
                vm.praDataContext = praData
                if(praData.hasReviewed=== translateTag(1379)) {
                    throwToastr('success', translateTag(3869), 2000)
                    
                }
                else {
                    vm.modalElementsReview = {
                        title: translateTag(3713), //"Project/Process Risk Assessment Review?"
                        message: `<div><p>${translateTag(3634)}</p></div>`, //"You are confirming that you have reviewed this assessment. This cannot be undone. Continue?"
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Review">{{vm.componentTranslateLabels(1188)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                    } 
                    document.getElementById('confirmcallingform').innerHTML = 'PRAREVIEWCALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsReview)
                 }
            }

            $scope.$on("PRAREVIEWCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.addAcknowledge()
                }
                else if (result=='button2') {
                    vm.cancelModal('confirmModal')
                }
            })

            let attachmentColumns = [
                {
                    headerName: '',
                    field: 'dummyCheckbox',
                    maxWidth: 50,
                    minWidth: 50,
                    checkboxSelection: (params) =>{
                        return params.data.rat_pra_show_check_box
                    }, 
                    suppressMenu: true,
                    suppressSorting: true,
                    headerCheckboxSelection: true,
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    //Added the id to the Ag-Grid and hid it. Used to sort the grid to show newest submissions first
                    field: 'rat_id',
                    hide: true,
                    sort: 'desc',
                },
                {
                    field: "rat_created_by_per",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',                    
                },
                {
                    field: "rat_created_date",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rat_file_name",
                    headerName: " ",
                    minWidth: 150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        return `<span class="pointer clip" ng-click='praCtrl.openAttachment(${cleanDoubleCurly(JSON.stringify(params.value))})'><a class="source" href="#" ng-non-bindable>${params.value}</a></span>`
                    }              
                },   
                {
                    field:"comment",
                    headerName:"Comment",
                    minWidth:150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        if(params.data.com_id == null || params.data.com_comment=='' || params.data.com_comment==null){
                            return `<i class="far fa-comment pointer" note="Add Comment" title="{{menu.translateLabels(8921)}}" ng-click='praCtrl.AddComments(${cleanDoubleCurly(JSON.stringify(params.data))})'></i>`
                        } else {
                            return `<i class="fa fa-comment pointer" note="Edit Comment" title="{{menu.translateLabels(9043)}}" ng-click='praCtrl.AddComments(${cleanDoubleCurly(JSON.stringify(params.data))})'></i>`
                        }
                        
                    } 
                }      
            ]

            vm.attachmentOptions.columnDefs = attachmentColumns

            //Funtion to open a attachment file in a new tab
            vm.openAttachment = (name) => {
                vm.attachmentURL =  $sce.trustAsResourceUrl(`${__env.imageUrl}/${name}`)
                $window.open(vm.attachmentURL, "_blank")
            }

            vm.AddComments=(data) =>{
                document.getElementById('mode').innerText = data.com_id
                document.getElementById('comment').value = data.com_comment ? data.com_comment.replaceAll("'","&#39") : null 
                document.getElementById('callingform').innerHTML= 'PRACALLIMAGECOMMENTSMODAL'
                document.getElementById('savetomemory').innerHTML = "false"
                document.getElementById('parentform').innerHTML = vm.mod_id
                document.getElementById('imageid').innerText = data.rat_id  
                document.getElementById('viewOnly').innerText = vm.viewOnlyCheck()
                vm.currentAttachment=data.rat_id 
                document.getElementById('comment_id').innerHTML = data.com_id 
                $rootScope.$broadcast("RECIEVEROFCOMMENTS", data.com_comment ) 
            }
            

            $scope.$on('PRACALLIMAGECOMMENTSMODAL', (event, data) => {
                vm.refreshAttachmentsRowData(data)
            })

            vm.refreshAttachmentsRowData = (data) => {
                let rowData = []
                vm.attachmentOptions.api.forEachNode((node) => rowData.push(node.data))
                rowData.forEach((node) => {
                    if (node.rat_id == vm.currentAttachment) {
                        node.com_comment=data.com_comment
                        node.com_id=data.com_id
                    }
                }) 
                vm.attachmentOptions.api.setRowData(rowData)
            }

            //Function to refresh/get attachment data
            function refreshAttachments (id) {
                if(id)
                {
                    payload = {
                        rmm_id: id,
                        mod_id: vm.mod_id
                    }
                    rmmAttachmentsService.getRmmAttachments(payload).then((response) => {
                        vm.attachmentData = response
                    
                        if (vm.attachmentOptions.api) {
                            translateAgGridHeader (vm.attachmentOptions)
                            vm.attachmentOptions.paginationPageSize = 15
                            vm.attachmentOptions.api.setRowData(prepareAttachmentsGridData(vm.attachmentData))
                            vm.attachmentOptions.api.redrawRows()
                            vm.attachmentOptions.api.sizeColumnsToFit()
                        }
                    })
                }
                else if (vm.attachmentOptions.api) {
                    translateAgGridHeader (vm.attachmentOptions)
                    vm.attachmentOptions.paginationPageSize = 15
                    vm.attachmentOptions.api.setRowData([])
                    vm.attachmentOptions.api.redrawRows()
                    vm.attachmentOptions.api.sizeColumnsToFit()
                }
            }

            function prepareAttachmentsGridData(data) {
                let gridData = JSON.parse(JSON.stringify(data))
                gridData.forEach((rec) =>{
                    rec.exceptionFields = ['rat_enable','rat_rmm_id','rat_mod_id','com_id','rat_id','rat_pra_show_check_box']
                    rec.com_comment = rec.com_comment ? rec.com_comment.replaceAll("'","&#39") : null
                    rec.rat_created_by_per = vm.getEmployeeName(rec.rat_created_by_per)
                    rec.rat_modified_by_per = vm.getEmployeeName(rec.rat_modified_by_per)
                    rec.rat_created_date = moment(rec.rat_created_date).format('YYYY-MM-DD')
                    rec.rat_modified_date = rec.rat_modified_date? moment(rec.rat_modified_date).format('YYYY-MM-DD') : '' 
                    rec.rat_pra_show_check_box = vm.pra_show_check_box
                })
                return gridData
            }

            //Function to add attachments
            function addAttachments (att)            
            {
                if(vm.currentMode === "new") {
                    if (validateFormFields('praForm', true)) {
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentPra)))
                        payload.rmm_pra_is_submitted = false

                        praService.createPra(payload).then((response) => {
                            vm.currentPra.rmm_pra_id = response.rmm_pra_id
                            vm.openViewer('edit', vm.currentPra.rmm_pra_id)
                            resetFormFieldClassList('praForm')
                            let fd = new FormData()
                            for (let i in vm.uploadFileList) {
                                fd.append("rmm_id", vm.currentPra.rmm_pra_id)
                                fd.append("mod_id", vm.mod_id)
                                fd.append("rmm_files", vm.uploadFileList[i])
                            }
                            rmmAttachmentsService.addRmmAttachments(fd).then((res) => {
                                refreshAttachments(vm.currentPra.rmm_pra_id)
                                vm.uploadFileList = []
                            })
                            refreshData()
                            vm.pra_show_check_box = true
                            toastr.success(translateTag(4278)) //Saved Successfully                            
                        })
                    }
                    else{
                        $rootScope.$broadcast("CALLCONFIRMMODAL")
                    }
                }
                else {
                    let fd = new FormData()
                    for (let i in vm.uploadFileList) {
                        fd.append("rmm_id", vm.currentPra.rmm_pra_id)
                        fd.append("mod_id", vm.mod_id)
                        fd.append("rmm_files", vm.uploadFileList[i])
                    }
                    rmmAttachmentsService.addRmmAttachments(fd).then((res) => {
                        refreshAttachments(vm.currentPra.rmm_pra_id)
                        vm.uploadFileList = []
                    })
                }                
            }

            //Function to open delete confirmation Modal
            vm.deleteAttachmentConfirmationModal = () => {
                vm.deleteAttCount = vm.attachmentOptions.api.getSelectedRows().length
                vm.modalElementsDelete = {
                    title: translateTag(3416), //"Delete Attachment?"
                    message: `<div><p>${translateTag(3581)} ${vm.deleteAttCount} ${translateTag(3417)}</p></div>`, //"You are about to delete {{praCtrl.deleteAttCount}} attachments. Undoing this will require IT support. Are you sure?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Yes">{{vm.componentTranslateLabels(1379)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                }
                document.getElementById('confirmcallingform').innerHTML = 'PRADELETEATTACHCALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsDelete)
            }

            $scope.$on("PRADELETEATTACHCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.deleteAttachment()
                }
            })

            //Function to delete the selected attachment rows
            vm.deleteAttachment = () => {
                var rows = vm.attachmentOptions.api.getSelectedRows()
                if (rows.length > 0) {
                var ids = []
                for (var i = 0; i < rows.length; i++) {
                    ids.push(rows[i].rat_id)
                }
                payload={rat_id: ids, mod_id: vm.mod_id}
                rmmAttachmentsService.removeRmmAttachments(payload).then((r) => {
                    refreshAttachments(vm.currentPra.rmm_pra_id)
                })
                }    
                modalService.Close('confirmModal')
            }

            //Function to add/remove an acknowledgment to a pra via the Ag-Grid
            vm.addAcknowledge = () => {
                let payload = {}
                payload.rmm_pra_id = vm.praDataContext.rmm_pra_id
                vm.currentAcknowledge = vm.praDataContext
                    praService.reviewPra(payload).then (() => {
                        refreshData()
                        modalService.Close('confirmModal')
                    })
            }

            //Function to open the Acknowledge History modal
            vm.viewAcknowledgeHistory = (lessData) => {
                if(!lessData.reviewedCount > 0 || !lessData.rmm_pra_is_submitted)
                    return

                vm.currentAcknowledgeHistory = []
                lessData.reviewers.forEach((rev) => {
                    let acknowledgment = {
                        name: vm.getEmployeeName(rev.rmm_pre_per_id),
                        pos : rev.rmm_pre_position_name,
                        reviewed_date: rev.rmm_pre_created_date
                    }
                    vm.currentAcknowledgeHistory.push(acknowledgment)
                })
                $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentAcknowledgeHistory,translateLabels(1297)) //"Reviews"
            }

            //Function to check if the current user has Acknowledged this pra
            function checkAcknowledged (praData) {
            let response = false
            praData.reviewers.forEach((rev) => {
                if(rev.rmm_pre_per_id == vm.userId)
                {
                response = true
                }
            })
            return response
            }

            //Fuction used to close modals
            vm.cancelModal = (modalId) => {
                modalService.Close(modalId)
                vm.initializeSelect2('newPra')
            }

            //function to get PRA ORA Titles
            vm.getPraOraTitles = () => {
                praService.getPraOraList().then((response) => {
                    vm.pra_ora_titles = JSON.parse(JSON.stringify(response))
                })
            }

            vm.siteChange = () =>{
                if(vm.currentPra.rmm_pra_site===null || vm.currentPra.rmm_pra_site===undefined){
                    vm.currentPra.rmm_pra_site = null
                }
                vm.getFilteredEmployees()
            }

            vm.getFilteredEmployees = () => {
                profileService.filterEmployeeListonSite(vm.currentPra.rmm_pra_site)
                vm.employeeList =  profileService.readFilterEmployeeListonJob() 
                profileService.filterRmmApproverEmployeesOnSite(vm.currentPra.rmm_pra_site)
                vm.rmmApproversEmployee = profileService.readFilterApproversList()
            }

            //function to get PRA ORA Event List
            vm.getPraOraEventsList = (id) => {
                if (id!==null && id !== undefined){
                    praService.getPraOraEventsList(id).then((response) => {
                        vm.pra_ora_events_list = JSON.parse(JSON.stringify(response))
                    })
                }else{
                    vm.pra_ora_events_list = []
                    vm.currentPra.rmm_pra_ora = null
                }
                setTimeout(() => {
                    vm.initializeBlueline()                    
                }, 1000);
            }

            //Function for the Blue Line search bar
            vm.blueLineSearchChanged = () =>{
                vm.praBlueLineOptions.api.setQuickFilter(vm.blueLineSearch)
            }
            
            function pushTagstoCMAndCloseModal (unique_tags,ec_index,th_index) {                
                angular.copy(vm.currentPra, vm.currentPra_blueLine)
                unique_tags.forEach((tag)=>{
                    blueLineCMObj = newTag()
                    blueLineCMObj.tag = tag
                    blueLineCMObj.rmm_pta_blueline = true
                    vm.currentPra_blueLine.element_categories[ec_index].threats[th_index].control_measures.push(blueLineCMObj)
                })
                vm.cancelModal('blueLineControlsModal')
                vm.currentPra = Object.assign({}, vm.currentPra_blueLine); 
                return true
            }

            // Function to add tags to control measures
            vm.addTagsToCM = (ec_index,th_index) =>{
                var rows = vm.praBlueLineOptions.api.getSelectedRows()
                if (rows.length > 0) {
                    let unique_tags = []
                    let dupeFlag = false
                    rows.forEach(row => {
                        if (unique_tags.find(tag => tag === row.tag)){
                            dupeFlag = true
                        }
                        if (!dupeFlag){
                            unique_tags.push(row.tag)
                        }else{
                            dupeFlag = false
                        }
                    });
                    $q.all([
                        pushTagstoCMAndCloseModal(unique_tags,ec_index,th_index),
                        setbackAccordian()
                    ]).then(()=>{
                        setTimeout(()=>{
                            vm.initializeTags()
                            setTimeout(() => {
                                vm.initializeBlueline()
                            }, 1000);
                            vm.changesInForm = true
                        },1000)
                    })
                }else{
                    vm.cancelModal('blueLineControlsModal')
                }
            }

            //Function to load Blueline AGGrid Options
            vm.loadAGgridOptions = (AGgridData) => {
                if (vm.praBlueLineOptions.api) {
                    translateAgGridHeader(vm.praBlueLineOptions)
                    vm.praBlueLineOptions.paginationPageSize = 10
                    vm.praBlueLineOptions.api.setRowData(prepareBlackLineControl(AGgridData))
                    vm.praBlueLineOptions.api.redrawRows()
                    vm.praBlueLineOptions.api.sizeColumnsToFit()
                }
                vm.blueLineactionDisabled = true
            }

            function prepareBlackLineControl(AGgridData){
                let data = JSON.parse(JSON.stringify(AGgridData))
                data.forEach((rec) => {
                    rec.exceptionFields = ['']
                    rec.prefix = ''
                    rec.endfix = ''
                    rec.tag = rec.tag
                    rec.event = rec.event  
                })
                return data
            }

            //function to get Bluelines
            vm.getPraBluelines = (data) => {
                var payload = {rmm_oec_id:data}
                if (data!==null && data !== undefined){
                    praService.getBluelinesList(payload).then((response) => {
                        vm.pra_bluelines = JSON.parse(JSON.stringify(response))
                        vm.blueLineAGData = vm.pra_bluelines.rmm_ora_bluelines
                    })
                }else{
                    vm.pra_bluelines = []
                    vm.currentPra.ora_events = []
                }
            }

            //Function to open the viewer
            vm.openViewer = (mode='new', id) => {
                if(!vm.canManagePRA)
                    return

                if(mode !== 'view') {
                    // Start the Autosave
                    vm.autosave = $interval(() => {
                        vm.savePra('autosave')
                        }, 60000)
                }
                vm.getPraOraTitles() 
                if(mode === 'new') {
                    vm.currentMode = 'new'
                    vm.initializeTagsAndPulldowns()
                    destroyTables().then(()=>{
                        initiateTables()
                    })
                    vm.userInApprovers = true
                    vm.hideingPraViewer = false
                    vm.praViewerOpen = true
                    vm.openingPraViewer = true
                    $timeout(() => {
                        vm.openingPraViewer = false
                        $('#newPra').data('serialize',$('#newPra').serialize())
                    }, 400)
                    refreshAttachments()
                }
                else if(mode === 'edit') {
                    vm.documentDetails = {}
                    vm.documentDetails.dlo_document_id = id
                    vm.documentDetails.dlo_dlt_id = 3 //PRA
                    $q.all([
                        documentLockService.docLock(vm.documentDetails)
                    ]).then((response) => {
                        vm.dlo_id = response[0].dlo_id
                        vm.docLockStatus = response[0].status
                        vm.docLockMessage = response[0].message
                        vm.docLockTime = response[0].time
                        if (!vm.docLockStatus){
                            throwToastr('warning',vm.docLockMessage,2000)
                        }   
                    }).then(() => {
                        if(vm.docLockStatus === true){
                            $scope.$emit('STARTSPINNER', translateTag(3880))
                            vm.currentMode = 'edit'
                            vm.saved = true
                            toastr.options.progressBar = true
                            vm.getSingleDetailRec(id).then(() => {
                                vm.initializeTagsAndPulldowns()
                                vm.validateCurrentUserInApprovers()
                                vm.hideingPraViewer = false
                                vm.praViewerOpen = true
                                vm.openingPraViewer = true
                                if(!vm.currentPra.rmm_pra_is_submitted){
                                    vm.pra_show_check_box = true
                                }
                                refreshAttachments(vm.currentPra.rmm_pra_id)
                                $timeout(() => {
                                    vm.openingPraViewer = false
                                    $('#newPra').data('serialize',$('#newPra').serialize())
                                    $scope.$emit('STOPSPINNER')
                                }, 400)
                            })
                            startUpdateDocLock()
                            startLockModal()

                            //Zero the idle timer on mouse movement.
                            $('#newPra').mousemove(function (e) {
                                clearInterval(vm.lockModal)                
                                vm.idletime = 0
                                startLockModal()
                            });

                            //Zero the idle timer on keypres event
                            $('#newPra').keypress(function (e) {
                                clearInterval(vm.lockModal)
                                vm.idletime = 0
                                startLockModal()
                            });
                        }
                    })
                    
                }
                else if(mode === 'view') {
                    vm.changesInForm = false
                    $scope.$emit('STARTSPINNER', translateTag(3880))
                    vm.getSingleDetailRec(id).then(() => {
                        vm.initializeTagsAndPulldowns()
                        vm.validateCurrentUserInApprovers()
                        vm.hideingPraViewer = false
                        vm.praViewerOpen = true
                        vm.openingPraViewer = true
                        refreshAttachments(vm.currentPra.rmm_pra_id)
                        $timeout(() => {
                            $scope.$emit('STOPSPINNER')
                        }, 400)
                    })
                }
            }

            // functions for document lock start___            

            vm.continueEditingPra = () => {
                vm.cancelModal('confirmModal')
                document.getElementById('inactiveTime').textContent =  ''
                vm.countdownSeconds = 60
                vm.lockCheckModal = false
                vm.continueEditing = true
                clearInterval(vm.lockModal)
                clearInterval(vm.countdownTimer)
                clearTimeout(vm.relieveLock)
                vm.idletime = 0
                startLockModal()
            }

            function startUpdateDocLock(){
                vm.updateDocLockInterval = setInterval(() => {
                    $q.all([
                        documentLockService.intervalDocLock(vm.dlo_id)
                    ])
                }, 30 * 1000)
            }

            function startLockModal(){
                vm.lockModal = setInterval(() => {
                    vm.idletime = vm.idletime + 1 // 1 minute
                    if(vm.idletime === 5){ // after 5 minutes of idle time open lockcheck modal
                        vm.continueEditing = false
                        vm.leaveEditing = false
                        vm.modalElementsLock = {
                            title: translateTag(3419),   //"Page inactive for 5 minutes" 
                            message: `<div style="text-align: center;"><h1 id ="inactiveTime" ></h1><p> ${translateTag(3420)}</p></div>`,  //"The entry will automatically save and close if no action is taken"
                            buttons: 
                                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Continue Working">{{vm.componentTranslateLabels(3421)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Save and Close">{{vm.componentTranslateLabels(3422)}}</button>`
                        }
                        document.getElementById('confirmcallingform').innerHTML = 'PRALOCKCALLCONFIRMMODAL' 
                        $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsLock)     
                        vm.lockCheckModal = true
                        startcountdownTimer()
                        vm.relieveLock = setTimeout(() => {
                            if (vm.lockCheckModal === true){
                                if (!vm.continueEditing && !vm.leaveEditing){
                                    vm.leaveEditing = true
                                    vm.saveAndClosePra()
                                }
                            }
                        }, 60 * 1000);
                    }                                        
                }, 60 * 1000);
            }

            $scope.$on("PRALOCKCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.continueEditingPra()
                }
                else if (result=='button2') {
                    vm.saveAndClosePra()
                }
            })

            function startcountdownTimer(){
                vm.countdownTimer = setInterval(() => {
                    if(vm.lockCheckModal === true && vm.countdownSeconds>=0){
                        vm.contect = ''
                        if (vm.countdownSeconds === 60){
                            vm.content = "01:00"
                        }
                        else{
                            vm.content = "00:" + vm.countdownSeconds.toLocaleString('en-US', {
                                minimumIntegerDigits: 2,
                                useGrouping: false
                              }) 
                        }
                        document.getElementById('inactiveTime').textContent =  vm.content
                        vm.countdownSeconds = vm.countdownSeconds - 1   
                    }                                       
                }, 1000)
            }

            // functions for document lock end___

            // An abstrect function to initialize the dropdowns and tags
            vm.initializeTagsAndPulldowns = () =>{
                vm.initializeSelect2('newPra')
                vm.initializeTags()
                setTimeout(() => {
                    vm.initializeBlueline()
                }, 1000); 
            }

            // function to get single detail record
            vm.getSingleDetailRec = (id) =>{
                vm.tmpDeletedElements = []
                vm.tmpDeletedThreats = []
                return (
                    $q.all([
                        praService.getPraSIngleDetailRec(id).then((response) => {
                            vm.currentPra = JSON.parse(JSON.stringify(response))
                            vm.prepResponseSingleDetail()
                        }),
                        praService.praBowtie(id).then((response) => {
                            vm.pra_bowties = JSON.parse(JSON.stringify(response))
                        })
                    ])
                )
            }

            // An abstrect function to prepare response payload for single detail record
            vm.prepResponseSingleDetail = () =>{
                vm.currentPra.approversList = []
                angular.copy(vm.currentPra.approvers,vm.currentPra.approversList)
                vm.currentPra.approvers = getApprovers(vm.currentPra.approvers)
                vm.currentPra.rmm_pra_created_date = moment(vm.currentPra.rmm_pra_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                vm.currentPra.rmm_pra_date = vm.currentPra.rmm_pra_date===null?null:moment(vm.currentPra.rmm_pra_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                vm.currentPra.rmm_pra_expiry_date = vm.currentPra.rmm_pra_expiry_date===null?null:moment(vm.currentPra.rmm_pra_expiry_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                vm.getPraOraEventsList(vm.currentPra.rmm_pra_ora)
                if (vm.currentPra.ora_events !== [] || vm.currentPra.ora_events.length > 0){
                    vm.getPraBluelines(vm.currentPra.ora_events)
                }
                if(vm.currentPra.rmm_pra_site){
                    vm.getFilteredEmployees()
                }
                vm.currentPra.element_categories.forEach((ec)=>{
                    ec.threats.forEach((th)=>{

                        th.rmm_pth_residual_risk_text = translateTag(th.rmm_pth_residual_risk)
                        th.rmm_pth_preliminary_risk_text = translateTag(th.rmm_pth_preliminary_risk)

                        th.rmm_pth_severity_to_risk_label = null
                        vm.changeLabel(ec.threats.indexOf(th), vm.currentPra.element_categories.indexOf(ec))
                        if (th.rmm_pth_risk_alara_preliminary!==null){
                            th.rmm_pth_risk_alara_preliminary = th.rmm_pth_risk_alara_preliminary === true ? 1 : 0
                        }
                        if (th.rmm_pth_risk_alara_residual!==null){
                            th.rmm_pth_risk_alara_residual = th.rmm_pth_risk_alara_residual === true ? 1 : 0
                        }                        
                        if(th.rmm_pth_require_bowtie!==null){
                            th.rmm_pth_require_bowtie = th.rmm_pth_require_bowtie === true ? 1 : 0
                        }
                        th.rmm_pth_risk = th.rmm_pth_risk_alara_preliminary === 0 ? th.rmm_pth_residual_risk : th.rmm_pth_preliminary_risk
                    })
                })
                vm.rmm_pra_doc_revision_no = `${appendLeadingZeros(vm.currentPra.rmm_pra_document_number)}`+'.'+`${appendLeadingZeros(vm.currentPra.rmm_pra_doc_version_number,3)}`
                vm.uneditedCurrentPra = []
                angular.copy(vm.currentPra, vm.uneditedCurrentPra);
                vm.refreshActions(vm.currentPra.rmm_pra_id)
            }

            //Function to refresh the action data
            vm.refreshActions = (id) => {
                payload = {
                    rmm_pra_id: id
                }
                $q.all([
                    praService.getGaHaActions(payload).then((response) => {
                        vm.currentPra.general_actions = actionManagementService.addCanCloseActionPermission(response.general_actions, 'general', vm.canCloseAllActions, vm.userId)
                        vm.currentPra.hazard_actions = actionManagementService.addCanCloseActionPermission(response.hazard_actions, 'hazard', vm.canCloseAllActions, vm.userId)
                        vm.immediateActions()
                    })
                ]).then(()=>{
                    destroyTables().then(()=>{
                        initiateTables()
                    })
                })
            }

            vm.immediateActions = () =>{
                vm.currentPra.hazard_actions.forEach((data)=>{
                    if(!data.further_action_required && data.immediate_action_required_and_performed) {
                        data.action_complete_by_who = data.created_by
                        data.recommended_action = data.immediate_action_taken
                        data.action_by_when = moment(data.sha_created_date).format('YYYY-MM-DD')
                    }
                })
            }

            //Function to force close the viewer
            vm.forceCloseViewer = () => {
                vm.cancelModal('confirmModal')                
                vm.cancelModal('signPraSuccessModal')
                vm.cancelModal('signPraFailureModal')
                vm.employeeList = []
                vm.releaseDocument(vm.dlo_id)
                clearInterval(vm.updateDocLockInterval)
                clearInterval(vm.lockModal)
                clearInterval(vm.countdownTimer)
                // Stop the autoSave
                $interval.cancel(vm.autosave)
                vm.hideingPraViewer = true
                vm.resetForm()
                refreshData()
                $timeout(() => {
                    vm.praViewerOpen = false
                }, 400)
            }

            //Function to close the viewer
            vm.closeViewer = () => {
                hasFormChanged()
                if (!vm.currentUserSigned){
                    if (vm.changesInForm && !vm.openingPraViewer == true){
                        vm.modalElementsChange = {
                            title: translateTag(2273), //"Confirm Changes"
                            message: `<div><p>${translateTag(2274)}</p></div>`, //"Any unsaved changes made on this document would be lost! Do you want to proceed ?"
                            buttons: 
                                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="SAVE & CLOSE">{{vm.componentTranslateLabels(2276)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note= "CLOSE ANYWAY">{{vm.componentTranslateLabels(2275)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button3')" note= "Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                        }
                        document.getElementById('confirmcallingform').innerHTML = 'PRACHANGECALLCONFIRMMODAL' 
                        $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsChange)
                        return
                    }
                }

                vm.releaseDocument(vm.dlo_id)
                clearInterval(vm.updateDocLockInterval)
                clearInterval(vm.lockModal)
                           
                vm.cancelModal('signPraSuccessModal')
                vm.cancelModal('signPraFailureModal')
                // Stop the Autosave
                $interval.cancel(vm.autosave)
                clearInterval(vm.countdownTimer)
                vm.hideingPraViewer = true
                vm.resetForm()
                refreshData()
                $timeout(() => {
                    vm.praViewerOpen = false
                }, 400)
            }

            $scope.$on("PRACHANGECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.saveAndClosePra()
                }
                else if (result=='button2') {
                    vm.forceCloseViewer()
                }
                else if (result=='button3') {
                    vm.cancelModal('confirmModal')
                }
            })

            // function to release document lock
            vm.releaseDocument = (id) => {
                payload = {}
                payload.dlo_id = id
                return (
                    $q.all([
                        documentLockService.closeDocLock(payload)
                    ])
                )
            }

            //Function to open modals
            vm.openModal = (modalId) => {
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()

                $('.modal .scroll').scrollTop(0)

                modalService.Open(modalId)
                vm.initializeSelect2(modalId, '.modal-body')
            }

            // Function to open Blue line control modal
            vm.openBlueLineControlModal = (th_index,ec_index) => {
                if (vm.currentPra.ora_events === [] || vm.currentPra.ora_events === undefined || vm.currentPra.ora_events === null) {
                    throwToastr('error',translateTag(3855),2000)
                    return
                }
                if (vm.currentPra.ora_events.length === 0) {
                    throwToastr('error',translateTag(3855),2000)
                    return
                }
                var payload = {rmm_oec_id:vm.currentPra.ora_events}
                praService.getBluelinesList(payload).then((response) => {
                    vm.pra_bluelines = JSON.parse(JSON.stringify(response))
                    vm.blueLineAGData = vm.pra_bluelines.rmm_ora_bluelines
                    setTimeout(() => {
                        getShowAccordianIds()
                    }, 500);
                    vm.blueLine_ec_index = ec_index
                    vm.blueLine_th_index = th_index
                    vm.current_blueline = []
                    angular.copy(vm.blueLineAGData,vm.current_blueline)
                    vm.currentPra.element_categories[ec_index].threats[th_index].control_measures.forEach((cm)=>{
                        let new_blueLine = []
                        for (let i = 0; i < vm.current_blueline.length; i++) {
                            if(cm.tag.trim().toLowerCase() !== vm.current_blueline[i].tag.trim().toLowerCase()){
                                new_blueLine.push(vm.current_blueline[i])                             
                            }
                        }
                        vm.current_blueline = new_blueLine
                    })
                    vm.loadAGgridOptions(vm.current_blueline)
                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()
                    $('.modal .scroll').scrollTop(0)
                    modalService.Open("blueLineControlsModal")
                    vm.initializeSelect2("blueLineControlsModal", '.modal-body')
                })
            }
 
            //Function to open the create action modals
            vm.openActionModal = (modalId) => {
                resetFormFieldClassList('praForm')
                if (validateFormFields('praForm', true)){
                    vm.actionMode = 'new'
                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()
                    $('.modal .scroll').scrollTop(0)
                
                    if(vm.currentMode === "new") {                                                        // Save the Document before opening an action modal
                        vm.currentMode = 'edit'
                        $scope.$emit('STARTSPINNER', translateTag(3881))
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentPra)))
                        payload.rmm_pra_is_submitted = false
                        vm.updatingRecord = true
                        toastr.options.progressBar = true
                        praService.createPra(payload).then((response) => {
                            if (response.rmm_pra_id){
                                vm.getSingleDetailRec(response.rmm_pra_id).then(() => {
                                    $q.all([
                                        vm.initializeTagsAndPulldowns()
                                    ]).then((data) => {
                                        vm.rmm_pra_doc_revision_no = `${appendLeadingZeros(vm.currentPra.rmm_pra_document_number)}`+'.'+`${appendLeadingZeros(vm.currentPra.rmm_pra_doc_version_number,3)}`
                                        vm.validateCurrentUserInApprovers()
                                        $('#newPra').data('serialize',$('#newPra').serialize())
                                        resetFormFieldClassList('praForm')
                                        modalService.Open(modalId)
                                        vm.initializeSelect2(modalId, '.modal-body')
                                        $scope.$emit('STOPSPINNER')
                                    })
                                })
                                refreshData()
                            }
                            if (!response){
                                throwToastr('error', translateTag(3857), 2000)
                            }
                            vm.updatingRecord = false
                        })
                    }
                    else{
                        modalService.Open(modalId)
                        vm.initializeSelect2(modalId, '.modal-body')
                    }
                }else{
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            //Function to open the edit action modals
            vm.openActionEditModal = (modalId, id) => {
                vm.actionMode = 'edit'
                if(modalId === 'generalActionModal') {
                    openGeneralEdit(id, modalId)
                    vm.refreshActions(vm.currentPra.rmm_pra_id)
                }
                else if(modalId === 'hazardActionModal') {
                    openHazardEdit(id, modalId)
                    vm.refreshActions(vm.currentPra.rmm_pra_id)
                }
            }

            //Function to prepare data to edit a general action
            function openGeneralEdit(id, modalId) {
                actionManagementService.getGeneralActionSingle({sga_id: id}).then ((response) => {
                    vm.generalEditData = response

                    vm.generalEditData.Site = parseInt(vm.generalEditData.Site)
                    vm.generalEditData.JobNumber = parseInt(vm.generalEditData.JobNumber)
                    vm.generalEditData.SiteLevel = parseInt(vm.generalEditData.SiteLevel)
                    vm.generalEditData.Supervisor = parseInt(vm.generalEditData.Supervisor)

                    vm.generalEditData.HeaderDate = moment(vm.generalEditData.HeaderDate).format('YYYY-MM-DD')
                    vm.generalEditData.sga_action_by_who_per_id = vm.generalEditData.sga_action_by_who_per

                    let i = 0
                    let initialAtt = JSON.parse(JSON.stringify(vm.generalEditData.attachments))
                    initialAtt.forEach((att) => {
                        if(att.gaa_type === 'FOLLOWUP')
                            vm.generalEditData.attachments.splice(i, 1)
                        else
                            i++
                    })
                    
                    vm.generalEditData.attachments.forEach((att) => {
                        att.imageDir = `${__env.imageUrl}/`
                    })

                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()

                    $('.modal .scroll').scrollTop(0)

                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId, '.modal-body')
                })
            }

            //Function to prepare data to edit a hazard action
            function openHazardEdit(id, modalId) {
                actionManagementService.getHazardActionSingle({hap_id: id}).then ((response) => {
                    vm.hazardEditData = response

                    vm.hazardEditData.Site = parseInt(vm.hazardEditData.Site)
                    vm.hazardEditData.JobNumber = parseInt(vm.hazardEditData.JobNumber)
                    vm.hazardEditData.SiteLevel = parseInt(vm.hazardEditData.SiteLevel)
                    vm.hazardEditData.Supervisor = parseInt(vm.hazardEditData.Supervisor)

                    vm.hazardEditData.HeaderDate = moment(vm.hazardEditData.HeaderDate).format('YYYY-MM-DD')

                    let i = 0
                    let initialAtt = JSON.parse(JSON.stringify(vm.hazardEditData.attachments))
                    initialAtt.forEach((att) => {
                        if(att.attachmenttype === 'FOLLOWUP')
                            vm.hazardEditData.attachments.splice(i, 1)
                        else
                            i++
                    })
                    
                    vm.hazardEditData.attachments.forEach((att) => {
                        att.imageDir = `${__env.imageUrl}/`
                    })

                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()

                    $('.modal .scroll').scrollTop(0)

                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId, '.modal-body')
                })
            }

            //Function to open the complete action modals
            vm.completeActionModal = (action, type) => {
                if(type === 'General')
                {
                    actionManagementService.getGeneralActionSingle({sga_id: action.sga_id}).then ((response) => {
                        vm.generalFollowup = response
                        vm.generalFollowup.sga_completed_action_date = dateToday.format('YYYY-MM-DD')
                        vm.generalFollowup.sga_action_by_who_per_id = vm.getEmployeeName(vm.generalFollowup.sga_action_by_who_per)
                        if(vm.generalFollowup.sga_completed_action_by_who_per != null)
                            vm.generalFollowup.sga_completed_action_by_who_per_id = parseInt(getEmployeeID(vm.generalFollowup.sga_completed_action_by_who_per))
                        vm.generalFollowup.attachment_files_initial = []
                        vm.generalFollowup.attachment_files_followup = []

                        vm.generalFollowup.attachments.forEach((attRec) => {
                            if(attRec.gaa_type == 'INITIAL')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                vm.generalFollowup.attachment_files_initial.push(attRec)
                            }
                            else if(attRec.gaa_type == 'FOLLOWUP')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                vm.generalFollowup.attachment_files_followup.push(attRec)
                            }
                        })

                        vm.openModal('completeGeneralActionModal')
                        setTimeout(()=>{
                            $scope.$broadcast('GENERAL_FOLLOWUP_OPENED')
                        },100) 
                    })
                }
                else
                {
                    actionManagementService.getHazardActionSingle({hap_id: action.id}).then ((response) => {
                        vm.followup = response
                        vm.followup.action_completed_date = dateToday.format('YYYY-MM-DD')
                        vm.followup.action_complete_by_who = (vm.followup.action_complete_by_who && vm.followup.action_complete_by_who != 'None') ? parseInt(getEmployeeID(vm.followup.action_complete_by_who)) : null
                        vm.followup.attachmentModalFiles = []
                        vm.followup.followupAttachmentModalFiles = []

                        vm.followup.attachments.forEach((attRec) => {
                            if(attRec.attachmenttype === 'INITIAL')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                attRec.AttachmentFileName = attRec.attachmentfilename
                                vm.followup.attachmentModalFiles.push(attRec)
                            }
                            else if(attRec.attachmenttype === 'FOLLOWUP')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                attRec.AttachmentFileName = attRec.attachmentfilename
                                vm.followup.followupAttachmentModalFiles.push(attRec)
                            }
                        })

                        vm.followup.HapId = action.id
                        vm.followup.action_by_who_name = vm.getEmployeeName(action.action_by_who)

                        vm.openModal('hapFollowupComponent')
                        setTimeout(()=>{
                            $scope.$broadcast('HAZARD_FOLLOWUP_OPENED')
                        },100)
                    })
                }
            }
            
            //Function to validate for Sign modal
            vm.validateForSign = () => {
                vm.noOfExtremes = 0
                vm.noOfHighs = 0
                vm.noOfRiskAlara = 0
                vm.noOfHaps = 0
                vm.signFlag = true
                vm.currentPra.element_categories.forEach((ec)=>{
                    ec.threats.forEach((th)=>{
                        if (th.rmm_pth_risk_alara_preliminary === 0){
                            if (th.rmm_pth_risk_alara_residual === 0){
                                vm.noOfRiskAlara += 1
                                vm.signFlag = false
                            }
                        }
                        if (th.rmm_pth_risk == 3626){
                            vm.noOfExtremes += 1
                        }
                        if (th.rmm_pth_risk == 3622){
                            vm.noOfHighs += 1
                        }
                    })
                })
                vm.currentPra.hazard_actions.forEach((hap)=> {
                    if (hap.action_status !== 1){
                        vm.noOfHaps += 1
                        vm.signFlag = false
                    }
                })
                return vm.signFlag
            }

            vm.validateBowtiePra = () => {
                return new Promise(resolve =>{
                    praService.validateBowtiePra(vm.currentPra.rmm_pra_id).then((response) => {
                        vm.validateBowtie = response.validate_bowtie
                        vm.missing_bowtie = response.missing_bowtie
                         resolve(vm.validateBowtie)
                    })
                })
                
            }

            // Function to verify if form has changed
            function hasFormChanged() {
                if($('#newPra').serialize() != $('#newPra').data('serialize')){
                    $('#newPra').data('serialize',null)
                    vm.changesInForm = true
                }
            }

            //Function to open the complete action modals
            vm.signActionModal = () => {
                hasFormChanged()
                if (vm.changesInForm) {
                    vm.savePra("save")
                }
                vm.validatePra().then((res)=>{
                    vm.validateBowtiePra().then((data) =>{
                        if(res.val && res.chip){
                            let checkValidateSign = vm.validateForSign()
                            let checkValidateBowtie = data
                            if (checkValidateSign && checkValidateBowtie){
                                vm.currentUserSigned = false
                                vm.currentPra.approversList.forEach((app) => {
                                    if (app.rmm_pap_per === vm.userId && app.rmm_pap_approved){
                                        vm.currentUserSigned = true 
                                    }
                                })
                                vm.openModal('signPraSuccessModal')
                            } else {
                                vm.openModal('signPraFailureModal')
                            }
                        } else {
                            if(!res.val){
                                $rootScope.$broadcast("CALLCONFIRMMODAL")
                            }
    
                        }
                    })
                    
                })
            }

            // Function to validate approvers for sign
            vm.validateCurrentUserInApprovers = () => {
                vm.userInApprovers = false
                if (vm.currentPra.approvers) {
                    if (vm.currentPra.approvers.length > 0){
                        vm.currentPra.approvers.forEach((app) => {
                            if (app === vm.userId){
                                vm.userInApprovers = true
                                return
                            }
                        })
                    }
                }
            }

            //Function to save the Pra
            vm.savePra = () => {
                resetFormFieldClassList('praForm')
                if (validateFormFields('praForm', true)){
                    // for autosave so that is does not show the spinner
                    if (mode === 'all') {
                        $scope.$emit('STARTSPINNER', translateTag(3882))
                    }
                    else {
                        vm.autoSaveActive = true
                    }

                    $('#newPra').data('serialize',$('#newPra').serialize())
                    vm.changesInForm = false 
                    if(vm.currentMode === "new") {
                        vm.updatingRecord = true
                        vm.saved = true
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentPra)))
                        payload.rmm_pra_is_submitted = false
                        praService.createPra(payload).then((response) => {
                            if (response.rmm_pra_id){
                                // for Auto Save to not interupt the user with refreshing
                                if(mode === 'all') {
                                    vm.getSingleDetailRec(response.rmm_pra_id).then(() => {
                                        $q.all([
                                            vm.initializeTagsAndPulldowns()
                                        ]).then((data) => {
                                            vm.rmm_pra_doc_revision_no = `${appendLeadingZeros(vm.currentPra.rmm_pra_document_number)}`+'.'+`${appendLeadingZeros(vm.currentPra.rmm_pra_doc_version_number,3)}`
                                            vm.validateCurrentUserInApprovers()
                                            refreshData()
                                            vm.updatingRecord = false
                                            $scope.$emit('STOPSPINNER')
                                        })
                                    })
                                }
                                else {
                                    // Update everything needed for the AG- Grid - Autosave
                                    reloadAutoSave(response.rmm_pra_id)
                                }
                            }
                            else {
                                vm.updatingRecord = false
                            }
                            if (!response){
                                throwToastr('error', translateTag(3857), 2000)
                            }
                        })
                    }
                    else{

                        vm.updatingRecord = true
                        let payload = preparePayload('edit', JSON.parse(JSON.stringify(vm.currentPra)))
                        if(mode === 'all'){
                            $scope.$emit('STARTSPINNER',translateTag(3882))
                            payload.rmm_pra_is_submitted = false
                        }
                        vm.tmpDeletedElements = []
                        vm.tmpDeletedThreats = []
                        praService.updatePra(payload).then((response) => {
                            if (response.rmm_pra_id){
                                // for Auto Save to not interupt the user with refreshing
                                if(mode === 'all') {
                                    vm.getSingleDetailRec(response.rmm_pra_id).then(() => {
                                        $q.all([
                                            vm.initializeTagsAndPulldowns()
                                        ]).then((data) => {
                                            vm.rmm_pra_doc_revision_no = `${appendLeadingZeros(vm.currentPra.rmm_pra_document_number)}`+'.'+`${appendLeadingZeros(vm.currentPra.rmm_pra_doc_version_number,3)}`
                                            vm.validateCurrentUserInApprovers()
                                            refreshData()
                                            vm.updatingRecord = false
                                            $scope.$emit('STOPSPINNER')
                                        })
                                    })
                                }
                                else {
                                    // Update everything needed for the AG- Grid - Autosave
                                    reloadAutoSave(response.rmm_pra_id)
                                }
                            }
                            if (!response){
                                throwToastr('error', translateTag(3858), 2000)
                            }
                        })
                    }
                }else{
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            function reloadAutoSave(id) {
                // Update everything needed for the AG- Grid - Autosave
                praService.getPraSIngleDetailRec(id).then((res) => {
                    vm.currentPra.approversList = []
                    angular.copy(res.approvers,vm.currentPra.approversList)
                    vm.currentPra.approvers = getApprovers(res.approvers)
                    vm.currentPra.rmm_pra_id =  res.rmm_pra_id
                    vm.currentPra.rmm_pra_state =  res.rmm_pra_state
                    vm.currentPra.rmm_pra_doc_version_number = res.rmm_pra_doc_version_number
                    vm.currentPra.rmm_pra_document_number = res.rmm_pra_document_number
                    // Loop through all the data and update the ID/s
                    vm.currentPra.element_categories.forEach((cat,catindex) => {
                        if(res.element_categories[catindex]){
                            cat.rmm_pec_id = res.element_categories[catindex].rmm_pec_id
                            cat.rmm_pec_pra = res.element_categories[catindex].rmm_pec_pra
                            cat.rmm_pec_sort = res.element_categories[catindex].rmm_pec_sort
                        }
                        cat.threats.forEach((evt, thrindex) => {
                            if(res.element_categories[catindex].threats[thrindex]) {
                                evt.rmm_pth_id = res.element_categories[catindex].threats[thrindex].rmm_pth_id
                                evt.rmm_pth_pec = res.element_categories[catindex].threats[thrindex].rmm_pth_pec
                            }
                            evt.control_measures.forEach((cm, cmindex)=>{
                                if(res.element_categories[catindex].threats[thrindex].control_measures[cmindex]){
                                    cm.rmm_pta_id = res.element_categories[catindex].threats[thrindex].control_measures[cmindex].rmm_pta_id
                                    cm.rmm_pta_created_by_per = res.element_categories[catindex].threats[thrindex].control_measures[cmindex].rmm_pta_created_by_per
                                    cm.rmm_pta_enable = res.element_categories[catindex].threats[thrindex].control_measures[cmindex].rmm_pta_enable
                                    cm.rmm_pta_parent_tag_name = res.element_categories[catindex].threats[thrindex].control_measures[cmindex].rmm_pta_parent_tag_name
                                    cm.rmm_pta_pth = res.element_categories[catindex].threats[thrindex].control_measures[cmindex].rmm_pta_pth
                                }
                            })
                            evt.additional_control_measures.forEach((acm, acmindex) => {
                                if(res.element_categories[catindex].threats[thrindex].additional_control_measures[acmindex]) {
                                    acm.rmm_pta_id = res.element_categories[catindex].threats[thrindex].additional_control_measures[acmindex].rmm_pta_id
                                    acm.rmm_pta_created_by_per = res.element_categories[catindex].threats[thrindex].additional_control_measures[acmindex].rmm_pta_created_by_per
                                    acm.rmm_pta_enable = res.element_categories[catindex].threats[thrindex].additional_control_measures[acmindex].rmm_pta_enable
                                    acm.rmm_pta_parent_tag_name = res.element_categories[catindex].threats[thrindex].additional_control_measures[acmindex].rmm_pta_parent_tag_name
                                    acm.rmm_pta_pth = res.element_categories[catindex].threats[thrindex].additional_control_measures[acmindex].rmm_pta_pth
                                }
                            })
                        })
                    })
                    vm.rmm_pra_doc_revision_no = `${appendLeadingZeros(vm.currentPra.rmm_pra_document_number)}`+'.'+`${appendLeadingZeros(vm.currentPra.rmm_pra_doc_version_number,3)}`
                    vm.validateCurrentUserInApprovers()
                    vm.updatingRecord = false
                    vm.uneditedCurrentPra = []
                    angular.copy(vm.currentPra, vm.uneditedCurrentPra)
                })
            }

            //Function to save and close the PRA
            vm.saveAndClosePra = () => {
                $interval.cancel(vm.autosave)
                vm.cancelModal('confirmModal')
                vm.savePra()
                setTimeout(()=>{
                    vm.forceCloseViewer()
                },4700)  
            }

            //Function to sign the PRA
            vm.signPra = (modalId) => {
                if(validateText(vm.currentPra.rmm_pra_executive_summary,"")) {
                    $scope.$emit('STARTSPINNER', translateTag(3883))
                    payload = {
                        rmm_pra_id: vm.currentPra.rmm_pra_id,
                        rmm_pra_executive_summary: vm.currentPra.rmm_pra_executive_summary ? vm.currentPra.rmm_pra_executive_summary : ""
                    }
                    vm.cancelModal(modalId)
                    vm.currentUserSigned = true
                    praService.signPra(payload).then((response) => {
                        // Stop the Autosave
                        $interval.cancel(vm.autosave)
                        vm.autoSaveActive = false
                        if (response.message === "Document Signed"){
                            vm.currentUserSigned = true
                            vm.currentPra.rmm_pra_state = response.rmm_pra_state
                            vm.currentPra.approversList.forEach((app) => {       
                                if (app.rmm_pap_per === vm.userId){
                                    app.rmm_pap_approved = true         //Setting the approved flag of current approver to true
                                }
                            })
                        }
                        refreshData()
                        $scope.$emit('STOPSPINNER')
                    })
                }
                else{
                    document.getElementById('rmm_pra_executive_summary').classList.add('invalid')
                    document.getElementById('rmm_pra_executive_summary').setCustomValidity(false)
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            //Function to prepare payload data
            function preparePayload(mode='new', payload) {
                let preparedPayload = payload
                if (mode === "new"){
                    preparedPayload.rmm_pra_state = 'draft'
                    preparedPayload.rmm_pra_created_date = moment(payload.rmm_pra_created_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_pra_date = (preparedPayload.rmm_pra_date===null || preparedPayload.rmm_pra_date===undefined)?null:moment(payload.rmm_pra_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_pra_expiry_date = (preparedPayload.rmm_pra_expiry_date===null || preparedPayload.rmm_pra_expiry_date===undefined)?null:moment(payload.rmm_pra_expiry_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    
                    payload.element_categories.forEach((ec, index) => {
                        ec.threats.forEach((th, index) => {
                            tmp_cm = []
                            tmp_additional = []
                            th.control_measures.forEach((val, index) => {
                                newCMObj = newTag()
                                newCMObj.tag = val.tag
                                newCMObj.rmm_pta_blueline = val.rmm_pta_blueline
                                tmp_cm.push(newCMObj)
                            })
                            th.additional_control_measures.forEach((val, index) => {
                                newAdditionalCMObj = newTag()
                                newAdditionalCMObj.tag = val.tag
                                tmp_additional.push(newAdditionalCMObj)
                            })
                            th.control_measures = tmp_cm
                            th.additional_control_measures = tmp_additional
                        })
                    })
                }else{
                    preparedPayload.rmm_pra_created_date = moment(payload.rmm_pra_created_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_pra_date = (preparedPayload.rmm_pra_date===null || preparedPayload.rmm_pra_date===undefined)?null:moment(payload.rmm_pra_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_pra_expiry_date = (preparedPayload.rmm_pra_expiry_date===null || preparedPayload.rmm_pra_expiry_date===undefined)?null:moment(payload.rmm_pra_expiry_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.approvers = payload.approvers != undefined ?  payload.approvers : []
                    preparedPayload.participants = payload.participants != undefined ?  payload.participants : []

                    //Title and scope
                    preparedPayload.rmm_pra_title = payload.rmm_pra_title ? payload.rmm_pra_title : null
                    preparedPayload.rmm_pra_scope = payload.rmm_pra_scope ? payload.rmm_pra_scope : null
                    
                    payload.element_categories.forEach((ec, index) => {
                        ec.threats.forEach((th, index) => {
                            th.rmm_pth_threat = th.rmm_pth_threat ? th.rmm_pth_threat : null
                            th.rmm_pth_outcome = th.rmm_pth_outcome ? th.rmm_pth_outcome : null
                            tmp_cm = []
                            tmp_additional = []
                            th.control_measures.forEach((cm, index) => {
                                if (!cm.rmm_pta_id || cm.rmm_pta_id === null){
                                    newCMObj = newTag()
                                    newCMObj.tag = cm.tag
                                    newCMObj.rmm_pta_blueline = cm.rmm_pta_blueline
                                    tmp_cm.push(newCMObj)
                                }else{
                                    tmp_cm.push(cm)
                                }
                            })
                            th.additional_control_measures.forEach((add, index) => {
                                if (!add.rmm_pta_id){
                                    newAdditionalCMObj = newTag()
                                    newAdditionalCMObj.tag = add.tag
                                    tmp_additional.push(newAdditionalCMObj)
                                }else{
                                    tmp_additional.push(add)
                                }
                            })
                            th.control_measures = tmp_cm
                            th.additional_control_measures = tmp_additional

                            th.rmm_pth_likelyhood_preliminary = th.rmm_pth_likelyhood_preliminary !== undefined ? th.rmm_pth_likelyhood_preliminary : null
                            th.rmm_pth_severity_preliminary = th.rmm_pth_severity_preliminary !== undefined ? th.rmm_pth_severity_preliminary : null
                            th.rmm_pth_preliminary_risk = th.rmm_pth_preliminary_risk !== undefined ? th.rmm_pth_preliminary_risk : null
                            th.rmm_pth_require_bowtie = th.rmm_pth_require_bowtie !== undefined ? th.rmm_pth_require_bowtie : null
                            th.rmm_pth_risk_alara_preliminary = th.rmm_pth_risk_alara_preliminary !== undefined ? th.rmm_pth_risk_alara_preliminary : null
                            th.rmm_pth_likelyhood_residual = th.rmm_pth_likelyhood_residual ? th.rmm_pth_likelyhood_residual : null
                            th.rmm_pth_severity_residual = th.rmm_pth_severity_residual !== undefined ? th.rmm_pth_severity_residual : null
                            th.rmm_pth_residual_risk = th.rmm_pth_residual_risk !== undefined ? th.rmm_pth_residual_risk : null
                            th.rmm_pth_risk_alara_residual = th.rmm_pth_risk_alara_residual !== undefined ? th.rmm_pth_risk_alara_residual : null
                        })
                    })
                    vm.uneditedCurrentPra.element_categories.forEach((uec, index) => {
                        uec.threats.forEach((uth, index) => {
                            uth.control_measures.forEach((ucm, index) => {
                                payload.element_categories.forEach((ec, index) => {
                                    ec.threats.forEach((th, index) => {
                                        if (uth.rmm_pth_id===th.rmm_pth_id && !th.control_measures.find(cm => cm.rmm_pta_id === ucm.rmm_pta_id)){
                                            ucm.rmm_pta_enable = false
                                            th.control_measures.push(ucm)
                                        }
                                    }) 
                                })
                            })
                            uth.additional_control_measures.forEach((uadd, index) => {
                                payload.element_categories.forEach((ec, index) => {
                                    ec.threats.forEach((th, index) => {
                                        if (uth.rmm_pth_id===th.rmm_pth_id && !th.additional_control_measures.find(add => add.rmm_pta_id === uadd.rmm_pta_id)){
                                            uadd.rmm_pta_enable = false
                                            th.additional_control_measures.push(uadd)
                                        }
                                    }) 
                                })
                            })
                        })
                    })

                    vm.tmpDeletedElements.forEach((dec) => {
                        preparedPayload.element_categories.push(dec) 
                    })
                    
                    vm.tmpDeletedThreats.forEach((dth) => {
                        preparedPayload.element_categories.forEach((ec) => {
                            if (dth.rmm_pth_pec === ec.rmm_pec_id) {
                                ec.threats.push(dth)
                            }
                        })
                    })
                }
                return preparedPayload
            }

            //Function to add an action to an assessment
            vm.addAction = (actionData) => {
                payload = {}
                if('sga_id' in actionData)
                {
                    payload.rmm_pga_pra = vm.currentPra.rmm_pra_id
                    payload.rmm_pga_sga = actionData.sga_id

                    praService.addPraGeneralAction(payload).then((response) => {
                        vm.refreshActions(vm.currentPra.rmm_pra_id)
                    })
                }
                else if('ID' in actionData)
                {
                    payload.rmm_pha_pra =  vm.currentPra.rmm_pra_id
                    payload.rmm_pha_sha = actionData.ID

                    praService.addPraHazardAction(payload).then((response) => {
                        vm.refreshActions(vm.currentPra.rmm_pra_id)
                    })
                }
            }

            //Function to remove completed actions from the grid
            vm.completeAction = (actionData) => {
                vm.refreshActions(vm.currentPra.rmm_pra_id)
            }

            //Function to initialize select2
            vm.initializeSelect2 = (parent, section='')=> {
                setTimeout(()=>{
                $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} ${section}`), escapeMarkup: function (text) { return text } })
                .on('select2:select', () => {
                    $(this).parent().find('label').addClass('filled')
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()
                today = new Date()
                if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
                $('.datepicker').pickadate({
                    format: 'yyyy-mm-dd',
                    onClose : function(){
                        this.$holder.blur()
                    },
                    min: new Date(moment(today).calendar()),
                }).removeAttr('readonly')
                .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                    evt.preventDefault()
                })
                preventFutureDatePickerInit()
                }, 500)
            }

            //Listeners
            $scope.$on('CLOSEMODAL', (event) => {
                vm.initializeSelect2('newPra')
            })

            $scope.$on('ADDACTION', (event, data) => {
                if(data && vm.actionMode != 'edit'){
                    vm.addAction(data)
                }else{
                    vm.refreshActions(vm.currentPra.rmm_pra_id)
                }
            })

            $scope.$on('COMPLETEACTION', (event, data) => {
                if(data)
                    vm.completeAction(data)
            })

            //Function to refresh data and Ag-Grid
            function refreshData() {
                $scope.$emit('STARTSPINNER', vm.loadMessage)
                $q.all([
                    listService.getSelectListData('ref_site'),
                    listService.getSelectListData('ref_job'),
                    listService.getSelectListData('ref_general_action'),
                    employeesService.getPersonProfile(),
                    profileService.getAllEmployeeProfile(),
                    profileService.getFullEmployeeProfile(),
                    listService.getSelectListData('ref_likelihood'),
                    listService.getSelectListData('ref_severity'),
                    listService.getSelectListData('ref_risk_category'),
                    listService.getActionTypes(),
                    praService.getPraList(vm.mainDateFilter),
                    listService.getFullSiteList(),
                    profileService.getRmmApproverEmployees('rmm-pra'),

                ]).then((data) => {
                    vm.siteList = data[0]                    
                    vm.jobList = data[1]
                    vm.actionTypeList = data[2]
                    vm.userId = data[3].per_id
                    vm.fullEmployeeList = profileService.readFullEmployeeProfile()
                    vm.site_name = listService.readFullSites()
                    vm.likelyHoodList = data[6]
                    vm.severityList = data[7]
                    vm.riskCategoryList = data[8]
                    vm.hapActionTypeList = data[9]
                    vm.praAGData = praService.readPraList()
                    vm.tmpDeletedElements = []
                    vm.tmpDeletedThreats = []

                    if (vm.praOptions.api) {
                        translateAgGridHeader (vm.praOptions)
                        let model = vm.praOptions.api.getFilterModel()
                        vm.praOptions.paginationPageSize = 15
                        vm.praOptions.api.setRowData(preparePraGridData())
                        vm.praOptions.api.redrawRows()
                        vm.praOptions.api.sizeColumnsToFit()
                        vm.praOptions.api.setFilterModel(model)
                    }
                    vm.actionDisabled = true
                    $scope.$emit('STOPSPINNER')
                })
            }

            vm.resetForm()
            vm.praViewerOpen = true
            vm.initializeSelect2('newPra')
            vm.praViewerOpen = false

            //function to append leading zeros
            function appendLeadingZeros (num, size=6) {
                var s = "000000000" + num;
                return s.substr(s.length-size)
            }

            //Function to prepare Ag-Grid data with string values
            function preparePraGridData() {
                let praGridData = JSON.parse(JSON.stringify(vm.praAGData))
                praGridData.forEach((rec) =>{
                    rec.exceptionFields = ['approvers', 'ora_events', 'general_actions', 'hazard_actions', 'acknowledgements', 'participants', 'rmm_pra_enable','rmm_pra_ora', 'dlo_enable', 'reviewers','rat_pra_show_check_box','rmm_pra_created_by_per_id']
                    rec.rmm_pra_site = getSiteName(rec.rmm_pra_site)
                    rec.rmm_pra_created_date = moment(rec.rmm_pra_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                    rec.rmm_pra_expiry_date = rec.rmm_pra_expiry_date===null?'':moment(rec.rmm_pra_expiry_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                    rec.rmm_pra_is_submitted  = translateTrueFalse(rec.rmm_pra_state == 'active' ||  rec.rmm_pra_state == 'expired' ? true : false)
                    rec.rmm_pra_revision_no = `${appendLeadingZeros(rec.rmm_pra_document_number)}`+'.'+`${appendLeadingZeros(rec.rmm_pra_doc_version_number,3)}`
                    rec.reviewedCount = rec.reviewers.length
                    rec.hasReviewed = translateTrueFalse(checkAcknowledged(rec))
                    rec.reviewersList = ''
                    rec.reviewers.forEach((rev) => {
                        rec.reviewersList += (`${vm.getEmployeeName(rev.rmm_pre_per_id)} - `)
                    })
                    rec.reviewersList =  rec.reviewersList.replace(/ -\s*$/, "")

                    rec.approversList = ''
                    rec.approvers.forEach((app) => {
                        rec.approversList += (`${vm.getEmployeeName(app.rmm_pap_per)} - `)
                    })
                    rec.approvers =  rec.approversList.replace(/ -\s*$/, "")
                    rec.approversList =  rec.approversList.replace(/ -\s*$/, "")

                    if(rec.dlo_enable.length !== 0){
                        rec.dlo_status = translateTrueFalse(rec.dlo_enable[0].dlo_enable)
                        rec.dlo_person = rec.dlo_enable[0].dlo_person
                    }
                    else{
                        rec.dlo_status = translateTrueFalse(true)
                        rec.dlo_person = null
                    }
                    
                    rec.participantsList = ''
                    rec.participants.forEach((par) => {
                        rec.participantsList += (`${vm.getEmployeeName(par)} - `)
                    })
                    rec.participants = rec.participantsList.replace(/ -\s*$/, "")
                    rec.participantsList = rec.participantsList.replace(/ -\s*$/, "")
                })
                return praGridData
            }

            function translateStatus(status) {
                if (status === 'draft'){
                    return translateTag(1399)
                }
                if (status === 'expired'){
                    return translateTag(3494)
                } 
                if (status == 'review'){
                    return translateTag(1188)
                } 
                if (status == 'active'){
                    return translateTag(3557)
                }
            }

            function translateTrueFalse(val) {
                return val ? translateTag(1379): translateTag(1380)
            }

            //Function to prepare Participants
            function getParticipants (values)
            {
                let participants = []
                values.forEach ((rec) => {
                    participants.push(rec.llp_per)
                })
                return participants
            }

            //Function to prepare Approvers
            function getApprovers (values)
            {
                let approvers = []
                values.forEach ((rec) => {
                    approvers.push(rec.rmm_pap_per)
                })
                return approvers
            }

            // Fuction to check if all modal feilds are valid
            vm.validatePra = () => {
                return new Promise(resolve =>{
                    let validated = validateFormFields('praForm')
                    asyncChips().then((res)=>{
                        resolve({val:validated, chip:res})
                    })
                })
            }

            function validateChips(){
                return new Promise(resolve => {
                    let chipVal = true
                    vm.currentPra.element_categories.forEach((cat)=> {
                        cat.threats.forEach((threat)=>{
                            if(threat.control_measures.length == 0) {
                                chipVal = false
                                throwToastr('error',`${translateTag(2281)}: ${cat.rmm_pec_element}  - ${translateTag(2115)}: ${threat.rmm_pth_threat} - ${translateTag(2478)} ${translateTag(1464)}`,5000)
                                resolve(chipVal)
                            }
                        })
                    })
                    resolve(chipVal)
                })
            }

            async function asyncChips() {
                dat = await validateChips();
                return dat
            }

            //Update Ag-Grid size when window is resized
            $(window).on('resize', () => {
                $timeout(function () {
                    if (vm.praOptions.api) {
                        vm.praOptions.api.sizeColumnsToFit()
                    }
                    if (vm.attachmentOptions.api) {
                        vm.attachmentOptions.api.sizeColumnsToFit()
                    }
                })
            })

            vm.initializeBlueline = () => {
                vm.currentPra.element_categories.forEach((ec_val, i) => {
                    ec_index = ec_val.rmm_pec_sort
                    ec_val.threats.forEach((th_val, j) =>{
                        th_val.control_measures.forEach((cm)=>{
                            id = "control_measure-"+j+"-"+ec_index
                            let cmObjsWebElements = document.getElementById(id).getElementsByClassName('chip')
                            if (cmObjsWebElements.length > 0){
                                for (let index = 0; index < cmObjsWebElements.length; index++) {
                                    let chipText = cmObjsWebElements[index].innerText
                                    if (chipText===cm.tag){
                                        if (cm.rmm_pta_blueline){
                                            cmObjsWebElements[index].classList.add("chip-blueline")
                                        }
                                    }
                                } 
                            } 
                        })
                        
                    })
                })
            }

            function getShowAccordianIds(){
                var expanded_elements = document.getElementsByClassName('collapse show')
                vm.exp_ids = []
                for (let i = 0; i < expanded_elements.length; i++) {
                    vm.exp_ids.push(expanded_elements[i].id)
                }
            }

            function setbackAccordian(){
                setTimeout(() => {
                    var accordian_elements = document.getElementsByClassName('collapse')
                    for (let i = 0; i < accordian_elements.length; i++) {
                        if(!vm.exp_ids.includes(accordian_elements[i].id)){
                            var removeClass_id = "#"+accordian_elements[i].id
                            $(removeClass_id).removeClass('show')
                        } 
                    }
                }, 500)
            }

            // Function to initialize tags
            vm.initializeTags = () => {
                setTimeout(()=>{
                    vm.currentPra.element_categories.forEach((ec_val, i) => {
                        ec_index = ec_val.rmm_pec_sort                          
                        ec_val.threats.forEach((th_val, j) =>{
                            id = "#control_measure-"+j+"-"+ec_index
                            $(id).materialChip({
                                placeholder: '+ ' + translateTag(2478),
                                secondaryPlaceholder: translateTag(2109),
                                data: th_val.control_measures
                            }).on('chip.add',(e, chip)=>{
                                vm.changesInForm = true
                                for (let index = 0; index < th_val.control_measures.length-1; index++) {
                                    if (th_val.control_measures[index].tag.trim().toLowerCase() === chip.tag.trim().toLowerCase()){
                                        throwToastr('error',translateTag(3859),2000)
                                        th_val.control_measures.pop()
                                        break;
                                    }
                                }

                            }).on('chip.delete',()=>{
                                vm.changesInForm = true
                            });
                        })
                    })
                    vm.currentPra.element_categories.forEach((ec_val, i) => {
                        ec_index = ec_val.rmm_pec_sort                          
                        ec_val.threats.forEach((th_val, j) =>{
                            id = "#additional_measure-"+j+"-"+ec_index
                            $(id).materialChip({
                                placeholder: '+ ' + translateTag(3952), //Additional Control
                                secondaryPlaceholder: translateTag(2116),
                                data: th_val.additional_control_measures
                            }).on('chip.add',(e, chip)=>{
                                for (let index = 0; index < th_val.additional_control_measures.length-1; index++) {
                                    if (th_val.additional_control_measures[index].tag.trim().toLowerCase() === chip.tag.trim().toLowerCase()){
                                        throwToastr('error',translateTag(3860),2000)
                                        th_val.additional_control_measures.pop()
                                        break;
                                    }
                                }
                                vm.changesInForm = true
                            }).on('chip.delete',()=>{
                                vm.changesInForm = true
                            });
                        })
                    });
                },500)
            }

            // Move the elements in an array
            function array_move(arr, old_index, new_index) {
                if (new_index >= arr.length) {
                    var k = new_index - arr.length + 1;
                    while (k--) {
                        arr.push(undefined);
                    }
                }
                arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
                return arr;
            }

            function dragAndSort(){
                $( "#sortable" ).sortable({
                    items: "li:not(.ui-state-disabled)",
                    stop: function( event, ui ) {
                        vm.currentPra.element_categories.forEach((val, index) => {
                            tmp = parseInt(event.target.children[index].firstElementChild.id.split('-').pop())
                            vm.currentPra.element_categories[tmp].rmm_pec_sort = index+1
                        });
                        let tmp_element_categories = []
                        vm.currentPra.element_categories.forEach((val, index) => {
                            let new_index = val.rmm_pec_sort-1
                            tmp_element_categories.splice(new_index,0,val)
                        });
                        vm.currentPra.element_categories = tmp_element_categories
                        $scope.$apply();
                    }
                })
                $( "#sortable" ).sortable({ handle: '.handle'})
                $( "#sortable" ).disableSelection()
            }
            function destroyTables() {
                return new Promise((resolve, reject)=>{
                    if($.fn.DataTable) {
                        if ($.fn.DataTable.isDataTable(".data-table")) {
                            $('.data-table').DataTable().clear().destroy()
                            resolve(true)
                        }
                        else{
                            resolve(true)  
                        }
                    }
                })
            }

            function initiateTables() {
                setTimeout(() =>{
                    $('.data-table').DataTable({
                        "searching": false,
                        "bSort": false,
                        "bLengthChange": false,
                        "pagingType": "numbers",
                        "pageLength": 15,
                        "language": {
                            "url": `/locales/datatables/i18n/${selectedLanguage}.json`
                        }
                    });
                    $('.dataTables_length').addClass('bs-select');
                    $(".dataTables_wrapper div:last-of-type div").removeClass("col-md-5 col-md-7")
                },500)
            }

            $(document).ready(function() {
                vm.initializeTags()
                dragAndSort()
            })
        //END
    }
])