angular
    .module('safeToDo')
    .service('praService', ['$http',
        function ($http) {
            let praList = []

            return {
                getPraList: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/pra-get-list/`, payload).then((response) => {
                        praList = response.data
                    }, (errorParams) => {
                        console.log('Failed to load PRAs', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            praList = []
                            window.location.href = "/";
                        }
                    })
                },
                getPraOraList: () => {
                    return $http.get(`${__env.apiUrl}/api/rmm/pra-ora-titles-list/`).then((response) => {
                        return response.data.data
                    }, (errorParams) => {
                        console.log('Failed to load PRA Pulldown list', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            window.location.href = "/";
                        }
                    })
                },
                getPraOraEventsList: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/pra-ora-event-list/${payload}/`).then((response) => {
                        return response.data.data
                    }, (errorParams) => {
                        console.log('Failed to load PRA Events Pulldown list', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            window.location.href = "/";
                        }
                    })
                },
                getBluelinesList: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/pra-bluelines/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load Bluelines', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            window.location.href = "/";
                        }
                    })
                },
                getPraSIngleDetailRec: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/pra-get-detail/${payload}/`).then((response) => {
                        praDetail = response.data
                        return praDetail
                    }, (errorParams) => {
                        console.log('Failed to load the single detail PRA', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            praDetail = null
                            window.location.href = "/";
                        }
                    })
                },
                getGaHaActions: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/pra-get-gaha-detail/${payload.rmm_pra_id}/`).then((response) => {
                        if(response.data.accessMsg){
                            toastr.error(response.data.accessMsg)
                            return []
                        }
                        else
                            return response.data
                    }, (errorParams) => {
                        console.log('Failed to load general actions', errorParams)
                    })
                },              

                createPra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/pra-insert/`, payload).then((response) => {
                       return response.data
                    }, (errorParams) => {
                        console.log('Failed to create pra', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },
                updatePra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/pra-update/${payload.rmm_pra_id}/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to update pra', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },
                signPra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/pra-sign/`, payload).then((response) => {
                       return response.data
                    }, (errorParams) => {
                        console.log('Failed to sign Pra', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                archivePra: (IdList) => {
                    var patchList = []
                    for (var i = 0; i < IdList.length; i++) {
                        patchList.push({ rmm_pra_id: IdList[i]})
                    }
                    return $http.post(`${__env.apiUrl}/api/rmm/pra-archive/`, patchList).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to archive PRA', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                addPraGeneralAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/pra-insert-general-action/`, payload).then((response) => {
                        if(response.data.accessMsg){
                        toastr.error(response.data.accessMsg)
                        return []
                        }
                        else
                            return response.data

                    }, (errorParams) => {
                        console.log('Failed to add PRA general action', errorParams)
                    })
                },
                addPraHazardAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/pra-insert-hazard-action/`, payload).then((response) => {
                        if(response.data.accessMsg){
                        toastr.error(response.data.accessMsg)
                        return []
                        }
                        else
                            return response.data

                    }, (errorParams) => {
                        console.log('Failed to add PRA hazard action', errorParams)
                    })
                },               
                copyRevisionPra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/pra-copy-revision/${payload.rmm_pra_id}/${payload.mode}/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to copy or revision pra', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                reviewPra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/pra-review/${payload.rmm_pra_id}/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to review pra', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },
                praBowtie: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/pra-bowtie/${payload}/`).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load Bowties', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },
                validateBowtiePra: (pra_id) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/validate-bowtie-pra/${pra_id}/`).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load Bowties', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },


                readPraList: () => {
                    return praList
                },

            //End
            }
        }
    ])