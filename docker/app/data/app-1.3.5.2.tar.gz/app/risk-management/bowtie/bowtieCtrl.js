angular
    .module('safeToDo')
    .controller('bowtieCtrl', ['$rootScope','$scope', '$timeout', '$compile', '$q', '$window', '$interval','$sce', 'gridService', 'select2Service',
      'bowtieService', 'listService', 'modalService', 'profileService', 'employeesService','menuService', 'actionManagementService', 'documentLockService', '$routeParams','rmmAttachmentsService','fileUploadService', 'exportCSV',
        function ($rootScope,$scope, $timeout, $compile, $q, $window, $interval ,$sce, gridService, select2Service, bowtieService, listService,
            modalService, profileService, employeesService, menuService, actionManagementService, documentLockService, $routeParams,rmmAttachmentsService,fileUploadService, exportCSV) {
            var vm = this;
            
            let dateToday = moment(new Date(), 'YYYY-MM-DD')
            vm.employeeList = []
            vm.fullEmployeeList = []
            vm.currentAcknowledgeHistory = []
            vm.userId = null
            vm.siteList = []
            vm.jobList = []
            vm.jobListSelect = []
            vm.actionTypeList = []
            vm.singleServeReportUrl = 'bowtie'
            vm.LLDataContext = {}
            vm.topSearch = ''
            vm.archiveCount = 0
            vm.deleteAttCount = 0
            vm.bowtieAGData = []
            vm.attachmentData = []
            vm.newAttachments = []
            vm.uploadFileList= []
            vm.actionDisabled = true
            vm.attActionDisabled = true
            vm.canViewBowtie = false
            vm.canManageBowtie = true
            vm.bowtieViewerOpen = false
            vm.hideingBowtieViewer = false
            vm.openingBowtieViewer = false
            vm.currentAcknowledge = null
            vm.generalEditData = {}
            vm.hazardEditData = {}
            vm.likelyHoodList = []
            vm.severityList = []
            vm.performActionMode = ''
            vm.selectedRecordCount = 0
            vm.rmm_bow_doc_revision_no = null
            vm.updatingRecord = false
            vm.userInApprovers = false
            vm.changesInForm = false
            vm.canArchiveSubmissions = false
            vm.currentUserSigned = false
            vm.pem = []
            vm.pcm = []
            vm.doc_title_list = []
            vm.doc_event_category_list = []
            vm.doc_major_unwanted_event_list = []
            vm.pre_likelyhood = null
            vm.pre_risk = null
            vm.pre_severity = null
            vm.res_likelyhood = null
            vm.res_risk = null
            vm.res_risk_tag = null
            vm.pre_risk_tag = null
            vm.res_severity = null
            vm.loadMessage = translateTag(3957)
            vm.continueEditing = false
            vm.leaveEditing = false
            vm.idletime = 0
            vm.countdownSeconds = 60
            vm.autosave = null
            vm.autoSaveActive = false
            vm.bowtie_show_check_box = false
            vm.mod_id = 12   //module bowtie
            vm.currentAttachment = null
            
            vm.alara = [
                {
                  id: 1,
                  label: translateTag(1379)
                },
                {
                  id: 0,
                  label: translateTag(1380)
                }
            ]

            vm.doc_type_list  = [
                {
                  id: 'ORA',
                  label: "ORA"
                },
                {
                  id: 'PRA',
                  label: "PRA"
                },
                {
                    id: 'standalone',
                    label: translateTag(9173) // 'Standalone'
                }
            ]

            //Get permissions for the user
            menuService.getPagePermissions().then((data) => {
                vm.permissions = data
                vm.canViewBowtie = vm.permissions.includes('Can View Bowtie') ? true : false
                vm.canManageBowtie = vm.permissions.includes('Can Manage Bowtie') ? true : false
                vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
                vm.canManageActionItems = vm.permissions.includes('Can Manage Action Items') ? true : false
                vm.canCloseAllActions = vm.permissions.includes('Can Close All Actions') ? true : false
            })

            $scope.$on('DATERANGE', (range) => {
                vm.mainDateFilter = {
                    start_date: moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD'),
                    end_date: moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')
                }
                refreshData()
            })

            //Function to clear the form feilds
            vm.resetForm = () => {
                resetFormFieldClassList('bowtieForm')
                vm.jobListSelect = []
                vm.attachmentData = []
                vm.saved = false
                vm.submitted = false
                vm.rmm_bow_doc_revision_no = null
                vm.updatingRecord = false
                vm.changesInForm = false
                vm.currentUserSigned = false
                vm.pem = [newEventMitigation()]
                vm.pcm = [newConsequenceMitigation()]
                vm.doc_title_list = []
                vm.doc_event_category_list = []
                vm.doc_major_unwanted_event_list = []
                vm.pre_likelyhood = null
                vm.pre_risk = null
                vm.pre_severity = null
                vm.res_likelyhood = null
                vm.res_risk = null
                vm.pre_risk_tag = null
                vm.res_risk_tag = null
                vm.res_severity = null
                vm.dlo_id = null
                vm.docLockMessage = ''
                vm.docLockStatus = false
                vm.countdownSeconds = 60
                vm.lockCheckModal = false
                vm.continueEditing = false
                vm.idletime = 0
                vm.leaveEditing = false
                vm.bowtie_show_check_box = false
                
                vm.currentBow =
                {
                    rmm_bow_id: null,
                    rmm_bow_document_number: null,
                    rmm_bow_doc_version_number: null,
                    rmm_bow_title: null,
                    rmm_bow_scope: null,
                    rmm_bow_date: dateToday.format("YYYY-MM-DD"),
                    rmm_bow_expiry_date: null,
                    rmm_bow_site: null,
                    rmm_bow_other_participants: null,
                    rmm_bow_state: null,
                    rmm_bow_document_type: null, // ORA - PRA 
                    rmm_bow_document_id: null, // ORA _ PRA - id _
                    rmm_bow_risk_category_id: null, // ORA PRA _ EventCatehpry or Step  ID 
                    rmm_bow_risk_sub_category_id: null, // ORA PRA _ Most unwanted event or threat ID
                    participants: [],
                    approvers: [],
                    rmm_bow_is_submitted: false,
                    rmm_bow_revision_no:null,
                    approversList:[],
                    rmm_bow_executive_summary: null,
                    rmm_bow_submitted_date: null,
                    root_causes_events: [newRootCause()],
                    consequences: [newConsequence()],
                    hazard_actions:[],
                    general_actions:[],
                    standalone :{
                        rmm_bsa_document: '', 
                        rmm_bsa_category: '',  
                        rmm_bsa_sub_category: '' 
                    } 
                }
            }

            // Function for a new Root Cause object
            function newRootCause() {
                return {
                    rmm_brc_id: null,
                    rmm_brc_bow: null,
                    rmm_brc_root_cause: null,
                    rmm_oec_enable: true,
                    event_mitigations: []
                }
            }

            // Function for a new Event Mitigation object
            function newEventMitigation() {
                return {
                    rmm_bem_id: null,
                    rmm_bem_brc: null,
                    rmm_bem_event: null
                }
            }

            // Function for a new Consequence
            function newConsequence() {
                return {
                    rmm_bco_id: null,
                    rmm_bco_bow: null,
                    rmm_bco_consequence: null,
                    consequence_mitigations: []
                }
            }

            // Function for a new Event Mitigation object
            function newConsequenceMitigation() {
                return {
                    rmm_bcm_id: null,
                    rmm_bcm_bco: null,
                    rmm_bcm_consequence: null
                }
            }

            // Function for a tag object
            function newTag() {
                return {
                    rmm_ota_id: null,
                    rmm_ota_oev: null,
                    tag: null,
                    rmm_ota_tag_name:null,    
                    rmm_ota_blueline: false,
                    rmm_ota_enable: true
                }
            }

            //Function to add a new Root Cause
            vm.addRootCause = function () {
                vm.currentBow.root_causes_events.push(newRootCause())
                vm.pem.push(newEventMitigation())
            }
            //Function to add a new COnsequence
            vm.addConsequence = function () {
                vm.currentBow.consequences.push(newConsequence())
                vm.pcm.push(newConsequenceMitigation())
            }

            //Function for change document type
            vm.loadDocumentTitles = function () {
                if (vm.currentBow.rmm_bow_document_type!==null && vm.currentBow.rmm_bow_document_type!==undefined && vm.currentBow.rmm_bow_document_type != 'standalone'){
                    bowtieService.getDocumentTitleList(vm.currentBow.rmm_bow_document_type).then((response) => {

                        response.forEach((rec, index) => {
                                rec.label = rec.label + ' (' + appendLeadingZeros(rec.doc_number)+'.'+appendLeadingZeros(rec.doc_version_number,3)+')'
                            }
                        )
                        vm.doc_title_list = response

                        // reset the standalone object.
                        vm.currentBow.standalone = { 
                            rmm_bsa_document: '',
                            rmm_bsa_category: '',
                            rmm_bsa_sub_category: '' 
                        }

                    })
                }
                else {
                    vm.doc_title_list = null

                    // reset the references.
                    vm.currentBow.rmm_bow_risk_category_id = null
                    vm.currentBow.rmm_bow_risk_sub_category_id = null
                    vm.currentBow.rmm_bow_document_id = null
                }

            }

            //Function for change document type
            vm.loadEventCategoryList = function () {
                if (vm.currentBow.rmm_bow_document_id!==null && vm.currentBow.rmm_bow_document_id!==undefined){
                    payload = {
                        type : vm.currentBow.rmm_bow_document_type,
                        title_id : vm.currentBow.rmm_bow_document_id
                    }
                    bowtieService.getEventCategoryList(payload).then((response) => {
                        vm.doc_event_category_list = response
                    })
                }
                else{
                    vm.doc_event_category_list = null
                }
            }

            //Function for change document type
            vm.loadMajorUnwantedEventList = function () {
                if (vm.currentBow.rmm_bow_risk_category_id!==null && vm.currentBow.rmm_bow_risk_category_id!==undefined){                    
                    payload = {
                        type : vm.currentBow.rmm_bow_document_type,
                        title_id : vm.currentBow.rmm_bow_risk_category_id
                    }
                    bowtieService.getMajorUnwantedEventList(payload).then((response) => {
                        vm.doc_major_unwanted_event_list = response
                    })
                }
                else {
                    vm.doc_major_unwanted_event_list = null
                }
            }

            //Function for change document type
            vm.loadRiskAssessments = function () {

                if (vm.currentBow.rmm_bow_risk_sub_category_id!==null && vm.currentBow.rmm_bow_risk_sub_category_id!==undefined && vm.currentBow.rmm_bow_document_type !='standalone'){
                    payload = {
                        type : vm.currentBow.rmm_bow_document_type,
                        title_id : vm.currentBow.rmm_bow_risk_sub_category_id
                    }
                    bowtieService.getRiskAssessments(payload).then((response) => {
                        if(response.length!==0){
                            vm.pre_likelyhood = response[0].pre_likelyhood
                            vm.pre_risk = response[0].pre_risk
                            vm.pre_severity = response[0].pre_severity
                            vm.res_likelyhood = response[0].res_likelyhood
                            vm.res_risk = response[0].res_risk
                            vm.res_severity = response[0].res_severity
                            vm.pre_risk_tag = response[0].pre_risk_tag
                            vm.res_risk_tag = response[0].res_risk_tag
                        }
                    })

                } else {
                    vm.pre_likelyhood = null
                    vm.pre_risk = null
                    vm.pre_severity = null
                    vm.res_likelyhood = null
                    vm.res_risk = null
                    vm.res_severity = null
                }
            }
            
            //Function to add a new unwanted event category
            vm.addEvent = function (ec_index) {
                vm.currentBow.event_categories[ec_index].events.push(newEvent())
                setTimeout(()=>{
                    vm.initializeTagsAndPulldowns()
                },100)
            }

            //Function to delete a Root Cause
            vm.deleteRootCauseAndMitigation = function (rm_index) {
                vm.currentBow.root_causes_events.splice(rm_index,1)[0]
                vm.pem.splice(rm_index,1)[0]
                if (vm.currentBow.root_causes_events.length === 0){
                    vm.addRootCause()
                    return
                }
                vm.initializeSelect2('newBowtie')
            }

            //Function to delete a consequence
            vm.deleteConsequenceAndMitigation = function (rm_index) {
                vm.currentBow.consequences.splice(rm_index,1)[0]
                vm.pcm.splice(rm_index,1)[0]
                if (vm.currentBow.consequences.length === 0){
                    vm.addConsequence()
                    return
                }
                vm.initializeSelect2('newBowtie')
            }

            // Function to click risk matrix
            vm.onClickRiskMatrix = (ec_index,ev_index,severity,likelyhood,p_risk) =>{
                vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_severity_preliminary = getRefIDForRisk(severity,'severity')
                vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_likelyhood_preliminary = getRefIDForRisk(likelyhood,'likelyHood')
                vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_preliminary_risk = p_risk
                vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_risk = p_risk
                vm.initializeSelect2('newBowtie')
            }

            //Function to get Score for a given Ref ID
            function getRefIDForRisk (ref_name,type) {
                let ref_id = null
                switch(type){
                    case "likelyHood":
                        vm.likelyHoodList.forEach((val, index) => {
                            if (val.rld_name === ref_name){
                                ref_id = val.rld_id
                            }
                        })
                        break;
                    case "severity":
                        vm.severityList.forEach((val, index) => {
                            if (val.rld_name === ref_name){
                                ref_id = val.rld_id
                            }
                        })
                        break; 
                }
                return ref_id
            }

            // Function to Evaluate Preliminary Risk
            function evalRisk (severity,likelyhood) {
                let Extreme = ['31','41','51','42','52','53']
                let High = ['21','22','32','33','43','44','54','55']
                let Medium = ['11','12','23','34','45']
                let Low = ['13','14','15','24','25','35']
                let code = `${severity}${likelyhood}`
                let risk = null
                if (Extreme.find(o => o === code)){
                    risk = 'Extreme'
                }
                if (High.find(o => o === code)){
                    risk = 'High'
                }
                if (Medium.find(o => o === code)){
                    risk = 'Medium'
                }
                if (Low.find(o => o === code)){
                    risk = 'Low'
                }
                return risk
            }

            //Function to get Score for a given Ref ID
            function getScoreForRisk (ref_id,type) {
                let score = null
                switch(type){
                    case "likelyHood":
                        vm.likelyHoodList.forEach((val, index) => {
                            if (val.rld_id === ref_id){
                                score = val.rld_score
                            }
                        })
                        break;
                    case "severity":
                        vm.severityList.forEach((val, index) => {
                            if (val.rld_id === ref_id){
                                score = val.rld_score
                            }
                        })
                        break; 
                }
                return score
            }

            // Function to Evaluate Preliminary Risk
            vm.evalPrelimRisk = (ev_index, ec_index) => {
                let severity = parseInt(getScoreForRisk(vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_severity_preliminary,'severity'))
                let likelyhood = parseInt(getScoreForRisk(vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_likelyhood_preliminary,'likelyHood'))
                if (vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_risk_alara_preliminary !== 0){
                    vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_risk = evalRisk(severity,likelyhood)
                }
                vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_preliminary_risk = evalRisk(severity,likelyhood)
            }

            // Function to Evaluate Residual Risk
            vm.evalResidualRisk = (ev_index, ec_index) => {
                let severity= parseInt(getScoreForRisk(vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_severity_residual,'severity'))
                let likelyhood = parseInt(getScoreForRisk(vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_likelyhood_residual,'likelyHood'))
                vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_risk = evalRisk(severity,likelyhood)
                vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_residual_risk = vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_risk
            }

            // Function to change ALARA
            vm.changeALARA = (ev_index, ec_index) => {
                if (vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_risk_alara_preliminary === 0){
                    setTimeout(()=>{
                        vm.initializeTagsAndPulldowns()
                    },100)
                }else{
                    vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_severity_residual = null
                    vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_likelyhood_residual = null
                    vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_risk = vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_preliminary_risk
                    vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_residual_risk = null
                    vm.currentBow.event_categories[ec_index].events[ev_index].rmm_oev_risk_alara_residual = null
                    vm.currentBow.event_categories[ec_index].events[ev_index].additional_control_measures=[]
                }
            }

            $scope.fileUploadChanged = (event)=> {

                //Add newly selected files after checking for duplicates and correct file types
                vm.uploadFileList = vm.uploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, []))

                if(vm.uploadFileList.length > 0)
                    addAttachments()
            }

            //Function for the top search bar
            vm.topSearchChanged = () =>{
                vm.bowtieOptions.api.setQuickFilter(vm.topSearch)
            } 

            //Function to open archive confirmation Modal
            vm.archiveConfirmationModal = () => {
                let archiveSelectedRecords = vm.bowtieOptions.api.getSelectedRows()
                vm.archiveCount = archiveSelectedRecords.length
                if (vm.archiveCount > 0) {
                    if(!vm.canArchiveSubmissions){
                        for (var i = 0; i < vm.archiveCount; i++) {
                            if(archiveSelectedRecords[i].rmm_bow_state!=="draft" || archiveSelectedRecords[i].rmm_bow_created_by_per_id!==vm.userId){
                                throwToastr('error',translateTag(1456),3000)
                                return
                            }
                        }
                    }
                }
                vm.modalElementsArchive = {
                    title: translateTag(3715), //"Archive Bowtie?"
                    message: `<div><p>${translateTag(3716)}</p></div>`, //"You are about to archive this assessment. Undoing this will require IT support. Are you sure?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                } 
                document.getElementById('confirmcallingform').innerHTML = 'BTARCHIVECALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsArchive)
            } 
            
            $scope.$on("BTARCHIVECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.bowArchive()
                }
                else if (result=='button2') {
                    vm.cancelModal('confirmModal')
                }
            })
    
            vm.getFilteredEmployees = () =>{
                profileService.filterEmployeeListonSite(vm.currentBow.rmm_bow_site)
                vm.employeeList =  profileService.readFilterEmployeeListonJob()
                profileService.filterRmmApproverEmployeesOnSite(vm.currentBow.rmm_bow_site)
                vm.rmmApproversEmployee = profileService.readFilterApproversList()               
            } 

            vm.generateHtmlReport = (id) => {  
                var win = window.open(`/ra/bowtieprint/?id=${id}`, "_blank");  
            }

            //Function to archive the selected rows
            vm.bowArchive = () => {
                var rows = vm.bowtieOptions.api.getSelectedRows()
                if (rows.length > 0) {
                    var ids = []

                    for (var i = 0; i < rows.length; i++) {
                        if (rows[i].dlo_status === 'Yes') {
                            ids.push(rows[i].rmm_bow_id)
                        }
                        else{
                            // You cannot Archive while Document is being edited
                            throwToastr('warning',translateTag(9116),2000)
                        }
                    }

                    bowtieService.archiveBowtie(ids).then((r) => {
                        refreshData()
                    })
                }
                modalService.Close('confirmModal')
            }

            // function to reset toastr options
            function resetToastrOptions() {
                toastr.options.progressBar = false,
                toastr.options.positionClass = 'toast-top-right'
                toastr.options.timeOut= "5000"
            }

            //function to throw toastr with time interval
            function throwToastr(type,message,time){
                toastr.options.timeOut = time
                toastr.options.positionClass = 'rmm-toast-custom'
                switch (type) {
                    case 'success':
                        toastr.success(message)
                        break;
                    case 'warning':
                        toastr.warning(message)
                        break;
                    case 'error':
                        toastr.error(message)
                        break;
                    case 'info':
                        toastr.info(message)
                        break;
                }
                resetToastrOptions()
            }

            //Function to open archive confirmation Modal
            vm.copyRevisionConfirmationModal= (mode='') => {
                vm.performActionMode = mode 
                var rows = vm.bowtieOptions.api.getSelectedRows()
                vm.selectedRecordCount = rows.length
                if (vm.selectedRecordCount === 0){
                    throwToastr('warning',translateTag(3861),2500)
                    return
                }
                if (vm.selectedRecordCount > 1) {
                    throwToastr('warning', translateTag(3958),2500)
                    return
                }
                if (rows[0].rmm_bow_state === 'draft' && vm.performActionMode==='revision'){
                    throwToastr('error',translateTag(3865),3000)
                    return
                }
                let duplicateFlag = false
                if ((rows[0].rmm_bow_state === 'active' || rows[0].rmm_bow_state === 'expired') && vm.performActionMode==='revision'){
                    vm.bowtieAGData.forEach((val)=>{
                        if (duplicateFlag)
                            return
                        if (val.rmm_bow_document_number === rows[0].rmm_bow_document_number){
                            if (val.rmm_bow_state === 'review' || val.rmm_bow_state === 'draft'){
                                throwToastr('error',translateTag(3959),2500)
                                duplicateFlag = true
                            }
                        }
                    })
                }
                if (!duplicateFlag){
                    vm.modalElementsCopy = {
                        title: capitalizeFirstLetter(vm.performActionMode), //
                        message: 
                        `<div>
                            <p ng-if=${vm.performActionMode==='copy'} note="You are about to make a copy of this Bowtie. Are you sure?">${translateTag(9533)}. ${translateTag(2257)}</p>
                            <p ng-if=${vm.performActionMode==='revision'} note="You are about to make a revision of this Bowtie. Are you sure?">${translateTag(9536)}. ${translateTag(2257)}</p>
                        </div>`,
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                    } 
                    document.getElementById('confirmcallingform').innerHTML = 'BTCOPYCALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsCopy)
                }
            }
       
            $scope.$on("BTCOPYCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.bowCopyRevision()
                }
                else if (result=='button2') {
                    vm.cancelModal('confirmModal')
                }
            })

            //Function to copy or revision the selected rows
            vm.bowCopyRevision = () => {
                var rows = vm.bowtieOptions.api.getSelectedRows()
                if (rows.length > 0) {              
                    let payload = {}
                    payload.rmm_bow_id =  rows[0].rmm_bow_id
                    payload.mode = vm.performActionMode

                    bowtieService.copyRevisionBowtie(payload).then((r) => {
                        refreshData()
                    })
                }
                modalService.Close('confirmModal')
            }

            //Funtion to export the selected rows to CSV file
            vm.exportCSV = () => {
                let rows = JSON.parse(JSON.stringify(vm.bowtieOptions.api.getSelectedRows()))
                exportCSV.export_csv(rows, translateTag(8335))
            }

            //Funtion to open a report in a new tab
            vm.viewReports = (e, id) =>{
                if(!e.ctrlKey){                    
                    lang_number = localStorage.getItem('lang_id')
                    vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.singleServeReportUrl}/${id}?lang=${lang_number}`)
                    $window.open(vm.reportURL, "_blank")
                }
            }        

            //#region Funtions to convert ID to Name
            vm.getEmployeeName = (value) => {
                let name = value
                vm.fullEmployeeList.forEach((emp)=>{
                    if(emp.per_id == value) {
                        name = emp.per_full_name
                    }
                })
                return name
              }

            function getEmployeeID(value) {
                let nameID = value
                vm.fullEmployeeList.forEach((emp)=>{
                    if(emp.per_full_name == value) {
                        nameID = emp.per_id
                    }
                })
                return nameID
            }

            function getActionTypeName(value) {
                let name = value
                vm.actionTypeList.forEach((at)=>{
                    if(at.rld_id == value) {
                    name = at.rld_name
                    }
                })
                return name
            }

            function getActionTypeID(value) {
                let nameID = value
                vm.actionTypeList.forEach((at)=>{
                    if(at.rld_name == value) {
                        nameID = at.rld_id
                    }
                })
                return nameID
            }

            function getSiteName(value) {
                let name = value
                vm.site_name.forEach((s)=>{
                    if(s.rld_id == value) {
                        name = s.rld_name
                    }
                })
                return name
            }

            function getJobNumber(value) {
                let name = value
                vm.jobList.forEach((j)=>{
                    if(j.rld_id == value) {
                        name = j.rld_code
                    }
                })
                return name
            }
            //#endregion
           
            vm.bowtieOptions = gridService.getCommonOptions()
            vm.attachmentOptions = gridService.getCommonOptions()

            //Function to disable action button if no rows are selected
            vm.bowtieOptions.onSelectionChanged = () => {
                var selectedRows = vm.bowtieOptions.api.getSelectedRows()
                vm.actionDisabled = selectedRows.length == 0
                $scope.$apply()
            }
            vm.attachmentOptions.onSelectionChanged = () => {
                var selectedRows = vm.attachmentOptions.api.getSelectedRows()
                vm.attActionDisabled = selectedRows.length == 0
                $scope.$apply()
            }

            //Set Ag-Grid colum values/settings
            let bowColumns = [
                {
                    headerName: '',
                    field: 'dummyCheckbox',
                    maxWidth: 50,
                    minWidth: 50,
                    checkboxSelection: true,
                    suppressMenu: true,
                    suppressSorting: true,
                    headerCheckboxSelection: true,
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    field: "review",
                    headerName: " ",
                    minWidth: 125,
                    maxWidth: 125,
                    suppressMenu: true,
                    cellRenderer: (params) => {
                    return `<span ng-show="${params.data.rmm_bow_is_submitted === translateTag(1379)}" ng-click="bowtieCtrl.signoff(data)" class="{{ data.hasReviewed === '${translateTag(1379)}'? 'text-success ' : 'pointer'}}" title="{{menu.translateLabels(3431)}}"><i class="far fa-file-alt fa-lg pr-2""></i></span>`
                        + `<span class="fa-1x fa-stack" style=" width: 1.25em;" ng-class="{ transparent: ${!vm.canManageBowtie}, pointer: ${vm.canManageBowtie}}"  ng-show="'${params.data.rmm_bow_state}'==='draft'" ng-click="bowtieCtrl.openViewer('edit', ${params.data.rmm_bow_id})"><i class="fas fa-pen fa-stack-1x text-primary" title="{{menu.translateLabels(1194)}}"></i> <i ng-show="${params.data.dlo_status === translateTag(1380)}" class="fas fa-ban fa-stack-1x text-danger" title="${params.data.dlo_person} {{menu.translateLabels(3423)}}"></i></span>`
                        + `<span ng-class="{ transparent: ${!vm.canManageBowtie}, pointer: ${vm.canManageBowtie}}"  ng-show="'${params.data.rmm_bow_state}'==='review'" ng-click="bowtieCtrl.openViewer('view', ${params.data.rmm_bow_id})"><i class="fas fa-lock pr-2 text-primary" title="{{menu.translateLabels(1188)}}"></i></span>`
                        + `<span note="Review History" title="{{menu.translateLabels(3951)}}" class="source signoff-count" ng-class="{ transparent: (!data.reviewedCount > 0 || data.rmm_bow_is_submitted === '{{menu.translateLabels(1380)}}'), pointer: (data.reviewedCount > 0 && data.rmm_bow_is_submitted === '{{menu.translateLabels(1379)}}') }" ng-click="bowtieCtrl.viewAcknowledgeHistory(data);">{{ data.reviewedCount }}</span>`
                        + `<span class="pointer text-left" ng-click="bowtieCtrl.viewReports($event, ${params.data.rmm_bow_id})"><i class="fa fa-external-link-alt notes=Launch report" title="{{menu.translateLabels(3429)}}"></i></span>`
                    },
                    valueGetter: function (params) {
                        return params.data.reviewedCount
                    },
                },
                {
                    field: '',
                    hide: true,
                    valueGetter: function (params) {
                        if (params.data.rmm_bow_state === 'draft')
                            return '1_Draft'
                        if (params.data.rmm_bow_state === 'review')
                            return '2_Review'
                        if (params.data.rmm_bow_state === 'active')
                            return '3_Active'
                        if (params.data.rmm_bow_state === 'expired')
                            return '4_Expired'
                    },
                    sort: 'asc',
                },
                {
                    field: "rmm_bow_created_date",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 140,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    sort: 'desc'
                },
                {
                    field: "rmm_bow_created_by_per",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 220,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_bow_expiry_date",
                    headerName: " ",
                    minWidth: 120,
                    maxWidth: 140,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        let expiryDate = new Date(params.data.rmm_bow_expiry_date)
                        let currentDate = new Date()
                        if (expiryDate < currentDate)
                            return '<div style="color: #D20000;">' + params.data.rmm_bow_expiry_date + '</div>'
                        else
                            return '<div>' + params.data.rmm_bow_expiry_date + '</div>'
                      }
                },
                {
                    field: "rmm_bow_title",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 1000,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_bow_site",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_bow_revision_no",
                    headerName: " ",
                    minWidth: 120,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_bow_state",
                    headerName: " ",
                    maxWidth: 120,
                    minWidth: 120,
                    suppressMenu: false,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    valueGetter: function (params) {
                        return translateStatus(params.data.rmm_bow_state)                        
                    },
                },              
                {field:"hasReviewed", hide:true},
                {field:"participantsList", hide:true},
                {field:"reviewersList", hide:true},
                {field:"reviewedCount", hide:true},
                {field:"rmm_bow_is_submitted", hide:true},
            ]
            vm.bowtieOptions.columnDefs = bowColumns
            vm.bowtieOptions.defaultColDef = {
                cellStyle : (params) =>{
                    if(params.data.rmm_bow_state === 'active' || params.data.rmm_bow_state === 'expired' || params.data.rmm_bow_state === 'review'){
                        return { "cursor": "pointer !important"}
                    }
                } 
            }

            vm.bowtieOptions.onCellClicked  = (params) => {
                if(params.column.colDef.field !== 'review' && (params.data.rmm_bow_state === 'active' || params.data.rmm_bow_state === 'expired' || params.data.rmm_bow_state === 'review')){
                    vm.openViewer('view', params.data.rmm_bow_id)
                }
            }

            vm.viewOnlyCheck = () => {
                // For autosave so that the fields do not react to this function
                if(!vm.autoSaveActive) {
                    if(vm.currentBow.rmm_bow_state === 'active' || vm.currentBow.rmm_bow_state === 'expired' || vm.currentBow.rmm_bow_state === 'review' || vm.updatingRecord)
                        return true
                    return false
                }
            }

            vm.signoff = (bowData) => {
                vm.bowDataContext = bowData
                if(bowData.hasReviewed=== translateTag(1379)) {
                    throwToastr('success', translateTag(3869), 2000)
                }
                else {
                    vm.modalElementsReview = {
                        title: translateTag(3718), //"Bowtie Risk Assessment Review?"
                        message: `<div><p>${translateTag(3634)}</p></div>`, //"You are confirming that you have reviewed this assessment. This cannot be undone. Continue?"
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Review">{{vm.componentTranslateLabels(1188)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                    } 
                    document.getElementById('confirmcallingform').innerHTML = 'BTREVIEWCALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsReview)
                 }
            }

            $scope.$on("BTREVIEWCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.addAcknowledge()
                }
                else if (result=='button2') {
                    vm.cancelModal('confirmModal')
                }
            })

            let attachmentColumns = [
                {
                    headerName: '',
                    field: 'dummyCheckbox',
                    maxWidth: 50,
                    minWidth: 50,
                    checkboxSelection: (params) =>{
                        return params.data.rat_bowtie_show_check_box
                    }, 
                    suppressMenu: true,
                    suppressSorting: true,
                    headerCheckboxSelection: true,
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    //Added the id to the Ag-Grid and hid it. Used to sort the grid to show newest submissions first
                    field: 'rat_id',
                    hide: true,
                    sort: 'desc',
                },
                {
                    field: "rat_created_by_per",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',                    
                },
                {
                    field: "rat_created_date",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rat_file_name",
                    headerName: " ",
                    minWidth: 150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        return `<span class="pointer clip" ng-click='bowtieCtrl.openAttachment(${cleanDoubleCurly(JSON.stringify(params.value))})'><a class="source" href="#" ng-non-bindable>${params.value}</a></span>`
                    }              
                },   
                {
                    field:"comment",
                    headerName:"Comment",
                    minWidth:150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        if(params.data.com_id == null || params.data.com_comment=='' || params.data.com_comment==null){
                            return `<i class="far fa-comment pointer" note="Add Comment" title="{{menu.translateLabels(8921)}}" ng-click='bowtieCtrl.AddComments(${cleanDoubleCurly(JSON.stringify(params.data))})'></i>`
                        } else {
                            return `<i class="fa fa-comment pointer" note="Edit Comment" title="{{menu.translateLabels(9043)}}" ng-click='bowtieCtrl.AddComments(${cleanDoubleCurly(JSON.stringify(params.data))})'></i>`
                        }
                        
                    } 
                }      
            ]
            vm.attachmentOptions.columnDefs = attachmentColumns
            
            //Funtion to open a attachment file in a new tab
            vm.openAttachment = (name) => {
                vm.attachmentURL =  $sce.trustAsResourceUrl(`${__env.imageUrl}/${name}`)
                $window.open(vm.attachmentURL, "_blank")
            }

            vm.AddComments=(data) =>{
                document.getElementById('mode').innerText = data.com_id
                document.getElementById('comment').value = data.com_comment ? data.com_comment.replaceAll("'","&#39") : null 
                document.getElementById('callingform').innerHTML= 'BOWTIECALLIMAGECOMMENTSMODAL'
                document.getElementById('savetomemory').innerHTML = "false"
                document.getElementById('parentform').innerHTML = vm.mod_id
                document.getElementById('imageid').innerText = data.rat_id  
                document.getElementById('viewOnly').innerText = vm.viewOnlyCheck()
                vm.currentAttachment=data.rat_id 
                document.getElementById('comment_id').innerHTML = data.com_id 
                $rootScope.$broadcast("RECIEVEROFCOMMENTS", data.com_comment ) 
            }
            

            $scope.$on('BOWTIECALLIMAGECOMMENTSMODAL', (event, data) => {
                vm.refreshAttachmentsRowData(data)
            })

            vm.refreshAttachmentsRowData = (data) => {
                let rowData = []
                vm.attachmentOptions.api.forEachNode((node) => rowData.push(node.data))
                rowData.forEach((node) => {
                    if (node.rat_id == vm.currentAttachment) {
                        node.com_comment=data.com_comment
                        node.com_id=data.com_id
                    }
                }) 
                vm.attachmentOptions.api.setRowData(rowData)
            }

            //Function to refresh/get attachment data
            function refreshAttachments (id) {
                if(id)
                {
                    payload = {
                        rmm_id: id,
                        mod_id: vm.mod_id
                    }
                    rmmAttachmentsService.getRmmAttachments(payload).then((response) => {
                        vm.attachmentData = response
                    
                        if (vm.attachmentOptions.api) {
                            translateAgGridHeader (vm.attachmentOptions)
                            vm.attachmentOptions.paginationPageSize = 15
                            vm.attachmentOptions.api.setRowData(prepareAttachmentsGridData(vm.attachmentData))
                            vm.attachmentOptions.api.redrawRows()
                            vm.attachmentOptions.api.sizeColumnsToFit()
                        }
                    })
                }
                else if (vm.attachmentOptions.api) {
                    translateAgGridHeader (vm.attachmentOptions)
                    vm.attachmentOptions.paginationPageSize = 15
                    vm.attachmentOptions.api.setRowData([])
                    vm.attachmentOptions.api.redrawRows()
                    vm.attachmentOptions.api.sizeColumnsToFit()
                }
            }

            function prepareAttachmentsGridData(data) {
                let gridData = JSON.parse(JSON.stringify(data))
                gridData.forEach((rec) =>{
                    rec.exceptionFields = ['rat_enable','rat_rmm_id','rat_mod_id','com_id','rat_id','rat_bowtie_show_check_box']
                    rec.com_comment = rec.com_comment ? rec.com_comment.replaceAll("'","&#39") : null
                    rec.rat_created_by_per = vm.getEmployeeName(rec.rat_created_by_per)
                    rec.rat_modified_by_per = vm.getEmployeeName(rec.rat_modified_by_per)
                    rec.rat_created_date = moment(rec.rat_created_date).format('YYYY-MM-DD')
                    rec.rat_modified_date = rec.rat_modified_date? moment(rec.rat_modified_date).format('YYYY-MM-DD') : '' 
                    rec.rat_bowtie_show_check_box = vm.bowtie_show_check_box
                })
                return gridData
            }

            //Function to add attachments
            function addAttachments (att){
                if(vm.currentMode === "new") {
                    if (validateFormFields('bowtieForm', true)) {
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentBow)))
                        payload.rmm_bow_is_submitted = false

                        bowtieService.createBowtie(payload).then((response) => {
                            vm.currentBow.rmm_bow_id = response.rmm_bow_id
                            vm.openViewer('edit', vm.currentBow.rmm_bow_id)
                            resetFormFieldClassList('bowtieForm')
                            let fd = new FormData()
                            for (let i in vm.uploadFileList) {
                                fd.append("rmm_id", vm.currentBow.rmm_bow_id)
                                fd.append("mod_id", vm.mod_id)
                                fd.append("rmm_files", vm.uploadFileList[i])
                            }
                            rmmAttachmentsService.addRmmAttachments(fd).then((res) => {
                                refreshAttachments(vm.currentBow.rmm_bow_id)
                                vm.uploadFileList = []
                            })
                            refreshData()
                            vm.bowtie_show_check_box = true
                            toastr.success(translateTag(4278)) //Saved Successfully                             
                        })
                    }
                    else{
                        $rootScope.$broadcast("CALLCONFIRMMODAL")
                    }
                }
                else {
                    let fd = new FormData()
                    for (let i in vm.uploadFileList) {
                        fd.append("rmm_id", vm.currentBow.rmm_bow_id)
                        fd.append("mod_id", vm.mod_id)
                        fd.append("rmm_files", vm.uploadFileList[i])
                    }
                    rmmAttachmentsService.addRmmAttachments(fd).then((res) => {
                        refreshAttachments(vm.currentBow.rmm_bow_id)
                        vm.uploadFileList = []
                    })
                }                
            }

            //Function to open delete confirmation Modal
            vm.deleteAttachmentConfirmationModal = () => {
                vm.deleteAttCount = vm.attachmentOptions.api.getSelectedRows().length
                vm.modalElementsDelete = {
                    title: translateTag(3416), //"Delete Attachment?"
                    message: `<div><p>${translateTag(3581)} ${vm.deleteAttCount} ${translateTag(3417)}</p></div>`, //"You are about to delete {{bowtieCtrl.deleteAttCount}} attachments. Undoing this will require IT support. Are you sure?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Yes">{{vm.componentTranslateLabels(1379)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                }
                document.getElementById('confirmcallingform').innerHTML = 'BOWTIEDELETEATTACHCALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsDelete)
            }

            $scope.$on("BOWTIEDELETEATTACHCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.deleteAttachment()
                }
            })

            //Function to delete the selected attachment rows
            vm.deleteAttachment = () => {
                var rows = vm.attachmentOptions.api.getSelectedRows()
                if (rows.length > 0) {
                var ids = []
                for (var i = 0; i < rows.length; i++) {
                    ids.push(rows[i].rat_id)
                }
                payload={rat_id: ids, mod_id: vm.mod_id}
                rmmAttachmentsService.removeRmmAttachments(payload).then((r) => {
                    refreshAttachments(vm.currentBow.rmm_bow_id)
                })
                }    
                modalService.Close('confirmModal')
            }

            //Function to add/remove an acknowledgment to an assessment via the Ag-Grid
            vm.addAcknowledge = () => {
                let payload = {}
                payload.rmm_bow_id = vm.bowDataContext.rmm_bow_id
                vm.currentAcknowledge = vm.bowDataContext
                    bowtieService.reviewBowtie(payload).then (() => {
                        refreshData()
                        modalService.Close('confirmModal')
                    })
            }

            //Function to open the Acknowledge History modal
            vm.viewAcknowledgeHistory = (bowData) => {
                if(!bowData.reviewedCount > 0 || !bowData.rmm_bow_is_submitted)
                    return

                vm.currentAcknowledgeHistory = []            
                bowData.reviewers.forEach((rev) => {
                    let acknowledgment = {

                        name: vm.getEmployeeName(rev.rmm_bre_per_id),
                        pos: rev.rmm_bre_position_name,
                        reviewed_date: rev.rmm_bre_created_date
                    }
                    vm.currentAcknowledgeHistory.push(acknowledgment)
                })
                $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentAcknowledgeHistory,translateLabels(3717)) //"Bowtie Risk Assessment Reviews"
            }

            //Function to check if the current user has Acknowledged this assessment
            function checkAcknowledged (BowtieData) {
                let response = false
                BowtieData.reviewers.forEach((rev) => {
                    if(rev.rmm_bre_per_id == vm.userId){
                        response = true
                    }
                })
                return response
            }

            //Fuction used to close modals
            vm.cancelModal = (modalId) => {
                vm.updatingRecord = false
                modalService.Close(modalId)
                vm.initializeSelect2('newBowtie')
            }

            //Function to open the viewer
            vm.openViewer = (mode='new', id) => {
                if(!vm.canManageBowtie)
                    return

                // Activate the Autosave
                if(mode !== 'view') {
                    vm.autosave = $interval(() => {
                        vm.saveBowtie('autosave')
                        }, 60000)
                }

                if(mode === 'new') {
                    vm.currentMode = 'new'
                    vm.initializeTagsAndPulldowns()
                    destroyTables().then(()=>{
                        initiateTables()
                    })
                    vm.userInApprovers = true
                    vm.hideingBowtieViewer = false
                    vm.bowtieViewerOpen = true
                    vm.openingBowtieViewer = true
                    $timeout(() => {
                        vm.openingBowtieViewer = false
                        $('#newBowtie').data('serialize',$('#newBowtie').serialize())
                    }, 400)
                    refreshAttachments()
                }
                else if (mode === 'edit') {
                    vm.documentDetails = {}
                    vm.documentDetails.dlo_document_id = id
                    vm.documentDetails.dlo_dlt_id = 4 //BOWTIE
                    $q.all([
                        documentLockService.docLock(vm.documentDetails)
                    ]).then((response) => {
                        vm.dlo_id = response[0].dlo_id
                        vm.docLockStatus = response[0].status
                        vm.docLockMessage = response[0].message
                        vm.docLockTime = response[0].time
                        if (!vm.docLockStatus){
                            throwToastr('warning',vm.docLockMessage,2000)
                        }   
                    }).then(() => {
                        if(vm.docLockStatus === true){
                            vm.currentMode = 'edit'
                            vm.saved = true
                            toastr.options.progressBar = true
                            $scope.$emit('STARTSPINNER', translateTag(8627)) // require translation tag
                            vm.getSingleDetailRec(id).then(() => {
                                vm.initializeTagsAndPulldowns()
                                vm.validateCurrentUserInApprovers()
                                vm.hideingBowtieViewer = false
                                vm.bowtieViewerOpen = true
                                vm.openingBowtieViewer = true
                                if(!vm.currentBow.rmm_bow_is_submitted){
                                    vm.bowtie_show_check_box = true
                                }
                                refreshAttachments(vm.currentBow.rmm_bow_id)
                                $timeout(() => {
                                    vm.openingBowtieViewer = false
                                    $('#newBowtie').data('serialize',$('#newBowtie').serialize())
                                    $scope.$emit('STOPSPINNER')
                                }, 400)
                            })

                            startUpdateDocLock()
                            startLockModal()

                        }
                    })
                }
                else if(mode === 'view') {
                    $scope.$emit('STARTSPINNER', translateTag(8627))
                    vm.getSingleDetailRec(id).then(() => {
                        vm.initializeTagsAndPulldowns()
                        vm.validateCurrentUserInApprovers()
                        vm.hideingBowtieViewer = false
                        vm.bowtieViewerOpen = true
                        vm.openingBowtieViewer = true
                        refreshAttachments(vm.currentBow.rmm_bow_id)
                        $timeout(() => {
                            vm.openingBowtieViewer = false
                            $('#newBowtie').data('serialize',$('#newBowtie').serialize())
                            $scope.$emit('STOPSPINNER')
                        }, 400)
                    })
                }
            }


            // functions for document lock start__

            //Zero the idle timer on mouse movement.
            $('#newBowtie').mousemove(function (e) {
                clearInterval(vm.lockModal)                
                vm.idletime = 0
                startLockModal()
            });

            //Zero the idle timer on keypres event
            $('#newBowtie').keypress(function (e) {
                clearInterval(vm.lockModal)
                vm.idletime = 0
                startLockModal()
            });

            vm.continueEditingBowtie = () => {
                vm.cancelModal('confirmModal')
                vm.countdownSeconds = 60
                vm.lockCheckModal = false
                vm.continueEditing = true
                document.getElementById('inactiveTime').textContent = ''
                clearInterval(vm.lockModal)
                clearInterval(vm.countdownTimer)
                clearTimeout(vm.relieveLock)
                vm.idletime = 0
                startLockModal()
            }
           
            function startUpdateDocLock(){
                vm.updateDocLockInterval = setInterval(() => {
                    $q.all([
                        documentLockService.intervalDocLock(vm.dlo_id)
                    ]).then((response) => {
                    })
                }, 30 * 1000)
            }

            function startLockModal(){
                vm.lockModal = setInterval(() => {
                    vm.idletime = vm.idletime + 1 // 1 minute
                    if(vm.idletime === 5){ // after 5 minutes of idle time open lockcheck modal
                        vm.continueEditing = false
                        vm.leaveEditing = false
                        vm.modalElementsLock = {
                            title: translateTag(3419),   //"Page inactive for 5 minutes" 
                            message: `<div style="text-align: center;"><h1 id ="inactiveTime" ></h1><p> ${translateTag(3420)}</p></div>`,  //"The entry will automatically save and close if no action is taken"
                            buttons: 
                                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Continue Working">{{vm.componentTranslateLabels(3421)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Save and Close">{{vm.componentTranslateLabels(3422)}}</button>`
                        }
                        document.getElementById('confirmcallingform').innerHTML = 'BTLOCKCALLCONFIRMMODAL' 
                        $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsLock)
                        vm.lockCheckModal = true
                        startcountdownTimer()
                        vm.relieveLock = setTimeout(() => {
                            if (vm.lockCheckModal === true){
                                if (!vm.continueEditing && !vm.leaveEditing){
                                    vm.leaveEditing = true
                                    vm.saveAndCloseBowtie()
                                }
                            }
                        }, 60 * 1000);
                    }                                        
                }, 60 * 1000);
            }

            $scope.$on("BTLOCKCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.continueEditingBowtie()
                }
                else if (result=='button2') {
                    vm.saveAndCloseBowtie()
                }
            })

            function startcountdownTimer(){
                vm.countdownTimer = setInterval(() => {
                    if(vm.lockCheckModal === true && vm.countdownSeconds>=0){
                        vm.content = ''
                        if (vm.countdownSeconds === 60){
                            vm.content = "01:00"
                        }
                        else{
                            vm.content = "00:" + vm.countdownSeconds.toLocaleString('en-US', {
                                minimumIntegerDigits: 2,
                                useGrouping: false
                              }) 
                        }
                        document.getElementById('inactiveTime').textContent =  vm.content
                        vm.countdownSeconds = vm.countdownSeconds - 1   
                    }                                     
                }, 1000)
            }

            // functions for document lock end___ 

            // An abstrect function to initialize the dropdowns and tags
            vm.initializeTagsAndPulldowns = () =>{
                vm.initializeSelect2('newBowtie')
                vm.initializeTags() 
            }

            // function to get single detail record
            vm.getSingleDetailRec = (id) =>{
                return (
                    $q.all([
                        bowtieService.getBowtieSIngleDetailRec(id).then((response) => {
                            vm.currentBow = JSON.parse(JSON.stringify(response))
                            vm.prepResponseSingleDetail()
                        }),
                    ])
                )
            }
            // An abstrect function to prepare response payload for single detail record
            vm.prepResponseSingleDetail = () =>{     
                vm.currentBow.approversList = []           
                angular.copy(vm.currentBow.approvers,vm.currentBow.approversList)
                vm.currentBow.approvers = getApprovers(vm.currentBow.approvers)
                vm.currentBow.rmm_bow_created_date = moment(vm.currentBow.rmm_bow_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                vm.currentBow.rmm_bow_date = vm.currentBow.rmm_bow_date===null?null:moment(vm.currentBow.rmm_bow_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                vm.currentBow.rmm_bow_expiry_date = vm.currentBow.rmm_bow_expiry_date===null?null:moment(vm.currentBow.rmm_bow_expiry_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                vm.rmm_bow_doc_revision_no = `${appendLeadingZeros(vm.currentBow.rmm_bow_document_number)}`+'.'+`${appendLeadingZeros(vm.currentBow.rmm_bow_doc_version_number,3)}`
                vm.pem = []
                vm.pcm = []
                if(vm.currentBow.rmm_bow_site){
                    vm.getFilteredEmployees()
                }
                if (vm.currentBow.rmm_bow_document_type!==null){
                    vm.loadDocumentTitles()
                }
                if (vm.currentBow.rmm_bow_document_id!==null){
                    vm.loadEventCategoryList()
                }
                if (vm.currentBow.rmm_bow_risk_category_id!==null){
                    vm.loadMajorUnwantedEventList()
                }
                if (vm.currentBow.rmm_bow_risk_sub_category_id!==null){
                    vm.loadRiskAssessments()
                }
                vm.currentBow.root_causes_events.forEach((rc)=>{
                    vm.pem.push(rc.event_mitigations[0])
                })

                vm.currentBow.consequences.forEach((con)=>{
                    vm.pcm.push(con.consequence_mitigations[0])
                })
                vm.refreshActions(vm.currentBow.rmm_bow_id)
            }

            //Function to refresh the action data
            vm.refreshActions = (id) => {
                payload = {
                    rmm_bow_id: id
                }
                $q.all([
                    bowtieService.getGaHaActions(payload).then((response) => {
                        vm.currentBow.general_actions = actionManagementService.addCanCloseActionPermission(response.general_actions, 'general', vm.canCloseAllActions, vm.userId)
                        vm.currentBow.hazard_actions = actionManagementService.addCanCloseActionPermission(response.hazard_actions, 'hazard', vm.canCloseAllActions, vm.userId)
                        vm.immediateActions()
                    })
                ]).then(()=>{
                    destroyTables().then(()=>{
                        initiateTables()
                    })
                })
            }      

            vm.immediateActions = () =>{
                vm.currentBow.hazard_actions.forEach((data)=>{
                    if(!data.further_action_required && data.immediate_action_required_and_performed) {
                        data.action_complete_by_who = data.created_by
                        data.recommended_action = data.immediate_action_taken
                        data.action_by_when = moment(data.sha_created_date).format('YYYY-MM-DD')
                    }
                })
            }
            
            //Function to force close the viewer
            vm.forceCloseViewer = () => {
                vm.cancelModal('confirmModal')
                           
                vm.cancelModal('signBowtieSuccessModal')
                vm.cancelModal('signBowtieFailureModal')
                vm.employeeList = []
                vm.releaseDocument(vm.dlo_id).then((response) => {
                })
                clearInterval(vm.updateDocLockInterval)
                clearInterval(vm.lockModal)
                clearInterval(vm.countdownTimer)
                // Stop the autosave
                $interval.cancel(vm.autosave)
                vm.hideingBowtieViewer = true
                vm.resetForm()
                refreshData()
                $timeout(() => {
                    vm.bowtieViewerOpen = false
                }, 400)
            }
            
            //Function to close the viewer
            vm.closeViewer = () => {
                hasFormChanged()
                if (!vm.currentUserSigned){
                    if (vm.changesInForm){
                        vm.modalElementsChange = {
                            title: translateTag(2273), //"Confirm Changes"
                            message: `<div><p>${translateTag(2274)}</p></div>`, //"Any unsaved changes made on this document would be lost! Do you want to proceed ?"
                            buttons: 
                                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="SAVE & CLOSE">{{vm.componentTranslateLabels(2276)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note= "CLOSE ANYWAY">{{vm.componentTranslateLabels(2275)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button3')" note= "Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                        } 
                        document.getElementById('confirmcallingform').innerHTML = 'BTCHANGECALLCONFIRMMODAL' 
                        $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsChange)
                        return
                    }
                }
                vm.releaseDocument(vm.dlo_id).then((response) => {
                })
                clearInterval(vm.updateDocLockInterval)
                clearInterval(vm.lockModal)
                           
                vm.cancelModal('signBowtieSuccessModal')
                vm.cancelModal('signBowtieFailureModal')
                // stop the autosave
                $interval.cancel(vm.autosave)
                clearInterval(vm.countdownTimer)
                vm.hideingBowtieViewer = true
                vm.resetForm()
                refreshData()
                $timeout(() => {
                    vm.bowtieViewerOpen = false
                }, 400)
            }

            $scope.$on("BTCHANGECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.saveAndCloseBowtie()
                }
                else if (result=='button2') {
                    vm.forceCloseViewer()
                }
                else if (result=='button3') {
                    vm.cancelModal('confirmModal')
                }
            })

            // function to release document lock
            vm.releaseDocument = (id) => {
                payload = {}
                payload.dlo_id = id
                return (
                    $q.all([
                        documentLockService.closeDocLock(payload)
                    ])
                )
            }

            //Function to open modals
            vm.openModal = (modalId) => {
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()

                $('.modal .scroll').scrollTop(0)

                modalService.Open(modalId)
                vm.initializeSelect2(modalId, '.modal-body')
            }

            //Function to open the create action modals
            vm.openActionModal = (modalId, mititgationType) => {
                resetFormFieldClassList('bowtieForm')
                if(validateFormFields('bowtieForm', true)){
                    vm.action_mitigation_type = mititgationType
                    vm.actionMode = 'new'
                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()
                    $('.modal .scroll').scrollTop(0)
                
                    if(vm.currentMode === "new") {                                                        // Save the Document before opening an action modal
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentBow)))
                        payload.rmm_bow_is_submitted = false
                        vm.updatingRecord = true
                        toastr.options.progressBar = true
                        throwToastr('info', translateTag(3784),5000) //Loading..."
                        bowtieService.createBowtie(payload).then((response) => {
                            if (response.rmm_bow_id){
                                vm.getSingleDetailRec(response.rmm_bow_id).then(() => {
                                    $q.all([
                                        vm.initializeTagsAndPulldowns()
                                    ]).then((data) => {
                                        vm.rmm_bow_doc_revision_no = `${appendLeadingZeros(vm.currentBow.rmm_bow_document_number)}`+'.'+`${appendLeadingZeros(vm.currentBow.rmm_bow_doc_version_number,3)}`
                                        vm.validateCurrentUserInApprovers()
                                        $('#newBowtie').data('serialize',$('#newBowtie').serialize())
                                        resetFormFieldClassList('bowtieForm')
                                        modalService.Open(modalId)
                                        vm.initializeSelect2(modalId, '.modal-body')
                                    })
                                })
                                refreshData()
                            }
                            if (!response){
                                throwToastr('error', "Action failed. Please try again", 2000)
                            }
                            vm.updatingRecord = false
                        })
                    }
                    else{
                        modalService.Open(modalId)
                        vm.initializeSelect2(modalId, '.modal-body')
                    }
                }else{
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            //Function to open the edit action modals
            vm.openActionEditModal = (modalId, id) => {
                vm.actionMode = 'edit'
                if(modalId === 'generalActionModal') {
                    openGeneralEdit(id, modalId)
                    vm.refreshActions(vm.currentBow.rmm_bow_id)
                }
                else if(modalId === 'hazardActionModal') {
                    openHazardEdit(id, modalId)
                    vm.refreshActions(vm.currentBow.rmm_bow_id)
                }
            }

            //Function to prepare data to edit a general action
            function openGeneralEdit(id, modalId) {
                actionManagementService.getGeneralActionSingle({sga_id: id}).then ((response) => {
                    vm.generalEditData = response

                    vm.generalEditData.Site = parseInt(vm.generalEditData.Site)
                    vm.generalEditData.JobNumber = parseInt(vm.generalEditData.JobNumber)
                    vm.generalEditData.SiteLevel = parseInt(vm.generalEditData.SiteLevel)
                    vm.generalEditData.Supervisor = parseInt(vm.generalEditData.Supervisor)

                    vm.generalEditData.HeaderDate = moment(vm.generalEditData.HeaderDate).format('YYYY-MM-DD')
                    vm.generalEditData.sga_action_by_who_per_id = vm.generalEditData.sga_action_by_who_per

                    let i = 0
                    let initialAtt = JSON.parse(JSON.stringify(vm.generalEditData.attachments))
                    initialAtt.forEach((att) => {
                        if(att.gaa_type === 'FOLLOWUP')
                            vm.generalEditData.attachments.splice(i, 1)
                        else
                            i++
                    })
                    
                    vm.generalEditData.attachments.forEach((att) => {
                        att.imageDir = `${__env.imageUrl}/`
                    })

                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()

                    $('.modal .scroll').scrollTop(0)

                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId,  '.modal-body')
                })
            }

            //Function to prepare data to edit a hazard action
            function openHazardEdit(id, modalId) {
               
                actionManagementService.getHazardActionSingle({hap_id: id}).then ((response) => {
                    vm.hazardEditData = response

                    vm.hazardEditData.Site = parseInt(vm.hazardEditData.Site)
                    vm.hazardEditData.JobNumber = parseInt(vm.hazardEditData.JobNumber)
                    vm.hazardEditData.SiteLevel = parseInt(vm.hazardEditData.SiteLevel)
                    vm.hazardEditData.Supervisor = parseInt(vm.hazardEditData.Supervisor)

                    vm.hazardEditData.HeaderDate = moment(vm.hazardEditData.HeaderDate).format('YYYY-MM-DD')

                    let i = 0
                    let initialAtt = JSON.parse(JSON.stringify(vm.hazardEditData.attachments))
                    initialAtt.forEach((att) => {
                        if(att.attachmenttype === 'FOLLOWUP')
                            vm.hazardEditData.attachments.splice(i, 1)
                        else
                            i++
                    })
                    
                    vm.hazardEditData.attachments.forEach((att) => {
                        att.imageDir = `${__env.imageUrl}/`
                    })

                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()

                    $('.modal .scroll').scrollTop(0)

                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId, '.modal-body')
                })
            }

            //Function to open the complete action modals
            vm.completeActionModal = (action, type) => {
                if(type === 'General')
                {
                    actionManagementService.getGeneralActionSingle({sga_id: action.sga_id}).then ((response) => {
                        vm.generalFollowup = response
                        vm.generalFollowup.sga_completed_action_date = dateToday.format('YYYY-MM-DD')
                        vm.generalFollowup.sga_action_by_who_per_id = vm.getEmployeeName(vm.generalFollowup.sga_action_by_who_per)
                        if(vm.generalFollowup.sga_completed_action_by_who_per != null)
                            vm.generalFollowup.sga_completed_action_by_who_per_id = parseInt(getEmployeeID(vm.generalFollowup.sga_completed_action_by_who_per))
                        vm.generalFollowup.attachment_files_initial = []
                        vm.generalFollowup.attachment_files_followup = []

                        vm.generalFollowup.attachments.forEach((attRec) => {
                            if(attRec.gaa_type == 'INITIAL')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                vm.generalFollowup.attachment_files_initial.push(attRec)
                            }
                            else if(attRec.gaa_type == 'FOLLOWUP')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                vm.generalFollowup.attachment_files_followup.push(attRec)
                            }
                        })

                        vm.openModal('completeGeneralActionModal')
                        setTimeout(()=>{
                            $scope.$broadcast('GENERAL_FOLLOWUP_OPENED')
                        },100) 
                    })
                }
                else
                {
                    actionManagementService.getHazardActionSingle({hap_id: action.id}).then ((response) => {
                        vm.followup = response
                        vm.followup.action_completed_date = dateToday.format('YYYY-MM-DD')
                        vm.followup.action_complete_by_who = (vm.followup.action_complete_by_who && vm.followup.action_complete_by_who != 'None') ? parseInt(getEmployeeID(vm.followup.action_complete_by_who)) : null
                        vm.followup.attachmentModalFiles = []
                        vm.followup.followupAttachmentModalFiles = []

                        vm.followup.attachments.forEach((attRec) => {
                            if(attRec.attachmenttype === 'INITIAL')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                attRec.AttachmentFileName = attRec.attachmentfilename
                                vm.followup.attachmentModalFiles.push(attRec)
                            }
                            else if(attRec.attachmenttype === 'FOLLOWUP')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                attRec.AttachmentFileName = attRec.attachmentfilename
                                vm.followup.followupAttachmentModalFiles.push(attRec)
                            }
                        })

                        vm.followup.HapId = action.id
                        vm.followup.action_by_who_name = vm.getEmployeeName(action.action_by_who)

                        vm.openModal('hapFollowupComponent')
                        setTimeout(()=>{
                            $scope.$broadcast('HAZARD_FOLLOWUP_OPENED')
                        },100)
                    })
                }
            }

            // Function to validate approvers for sign
            vm.validateCurrentUserInApprovers = () => {
                vm.userInApprovers = false
                if (vm.currentBow.approvers.length > 0){
                    vm.currentBow.approvers.forEach((app) => {
                        if (app === vm.userId){
                            vm.userInApprovers = true
                            return
                        }
                    })
                }
            }
            
            //Function to validate for Sign modal
            vm.validateForSign = () => {
                vm.noOfHaps = 0
                vm.signFlag = true
                vm.currentBow.hazard_actions.forEach((hap)=> {
                    if (hap.action_status !== 1){
                        vm.noOfHaps += 1
                        vm.signFlag = false
                    }
                })
                return vm.signFlag
            }

            // Function to verify if form has changed
            function hasFormChanged() {
                if($('#newBowtie').serialize() != $('#newBowtie').data('serialize')){
                    $('#newBowtie').data('serialize',null)
                    vm.changesInForm = true
                }                
            }

            //Function to open the complete action modals
            vm.signActionModal = () => {
                if(vm.validateBowtie()){
                    vm.updatingRecord = true
                    hasFormChanged()
                    if (vm.changesInForm) {
                        vm.saveBowtie()
                    }                    
                    if (vm.validateForSign()){
                        vm.currentUserSigned = false
                        vm.currentBow.approversList.forEach((app) => {
                            if (app.rmm_bap_per === vm.userId && app.rmm_bap_approved){
                                vm.currentUserSigned = true 
                            }
                        })
                        if(vm.changesInForm){
                            setTimeout(()=>{
                                vm.openModal('signBowtieSuccessModal')
                            },3500)
                        }
                        else{
                            vm.openModal('signBowtieSuccessModal')
                        }
                    }
                    else {
                        if(vm.changesInForm){
                            setTimeout(()=>{
                                vm.openModal('signBowtieFailureModal')
                            },3500)
                        }
                        else{
                            vm.openModal('signBowtieFailureModal')
                        }                                          
                    }
                }else{
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }               
            }

            //Function to save the Bowtie
            vm.saveBowtie = (mode='normal') =>{
                resetFormFieldClassList('bowtieForm')
                if (validateFormFields('bowtieForm', true)){
                    // for Auto Save to not showspinner
                    if (mode === 'normal') {
                        $scope.$emit('STARTSPINNER', translateTag(8629))
                    }
                    else {
                        vm.autoSaveActive = true
                    }
                    $('#newBowtie').data('serialize',$('#newBowtie').serialize())
                    vm.changesInForm = false
                    if(vm.currentMode === "new") {
                        vm.updatingRecord = true
                        vm.saved = true
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentBow)))
                        payload.rmm_bow_is_submitted = false
                        bowtieService.createBowtie(payload).then((response) => {
                            if (response.rmm_bow_id){
                                if(mode === 'normal') {
                                    // for Auto Save to not interupt the user with refreshing
                                    vm.getSingleDetailRec(response.rmm_bow_id).then(() => {
                                        $q.all([
                                            vm.initializeTagsAndPulldowns()
                                        ]).then((data) => {
                                            vm.rmm_bow_doc_revision_no = `${appendLeadingZeros(vm.currentBow.rmm_bow_document_number)}`+'.'+`${appendLeadingZeros(vm.currentBow.rmm_bow_doc_version_number,3)}`
                                            vm.validateCurrentUserInApprovers()
                                            vm.updatingRecord = false
                                            $scope.$emit('STOPSPINNER')
                                            refreshData("save")
                                        })
                                    })
                                }
                                else {
                                    // Update everything needed for the AG- Grid - Autosave
                                    reloadAutoSave(response.rmm_bow_id)
                                }
                            }
                            else {
                                vm.updatingRecord = false
                            }
                            if (!response){
                                throwToastr("error",translateTag(3857), 2000)
                            }
                        })
                    }
                    else{
                        vm.updatingRecord = true
                        let payload = preparePayload('edit', JSON.parse(JSON.stringify(vm.currentBow)))
                        payload.rmm_bow_is_submitted = false
                        bowtieService.updateBowtie(payload).then((response) => {
                            if (response.rmm_bow_id){
                                // for Auto Save to not interupt the user with refreshing
                                if(mode === 'normal') {
                                    vm.getSingleDetailRec(response.rmm_bow_id).then((response) => {
                                        $q.all([
                                            vm.initializeTagsAndPulldowns()
                                        ]).then((data) => {
                                            vm.rmm_bow_doc_revision_no = `${appendLeadingZeros(vm.currentBow.rmm_bow_document_number)}`+'.'+`${appendLeadingZeros(vm.currentBow.rmm_bow_doc_version_number,3)}`
                                            vm.validateCurrentUserInApprovers()
                                            vm.updatingRecord = false
                                            $scope.$emit('STOPSPINNER')
                                            refreshData("save")
                                        })
                                    })
                                }
                                else {
                                    // Update everything needed for the AG- Grid - Autosave
                                    reloadAutoSave(response.rmm_bow_id)
                                }
                            }
                            if (!response){
                                throwToastr("error",translateTag(3858), 2000)         
                            }
                        }) 
                    }
                }else{
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            function reloadAutoSave(id) {
                // Update everything needed for the AG- Grid - Autosave
                bowtieService.getBowtieSIngleDetailRec(id).then((res) => {
                    vm.currentBow.approversList = []
                    angular.copy(res.approvers,vm.currentBow.approversList)
                    vm.currentBow.approvers = getApprovers(res.approvers)
                    vm.currentBow.rmm_bow_id =  res.rmm_bow_id
                    vm.currentBow.rmm_bow_state =  res.rmm_bow_state
                    vm.currentBow.rmm_bow_doc_version_number = res.rmm_bow_doc_version_number
                    vm.currentBow.rmm_bow_document_number = res.rmm_bow_document_number
                    vm.currentBow.consequences.forEach((con,conindex) => {
                        if(res.consequences[conindex]) {
                            con.rmm_bco_bow = res.consequences[conindex].rmm_bco_bow
                            con.rmm_bco_id = res.consequences[conindex].rmm_bco_id
                            con.rmm_bco_created_by_per = res.consequences[conindex].rmm_bco_created_by_per
                        }
                        con.consequence_mitigations.forEach((conmit,conmitindex)=>{
                            if(res.consequences[conindex].consequence_mitigations[conmitindex]) {
                                conmit.rmm_bcm_bco =  res.consequences[conindex].consequence_mitigations[conmitindex].rmm_bcm_bco
                                conmit.rmm_bcm_created_by_per = res.consequences[conindex].consequence_mitigations[conmitindex].rmm_bcm_created_by_per
                                conmit.rmm_bcm_id = res.consequences[conindex].consequence_mitigations[conmitindex].rmm_bcm_id
                            }
                        })
                    })
                    vm.currentBow.root_causes_events.forEach((rce,rceindex) => {
                        if(res.root_causes_events[rceindex]) {
                            rce.rmm_brc_bow = res.root_causes_events[rceindex].rmm_brc_bow
                            rce.rmm_brc_id = res.root_causes_events[rceindex].rmm_brc_id
                            rce.rmm_brc_created_by_per = res.root_causes_events[rceindex].rmm_brc_created_by_per
                        }
                        rce.event_mitigations.forEach((em,emindex) => {
                            if(res.root_causes_events[rceindex].event_mitigations[emindex]) {
                                em.rmm_bem_brc =  res.root_causes_events[rceindex].event_mitigations[emindex].rmm_bem_brc
                                em.rmm_bem_created_by_per = res.root_causes_events[rceindex].event_mitigations[emindex].rmm_bem_created_by_per
                                em.rmm_bem_id = res.root_causes_events[rceindex].event_mitigations[emindex].rmm_bem_id
                            }
                        })
                    })

                    vm.rmm_bow_doc_revision_no = `${appendLeadingZeros(vm.currentBow.rmm_bow_document_number)}`+'.'+`${appendLeadingZeros(vm.currentBow.rmm_bow_doc_version_number,3)}`
                    vm.validateCurrentUserInApprovers()
                    vm.updatingRecord = false
                    vm.uneditedCurrentBow = []
                    angular.copy(vm.currentBow, vm.uneditedCurrentBow)
                })
            }

            //Function to save and close the ORA
            vm.saveAndCloseBowtie = () => {
                vm.cancelModal('confirmModal')
                vm.saveBowtie()
                setTimeout(()=>{
                    vm.forceCloseViewer()
                },4700)  
            }
            
            //Function to sign the ORA
            vm.signBowtie = (modalId) => {
                if(validateText(vm.currentBow.rmm_bow_executive_summary,"")) {
                    payload = {
                        rmm_bow_id: vm.currentBow.rmm_bow_id,
                        rmm_bow_executive_summary: vm.currentBow.rmm_bow_executive_summary
                    }
                    vm.currentUserSigned = true
                    vm.cancelModal(modalId)
                    bowtieService.signBowtie(payload).then((response) => {
                        // Stop the Autosave
                        $interval.cancel(vm.autosave)
                        vm.autoSaveActive = false
                        if (response.message === "Document Signed"){
                            vm.currentUserSigned = true
                            vm.currentBow.rmm_bow_state = response.rmm_bow_state
                            vm.currentBow.approversList.forEach((app) => {       
                                if (app.rmm_bap_per === vm.userId){
                                    app.rmm_bap_approved = true         //Setting the approved flag of current approver to true
                                }
                            })
                        }
                        refreshData()
                        vm.cancelModal(modalId)
                    })
                    vm.updatingRecord = false
                }
                else{
                    document.getElementById('rmm_bow_executive_summary').classList.add('invalid')
                    document.getElementById('rmm_bow_executive_summary').setCustomValidity(false)
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            function newApprover(){
                return(                             
                    {
                        rmm_oap_per: null,
                        rmm_oap_approved: false,
                        rmm_oap_approved_date: null,
                        full_name: null
                    })
            }

            

            //Function to prepare payload data
            function preparePayload(mode='new', payload) {
                let preparedPayload = payload
                if (mode === "new"){
                    preparedPayload.rmm_bow_state = 'draft'       
                    preparedPayload.rmm_bow_date = (preparedPayload.rmm_bow_date===null || preparedPayload.rmm_bow_date===undefined) ? null:moment(payload.rmm_bow_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_bow_expiry_date = (preparedPayload.rmm_bow_expiry_date===null || preparedPayload.rmm_bow_expiry_date===undefined) ? null:moment(payload.rmm_bow_expiry_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    
                    for (let i = 0; i < preparedPayload.root_causes_events.length; i++) {
                        for (let j = 0; j < vm.pem.length; j++) {
                            if (i===j){
                                preparedPayload.root_causes_events[i].event_mitigations.push(vm.pem[i])
                            }
                        }
                        
                    }
                    for (let i = 0; i < preparedPayload.consequences.length; i++) {
                        for (let j = 0; j < vm.pcm.length; j++) {
                            if (i===j){
                                preparedPayload.consequences[i].consequence_mitigations.push(vm.pcm[i])
                            }
                        }
                    }
                    
                }else{
                    preparedPayload.rmm_bow_date = (preparedPayload.rmm_bow_date===null || preparedPayload.rmm_bow_date===undefined) ? null:moment(payload.rmm_bow_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_bow_expiry_date = (preparedPayload.rmm_bow_expiry_date===null || preparedPayload.rmm_bow_expiry_date===undefined) ?null:moment(payload.rmm_bow_expiry_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.approvers = payload.approvers != undefined ?  payload.approvers : []
                    preparedPayload.participants = payload.participants != undefined ?  payload.participants : []
                    preparedPayload.rmm_bow_site = payload.rmm_bow_site != undefined ? payload.rmm_bow_site : null


                    preparedPayload.rmm_bow_document_type = payload.rmm_bow_document_type != undefined ? payload.rmm_bow_document_type : null
                    preparedPayload.rmm_bow_document_id = payload.rmm_bow_document_id != undefined ? payload.rmm_bow_document_id : null
                    preparedPayload.rmm_bow_risk_category_id = payload.rmm_bow_risk_category_id != undefined ? payload.rmm_bow_risk_category_id : null
                    preparedPayload.rmm_bow_risk_sub_category_id = payload.rmm_bow_risk_sub_category_id != undefined ? payload.rmm_bow_risk_sub_category_id : null
                    
                    preparedPayload.rmm_bow_title = payload.rmm_bow_title ? payload.rmm_bow_title : null
                    preparedPayload.rmm_bow_scope = payload.rmm_bow_scope ? payload.rmm_bow_scope : null                   

                    
                    for (let i = 0; i < preparedPayload.root_causes_events.length; i++) {                        
                        preparedPayload.root_causes_events[i].event_mitigations = []
                        for (let j = 0; j < vm.pem.length; j++) {
                            if (i===j){
                                preparedPayload.root_causes_events[i].event_mitigations.push(vm.pem[i])
                            }
                        }
                        
                    }
                    preparedPayload.root_causes_events.forEach((rc, index) => {
                        rc.rmm_brc_root_cause = rc.rmm_brc_root_cause ? rc.rmm_brc_root_cause : null
                        rc.event_mitigations.forEach((em, index) => {
                            em.rmm_bem_event = em.rmm_bem_event ? em.rmm_bem_event : null
                        })
                    })

                    for (let i = 0; i < preparedPayload.consequences.length; i++) {
                        preparedPayload.consequences[i].consequence_mitigations = []
                        for (let j = 0; j < vm.pcm.length; j++) {
                            if (i===j){
                                preparedPayload.consequences[i].consequence_mitigations.push(vm.pcm[i])
                            }
                        }
                    }         
                    preparedPayload.consequences.forEach((cons, index) => {
                        cons.rmm_bco_consequence = cons.rmm_bco_consequence ? cons.rmm_bco_consequence : null
                        cons.consequence_mitigations.forEach((cm, index) => {
                            cm.rmm_bcm_consequence = cm.rmm_bcm_consequence ? cm.rmm_bcm_consequence : null
                        })
                    })          
                    
                }

                return preparedPayload
            }

            //Function to add an action to this assessment
            vm.addAction = (actionData) => {
                payload = {}
                if('sga_id' in actionData){
                    payload.rmm_bga_bow = vm.currentBow.rmm_bow_id
                    payload.rmm_bga_sga = actionData.sga_id
                    payload.rmm_bga_mitigation_type = vm.action_mitigation_type

                    bowtieService.addBowtieGeneralAction(payload).then((response) => {
                        vm.refreshActions(vm.currentBow.rmm_bow_id)
                    })
                }
                else if('ID' in actionData){
                    payload.rmm_bha_bow =  vm.currentBow.rmm_bow_id
                    payload.rmm_bha_sha = actionData.ID
                    payload.rmm_bha_mitigation_type = vm.action_mitigation_type

                    bowtieService.addBowtieHazardAction(payload).then((response) => {
                        vm.refreshActions(vm.currentBow.rmm_bow_id)
                    })
                }
            }

            //Function to remove completed actions from the grid
            vm.completeAction = (actionData) => {
                vm.refreshActions(vm.currentBow.rmm_bow_id)
            }

            //Funtion to initialize select2
            vm.initializeSelect2 = (parent, section='')=> {
                setTimeout(()=>{
                $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} ${section}`), escapeMarkup: function (text) { return text } })
                .on('select2:select', () => {
                    $(this).parent().find('label').addClass('filled')
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()
                today = new Date()
                if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
                $('.datepicker').pickadate({
                    format: 'yyyy-mm-dd',
                    onClose : function(){
                        this.$holder.blur()
                    },
                    min: new Date(moment(today).calendar()),
                }).removeAttr('readonly')
                .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                    evt.preventDefault()
                })
                preventFutureDatePickerInit()
                }, 500)
            }

            //Listeners
            $scope.$on('CLOSEMODAL', (event) => {
                vm.initializeSelect2('newBowtie')
            })

            $scope.$on('ADDACTION', (event, data) => {
                if(data && vm.actionMode != 'edit'){
                    vm.addAction(data)
                }else{
                    vm.refreshActions(vm.currentBow.rmm_bow_id)
                }
            })

            $scope.$on('COMPLETEACTION', (event, data) => {
                if(data)
                    vm.completeAction(data)
            })

            //Function to refresh data and Ag-Grid
            function refreshData(mode="all") {
                if(mode === 'all')
                    $scope.$emit('STARTSPINNER', vm.loadMessage)
                    
                $q.all([
                    listService.getSelectListData('ref_site'),
                    listService.getSelectListData('ref_job'),
                    listService.getSelectListData('ref_general_action'),
                    employeesService.getPersonProfile(),
                    profileService.getAllEmployeeProfile(),
                    profileService.getFullEmployeeProfile(),
                    listService.getSelectListData('ref_likelihood'),
                    listService.getSelectListData('ref_severity'),
                    listService.getSelectListData('ref_event_category'),
                    bowtieService.getBowtieList(vm.mainDateFilter),
                    listService.getFullSiteList(),
                    profileService.getRmmApproverEmployees('rmm-bowtie'),

                ]).then((data) => {
                    vm.siteList = data[0]
                    vm.jobList = data[1]
                    vm.actionTypeList = data[2]
                    vm.userId = data[3].per_id
                    vm.fullEmployeeList = profileService.readFullEmployeeProfile()
                    vm.likelyHoodList = data[6]
                    vm.severityList = data[7]
                    vm.eventCategoryList = data[8]
                    vm.bowtieAGData = bowtieService.readBowtieList()
                    vm.tmpDeletedEventCategories = []
                    vm.tmpDeletedEvents = []
                    vm.site_name = listService.readFullSites()

                    if (vm.bowtieOptions.api) {
                        translateAgGridHeader (vm.bowtieOptions)
                        let model = vm.bowtieOptions.api.getFilterModel()
                        vm.bowtieOptions.paginationPageSize = 15
                        vm.bowtieOptions.api.setRowData(prepareBowtieGridData())
                        vm.bowtieOptions.api.redrawRows()
                        vm.bowtieOptions.api.sizeColumnsToFit()
                        vm.bowtieOptions.api.setFilterModel(model)
                    }
                    vm.actionDisabled = true
                    $scope.$emit('STOPSPINNER')
                })
            }
            vm.resetForm()
            vm.bowtieViewerOpen = true
            vm.initializeSelect2('newBowtie')
            vm.bowtieViewerOpen = false

            //function to append leading zeros
            function appendLeadingZeros (num, size=6){
                var s = "000000000" + num;
                return s.substr(s.length-size);
            }

            //Function to prepare Ag-Grid data with string values
            function prepareBowtieGridData() {
                let bowtieGridData = JSON.parse(JSON.stringify(vm.bowtieAGData))
                bowtieGridData.forEach((rec) =>{
                    rec.exceptionFields = ['approvers','general_actions', 'hazard_actions', 'acknowledgements', 'participants', 'rmm_bow_enable', 'reviewers', 'dlo_enable', 'rmm_bow_slug', 'rmm_bow_risk_category_id', 'rmm_bow_risk_sub_category_id','rat_bowtie_show_check_box','rmm_bow_created_by_per_id','rmm_bsa_category', 'rmm_bsa_sub_category','rmm_bsa_document']
                    rec.rmm_bow_site = getSiteName(rec.rmm_bow_site)
                    rec.rmm_bow_created_date = moment(rec.rmm_bow_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                    rec.rmm_bow_expiry_date =  rec.rmm_bow_expiry_date===null?'':moment(rec.rmm_bow_expiry_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                    rec.rmm_bow_is_submitted  = translateTrueFalse(rec.rmm_bow_state == 'active' ||  rec.rmm_bow_state == 'expired' ? true : false)
                    rec.rmm_bow_revision_no = `${appendLeadingZeros(rec.rmm_bow_document_number)}`+'.'+`${appendLeadingZeros(rec.rmm_bow_doc_version_number,3)}`
              
                    rec.approversList = ''
                    rec.approvers.forEach((app) => {
                        rec.approversList += (`${vm.getEmployeeName(app.rmm_bap_per)} - `)
                    })
                    rec.approvers =  rec.approversList.replace(/ -\s*$/, "")
                    rec.approversList =  rec.approversList.replace(/ -\s*$/, "")

                    if(rec.dlo_enable.length !== 0){
                        rec.dlo_status = translateTrueFalse(rec.dlo_enable[0].dlo_enable)
                        rec.dlo_person = rec.dlo_enable[0].dlo_person
                    }
                    else{
                        rec.dlo_status = translateTrueFalse(true)
                        rec.dlo_person = null
                    }
                    
                    rec.participantsList = ''
                    rec.participants.forEach((par) => {
                        rec.participantsList += (`${vm.getEmployeeName(par)} - `)
                    })
                    rec.participants = rec.participantsList.replace(/ -\s*$/, "")
                    rec.participantsList = rec.participantsList.replace(/ -\s*$/, "")

                    rec.reviewersList = ''
                    rec.reviewers.forEach((rev) => {
                        rec.reviewersList += (`${vm.getEmployeeName(rev.rmm_bre_per_id)} - `)
                    })
                    rec.reviewersList =  rec.reviewersList.replace(/ -\s*$/, "")

                    rec.reviewedCount = rec.reviewers.length
                    rec.hasReviewed = translateTrueFalse(checkAcknowledged(rec))                   
                })
                return bowtieGridData
            }

            function translateStatus(status) {
                if (status === 'draft'){
                    return translateTag(1399)
                }
                if (status === 'expired'){
                    return translateTag(3494)
                } 
                if (status == 'review'){
                    return translateTag(1188)
                } 
                if (status == 'active'){
                    return translateTag(3557)
                }
            }
            function translateTrueFalse(val) {
                return val ? translateTag(1379): translateTag(1380)
            }

            //Function to prepare Participants
            function getParticipants (values)
            {
                let participants = []
                values.forEach ((rec) => {
                    participants.push(rec.llp_per)
                })
                return participants
            }

            //Function to prepare Approvers
            function getApprovers (values)
            {
                let approvers = []
                values.forEach ((rec) => {
                    approvers.push(rec.rmm_bap_per)
                })
                return approvers
            }

            // Fuction to check if all modal feilds are valid
            vm.validateBowtie = () => {
                let validated = validateFormFields('bowtieForm')
                if (!validated){vm.updatingRecord=false}
                return validated
            }

            //Update Ag-Grid size when window is resized
            $(window).on('resize', () => {
                $timeout(function () {
                    if (vm.bowtieOptions.api) {
                        vm.bowtieOptions.api.sizeColumnsToFit()
                    }
                    if (vm.attachmentOptions.api) {
                        vm.attachmentOptions.api.sizeColumnsToFit()
                    }
                })
            })

            // Function to initialize tags
            vm.initializeTags = () => {
                setTimeout(()=>{
                },50)
            }
            
            // Move the elements in an array
            function array_move(arr, old_index, new_index) {
                if (new_index >= arr.length) {
                    var k = new_index - arr.length + 1;
                    while (k--) {
                        arr.push(undefined);
                    }
                }
                arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
                return arr;
            };

            function initializeEqualHeights (){
                $('#root-cause').each(function(){ 
                    var rc_elements =this
                    $('#pe-mitigation').each(function(){
                        var pem_elements = this
                        $('h6', rc_elements).each(function(){
                            var h6_rc_elements = this
                            $('h6', pem_elements).each(function(){
                                var h6_pem_elements = this
                                // If this box is higher than the cached highest then store it
                                if($(h6_rc_elements).height() > $(h6_pem_elements).height()) {
                                    $('h6',pem_elements).height($(h6_rc_elements).height());
                                }else{
                                    $('h6',rc_elements).height($(h6_pem_elements).height()); 
                                }
                            });
                        })
                    }); 
                });
                $('#consequences').each(function(){ 
                    var consq_elements =this
                    $('#pc-mitigation').each(function(){
                        var pcm_elements = this
                        $('h6', consq_elements).each(function(){
                            var h6_consq_elements = this
                            $('h6', pcm_elements).each(function(){
                                var h6_pcm_elements = this
                                // If this box is higher than the cached highest then store it
                                if($(h6_consq_elements).height() > $(h6_pcm_elements).height()) {
                                    $('h6',pcm_elements).height($(h6_consq_elements).height());
                                }else{
                                    $('h6',consq_elements).height($(h6_pcm_elements).height()); 
                                }
                                
                            });
                        })
                    }); 
                });
            }

            function dragAndSort(){
                $( "#sortable" ).sortable({
                    items: "li:not(.ui-state-disabled)",
                    stop: function( event, ui ) {
                        vm.currentBow.event_categories.forEach((val, index) => {
                            tmp = parseInt(event.target.children[index].firstElementChild.id.split('-').pop());
                            vm.currentBow.event_categories[tmp].rmm_oec_sort = index+1
                        });
                        let tmp_event_categories = []
                        vm.currentBow.event_categories.forEach((val, index) => {
                            let new_index = val.rmm_oec_sort-1
                            tmp_event_categories.splice(new_index,0,val)
                        });
                        vm.currentBow.event_categories = tmp_event_categories
                        $scope.$apply();
                    }
                });
                $( "#sortable" ).sortable({ handle: '.handle'});
                $( "#sortable" ).disableSelection();
            }

            function destroyTables() {
                return new Promise((resolve, reject)=>{
                    if($.fn.DataTable) {
                        if ($.fn.DataTable.isDataTable(".data-table")) {
                            $('.data-table').DataTable().clear().destroy()

                            resolve(true)
                        }
                        else{
                            resolve(true)  
                        }
                    }
                })
            }

            function initiateTables() {
                setTimeout(() =>{
                    $('.data-table').DataTable({
                        "searching": false,
                        "bSort": false,
                        "bLengthChange": false,
                        "pagingType": "numbers",
                        "pageLength": 5,
                        "language": {
                            "url": `/locales/datatables/i18n/${selectedLanguage}.json`
                        }
                    });
                    $('.dataTables_length').addClass('bs-select');
                    $(".dataTables_wrapper div:last-of-type div").removeClass("col-md-5 col-md-7");
                },500)
            }

            $(document).ready(() => {
                vm.initializeTags()
                dragAndSort()
                setInterval(() => {
                    if (vm.bowtieViewerOpen){
                        initializeEqualHeights()
                    }
                }, 500);
            });
        //END
    }
])