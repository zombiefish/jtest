angular
    .module('safeToDo')
    .controller('bowtieCtrlPrint', ['bowtieService', '$routeParams',
        function (bowtieService, $routeParams) {
            var vm = this;
            if($routeParams.id){
                bowtieService.getBowtieHtml($routeParams.id).then((response) => {      
                    var win = window.open("about:blank", "_self");  
                    win.document.write(response)
                    win.focus();                    
                })
            }
                  //END
    }
])