angular
    .module('safeToDo')
    .service('bowtieService', ['$http',
        function ($http) {           
            let bowtieList = []

            return {
                getBowtieList: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/bowtie-get-list/`, payload).then((response) => {
                        bowtieList = response.data
                    }, (errorParams) => {
                        console.log('Failed to load Bowties', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            bowtieList = []
                            window.location.href = "/";
                        }
                    })
                },
                getBowtieSIngleDetailRec: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/bowtie-get-detail/${payload}/`).then((response) => {
                        bowtieDetail = response.data
                        return bowtieDetail
                    }, (errorParams) => {
                        console.log('Failed to load the single detail ORA', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            bowtieDetail = null
                            window.location.href = "/";
                        }
                    })
                },
                getBowtieHtml: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/bowtie-get-html-report/${payload}/`).then((response) => {
                        bowtieDetail = response.data
                        // console.log('rsponse for html report ___ ', bowtieDetail)
                        return bowtieDetail
                    }, (errorParams) => {
                        console.log('Failed to load the single detail ORA', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            bowtieDetail = null
                            window.location.href = "/";
                        }
                    })
                },
                getDocumentTitleList: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/bowtie-doc-title-list/${payload}/`).then((response) => {
                        docTitleList = response.data
                        return docTitleList
                    }, (errorParams) => {
                        console.log('Failed to load the Document title list', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            bowtieDetail = null
                            window.location.href = "/";
                        }
                    })
                },
                getEventCategoryList: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/bowtie-doc-category-list/${payload.type}/${payload.title_id}/`).then((response) => {
                        docCategoryList = response.data
                        return docCategoryList
                    }, (errorParams) => {
                        console.log('Failed to load the Document Category list', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            bowtieDetail = null
                            window.location.href = "/";
                        }
                    })
                },
                getMajorUnwantedEventList: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/bowtie-doc-subcategory-list/${payload.type}/${payload.title_id}/`).then((response) => {
                        docMUEList = response.data
                        return docMUEList
                    }, (errorParams) => {
                        console.log('Failed to load the Document Major Unwanted event list', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            bowtieDetail = null
                            window.location.href = "/";
                        }
                    })
                },
                getRiskAssessments: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/bowtie-doc-subcategory-data/${payload.type}/${payload.title_id}/`).then((response) => { 
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load the documents risk assessment data', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            bowtieDetail = null
                            window.location.href = "/";
                        }
                    })
                },
                getGaHaActions: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/bowtie-get-gaha-detail/${payload.rmm_bow_id}/`).then((response) => {
                        if(response.data.accessMsg){
                            toastr.error(response.data.accessMsg)
                            return []
                        }
                        else
                            return response.data
                    }, (errorParams) => {
                        console.log('Failed to load general actions', errorParams)
                    })
                },    
                createBowtie: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/bowtie-insert/`, payload).then((response) => {
                       return response.data
                    }, (errorParams) => {
                        console.log('Failed to create Bowtie', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },
                updateBowtie: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/bowtie-update/${payload.rmm_bow_id}/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to update Bowtie', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },
                signBowtie: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/bowtie-sign/`, payload).then((response) => {
                       return response.data
                    }, (errorParams) => {
                        console.log('Failed to sign Bowtie', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                archiveBowtie: (IdList) => {
                    var patchList = {
                        rmm_bow_id : IdList
                    }
                    return $http.post(`${__env.apiUrl}/api/rmm/bowtie-archive/`, patchList).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to archive document', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },

                reviewBowtie: (payload) => {                    
                    return $http.post(`${__env.apiUrl}/api/rmm/bowtie-review/${payload.rmm_bow_id}/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to review bowtie', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },
                addBowtieGeneralAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/bowtie-insert-general-action/`, payload).then((response) => {
                        if(response.data.accessMsg){
                        toastr.error(response.data.accessMsg)
                        return []
                        }
                        else
                            return response.data

                    }, (errorParams) => {
                        console.log('Failed to add Bowtie general action', errorParams)
                    })
                },
                addBowtieHazardAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/bowtie-insert-hazard-action/`, payload).then((response) => {
                        if(response.data.accessMsg){
                        toastr.error(response.data.accessMsg)
                        return []
                        }
                        else
                            return response.data

                    }, (errorParams) => {
                        console.log('Failed to add Bowtie hazard action', errorParams)
                    })
                },                
                copyRevisionBowtie: (payload) => {                    
                    return $http.post(`${__env.apiUrl}/api/rmm/bowtie-copy-revision/${payload.rmm_bow_id}/${payload.mode}/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to copy or revision bowtie', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },             

                readBowtieList: () => {
                    return bowtieList
                },

            //End
            }
        }
    ])