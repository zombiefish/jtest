angular
    .module('safeToDo')
    .service('oraService', ['$http',
        function ($http) {           
            let oraList = []

            return {
                getOraList: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/ora-get-list/`, payload).then((response) => {
                        oraList = response.data
                    }, (errorParams) => {
                        console.log('Failed to load ORAs', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            oraList = []
                            window.location.href = "/";
                        }
                    })
                },
                getOraSIngleDetailRec: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/ora-get-detail/${payload}/`).then((response) => {
                        oraDetail = response.data
                        return oraDetail
                    }, (errorParams) => {
                        console.log('Failed to load the single detail ORA', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            oraDetail = null
                            window.location.href = "/";
                        }
                    })
                },
                getGaHaActions: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/ora-get-gaha-detail/${payload.rmm_ora_id}/`).then((response) => {
                        if(response.data.accessMsg){
                            toastr.error(response.data.accessMsg)
                            return []
                        }
                        else
                            return response.data
                    }, (errorParams) => {
                        console.log('Failed to load general actions', errorParams)
                    })
                },    
                createOra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/ora-insert/`, payload).then((response) => {
                       return response.data
                    }, (errorParams) => {
                        console.log('Failed to create ora', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },
                updateOra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/ora-update/${payload.rmm_ora_id}/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to update ora', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },
                signOra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/ora-sign/`, payload).then((response) => {
                       return response.data
                    }, (errorParams) => {
                        console.log('Failed to sign Ora', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                archiveOra: (IdList) => {
                    var patchList = []
                    for (var i = 0; i < IdList.length; i++) {
                        patchList.push({ rmm_ora_id: IdList[i]})
                    }
                    return $http.post(`${__env.apiUrl}/api/rmm/ora-archive/`, patchList).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to archive lesson', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },

                reviewOra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/ora-review/${payload.rmm_ora_id}/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to review ora', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },
                addOraGeneralAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/ora-insert-general-action/`, payload).then((response) => {
                        if(response.data.accessMsg){
                        toastr.error(response.data.accessMsg)
                        return []
                        }
                        else
                            return response.data

                    }, (errorParams) => {
                        console.log('Failed to add ORA general action', errorParams)
                    })
                },
                addOraHazardAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/ora-insert-hazard-action/`, payload).then((response) => {
                        if(response.data.accessMsg){
                        toastr.error(response.data.accessMsg)
                        return []
                        }
                        else
                            return response.data

                    }, (errorParams) => {
                        console.log('Failed to add ORA hazard action', errorParams)
                    })
                },                
                copyRevisionOra: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/rmm/ora-copy-revision/${payload.rmm_ora_id}/${payload.mode}/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to copy or revision ora', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                oraBowtie: (payload) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/ora-bowtie/${payload}/`).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load Bowties', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },
                validateBowtieOra: (ora_id) => {
                    return $http.get(`${__env.apiUrl}/api/rmm/validate-bowtie-ora/${ora_id}/`).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load Bowties', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                        return false
                    })
                },
                readOraList: () => {
                    return oraList
                },

            //End
            }
        }
    ])