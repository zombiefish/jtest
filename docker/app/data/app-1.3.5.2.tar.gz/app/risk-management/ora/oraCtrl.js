angular
    .module('safeToDo')
    .controller('oraCtrl', ['$rootScope','$scope', '$timeout', '$q', '$compile', '$window', '$interval', '$sce', 'gridService', 'select2Service',
      'oraService', 'listService', 'modalService', 'profileService', 'employeesService','menuService', 'actionManagementService', 'documentLockService','rmmAttachmentsService','fileUploadService', 'exportCSV',
        function ($rootScope,$scope, $timeout, $q, $compile, $window, $interval, $sce, gridService, select2Service, oraService, listService,
            modalService, profileService, employeesService, menuService, actionManagementService, documentLockService,rmmAttachmentsService,fileUploadService, exportCSV) {
            var vm = this;
            
            let dateToday = moment(new Date(), 'YYYY-MM-DD')
            vm.employeeList = []
            vm.fullEmployeeList = []
            vm.currentAcknowledgeHistory = []
            vm.userId = null
            vm.siteList = []
            vm.jobList = []
            vm.jobListSelect = []
            vm.actionTypeList = []
            vm.singleServeReportUrl = 'organizational_risk_assessment'
            vm.bowtieReportUrl = 'bowtie'
            vm.LLDataContext = {}
            vm.topSearch = ''
            vm.archiveCount = 0
            vm.deleteAttCount = 0
            vm.oraAGData = []
            vm.attachmentData = []
            vm.newAttachments = []
            vm.uploadFileList= []
            vm.actionDisabled = true
            vm.attActionDisabled = true
            vm.canViewORA = false
            vm.canManageORA = true
            vm.oraViewerOpen = false
            vm.hideingOraViewer = false
            vm.openingOraViewer = false
            vm.currentAcknowledge = null
            vm.generalEditData = {}
            vm.hazardEditData = {}
            vm.tmpDeletedEventCategories = []
            vm.tmpDeletedEvents = []
            vm.likelyHoodList = []
            vm.severityList = []
            vm.performActionMode = ''
            vm.selectedRecordCount = 0
            vm.rmm_ora_doc_revision_no = null
            vm.updatingRecord = false
            vm.userInApprovers = false
            vm.changesInForm = false
            vm.canArchiveSubmissions = false
            vm.currentUserSigned = false
            vm.selectedDocumentNo = ''
            vm.ora_bowties = []
            vm.loadMessage = translateTag(3871)
            vm.continueEditing = false
            vm.leaveEditing = false
            vm.idletime = 0
            vm.countdownSeconds = 60
            vm.autosave = null
            vm.autoSaveActive = false
            vm.ora_show_check_box = false
            vm.mod_id = 14   //module ora
            vm.currentAttachment = null

            vm.alara = [
                {
                  id: 1,
                  label: translateTag(1379)
                },
                {
                  id: 0,
                  label: translateTag(1380)
                }
            ]

            vm.requireBowtie = [
                {
                  id: 1,
                  label: translateTag(1379)
                },
                {
                  id: 0,
                  label: translateTag(1380)
                }
            ]

            //Get permissions for the user
            menuService.getPagePermissions().then((data) => {
                vm.permissions = data
                vm.canViewORA = vm.permissions.includes('Can View ORA') ? true : false
                vm.canManageORA = vm.permissions.includes('Can Manage ORA') ? true : false
                vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
                vm.canManageActionItems = vm.permissions.includes('Can Manage Action Items') ? true : false
                vm.canCloseAllActions = vm.permissions.includes('Can Close All Actions') ? true : false

            })

            $scope.$on('DATERANGE', (range) => {
                vm.mainDateFilter = {
                    start_date: moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD'),
                    end_date: moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')
                }
                refreshData()
            })

            //Function to clear the form feilds
            vm.resetForm = () => {
                resetFormFieldClassList('oraForm')
                vm.jobListSelect = []
                vm.attachmentData = []
                vm.tmpDeletedEventCategories = []
                vm.tmpDeletedEvents = []
                vm.saved = false
                vm.submitted = false
                vm.rmm_ora_doc_revision_no = null
                vm.updatingRecord = false
                vm.changesInForm = false
                vm.currentUserSigned = false
                vm.ora_bowties = []
                vm.dlo_id = null
                vm.docLockMessage = ''
                vm.docLockStatus = false
                vm.countdownSeconds = 60
                vm.lockCheckModal = false
                vm.continueEditing = false
                vm.idletime = 0
                vm.leaveEditing = false
                vm.ora_show_check_box = false
                
                vm.currentOra =
                {
                    rmm_ora_id: null,
                    rmm_ora_document_number: null,
                    rmm_ora_doc_version_number: null,
                    rmm_ora_title: null,
                    rmm_ora_scope: null,
                    rmm_ora_expiry_date: null,
                    rmm_ora_site: null,
                    rmm_ora_other_participants: null,
                    rmm_ora_state: null,
                    rmm_ora_date: dateToday.format("YYYY-MM-DD"),
                    rmm_ora_created_date: dateToday.format("YYYY-MM-DD"),
                    rmm_ora_created_by_per_id: null,
                    participants: [],
                    approvers: [],
                    rmm_ora_is_submitted: false,
                    rmm_ora_revision_no:null,
                    event_categories: [newEventCategory()],
                    approversList:[],
                    rmm_ora_executive_summary: null,
                    hazard_actions:[],
                    general_actions:[]
                }
            }

            // Function for a new event category object
            function newEventCategory() {
                return {
                    rmm_oec_category: null,
                    rmm_oec_id: null,
                    rmm_oec_sort: 1,
                    rmm_oec_enable: true,
                    events: [newEvent()]
                }
            }

            // Function for a Unwanted major event object
            function newEvent() {
                return {
                    rmm_oev_id: null,
                    rmm_oev_oec: null,
                    rmm_oev_enable: true,
                    rmm_oev_major_unwanted_event: null,
                    rmm_oev_likelyhood_preliminary: null,
                    rmm_oev_severity_preliminary: null,
                    rmm_oev_preliminary_risk: null,
                    rmm_oev_preliminary_risk_text: null,
                    rmm_oev_risk_alara_preliminary: null,
                    rmm_oev_require_bowtie: null,
                    rmm_oev_likelyhood_residual: null,
                    rmm_oev_severity_residual: null,
                    rmm_oev_residual_risk: null,
                    rmm_oev_residual_risk_text: null,
                    rmm_oev_risk: null,
                    rmm_oev_risk_alara_residual: null,
                    rmm_oev_outcome: null,
                    control_measures: [],
                    //control_measures: [],
                    additional_control_measures:[]
                }
            }

            // Function for a tag object
            function newTag() {
                return {
                    rmm_ota_id: null,
                    rmm_ota_oev: null,
                    tag: null,
                    rmm_ota_tag_name:null,    
                    rmm_ota_blueline: false,
                    rmm_ota_enable: true
                }
            }

            //Function to add a new event category
            vm.addEventCategory = function () {
                let eventCatagories = vm.currentOra.event_categories
                let newCat = newEventCategory()
                newCat.rmm_oec_sort = eventCatagories.length + 1
                vm.currentOra.event_categories.push(newCat)
                setTimeout(()=>{
                    vm.initializeTagsAndPulldowns()
                },100)
            }

            //Function to add a new unwanted event category
            vm.addEvent = function (ec_index) {
                vm.currentOra.event_categories[ec_index].events.push(newEvent())
                setTimeout(()=>{
                    vm.initializeTagsAndPulldowns()
                },100)
            }

            //Function to delete an event category
            vm.deleteEventCategory = function (rm_index) {
                let tmp_ec_obj = {}
                vm.currentOra.event_categories[rm_index].rmm_oec_enable = false
                tmp_ec_obj = vm.currentOra.event_categories.splice(rm_index,1)[0]
                vm.currentOra.event_categories.forEach((val, index) => {
                   val.rmm_oec_sort = index+1
                });
                vm.tmpDeletedEventCategories.push(tmp_ec_obj)
                if (vm.currentOra.event_categories.length === 0){
                    vm.addEventCategory()
                    return
                }
                vm.initializeSelect2('newOra')
            }

            //Function to delete an event
            vm.deleteEvent = function (rm_ev_index,rm_ec_index) {
                let tmp_ev_obj = {}
                vm.currentOra.event_categories[rm_ec_index].events[rm_ev_index].rmm_oev_enable = false
                tmp_ev_obj = vm.currentOra.event_categories[rm_ec_index].events.splice(rm_ev_index,1)[0]
                vm.tmpDeletedEvents.push(tmp_ev_obj)
                if (vm.currentOra.event_categories[rm_ec_index].events.length === 0){
                    vm.addEvent(rm_ec_index)
                    return
                }
                vm.initializeSelect2('newOra')
            }

            // Function to click risk matrix
            vm.onClickRiskMatrix = (ec_index,ev_index,severity,likelyhood,p_risk) =>{
                vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_severity_preliminary = getRefIDForRisk(severity,'severity')
                vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_likelyhood_preliminary = getRefIDForRisk(likelyhood,'likelyHood')
                vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_preliminary_risk = p_risk
                vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_risk = p_risk
                vm.initializeSelect2('newOra')
            }

            //Function to get Score for a given Ref ID
            function getRefIDForRisk (ref_name,type) {
                let ref_id = null
                switch(type){
                    case "likelyHood":
                        vm.likelyHoodList.forEach((val, index) => {
                            if (val.rld_name === ref_name){
                                ref_id = val.rld_id
                            }
                        })
                        break;
                    case "severity":
                        vm.severityList.forEach((val, index) => {
                            if (val.rld_name === ref_name){
                                ref_id = val.rld_id
                            }
                        })
                        break; 
                }
                return ref_id
            }

            // Function to Evaluate Preliminary Risk
            function evalRisk (severity,likelyhood) {
                let Extreme = ['31','41','51','42','52','53']
                let High = ['21','22','32','33','43','44','54','55']
                let Medium = ['11','12','23','34','45']
                let Low = ['13','14','15','24','25','35']
                let code = `${severity}${likelyhood}`
                let risk = null
                if (Extreme.find(o => o === code)){
                    risk = 3626
                }
                if (High.find(o => o === code)){
                    risk = 3622
                }
                if (Medium.find(o => o === code)){
                    risk = 3627
                }
                if (Low.find(o => o === code)){
                    risk = 3628
                }
                return risk
            }

            //Function to get Score for a given Ref ID
            function getScoreForRisk (ref_id,type) {
                let score = null
                switch(type){
                    case "likelyHood":
                        vm.likelyHoodList.forEach((val, index) => {
                            if (val.rld_id === ref_id){
                                score = val.rld_score
                            }
                        })
                        break;
                    case "severity":
                        vm.severityList.forEach((val, index) => {
                            if (val.rld_id === ref_id){
                                score = val.rld_score
                            }
                        })
                        break; 
                }
                return score
            }

            // Function to check Event Category Pull down
            vm.checkECPulldown = (ec_index, ec_id) =>{
                for (let i = 0; i < vm.currentOra.event_categories.length; i++) {
                    if (i !== ec_index){
                        if (vm.currentOra.event_categories[i].rmm_oec_category === ec_id){
                            vm.currentOra.event_categories[ec_index].rmm_oec_category = null
                            throwToastr('error',translateTag(8348), 2000)
                        } 
                    }
                }
            }

            // Function to Evaluate Preliminary Risk
            vm.evalPrelimRisk = (ev_index, ec_index) => {
                let severity = parseInt(getScoreForRisk(vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_severity_preliminary,'severity'))
                let likelyhood = parseInt(getScoreForRisk(vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_likelyhood_preliminary,'likelyHood'))
                if (vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_risk_alara_preliminary !== 0){
                    vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_risk = evalRisk(severity,likelyhood)
                }
                vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_preliminary_risk = evalRisk(severity,likelyhood)
                vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_preliminary_risk_text = translateTag(evalRisk(severity,likelyhood))
            }

            // Function to Evaluate Residual Risk
            vm.evalResidualRisk = (ev_index, ec_index) => {
                let severity= parseInt(getScoreForRisk(vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_severity_residual,'severity'))
                let likelyhood = parseInt(getScoreForRisk(vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_likelyhood_residual,'likelyHood'))
                vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_risk = evalRisk(severity,likelyhood)
                vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_residual_risk = evalRisk(severity,likelyhood)
                vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_residual_risk_text = translateTag(vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_residual_risk)
            }

            // Function to change ALARA
            vm.changeALARA = (ev_index, ec_index) => {
                if (vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_risk_alara_preliminary === 0){
                    vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_risk = null
                    setTimeout(()=>{
                        vm.initializeTagsAndPulldowns()
                    },100)
                }else{
                    vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_severity_residual = null
                    vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_likelyhood_residual = null
                    vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_risk = vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_preliminary_risk
                    vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_residual_risk = null
                    vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_residual_risk_text = null
                    vm.currentOra.event_categories[ec_index].events[ev_index].rmm_oev_risk_alara_residual = null
                    vm.currentOra.event_categories[ec_index].events[ev_index].additional_control_measures=[]
                }
            }

            $scope.fileUploadChanged = (event)=> {

                //Add newly selected files after checking for duplicates and correct file types
                vm.uploadFileList = vm.uploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, []))

                if(vm.uploadFileList.length > 0)
                    addAttachments()
            }

            //Function for the top search bar
            vm.topSearchChanged = () =>{
                vm.oraOptions.api.setQuickFilter(vm.topSearch)
            }

            //Function to open archive confirmation Modal
            vm.archiveConfirmationModal = () => {
                let archiveSelectedRecords = vm.oraOptions.api.getSelectedRows()
                vm.archiveCount = archiveSelectedRecords.length
                if (vm.archiveCount > 0) {
                    if(!vm.canArchiveSubmissions){
                        for (var i = 0; i < vm.archiveCount; i++) {
                            if(archiveSelectedRecords[i].rmm_ora_state!=="draft" || archiveSelectedRecords[i].rmm_ora_created_by_per_id!==vm.userId){
                                throwToastr('error',translateTag(1456),3000)
                                return
                            }
                        }
                    }

                }
                vm.modalElementsArchive = {
                    title: translateTag(3659), //"Archive ORA?"
                    message: `<div><p>${translateTag(3716)}</p></div>`, //"You are about to archive this assessment. Undoing this will require IT support. Are you sure?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                } 
                document.getElementById('confirmcallingform').innerHTML = 'ORAARCHIVECALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsArchive)
            }     
            
            $scope.$on("ORAARCHIVECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.oraArchive()
                }
                else if (result=='button2') {
                    vm.cancelModal('confirmModal')
                }
            })

            //Function to archive the selected rows
            vm.oraArchive = () => {
                var rows = vm.oraOptions.api.getSelectedRows()
                if (rows.length > 0) {
                    var ids = []
                    for (var i = 0; i < rows.length; i++) {
                        if (rows[i].dlo_status === 'Yes') {
                            ids.push(rows[i].rmm_ora_id)
                        }
                        else{
                            // You cannot Archive while Document is being edited
                            throwToastr('warning',translateTag(9116),2000)
                        }
                    }

                    oraService.archiveOra(ids).then((r) => {
                        refreshData()
                    })
                }

                modalService.Close('confirmModal')
            }

            // function to reset toastr options
            function resetToastrOptions() {
                toastr.options.progressBar = false,
                toastr.options.positionClass = 'toast-top-right'
                toastr.options.timeOut= "5000"
            }

            //function to throw toastr with time interval
            function throwToastr(type,message,time){
                toastr.options.timeOut = time
                toastr.options.positionClass = 'rmm-toast-custom'
                switch (type) {
                    case 'success':
                        toastr.success(message)
                        break;
                    case 'warning':
                        toastr.warning(message)
                        break;
                    case 'error':
                        toastr.error(message)
                        break;
                    case 'info':
                        toastr.info(message)
                        break;
                }
                resetToastrOptions()
            }

            //Function to open archive confirmation Modal
            vm.copyRevisionConfirmationModal= (mode='') => {
                vm.performActionMode = mode
                var rows = vm.oraOptions.api.getSelectedRows()
                vm.selectedRecordCount = rows.length
                
                
                if (vm.selectedRecordCount === 0){
                    throwToastr('warning',translateTag(3861),2500)
                    return
                }
                if (vm.selectedRecordCount > 1) {
                    throwToastr('warning',translateTag(3863),2500)
                    return
                }
                if (rows[0].rmm_ora_state === 'draft' && vm.performActionMode==='revision'){
                    throwToastr('error',translateTag(3865),3000)
                    return
                }

                if (vm.selectedRecordCount === 1){     
                    vm.selectedDocumentNo = ''  
                    let dispTitle = ''
                    if(rows[0].rmm_ora_title){
                        dispTitle = ' - ' + rows[0].rmm_ora_title
                    }
                                 
                    if(rows[0].rmm_ora_revision_no !== ''){
                        vm.selectedDocumentNo = rows[0].rmm_ora_revision_no + dispTitle
                    }
                }


                let duplicateFlag = false
                if ((rows[0].rmm_ora_state === 'active' || rows[0].rmm_ora_state === 'expired') && vm.performActionMode==='revision'){
                    vm.oraAGData.forEach((val)=>{
                        if (duplicateFlag)
                            return
                        if (val.rmm_ora_document_number === rows[0].rmm_ora_document_number){
                            if (val.rmm_ora_state === 'review' || val.rmm_ora_state === 'draft'){
                                vm.version_number = `${appendLeadingZeros(val.rmm_ora_document_number)}`+'.'+`${appendLeadingZeros(val.rmm_ora_doc_version_number,3)}`
                                vm.message = translateTag(4316)+" "+val.rmm_ora_state+" "+translateTag(3866)+" ("+ vm.version_number+"). "+translateTag(3867)+" "+val.rmm_ora_state+" "+translateTag(3868)
                                throwToastr('error', vm.message, 2500)
                                duplicateFlag = true
                            }
                        }
                    })
                }
                if (!duplicateFlag){
                    vm.modalElementsCopy = {
                        title: capitalizeFirstLetter(vm.performActionMode), //
                        message: 
                        `<div>
                            <p ng-if=${vm.performActionMode==='copy'} note="You are about to make a copy of this Organizational Risk Assessment. Are you sure?">${translateTag(9535)} ${vm.selectedDocumentNo}. ${translateTag(2257)}</p>
                            <p ng-if=${vm.performActionMode==='revision'} note="You are about to make a revision of this Organizational Risk Assessment. Are you sure?">${translateTag(9538)} ${vm.selectedDocumentNo}. ${translateTag(2257)}</p>
                        </div>`,
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                    } 
                    document.getElementById('confirmcallingform').innerHTML = 'ORACOPYCALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsCopy)
                }  
            }

            $scope.$on("ORACOPYCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.oraCopyRevision()
                }
                else if (result=='button2') {
                    vm.cancelModal('confirmModal')
                }
            })

            //Function to copy or revision the selected rows
            vm.oraCopyRevision = () => {
                var rows = vm.oraOptions.api.getSelectedRows()
                if (rows.length > 0) {              
                    let payload = {}
                    payload.rmm_ora_id =  rows[0].rmm_ora_id
                    payload.mode = vm.performActionMode

                    oraService.copyRevisionOra(payload).then((r) => {
                        refreshData()
                    })
                }

                modalService.Close('confirmModal')
            }

            //Funtion to export the selected rows to CSV file
            vm.exportCSV = () => {                
                let rows = JSON.parse(JSON.stringify(vm.oraOptions.api.getSelectedRows()))
                exportCSV.export_csv(rows, translateTag(2103))
            }

            //Funtion to open a report in a new tab
            vm.viewReports = (e, id, doc="ORA") =>{
                if(!e.ctrlKey) {
                    if(doc==="ORA"){
                        lang_number = localStorage.getItem('lang_id')
                        vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.singleServeReportUrl}/${id}?lang=${lang_number}`)
                    }
                    else if (doc==="BOWTIE"){
                        lang_number = localStorage.getItem('lang_id')
                        vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.bowtieReportUrl}/${id}?lang=${lang_number}`)
                    }
                    $window.open(vm.reportURL, "_blank")
                }
            }        

            //#region Funtions to convert ID to Name
            vm.getEmployeeName = (value) => {
                let name=value
                vm.fullEmployeeList.forEach((emp)=>{
                    if(emp.per_id == value) {
                        name = emp.per_full_name
                    }
                })
                return name
              }

            function getEmployeeID(value) {
                let nameID = value
                vm.fullEmployeeList.forEach((emp)=>{
                    if(emp.per_full_name == value) {
                        nameID = emp.per_id
                    }
                })
                return nameID
            }

            function getActionTypeName(value) {
                let name = value
                vm.actionTypeList.forEach((at)=>{
                    if(at.rld_id == value) {
                    name = at.rld_name
                    }
                })
                return name
            }

            function getHapActionTypeName(value) {
                let name = value
                vm.hapActionTypeList.forEach((at)=>{
                    if(at.rld_id == value) {
                    name = at.rld_name
                    }
                })
                return name
            }

            function getActionTypeID(value) {
                let nameID = value
                vm.actionTypeList.forEach((at)=>{
                    if(at.rld_name == value) {
                        nameID = at.rld_id
                    }
                })
                return nameID
            }

            function getSiteName(value) {
                let name = value
                vm.site_name.forEach((s)=>{
                    if(s.rld_id == value) {
                        name = s.rld_name
                    }
                })
                return name
            }

            function getJobNumber(value) {
                let name = value
                vm.jobList.forEach((j)=>{
                    if(j.rld_id == value) {
                        name = j.rld_code
                    }
                })
                return name
            }
            //#endregion
           
            vm.oraOptions = gridService.getCommonOptions()
            vm.attachmentOptions = gridService.getCommonOptions()

            //Function to disable action button if no rows are selected
            vm.oraOptions.onSelectionChanged = () => {
                var selectedRows = vm.oraOptions.api.getSelectedRows()
                vm.actionDisabled = selectedRows.length == 0
                $scope.$apply()
            }
            vm.attachmentOptions.onSelectionChanged = () => {
                var selectedRows = vm.attachmentOptions.api.getSelectedRows()
                vm.attActionDisabled = selectedRows.length == 0
                $scope.$apply()
            }

            //Set Ag-Grid colum values/settings
            let oraColumns = [
                {
                    headerName: '',
                    field: 'dummyCheckbox',
                    maxWidth: 50,
                    minWidth: 50,
                    checkboxSelection: true,
                    suppressMenu: true,
                    suppressSorting: true,
                    headerCheckboxSelection: true,
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    field: "review",
                    headerName: " ",
                    minWidth: 125,
                    maxWidth: 125,
                    suppressMenu: true,
                    cellRenderer: (params) => {
                    return `<span ng-show="${params.data.rmm_ora_is_submitted === translateTag(1379)}" ng-click="oraCtrl.signoff(data)" class="{{ data.hasReviewed === '${translateTag(1379)}'? 'text-success ' : 'pointer'}}" note="Review Submission" title={{menu.translateLabels(3431)}}><i class="far fa-file-alt fa-lg pr-2""></i></span>`
                        + `<span class="fa-1x fa-stack" style=" width: 1.25em;" ng-class="{ transparent: ${!vm.canManageORA}, pointer: ${vm.canManageORA}}"  ng-show="'${params.data.rmm_ora_state}'==='draft'" ng-click="oraCtrl.openViewer('edit', ${params.data.rmm_ora_id})"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title={{menu.translateLabels(1194)}}></i> <i ng-show="${params.data.dlo_status === translateTag(1380)}" class="fas fa-ban fa-stack-1x text-danger" notes="Person is updating the document, please wait." title="${params.data.dlo_person} {{menu.translateLabels(3423)}}"></i></span>`                        
                        + `<span ng-class="{ transparent: ${!vm.canManageORA}, pointer: ${vm.canManageORA}}"  ng-show="'${params.data.rmm_ora_state}'==='review'" ng-click="oraCtrl.openViewer('view', ${params.data.rmm_ora_id})"><i class="fas fa-lock pr-2 text-primary" note="Review" title={{menu.translateLabels(1188)}}></i></span>`                        
                        + `<span note="Review History" title={{menu.translateLabels(3951)}} class="source signoff-count" ng-class="{ transparent: (!data.reviewedCount > 0 || data.rmm_ora_is_submitted === '{{menu.translateLabels(1380)}}'), pointer: (data.reviewedCount > 0 && data.rmm_ora_is_submitted === '{{menu.translateLabels(1379)}}') }" ng-click="oraCtrl.viewAcknowledgeHistory(data);">{{ data.reviewedCount }}</span>`
                        + `<span class="pointer text-left" ng-click="oraCtrl.viewReports($event, ${params.data.rmm_ora_id})"><i class="fa fa-external-link-alt" note="Launch Report" title={{menu.translateLabels(3429)}}></i></span>`
                    },
                    valueGetter: function (params) {
                        return params.data.reviewedCount
                    },
                },
                {
                    field: '',
                    hide: true,
                    valueGetter: function (params) {
                        if (params.data.rmm_ora_state === 'draft')
                            return '1_Draft'
                        if (params.data.rmm_ora_state === 'review')
                            return '2_Review'
                        if (params.data.rmm_ora_state === 'active')
                            return '3_Active'
                        if (params.data.rmm_ora_state === 'expired')
                            return '4_Expired'
                    },
                    sort: 'asc',
                },
                {
                    field: "rmm_ora_created_date",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 140,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    sort: 'desc'
                },
                {
                    field: "rmm_ora_created_by_per",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 220,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_ora_expiry_date",
                    headerName: " ",
                    minWidth: 120,
                    maxWidth: 140,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        let expiryDate = new Date(params.data.rmm_ora_expiry_date)
                        let currentDate = new Date()
                        if (expiryDate < currentDate)
                            return '<div style="color: #D20000;">' + params.data.rmm_ora_expiry_date + '</div>'
                        else
                            return '<div>' + params.data.rmm_ora_expiry_date + '</div>'
                      }
                },
                {
                    field: "rmm_ora_title",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 1000,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_ora_site",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_ora_revision_no",
                    headerName: " ",
                    minWidth: 120,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rmm_ora_state",
                    headerName: " ",
                    maxWidth: 120,
                    minWidth: 120,
                    suppressMenu: false,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    valueGetter: function (params) {
                        return translateStatus(params.data.rmm_ora_state)                        
                    },
                },              
                {field:"hasReviewed", hide:true},
                {field:"participantsList", hide:true},
                {field:"reviewersList", hide:true},
                {field:"reviewedCount", hide:true},
                {field:"rmm_ora_is_submitted", hide:true},
                {field:"rmm_ora_executive_summary", hide:true},
                {field:"rmm_ora_other_participants", hide:true},
                {field:"approversList", hide:true},
                {field:"rmm_ora_revision_no", hide:true},
                {field:"rmm_ora_doc_version_number", hide:true},
                {field:"rmm_ora_document_number", hide:true},
                {field:"rmm_ora_id", hide:true},
                {field:"rmm_ora_date", hide:true},
                {field:"rmm_ora_scope", hide:true},
            ]
            vm.oraOptions.columnDefs = oraColumns
            vm.oraOptions.defaultColDef = {
                cellStyle : (params) =>{
                    if(params.data.rmm_ora_state === 'active' || params.data.rmm_ora_state === 'expired' || params.data.rmm_ora_state === 'review'){
                        return { "cursor": "pointer !important"}
                    }
                } 
            }

            vm.oraOptions.onCellClicked  = (params) => {
                if(params.column.colDef.field !== 'review' && (params.data.rmm_ora_state === 'active' || params.data.rmm_ora_state === 'expired' || params.data.rmm_ora_state === 'review')){
                    vm.openViewer('view', params.data.rmm_ora_id)
                }
            }

            vm.viewOnlyCheck = () => {
                // For autosave so that the fields do not react to this function
                if(!vm.autoSaveActive) {
                    if(vm.currentOra.rmm_ora_state === 'active' || vm.currentOra.rmm_ora_state === 'expired' || vm.currentOra.rmm_ora_state === 'review' || vm.updatingRecord)
                        return true
                    return false
                }
            }

            vm.signoff = (oraData) => {
                vm.oraDataContext = oraData
                if(oraData.hasReviewed=== translateTag(1379)) {
                    throwToastr('success', translateTag(3869), 2000)
                }
                else {
                    vm.modalElementsReview = {
                        title: translateTag(3714), //"Org. Risk Assessment Review?"
                        message: `<div><p>${translateTag(3634)}</p></div>`, //"You are confirming that you have reviewed this assessment. This cannot be undone. Continue?"
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Review">{{vm.componentTranslateLabels(1188)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                    } 
                    document.getElementById('confirmcallingform').innerHTML = 'ORAREVIEWCALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsReview)
                 }
            }

            $scope.$on("ORAREVIEWCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.addAcknowledge()
                }
                else if (result=='button2') {
                    vm.cancelModal('confirmModal')
                }
            })

            let attachmentColumns = [
                {
                    headerName: '',
                    field: 'dummyCheckbox',
                    maxWidth: 50,
                    minWidth: 50,
                    checkboxSelection: (params) =>{
                        return params.data.rat_ora_show_check_box
                    }, 
                    suppressMenu: true,
                    suppressSorting: true,
                    headerCheckboxSelection: true,
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    //Added the id to the Ag-Grid and hid it. Used to sort the grid to show newest submissions first
                    field: 'rat_id',
                    hide: true,
                    sort: 'desc',
                },
                {
                    field: "rat_created_by_per",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',                    
                },
                {
                    field: "rat_created_date",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "rat_file_name",
                    headerName: " ",
                    minWidth: 150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        return `<span class="pointer clip" ng-click='oraCtrl.openAttachment(${cleanDoubleCurly(JSON.stringify(params.value))})'><a class="source" href="#" ng-non-bindable>${params.value}</a></span>`
                    }              
                },   
                {
                    field:"comment",
                    headerName:"Comment",
                    minWidth:150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        if(params.data.com_id == null || params.data.com_comment=='' || params.data.com_comment==null){
                            return `<i class="far fa-comment pointer" note="Add Comment" title="{{menu.translateLabels(8921)}}" ng-click='oraCtrl.AddComments(${cleanDoubleCurly(JSON.stringify(params.data))})'></i>`
                        } else {
                            return `<i class="fa fa-comment pointer" note="Edit Comment" title="{{menu.translateLabels(9043)}}" ng-click='oraCtrl.AddComments(${cleanDoubleCurly(JSON.stringify(params.data))})'></i>`
                        }
                        
                    } 
                }      
            ]
            vm.attachmentOptions.columnDefs = attachmentColumns
            
            //Funtion to open a attachment file in a new tab
            vm.openAttachment = (name) => {
                vm.attachmentURL =  $sce.trustAsResourceUrl(`${__env.imageUrl}/${name}`)
                $window.open(vm.attachmentURL, "_blank")
            }

            vm.AddComments=(data) =>{
                document.getElementById('mode').innerText = data.com_id
                document.getElementById('comment').value = data.com_comment ? data.com_comment.replaceAll("'","&#39") : null 
                document.getElementById('callingform').innerHTML= 'ORACALLIMAGECOMMENTSMODAL'
                document.getElementById('savetomemory').innerHTML = "false"
                document.getElementById('parentform').innerHTML = vm.mod_id
                document.getElementById('imageid').innerText = data.rat_id  
                document.getElementById('viewOnly').innerText = vm.viewOnlyCheck()
                vm.currentAttachment=data.rat_id 
                document.getElementById('comment_id').innerHTML = data.com_id 
                $rootScope.$broadcast("RECIEVEROFCOMMENTS", data.com_comment ) 
            }
            

            $scope.$on('ORACALLIMAGECOMMENTSMODAL', (event, data) => {
                vm.refreshAttachmentsRowData(data)
            })

            vm.refreshAttachmentsRowData = (data) => {
                let rowData = []
                vm.attachmentOptions.api.forEachNode((node) => rowData.push(node.data))
                rowData.forEach((node) => {
                    if (node.rat_id == vm.currentAttachment) {
                        node.com_comment=data.com_comment
                        node.com_id=data.com_id
                    }
                }) 
                vm.attachmentOptions.api.setRowData(rowData)
            }

            //Function to refresh/get attachment data
            function refreshAttachments (id) {
                if(id)
                {
                    payload = {
                        rmm_id: id,
                        mod_id: vm.mod_id
                    }
                    rmmAttachmentsService.getRmmAttachments(payload).then((response) => {
                        vm.attachmentData = response
                    
                        if (vm.attachmentOptions.api) {
                            translateAgGridHeader (vm.attachmentOptions)
                            vm.attachmentOptions.paginationPageSize = 15
                            vm.attachmentOptions.api.setRowData(prepareAttachmentsGridData(vm.attachmentData))
                            vm.attachmentOptions.api.redrawRows()
                            vm.attachmentOptions.api.sizeColumnsToFit()
                        }
                    })
                }
                else if (vm.attachmentOptions.api) {
                    translateAgGridHeader (vm.attachmentOptions)
                    vm.attachmentOptions.paginationPageSize = 15
                    vm.attachmentOptions.api.setRowData([])
                    vm.attachmentOptions.api.redrawRows()
                    vm.attachmentOptions.api.sizeColumnsToFit()
                }
            }

            function prepareAttachmentsGridData(data) {
                let gridData = JSON.parse(JSON.stringify(data))
                gridData.forEach((rec) =>{
                    rec.exceptionFields = ['rat_enable','rat_rmm_id','rat_mod_id','com_id','rat_id','rat_ora_show_check_box']
                    rec.com_comment = rec.com_comment ? rec.com_comment.replaceAll("'","&#39") : null
                    rec.rat_created_by_per = vm.getEmployeeName(rec.rat_created_by_per)
                    rec.rat_modified_by_per = vm.getEmployeeName(rec.rat_modified_by_per)
                    rec.rat_created_date = moment(rec.rat_created_date).format('YYYY-MM-DD')
                    rec.rat_modified_date = rec.rat_modified_date? moment(rec.rat_modified_date).format('YYYY-MM-DD') : '' 
                    rec.rat_ora_show_check_box = vm.ora_show_check_box
                })
                return gridData
            }

            //Function to add attachments
            function addAttachments (att)            
            {
                if(vm.currentMode === "new") {
                    if (validateFormFields('oraForm', true)) {
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentOra)))
                        payload.rmm_ora_is_submitted = false

                        oraService.createOra(payload).then((response) => {
                            vm.currentOra.rmm_ora_id = response.rmm_ora_id
                            vm.openViewer('edit', vm.currentOra.rmm_ora_id)
                            resetFormFieldClassList('oraForm')
                            let fd = new FormData()
                            for (let i in vm.uploadFileList) {
                                fd.append("rmm_id", vm.currentOra.rmm_ora_id)
                                fd.append("mod_id", vm.mod_id)
                                fd.append("rmm_files", vm.uploadFileList[i])
                            }
                            rmmAttachmentsService.addRmmAttachments(fd).then((res) => {
                                refreshAttachments(vm.currentOra.rmm_ora_id)
                                vm.uploadFileList = []
                            })
                            refreshData()
                            vm.ora_show_check_box = true
                            toastr.success(translateTag(4278)) //Saved Successfully                             
                        })
                    }
                    else{
                        $rootScope.$broadcast("CALLCONFIRMMODAL")
                    }
                }
                else {
                    let fd = new FormData()
                    for (let i in vm.uploadFileList) {
                        fd.append("rmm_id", vm.currentOra.rmm_ora_id)
                        fd.append("mod_id", vm.mod_id)
                        fd.append("rmm_files", vm.uploadFileList[i])
                    }
                    rmmAttachmentsService.addRmmAttachments(fd).then((res) => {
                        refreshAttachments(vm.currentOra.rmm_ora_id)
                        vm.uploadFileList = []
                    })
                }                
            }

            //Function to open delete confirmation Modal
            vm.deleteAttachmentConfirmationModal = () => {
                vm.deleteAttCount = vm.attachmentOptions.api.getSelectedRows().length
                vm.modalElementsDelete = {
                    title: translateTag(3416), //"Delete Attachment?"
                    message: `<div><p>${translateTag(3581)} ${vm.deleteAttCount} ${translateTag(3417)}</p></div>`, //"You are about to delete {{oraCtrl.deleteAttCount}} attachments. Undoing this will require IT support. Are you sure?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Yes">{{vm.componentTranslateLabels(1379)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                }
                document.getElementById('confirmcallingform').innerHTML = 'ORADELETEATTACHCALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsDelete)
            }

            $scope.$on("ORADELETEATTACHCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.deleteAttachment()
                }
            })

            //Function to delete the selected attachment rows
            vm.deleteAttachment = () => {
                var rows = vm.attachmentOptions.api.getSelectedRows()
                if (rows.length > 0) {
                var ids = []
                for (var i = 0; i < rows.length; i++) {
                    ids.push(rows[i].rat_id)
                }
                payload={rat_id: ids, mod_id: vm.mod_id}
                rmmAttachmentsService.removeRmmAttachments(payload).then((r) => {
                    refreshAttachments(vm.currentOra.rmm_ora_id)
                })
                }    
                modalService.Close('confirmModal')
            }

            //Function to add/remove an acknowledgment to an assessment via the Ag-Grid
            vm.addAcknowledge = () => {
                let payload = {}
                payload.rmm_ora_id = vm.oraDataContext.rmm_ora_id
                vm.currentAcknowledge = vm.oraDataContext
                    oraService.reviewOra(payload).then (() => {
                        refreshData()
                        modalService.Close('confirmModal')
                    })
            }

            //Function to open the Acknowledge History modal
            vm.viewAcknowledgeHistory = (oraData) => {
                if(!oraData.reviewedCount > 0 || !oraData.rmm_ora_is_submitted)
                    return

                vm.currentAcknowledgeHistory = []
                oraData.reviewers.forEach((rev) => {
                    let acknowledgment = {
                        name: vm.getEmployeeName(rev.rmm_ore_per_id),
                        pos: rev.rmm_ore_position_name,
                        reviewed_date: rev.rmm_ore_created_date
                    }
                    vm.currentAcknowledgeHistory.push(acknowledgment)
                })
                $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentAcknowledgeHistory,translateLabels(1297)) //"Reviews"
            }

            //Function to check if the current user has Acknowledged this assessment
            function checkAcknowledged (OraData) {
                let response = false
                OraData.reviewers.forEach((rev) => {
                    if(rev.rmm_ore_per_id == vm.userId){
                        response = true
                    }
                })
                return response
            }

            //Fuction used to close modals
            vm.cancelModal = (modalId) => {
                modalService.Close(modalId)
                vm.initializeSelect2('newOra')
            }

            //Function to open the viewer
            vm.openViewer = (mode='new', id) => {
                // Activate the Autosave
                if(mode !== 'view') {
                    vm.autosave = $interval(() => {
                        vm.saveOra('autosave')
                      }, 60000)
                }

                if(!vm.canManageORA)
                    return
                if(mode === 'new') {
                    vm.currentMode = 'new'
                    vm.initializeTagsAndPulldowns()
                    destroyTables().then(()=>{
                        initiateTables()
                    })
                    vm.userInApprovers = true
                    vm.hideingOraViewer = false
                    vm.oraViewerOpen = true
                    vm.openingOraViewer = true
                    $timeout(() => {
                        vm.openingOraViewer = false
                        $('#newOra').data('serialize',$('#newOra').serialize())
                    }, 400)
                    refreshAttachments()
                }
                else if (mode === 'edit') {
                    vm.documentDetails = {}
                    vm.documentDetails.dlo_document_id = id
                    vm.documentDetails.dlo_dlt_id = 1 //ORA
                    $q.all([
                        documentLockService.docLock(vm.documentDetails)
                    ]).then((response) => {
                        vm.dlo_id = response[0].dlo_id
                        vm.docLockStatus = response[0].status
                        vm.docLockMessage = response[0].message
                        vm.docLockTime = response[0].time
                        if (!vm.docLockStatus){
                            throwToastr('warning',vm.docLockMessage,2000)
                        }   
                    }).then(() => {
                            if(vm.docLockStatus === true){
                                $scope.$emit('STARTSPINNER', translateTag(3878))
                                vm.currentMode = 'edit'
                                vm.saved = true
                                toastr.options.progressBar = true
                                vm.documentDetails = {}
                                vm.documentDetails.dlo_document_id = id
                                vm.documentDetails.dlo_dlt_id = 2
                                vm.getSingleDetailRec(id).then(() => {
                                    vm.initializeTagsAndPulldowns()
                                    vm.validateCurrentUserInApprovers()
                                    vm.hideingOraViewer = false
                                    vm.oraViewerOpen = true
                                    vm.openingOraViewer = true
                                    if(!vm.currentOra.rmm_ora_is_submitted){
                                        vm.ora_show_check_box = true
                                    }
                                    refreshAttachments(vm.currentOra.rmm_ora_id)
                                    $timeout(() => {
                                        vm.openingOraViewer = false
                                        $('#newOra').data('serialize',$('#newOra').serialize())
                                        $scope.$emit('STOPSPINNER')
                                    }, 400)
                                })
                                startUpdateDocLock() // Interval function to update to timestamp every 2 minutes
                                startLockModal() // Interval function after inactive page
                            }
                        }
                    )                                  
                }
                else if(mode === 'view') {
                    vm.changesInForm = false
                    $scope.$emit('STARTSPINNER', translateTag(3878))
                    vm.getSingleDetailRec(id).then(() => {
                        vm.initializeTagsAndPulldowns()
                        vm.validateCurrentUserInApprovers()
                        vm.hideingOraViewer = false
                        vm.oraViewerOpen = true
                        vm.openingOraViewer = true
                        refreshAttachments(vm.currentOra.rmm_ora_id)
                        $timeout(() => {
                            $('#newOra').data('serialize',$('#newOra').serialize())
                            $scope.$emit('STOPSPINNER')
                        }, 400)
                    })
                }
            }

            // functions for document lock start__

            //Zero the idle timer on mouse movement.
            $('#newOra').mousemove(function (e) {
                clearInterval(vm.lockModal)                
                vm.idletime = 0
                startLockModal()
            });

            //Zero the idle timer on keypres event
            $('#newOra').keypress(function (e) {
                clearInterval(vm.lockModal)
                vm.idletime = 0
                startLockModal()
            });

            vm.continueEditingOra = () => {
                vm.cancelModal('confirmModal')
                vm.countdownSeconds = 60
                vm.lockCheckModal = false
                vm.continueEditing = true
                document.getElementById('inactiveTime').textContent = ''
                clearInterval(vm.lockModal)
                clearTimeout(vm.relieveLock)
                clearInterval(vm.countdownTimer)
                vm.idletime = 0
                startLockModal()

            }
           
            function startUpdateDocLock(){
                vm.updateDocLockInterval = setInterval(() => {
                    $q.all([
                        documentLockService.intervalDocLock(vm.dlo_id)
                    ])
                }, 30 * 1000)
            }

            function startLockModal(){
                vm.lockModal = setInterval(() => {
                    vm.idletime = vm.idletime + 1 // 1 minute
                    if(vm.idletime === 5){ // after 5 minutes of idle time open lockcheck modal
                        vm.continueEditing = false
                        vm.leaveEditing = false
                        vm.modalElementsLock = {
                            title: translateTag(3419),   //"Page inactive for 5 minutes" 
                            message: `<div style="text-align: center;"><h1 id ="inactiveTime" ></h1><p> ${translateTag(3420)}</p></div>`,  //"The entry will automatically save and close if no action is taken"
                            buttons: 
                                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Continue Working">{{vm.componentTranslateLabels(3421)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Save and Close">{{vm.componentTranslateLabels(3422)}}</button>`
                        }
                        document.getElementById('confirmcallingform').innerHTML = 'ORALOCKCALLCONFIRMMODAL' 
                        $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsLock)
                        vm.lockCheckModal = true
                        startcountdownTimer()
                        vm.relieveLock = setTimeout(() => {
                            if (vm.lockCheckModal === true){
                                if (!vm.continueEditing && !vm.leaveEditing){
                                    vm.leaveEditing = true
                                    vm.saveAndCloseOra()
                                }
                            }
                        }, 60 * 1000);
                    }                                        
                }, 60 * 1000);
            }

            $scope.$on("ORALOCKCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.continueEditingOra()
                }
                else if (result=='button2') {
                    vm.saveAndCloseOra()
                }
            })

            function startcountdownTimer(){
                vm.countdownTimer = setInterval(() => {
                    if(vm.lockCheckModal === true && vm.countdownSeconds>=0){
                        vm.content = ''
                        if (vm.countdownSeconds === 60){
                            vm.content = "01:00"
                        }
                        else{
                            vm.content = "00:" + vm.countdownSeconds.toLocaleString('en-US', {
                                minimumIntegerDigits: 2,
                                useGrouping: false
                              }) 
                        }
                        document.getElementById('inactiveTime').textContent =  vm.content
                        vm.countdownSeconds = vm.countdownSeconds - 1   
                    }                                        
                }, 1000)
            }

            // functions for document lock end___ 

            // An abstrect function to initialize the dropdowns and tags
            vm.initializeTagsAndPulldowns = () =>{
                vm.initializeSelect2('newOra')
                vm.initializeTags() 
            }

            // function to get single detail record
            vm.getSingleDetailRec = (id) =>{
                vm.tmpDeletedEventCategories = []
                vm.tmpDeletedEvents = []
                return (
                    $q.all([
                        oraService.getOraSIngleDetailRec(id).then((response) => {
                            vm.currentOra = JSON.parse(JSON.stringify(response))
                            vm.prepResponseSingleDetail()
                        }),
                        oraService.oraBowtie(id).then((response) => {
                            vm.ora_bowties = JSON.parse(JSON.stringify(response))
                        })
                    ])
                )
            }

            vm.siteChange = () => {
                if(vm.currentOra.rmm_ora_site===null || vm.currentOra.rmm_ora_site===undefined){
                    vm.currentOra.rmm_ora_site = null
                }
                vm.getFilteredEmployees()
            }

            vm.getFilteredEmployees = () => {
                profileService.filterEmployeeListonSite(vm.currentOra.rmm_ora_site)
                vm.employeeList =  profileService.readFilterEmployeeListonJob() 
                profileService.filterRmmApproverEmployeesOnSite(vm.currentOra.rmm_ora_site)
                vm.rmmApproversEmployee = profileService.readFilterApproversList() 
            }

            // An abstrect function to prepare response payload for single detail record
            vm.prepResponseSingleDetail = () => {     
                vm.currentOra.approversList = []
                angular.copy(vm.currentOra.approvers,vm.currentOra.approversList)
                vm.currentOra.approvers = getApprovers(vm.currentOra.approvers)
                vm.currentOra.rmm_ora_created_date = moment(vm.currentOra.rmm_ora_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                vm.currentOra.rmm_ora_date = vm.currentOra.rmm_ora_date===null?null:moment(vm.currentOra.rmm_ora_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                vm.currentOra.rmm_ora_expiry_date = vm.currentOra.rmm_ora_expiry_date===null?null:moment(vm.currentOra.rmm_ora_expiry_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                if(vm.currentOra.rmm_ora_site){
                    vm.getFilteredEmployees()
                }
                vm.currentOra.event_categories.forEach((ec)=>{
                    ec.events.forEach((ev)=>{
                        ev.rmm_oev_residual_risk_text = translateTag(ev.rmm_oev_residual_risk)
                        ev.rmm_oev_preliminary_risk_text = translateTag(ev.rmm_oev_preliminary_risk)

                        if (ev.rmm_oev_risk_alara_preliminary!==null) {
                            ev.rmm_oev_risk_alara_preliminary = ev.rmm_oev_risk_alara_preliminary === true ? 1 : 0
                        }
                        if (ev.rmm_oev_risk_alara_residual!==null) {
                            ev.rmm_oev_risk_alara_residual = ev.rmm_oev_risk_alara_residual === true ? 1 : 0
                        }
                        if (ev.rmm_oev_require_bowtie!==null){
                            ev.rmm_oev_require_bowtie=ev.rmm_oev_require_bowtie === true ? 1 : 0
                        }
                        ev.rmm_oev_risk = ev.rmm_oev_risk_alara_preliminary === 0 ? ev.rmm_oev_residual_risk : ev.rmm_oev_preliminary_risk
                    })
                })
                vm.rmm_ora_doc_revision_no = `${appendLeadingZeros(vm.currentOra.rmm_ora_document_number)}`+'.'+`${appendLeadingZeros(vm.currentOra.rmm_ora_doc_version_number,3)}`
                vm.uneditedCurrentOra = []
                angular.copy(vm.currentOra, vm.uneditedCurrentOra);
                vm.savedCurrentOra = Object.assign({},vm.currentOra)
                vm.refreshActions(vm.currentOra.rmm_ora_id)
            }

            //Function to refresh the action data
            vm.refreshActions = (id) => {
                payload = {
                    rmm_ora_id: id
                }
                $q.all([
                    oraService.getGaHaActions(payload).then((response) => {

                        vm.currentOra.general_actions = actionManagementService.addCanCloseActionPermission(response.general_actions, 'general', vm.canCloseAllActions, vm.userId)
                        vm.currentOra.hazard_actions = actionManagementService.addCanCloseActionPermission(response.hazard_actions, 'hazard', vm.canCloseAllActions, vm.userId)

                        vm.immediateActions()
                    })
                ]).then(()=>{
                    destroyTables().then(()=>{
                        initiateTables()
                    })
                })
            }      

            vm.immediateActions = () =>{
                vm.currentOra.hazard_actions.forEach((data)=>{
                    if(!data.further_action_required && data.immediate_action_required_and_performed) {
                        data.action_complete_by_who = data.created_by
                        data.recommended_action = data.immediate_action_taken
                        data.action_by_when = moment(data.sha_created_date).format('YYYY-MM-DD')
                    }
                })
            }

            //Function to force close the viewer
            vm.forceCloseViewer = () => {
                vm.changesInForm = false
                vm.cancelModal('confirmModal')
                vm.cancelModal('signOraSuccessModal')
                vm.cancelModal('signOraFailureModal')
                vm.employeeList = []
                vm.releaseDocument(vm.dlo_id).then((response) => {
                })
                clearInterval(vm.updateDocLockInterval)
                clearInterval(vm.lockModal)
                clearInterval(vm.countdownTimer)
                // Stop the Autosave
                $interval.cancel(vm.autosave)
                vm.hideingOraViewer = true
                vm.resetForm()
                refreshData()
                $timeout(() => {
                    vm.oraViewerOpen = false
                }, 400)
            }
            
            //Function to close the viewer
            vm.closeViewer = () => {
                hasFormChanged()
                if (!vm.currentUserSigned){
                    if (vm.changesInForm && !vm.openingOraViewer == true){
                        vm.changesInForm = false
                        vm.modalElementsChange = {
                            title: translateTag(2273), //"Confirm Changes"
                            message: `<div><p>${translateTag(2274)}</p></div>`, //"Any unsaved changes made on this document would be lost! Do you want to proceed ?"
                            buttons: 
                                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="SAVE & CLOSE">{{vm.componentTranslateLabels(2276)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note= "CLOSE ANYWAY">{{vm.componentTranslateLabels(2275)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button3')" note= "Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                        } 
                        document.getElementById('confirmcallingform').innerHTML = 'ORACHANGECALLCONFIRMMODAL' 
                        $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsChange)
                        return
                    }
                }
                vm.releaseDocument(vm.dlo_id).then((response) => {
                })
                clearInterval(vm.updateDocLockInterval)
                clearInterval(vm.lockModal)
                clearInterval(vm.countdownTimer)
                vm.cancelModal('signOraSuccessModal')
                vm.cancelModal('signOraFailureModal')
                vm.hideingOraViewer = true
                // Stop the Autosave
                $interval.cancel(vm.autosave)
                vm.resetForm()
                refreshData()
                $timeout(() => {
                    vm.oraViewerOpen = false
                }, 400)
            }

            $scope.$on("ORACHANGECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.saveAndCloseOra()
                }
                else if (result=='button2') {
                    vm.forceCloseViewer()
                }
                else if (result=='button3') {
                    vm.cancelModal('confirmModal')
                }
            })

            // function to release document lock
            vm.releaseDocument = (id) => {
                payload = {}
                payload.dlo_id = id
                return (
                    $q.all([
                        documentLockService.closeDocLock(payload)
                    ])
                )
            }

            //Function to open modals
            vm.openModal = (modalId) => {
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()

                $('.modal .scroll').scrollTop(0)

                modalService.Open(modalId)
                vm.initializeSelect2(modalId, '.modal-body')
            }

            //Function to open the create action modals
            vm.openActionModal = (modalId) => {
                resetFormFieldClassList('oraForm')
                if (validateFormFields('oraForm', true)){
                    vm.actionMode = 'new'
                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()
                    $('.modal .scroll').scrollTop(0)
                
                    if(vm.currentMode === "new") {                                                        // Save the Document before opening an action modal
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentOra)))
                        payload.rmm_ora_is_submitted = false
                        vm.updatingRecord = true
                        toastr.options.progressBar = true
                        throwToastr('info',translateTag(3856)+"...",5000)
                        oraService.createOra(payload).then((response) => {
                            if (response.rmm_ora_id){
                                vm.getSingleDetailRec(response.rmm_ora_id).then(() => {
                                    $q.all([
                                        vm.initializeTagsAndPulldowns()
                                    ]).then((data) => {
                                        vm.rmm_ora_doc_revision_no = `${appendLeadingZeros(vm.currentOra.rmm_ora_document_number)}`+'.'+`${appendLeadingZeros(vm.currentOra.rmm_ora_doc_version_number,3)}`
                                        vm.validateCurrentUserInApprovers()
                                        $('#newOra').data('serialize',$('#newOra').serialize())
                                        resetFormFieldClassList('oraForm')
                                        modalService.Open(modalId)
                                        vm.initializeSelect2(modalId, '.modal-body')
                                    })
                                })
                                refreshData()
                            }
                            if (!response){
                                throwToastr('error', translateTag(3857), 2000)
                            }
                            vm.updatingRecord = false
                        })
                    }
                    else{
                        modalService.Open(modalId)
                        vm.initializeSelect2(modalId, '.modal-body')
                    }
                }else{
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            //Function to open the edit action modals
            vm.openActionEditModal = (modalId, id) => {
                vm.actionMode = 'edit'
                if(modalId === 'generalActionModal') {
                    openGeneralEdit(id, modalId)
                    vm.refreshActions(vm.currentOra.rmm_ora_id)
                }
                else if(modalId === 'hazardActionModal') {
                    openHazardEdit(id, modalId)
                    vm.refreshActions(vm.currentOra.rmm_ora_id)
                }
            }

            //Function to prepare data to edit a general action
            function openGeneralEdit(id, modalId) {
                actionManagementService.getGeneralActionSingle({sga_id: id}).then ((response) => {
                    vm.generalEditData = response

                    vm.generalEditData.Site = parseInt(vm.generalEditData.Site)
                    vm.generalEditData.JobNumber = parseInt(vm.generalEditData.JobNumber)
                    vm.generalEditData.SiteLevel = parseInt(vm.generalEditData.SiteLevel)
                    vm.generalEditData.Supervisor = parseInt(vm.generalEditData.Supervisor)

                    vm.generalEditData.HeaderDate = moment(vm.generalEditData.HeaderDate).format('YYYY-MM-DD')
                    vm.generalEditData.sga_action_by_who_per_id = vm.generalEditData.sga_action_by_who_per

                    let i = 0
                    let initialAtt = JSON.parse(JSON.stringify(vm.generalEditData.attachments))
                    initialAtt.forEach((att) => {
                        if(att.gaa_type === 'FOLLOWUP')
                            vm.generalEditData.attachments.splice(i, 1)
                        else
                            i++
                    })
                    
                    vm.generalEditData.attachments.forEach((att) => {
                        att.imageDir = `${__env.imageUrl}/`
                    })

                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()

                    $('.modal .scroll').scrollTop(0)

                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId,  '.modal-body')
                })
            }

            //Function to prepare data to edit a hazard action
            function openHazardEdit(id, modalId) {
               
                actionManagementService.getHazardActionSingle({hap_id: id}).then ((response) => {
                    vm.hazardEditData = response

                    vm.hazardEditData.Site = parseInt(vm.hazardEditData.Site)
                    vm.hazardEditData.JobNumber = parseInt(vm.hazardEditData.JobNumber)
                    vm.hazardEditData.SiteLevel = parseInt(vm.hazardEditData.SiteLevel)
                    vm.hazardEditData.Supervisor = parseInt(vm.hazardEditData.Supervisor)

                    vm.hazardEditData.HeaderDate = moment(vm.hazardEditData.HeaderDate).format('YYYY-MM-DD')

                    let i = 0
                    let initialAtt = JSON.parse(JSON.stringify(vm.hazardEditData.attachments))
                    initialAtt.forEach((att) => {
                        if(att.attachmenttype === 'FOLLOWUP')
                            vm.hazardEditData.attachments.splice(i, 1)
                        else
                            i++
                    })
                    
                    vm.hazardEditData.attachments.forEach((att) => {
                        att.imageDir = `${__env.imageUrl}/`
                    })

                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()

                    $('.modal .scroll').scrollTop(0)

                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId, '.modal-body')
                })
            }

            //Function to open the complete action modals
            vm.completeActionModal = (action, type) => {
                if(type === 'General')
                {
                    actionManagementService.getGeneralActionSingle({sga_id: action.sga_id}).then ((response) => {
                        vm.generalFollowup = response
                        vm.generalFollowup.sga_completed_action_date = dateToday.format('YYYY-MM-DD')
                        vm.generalFollowup.sga_action_by_who_per_id = vm.getEmployeeName(vm.generalFollowup.sga_action_by_who_per)
                        if(vm.generalFollowup.sga_completed_action_by_who_per != null)
                            vm.generalFollowup.sga_completed_action_by_who_per_id = parseInt(getEmployeeID(vm.generalFollowup.sga_completed_action_by_who_per))
                        vm.generalFollowup.attachment_files_initial = []
                        vm.generalFollowup.attachment_files_followup = []

                        vm.generalFollowup.attachments.forEach((attRec) => {
                            if(attRec.gaa_type == 'INITIAL')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                vm.generalFollowup.attachment_files_initial.push(attRec)
                            }
                            else if(attRec.gaa_type == 'FOLLOWUP')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                vm.generalFollowup.attachment_files_followup.push(attRec)
                            }
                        })

                        vm.openModal('completeGeneralActionModal')
                        setTimeout(()=>{
                            $scope.$broadcast('GENERAL_FOLLOWUP_OPENED')
                        },100) 
                    })
                }
                else
                {
                    actionManagementService.getHazardActionSingle({hap_id: action.id}).then ((response) => {
                        vm.followup = response
                        vm.followup.action_completed_date = dateToday.format('YYYY-MM-DD')
                        vm.followup.action_complete_by_who = (vm.followup.action_complete_by_who && vm.followup.action_complete_by_who != 'None') ? parseInt(getEmployeeID(vm.followup.action_complete_by_who)) : null
                        vm.followup.attachmentModalFiles = []
                        vm.followup.followupAttachmentModalFiles = []

                        vm.followup.attachments.forEach((attRec) => {
                            if(attRec.attachmenttype === 'INITIAL')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                attRec.AttachmentFileName = attRec.attachmentfilename
                                vm.followup.attachmentModalFiles.push(attRec)
                            }
                            else if(attRec.attachmenttype === 'FOLLOWUP')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                attRec.AttachmentFileName = attRec.attachmentfilename
                                vm.followup.followupAttachmentModalFiles.push(attRec)
                            }
                        })

                        vm.followup.HapId = action.id
                        vm.followup.action_by_who_name = vm.getEmployeeName(action.action_by_who)
                        vm.openModal('hapFollowupComponent')
                        setTimeout(()=>{
                            $scope.$broadcast('HAZARD_FOLLOWUP_OPENED')
                        },100)
                    })
                }
            }

            // Function to validate approvers for sign
            vm.validateCurrentUserInApprovers = () => {
                vm.userInApprovers = false
                if(vm.currentOra.approvers) {
                    if (vm.currentOra.approvers.length > 0){
                        vm.currentOra.approvers.forEach((app) => {
                            if (app === vm.userId){
                                vm.userInApprovers = true
                                return
                            }
                        })
                    }
                }
            }

            //Function to validate for Sign modal
            vm.validateForSign = () => {
                vm.noOfExtremes = 0
                vm.noOfHighs = 0
                vm.noOfRiskAlara = 0
                vm.noOfHaps = 0
                vm.signFlag = true
                vm.currentOra.event_categories.forEach((ec)=>{
                    ec.events.forEach((ev)=>{
                        if (ev.rmm_oev_risk_alara_preliminary === 0){
                            if (ev.rmm_oev_risk_alara_residual === 0){
                                vm.noOfRiskAlara += 1
                                vm.signFlag = false
                            }
                        }
                        // 3626 - Extreme
                        if (ev.rmm_oev_risk == 3626){ 
                            vm.noOfExtremes += 1
                        }
                        // 3622 - High
                        if (ev.rmm_oev_risk == 3622){
                            vm.noOfHighs += 1
                        }
                    })
                })
                vm.currentOra.hazard_actions.forEach((hap)=> {
                    if (hap.action_status !== 1){

                        vm.noOfHaps += 1
                        vm.signFlag = false
                    }
                })

                return vm.signFlag
            }

            vm.validateBowtieOra = () => {
                return new Promise(resolve =>{
                    oraService.validateBowtieOra(vm.currentOra.rmm_ora_id).then((response) => {
                        vm.validateBowtie = response.validate_bowtie
                        vm.missing_bowtie = response.missing_bowtie
                        resolve(vm.validateBowtie)
                    })
                })
            }

            // Function to verify if form has changed
            function hasFormChanged() {
                if($('#newOra').serialize() != $('#newOra').data('serialize')){
                    $('#newOra').data('serialize',null)
                    vm.changesInForm = true
                }
            }

            //Function to open the complete action modals
            vm.signActionModal = () => {
                
                hasFormChanged()
                if (vm.changesInForm) {
                    vm.saveOra()
                }
                vm.validateOra().then((res)=>{
                    vm.validateBowtieOra().then((data)=>{
                        if(res.val && res.chip){
                            let checkValidateSign = vm.validateForSign()
                            let checkValidateBowtie = data
                            if (checkValidateSign && checkValidateBowtie){
                                vm.currentUserSigned = false
                                vm.currentOra.approversList.forEach((app) => {
                                    if (app.rmm_oap_per === vm.userId && app.rmm_oap_approved){
                                        vm.currentUserSigned = true 
                                    }
                                })
                                vm.openModal('signOraSuccessModal')
                            } else {
                                vm.openModal('signOraFailureModal')
                            }
                        } else {
                            if(!res.val){
                                $rootScope.$broadcast("CALLCONFIRMMODAL")
                            }
                        }
                    })
                })
            }

            //Function to save the Ora
            vm.saveOra = (mode = 'normal') =>{ 
                resetFormFieldClassList('oraForm')
                if (validateFormFields('oraForm', true)) {
                    // for autosave so that is does not show the spinner
                    if (mode === 'normal') {
                        $scope.$emit('STARTSPINNER', translateTag(3879))
                    }
                    else {
                        vm.autoSaveActive = true
                    }

                    $('#newOra').data('serialize',$('#newOra').serialize())
                    vm.changesInForm = false
                    if(vm.currentMode === "new") {
                        vm.updatingRecord = true
                        vm.saved = true
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentOra)))
                        payload.rmm_ora_is_submitted = false
                        oraService.createOra(payload).then((response) => {
                            if (response.rmm_ora_id){
                                // for Auto Save to not interupt the user with refreshing
                                if(mode === 'normal') {
                                    vm.getSingleDetailRec(response.rmm_ora_id).then(() => {
                                        $q.all([
                                            vm.initializeTagsAndPulldowns()
                                        ]).then((data) => {
                                            vm.rmm_ora_doc_revision_no = `${appendLeadingZeros(vm.currentOra.rmm_ora_document_number)}`+'.'+`${appendLeadingZeros(vm.currentOra.rmm_ora_doc_version_number,3)}`
                                            vm.validateCurrentUserInApprovers()
                                            vm.updatingRecord = false
                                            $scope.$emit('STARTSPINNER')
                                            refreshData()
                                        })
                                    })
                                }
                                else {
                                    reloadAutoSave(response.rmm_ora_id)
                                }
                            }
                            else {
                                vm.updatingRecord = false
                            }
                            if (!response){
                                throwToastr("error",translateTag(3857), 2000)
                            }
                        })
                    }
                    else {

                        let payload = preparePayload('edit', JSON.parse(JSON.stringify(vm.currentOra)))
                        vm.updatingRecord = true
                        if(mode === 'normal'){
                            payload.rmm_ora_is_submitted = false
                        }

                        vm.tmpDeletedEventCategories = []
                        vm.tmpDeletedEvents = []
                        oraService.updateOra(payload).then((response) => {
                            if (response.rmm_ora_id) {
                                // for Auto Save to not interupt the user with refreshing
                                if(mode === 'normal') {
                                    vm.getSingleDetailRec(response.rmm_ora_id).then(() => {
                                        $q.all([
                                            vm.initializeTagsAndPulldowns()
                                        ]).then((data) => {
                                            vm.rmm_ora_doc_revision_no = `${appendLeadingZeros(vm.currentOra.rmm_ora_document_number)}`+'.'+`${appendLeadingZeros(vm.currentOra.rmm_ora_doc_version_number,3)}`
                                            vm.validateCurrentUserInApprovers()
                                            vm.updatingRecord = false
                                            $scope.$emit('STARTSPINNER')
                                            refreshData()
                                        })
                                    })
                                }
                                else {
                                    // Update everything needed for the  Modal - Autosave
                                    reloadAutoSave(response.rmm_ora_id)
                                }
                            }
                            if (!response){
                                throwToastr("error",translateTag(3858), 2000)
                            }
                        }) 
                    }
                }else{
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            function reloadAutoSave(id) {
                // Update everything needed for the AG- Grid - Autosave
                oraService.getOraSIngleDetailRec(id).then((res) => {
                    vm.currentOra.approversList = []
                    angular.copy(res.approvers,vm.currentOra.approversList)
                    vm.currentOra.approvers = getApprovers(res.approvers)
                    vm.currentOra.rmm_ora_id =  res.rmm_ora_id
                    vm.currentOra.rmm_ora_state =  res.rmm_ora_state
                    vm.currentOra.rmm_ora_doc_version_number = res.rmm_ora_doc_version_number
                    vm.currentOra.rmm_ora_document_number = res.rmm_ora_document_number
                    // Loop through all the data and update the ID/s
                    vm.currentOra.event_categories.forEach((cat,catindex) => {
                        if(res.event_categories[catindex]){
                            cat.rmm_oec_id = res.event_categories[catindex].rmm_oec_id
                            cat.rmm_oec_ora = res.event_categories[catindex].rmm_oec_ora
                        }
                        cat.events.forEach((evt, evtindex) => {
                            if(res.event_categories[catindex].events[evtindex]) {
                                evt.rmm_oev_id = res.event_categories[catindex].events[evtindex].rmm_oev_id
                                evt.rmm_oev_oec = res.event_categories[catindex].events[evtindex].rmm_oev_oec
                            }
                            evt.control_measures.forEach((cm, cmindex)=>{
                                if(res.event_categories[catindex].events[evtindex].control_measures[cmindex]){
                                    cm.rmm_ota_id = res.event_categories[catindex].events[evtindex].control_measures[cmindex].rmm_ota_id
                                    cm.rmm_ota_created_by_per = res.event_categories[catindex].events[evtindex].control_measures[cmindex].rmm_ota_created_by_per
                                    cm.rmm_ota_enable = res.event_categories[catindex].events[evtindex].control_measures[cmindex].rmm_ota_enable
                                    cm.rmm_ota_parent_tag_name = res.event_categories[catindex].events[evtindex].control_measures[cmindex].rmm_ota_parent_tag_name
                                    cm.rmm_ota_oev = res.event_categories[catindex].events[evtindex].control_measures[cmindex].rmm_ota_oev
                                }
                            })
                            evt.additional_control_measures.forEach((acm, acmindex) => {
                                if(res.event_categories[catindex].events[evtindex].additional_control_measures[acmindex]) {
                                    acm.rmm_ota_id = res.event_categories[catindex].events[evtindex].additional_control_measures[acmindex].rmm_ota_id
                                    acm.rmm_ota_created_by_per = res.event_categories[catindex].events[evtindex].additional_control_measures[acmindex].rmm_ota_created_by_per
                                    acm.rmm_ota_enable = res.event_categories[catindex].events[evtindex].additional_control_measures[acmindex].rmm_ota_enable
                                    acm.rmm_ota_parent_tag_name = res.event_categories[catindex].events[evtindex].additional_control_measures[acmindex].rmm_ota_parent_tag_name
                                    acm.rmm_ota_oev = res.event_categories[catindex].events[evtindex].additional_control_measures[acmindex].rmm_ota_oev
                                }
                            })
                        })
                    })
                    vm.rmm_ora_doc_revision_no = `${appendLeadingZeros(vm.currentOra.rmm_ora_document_number)}`+'.'+`${appendLeadingZeros(vm.currentOra.rmm_ora_doc_version_number,3)}`
                    vm.uneditedCurrentOra = []
                    vm.validateCurrentUserInApprovers()
                    vm.updatingRecord = false
                    vm.uneditedCurrentOra = []
                    angular.copy(vm.currentOra, vm.uneditedCurrentOra)
                })
            }

            //Function to save and close the ORA
            vm.saveAndCloseOra = () => {
                vm.cancelModal('confirmModal')
                $interval.cancel(vm.autosave)
                vm.saveOra()
                setTimeout(()=>{
                    vm.forceCloseViewer()
                },4700)  
            }
            
            //Function to sign the ORA
            vm.signOra = (modalId) => {
                if(validateText(vm.currentOra.rmm_ora_executive_summary,"")) {
                    $scope.$emit('STARTSPINNER', translateTag(3877))
                    payload = {
                        rmm_ora_id: vm.currentOra.rmm_ora_id,
                        rmm_ora_executive_summary: vm.currentOra.rmm_ora_executive_summary ? vm.currentOra.rmm_ora_executive_summary : ""
                    }
                    vm.currentUserSigned = true
                    vm.cancelModal(modalId)
                    oraService.signOra(payload).then((response) => {
                        // Stop the Autosave
                        $interval.cancel(vm.autosave)
                        vm.autoSaveActive = false
    
                        if (response.message === "Document Signed"){
                            vm.currentUserSigned = true
                            vm.currentOra.rmm_ora_state = response.rmm_ora_state
                            vm.currentOra.approversList.forEach((app) => {       
                                if (app.rmm_oap_per === vm.userId){
                                    app.rmm_oap_approved = true         //Setting the approved flag of current approver to true
                                }
                            })
                        }
                        refreshData()
                        $scope.$emit('STOPSPINNER')
                        vm.cancelModal(modalId)
                    })
                }
                else{
                    document.getElementById('rmm_ora_executive_summary').classList.add('invalid')
                    document.getElementById('rmm_ora_executive_summary').setCustomValidity(false)
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            function newApprover(){
                return(                             
                    {
                        rmm_oap_per: null,
                        rmm_oap_approved: false,
                        rmm_oap_approved_date: null,
                        full_name: null
                    })
            }

            //Function to prepare payload data
            function preparePayload(mode='new', payload) {
                  let preparedPayload = payload
                if (mode === "new"){
                    preparedPayload.rmm_ora_state = 'draft'
                    preparedPayload.rmm_ora_created_date = preparedPayload.rmm_ora_created_date===null ?null :moment(payload.rmm_ora_created_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_ora_date = (preparedPayload.rmm_ora_date===null || preparedPayload.rmm_ora_date===undefined) ? null:moment(payload.rmm_ora_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_ora_expiry_date = (preparedPayload.rmm_ora_expiry_date===null || preparedPayload.rmm_ora_expiry_date===undefined) ? null:moment(payload.rmm_ora_expiry_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    
                    preparedPayload.rmm_oev_preliminary_risk = 
                    
                    payload.event_categories.forEach((ec, index) => {
                        ec.events.forEach((ev, index) => {
                            tmp_cm = []
                            tmp_additional = []
                            ev.control_measures.forEach((val, index) => {
                                newCMObj = newTag()
                                newCMObj.tag = val.tag
                                tmp_cm.push(newCMObj)
                            })
                            ev.additional_control_measures.forEach((val, index) => {
                                newAdditionalCMObj = newTag()
                                newAdditionalCMObj.tag = val.tag
                                tmp_additional.push(newAdditionalCMObj)
                            })
                            ev.control_measures = tmp_cm
                            ev.additional_control_measures = tmp_additional
                        })
                    })
                }else{
                    preparedPayload.rmm_ora_created_date = preparedPayload.rmm_ora_created_date===null ?null :moment(payload.rmm_ora_created_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_ora_date = (preparedPayload.rmm_ora_date===null || preparedPayload.rmm_ora_date===undefined) ? null:moment(payload.rmm_ora_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.rmm_ora_expiry_date = (preparedPayload.rmm_ora_expiry_date===null || preparedPayload.rmm_ora_expiry_date===undefined) ?null:moment(payload.rmm_ora_expiry_date, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DD')
                    preparedPayload.approvers = payload.approvers != undefined ?  payload.approvers : []
                    preparedPayload.participants = payload.participants != undefined ? payload.participants : []

                    //Title and scope
                    preparedPayload.rmm_ora_title = payload.rmm_ora_title ? payload.rmm_ora_title : null
                    preparedPayload.rmm_ora_scope = payload.rmm_ora_scope ? payload.rmm_ora_scope : null


                    payload.event_categories.forEach((ec, index) => {
                        ec.events.forEach((ev, index) => {
                            ev.rmm_oev_major_unwanted_event = ev.rmm_oev_major_unwanted_event ? ev.rmm_oev_major_unwanted_event : null
                            ev.rmm_oev_outcome = ev.rmm_oev_outcome ? ev.rmm_oev_outcome : null
                            tmp_cm = []
                            tmp_additional = []
                             ev.control_measures.forEach((cm, index) => {
                                if (!cm.rmm_ota_id){
                                    newCMObj = newTag()
                                    newCMObj.tag = cm.tag
                                    tmp_cm.push(newCMObj)
                                }else{
                                    tmp_cm.push(cm)
                                }
                            })
                            ev.additional_control_measures.forEach((add, index) => {
                                if (!add.rmm_ota_id){
                                    newAdditionalCMObj = newTag()
                                    newAdditionalCMObj.tag = add.tag
                                    tmp_additional.push(newAdditionalCMObj)
                                }else{
                                    tmp_additional.push(add)
                                }
                            })
                            ev.control_measures = tmp_cm
                            ev.additional_control_measures = tmp_additional
                            ev.rmm_oev_likelyhood_preliminary = ev.rmm_oev_likelyhood_preliminary !== undefined ? ev.rmm_oev_likelyhood_preliminary : null
                            ev.rmm_oev_severity_preliminary = ev.rmm_oev_severity_preliminary !== undefined ? ev.rmm_oev_severity_preliminary : null
                            ev.rmm_oev_preliminary_risk = ev.rmm_oev_preliminary_risk !== undefined ? ev.rmm_oev_preliminary_risk : null
                            ev.rmm_oev_require_bowtie = ev.rmm_oev_require_bowtie !== undefined ? ev.rmm_oev_require_bowtie : null
                            ev.rmm_oev_risk_alara_preliminary = ev.rmm_oev_risk_alara_preliminary !== undefined ? ev.rmm_oev_risk_alara_preliminary : null

                            ev.rmm_oev_likelyhood_residual = ev.rmm_oev_likelyhood_residual ? ev.rmm_oev_likelyhood_residual : null
                            ev.rmm_oev_severity_residual = ev.rmm_oev_severity_residual !== undefined ? ev.rmm_oev_severity_residual : null
                            ev.rmm_oev_residual_risk = ev.rmm_oev_residual_risk !== undefined ? ev.rmm_oev_residual_risk : null
                            ev.rmm_oev_risk_alara_residual = ev.rmm_oev_risk_alara_residual !== undefined ? ev.rmm_oev_risk_alara_residual : null

                        })
                    })
                    vm.uneditedCurrentOra.event_categories.forEach((uec, index) => {
                        uec.events.forEach((uev, index) => {
                            uev.control_measures.forEach((ucm, index) => {
                                payload.event_categories.forEach((ec, index) => {
                                    ec.events.forEach((ev, index) => {
                                        if (uev.rmm_oev_id===ev.rmm_oev_id && !ev.control_measures.find(cm => cm.rmm_ota_id === ucm.rmm_ota_id)){
                                            ucm.rmm_ota_enable = false
                                            ev.control_measures.push(ucm)
                                        }
                                    }) 
                                })
                            })
                            uev.additional_control_measures.forEach((uadd, index) => {
                                payload.event_categories.forEach((ec, index) => {
                                    ec.events.forEach((ev, index) => {
                                        if (uev.rmm_oev_id===ev.rmm_oev_id && !ev.additional_control_measures.find(add => add.rmm_ota_id === uadd.rmm_ota_id)){
                                            uadd.rmm_ota_enable = false
                                            ev.additional_control_measures.push(uadd)
                                        }
                                    }) 
                                })
                            })
                        })
                    })

                    vm.tmpDeletedEventCategories.forEach((dec) => {
                        preparedPayload.event_categories.push(dec) 
                    })
                    
                    vm.tmpDeletedEvents.forEach((dev) => {
                        preparedPayload.event_categories.forEach((ec) => {
                            if (dev.rmm_oev_oec === ec.rmm_oec_id) {
                                ec.events.push(dev)
                            }
                        })
                    })
                }
                return preparedPayload
            }

            //Function to add an action to this assessment
            vm.addAction = (actionData) => {
                payload = {}
                if('sga_id' in actionData){
                    payload.rmm_oga_ora = vm.currentOra.rmm_ora_id
                    payload.rmm_oga_sga = actionData.sga_id

                    oraService.addOraGeneralAction(payload).then((response) => {
                        vm.refreshActions(vm.currentOra.rmm_ora_id)
                    })
                }
                else if('ID' in actionData){
                    payload.rmm_oha_ora =  vm.currentOra.rmm_ora_id
                    payload.rmm_oha_sha = actionData.ID

                    oraService.addOraHazardAction(payload).then((response) => {
                        vm.refreshActions(vm.currentOra.rmm_ora_id)
                    })
                }
            }

            //Function to remove completed actions from the grid
            vm.completeAction = (actionData) => {
                vm.refreshActions(vm.currentOra.rmm_ora_id)
            }

            //Funtion to initialize select2
            vm.initializeSelect2 = (parent, section='')=> {
                setTimeout(()=>{
                $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} ${section}`), escapeMarkup: function (text) { return text } })
                .on('select2:select', () => {
                    $(this).parent().find('label').addClass('filled')
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()
                today = new Date()
                if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
                $('.datepicker').pickadate({
                    format: 'yyyy-mm-dd',
                    onClose : function(){
                        this.$holder.blur()
                    },
                    min: new Date(moment(today).calendar()),
                }).removeAttr('readonly')
                .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                    evt.preventDefault()
                })
                preventFutureDatePickerInit()
                }, 500)
            }

            //Listeners
            $scope.$on('CLOSEMODAL', (event) => {
                vm.initializeSelect2('newOra')
            })

            $scope.$on('ADDACTION', (event, data) => {
                if(data && vm.actionMode != 'edit'){
                    vm.addAction(data)
                }else{
                    vm.refreshActions(vm.currentOra.rmm_ora_id)
                }
            })

            $scope.$on('COMPLETEACTION', (event, data) => {
                if(data)
                    vm.completeAction(data)
            })

            //Function to refresh data and Ag-Grid
            function refreshData() {
                $scope.$emit('STARTSPINNER', vm.loadMessage)
                $q.all([
                    listService.getSelectListData('ref_site'),
                    listService.getSelectListData('ref_job'),
                    listService.getSelectListData('ref_general_action'),
                    employeesService.getPersonProfile(),
                    profileService.getAllEmployeeProfile(),
                    profileService.getFullEmployeeProfile(),
                    listService.getSelectListData('ref_likelihood'),
                    listService.getSelectListData('ref_severity'),
                    listService.getSelectListData('ref_event_category'),
                    listService.getActionTypes(),
                    oraService.getOraList(vm.mainDateFilter),
                    listService.getFullSiteList(),
                    profileService.getRmmApproverEmployees('rmm-ora'),

                ]).then((data) => {
                    vm.siteList = data[0]
                    vm.jobList = data[1]
                    vm.actionTypeList = data[2]
                    vm.userId = data[3].per_id
                    vm.fullEmployeeList = profileService.readFullEmployeeProfile()
                    vm.likelyHoodList = data[6]
                    vm.severityList = data[7]
                    vm.eventCategoryList = data[8]
                    vm.hapActionTypeList = data[9]
                    vm.oraAGData = oraService.readOraList()
                    vm.tmpDeletedEventCategories = []
                    vm.tmpDeletedEvents = []
                    vm.site_name = listService.readFullSites()


                    if (vm.oraOptions.api) {
                        translateAgGridHeader(vm.oraOptions)
                        let model = vm.oraOptions.api.getFilterModel()
                        vm.oraOptions.paginationPageSize = 15
                        vm.oraOptions.api.setRowData(prepareOraGridData())
                        vm.oraOptions.api.redrawRows()
                        vm.oraOptions.api.sizeColumnsToFit()
                        vm.oraOptions.api.setFilterModel(model)
                    }
                    vm.actionDisabled = true
                    $scope.$emit('STOPSPINNER')
                })
            }

            vm.resetForm()
            vm.oraViewerOpen = true
            vm.initializeSelect2('newOra')
            vm.oraViewerOpen = false

            //function to append leading zeros
            function appendLeadingZeros (num, size=6){
                var s = "000000000" + num;
                return s.substr(s.length-size);
            }

            //Function to prepare Ag-Grid data with string values
            function prepareOraGridData() {
                let oraGridData = JSON.parse(JSON.stringify(vm.oraAGData))
                oraGridData.forEach((rec) =>{
                    rec.exceptionFields = ['approvers','general_actions', 'hazard_actions', 'acknowledgements', 'participants', 'rmm_ora_enable', 'dlo_enable', 'reviewers','rat_ora_show_check_box','rmm_ora_created_by_per_id','rmm_ora_submitted_date']
                    rec.rmm_ora_site = getSiteName(rec.rmm_ora_site)
                    rec.rmm_ora_created_date = moment(rec.rmm_ora_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                    rec.rmm_ora_expiry_date =  rec.rmm_ora_expiry_date===null?'':moment(rec.rmm_ora_expiry_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                    rec.rmm_ora_is_submitted  = translateTrueFalse(rec.rmm_ora_state == 'active' ||  rec.rmm_ora_state == 'expired' ? true : false)
                    rec.rmm_ora_revision_no = `${appendLeadingZeros(rec.rmm_ora_document_number)}`+'.'+`${appendLeadingZeros(rec.rmm_ora_doc_version_number,3)}`
                    if(rec.dlo_enable.length !== 0){
                        rec.dlo_status = translateTrueFalse(rec.dlo_enable[0].dlo_enable)
                        rec.dlo_person = rec.dlo_enable[0].dlo_person
                    }
                    else{
                        rec.dlo_status = translateTrueFalse(true)
                        rec.dlo_person = null
                    }

                    rec.approversList = ''
                    rec.approvers.forEach((app) => {
                        rec.approversList += (`${vm.getEmployeeName(app.rmm_oap_per)} - `)
                    })
                    rec.approvers =  rec.approversList.replace(/ -\s*$/, "")
                    rec.approversList =  rec.approversList.replace(/ -\s*$/, "")
                    
                    rec.participantsList = ''
                    rec.participants.forEach((par) => {
                        rec.participantsList += (`${vm.getEmployeeName(par)} - `)
                    })
                    rec.participants = rec.participantsList.replace(/ -\s*$/, "")
                    rec.participantsList = rec.participantsList.replace(/ -\s*$/, "")

                    rec.reviewersList = ''
                    rec.reviewers.forEach((rev) => {
                        rec.reviewersList += (`${vm.getEmployeeName(rev.rmm_ore_per_id)} - `)
                    })
                    rec.reviewersList =  rec.reviewersList.replace(/ -\s*$/, "")

                    rec.reviewedCount = rec.reviewers.length
                    rec.hasReviewed = translateTrueFalse(checkAcknowledged(rec))
                           
                })
                return oraGridData
            }

            function translateStatus(status) {
                if (status === 'draft'){
                    return translateTag(1399)
                }
                if (status === 'expired'){
                    return translateTag(3494)
                } 
                if (status == 'review'){
                    return translateTag(1188)
                } 
                if (status == 'active'){
                    return translateTag(3557)
                }
            }

            function translateTrueFalse(val) {
                return val ? translateTag(1379): translateTag(1380)
            }

            //Function to prepare Participants
            function getParticipants (values)
            {
                let participants = []
                values.forEach ((rec) => {
                    participants.push(rec.llp_per)
                })
                return participants
            }

            //Function to prepare Approvers
            function getApprovers (values)
            {
                let approvers = []
                values.forEach ((rec) => {
                    approvers.push(rec.rmm_oap_per)
                })
                return approvers
            }

            //Update Ag-Grid size when window is resized
            $(window).on('resize', () => {
                $timeout(function () {
                    if (vm.oraOptions.api) {
                        vm.oraOptions.api.sizeColumnsToFit()
                    }
                    if (vm.attachmentOptions.api) {
                        vm.attachmentOptions.api.sizeColumnsToFit()
                    }
                })
            })

            // Function to initialize tags
            vm.initializeTags = () => {
                setTimeout(()=>{
                    vm.currentOra.event_categories.forEach((ec_val, i) => {
                        ec_index = ec_val.rmm_oec_sort                          
                        ec_val.events.forEach((ev_val, j) =>{
                            id = "#control_measure-"+ j + "-" + ec_index
                            $(id).materialChip({
                                placeholder: '+ ' + translateTag(2478),
                                secondaryPlaceholder: translateTag(2109),
                                data: ev_val.control_measures
                            }).on('chip.add',(e, chip)=>{
                                for (let index = 0; index < ev_val.control_measures.length-1; index++) {
                                    if (ev_val.control_measures[index].tag.trim().toLowerCase() === chip.tag.trim().toLowerCase()){
                                        throwToastr('error',translateTag(3859),2000)
                                        ev_val.control_measures.pop()
                                        break
                                    }
                                }
                                vm.changesInForm = true
                            }).on('chip.delete',(data)=>{
                                vm.changesInForm = true
                            })
                        })
                    });

                    vm.currentOra.event_categories.forEach((ec_val, i) => {
                        ec_index = ec_val.rmm_oec_sort                          
                        ec_val.events.forEach((ev_val, j) =>{
                            id = "#additional_measure-"+j+"-"+ec_index
                            $(id).materialChip({
                                placeholder: '+ ' + translateTag(3952), //Additional Control
                                secondaryPlaceholder: translateTag(2116),
                                data: ev_val.additional_control_measures
                            }).on('chip.add',(e, chip)=>{
                                for (let index = 0; index < ev_val.additional_control_measures.length-1; index++) {
                                    if (ev_val.additional_control_measures[index].tag.trim().toLowerCase() === chip.tag.trim().toLowerCase()){
                                        throwToastr('error',translateTag(3860),2000)
                                        ev_val.additional_control_measures.pop()
                                        break;
                                    }
                                }
                                vm.changesInForm = true
                            }).on('chip.delete',()=>{
                                vm.changesInForm = true
                            });
                        })
                    });
                },500)
            }

            // Fuction to check if all modal feilds are valid
            vm.validateOra = () => {
                return new Promise(resolve =>{
                    let validated = validateFormFields('oraForm')
                    asyncChips().then((res)=>{
                        resolve({val:validated, chip:res})
                    })
                })
            }

            function validateChips(){
                return new Promise(resolve => {
                    let chipVal = true
                    vm.currentOra.event_categories.forEach((cat)=> {
                        cat.events.forEach((event)=>{
                            if(event.control_measures.length == 0) {
                                chipVal = false
                                let catList = vm.eventCategoryList.find(element => element.rld_id == cat.rmm_oec_category)
                                throwToastr('error',`${translateTag(2286)}: ${catList.rld_name}  - ${translateTag(2107)}: ${event.rmm_oev_major_unwanted_event} - ${translateTag(2478)} ${translateTag(1464)}`,5000)
                                resolve(chipVal)
                            }
                        })
                    })
                    resolve(chipVal)
                })
            }

            async function asyncChips() {
                dat = await validateChips();
                return dat
            }

            // Move the elements in an array
            function array_move(arr, old_index, new_index) {
                if (new_index >= arr.length) {
                    var k = new_index - arr.length + 1
                    while (k--) {
                        arr.push(undefined)
                    }
                }
                arr.splice(new_index, 0, arr.splice(old_index, 1)[0])
                return arr
            }


            function dragAndSort(){
                $( "#sortable" ).sortable({
                    items: "li:not(.ui-state-disabled)",
                    stop: function( event, ui ) {
                        vm.currentOra.event_categories.forEach((val, index) => {
                            tmp = parseInt(event.target.children[index].firstElementChild.id.split('-').pop())
                            vm.currentOra.event_categories[tmp].rmm_oec_sort = index+1
                        });
                        let tmp_event_categories = []
                        vm.currentOra.event_categories.forEach((val, index) => {
                            let new_index = val.rmm_oec_sort-1
                            tmp_event_categories.splice(new_index,0,val)
                        })
                        vm.currentOra.event_categories = tmp_event_categories
                        $scope.$apply();
                    }
                });
                $( "#sortable" ).sortable({ handle: '.handle'})
                $( "#sortable" ).disableSelection()
            }

            function destroyTables() {
                return new Promise((resolve, reject)=>{
                    if($.fn.DataTable) {
                        if ($.fn.DataTable.isDataTable(".data-table")) {
                            $('.data-table').DataTable().clear().destroy()
                            resolve(true)
                        }
                        else{
                            resolve(true)  
                        }
                    }
                })
            }


            function initiateTables() {
                setTimeout(() =>{
                    $('.data-table').DataTable({
                        "searching": false,
                        "bSort": false,
                        "bLengthChange": false,
                        "pagingType": "numbers",
                        "pageLength": 5,
                        "language": {
                            "url": `/locales/datatables/i18n/${selectedLanguage}.json`
                        }
                    });
                    $('.dataTables_length').addClass('bs-select');
                    $(".dataTables_wrapper div:last-of-type div").removeClass("col-md-5 col-md-7")
                },500)
            }

            $(document).ready(function() {
                vm.initializeTags()
                dragAndSort()
            })

        //END
    }
])