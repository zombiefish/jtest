﻿angular
    .module('safeToDo')
    .service('supervisorsService', ['$http',
        function ($http) {

            var supervisorsPromise = $http.get(`${__env.apiUrl}/api/employee/get-employee-list/`)
              .then(function (response) {
                    for (var i = 0; i < response.data.length; i++) {
                        supervisors.O[response.data[i].per_id] = response.data[i];
                        supervisors.A.push(response.data[i]);
                    }
                    return response.data;
                }, function (args) {
                    console.log('Failed to load supervisors.');
                    console.log(args);
                });

            var supervisorsJobsPromise = $http.get('/api/Jobs/All')
                .then(function (response) {
                    for (var i = 0; i < response.data.length; i++) {
                        supervisorsJobs.push(response.data[i].Job);
                    }
                    return response.data;
                }, function (args) {
                    console.log('Failed to load Jobs.');
                    console.log(args);
                });

            var supervisorsJobs = [];

            var supervisors = {
                O: {},
                A: []
            };

            return {
                getSupervisorsP: function () {
                    return supervisorsPromise;
                },
                getSupervisors: function () {
                    return supervisors;
                },
                getSupervisorsJobsP: function () {
                    return supervisorsJobsPromise;
                },
                getSupervisorsJobs: function () {
                    return supervisorsJobs;
                }
            };
        }
]);