﻿function getTextWidth(text, font) {
    // re-use canvas object for better performance
    var canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement("canvas"));
    var context = canvas.getContext("2d");
    context.font = font;
    var metrics = context.measureText(text);
    return metrics.width;
}

var jsvm = {};

function actionsMenu(targetId, parentId, event) {
    event.stopPropagation();
    jsvm.rowContextId = targetId;
    jsvm.parentId = parentId;

    var y = event.pageY;
    var x = 70;
    var actions = $('#historyActionDropdown');
    actions.addClass('show');
    actions.css({ top: y, right: x });
}

angular
    .module('safeToDo')
    .controller('TargetsCtrl', ['$scope', '$routeParams', '$timeout', '$q', 'listService', 'formsService', 'targetsService', 'employeesService', 'supervisorsService', 'gridService', 'modalService', function ($scope, $routeParams, $timeout, $q, listService, formsService, targetsService, employeesService, supervisorsService, gridService, modalService) {
        var vm = this;
        
        vm.options = gridService.getCommonOptions();
        vm.targets = [];
        vm.supervisors = [];
        vm.frequencies = [];
        vm.forms = [];
        vm.canManageTargets = false;
        vm.mode = 'Add';
        vm.editModel = {
            FDFormID: null,
            SupervisorID: null,
            Target: null,
            FrequencyID: null,
            EffectiveOn: null,
            EffectiveEnd: null,
            clear: function () {
                this.ID = null;
                this.FDFormID = null;
                this.SupervisorID = null;
                this.Target = null;
                this.FrequencyID = null;
                this.EffectiveOn = null;
                this.EffectiveEnd = null;
            },
            copy: function (copyFrom) {
                this.ID = copyFrom.ID;
                this.FDFormID = copyFrom.FDFormID;
                this.SupervisorID = copyFrom.SupervisorID;
                this.Target = copyFrom.Target;
                this.FrequencyID = copyFrom.FrequencyID;
                this.EffectiveOn = copyFrom.EffectiveOn;
                this.EffectiveEnd = copyFrom.EffectiveEnd;
            }
        };
        var editTargetRef = null;

        vm.topSearch = "";
        vm.topSearchChanged = function () {
            vm.options.api.onFilterChanged();
        };
        vm.options.isExternalFilterPresent = function () {
            return vm.topSearch !== "";
        };
        vm.options.doesExternalFilterPass = function (gridRow) {
            for (var property in gridRow.data) {
                
                if (gridRow.data.hasOwnProperty(property)) {
                    //any property in the row matches search box
                    if (property === "SupervisorID") {
                        var email = supervisorsService.getSupervisors().O[gridRow.data[property]].EmailAddress;
                        var name = supervisorsService.getSupervisors().O[gridRow.data[property]].SupervisorName;
                        if ((email + "").toLowerCase().indexOf(vm.topSearch.toLowerCase()) > -1 ||
                            (name + "").toLowerCase().indexOf(vm.topSearch.toLowerCase()) > -1) {
                            return true;
                        }
                    }
                    else if (property === "FDFormID") {
                        var formName = formsService.getTopFormDescriptions().O[gridRow.data[property]].FormName;
                        if ((formName + "").toLowerCase().indexOf(vm.topSearch.toLowerCase()) > -1) { 
                            return true;
                        }
                    }
                    else if (property === "FrequencyID") {
                        var Frequency = frequencyValueGetter(gridRow);
                        if ((Frequency + "").toLowerCase().indexOf(vm.topSearch.toLowerCase()) > -1) {
                            return true;
                        }
                    }
                }
            }
            
            return false;
        };
        var defWidth = 10;

        vm.frequency = 'Other';

        vm.switchFrequency = function(frequency) {
            if (frequency === 1) {
                vm.frequency = 'Daily';
            } else {
                vm.frequency = 'Other';
            }
        };

        vm.disableEffectiveDateSelect = function () {
            return !vm.editModel.FrequencyID || !vm.editModel.FDFormID || !vm.editModel.SupervisorID || !vm.revisionDates;
        };

        vm.minDate = '2017-01-01';

        vm.tryFetchEffectiveDates = function () {
            console.log('change');
            var tgt = vm.editModel;
            if (!tgt.FDFormID || !tgt.SupervisorID || !tgt.FrequencyID) {
                return;
            }
            vm.editModel.EffectiveOn = null;
            targetsService.getRevisionDates(tgt.FDFormID, tgt.SupervisorID, tgt.FrequencyID)
                .then(function (data) {
                    var code = data[0].Code;
                    if (code === null) {
                        vm.revisionDates = data;
                        vm.editModel.EffectiveOn = data[0].EffectiveOn;
                    }
                    var today = new Date();
                    if (code === 'Boundary') {
                        vm.minDate = data[0].EffectiveOn;
                        vm.editModel.EffectiveOn = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                    }

                    if (code === 'NoRecords') {
                        vm.minDate = null;
                        vm.editModel.EffectiveOn = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                    }

                    if (code === 'NoActiveOverwrite') {
                        vm.minDate = data[0].EffectiveOn;
                        vm.editModel.EffectiveOn = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                    }
                });
        };

        function frequencyValueGetter(params) {
            return listService.getFrequencies().O[params.data.FrequencyID + ''].FrequencyDescription;
        }

        function formatDate(date) {
            if (!date)
                return date;

            var pieces = date.split('T')[0].split('-');
            return pieces[1] + '/' + pieces[2] + '/' + pieces[0];
        }

        function targetCellRenderer(params) {
            var ee = formatDate(params.data.EffectiveEnd);
            var eo = formatDate(params.data.EffectiveOn);
            var t = params.data.Target;
            return '<div><div class="supervisor-name">' + t + '</div><div class="supervisor-email">' + eo + (ee === null ? '' : ' - ' + ee) + '</div></div>';
        }

        let targetColumns = [
            {
                field: "SupervisorID",
                headerName: "Employee",
                minWidth: 270,
                cellRenderer: function (params) {
                    var email = supervisorsService.getSupervisors().O[params.data.SupervisorID].EmailAddress;
                    var name = supervisorsService.getSupervisors().O[params.data.SupervisorID].SupervisorName;
                    return '<div><div class="supervisor-name">' + name + '</div><div class="supervisor-email">' + email + '</div></div>';
                },
                valueGetter: function (params) {
                    return supervisorsService.getSupervisors().O[params.data.SupervisorID].SupervisorName;
                }, filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab']
            },
            {
                field: "FDFormID",
                headerName: "Form",
                minWidth: 370,
                valueGetter: function (params) {
                    var forms = formsService.getTopFormDescriptions().O;
                    return forms[params.data.FDFormID + ''].FormName;
                }, filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab']
            },
            {
                field: "Target",
                headerName: "Target",
                minWidth: 190,
                filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab'],
                cellRenderer: targetCellRenderer
            },
            {
                field: "Frequency",
                headerName: "Frequency",
                minWidth: 100,
                valueGetter: frequencyValueGetter, filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab']
            },
            {
                colId: "actions",
                suppressMenu: true,
                headerName: "",
                minWidth: 50,
                cellRenderer: function (params) {
                    return '<span class="flex-actions" ng-click="targets.actionsMenu('
                        + params.data.ID
                        + ', ' + params.rowIndex + ', $event);"><img class="jump-icon" src="images/icon-more-dots.svg" /></span>';
                }
            }
        ];

        vm.rowContextId = 0;
        vm.editHistory = false;
        vm.actionsMenu = (targetId, rowIndex, $event) => {
            $event.stopPropagation()
            vm.rowContextId = targetId

            if (rowIndex !== null) {
                vm.rowContextIndex = rowIndex
                vm.editHistory = false
            }
            else
                vm.editHistory = true

            var y = $event.pageY
            var x = 70
            var actions = $('#targetsActionDropdown')
            actions.addClass('show')
            actions.css({ top: y, right: x })
        };

        vm.getEditObject = () => {
            for (var i = 0; i < vm.targets.length; i++) {
                if (vm.targets[i].ID === vm.rowContextId) {
                    return vm.targets[i];
                }
            }
            return null;
        };

        vm.getHistoryEditObject = function (targetId, parentId) {
            for (var i = 0; i < vm.targets.length; i++) {
                if (vm.targets[i].ID === parentId) {
                    for (var j = 0; j < vm.targets[i].History.Targets.length; j++) {
                        if (vm.targets[i].History.Targets[j].ID === targetId) {
                            return vm.targets[i].History.Targets[j];
                        }
                    }
                }
            }
            return null;
        };

        vm.removeTarget = function () {
            for (var i = 0; i < vm.targets.length; i++) {
                if (vm.targets[i].ID === vm.rowContextId) {
                    vm.targets.splice(i, 1);
                    return;
                }
            }
        };

        vm.expandedRowIndex = null;

        vm.history = function () {
            if (vm.expandedRowIndex !== null)
                vm.options.api.rowModel.rowsToDisplay[vm.expandedRowIndex].setExpanded(false);

            vm.expandedRowIndex = vm.rowContextIndex;
            vm.options.api.rowModel.rowsToDisplay[vm.rowContextIndex].setExpanded(true);
        };

        vm.closeHistory = function () {
            vm.options.api.rowModel.rowsToDisplay[vm.expandedRowIndex].setExpanded(false);
            vm.expandedRowIndex = null;
        };

        vm.options.onFilterChanged = function () {
            if (vm.expandedRowIndex !== null)
                vm.closeHistory();
        }
        
        vm.options.onSortChanged = function () {
            vm.options.api.forEachNode(node => {
                node.expanded = false;
            });
            vm.options.api.onGroupExpandedOrCollapsed();
            vm.expandedRowIndex = null;
            vm.options.api.redrawRows();
        }

        vm.add = function () {
            console.log('add');
            vm.mode = 'Add';
            editTargetRef = null;
            vm.editModel.clear();

            vm.openModal('targetAddEditModal');
        };

        vm.edit = function () {
            console.log('edit ' + vm.rowContextId);
            vm.mode = 'Edit';
            editTargetRef = vm.getEditObject();
            vm.editModel.copy(editTargetRef);

            vm.openModal('targetAddEditModal');
        };

        vm.startEditHistory = function () {
            vm.mode = 'Edit';
            editTargetRef = vm.getHistoryEditObject(jsvm.rowContextId, jsvm.parentId);
            vm.editModel.copy(editTargetRef);

            vm.openModal('targetAddEditModal');
        };

        vm.delete = function () {
            console.log('delete ' + vm.rowContextId);
            vm.mode = 'Delete';
            editTargetRef = vm.getEditObject();
            vm.editModel.copy(editTargetRef);
            vm.modalElements = {
                title: "Delete Entry", //"Delete Entry"
                message: `<div><p>${translateTag(8864)}</p></div>`, //"Are you sure you want to delete this entry?"
                buttons: `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Delete Entry">{{vm.componentTranslateLabels(2276)}}</button>`
            } 
            document.getElementById('confirmcallingform').innerHTML = 'TARGETCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        };

        $scope.$on("TARGETCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.confirmDelete()
            }
        })

        vm.confirmDelete = function () {
            targetsService.deleteTarget(vm.editModel.ID)
                .then(function () {
                    toastr.success('Delete succeeded!');
                    modalService.Close('confirmModal')

                    vm.removeTarget();

                    vm.options.api.setRowData(vm.targets);
                    vm.options.api.redrawRows();
                }, function () {
                    toastr.error('Delete failed.');
                });
        };

        vm.save = function () {
            if (vm.mode === 'Add') {
                targetsService.newTarget(vm.editModel)
                    .then(function (response) {
                        refreshTargets();

                        toastr.success('Add succeeded!');
                        modalService.Close('targetAddEditModal')
                    },
                        function () {
                            toastr.error('Add failed.');
                        });
            } else if (vm.mode === 'Edit') {
                targetsService.updateTarget(vm.editModel.ID, vm.editModel)
                    .then(function () {
                        refreshTargets();

                        toastr.success('Save complete!');
                        modalService.Close('targetAddEditModal')
                    }, function () {
                        toastr.error('Save failed.');
                    });
            }
        };

        vm.options.columnDefs = targetColumns;
        vm.options.headerHeight = 70;
        vm.options.alignedGrids = [];
        vm.options.enableColResize = true;
        
        var detailColumnDefs = [
            { headerName: 'SupervisorBlank', field: 'SupervisorID', cellClass: 'history-cell-blank', cellRenderer: function () { return ''; }, minWidth: 270 },
            { headerName: 'FormBlank', field: 'FDFormID', cellClass: 'history-cell-blank right', cellRenderer: function () { return ''; }, minWidth: 370 },
            { headerName: 'Target', field: 'Target', cellClass: 'history-cell', minWidth: 190, cellRenderer: targetCellRenderer },
            { headerName: 'Frequency', field: 'Frequency', cellClass: 'history-cell', valueGetter: frequencyValueGetter, minWidth: 100 },
            {
                colId: 'actions', headerName: '', field: 'switchCode', cellClass: 'history-cell', minWidth: 50, cellRenderer: function (params) {
                    return '<span class="flex-actions" onclick="actionsMenu('
                        + params.data.ID
                        + ', ' + params.data.ParentID + ', event);"><img class="jump-icon" src="images/icon-more-dots.svg" /></span>';
                }
            }
        ];

        function TargetHistoryPanelCellRenderer() { }

        TargetHistoryPanelCellRenderer.prototype.init = function (params) {
            // trick to convert string of html into dom object
            var eTemp = document.createElement('div');
            eTemp.innerHTML = this.getTemplate(params);
            this.eGui = eTemp.firstElementChild;

            this.setupDetailGrid(params.data);
            this.consumeMouseWheelOnDetailGrid();
        };

        TargetHistoryPanelCellRenderer.prototype.setupDetailGrid = function (targetHistory) {

            this.detailGridOptions = {
                headerHeight: 0,
                suppressMenu: true,
                suppressHorizontalScroll: true,
                enableSorting: false,
                enableFilter: false,
                enableColResize: false,
                rowData: targetHistory.Targets,
                toolPanelSuppressSideButtons: true,
                rowHeight: 60,
                localeText: sofvie_agGrid_languages[`${selectedLanguage}`],
                columnDefs: detailColumnDefs,
                onGridReady: function (params) {
                    setTimeout(function () { vm.options.api.sizeColumnsToFit(); }, 0);
                },
                defaultColDef: {
                    editable: false
                },
                enableRangeSelection: false
            };
            vm.options.alignedGrids.push(this.detailGridOptions);
            var eDetailGrid = this.eGui.querySelector('.full-width-grid');
            new agGrid.Grid(eDetailGrid, this.detailGridOptions);
        };

        TargetHistoryPanelCellRenderer.prototype.getTemplate = function (params) {

            var parentRecord = params.node.parent.data;

            var template =
                '<div class="full-width-panel">' +
                '  <div class="past-target-header">Past Targets</div>' +
                '  <div class="full-width-grid"></div>' +
                '</div>';

            return template;
        };

        TargetHistoryPanelCellRenderer.prototype.getGui = function () {
            return this.eGui;
        };

        TargetHistoryPanelCellRenderer.prototype.destroy = function () {
            vm.options.alignedGrids.length = 0;
            this.detailGridOptions.api.destroy();
        };

        // if we don't do this, then the mouse wheel will be picked up by the main
        // grid and scroll the main grid and not this component. this ensures that
        // the wheel move is only picked up by the text field
        TargetHistoryPanelCellRenderer.prototype.consumeMouseWheelOnDetailGrid = function () {
            var eDetailGrid = this.eGui.querySelector('.full-width-grid');

            var mouseWheelListener = function (event) {
                event.stopPropagation();
            };

            // event is 'mousewheel' for IE9, Chrome, Safari, Opera
            eDetailGrid.addEventListener('mousewheel', mouseWheelListener);
            // event is 'DOMMouseScroll' Firefox
            eDetailGrid.addEventListener('DOMMouseScroll', mouseWheelListener);
        };

        vm.options.isFullWidthCell = function (rowNode) {
            return rowNode.level === 1;
        };

        vm.options.fullWidthCellRenderer = TargetHistoryPanelCellRenderer;

        vm.options.getRowHeight = function (params) {
            var rowIsHistoryRow = params.node.level === 1;
            return rowIsHistoryRow ? 240 : 60;
        };

        vm.options.getNodeChildDetails = function (target) {
            if (target.History && target.History.Targets && target.History.Targets.length > 0) {
                return {
                    group: true,
                    // the key is used by the default group cellRenderer
                    key: target.ID,
                    // provide ag-Grid with the children of this group
                    children: [target.History]
                };
            } else {
                return null;
            }
        };

        vm.openModal = function (id) {
            if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                $scope.$apply();

            modalService.Open(id);
        };
        
        vm.closeModal = function (id) {
            modalService.Close(id);
        };

      vm.targetTabClick = function () {
        vm.options.api.sizeColumnsToFit();
        vm.options.api.resetRowHeights();
        console.log("resize target")
      };
        employeesService.getMeP(true).then(function (userData) {
            for (var i = 0; i < userData.Roles.length; i++) {
                if (userData.Roles[i] === 'CanManageTargets') {
                    vm.canManageTargets = true;
                }
            }
        });

        $(window).click(function (e) {
            $('.dropdown-content').removeClass('show');
        });

        function refreshTargets() {
          targetsService.getTargets().then(function (data) {
                vm.targets = data;
                let model = vm.options.api.getFilterModel()
                vm.options.api.setRowData(vm.targets);
                vm.options.api.redrawRows();
                vm.options.api.setFilterModel(model)
                $timeout(function () {
                    vm.options.api.sizeColumnsToFit();
                }, 500);
            });
        }

        $q.all([listService.getFrequenciesP(), supervisorsService.getSupervisorsP(), formsService.getTopFormDescriptionsP()])
            .then(function () {
              var forms = formsService.getTopFormDescriptions();
                vm.forms.length = 0;
              for (var i = 0; i < forms.A.length; i++) {
                if (forms.A[i].FormName != 'HAZARD REPORT' && forms.A[i].FormName != 'POSITIVE IDENTIFICATION')
                    vm.forms.push(forms.A[i]);
                }
                var supervisors = supervisorsService.getSupervisors();
                vm.supervisors.length = 0;
                for (var j = 0; j < supervisors.A.length; j++) {
                    vm.supervisors.push(supervisors.A[j]);
              }
              sortSupervisors()
                var frequencies = listService.getFrequencies();
                vm.frequencies.length = 0;
                for (var k = 0; k < frequencies.A.length; k++) {
                    vm.frequencies.push(frequencies.A[k]);
                }

                refreshTargets();
            });

      function sortSupervisors() {
        let newArr = []
        let fullArr = []
        vm.supervisors.forEach((supervisor) => {
          newArr.push(supervisor.SupervisorName.toUpperCase());
        });
        newArr.sort()
        newArr.forEach((data) => {
          vm.supervisors.forEach((supervisor) => {
            if (data === supervisor.SupervisorName.toUpperCase()) {
              fullArr.push(supervisor)
            }
          })
        })
        vm.supervisors = fullArr;

      }
        $scope.$on('menu-width-changed', function () {
            $timeout(function () {
                vm.options.api.sizeColumnsToFit();
            }, 500);
        });

        $(window).on('resize', function () {
            $timeout(function () {
                vm.options.api.sizeColumnsToFit();
            });
        });

        $scope.$on("$destroy", function () {
            $(window).off('resize');
        });
    }]);