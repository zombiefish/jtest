﻿angular
    .module('safeToDo')
    .service('targetsService', ['$http',
        function ($http) {
            let supervisorTargets = []
            let supervisorTargetData = []
            let companyTargets = []
            let companyTargetData = []
            function fixDate(dt) {
                if (!dt)
                    return dt;

                var dtParts = dt.split('-')
                if (dtParts[1].length < 2)
                    dtParts[1] = '0' + dtParts[1]
                if (dtParts[2].length < 2)
                    dtParts[2] = '0' + dtParts[2]

                return dtParts[0] + '-' + dtParts[1] + '-' + dtParts[2]
            }

            return {
                newTarget: (target) => {
                    target.EffectiveOn = fixDate(target.EffectiveOn)
                    target.EffectiveEnd = fixDate(target.EffectiveEnd)
                    return $http.post('/api/SupervisorTargets', target)
                },
                updateTarget: (targetId, target) => {
                    target.EffectiveOn = fixDate(target.EffectiveOn)
                    target.EffectiveEnd = fixDate(target.EffectiveEnd)
                    return $http.put('/api/SupervisorTargets/' + targetId, target)
                },
                deleteTarget: (targetId) => {
                    return $http.delete('/api/SupervisorTargets/' + targetId)
                },
                getRevisionDates: (FDFormID, SupervisorID, FrequencyID) => {
                    let body = {FDFormID, SupervisorID, FrequencyID}
                    return $http.post('/api/SupervisorTargets/revisiondates', body)
                    .then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load revision dates.', errorParams)
                    });
                }
            };
        }
    ]);