﻿angular.module('safeToDo').config(config)
    .service('profileService', ['$http',
        function ($http) {
          let recognitionData = []
          let personProfile = []
          let employeeData = {}
          let employeeJobs = []
          let distributionList = []
          let distributionGroupList = []
          let allEmployeeProfile = []
          let fullEmployeeProfile = []
          let allTrainingEmployeeProfile = []
          let disciplines = []
          let training = []
          let reviews = []
          let certs = []
          let allSupervisorProfile = []
          let allHumanResourceList = []
          let user_visbility = ''
          let filteredEmployees = []
          let filteredApproverEmployees = []
          let filteredSupervisors = []
          let filteredDistribution = []
          let activePersonList = []
          let rmmApproverEmployees = []         

          return {
            

            getPersonProfile: () => {
              return $http.get(`${__env.apiUrl}/api/userprofile/get-person-profile/${selectedLanguage}/`).then((params)=> {
                params.data.error = '';
                personProfile = params.data[0];
              }, (errParams) => {
                  var errorObj = {};
                  if (errParams.status == 404) {
                      errorObj.error = 'User not found - Contact a system administrator';
                  }
                  return errorObj;
              })
            },
            checkUserPermission: (permission) => {
              return $http.post(`${__env.apiUrl}/api/user/is-user-has-permission/`,{"permissionCodeName":permission}).then((response)=> {
                 return response.data[0]
              }, (errParams) => {
                  var errorObj = {};
                  if (errParams.status == 404) {
                      errorObj.error = 'Permission not found - Contact a system administrator';
                  }
                  return errorObj;
              });
            },

            checkUserPermissionsList: () => {
              return $http.get(`${__env.apiUrl}/api/sofvie-auth/user-role-and-permissions/`).then((response)=> {
                 return response.data
              }, (errorParams) => {
                if(errorParams.status === 403 && errorParams.data.detail)
                {
                  toastr.error(errorParams.data.detail)
                }
                var errorObj = {};
                return errorObj;
              });
            },            

            getAllEmployeeProfile: () =>{
              return $http.get(`${__env.apiUrl}/api/employee/get-employee-list-uv/all/`).then((params)=> {
                params.data.error = '';
                user_visbility = params.data.emp_data_visibility;
                allEmployeeProfile = params.data.Employee_list;                
              }, (errParams) => {
                  var errorObj = {};
                  if (errParams.status == 404) {
                      errorObj.error = 'User not found - Contact a system administrator';
                  }
                  return errorObj;
              });
            },            

            filterEmployeeListonJob: (job_id) => {              
              filteredEmployees = filterEmployees(allEmployeeProfile, user_visbility, job_id, 'job')
            },

            readFilterEmployeeListonJob: function () {
              return filteredEmployees;
            },

            filterEmployeeListonSite: (site_id) => {
              filteredEmployees = filterEmployees(allEmployeeProfile, user_visbility, site_id, 'site')
            },

            getRmmApproverEmployees: (module) =>{
              return $http.get(`${__env.apiUrl}/api/employee/get-employee-list-uv/${module}/`).then((params)=> {
                params.data.error = '';
                user_visbility = params.data.emp_data_visibility;
                rmmApproverEmployees = params.data.Employee_list;                
              }, (errParams) => {
                  var errorObj = {};
                  if (errParams.status == 404) {
                      errorObj.error = 'User not found - Contact a system administrator';
                  }
                  return errorObj;
              });
            },

            filterRmmApproverEmployeesOnSite: (site_id) => {
              filteredApproverEmployees = filterEmployees(rmmApproverEmployees, user_visbility, site_id, 'site')
            },
            readFilterApproversList: function () {
              return filteredApproverEmployees;
            },

            filterRmmApproverEmployeesOnJob: (job_id) => {              
              filteredApproverEmployees = filterEmployees(rmmApproverEmployees, user_visbility, job_id, 'job')              
            },           
            
            getFullEmployeeProfile: (mode='allEmployee') =>{
              return $http.get(`${__env.apiUrl}/api/employee/get-full-employee-list-profile/${mode}/`).then((params)=> {
                params.data.error = '';
                fullEmployeeProfile = params.data;
              }, (errParams) => {
                  var errorObj = {};
                  if (errParams.status == 404) {
                      errorObj.error = 'User not found - Contact a system administrator';
                  }
                  return errorObj;
              });
            },

            getAllTrainingEmployeeProfile: () =>{
              return $http.get(`${__env.apiUrl}/api/employee/get-employee-list-uv/training/`).then((params)=> {
                params.data.error = '';
                allTrainingEmployeeProfile = params.data.Employee_list;
              }, (errParams) => {
                  var errorObj = {};
                  if (errParams.status == 404) {
                      errorObj.error = 'User not found - Contact a system administrator';
                  }
                  return errorObj;
              });
            },  

            getAllSupervisorProfile: () =>{
              return $http.get(`${__env.apiUrl}/api/employee/get-employee-list-uv/supervisor/`).then((params)=> {
                params.data.error = '';
                user_visbility = params.data.emp_data_visibility
                allSupervisorProfile = params.data.Employee_list;                
              }, (errParams) => {
                  var errorObj = {};
                  if (errParams.status == 404) {
                      errorObj.error = 'User not found - Contact a system administrator';
                  }
                  return errorObj;
              });
            },

            filterSupervisorListonJob: (job_id) => {   
              filteredSupervisors = filterEmployees(allSupervisorProfile, user_visbility, job_id, 'job')              
            },
            readFilterSupervisorListonJob: function () {
              return filteredSupervisors;
            },           

            getAllHumanResourceList: () => {
              return $http.get(`${__env.apiUrl}/api/employee/get-employee-list-uv/human-resource/`).then((response) => {
                allHumanResourceList = response.data.Employee_list;                
              }, (errorParams) => {
                console.log('Failed to load lHumanResource List', errorParams)
              })
            },

            getDistributionList: () => {
              return $http.get(`${__env.apiUrl}/api/edl/get-distribution-list/`).then((response) => {
                user_visbility = response.data.emp_data_visibility
                distributionList = response.data.Employee_list
                for (i in distributionList){
                  if(distributionList[i]["email"] && distributionList[i]["email"] !== ''){
                    if (distributionList[i]["email"].includes(',')){
                      distributionGroupList.push(distributionList[i])
                    }
                 }
                }
              }, (errorParams) => {
                console.log('Failed to load Distribution List', errorParams)
              })
            },
            filterDistributionListonJob: (job_id) => {              
              filteredDistribution = filterEmployees(distributionList, user_visbility, job_id, 'job')              
            },
            readFilterDistributionListonJob: function () {
              return filteredDistribution;
            },

            getTrainingRecords: () => {
              return $http.get(`${__env.apiUrl}/api/userprofile/get-employee-training-record/${selectedLanguage}/`).then(function (response) {
                training = response.data
              }, function (errorParams) {
                console.log('Failed to load Training Records')
                console.log(errorParams)
              });
            },

            getCertificationRecords: () => {
              return $http.get(`${__env.apiUrl}/api/userprofile/get-employee-certification-record/${selectedLanguage}/`).then(function (response) {
                certs = response.data;
              }, function (errorParams) {
                console.log('Failed to load Training Records')
                console.log(errorParams);
              });
            },

            getReviewRecords: () => {
              return $http.get(`${__env.apiUrl}/api/userprofile/get-user-review/`).then(function (response) {
                reviews = response.data
              }, function (errorParams) {
                console.log('Failed to load Training Records')
                console.log(errorParams);
              });
            },     
            
            getDisciplineRecords: () => {
              return $http.get(`${__env.apiUrl}/api/userprofile/get-user-discipline/`).then(function (response) {
                disciplines = response.data
              }, function (errorParams) {
                console.log('Failed to load Discplines Records')
                console.log(errorParams);
              });
            },              

            getRecognitionRecords: (person) => {
              return $http.get(`${__env.apiUrl}/api/userprofile/get-employee-positive-recognition/`).then(function (response) {
                recognitionData = response.data
              }, function (errorParams) {
                console.log('Failed to load Recognition Records')
                console.log(errorParams);
              });
            },

            getActivePersonList: () => {
              return $http.get(`${__env.apiUrl}/api/employee/get-active-person-list/`).then(function (response) {
                activePersonList = response.data
              }, function (errorParams) {
                console.log('Failed to load Active Person List')
                console.log(errorParams);
              });
            },

            readReviews: () => {
              return reviews
            },

            readDisciplines: () => {
              return disciplines
            },

            readTrainingRecords: function () {
                return training;
            },

            readDistributionList: function () {
              return distributionList;
            },

            readdistributionGroupList: function () {
              return distributionGroupList;
            },

            readCertificationRecords: function () {
              return certs;
            },

            readPositiveRecognition: function () {
                return recognitionData;
            },

            readEmployeeJobs: function () {
                return employeeJobs
            },

            readPersonProfile: () =>{
                return personProfile
            },

            readAllEmployeeProfile: () =>{
                return allEmployeeProfile
            },

            readFullEmployeeProfile: () =>{
              return fullEmployeeProfile
          },            

            readAllTrainingEmployeeProfile: () =>{
              return allTrainingEmployeeProfile
            },

            readAllSupervisorProfile: () =>{
              return allSupervisorProfile
            },
           
            readAllHumanResourceProfile: () =>{
              return allHumanResourceList
            },
            readActivePersonList: () =>{
              return activePersonList
            }
          }

          
        }])

        var __version_number = __env.version;

  config.$inject = ['$httpProvider'];
  function config($httpProvider) {
    //Inject using the $injector
    $httpProvider.interceptors.push(['$injector', function($injector){
      return {
        request: function(config) {
          //Get access by injecting an instance of the desired module/service
          let $window = $injector.get('$window')
          let token2 = JSON.parse($window.localStorage.getItem('token'))
          if (token2) {
            checkToken()
            config.headers['Authorization'] = `Bearer ${token2.access}`
          }
          else {
            $window.location.href = '/login.html'
          }
          return config
        }
      }
    }])
  }

  function filterEmployees(emp_list, user_visbility, filter_id, mode){
    let temp_emps = []
    if(filter_id === undefined || filter_id === null){
      return temp_emps
    }
    if(user_visbility === 'all'){
      temp_emps = emp_list
    }
    else{
      emp_list.forEach(employee => {                  
        if(employee.emp_data_visibility === 'all'){
          temp_emps.push(employee)
        }
        else{
          if(mode === 'job'){
            if(employee.employee_jobs.split(',').includes(filter_id.toString())){
              temp_emps.push(employee)
            }          
          }
          else if(mode === 'site'){
            if(employee.employee_sites.split(',').includes(filter_id.toString())){
              temp_emps.push(employee)
            }
          }      
        }                  
      })                
    }
    return temp_emps
  }

  function checkToken() {
    let checkToken = JSON.parse(window.localStorage.getItem('token'))
      if (parseJwt(checkToken.access).exp < Date.now() / 1000) {
        window.location.href = '/login.html'
      }
  }

  function parseJwt(token) {
    let base64Url = token.split(".")[1]
    return JSON.parse(window.atob(base64Url))
  }
