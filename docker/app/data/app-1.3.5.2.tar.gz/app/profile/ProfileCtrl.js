﻿function getTextWidth(text, font) {
    // re-use canvas object for better performance
    var canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement("canvas"));
    var context = canvas.getContext("2d");
    context.font = font;
    var metrics = context.measureText(text);
    return metrics.width;
}

angular
    .module('safeToDo')
    .controller('ProfileCtrl', ['$scope', '$timeout', '$q', '$window', '$sce', 'gridService', 'employeesService', 'profileService', 'toolboxService', 'modalService', 'positiveIdService', 'formsService', '$rootScope',
      function ($scope, $timeout, $q, $window, $sce, gridService, employeesService, profileService, toolboxService, modalService, positiveIdService, formsService, $rootScope) {
        var vm = this
        
        vm.trainingOptions = gridService.getCommonOptions();
        vm.disciplinesOptions = gridService.getCommonOptions();
        vm.reviewsOptions = gridService.getCommonOptions();
        vm.certOptions = gridService.getCommonOptions();
        vm.employeeName = ``
        vm.employeeEmail = ''
        vm.employeeAddress = ''
        vm.employeeId = ''
        vm.employeeRole = ''
        vm.employeeSite = ''
        vm.formNames = [];
        vm.personProfile = [];
        vm.viewpointID = '';
        vm.trainingTable = [];
        vm.positiveRecognition = []
        vm.positiveIDReportUrl = `positive_recognition`
        vm.disciplineType = 248310
        vm.currentpid = -1        
        
        let token = JSON.parse($window.localStorage.getItem('token'))

        parseJwt(token.access)
        function parseJwt (token) {
          var base64Url = token.split('.')[1];
          var base64 = base64Url.replace('-', '+').replace('_', '/');
          return JSON.parse($window.atob(base64));
        }

        vm.openReport = (submission_id, formDescriptionId) => {
          formsService.getFormDescription(formDescriptionId).then((response)=>{                                                            
            vm.singleServeReportUrl = response[0].ReportURL            
            lang_number = localStorage.getItem('lang_id')
            vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.singleServeReportUrl}/${submission_id}?lang=${lang_number}`)
            $window.open(vm.reportURL, "_blank")
            
        })
        }


        let today = new Date()

        function pad(num, size) {
        var s = "000000000" + num;
        return s.substr(s.length - size);
        }

        var trainingColumns = [
            {
              field: "training_code",
              headerName: "  ",
              minWidth: 100,
              maxWidth: 150,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: (params) => {                
                return `<span class="clip">${params.value}</span>`
              }
            },
            {
              field: "training_name",
              headerName: " ",
              minWidth: 300,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: (params) => {                
                return `<span class="clip">${params.value}</span>`
              }
            },
            {
              field: "etr_training_status_lable",
              headerName: " ",
              minWidth: 120,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: (params) => {                
                return `<span class="clip">${params.value}</span>`
              }
            },
            {
              field: "etr_completion_date",
              headerName: " ",
              minWidth: 120,
              maxWidth: 160,
              filter: 'agSetColumnFilter',
              cellRenderer: function (params) {
                if(!params.value){
                  return translateTag(1381)
                }
                if(params.data.rld_option == 3 || params.data.rld_option == 4 || params.data.rld_option == 5)
                {
                  return("")
                }
                return params.value.substring(0,10)
              },
              menuTabs: ['filterMenuTab']
            },
            {
              field: "etr_expiry_date",
              headerName: " ",
              minWidth: 100,
              maxWidth: 150,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: function (params) {
                if(!params.value){
                  return translateTag(1381)
                }
                if(params.data.rld_option == 3 || params.data.rld_option == 4 || params.data.rld_option == 5)
                {
                  return("")
                }
                return params.value.substring(0,10)
              },
              cellClassRules: {
                'text-danger': function (params) {
                  let expiryDate = params.data.etr_expiry_date
                  let today = new Date()
                  today = today.toISOString().slice(0, 10)
                  if(expiryDate < today)
                    return true
                },
                'text-warning': 
                  function (params) { 
                    let warningDate = new Date(params.data.etr_expiry_date)
                    warningDate.setMonth(warningDate.getMonth() -1)
                    warningDate = warningDate.toISOString().slice(0, 10)
                    let expiryDate = params.data.etr_expiry_date
                    let today = new Date()
                    today = today.toISOString().slice(0, 10)
                    if(warningDate<today && today < expiryDate)
                      return true
                  }
              },
            },
            {
              field: "CertPeriod",
              headerName: "Validity",
              maxWidth: 100,
              sort: 'desc',
              hide: true,
              cellRenderer: function (params) {
                // cert = getExpiryDate(params)
                // if (params.data.CertPeriod === 0) return 'n/a'
                // if (cert <= params.data.CompleteDate.substring(0, 10)) {
                //   return "Yes"
                // } else
                // { return "z" }
              },
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab']
            }
        ];

        var certColumns = [
          {
            field: "training_code",
            headerName: " ",
            minWidth: 100,
            maxWidth: 150,
            //    resizable: true,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: (params) => {                
              return `<span class="clip">${params.value}</span>`
            }
          },
          {
            field: "training_name",
            headerName: " ",
            minWidth: 300,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: (params) => {                
              return `<span class="clip">${params.value}</span>`
            }
          },
          {
            field: "etr_training_status_lable",
            headerName: " ",
            minWidth: 120,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: (params) => {                
              return `<span class="clip">${params.value}</span>`
            }
          },
          {
            field: "etr_completion_date",
            headerName: " ",
            minWidth: 120,
            maxWidth: 160,
            filter: 'agSetColumnFilter',
            cellRenderer: function (params) {
              if(!params.value){
                return translateTag(1381)
              }
              if(params.data.rld_option == 3 || params.data.rld_option == 4 || params.data.rld_option == 5)
              {
                return("")
              }
              return params.value.substring(0, 10)
            },
            menuTabs: ['filterMenuTab']
          },
          {
            field: "etr_expiry_date",
            headerName: " ",
            minWidth: 100,
            maxWidth: 150,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: function (params) {
              if(!params.value){
                return translateTag(1381)
              }
              if(params.data.rld_option == 3 || params.data.rld_option == 4 || params.data.rld_option == 5)
              {
                return("")
              }
              return params.value.substring(0, 10)
            },
            cellClassRules: {
              //  'abc': function (params) { return params.data.CompleteDate.substring(0,10) === getExpiryDate(params) },
         
              'text-danger': function (params) {
                let expiryDate = params.data.etr_expiry_date
                let today = new Date()
                today = today.toISOString().slice(0, 10)
                if(expiryDate < today)
                  return true
              },
              'text-warning': 
                function (params) { 
                  let warningDate = new Date(params.data.etr_expiry_date)
                  warningDate.setMonth(warningDate.getMonth() -1)
                  warningDate = warningDate.toISOString().slice(0, 10)
                  let expiryDate = params.data.etr_expiry_date
                  let today = new Date()
                  today = today.toISOString().slice(0, 10)
                  if(warningDate<today && today < expiryDate)
                    return true
                }
              
            },
          }
        ];

        var disciplinesColumns = [
                {
                  field: "submitted_by",
                  headerName: " ",
                  maxWidth: 150,
                  minwidth: 100,
                  filter: 'agSetColumnFilter',
                  menuTabs: ['filterMenuTab'],
                  cellRenderer: (params) => {    
                    return `<span class="clip">${params.value}</span>`
                  }
                },
                {
                  field: "FormSubmissionDate",
                  headerName: " ",
                  minWidth: 100,
                  maxWidth: 150,
                  filter: 'agSetColumnFilter',
                  menuTabs: ['filterMenuTab'],
                  cellRenderer: function (params) {
                    return params.value.substring(0, 10)
                  },
                },
                {
                    field: "discipline_violation",
                    headerName: " ",
                    minWidth: 200,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {                
                      return `<span class="clip">${params.value}</span>`
                    }
                },
                {
                    field: "event_type",
                    headerName: " ",
                    minWidth: 80,
                    maxWidth: 150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: "tippyCellRenderer",
                    cellClass: "clip"
                }
            ];

        var reviewsColumns = [
            {
              field: "submitted_by",
              headerName: " ",
              minWidth: 100,
              maxWidth: 150,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: (params) => {                
                return `<span class="clip">${params.value}</span>`
              }
            },
            {
              field: "FormSubmissionDate",
              headerName: " ",
              minWidth: 100,
              maxWidth: 150,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: (params) => {
                return params.value.substring(0,10)
              }
            },
            {
              field: "goals_1",
              minWidth: 200,
              headerName: " ",
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: (params) => {
                return `<span class="clip">${params.data.goals_1}  -  ${params.data.goals_2}   -   ${params.data.goals_3}</span>`
              }
          },
          {
            field: "goals_2",
            minWidth: 80,
            maxWidth: 150,
            headerName: " ",
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: (params) => {
              if(params.data.FormID === 339913)
                return translateTag(3818) //60 Day
              return translateTag(2190) //Annual
            }
          }
            ];

        vm.trainingOptions.columnDefs = trainingColumns;

        vm.certOptions.columnDefs = certColumns;


        let defWidth = 10
        vm.trainingOptions.onColumnResized = (params) => {
          if (params.column.colDef.field === 'Description') {
            defWidth = params.column.actualWidth
          }
        }

        vm.disciplinesOptions.onColumnResized = function (params) {
            if (params.column.colDef.field === 'discipline_violation') {
              defWidth = params.column.actualWidth
            }
          }

        vm.disciplinesOptions.columnDefs = disciplinesColumns

        vm.reviewsOptions.columnDefs = reviewsColumns

        profileService.getPersonProfile().then(() => {
          vm.personProfile = profileService.readPersonProfile()
          vm.currentUserId = vm.personProfile.per_id
        })

        function refreshFilters() {
            $q.all([
              profileService.getPersonProfile(),
            ])   
              .then(function () {
                vm.personProfile = profileService.readPersonProfile()
                $q.all([
                  profileService.getTrainingRecords(),
                  profileService.getCertificationRecords(),
                  profileService.getReviewRecords(),
                  profileService.getRecognitionRecords(),
                  profileService.getDisciplineRecords()
                ]).then(()=>{
                  vm.positiveRecognition = profileService.readPositiveRecognition()
                  // Training Grid Data
                   if (vm.trainingOptions.api) {
                    translateAgGridHeader(vm.trainingOptions)
                    vm.trainingOptions.paginationPageSize = 10                    
                    let modelTraining = vm.trainingOptions.api.getFilterModel() 
                    vm.trainingOptions.api.setRowData(profileService.readTrainingRecords())  
                    vm.trainingOptions.api.redrawRows()
                    vm.trainingOptions.api.sizeColumnsToFit()
                    vm.trainingOptions.api.sizeColumnsToFit()//Have to do this twice for some reason to get it to work
                    vm.trainingOptions.api.setFilterModel(modelTraining)
                  }
                  // Certifications Grid Data
                  if (vm.certOptions.api) {
                    translateAgGridHeader(vm.certOptions)
                    vm.certOptions.paginationPageSize = 10             
                    let modelCert = vm.certOptions.api.getFilterModel() 
                    vm.certOptions.api.setRowData(profileService.readCertificationRecords());     

                    vm.certOptions.api.redrawRows();
                    vm.certOptions.api.sizeColumnsToFit();
                    vm.certOptions.api.sizeColumnsToFit();//Have to do this twice for some reason to get it to work
                    vm.certOptions.api.setFilterModel(modelCert)
                  }
                  // Reviews Grid Data
                  if (vm.reviewsOptions.api) {
                    translateAgGridHeader(vm.reviewsOptions)
                    vm.reviewsOptions.paginationPageSize = 10             
                    let modelReviews = vm.reviewsOptions.api.getFilterModel() 
                    vm.reviewsOptions.api.setRowData(profileService.readReviews());
                    vm.reviewsOptions.api.redrawRows();
                    vm.reviewsOptions.api.sizeColumnsToFit();
                    vm.reviewsOptions.api.sizeColumnsToFit();//Have to do this twice for some reason to get it to work
                    vm.reviewsOptions.api.setFilterModel(modelReviews)
                  }

                  let discipline_type 
                  
                  // Disciplines Grid Data
                  if(profileService.readDisciplines().length){
                    discipline_type=profileService.readDisciplines()[0].FormID
                  }
                  if(discipline_type==372428){
                    vm.discipline_type=372428
                  }
                  if (vm.disciplinesOptions.api) {
                    translateAgGridHeader(vm.disciplinesOptions)
                    vm.disciplinesOptions.paginationPageSize = 10             
                    let modelDisciplines = vm.disciplinesOptions.api.getFilterModel() 
                    vm.disciplinesOptions.api.setRowData(preparedisciplinesGridData());
                    vm.disciplinesOptions.api.redrawRows();
                    vm.disciplinesOptions.api.sizeColumnsToFit();
                    vm.disciplinesOptions.api.sizeColumnsToFit();//Have to do this twice for some reason to get it to work
                    vm.disciplinesOptions.api.setFilterModel(modelDisciplines)
                  }
                })
            })
        }

        //Function to prepare Ag-Grid data with string values
        function preparedisciplinesGridData() {
          let disciplinesGridData = JSON.parse(JSON.stringify(profileService.readDisciplines()).replaceAll("'","&#39"))
          disciplinesGridData.forEach((rec) =>{
              rec.exceptionFields = ['JobNumber','Site','SiteLevel','Supervisor','employee_name']
          })
          return disciplinesGridData
      }

   
        vm.initializeTable= () => {
          vm.positiveRecognitionTable = $('#positiveRecognitionList').DataTable({
            "pagingType": "numbers",
            "lengthChange": false,
            "searching": false,
            "pageLength": 5,
            "language": {
							"info": `_START_ ${translateTag(1130)} _END_ ${translateTag(1131)} _TOTAL_`
					  }
          })
          $('.dataTables_length').addClass('bs-select')
        }

        angular.element(document).ready(() => {
          refreshFilters()
        })
        
        $scope.$on("$destroy", () => {
            $(window).off('resize')
            $(window).off('click')
            $('.sites').off('resize')
        })

        $('.home').scroll((e) => {
            $('.filter-dropdown').removeClass('show');
        })

        $(window).click(function (e) {
            $('.filter-dropdown').removeClass('show');
        });

        $('.sites').scroll(function (e) {
            $('.filter-dropdown').removeClass('show');
        });

        /*
            widget grids
        */
        $scope.$on('menu-width-changed', function () {
            $timeout(function () {
                vm.actionsOptions.api.sizeColumnsToFit();
                vm.submissionsOptions.api.sizeColumnsToFit();
            }, 500);

            $timeout(function () {
                Highcharts.charts.forEach(function (chart) {
                    chart.reflow();
                });
            }, 100);
        });

        $(window).on('resize', function () {
          $timeout(function () {
            vm.certOptions.api.sizeColumnsToFit();
            vm.trainingOptions.api.sizeColumnsToFit();
            vm.disciplinesOptions.api.sizeColumnsToFit();
            vm.reviewsOptions.api.sizeColumnsToFit();
             //   vm.actionsOptions.api.sizeColumnsToFit();
              //  vm.submissionsOptions.api.sizeColumnsToFit();
            });

            $timeout(function () {
            //    Highcharts.charts.forEach(function (chart) {
              //      chart.reflow();
             //   });
            });
        });

        vm.hideDropdowns = function () {
            $('.filter-dropdown').removeClass('show');
            };

        vm.assigned_toggle = 'assigned to me';
        vm.status_toggle = 'All';
        vm.compliance_toggle = 'My Forms';
        vm.action_type_toggle = 'Compliance';
        vm.showHelp = function (id) {
                vm.openModal(id);
            };


      // modal methods:
      vm.openModal = (id) => {modalService.Open(id)}

      // Positive Recognition Section
      vm.reloadPIDTable = () => {
        profileService.getRecognitionRecords().then(() => {
          vm.newvalue = profileService.readPositiveRecognition()}).then((newvalue) =>{     
          // direct assignment doesn't work with DataTable because it thinks that you are reinitializing it
          for (let i = 0; i < vm.positiveRecognition.length; i++) {
            Object.assign(vm.positiveRecognition[i], vm.newvalue[i])
          }
        })
      }

      vm.addPIDLike = (data, $event) => {
        if (data.liked_by_per) {    // remove like
          // keep current parameters
          vm.currentlikeid = data.mylikeid
          vm.comment_data = data
          // confirm remove
          vm.modalElements = {
            title: translateLabels(3828),  //"Remove Like?"
            message: `<div><p>${translateTag(3827)}</p></div>`, //"Your record of liking this Positive Recognition will be erased. Continue?"
            buttons: `<button class='btn btn-primary btn-rounded' ng-click="vm.return('button1')" note="Remove">{{vm.componentTranslateLabels(2434)}}</button>`//"Remove"
          }
          document.getElementById('confirmcallingform').innerHTML = 'RETURNPROFILECOMMENTDELETE' 
          $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        } else {
          // add like
          positiveIdService.addLike(data.pid_id)
                            .then((data) => {
                                if (data.status===201) {
                                  vm.reloadPIDTable()
                                }
                            })
        }
      }
      
      $scope.$on("RETURNPROFILECOMMENTDELETE", (event,result) => {
        if (result=='button1') {
            vm.confirmLikeDelete(vm.currentlikeid, vm.comment_data)
        }
        modalService.Close("confirmModal")
      })

      vm.confirmLikeDelete = (likeid, currentdata) => {   
        positiveIdService.deleteLike(likeid)
            .then(function (success) {
                if (success) {                                
                    currentdata.mylikeid = 0
                    currentdata['likeCount'] = Math.max(currentdata['likeCount'] - 1, 0)
                    currentdata['liked_by_per'] = false
                    // replace cell values
                    // vm.currentpidElement.parentElement.nextElementSibling.innerText = currentdata['number of likes']
                }
            })          
      }

      vm.viewPIDLikes = (data) => {
        if (!data["likeCount"]) {
            return
        }

        vm.currentLikeHistory = [];
        positiveIdService.getLikesByHeader(data.pid_id, vm.currentUserId)
                .then((data) => {
                data.map((rec)=>{
                  rec.name = rec.SigningName
                  rec.reviewed_date=rec.SigningTimestamp
                  rec.pos=rec.prl_position
                  delete rec.SigningName
                  delete rec.SigningTimestamp
                  delete rec.prl_position
                })
                vm.currentLikeHistory = data
                $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentLikeHistory)
            })
        //show history
      }

      vm.addComments=(data) =>{
        vm.comment_data = data  
        vm.commentValue = ''
        vm.modalTitle = translateLabels(8921)  //Add comment
        document.getElementById('savetomemory').innerHTML = "false"
        document.getElementById('parentform').innerHTML = 11
        document.getElementById('callingform').innerHTML= 'CLOSEPROFILEIMAGECOMMENTSMODAL'
        document.getElementById('comment_id').innerHTML = '' // comment id    
        document.getElementById('imageid').innerText = data.pid_id
        document.getElementById('allowmultiple').innerHTML = 1 //allow multiple
        $rootScope.$broadcast("RECIEVEROFCOMMENTS", vm.commentValue, vm.modalTitle)
      }

      $scope.$on("CLOSEPROFILEIMAGECOMMENTSMODAL", (event, data) => {
        if(data.com_comment){
          vm.comment_data.commentCount++
          vm.comment_data.comment_by_per=true 
        }
        vm.commentValue=''
      })

      vm.viewPIDComments = (positive) => {
        vm.comment_data = positive
        document.getElementById('pidlistcommentcallingform').innerHTML= 'PROFILECALLPIDLISTCOMMENTMODAL' 
        $rootScope.$broadcast("CALLPIDLISTCOMMENTMODAL", positive.pid_id, vm.currentUserId);  
      }
      
      $scope.$on("PROFILECALLPIDLISTCOMMENTMODAL", (event, data) => {
        vm.comment_data.commentCount=data.commentCounts
        vm.comment_data.comment_by_per=data.comment_by_per
      })

}]);