angular.module('safeToDo').service('lockoutTagoutService', ['$http',
    function ($http) {
          return {
            getAllLOTO: () => {
                return $http.get(`${__env.apiUrl}/api/loto/get-all-procedure/`).then((response) => {     
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to get get all LOTO Procedures', errorParams)
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    }
                })
            },
            copyLOTOProcedure: (payload) => {
                return $http.get(`${__env.apiUrl}/api/loto/copy-loto/${payload.lth_id}/`, payload).then((response) => {  
                    return response   
                }, (errorParams) =>{
                    console.log("ERROR ",errorParams)
                })
            },
            reviseLOTOProcedure: (payload) => {
                return $http.get(`${__env.apiUrl}/api/loto/revision-loto/${payload.lth_id}/`, payload).then((response) => {  
                    return response   
                }, (errorParams) =>{
                    console.log("ERROR ",errorParams)
                })
            },
            archiveLOTO: (payload) => {
                return $http.post(`${__env.apiUrl}/api/loto/archive-loto-procedure/`, payload).then((response) => {  
                    return response   
                }, (errorParams) =>{
                    console.log("ERROR ",errorParams)
                })
            },
            reviewProcedure : (payload) => {
                return $http.post(`${__env.apiUrl}/api/loto/create-review/${payload}/`, payload).then((response) => {
                    return response.data
                }, (errorParams) => {
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    } 
                })
            },
            archiveSubmittedLOTOProcedure: (payload) => {
                return $http.post(`${__env.apiUrl}/api/loto/archive-loto-submission/`, payload).then((response) => {
                    return response.data
                }, (errorParams) => {
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    } 
                })
            },
        }
    }
]);