﻿angular.module('safeToDo') 
.controller('lockout-tagoutCtrl', ['$scope', 'menuService', 'gridService','$q','lockoutTagoutService','$compile','exportCSV','$rootScope','modalService','employeesService','documentLockService','profileService',
    function ($scope, menuService, gridService,$q, lockoutTagoutService,$compile,exportCSV,$rootScope,modalService,employeesService, documentLockService,profileService) {
        let vm = this
        vm.topSearch = ''
        vm.actionDisabled = true
        vm.lotoOptions =  gridService.getCommonOptions()
        vm.canManageLOTO = true

        menuService.getPagePermissions().then((data) => {
            vm.permissions = data         
            vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
            vm.canManageLOTO = vm.permissions.includes('Can Manage LOTO') ? true : false
            vm.canViewLOTO = vm.permissions.includes('Can View LOTO') ? true : false
        })

        vm.lotoOptions = gridService.getCommonOptions()

        $scope.$emit('STARTSPINNER', translateTag(9362))
        employeesService.getPersonProfile().then((data)=> {
            vm.per_id = data.per_id
        }) 

        vm.getReviewedButton = (params) => {
            let count
            let reviewed
            let buttons
            count =''
            if(params.data.reviewer_count > 0){
                count = params.data.reviewer_count
            }
            reviewed = ''
            for(rev of params.data.reviewers){
                if(rev.crw_per == vm.per_id){
                    reviewed = 'text-success'
                }
            }
            buttons = `<span class="pointer text-left" ng-click="loto.review(data)"><i class="far fa-file-alt fa-lg  ${reviewed}"  note="Review" title="{{menu.translateLabels(1188)}}"></i></span><span class='ml-2' style="cursor:pointer" ng-click="loto.viewAcknowledgeHistory(data)"> ${count}</span>`
            return buttons
        }

        //Set parget target Ag-Grid colum values/settings
        let lotoColumns = [
            {
                headerName: '',
                field: 'dummyCheckbox',
                maxWidth: 60,
                minWidth: 60,
                checkboxSelection: true,
                suppressMenu: true,
                suppressSorting: true,
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
            },
            {
                field: "review",
                headerName: " ",
                maxWidth: 150,
                minWidth: 150,
                suppressMenu: true,
                suppressSorting: true,
                cellRenderer: (params) => {
                    let buttons = ``
                    switch (params.data.lth_is_approved){
                        case 1: // review 
                            buttons += `<span  class="pointer text-left" ng-click="loto.view(${params.data.lth_id})"><i class="fas fa-lock pr-2 text-primary"  title="{{menu.translateLabels(1188)}}"></i></span>`
                            break;
                        case 2: // active
                            buttons += vm.getReviewedButton(params) 
                            break;
                        case 3: // draft
                            buttons +=`<span class="pointer text-left" ng-show="${vm.canManageLOTO}" ng-click="loto.edit(${params.data.lth_id})"><i class="fa fa-pen"  note="Edit" title="{{menu.translateLabels(1194)}}"></i></span><i ng-show="${!params.data.dlo_status}" class="fas fa-ban fa-stack-1x text-danger" style="left:-57px;position: absolute;" title="${params.data.dlo_person}  ${translateTag(3423)}"></i></span>`
                            break;
                        case 4: // expired
                            buttons += vm.getReviewedButton(params)
                            break
                    }
                    return buttons
                },           
            },
            {
                field: "lth_title",
                headerName: " ",
                minWidth:200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                showRowGroup: true,
                cellRenderer:'tippyCellRenderer',
                sort: 'asc',
            },            
            {
                field: "lth_equipment_type",
                headerName: " ",
                minWidth:200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                showRowGroup: true,
                cellRenderer:'tippyCellRenderer',
                sort: 'asc',
            }, 
            {
                field: "lth_equipment_number",
                headerName: " ",
                minWidth:200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                showRowGroup: true,
                cellRenderer:'tippyCellRenderer',
                sort: 'asc',
                
            },
            {
                field: "lth_document_version_number",
                headerName: " ",
                minWidth:200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                showRowGroup: true,
                cellRenderer:'tippyCellRenderer',
                sort: 'asc',
                valueGetter: function(params) {
                    return params.data.lth_document_number 

                }
            },
            {
                field: "lth_status",
                headerName: " ",
                minWidth:200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                showRowGroup: true,
                cellRenderer:'tippyCellRenderer',
                sort: 'asc',
            },   
            {
                field: "lth_created_date",
                headerName: " ",
                minWidth:200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                showRowGroup: true,
                cellRenderer:(params) =>{
                    return moment(params.data.lth_created_date).format('YYYY-MM-DD')
                },
                sort: 'asc',
            }, 
            {
                field: "lth_modified_by",
                headerName: " ",
                minWidth:200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                showRowGroup: true,
                cellRenderer:'tippyCellRenderer',
                sort: 'asc',
            },
        ]
        
        vm.lotoOptions.columnDefs = lotoColumns  
        vm.lotoOptions.defaultColDef = {
            cellStyle : (params) =>{
                if(params.data.lth_status === translateTag(3557) || params.data.lth_status === translateTag(3494) || params.data.lth_status === translateTag(1188)){
                    return { "cursor": "pointer !important"}
                }
            } 
        }
        vm.viewAcknowledgeHistory =(params) => {
            if(!params.reviewer_count > 0){

                return
            }

            vm.currentAcknowledgeHistory = []
            params.reviewers.forEach((rev) => {
                let acknowledgment = {
                    name: rev.reviewer_name,
                    pos: rev.position_name,
                    reviewed_date: rev.crw_created_date
                }
                vm.currentAcknowledgeHistory.push(acknowledgment)
            })
            $rootScope.$broadcast("CALLHISTORYMODAL", vm.currentAcknowledgeHistory, translateLabels(1297)) //"Reviews"
        } 


        vm.refresh = () => {
            $q.all([
                lockoutTagoutService.getAllLOTO(),
            ]).then(data =>{
  
                tippyData = vm.prepareTippyData(data[0])
                if(vm.lotoOptions.api){
                    translateAgGridHeader(vm.lotoOptions)
                    vm.lotoOptions.api.setRowData(tippyData)
                    vm.lotoOptions.api.sizeColumnsToFit()
                    vm.actionDisabled = true

                }

                $scope.$emit('STOPSPINNER')
            })
        }

        vm.prepareTippyData = (data) => {
            let rtrn = []

            for(item of data){

                if(item.dlo_enable.length !== 0){
                    item.dlo_status = item.dlo_enable[0].dlo_enable
                    item.dlo_person = item.dlo_enable[0].dlo_person
                } else {
                    item.dlo_status = true
                    item.dlo_person = null
                }

                let tippy = {
                    "lth_id" : item.lth_id,
                    "lth_title" : item.lth_title,
                    "lth_equipment_number": item.lth_equipment_number,
                    "lth_document_number":item.lth_document_number,
                    "lth_created_date":moment(item.lth_created_date).format('YYYY-MM-DD'),
                    "lth_modified_by": item.lth_modified_by,
                    "lth_status": item.lth_status,
                    "chd_site":item.chd_site,
                    "chd_job":item.chd_job,
                    "chd_level": item.chd_level,
                    "lth_equipment_type":item.lth_equipment_type,
                    "exceptionFields": ["reviewer_count","lth_document_version_number",'reviewers', "lth_is_approved",'dlo_enable', 'dlo_person', 'dlo_status'],
                    "lth_is_approved": item.lth_is_approved,
                    "reviewer_count" : item.reviewer_count,
                    "reviewers": item.reviewers,
                    "dlo_status": item.dlo_status,
                    "dlo_person": item.dlo_person
                    
                }
                rtrn.push(tippy)
            }
            return rtrn
        }

        vm.lotoOptions.onCellClicked  = (params) => {
            if(params.column.colDef.field != "review"){
                if(params.data.lth_status == translateTag(3557) ){ // active
                    vm.openModal('view',params.data.lth_id)
                } else if( params.data.lth_status == translateTag(3494)){ // expired
                    vm.openModal('viewexpired',params.data.lth_id)
                }
            }
        }

        vm.lotoOptions.onGridReady= () => {
            vm.refresh()
        }

        vm.procedure = () => {
            vm.openModal('loto')
        }
        $scope.$on('CLOSELOTOPROCEDURE', (event, result) => {

            vm.refresh()
        })

        vm.copy = (id) =>{

            if(vm.lotoOptions.api.getSelectedRows().length == 1){
                $scope.$emit('STARTSPINNER', translateTag(9362))
                // get the data from the selected row
                let current = vm.lotoOptions.api.getSelectedRows()[0]
                
                let payload = {
                    'lth_id':current.lth_id,
                    'mode':'copy'
                }
                lockoutTagoutService.copyLOTOProcedure(payload).then((response) => {
                    if(response){
                        toastr.success(translateTag(2395)) // Success
                        vm.refresh()
                    }
                })
            } else {
                toastr.warning(translateTag(3861)) // Document not selected
            }
        }

        vm.revision = () =>{

            if(vm.lotoOptions.api.getSelectedRows().length == 1){
                // get the data from the selected row
                let current = vm.lotoOptions.api.getSelectedRows()[0]
                if(current.lth_is_approved == 1 || current.lth_is_approved == 2 || current.lth_is_approved == 4){
                    $scope.$emit('STARTSPINNER', translateTag(9362)) // Loading Lockout / Tagout. Please wait.
                    let payload = {
                        'lth_id':current.lth_id,
                        'mode':'revision'
                    }
                    lockoutTagoutService.reviseLOTOProcedure(payload).then((response) => {
                        if(response){
                            toastr.success(translateTag(2395)) // Success
                            vm.refresh()
                        }
                    })
                } else (
                    toastr.warning(translateTag(3865)) // Cannot create revision of a Draft
                )
            } else {
                toastr.warning(translateTag(3861)) // Document not selected
            }
        }

        vm.equipment = () => {
            vm.openModal('equipment')
        }

        vm.review = (data) =>{
            let id = data.lth_id
            let reviewed = false
            let reviewers = data.reviewers
            for(review of reviewers){

                if(review.crw_per == vm.per_id){
                    reviewed = true
                }
            }
            if(!reviewed){
                $scope.$emit("STARTSPINNER", translateTag(9362)) // Loading Lockout / Tagout. Please wait.
                lockoutTagoutService.reviewProcedure(id).then((response) => {
                    vm.refresh()
                })
            } else {
                toastr.warning(translateTag(3869)) // You have already reviewed this assessment
            }
        }

        vm.edit = (id) => {
            vm.openModal('loto',id)
        }

        vm.csv = () => {
            let rows = JSON.parse(JSON.stringify(vm.lotoOptions.api.getSelectedRows()))
            for(let c=0;c<rows.length;c++){
                delete rows[c].reviewers
                delete rows[c].lth_is_approved
            }
            exportCSV.export_csv(rows, translateTag(9295))
        }

        vm.archiveAgGridConfirmationModal = () => {
            vm.archiveCount = vm.lotoOptions.api.getSelectedRows().length

            let tag 
            if(vm.archiveCount == 1){
                tag = 9471 // You are about to archive this procedure. Undoing this will require IT support. Are you sure?
            } else if(vm.archiveCount > 1){
                tag = 9470 // You are about to archive these procedures. Undoing this will require IT support. Are you sure?
            } else {
                
                return
            }
            vm.modalElements = {
                title: translateLabels(3580),  //"You are about to archive"
                message: `<div><p>${translateTag(tag)}</p></div>`, //
                buttons: 
                    `<button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" notes="Cancel" >{{vm.componentTranslateLabels(1257)}}</button>        
                     <button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" notes="Yes">{{vm.componentTranslateLabels(1379)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'LOTOCALLCONFIRMMODALDELETE' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("LOTOCALLCONFIRMMODALDELETE", (event,result) => {
            if (result=='button1') {
                $scope.$emit("STARTSPINNER", translateTag(9362))
                vm.archive()
            }
        })

        //Function to update grid when search is changed
        vm.topSearchChanged = () =>{
            vm.lotoOptions.api.setQuickFilter(vm.topSearch)
        }


        vm.archive = () => {

            let rows = vm.lotoOptions.api.getSelectedRows()
            let ids = []
            for(let i=0;i<rows.length;i++){
                let item = rows[i]

                ids.push({"lth_id":item.lth_id})
            }

            lockoutTagoutService.archiveLOTO(ids).then(() => {
                modalService.Close('confirmModal')
                vm.refresh()
            })

        }
        
        vm.view = (id) => {
            vm.openModal('view', id)

        }
        vm.openModal = (mode, id=null, doclockid) => {
            //add code to open either the equipment modal or the new/edit LOTO modal.
            $scope.$emit('STARTSPINNER', translateTag(9362))
            if(mode ==='equipment'){
                //open equipment modal.
                $('#equipmentModal').html($compile(`<equipment-modal></equipment-modal>`)($scope))
            } else if(mode==='loto' && id==null){
                //open loto modal.

                $('#lotoModal').html($compile(`<loto-modal mode='new' lotoid="${id} doclocklotolockid="null"></loto-modal>`)($scope))
            } else if(mode==='loto' && id > 0){ // edit mode.

                vm.documentDetails = {}
                vm.documentDetails.dlo_document_id = id
                vm.documentDetails.dlo_dlt_id = 9 //Loto
                 $q.all([
                    documentLockService.docLock(vm.documentDetails)
                ]).then((response) => {
                    vm.dlo_id = response[0].dlo_id
                    vm.docLockStatus = response[0].status
                    vm.docLockMessage = response[0].message
                    vm.docLockTime = response[0].time
                    if (!vm.docLockStatus){
                        throwToastr('warning',vm.docLockMessage,2000)
                        $scope.$emit('STOPSPINNER')
                    }   
                }).then(()=> {
                    if(vm.docLockStatus === true){
                        let doclockid = vm.dlo_id
                        $('#lotoModal').html($compile(   
                        `<loto-modal mode='edit' lotoid="${id}" doclocklotolockid="${doclockid}"></loto-modal>"`)($scope))
                    } 
                })
            } else if(mode==='view'){ // read only mode.
                $('#lotoModal').html($compile(`<loto-modal mode='view' lotoid="${id}"></loto-modal>`)($scope))
            } else if(mode==='viewexpired'){  // read only mode
                $('#lotoModal').html($compile(`<loto-modal mode='viewexpired' lotoid="${id}"></loto-modal>`)($scope))
            }


        }
        $scope.$on("REFRESHLOTO", (evt, data) => {
            vm.refresh()
           })

        vm.lotoOptions.onSelectionChanged = () => {                
            let selectedRows = vm.lotoOptions.api.getSelectedRows()
            vm.actionDisabled = (selectedRows.length == 0)
            $scope.$apply()
        }
    }
])