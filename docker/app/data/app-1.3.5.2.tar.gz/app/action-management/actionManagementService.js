angular
    .module('safeToDo')
    .service('actionManagementService', ['$http',
        function ($http) {
            let hazardsList = []
            let generalActionsList = []

            return {
                getHazardsList: (filter) => {
                    return $http.post(`${__env.apiUrl}/api/ha/get-hazard-actions/`, filter).then((response) => {
                        hazardsList = response.data                        
                    }, (errorParams) => {
                        hazardsList = [{message: 'error happened'}]
                        console.log('Failed to load Hazard Form Records', errorParams)
                    })
                },
                getHazardActionSingle: (id) => {
                    return $http.post(`${__env.apiUrl}/api/ha/get-detail-single-hazard-action/`, id).then((response) => {
                        return response.data.OutPut
                    }, (errorParams) => {
                        console.log('Failed to load Hazard Form Records', errorParams)
                    })
                }, 

                getGeneralActionsList: (filter) => {
                    return $http.post(`${__env.apiUrl}/api/ga/get-general-actions/`, filter).then((response) => {
                        generalActionsList = response.data
                    }, (errorParams) => {
                        generalActionsList = [{message: 'error happened'}]
                        console.log('Failed to load General Form Records', errorParams)
                    })
                }, 

                getGeneralActionSingle: (id) => {
                    return $http.post(`${__env.apiUrl}/api/ga/get-detail-single-general-action/`, id).then((response) => {
                        return response.data.OutPut
                    }, (errorParams) => {
                        console.log('Failed to load General Form Records', errorParams)
                    })
                }, 

                createGeneralAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/ga/create-general-action/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create general action', errorParams)
                    })
                }, 
                updateGeneralAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/ga/update-general-action/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to update general action', errorParams)
                    })
                }, 

                createHazardAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/ha/create-hazard-action/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create hazard action', errorParams)
                    })
                },

                updateHazardAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/ha/update-hazard-action/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to update hazard action', errorParams)
                    })
                },

                addGeneralActionAttachments: (payload) => {                    
                    return $http.post(`${__env.apiUrl}/api/ga/add-general-action-attachments/`, payload,{
                        // this cancels AngularJS normal serialization of request
                        transformRequest: angular.identity,
                        // this lets browser set `Content-Type: multipart/form-data` 
                        // header and proper data boundary
                        headers: {'Content-Type': undefined}}).then((response) =>{                            
                        return response
                    }, (errorParams) => {
                        console.log('Failed to add general action attachment', errorParams)
                    })
                },
                removeGeneralActionAttachment: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/ga/remove-general-action-attachment/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to remove general action attachment', errorParams)
                    })
                }, 

                addHazardActionAttachments: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/ha/add-hazard-action-attachments/`, payload,{
                        // this cancels AngularJS normal serialization of request
                        transformRequest: angular.identity,
                        // this lets browser set `Content-Type: multipart/form-data` 
                        // header and proper data boundary
                        headers: {'Content-Type': undefined}}).then((response) =>{
                        return response
                    }, (errorParams) => {
                        console.log('Failed to add hazard attachment', errorParams)
                    })
                },
                removeHazardActionAttachment: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/ha/remove-hazard-action-attachment/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to remove hazard action attachment', errorParams)
                    })
                }, 

                closeGeneralAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/ga/close-general-action/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to close general action', errorParams)
                    })
                },

                archiveHazardAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/ha/archive-hazard-actions/`, payload).then((response) => {
                        return true
                    }, (errorParams) => {
                        console.log('Failed to archive hazard action', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })                    
                },

                archiveGeneralAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/ga/archive-general-action/`, payload).then((response) => {
                        return true                        
                    }, (errorParams) => {
                        console.log('Failed to archive general action', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })                    
                },

                reopenActionItem: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/ha/reopen-action-item/`, payload).then((response) => {
                        return response                        
                    }, (errorParams) => {
                        console.log('Failed to reopen action item', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })                    
                },

                // Returns list 
                readHazardsList: () => {
                    return hazardsList
                },
                
                readGeneralActionsList: () => {
                    return generalActionsList
                },

                addCanCloseActionPermission: (actions, type, canCloseAllActions, userId) => {
                    for (let index = 0; index < actions.length; index++) {
                        let element = actions[index]
                        element['can_close_action'] = canCloseAllActions
                        if(!canCloseAllActions){
                            if(type=='hazard' && (element.sha_created_by_per_id == userId || element.action_by_who_per.includes(userId))){
                                element['can_close_action'] = true
                            }
                            else if(type=='general' && (element.sga_created_by_per == userId || element.sga_action_by_who_per.includes(userId))){
                                element['can_close_action'] = true
                            }else{
                                element['can_close_action'] = false
                            }
                        }                    
                    }    
                    return actions
                },
            }
        }
    ])