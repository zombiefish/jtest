angular
    .module('safeToDo')
    .controller('actionManagementCtrl', ['$compile', '$scope', '$rootScope', '$timeout', '$q', '$window', '$sce', 'gridService', 'select2Service',
      'actionManagementService', 'listService', 'modalService', 'profileService', 'menuService', 'exportCSV', 'employeesService',
      function ($compile, $scope, $rootScope, $timeout, $q, $window, $sce, gridService, select2Service, actionManagementService, listService, modalService, profileService, menuService, exportCSV, employeesService) {
        let vm = this
        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        vm.hazardSearch = ''
        vm.generalSearch = ''
        vm.actionMode = 'new'
        vm.actionID = 1000
        vm.hazardID = 2000
        vm.archiveCount = 0
        vm.archiveAction = ''
        vm.employeeList = []
        vm.fullEmployeeList = []
        vm.actionTypeList = []     
        vm.actionHazardTypeList = []
        vm.identificationList = []
        vm.potentialLossList = []
        vm.hazardTypeList = []
        vm.generalData= []
        vm.followup = {}
        vm.followup.modalId = 'hapFollowupComponent'
        vm.generalFollowup = {}
        vm.generalEditData = {}
        vm.hazardEditData = {}
        vm.actionHazardDisabled = true
        vm.actionGeneralDisabled = true
        vm.canArchiveSubmissions = false
        vm.loadMessage = translateTag(3621)  //"Loading actions. Please wait."
        vm.loadDefault = false
        vm.mobileDisabled = true
        
        // default settings for Filters
        vm.hazardFilterType = "Assigned To Me"
        vm.hazardFilterValue = translateTag(1062) // translated value.
        vm.hazardStatusFilter = "Incomplete"
        vm.generalFilterType = "Assigned To Me"
        vm.generalFilterValue = translateTag(1062) // translated value.
        vm.generalStatusFilter = "Incomplete"

        //Get permissions for the user
        menuService.getPagePermissions().then((data) => {
            vm.permissions = data
            vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
            vm.canManageActionItems = vm.permissions.includes('Can Manage Action Items') ? true : false
            vm.canReopenActionItems = vm.permissions.includes('Can Re-open Action Items') ? true : false
            vm.canCloseAllActions = vm.permissions.includes('Can Close All Actions') ? true : false
        })

        $rootScope.$on("MOBILE-LOADED", (event,result) => {
            vm.mobileDisabled = false
            $scope.$digest()
        })

        //Functions to update filter
        vm.changeHazardFilter = (filter) => {
            vm.hazardFilterType = filter
            refreshData('Haz')
        }
        vm.changeGeneralFilter = (filter) => {
            vm.generalFilterType = filter

            refreshData('Gen')
        } 

        //Function to clear status filter
        vm.clearStatus = (action) => {
            if(action === 'hazard')
            {
                vm.hazardStatusFilter = "All"
                refreshData('Haz')
            }
            else if (action === 'general')
            {
                vm.generalStatusFilter = "All"
                refreshData('Gen')
            }            
        }
        
        //Functions to export toCSV file
        vm.exportHazardCSV = () => {
            let rows = JSON.parse(JSON.stringify(vm.hazardOptions.api.getSelectedRows()))
            exportCSV.export_csv([...rows], 'HazardActionsData')
        }
        vm.exportGeneralCSV = () => {
            let rows = JSON.parse(JSON.stringify(vm.generalOptions.api.getSelectedRows()))
            exportCSV.export_csv(rows, translateTag(1324))
        }

        //Function to open archive confirmation Modal
        vm.archiveConfirmationModal = (action) => {
            if(action === 'hazard')
            {
                vm.archiveAction = action
                vm.archiveCount = vm.hazardOptions.api.getSelectedRows().length
            }
            else if (action === 'general')
            {
                vm.archiveAction = action
                vm.archiveCount = vm.generalOptions.api.getSelectedRows().length
            }
            
            vm.modalElements = {
                title: translateLabels(1355),  //"Archive Action?"
                message: `<div><p>${translateTag(3580)} ${vm.archiveCount} ${translateTag(3582)}</p></div>`, //"submissions. Undoing this will require IT support. Are you sure?"
                buttons: 
                    `<button ng-show=${vm.archiveAction === 'hazard'} class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" notes="Yes">{{vm.componentTranslateLabels(1379)}}</button>
                    <button ng-show=${vm.archiveAction === 'general'} class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button2')" notes="Yes">{{vm.componentTranslateLabels(1379)}}</button>
                    <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" notes="Cancel" >{{vm.componentTranslateLabels(1257)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'ACTIONCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        // function to re open action - hap or gap
        vm.reopenActionItem = (actionType) =>{
            if(actionType === 'hazard')
            {
                vm.archiveAction = actionType
                vm.archiveCount = vm.hazardOptions.api.getSelectedRows().length
            }
            else if (actionType === 'general')
            {
                vm.archiveAction = actionType
                vm.archiveCount = vm.generalOptions.api.getSelectedRows().length
            }
            
            vm.modalElements = {
                title: translateLabels(9239),  // re open action
                message: `<div><p>${translateTag(1409)}</p></div>`,
                buttons: 
                    `<button ng-show=${vm.archiveAction === 'hazard'} class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" notes="Yes">{{vm.componentTranslateLabels(1379)}}</button>
                    <button ng-show=${vm.archiveAction === 'general'} class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button2')" notes="Yes">{{vm.componentTranslateLabels(1379)}}</button>
                    <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" notes="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'ACTIONREOPENCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("ACTIONREOPENCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.hazardReopenAction()
            }
            else if (result=='button2') {
                vm.generalReopenAction()
            }
        })

        $scope.$on("ACTIONCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.hazardArchive()
            }
            else if (result=='button2') {
                vm.generalArchive()
            }
        })

        $scope.$on("CALLWARNINGMODAL", (event,result) => {
            if (result=='closeWarningModal') {
                modalService.Close('confirmModal')
                refreshData('Haz')
            }
        })

        //Functions to reopen hazard action
        vm.hazardReopenAction = () => { 
            let rows = vm.hazardOptions.api.getSelectedRows()
            if (rows.length > 0) {
                let payload = {}
                let action_ids = []
                let incompleteFlag = 0
                rows.forEach((row)=>{
                    action_ids.push(row.id)
                })
                payload = {'action_ids': action_ids, 'action_type':"HAP"}
                actionManagementService.reopenActionItem(payload).then((response) => {
                    if (response.status === 200) {
                        if(response.data.notReopenedArray.length > 0){
                            vm.modalElements = {
                                title: translateLabels(2182),  // Warning
                                message: `<div><p>${translateTag(9267)}</p></div>`,
                                buttons: `<button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('closeWarningModal')" notes="Ok" >{{vm.componentTranslateLabels(1405)}}</button>`
                            }
                            document.getElementById('confirmcallingform').innerHTML = 'CALLWARNINGMODAL'
                            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
                        }
                        else
                            refreshData('Haz')
                    }
                })
            }
            else    
                toastr.error(translateTag(3816)) // "No Rows Selected")
                modalService.Close('confirmModal')
        }

         //Functions to reopen general action
         vm.generalReopenAction = () => {
            let rows = vm.generalOptions.api.getSelectedRows()
            if (rows.length > 0) {
                let payload = {}
                let action_ids = []
                rows.forEach((row)=>{
                    action_ids.push(row.sga_id)
                })
                payload = {'action_ids': action_ids, 'action_type':"GAP"}
                actionManagementService.reopenActionItem(payload).then((response) => {
                    if (response.status === 200) {
                        refreshData('Gen')
                    }
                })
            }
            else    
                toastr.error(translateTag(3816)) // "No Rows Selected")
                modalService.Close('confirmModal')
        }



        //Functions to archive the actions
        vm.hazardArchive = () => {
            let rows = vm.hazardOptions.api.getSelectedRows()
            if (rows.length > 0) {
                let payload = []
                rows.forEach((row)=>{
                    payload.push({submission_hap_id: row.id})
                })
                actionManagementService.archiveHazardAction(payload).then((r) => {
                    if (r === true) {
                        refreshData('Haz')
                    }
                })
            }
            else    
                toastr.error(translateTag(3816)) // "No Rows Selected")
            modalService.Close('confirmModal')
        }   

        vm.generalArchive = () => {
            let rows = vm.generalOptions.api.getSelectedRows()
             if (rows.length > 0) {
                 let payload = []
                 rows.forEach((row)=>{
                     payload.push({sga_id: row.sga_id})
                 })

                actionManagementService.archiveGeneralAction(payload).then((r) => {
                    if (r === true) {
                        refreshData('Gen')
                    }
                })
            }
            else    
                toastr.error(translateTag(3816)) // "No Rows Selected")
                modalService.Close('confirmModal')
        }

        //#region Functions to convert ID's to Names
        function getEmployeeName(value) {
            let name = value
            vm.fullEmployeeList.forEach((emp)=>{
                if(emp.per_id == value) {
                    name = emp.per_full_name
                }
          })
          return name
        }

        function getEmployeeNames(values  ) {
            if(values == null){
                return ''
            } else {
                let by_who = []
                let len = values.length
                for(let l = 0;l < len; l++) {
                    by_who.push(getEmployeeName(values[l]))
                }
                return by_who.join("; ")
            }
         }
 
         function getEmployeeID(value) {
            let nameID = value
            vm.fullEmployeeList.forEach((emp)=>{
            if(emp.per_full_name == value) {
                nameID = emp.per_id
            }
          })
          return nameID
        }
        function getActionTypeName(value) {
            let name = value
            vm.actionTypeList.forEach((at)=>{
            if(at.rld_id == value) {
              name = at.rld_name
            }
          })
          return name
        }
        function getActionTypeID(value) {
            let nameID = value
            vm.actionTypeList.forEach((at)=>{
            if(at.rld_name == value) {
              nameID = at.rld_id
            }
          })
          return nameID
        }
        function getActionHazardTypeName(value) {
            let name = value
            vm.actionHazardTypeList.forEach((at)=>{
            if(at.rld_id == value) {
              name = at.rld_name
            }
          })
          return name
        }
        function getIdentificationName(value) {
            let name = value
            vm.identificationList.forEach((at)=>{
            if(at.rld_id == value) {
              name = at.rld_name
            }
          })
          return name
        }
        function getPotentialLossName(value) {
            let name = value
            vm.potentialLossList.forEach((at)=>{
            if(at.rld_id == value) {
              name = at.rld_name
            }
          })
          return name
        }
        function getHazardTypeName(value) {
            let name = value
            vm.hazardTypeList.forEach((at)=>{
            if(at.rld_id == value) {
              name = at.rld_name
            }
          })
          return name
        }
        //#endregion

        vm.hazardOptions = gridService.getCommonOptions()
        vm.generalOptions = gridService.getCommonOptions()
        
        //Functions to disable action button if no rows are selected
        vm.hazardOptions.onSelectionChanged = () => {
            let selectedRows = vm.hazardOptions.api.getSelectedRows()
            vm.actionHazardDisabled = selectedRows.length == 0
            $scope.$apply()
        }
        vm.generalOptions.onSelectionChanged = () => {
            let selectedRows = vm.generalOptions.api.getSelectedRows()
            vm.actionGeneralDisabled = selectedRows.length == 0
            $scope.$apply()
        }

        //Functions to update grid with search filter
        vm.hazardSearchChanged = () =>{
            vm.hazardOptions.api.setQuickFilter(vm.hazardSearch)
        }
        vm.generalSearchChanged = () =>{
            vm.generalOptions.api.setQuickFilter(vm.generalSearch)
        }

        //Function to launch the reports
        vm.viewReports = (e, id=null, report) => {
            if(!e.ctrlKey){
                lang_number = localStorage.getItem('lang_id')
                vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${report}/${id}?lang=${lang_number}`)
                $window.open(vm.reportURL, "_blank")
            }
        }

        //Set Ag-Grid column settings for hazards
        let hazardColumns = [
            {
                headerName: '',
                field: 'dummyCheckbox',
                maxWidth: 50,
                minWidth: 50,
                checkboxSelection: true,
                suppressMenu: true,
                suppressSorting: true,
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
            },
            {
                field: 'id',
                hide: true,
            },
            {
                field: '',
                headerName: " ",
                hide: true,
                minWidth: 200,
                maxWidth: 200,
                valueGetter: function (params) {
                    let status = params.data.action_status
                    let actionDate = new Date(params.data.action_by_when)
                    let currentDate = new Date()                    
                    if (actionDate < currentDate && status.toUpperCase() === translateTag(5028).toUpperCase() /* 'Incomplete'*/ )
                        return '1_Overdue'
                    else if (status === translateTag(5028).toUpperCase() /*'Incomplete' */)
                        return '2_Due'
                    else
                        return '3_Complete'
                }
            },
            {
                field: "review",
                headerName: " ",
                width: 80,
                suppressSizeToFit: true,
                suppressMenu: true,
                suppressSorting: true,
                cellRenderer: function (params) {      
                    // if action COMPLETE, no edit button - add invisble class
                    let invisible = params.data.action_status === translateTag(2045) ? 'invisible' : ''
                    return `<span class="pointer ${invisible}" ng-if="actions.canManageActionItems" ng-click="actions.openModal('hazardActionModal','edit', ${params.data.id})"><i class="fa fa-pen" style="padding: 5px" title="${translateTag(1194)}" notes="Edit"></i></span>`
                     + `<span class="pointer text-left pl-1" ng-click="actions.viewReports($event,${params.data.submissionheaderid_id}, 'hazard_report')"> <i class="fa fa-external-link-alt" notes = "Launch Report" title="${translateTag(3429)}"></i></span>`
                }, filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab']
            },
            {
                field: "submitted_date",
                headerName: " ",
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                sort: 'desc',
            },
            {
                field: "submitted_by",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer'
            },
            {
                field: "action_by_who",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer'
            },
            {
                field: "action_by_when",
                headerName: " ",
                minWidth: 120,
                maxWidth: 120,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: (params) => {
                    let status = params.data.action_status
                    let actionDate = new Date(params.data.action_by_when)
                    let currentDate = new Date()
                    try {
                        if(!params.data.action_by_when)
                            return ('<div><div>')                        
                        else if (actionDate < currentDate && status.toString().toUpperCase() === translateTag(5028).toString().toUpperCase() /* 'Incomplete'*/ )
                            return '<div style="color: #D20000;">' + params.data.action_by_when + '</div>'
                        else
                            return '<div>' + params.data.action_by_when + '</div>'                        
                    } catch (error) {
                        console.log('error: ', status, error)
                        return '<div>' + params.data.action_by_when + '</div>'  
                    }
                    
                }
            },
            {
                field: "action_type",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer'
            }, 
            {
                field: "recommended_action",
                headerName: " ",
                minWidth: 200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                valueGetter: function (params) {                   
                    if(params.data.recommended_action)
                        return params.data.recommended_action.replace(/\r?\n|\r/g, ' ');
                    else
                        return ' '
                }
            },
            {
                field: "HeaderDate",
                headerName: " ",
                minWidth: 120,
                maxWidth: 120,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Site",
                headerName: " ",
                minWidth: 200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "JobNumber",
                headerName: " ",
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "SiteLevel",
                headerName: " ",
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Workplace",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Supervisor",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "action_status",
                headerName: " ",
                minWidth: 100,
                maxWidth: 100,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "action_complete_by_who",
                hide: true
            },
            {
                field: "action_completed_date",
                hide: true
            },
            
            {
                field: "attachment_files",
                hide: true
            },
            
            {
                field: "completed_action_score",
                hide: true
            },
            {
                field: "completed_action_taken",
                hide: true
            },
            {
                field: "completed_action_type",
                hide: true
            },
            {
                field: "further_action_required",
                hide: true
            },
            {
                field: "hazard_description",
                hide: true
            },
            {
                field: "hazard_identification",
                hide: true
            },
            {
                field: "hazard_identification_score",
                hide: true
            },
            {
                field: "hazard_type",
                hide: true
            },
            {
                field: "immediate_action_required_and_performed",
                hide: true
            },
            {
                field: "immediate_action_score",
                hide: true
            },
            {
                field: "immediate_action_taken",
                hide: true
            },
            {
                field: "immediate_action_type",
                hide: true
            },
            {
                field: "potential_risk",
                hide: true,
                cellRenderer:"tippyCellRenderer"
            },
            {
                field: "potential_risk_score",
                hide: true,
                cellRenderer:"tippyCellRenderer"
            },
            {
                field: "recommended_action",
                hide: true
            },
            {
                field: "submissionheaderid",
                hide: true
            },
            {
                field: "distribution",
                hide: true
            },

        ]

        vm.hazardOptions.columnDefs = hazardColumns

        //Set Ag-Grid column settings for generals
        let generalColumns = [
            {
                headerName: '',
                field: 'dummyCheckbox',
                maxWidth: 50,
                minWidth: 50,
                checkboxSelection: true,
                suppressMenu: true,
                suppressSorting: true,
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
            },
            {
                field: 'sga_id',
                hide: true,
            },
            {
                field: '',
                headerName: " ",
                hide: true,                
                valueGetter: function (params) {
                    let status = params.data.sga_action_is_complete
                    let actionDate = new Date(params.data.sga_action_by_when)
                    let currentDate = new Date()
                    
                    if (actionDate < currentDate && status.toUpperCase() === translateTag(5028).toUpperCase() /* 'Incomplete'*/ )
                        return '1_Overdue'
                    else if (status.toUpperCase() ===  translateTag(5028).toUpperCase())
                        return '2_Due'
                    else
                        return '3_Complete'
                },
                //sort: 'asc',
            },
            {
                field: "review",
                headerName: " ",
                maxWidth: 80,
                minWidth: 80,
                suppressMenu: true,
                suppressMenu: true,
                suppressSorting: true,
                cellRenderer: function (params) {   
                    // if action COMPLETE, no edit button - add invisble class                 
                    let invisible = params.data.sga_action_is_complete === translateTag(2045) ? 'invisible' : ''
                  return `<span class="pointer ${invisible}" ng-if="actions.canManageActionItems" ng-click="actions.openModal('generalActionModal','edit', ${params.data.sga_id})"><i class="fa fa-pen" style="padding: 5px" title="${translateTag(1194)}" notes="Edit"></i></span>`
                        +`<span class="pointer text-left pl-1" ng-click="actions.viewReports($event, ${params.data.sga_submission_header_id}, 'general_actions_parent')"> <i class="fa fa-external-link-alt" notes="Launch Report" title="${translateTag(3429)}"></i></span>`
                }, 
                filter: 'agSetColumnFilter', 
                menuTabs: ['filterMenuTab']
            },
            {
                field: "submitted_date",
                headerName: " ",
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                sort: 'desc'
            },
            {
                field: "submitted_by",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "sga_action_by_who",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "sga_action_by_when",
                headerName: " ",
                minWidth: 120,
                maxWidth: 120,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],                
                cellRenderer: (params) => {

                    let status = params.data.sga_action_is_complete
                    let actionDate = new Date(params.data.sga_action_by_when)
                    let currentDate = new Date()
                    try {
                        if (actionDate < currentDate && status.toString().toUpperCase() === translateTag(5028).toString().toUpperCase() /* 'Incomplete'*/ )
                            return '<div style="color: #D20000;">' + params.data.sga_action_by_when + '</div>'
                        else
                            return '<div>' + params.data.sga_action_by_when + '</div>'
                    } catch (error) {
                        console.log('error: ',status, error)
                        return params.data.sga_action_by_when
                    }
                    
                },
               // sort: 'asc',
            },
            {
                field: "sga_action_type_rld_id",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            }, 
            {
                field: "sga_recommended_action",
                headerName: " ",
                minWidth: 200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                valueGetter: function (params) {
                    if(params.data.sga_recommended_action)
                        return params.data.sga_recommended_action.replace(/\r?\n|\r/g, ' ');
                    else
                        return ' '
                }
            },
            {
                field: "HeaderDate",
                headerName: " ",
                minWidth: 120,
                maxWidth: 120,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Site",
                headerName: " ",
                minWidth: 200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "JobNumber",
                headerName: " ",
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "SiteLevel",
                headerName: " ",
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Workplace",
                headerName: "Work place",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Supervisor",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "sga_action_is_complete",
                headerName: " ",
                minWidth: 100,
                maxWidth: 100,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer'
            },
            {
                field:"distribution",
                hide:true
            },
            {
                field:"distribution_emails",
                hide:true
            },
            {
                field:"exceptionFields",
                hide:true
            },
            {
                field:"sga_completed_action_by_who_per_id",
                hide:true
            },
            {
                field:"sga_completed_action_date",
                hide:true
            },
            {
                field:"sga_completed_action_taken",
                hide:true
            },
            {
                field:"sga_completed_action_type_rld_id",
                hide:true
            },
            {
                field:"sga_created_by_per_id",
                hide:true
            },
            {
                field:"sga_created_date",
                hide:true
            },
            {
                field:"sga_enable",
                hide:true
            },
            {
                field:"sga_enote",
                hide:true
            },
            {
                field:"sga_modified_by_per_id",
                hide:true
            },
            {
                field:"sga_modified_date",
                hide:true
            },
            {
                field:"sga_submission_header_id",
                hide:true
            },
        ]

        vm.generalOptions.columnDefs = generalColumns

        //Functions to open complete/followup action components
        vm.generalOptions.onRowDoubleClicked = (row) => {   
            if(!vm.canCloseAllActions){
                if(row.data.created_by_per_id != vm.userId && !row.data.sga_action_by_who_per_id.includes(vm.userId)){
                    toastr.success(translateTag(9525)) // You can only close actions created by you or assigned to you.
                    return
                }
            }  
            if(row.data.sga_action_is_complete === translateTag(2045)){
                // if action COMPLETE, do not open edit modal - add invisble class
                return
            }       
            actionManagementService.getGeneralActionSingle({sga_id: row.data.sga_id}).then((response)=>
            {   

                vm.generalFollowup = response
                if(!vm.generalFollowup.sga_completed_action_date){
                    vm.generalFollowup.sga_completed_action_date = dateToday.format('YYYY-MM-DD')    
                }

                vm.generalFollowup.sga_completed_action_by_who_per_id = getEmployeeID(vm.generalFollowup.sga_completed_action_by_who_per)
                
                vm.generalFollowup.attachment_files_initial = []
                vm.generalFollowup.attachment_files_followup = []

                vm.generalFollowup.sga_action_by_who_per_id = getEmployeeNames(vm.generalFollowup.sga_action_by_who_per)

                vm.generalFollowup.attachments.forEach((attRec) => {
                    if(attRec.gaa_type == 'INITIAL')
                    {
                        attRec.imageDir = `${__env.imageUrl}/`
                        vm.generalFollowup.attachment_files_initial.push(attRec) 
                    }
                    else if(attRec.gaa_type == 'FOLLOWUP')
                    {
                        attRec.imageDir = `${__env.imageUrl}/`
                        vm.generalFollowup.attachment_files_followup.push(attRec) 
                    }
                })
                
                vm.openModal('completeGeneralActionModal')
                setTimeout(()=>{
                    $scope.$broadcast('GENERAL_FOLLOWUP_OPENED')
                },100) 
            })
        }

        vm.hazardOptions.onRowDoubleClicked = (row) => {          
            if(!vm.canCloseAllActions){
                if(row.data.created_by_per_id != vm.userId && !row.data.action_by_who_per_id.includes(vm.userId)){
                    toastr.success(translateTag(9525)) // You can only close actions created by you or assigned to you.

                    return
                }
            }  
            if(row.data.action_status === translateTag(2045)){
                // if action COMPLETE, do not open edit modal - add invisble class
                return
            }

            actionManagementService.getHazardActionSingle({hap_id: row.data.id}).then((response)=> {


                vm.followup = response
                vm.followup.sha_is_group_action = true
                if(!vm.followup.action_completed_date){
                    vm.followup.action_completed_date = dateToday.format('YYYY-MM-DD')
                }
                vm.followup.action_complete_by_who = (vm.followup.action_complete_by_who && vm.followup.action_complete_by_who != 'None') ? parseInt(getEmployeeID(vm.followup.action_complete_by_who)) : null

                vm.followup.attachmentModalFiles = []
                vm.followup.followupAttachmentModalFiles = []
                vm.followup.action_status = vm.followup.action_status.toLowerCase() == translateTag(2045).toLowerCase() ? translateTag(2045): translateTag(5028) // 'INCOMPLETE'

                vm.followup.attachments.forEach((attRec) => {
                    if(attRec.attachmenttype === 'INITIAL')
                    {
                        attRec.imageDir = `${__env.imageUrl}/`
                        attRec.AttachmentFileName = attRec.attachmentfilename
                        vm.followup.attachmentModalFiles.push(attRec) 
                    }
                    else if(attRec.attachmenttype === 'FOLLOWUP')
                    {
                        attRec.imageDir = `${__env.imageUrl}/`
                        attRec.AttachmentFileName = attRec.attachmentfilename
                        vm.followup.followupAttachmentModalFiles.push(attRec) 
                    }
                })
                
                vm.followup.HapId = row.data.id
                
                vm.followup.action_by_who_name = getEmployeeNames(vm.followup.action_by_who)
                vm.followup.modalId = 'hapFollowupComponent'                                
                
                vm.openModal('hapFollowupComponent')
                setTimeout(()=>{
                    $scope.$broadcast('HAZARD_FOLLOWUP_OPENED')
                },100)
            })
        }
        
        //Function to open modals
        vm.openModal = (modalId, mode = 'new', id) => {
            vm.actionMode = mode
            if(mode === 'edit' && modalId === 'generalActionModal') {
                openGeneralEdit(id, modalId)
            }
            else if(mode === 'edit' && modalId === 'hazardActionModal') {
                openHazardEdit(id, modalId)
            }
            else
            {
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()            

                $('.modal .scroll').scrollTop(0)

                modalService.Open(modalId)
                vm.initializeSelect2(modalId)
            }            
        }
        
        vm.openForm = (activeFormID) =>{
            let message={activeFormID:null,incidentId:null,moduleId:null}
            message.activeFormID=activeFormID
            $rootScope.$broadcast("OPENMOBILEFRAME", message)
        }

        //Refresh grid when any form is submitted
        $scope.$on('REFRESH_FORMSUBMISSIONS', (event) => {
            refreshData()
        })

        //Function to initialize select2
        vm.initializeSelect2 = (parent)=> {
            setTimeout(()=>{
            $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} .modal-body`), escapeMarkup: function (text) { return text } })
                .on('select2:select', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list'))
                        $rootScope.$broadcast('distribution-list-added', event)
                    $(this).parent().find('label').addClass('filled')   
                })
                .on('select2:unselect', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list'))
                        $rootScope.$broadcast('distribution-list-removed', event)
                    $(this).parent().find('label').addClass('filled')
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()
            }, 500)
            if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
            $('.datepicker').pickadate({
                format: 'yyyy-mm-dd',
                onClose : function(){
                    this.$holder.blur()
                },
            }).removeAttr('readonly')
            .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                evt.preventDefault()
            })
            preventFutureDatePickerInit()
        }

        //Function to prepare data to edit a general action
        function openGeneralEdit(id, modalId) {
            actionManagementService.getGeneralActionSingle({sga_id: id}).then ((response) => {
                vm.generalEditData = response
                vm.generalEditData.Site = parseInt(vm.generalEditData.Site)
                vm.generalEditData.JobNumber = parseInt(vm.generalEditData.JobNumber)
                vm.generalEditData.SiteLevel = parseInt(vm.generalEditData.SiteLevel)
                vm.generalEditData.Supervisor = parseInt(vm.generalEditData.Supervisor)

                vm.generalEditData.HeaderDate = moment(vm.generalEditData.HeaderDate).format('YYYY-MM-DD')
                vm.generalEditData.sga_action_by_who_per_id = vm.generalEditData.sga_action_by_who_per

                if(vm.generalEditData.sga_is_group_action) {
                    vm.generalEditData.sga_is_group_action = 'group'
                } else {
                    vm.generalEditData.sga_is_group_action = 'individual'
                }

                let i = 0
                let initialAtt = JSON.parse(JSON.stringify(vm.generalEditData.attachments))
                initialAtt.forEach((att) => {
                    if(att.gaa_type === 'FOLLOWUP')
                        vm.generalEditData.attachments.splice(i, 1)
                    else
                        i++
                })

                vm.generalEditData.attachments.forEach((att) => {
                    att.imageDir = `${__env.imageUrl}/`
                })
                
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()            

                $('.modal .scroll').scrollTop(0)

                modalService.Open(modalId)
                vm.initializeSelect2(modalId)
            })
        }

        //Function to prepare data to edit a hazard action
        function openHazardEdit(id, modalId) {
            actionManagementService.getHazardActionSingle({hap_id: id}).then ((response) => {
                vm.hazardEditData = response
                vm.hazardEditData.Site = parseInt(vm.hazardEditData.Site)
                vm.hazardEditData.JobNumber = parseInt(vm.hazardEditData.JobNumber)
                vm.hazardEditData.SiteLevel = parseInt(vm.hazardEditData.SiteLevel)
                vm.hazardEditData.Supervisor = parseInt(vm.hazardEditData.Supervisor)

                vm.hazardEditData.HeaderDate = moment(vm.hazardEditData.HeaderDate).format('YYYY-MM-DD')

                if(vm.hazardEditData.sha_is_group_action) {
                    vm.hazardEditData.sha_is_group_action = 'group'
                } else {
                    vm.hazardEditData.sha_is_group_action = 'individual'
                }

                let i = 0
                let initialAtt = JSON.parse(JSON.stringify(vm.hazardEditData.attachments))
                initialAtt.forEach((att) => {
                    if(att.attachmenttype === 'FOLLOWUP')
                        vm.hazardEditData.attachments.splice(i, 1)
                    else {
                        i++
                    }
                })

                vm.hazardEditData.attachments.forEach((att) => {
                    att.imageDir = `${__env.imageUrl}/`
                })
                
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()            

                $('.modal .scroll').scrollTop(0)
                
                modalService.Open(modalId)
                vm.initializeSelect2(modalId)             
            })
        }

        //Brodcast recivers from complete/followup action components to refresh data
        $scope.$on('UPDATE_FOLLOWUP', (event) => {
            refreshData('Haz')
        })
        $scope.$on('GENERAL_REFRESHDATA', (event) => {
            refreshData('All')
        })
        $scope.$on('COMPLETEACTION', (event) => {
            refreshData('Gen')
        })

        //Function to refresh data/Ag-grid
        function refreshData(mode='All') {
            $scope.$emit('STARTSPINNER', vm.loadMessage)
            
            if ($window.sessionStorage.getItem('homepageRedirect_actionsFilter') == 'homepage') {

                let homePageSiteList = $window.sessionStorage.getItem('homePageSiteList')
                let homePageJobList = $window.sessionStorage.getItem('homePageJobList')
                vm.homePageActionsPayload = {
                    "sites": homePageSiteList,
                    "jobs": homePageJobList
                }
                vm.hazardFilterType = "homepage"
                vm.generalFilterType = "homepage"    
            }

            if ($window.sessionStorage.getItem('userAdminRedirect_actionsFilter') == 'Deactivation') {
                vm.hazardFilterType = "Deactivation"
                vm.generalFilterType = "Deactivation"
                vm.hazardStatusFilter = "Incomplete"
                vm.generalStatusFilter = "Incomplete"
                vm.userAdminRedirectUserId = $window.sessionStorage.getItem('userAdminRedirect_userId')
                $window.sessionStorage.removeItem('userAdminRedirect_actionsFilter')
                $window.sessionStorage.removeItem('userAdminRedirect_userId')
            }
            else{
                $window.sessionStorage.removeItem('userAdminRedirect_actionsFilter')
                $window.sessionStorage.removeItem('userAdminRedirect_userId')
            }
            

            let services = []
            if(mode == 'All')
            {
                if(vm.hazardFilterType == "Deactivation" &&  vm.generalFilterType == "Deactivation"){
                    services = [
                        listService.getSelectListData('ref_general_action'),
                        listService.getSelectListData('ref_action_type'),
                        listService.getSelectListData('ref_hazard_identification'),
                        listService.getSelectListData('ref_potential_loss'),
                        listService.getSelectListData('ref_hazard_type'),                           
                        actionManagementService.getHazardsList({filter:vm.hazardFilterType, status: vm.hazardStatusFilter, user_id: vm.userAdminRedirectUserId}),
                        actionManagementService.getGeneralActionsList({filter:vm.generalFilterType, status: vm.generalStatusFilter, user_id: vm.userAdminRedirectUserId}),                             
                        profileService.getAllEmployeeProfile(),
                        profileService.getFullEmployeeProfile(),
                    ]
                }
                else{
                    services = [
                        listService.getSelectListData('ref_general_action'),
                        listService.getSelectListData('ref_action_type'),
                        listService.getSelectListData('ref_hazard_identification'),
                        listService.getSelectListData('ref_potential_loss'),
                        listService.getSelectListData('ref_hazard_type'),                           
                        actionManagementService.getHazardsList({filter:vm.hazardFilterType, status: vm.hazardStatusFilter, user_id: vm.userAdminRedirectUserId, actions_payload :vm.homePageActionsPayload}),
                        actionManagementService.getGeneralActionsList({filter:vm.generalFilterType, status: vm.generalStatusFilter, user_id: vm.userAdminRedirectUserId, actions_payload :vm.homePageActionsPayload}),                             
                        profileService.getAllEmployeeProfile(),
                        profileService.getFullEmployeeProfile(),
                    ]
                }
            }
            else if (mode == 'Haz'){
                services = [
                    listService.getSelectListData('ref_general_action'),
                    listService.getSelectListData('ref_action_type'),
                    listService.getSelectListData('ref_hazard_identification'),
                    listService.getSelectListData('ref_potential_loss'),
                    listService.getSelectListData('ref_hazard_type'),
                    actionManagementService.getHazardsList({filter:vm.hazardFilterType, status: vm.hazardStatusFilter, user_id: vm.userAdminRedirectUserId}),             
                    profileService.getAllEmployeeProfile(),
                    profileService.getFullEmployeeProfile(),
                ]
            }
            else if (mode == 'Gen'){
                services = [
                    listService.getSelectListData('ref_general_action'),
                    listService.getSelectListData('ref_action_type'),
                    listService.getSelectListData('ref_hazard_identification'),
                    listService.getSelectListData('ref_potential_loss'),
                    listService.getSelectListData('ref_hazard_type'),
                    actionManagementService.getGeneralActionsList({filter:vm.generalFilterType, status: vm.generalStatusFilter, user_id: vm.userAdminRedirectUserId}),                
                    profileService.getAllEmployeeProfile(),
                    profileService.getFullEmployeeProfile(),
                ]
            }            

            services.push(employeesService.getPersonProfile())            

            $q.all(services).then((data) => {
                if(vm.hazardFilterType == 'Assigned To Me'){
                    vm.hazardFilterValue = translateTag(1062)
                } else if (vm.hazardFilterType == 'Created By Me'){
                    vm.hazardFilterValue = translateTag(1063)
                } else if(vm.hazardFilterType== 'Completed By Me'){
                    vm.hazardFilterValue = translateTag(1322)
                } else if(vm.hazardFilterType=='Site'){
                    vm.hazardFilterValue = translateTag(828)
                } else if(vm.hazardFilterType == 'All'){
                    vm.hazardFilterValue = translateTag(1064)
                }
                if(vm.generalFilterType == 'Assigned To Me'){
                    vm.generalFilterValue = translateTag(1062)
                } else if (vm.generalFilterType == 'Created By Me'){
                    vm.generalFilterValue = translateTag(1063)
                } else if(vm.generalFilterType== 'Completed By Me'){
                    vm.generalFilterValue = translateTag(1322)
                } else if(vm.generalFilterType=='Site'){
                    vm.generalFilterValue = translateTag(828)
                } else if(vm.generalFilterType == 'All'){
                    vm.generalFilterValue = translateTag(1064)
                }
                if(mode == 'All' || mode == 'Haz')
                    vm.hazardData = actionManagementService.readHazardsList().OutPut
                if(mode == 'All' || mode == 'Gen')
                    vm.generalData = actionManagementService.readGeneralActionsList().OutPut
                vm.employeeList = profileService.readAllEmployeeProfile()
                vm.fullEmployeeList = profileService.readFullEmployeeProfile()
                vm.actionTypeList = data[0]
                vm.actionHazardTypeList = data[1]
                vm.identificationList = data[2]
                vm.potentialLossList = data[3]
                vm.hazardTypeList = data[4]
                vm.userId = data.at(-1).per_id


                if (vm.hazardOptions.api) {
                    translateAgGridHeader(vm.hazardOptions)
                    let modelHazard = vm.hazardOptions.api.getFilterModel()
                    vm.hazardOptions.paginationPageSize = 10
                    vm.hazardOptions.api.setRowData(prepareHazardActionsGridData())
                    vm.hazardOptions.api.redrawRows()
                    vm.hazardOptions.api.sizeColumnsToFit()
                    vm.hazardOptions.api.setFilterModel(modelHazard)
                }
                if (vm.generalOptions.api) {
                    translateAgGridHeader(vm.generalOptions)
                    let modelGeneral = vm.generalOptions.api.getFilterModel()
                    vm.generalOptions.paginationPageSize = 10
                    vm.generalOptions.api.setRowData(prepareGeneralActionsGridData())
                    vm.generalOptions.api.redrawRows()
                    vm.generalOptions.api.sizeColumnsToFit()
                    vm.generalOptions.api.setFilterModel(modelGeneral)
                }
             
                $scope.$emit('STOPSPINNER')
                $window.sessionStorage.removeItem('homepageRedirect_actionsFilter')
               
            })
              
        }

        refreshData()

        //Function to prepare Hazard Data for the grid/tippy
        function prepareHazardActionsGridData(data=vm.hazardData) {
            
            if(!data)
                return []

            let hazardActionsGridData = JSON.parse(JSON.stringify(data))

            hazardActionsGridData.forEach((rec) =>{
                rec.exceptionFields = ['further_action_required', 'is_native_system','sha_enable','sha_enote', 'name_site', 'name_job_number', 'name_level','action_by_who_per_id', 'created_by_per_id']
                rec.created_by_per_id = rec.submitted_by
                rec.Supervisor = getEmployeeName(rec.Supervisor)
                rec.submitted_by = getEmployeeName(rec.submitted_by)
                rec.immediate_action_required_and_performed = rec.immediate_action_required_and_performed ? translateTag(1379) : translateTag(1380) //'Yes':'No'                
                rec.Site = rec.name_site
                rec.JobNumber = rec.name_job_number
                rec.SiteLevel = rec.name_level
                
                if(rec.HeaderDate != null)
                    rec.HeaderDate = moment(rec.HeaderDate).format('YYYY-MM-DD')
                rec.submitted_date = moment(rec.submitted_date).format('YYYY-MM-DD')
                rec.sha_created_date = moment(rec.sha_created_date).format('YYYY-MM-DD')
                rec.sha_modified_date = rec.sha_modified_date == null? '': moment(rec.sha_modified_date).format('YYYY-MM-DD')
                rec.attachment_files = rec.attachments
                if(rec.attachments != null)
                    rec.attachments = rec.attachments.length
                rec.distribution_emails = rec.distribution_emails
                if(typeof rec.distribution_emails === 'object'){
                    // removing duplicates from distribution_emails
                    rec.distribution_emails = removeDuplicates(rec.distribution_emails)

                }
                
                if(rec.distribution_emails[0] != null)
                    rec.distribution = formatDistribution(rec.distribution_emails)
                else
                    rec.distribution = ''
                if(rec.action_status==null){
                    rec.action_status == translateTag(5028) //'Incomplete'
                } else {
                    rec.action_status = rec.action_status.toUpperCase() === 'COMPLETE'  ? translateTag(2045) : translateTag(5028)
                }

            })
            return hazardActionsGridData
        }

        //Function to prepare General Data for the grid/tippy
        function prepareGeneralActionsGridData(data=vm.generalData) {

            if(!data)
                return []

            let generalActionsGridData = JSON.parse(JSON.stringify(data))
            generalActionsGridData.forEach((rec) => {
                rec.exceptionFields = ['sga_enote', 'sga_enable', 'ReportURL', 'Form', 'FormDescriptionID', 'distribution_emails','sga_action_by_who_per','sga_action_by_who_per_id', 'created_by_per_id']
                rec.created_by_per_id = rec.sga_created_by_per_id
                rec.sga_created_by_per_id = getEmployeeName(rec.sga_created_by_per_id)
                rec.sga_modified_by_per_id = getEmployeeName(rec.sga_modified_by_per_id)
                rec.submitted_by = getEmployeeName(rec.submitted_by)
                rec.Supervisor = getEmployeeName(rec.Supervisor)
                rec.sga_action_is_complete = rec.sga_action_is_complete? translateTag(2045) /* 'Complete' */: translateTag(5028) /*'Incomplete'*/
                
                if(rec.HeaderDate != null)
                    rec.HeaderDate = moment(rec.HeaderDate).format('YYYY-MM-DD')
                rec.sga_created_date = moment(rec.sga_created_date).format('YYYY-MM-DD')
                rec.sga_modified_date = rec.sga_modified_date == null? '': moment(rec.sga_modified_date).format('YYYY-MM-DD')
                rec.submitted_date = moment(rec.submitted_date).format('YYYY-MM-DD')

                rec.attachment_files = rec.attachments
                if(rec.attachments != null)
                    rec.attachments = rec.attachments.length
                if(typeof rec.distribution_emails === 'object'){
                    // removing duplicates from distribution_emails
                    rec.distribution_emails = removeDuplicates(rec.distribution_emails)
                }
                if(rec.distribution_emails[0] != null)
                    rec.distribution = formatDistribution(rec.distribution_emails)
                else
                    rec.distribution = ''

            })
            
            return generalActionsGridData
        }

        //Function to format the distribution list for the tippy
        function formatDistribution(dist)
        {
            let output = '<table>'
            dist.forEach((rec)=> {
                output += `<tr><td>${rec}</td><tr>` 
            })
            output += '</table>'
            return output
        }

        //Function to remove duplicates in array
        function removeDuplicates(dist)
        {
            dist = dist.filter(function(item, pos, self) {
                return self.indexOf(item) == pos;
            })
            return dist
        }

        //Update Ag-Grid size when window is resized
        $(window).on('resize', () => {
            $timeout(function () {
                if (vm.hazardOptions.api) {
                    vm.hazardOptions.api.sizeColumnsToFit()
                }
                if (vm.generalOptions.api) {
                    vm.generalOptions.api.sizeColumnsToFit()
                }
            })
        })
      }
    ])