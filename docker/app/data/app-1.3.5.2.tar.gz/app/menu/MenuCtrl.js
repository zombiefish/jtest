﻿angular
  .module('safeToDo')
  .controller('MenuCtrl', ['$http','$rootScope', '$route', '$scope', '$timeout', '$cookies', '$location', '$q', '$window', 'menuService', 'profileService', 'listService',
    function ($http, $rootScope, $route, $scope, $timeout, $cookies ,$location, $q , $window,  menuService,  profileService, listService) {
      let vm = this
      vm.isAccessDenied = false
      vm.isAuthLoading = true
      vm.dataLinks = menuService.getMenuItems()
      vm.currentActive = 'home'
      vm.currentActiveFormId = -1
      vm.isMenuCollapsed = false; //Screen real estate
      vm.dataOn = false
      vm.dataOn2 = false
      vm.dataOn3 = false // Risk Management
      vm.dataOn4 = false // Analytics
      vm.dataOn5 = false // Modules
      vm.flyoutOn = false
      vm.showFlyout = false
      vm.showFlyout2 = false
      vm.showFlyout3 = false // Risk Management
      vm.showFlyout4 = false // Analytics
      vm.showFlyout5 = false // Modules
      vm.noAnimate = false
      vm.menuFootHover = false
      vm.selectedFormDescriptionId = 0
      let collapsedState = 'true'
      vm.canViewAdminLink = false
      vm.canAccessToAddOnModules = false
      vm.canViewLessonsLearnedLink = false
      vm.canViewDecisionLogLink = false
      vm.canViewIncidentsLink = false
      vm.canViewLineup = false
      vm.canViewTrainingRecords = false
      vm.canViewRmm = false
      vm.canViewORA = false
      vm.canViewPRA = false
      vm.canViewJRA = false
      vm.canViewBowtie = false
      vm.canViewAnalytics = false
      vm.canViewAnalyticsAdoptionTracking = false
      vm.canViewAnalyticsHumanResources = false
      vm.canViewAnalyticsIncidents = false
      vm.canViewReports = false
      vm.pageSpinner = false
      vm.pageSpinnerMessage = ""
      vm.canViewLOTO = false

      $scope.$on('STARTSPINNER', (event, value) => {
          vm.pageSpinner = true
          vm.pageSpinnerMessage = value
      })

      $scope.$on('STOPSPINNER', (message) => {
          vm.pageSpinner = false
          vm.pageSpinnerMessage = ""
      })

      //Get permissions for the user
      menuService.getPagePermissions().then((data) => {
        vm.permissions = data
        vm.canViewAdminLink = vm.permissions.includes('Access Administration') ? true : false
        vm.canAccessToAddOnModules = vm.permissions.includes('Access to Add-On Modules') ? true : false
        vm.canViewDocuments = vm.permissions.includes('Can View Documents') ? true : false
        vm.canViewLessonsLearnedLink = vm.permissions.includes('Can View Lessons Learned') ? true : false
        vm.canViewDecisionLogLink = vm.permissions.includes('Can View Decision Log') ? true : false
        vm.canViewIncidentsLink = vm.permissions.includes('Can View Incidents') ? true : false
        vm.canViewLineup = vm.permissions.includes('Can View Lineup') ? true : false
        vm.canViewTrainingRecords = vm.permissions.includes('Can View Training Records') ? true : false
        vm.canViewRmm = vm.permissions.includes('Can View Risk Management Module') ? true : false
        vm.canViewORA = vm.permissions.includes('Can View ORA') ? true : false
        vm.canViewPRA = vm.permissions.includes('Can View PRA') ? true : false
        vm.canViewJRA = vm.permissions.includes('Can View JRA') ? true : false
        vm.canViewBowtie = vm.permissions.includes('Can View Bowtie') ? true : false
        vm.canViewAnalytics = vm.permissions.includes('Can View Analytics') ? true : false
        vm.canViewAnalyticsAdoptionTracking = vm.permissions.includes('Can View Analytics Adoption Tracking') ? true : false
        vm.canViewAnalyticsHumanResources = vm.permissions.includes('Can View Analytics Human Resources') ? true : false
        vm.canViewAnalyticsIncidents = vm.permissions.includes('Can View Analytics Incidents') ? true : false
        vm.canViewReports = vm.permissions.includes('Can View Reports') ? true : false
        vm.canViewLOTO = vm.permissions.includes('Can View LOTO') ? true : false

        // Used to re-route if the user does not have permission to be on the page
        if ($route.current.permission !== undefined && $route.current.permission !== null) {
          if (!vm.permissions.includes($route.current.permission)) {
            $location.path('/')
          }
        }
      })

      // Used to re-route if the user does not have permission to be on the page
      $rootScope.$on('$routeChangeStart', function (event, next, current) {
        if (next.permission !== undefined && next.permission !== null && vm.permissions) {
          if (!vm.permissions.includes(next.permission)) {
            $location.path('/')
          }
        }
      })      
    
      vm.detectWindowSize = () => {
        if ($cookies.get('menu-isMenuCollapsed') !== undefined && $cookies.get('menu-isMenuCollapsed') !== '') {
          vm.isMenuCollapsed = (collapsedState === $cookies.get('menu-isMenuCollapsed'))
        }
        else if (window.matchMedia("(max-width: 1024px)").matches) {
          vm.isMenuCollapsed = true
        }
        else {
          vm.isMenuCollapsed = false
        }
        $cookies.put('menu-isMenuCollapsed', vm.isMenuCollapsed)
      }

      vm.detectWindowSize()

      vm.toggleMenuCollapse = () => {
        vm.isMenuCollapsed = !vm.isMenuCollapsed;
        $cookies.put('menu-isMenuCollapsed', vm.isMenuCollapsed);
        $rootScope.$broadcast('menu-width-changed');
      }

      // Form submissions
      vm.dataActive = () => {
        return ['forms', 'haps', 'recognition', 'gaps', 'lineup'].indexOf(vm.currentActive) > -1
      }

      // Administration
      vm.dataActive2 = () => {
        return ['adminFormBuilder','adminEquipment', 'adminLists', 'adminRole', 'adminTarget', 'adminTraining', 'adminUser'].indexOf(vm.currentActive) > -1
      }

      // Risk Management
      vm.dataActive3 = () => {
        return ['jra', 'pra', 'ora', 'bowtie'].indexOf(vm.currentActive) > -1
      }

      // Analytics
      vm.dataActive4 = () => {
        return ['analyticsAdoption', 'analyticsHr', 'analyticsIncidents'].indexOf(vm.currentActive) > -1
      }

      // // Modules
      // vm.dataActive5 = () => {
      //   return true
      // }

      vm.enterFlyout = () => {
        vm.flyoutOn = true
        vm.showFlyout = true
      }

      vm.leaveFlyout = () => {
        vm.flyoutOn = false
        $scope.$broadcast('leave-flyout', { leaveflyout: true }) //down in the scope chain
        //Do not want immediate effect on off - cursor may be transitioning to another valid area.
        $timeout(() => {
          vm.showFlyout = vm.flyoutOn || vm.dataOn
        }, 1)
      }

      vm.enterFlyout2 = () => {
        vm.flyoutOn = true
        vm.showFlyout2 = true
      }

      vm.leaveFlyout2 = () => {
        vm.flyoutOn = false
        $scope.$broadcast('leave-flyout', { leaveflyout: true }) //down in the scope chain
        //Do not want immediate effect on off - cursor may be transitioning to another valid area.
        $timeout(() => {
          vm.showFlyout2 = vm.flyoutOn || vm.dataOn2
        }, 1)
      }

      // Risk Management
      vm.enterFlyout3 = () => {
        vm.flyoutOn = true
        vm.showFlyout3 = true
      }

      vm.leaveFlyout3 = () => {
        vm.flyoutOn = false
        $scope.$broadcast('leave-flyout', { leaveflyout: true }) //down in the scope chain
        //Do not want immediate effect on off - cursor may be transitioning to another valid area.
        $timeout(() => {
          vm.showFlyout3 = vm.flyoutOn || vm.dataOn3
        }, 1)
      }

      // Analytics
      vm.enterFlyout4 = () => {
        vm.flyoutOn = true
        vm.showFlyout4 = true
      }

      vm.leaveFlyout4 = () => {
        vm.flyoutOn = false
        $scope.$broadcast('leave-flyout', { leaveflyout: true }) //down in the scope chain
        //Do not want immediate effect on off - cursor may be transitioning to another valid area.
        $timeout(() => {
          vm.showFlyout4 = vm.flyoutOn || vm.dataOn4
        }, 1)
      }

      // Modules
      vm.enterFlyout5 = () => {
        vm.flyoutOn = true
        vm.showFlyout5 = true
      }

      vm.leaveFlyout5 = () => {
        vm.flyoutOn = false
        $scope.$broadcast('leave-flyout', { leaveflyout: true }) //down in the scope chain
        //Do not want immediate effect on off - cursor may be transitioning to another valid area.
        $timeout(() => {
          vm.showFlyout5 = vm.flyoutOn || vm.dataOn5
        }, 1)
      }

      vm.enterData = () => {
        vm.dataOn = true
        vm.showFlyout = true
        vm.showFlyout2 = false
        vm.showFlyout3 = false
        vm.showFlyout4 = false
        vm.showFlyout5 = false
      }

      vm.enterData2 = () => {
        vm.dataOn2 = true
        vm.showFlyout2 = true
        vm.showFlyout = false
        vm.showFlyout3 = false
        vm.showFlyout4 = false
        vm.showFlyout5 = false
      }

      // Risk Management
      vm.enterData3 = () => {
        vm.dataOn3 = true
        vm.showFlyout3 = true
        vm.showFlyout = false
        vm.showFlyout2 = false
        vm.showFlyout4 = false
        vm.showFlyout5 = false
      }
      
      // Analytics
      vm.enterData4 = () => {
        vm.dataOn4 = true
        vm.showFlyout4 = true
        vm.showFlyout = false
        vm.showFlyout2 = false
        vm.showFlyout3 = false
        vm.showFlyout5 = false
      }

      // Modules
      vm.enterData5 = () => {
        vm.dataOn5 = true
        vm.showFlyout5 = true
        vm.showFlyout = false
        vm.showFlyout2 = false
        vm.showFlyout3 = false
        vm.showFlyout4 = false
      }

      vm.leaveData = () => {
        vm.dataOn = false
        //Do not want immediate effect on off - cursor may be transitioning to another valid area.
        $timeout(() => {
          vm.showFlyout = vm.flyoutOn || vm.dataOn
        }, 1)
      }

      vm.leaveData2 = () => {
        vm.dataOn2 = false
        //Do not want immediate effect on off - cursor may be transitioning to another valid area.
        $timeout(() => {
          vm.showFlyout2 = vm.flyoutOn || vm.dataOn2
        }, 1)
      }
      
      // Risk Management
      vm.leaveData3 = () => {
        vm.dataOn3 = false
        //Do not want immediate effect on off - cursor may be transitioning to another valid area.
        $timeout(() => {
          vm.showFlyout3 = vm.flyoutOn || vm.dataOn3
        }, 1)
      } 

      // Analytics
      vm.leaveData4 = () => {
        vm.dataOn4 = false
        //Do not want immediate effect on off - cursor may be transitioning to another valid area.
        $timeout(() => {
          vm.showFlyout4 = vm.flyoutOn || vm.dataOn4
        }, 1)
      } 

      // Modules
      vm.leaveData5 = () => {
        vm.dataOn5 = false
        //Do not want immediate effect on off - cursor may be transitioning to another valid area.
        $timeout(() => {
          vm.showFlyout5 = vm.flyoutOn || vm.dataOn4
        }, 1)
      }

      vm.closeFlyout = () => {
        vm.noAnimate = true
        vm.showFlyout = false
        vm.showFlyout2 = false
        vm.showFlyout3 = false
        vm.showFlyout4 = false
        vm.showFlyout5 = false
        //User has clicked a link. Temporarily turn off animations so the drawer disappears immediately.
        $timeout(() => {
          vm.noAnimate = false
        }, 1)
      }

      vm.closeFlyout2 = () => {
        vm.noAnimate = true
        vm.showFlyout = false
        vm.showFlyout2 = false
        vm.showFlyout3 = false
        vm.showFlyout4 = false
        vm.showFlyout5 = false

        //User has clicked a link. Temporarily turn off animations so the drawer disappears immediately.
        $timeout(() => {
          vm.noAnimate = false
        }, 1)
      }

      // Risk Management
      vm.closeFlyout3 = () => {
        vm.noAnimate = true
        vm.showFlyout = false
        vm.showFlyout2 = false
        vm.showFlyout3 = false
        vm.showFlyout4 = false
        vm.showFlyout5 = false

        //User has clicked a link. Temporarily turn off animations so the drawer disappears immediately.
        $timeout(() => {
          vm.noAnimate = false
        }, 1)
      }

      // Analytics
      vm.closeFlyout4 = () => {
        vm.noAnimate = true
        vm.showFlyout = false
        vm.showFlyout2 = false
        vm.showFlyout3 = false
        vm.showFlyout4 = false
        vm.showFlyout5 = false

        //User has clicked a link. Temporarily turn off animations so the drawer disappears immediately.
        $timeout(() => {
          vm.noAnimate = false
        }, 1)
      }

      // Modules
      vm.closeFlyout5 = () => {
        vm.noAnimate = true
        vm.showFlyout = false
        vm.showFlyout2 = false
        vm.showFlyout3 = false
        vm.showFlyout4 = false
        vm.showFlyout5 = false

        //User has clicked a link. Temporarily turn off animations so the drawer disappears immediately.
        $timeout(() => {
          vm.noAnimate = false
        }, 1)
      }

      vm.openLink =(link) => {
        if($location.url() === '/a/home' && link==="/a/home"){
          $route.reload()
        }
        else{
          $location.url(link)
        }
      }

      vm.incidentMinimumYear = ''
      
      vm.loadMinYear=()=>{                
          $q.all([
              menuService.getMinimumYearIncident()
          ]).then(() => {
              vm.incidentMinimumYear = menuService.readMinIncidentDate()
              $window.sessionStorage.setItem('incidentStartYear', vm.incidentMinimumYear)              
          })
      }

      // vm.getIncidentMinimumYear=()=>{
      //   return vm.incidentMinimumYear
      // }

      function menuHeight() {
        let windowHeight = $(window).outerHeight()
        let menuHeight = $('#left-drawer').outerHeight()
        let leftDrawerHeight = $(".left-drawer").height()
        $('#left-drawer').css({ "max-height": leftDrawerHeight - 50 + "px" })
      }

      $(() => {
        menuHeight()
        vm.loadMinYear()
      })

      vm.translateLabels = (key) =>{
        return translateTag(key)
      }

      vm.translateGenericLabels = (key) =>{
        return translateGenericFields(key)
      }

      //Coloring active left menu selection
      $scope.$on('$routeChangeSuccess', (event, current, previous) => {
        switch (current.$$route.originalPath) {
          
          case '/a/home':
            vm.currentActive = 'home'
            break
          case '/a/toolbox':
            vm.currentActive = 'toolbox'
            break
          case '/a/profile':
            vm.currentActive = 'profile'
            break
          case '/a/positive-id':
            vm.currentActive = 'positive-id'
            break
          case '/a/sites':
            vm.currentActive = 'sites'
            break
          case '/a/haps':
            vm.currentActive = 'haps'
            break
          case '/a/gaps':
            vm.currentActive = 'gaps'
            break
          case '/a/action-management':
            vm.currentActive = 'action-management'
            break
          case '/a/document-review':
            vm.currentActive = 'document-review'
            break
          case '/a/lessons-learned':
            vm.currentActive = 'lessons-learned'
            break
          case '/a/decision-log':
            vm.currentActive = 'decision-log'
            break
          case '/a/lineup':
            vm.currentActive = 'lineup'
            break
          case '/a/recognition':
            vm.currentActive = 'recognition'
            break
          case '/a/forms/:formDescriptionId':
            vm.currentActive = 'forms'
            vm.selectedFormDescriptionId = current.params.formDescriptionId
            break
          case '/a/reports':
            vm.currentActive = 'reports'
            break
          case '/a/pentaho':
            vm.currentActive = 'reports'
            break
          case '/a/targets':
            vm.currentActive = 'targets'
            break
          case '/a/access':
            vm.currentActive = 'access'
            break
          case '/a/tir':
            vm.currentActive = 'tir'
            break
          case '/admin/user':
            vm.currentActive = 'adminUser'
              break
          case '/admin/role':
            vm.currentActive = 'adminRole'
                break
          case '/admin/target':
            vm.currentActive = 'adminTarget'
                break
          case '/admin/training':
            vm.currentActive = 'adminTraining'
                break     
          case '/admin/form-builder':
            vm.currentActive = 'adminFormBuilder'
                break                                                   
          case '/admin/equipment':
            vm.currentActive = 'adminEquipment'
                break           
          case '/admin/list':
            vm.currentActive = 'adminLists'
                break
          // Risk Management
          case '/ra/jra':
            vm.currentActive = 'jra'
                break    
          case '/ra/pra':
            vm.currentActive = 'pra'
                break 
          case '/ra/ora':
            vm.currentActive = 'ora'
                break 
          case '/ra/bowtie':
            vm.currentActive = 'bowtie'
                break 
          //Analytics  
          case '/analytics/adoption':
            vm.currentActive = 'analyticsAdoption'
                break  
          case '/analytics/hr':
            vm.currentActive = 'analyticsHr'
                break    
          case '/analytics/incidents':
            vm.currentActive = 'analyticsIncidents'
                break                         
          default:
            vm.currentActive = 'home'
        }
      })
  }])