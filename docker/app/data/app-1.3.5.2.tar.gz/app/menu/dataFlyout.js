﻿safeToDo.component("stdDataFlyout", {
  bindings: {
    currentActive: '<',
    selectedFormDescriptionId: '<',
    selectedSubformId: '<',
    closeFlyout: '&'
  },
  templateUrl: 'app/menu/dataFlyout.html',
  controllerAs: 'vm',
  controller: function ($scope, $element, $timeout, $filter, $q, menuService,profileService) {
    var vm = this;
    var elem = $($element);
    vm.selectedCategory = false;    
    refreshDataFlyout()
    // refreshing the data flyout menu - categories and sub categories
    function refreshDataFlyout(){
      $q.all([  
        menuService.getFormCategories(),
        menuService.getMenuItems(),
        menuService.getPagePermissions(),
      ]).then((data) => {
        vm.formCategories = menuService.readFormCategories() 
        vm.dataLinks = menuService.readMenuItems()
        vm.permissions = data[2]

        checkFormCategoriesPermission()

        if(!vm.permissions.includes('Can View Own Management Submissions') && !vm.permissions.includes('Can View All Management Submissions')){
          let management_category_index = vm.formCategories.findIndex(item => item.category_name.toLowerCase() === translateTag(986).toLowerCase())
          if(management_category_index != -1)
            vm.formCategories.splice(management_category_index, 1)
        }
        
        if(!vm.permissions.includes('View Own HR Submissions') && !vm.permissions.includes('View All HR Submissions')){
          let hr_category_index = vm.formCategories.findIndex(item => item.category_name.toLowerCase() === translateTag(984).toLowerCase())
          if(hr_category_index != -1)
            vm.formCategories.splice(vm.formCategories.findIndex(item => item.category_name.toLowerCase() === translateTag(984).toLowerCase()), 1)
        }
        
        if(!vm.permissions.includes('Can View Own Daily Log') && !vm.permissions.includes('Can View All Daily Log')){
          let daily_log_form_index = vm.dataLinks.findIndex(item => item.name.toLowerCase() === translateTag(992).toLowerCase())
          if(daily_log_form_index != -1)
            vm.dataLinks.splice(daily_log_form_index, 1)
        }

        if(!vm.permissions.includes('Can View Lineup')) {        
          let lineup_form_index = vm.dataLinks.findIndex(item => item.name.toLowerCase() === translateTag(993).toLowerCase())
          if(lineup_form_index != -1)
            vm.dataLinks.splice(vm.dataLinks.findIndex(item => item.name.toLowerCase() === translateTag(993).toLowerCase()), 1)
        }
        checkFormCategories(vm.formCategories)
      })
    }

    function checkFormCategoriesPermission(){
      let formCategoriesLength = vm.formCategories.length
      for (let index = 0; index < formCategoriesLength; index++) {

        let categoryId = vm.formCategories[index].id
        let categoryType = vm.formCategories[index].type

        let categoryExists = vm.dataLinks.some(t => t.formCategoryID === categoryId && t.type === categoryType)

        vm.formCategories[index]['categoryPermission'] = categoryExists
      }
    }

    function checkFormCategories(categories) {
      vm.allowedFormCategories = []
      categories.forEach((cat) =>{        
        if (vm.dataLinks.find(o => o.formCategoryID === cat.id && o.type === cat.type))
          vm.allowedFormCategories.push(cat)
      })
    }
    
    vm.$onInit = function () {
      $timeout(function () {
        //DOM has finished rendering
      });
    };

    
    vm.canviewadminpagelink = false

    profileService.checkUserPermission('Access Administration').then((response)=>{
      vm.canviewadminpagelink  = response.isPermits ? true : false
       })

    vm.$onChanges = function (changesObj) {
      if (changesObj.currentActive && changesObj.currentActive.currentValue !== null) {
        //      console.log('new current active:' + changesObj.currentActive.currentValue);
      }

      if (changesObj.selectedFormDescriptionId && changesObj.selectedFormDescriptionId.currentValue !== null) {
        //    console.log('new selectedFormDescriptionId:' + changesObj.selectedFormDescriptionId.currentValue);
      }

      if (changesObj.selectedSubformId && changesObj.selectedSubformId.currentValue !== null) {
        //     console.log('new selectedSubformId:' + changesObj.selectedSubformId.currentValue);
      }
    };


    vm.translateLabels = (key) =>{      
      return translateTag(key)
    }

    vm.selectCategory = function (catId, type) {     
      
      if (vm.selectedCategory === catId)
        vm.selectedCategory = false;
      else{
        vm.selectedCategory = parseInt(catId);
        vm.selectedCategoryType = type
      }     
    };

    vm.getSelectedCategory = () => {
      let selectedFormCategory = null
      if(vm.selectedCategory){      
        vm.allowedFormCategories.forEach(form => {
          if(form['id'] == vm.selectedCategory && form['type'] == vm.selectedCategoryType){
            selectedFormCategory = form['category_name']
            return true
          }
        });
      }
      return selectedFormCategory
    };

    $scope.$on('leave-flyout', function (evt, data) {
      $timeout(function () {
        vm.selectedCategory = -1;
      }, 600);
    });

    $scope.$on('refresh-dataflyout', () => {
      refreshDataFlyout()
    });
  }
});

safeToDo.component("stdDataFlyoutAdmin", {
  bindings: {
    currentActive: '<',
    selectedFormDescriptionId: '<',
    selectedSubformId: '<',
    closeFlyout: '&'
  },
  templateUrl: 'app/menu/dataFlyoutAdmin.html',
  controllerAs: 'vm',
  controller: function ($scope, $element, $timeout, $filter, $q, menuService) {
    var vm = this;
    var elem = $($element);
    vm.selectedAdmin = -1;
  
    //Get permissions for the user
    menuService.getPagePermissions().then((data) => {
      vm.permissions = data

      vm.adminLinks = [ {'adminName': translateTag(9133),'id': 'form-builder', 'permission': vm.permissions.includes('Can View Custom Forms')},
                        {'adminName': translateTag(3500),'id': 'equipment', 'permission': vm.permissions.includes('Can Manage Equipment Preops')},
                        {'adminName': translateTag(8465),'id': 'i18n', 'permission': vm.permissions.includes('Can View Internationalization')},
                        {'adminName': translateTag(1031),'id': 'list', 'permission': vm.permissions.includes('Can Manage Basic Lists') || vm.permissions.includes('Can Manage Advanced Lists')},
                        {'adminName': translateTag(1032),'id': 'role', 'permission': vm.permissions.includes('Can View Access')},
                        {'adminName': translateTag(1033),'id': 'target', 'permission': vm.permissions.includes('Can Manage Targets')},
                        {'adminName': translateTag(1034),'id': 'training', 'permission': vm.permissions.includes('Can View Training Records')},
                        {'adminName': translateTag(9072),'id': 'user', 'permission': vm.permissions.includes('Can View Users')},
                        {'adminName': translateTag(1446),'id': 'trifr', 'permission': vm.permissions.includes('Can View TRIFR Manager')}]
    })
    vm.translateLabels = (key) =>{      
      return translateTag(key)
    }
    vm.$onInit = function () {
      $timeout(function () {
        //DOM has finished rendering
      });
    };
  }
});

// Risk Management
safeToDo.component("stdDataFlyoutRa", {
  bindings: {
    currentActive: '<',
    selectedFormDescriptionId: '<',
    selectedSubformId: '<',
    closeFlyout: '&'
  },
  templateUrl: 'app/menu/dataFlyoutRA.html',
  controllerAs: 'vm',
  controller: function ($scope, $element, $timeout, $filter, $q, menuService) {
    var vm = this;
    var elem = $($element);
    vm.selectedRA = -1;
  
    //Get permissions for the user
    menuService.getPagePermissions().then((data) => {
      vm.permissions = data
      vm.raLinks = [  
        {'raName': translateTag(3499),'id': 'ora', 'permission': vm.permissions.includes('Can View ORA')},
        {'raName': translateTag(2259),'id': 'pra', 'permission': vm.permissions.includes('Can View PRA')},                      
        {'raName': translateTag(2291),'id': 'bowtie', 'permission': vm.permissions.includes('Can View Bowtie')},
        {'raName': translateTag(2253),'id': 'jra', 'permission': vm.permissions.includes('Can View JRA')}
      ]
    })
    vm.translateLabels = (key) =>{      
      return translateTag(key)
    }
    vm.$onInit = function () {
      $timeout(function () {
        //DOM has finished rendering
      });
    };
  }
});

// Modules
safeToDo.component("stdDataFlyoutModules", {
  bindings: {
    currentActive: '<',
    selectedFormDescriptionId: '<',
    selectedSubformId: '<',
    closeFlyout: '&'
  },
  templateUrl: 'app/menu/dataFlyoutModules.html',
  controllerAs: 'vm',
  controller: function ($scope,$rootScope, $element, $timeout, $filter, $q, menuService) {
    var vm = this;
    var elem = $($element);
    vm.selectedModule = -1;
  
    //Get permissions for the user
    menuService.getPagePermissions().then((data) => {
      vm.permissions = data
      vm.moduleLinks = [
                    {'moduleName': "MySDS",'id': 'MySDS', 'permission': vm.permissions.includes('MySDS'), 'link':"https://clients.mysds.ca/clientlogin.php"}
      ]
    })

    vm.openMySDS = () =>{
      menuService.getMySDSToken().then((res) =>{
          $rootScope.$broadcast("OPENMYSDSFRAME", menuService.readMySDSToken())
       })
    }

    vm.translateLabels = (key) =>{
      return translateTag(key)
    }
    vm.$onInit = function () {
      $timeout(function () {
        //DOM has finished rendering
      })
    }
  }
});

// Analytics
safeToDo.component("stdDataFlyoutAnalytics", {
  bindings: {
    currentActive: '<',
    selectedFormDescriptionId: '<',
    selectedSubformId: '<',
    closeFlyout: '&'
  },
  templateUrl: 'app/menu/dataFlyoutAnalytics.html',
  controllerAs: 'vm',
  controller: function ($scope, $element, $timeout, $filter, $q, menuService) {
    var vm = this;
    var elem = $($element);
    vm.selectedAnalytics = -1;
  
    //Get permissions for the user
    menuService.getPagePermissions().then((data) => {
      vm.permissions = data

      vm.analyticsLinks = [
                      {'analyticsName': translateTag(984),'id': 'hr', 'permission': vm.permissions.includes('Can View Analytics Human Resources')},
                      {'analyticsName': translateTag(979),'id': 'incidents', 'permission': vm.permissions.includes('Can View Analytics Incidents')} 
      ]     
    })
    vm.translateLabels = (key) =>{      
      return translateTag(key)
    }
    vm.$onInit = function () {
      $timeout(function () {
        //DOM has finished rendering
      });
    };
  }
});