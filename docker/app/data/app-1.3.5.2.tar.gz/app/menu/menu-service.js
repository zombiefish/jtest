angular
  .module('safeToDo')
  .service('menuService', ['$http', '$location','$window', '$q','profileService',
    function ($http, $location, $window, $q, profileService ) {
      var menuItems = []

      let permissionsList = []
      let formCategories = []
      let MySDSToken = ''
      let MySDSReply = ''

      translateLabels =  (key) =>{
        return translateTag(key)
      }

      //Function to get Total rows in a page
      getTotalRowsInGrid = (id) => {
        // The .querySelector function returns the Web elements matching the below Selector
        return document.querySelector(`div#${id} div.ag-body-container`).childNodes
      }

      //Resetting the Total rows 
      setTotalRowsForMasterDetailGrid = (id, totalRowCount) => {
          // Below is the XPath Expression to locate the element in the browser in order to modify its HTML content
          // totalXpathExp = `//div[@id='${id}']//div[@class='ag-paging-panel ag-font-style']/span[@class='ag-paging-row-summary-panel']`
          // .evaluate is the function that locates and returns the expected Web element based on the XPath expression. For more 
          // information, Please refer https://developer.mozilla.org/en-US/docs/Web/API/Document/evaluate
          // totalRowCountElement = document.evaluate(totalXpathExp, document.body, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue
          totalRowCountElement = document.getElementById(id)
          totalRowCountElement.innerHTML = `(${totalRowCount})`
      }
      
      return {

        //Get permissions
        getPagePermissions: ()=> {
          return $q.all([
            profileService.checkUserPermissionsList(),
          ]).then((data) => {
              permissionsList = data[0]
              return permissionsList
          })                 
        },        

        getMinimumYearIncident: function () {
          return $http.get(`${__env.apiUrl}/api/analytic/incident-minimum-creation-date-year/`,)
              .then(function (response) {
                  minIncidentYear = response.data.min_year                         
              }, function (errorParams) {
                  console.log('Failed to load min_year');
                  console.log(errorParams);
              });
        }, 

        readMinIncidentDate: () =>{
          return  minIncidentYear
        }, 
        
        getMySDSToken: () => {
          return $http.get(`${__env.apiUrl}/api/utils/mysds-token/`).then((response) =>{
            MySDSToken = response.data.token
          })
        },
        sendMySDSToken: (token) => {
          payload = {token: token}
          return $http.post(`https://clients.mysds.ca/api.php`).then((response) =>{
            MySDSReply = response.data
          })
        },

        getMenuItems: () => {
          return $http.get(`${__env.apiUrl}/api/formnavigation/menu-items/`)
              .then((response) => {
                menuItems.length = 0
                for (var i = 0; i < response.data.length; i++) {
                  var nav = response.data[i]
                  
                  if (nav.subform) {
                    if (nav.SubformKey === 'hazard_action_protocol') {
                      nav.path = '/a/haps'
                      nav.report_id= '111'
                    } else if (nav.SubformKey === 'positive_identification_sub') {
                      nav.path = '/a/recognition'
                      nav.report_id= '111'
                    }
                      else if (nav.SubformKey === 'general_action') {
                      nav.path = '/a/gaps'
                      nav.report_id= '111'
                    }
                  }
                  if (nav.formDescriptionId == 1084) {
                    nav.path = '/a/lineup'
                  }
                  nav.active = () => {
                    return this.path === $location.path()
                  }
                  
                  if (nav.report_id == 166071){
                    nav.name = translateLabels(2249) // positive recognition report.              
                  }

                  if(nav.report_id == 131200) // "General Report"
                  nav.path  = '/a/forms/1397'
                  // 372298
                  if (nav.report_id != 372298 && nav.report_id != 0)
                    menuItems.push(nav)
                  // return menuItems
                }     
              }, (args) => {
                  console.log("This is the ERROR", args)
              })
        },
        readMenuItems: () => {
          return menuItems
        },

        readMySDSToken: () => {
          return MySDSToken
        },
        readMySDSReply: () => {
          return MySDSReply
        },

        getFormCategories: () => {
          return $http.get(`${__env.apiUrl}/api/formnavigation/form-categories/`).then((response) => {
            formCategories = response.data
          })
        },

        readFormCategories : () =>{
          return formCategories
        },

        getCreateMobileFormsPermission: () => {
          return $http.get(`${__env.apiUrl}/api/formnavigation/form-mobileforms/`);
        },   
      }
    }
  ])