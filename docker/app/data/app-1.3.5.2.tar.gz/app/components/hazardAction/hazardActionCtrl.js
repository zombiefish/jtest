safeToDo.component("hazardActionForm", {
    templateUrl: 'app/components/hazardAction/hazardAction.html',
    bindings: {
        modalId: '<',
        currentHazardAction: '<',
        mode: '<',
        hapModel: '<',
        incidentId: '<',
        onSave: '&',
        bindings: '&',    
        headerData: '<',   

    },
    controllerAs: 'vm2',
    controller: function ( $controller, $q, $scope, $rootScope, $element, $timeout, fileUploadService, modalService, select2Service, listService, profileService, actionManagementService, $compile, employeesService, settingsService,  $window, $rootScope, imageCommentService, menuService) {
        let vm2 = this
        $controller('distributionGroupCtrl', {$scope: $scope})
        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        vm2.siteList = []
        vm2.jobList = []
        vm2.jobListSelect = []
        vm2.levelList = []
        vm2.levelListSelect = []    
        vm2.hazardTypeList = []    
        vm2.actionTypeList = []
        vm2.identificationList = []
        vm2.employeeList = []
        vm2.supervisorList = []
        vm2.distributionList = []
        vm2.potentialLossList = []
        vm2.current_user_id = null        
        vm2.assignSingle = false
        vm2.newInitialAttachments = []
        vm2.hazUploadFileList = []
        vm2.checkRequired = true

        vm2.editAttachmentIndex= null

        vm2.componentTranslateLabels = (key) => {
            return translateTag(key)
        }
        menuService.getPagePermissions().then((data) => {
            vm2.permissions = data       
            vm2.canAssignMultipleUsersToActions =  vm2.permissions.includes('Can Assign Action to Multiple Users') ? true : false
        })

        //Function to close the modal
        vm2.closeModal = (modalId) => {       
            modalService.Close(modalId)
            createHazardAction()      
            resetFormFieldClassList('hazardForm')          
            refreshData()
            vm2.newInitialAttachments = []
            vm2.hazUploadFileList = []
            vm2.employeeList = []
            vm2.supervisorList = []
            vm2.distributionList = []
            $scope.$emit('CLOSEMODAL')
        }
        vm2.cancelModal = (modalId) => { 
            vm2.deleteInitPara=null
            modalService.Close(modalId)
        }

        
        let deleteIndex = null
        //Function to delete local attachments
        vm2.deleteInitialAttachment = (index) => {
            vm2.deleteInitPara={
                mode:'init',
                index: index
            }
            vm2.deleteAttachmentConfirmationModal(index)
            for (let image_index=0;image_index<vm2.newInitialAttachments.length;image_index++){
                if(vm2.newInitialAttachments[image_index].comment){
                    if(vm2.newInitialAttachments[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                } else {
                    let elem = document.getElementById('comment_' + image_index)
                    elem.classList.remove('fas')
                    elem.classList.add('far')
                }
            }    
        }

        //Function to open delete Attachment Confirmation Modal
        vm2.deleteAttachmentConfirmationModal = (index) => {
            deleteIndex = index
            vm2.modalElements = {
                title: translateTag(3416), //"Delete Attachment?"
                message:               
                `<div>          
                    <p ng-if=${vm2.deleteInitPara && vm2.deleteInitPara.mode=='init'} note="You are about to delete this attachment.Are you sure?">${translateTag(1452)}</p>
                    <p ng-if=${!vm2.deleteInitPara} note="You are about to delete this attachment. Undoing this will require IT support. Are you sure?">${translateTag(3635)}</p>
                </div>`, 
                buttons: 
                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            } 
            document.getElementById('confirmcallingform').innerHTML = 'HAZARDACTIONCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm2.modalElements)
        }

        $scope.$on("HAZARDACTIONCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm2.deleteExistingInitialAttachment(vm2.deleteInitPara)
            }
            else if (result=='button2') {
                vm2.cancelModal('confirmModal')
            }
        })

        //Function to delete existing attachments
        vm2.deleteExistingInitialAttachment = (deleteInitPara) => {
            if(deleteInitPara && deleteInitPara.mode=="init"){
                vm2.hazUploadFileList.splice(deleteInitPara.index, 1)
                vm2.newInitialAttachments.splice(deleteInitPara.index, 1)
            }
            else{
                let id = vm2.currentHazardAction.attachments[deleteIndex].id
                actionManagementService.removeHazardActionAttachment({haa_id: id}).then((res) =>{
                    vm2.currentHazardAction.attachments.splice(deleteIndex, 1)
                    let elem = document.getElementById('disk_comment_' + deleteIndex)
                    elem.classList.remove('fas')
                    elem.classList.add('far')
                    deleteIndex = null
                })
            }            
            modalService.Close('confirmModal')
            vm2.deleteInitPara=null
        }

        vm2.convertTime = (timestamp) =>{
            return moment(timestamp).format("YYYY-MM-DD hh:mm:ss a")
        }
       
        $scope.initialHazardFileUploadChanged  = (event)=> {

            let existingFileNames = []
            for(let i in vm2.hazUploadFileList) {
                existingFileNames.push(vm2.hazUploadFileList[i].name)
            }

            //Add newly selected files after checking for duplicates and correct file types
            vm2.hazUploadFileList = vm2.hazUploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, existingFileNames, true))

            //Get data from files to display in html
            fileUploadService.getFileUploadData(vm2.hazUploadFileList).then ((filesData) => {
                vm2.newInitialAttachments = filesData
                $scope.$apply() // Update html bindings
            })
        }

       $scope.checkAction = () =>{
            if(vm2.currentHazardAction.immediate_action_required_and_performed || vm2.currentHazardAction.further_action_required){          
                vm2.checkRequired = false 
            }
            else{
                vm2.checkRequired = true 
            }

            if(!vm2.currentHazardAction.immediate_action_required_and_performed){
                vm2.currentHazardAction.immediate_action_taken = ''
                vm2.currentHazardAction.immediate_action_type = null
            }

            if(!vm2.currentHazardAction.further_action_required){
                vm2.currentHazardAction.recommended_action = ''
                vm2.currentHazardAction.action_type = null
                vm2.currentHazardAction.action_by_who = null
                vm2.currentHazardAction.action_by_when= null
            }
            
            vm2.initializeSelect2()
        } 



        //Function to reset form to new
        function createHazardAction() {
            vm2.submitted = false
            vm2.currentHazardAction = {
                ID: null,
                HeaderDate: dateToday.format("YYYY-MM-DD"),
                Site: null,
                JobNumber: null,
                SiteLevel: null,
                Workplace: '',
                Supervisor: null,
                hazard_type: null,
                hazard_identification: null,
                hazard_description: '',
                potential_risk: null,
                immediate_action_required_and_performed: false,
                immediate_action_taken: '',
                further_action_required: false,
                recommended_action: '',
                immediate_action_type: null,
                action_by_who: null,
                action_type: null,
                action_complete_by_who: [],
                action_completed_date: null,
                action_by_when: null, 
                action_status: 'Incomplete',
                completed_action_taken:'',
                completed_action_type:null,
                hazard_identification_score: 0,
                potential_risk_score: 0,
                immediate_action_score: 0,
                completed_action_score: 0,
                attachments: [],
                distribution: [],
                sha_is_group_action: 'individual'
            }
        }
        
        vm2.$onChanges = () => {
            if(vm2.currentHazardAction && vm2.currentHazardAction.id != null){
                vm2.editHazardAction()
            }
            vm2.getJobsLevels('edit')
            vm2.newInitialAttachments = []
            vm2.hazUploadFileList = []
        }
        vm2.getFilteredEmployees = () =>{   
            profileService.filterEmployeeListonJob(vm2.currentHazardAction.JobNumber)
            vm2.employeeList =  profileService.readFilterEmployeeListonJob()
            profileService.filterSupervisorListonJob(vm2.currentHazardAction.JobNumber)
            vm2.supervisorList = profileService.readFilterSupervisorListonJob()
            profileService.filterDistributionListonJob(vm2.currentHazardAction.JobNumber)
            vm2.distributionList = profileService.readFilterDistributionListonJob()
        }



        //Function to get Jobs & Levels for a site
        vm2.getJobsLevels = (mode) => {

            vm2.jobListSelect = []
            vm2.levelListSelect = []

            if(vm2.currentHazardAction !== undefined){
                if(vm2.currentHazardAction.Site === undefined || vm2.currentHazardAction.Site === null){
                    vm2.currentHazardAction.JobNumber = null
                    vm2.currentHazardAction.SiteLevel = null
                    vm2.getFilteredEmployees()
                    return
                }
            }

            if(!vm2.currentHazardAction  || !vm2.siteList.some(t => t.rld_id === vm2.currentHazardAction.Site))
                return

            let mainSite = vm2.currentHazardAction.Site
            if(mode != 'edit') {
                vm2.currentHazardAction.JobNumber = null
                vm2.currentHazardAction.SiteLevel = null
            }            
            if(vm2.clonedActionData !== undefined && mainSite === vm2.clonedActionData.Site && vm2.siteList.some(t => t.rld_id === vm2.clonedActionData.Site && t.rld_historical)){    
                addHistoricalOption('hazard_job_number', vm2.jobListSelect, vm2.clonedActionData.JobNumber, vm2.clonedActionData.JobNumber_ltr_text)
                addHistoricalOption('hazard_level', vm2.levelListSelect, vm2.clonedActionData.SiteLevel, vm2.clonedActionData.SiteLevel_ltr_text)
                return
            }
            
            vm2.jobList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id === mainSite)
                    vm2.jobListSelect.push(rec)
            })
            vm2.levelList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id === mainSite)
                    vm2.levelListSelect.push(rec)
            })
        }

        //Function to submit hazard action
        vm2.submitHazardAction = () => {
            if(vm2.validateForm())
            {
                vm2.submitted = true
                if(vm2.mode === 'edit')
                {
                    getScores()
                    let payload = prepareHazardEditPayload(vm2.currentHazardAction)                    
                    let ufl = [...vm2.hazUploadFileList]
                    let att = [...vm2.newInitialAttachments]
                    actionManagementService.updateHazardAction(payload).then ((res) => {
                                                    
                            for (var i in ufl) {
                                let fd = new FormData()
                                fd.append("submission_hap_id", payload.ID)
                                fd.append("submission_hap_file", ufl[i])
                                fd.append("submission_hap_type", 'INITIAL')
                                fd.append("haa_image_timestamp", moment.unix(ufl[i].lastModified/1000).format('YYYY-MM-DD HH:mm:ss'))

                                if(ufl.length > 0) {
                                    actionManagementService.addHazardActionAttachments(fd).then((res) => {
                                             
                                     let sfiles = res.data.message["Successfull Files"]
                                   
                                     let attached_count = 0
     
                                    sfiles.allowed_original.forEach((attached) =>  {

                                         att.forEach((newA) =>{
                                             if(newA.comment){
                                                
                                                 if(attached==newA.file){
                                                     //call the add comment service.
                                                     newA.comment.com_reference_id = sfiles.ids[attached_count]
                                                     //call service to insert comment.
                                                     imageCommentService.saveComment(newA.comment)
     
                                                 }
                                             }
                                         })
                                         attached_count++
                                     })

                                        
                                   })
                                }
                            }
                            
                        })
                 

                        vm2.closeModal('hazardActionModal')
                        $scope.$emit('GENERAL_REFRESHDATA')
                        $scope.$emit('HAP_REFRESHDATA')
                        $scope.$emit('ADDACTION', vm2.currentHazardAction)
                        vm2.newInitialAttachments = []
                        vm2.hazUploadFileList = []

                } else {
                        let ufl = [...vm2.hazUploadFileList]
                        let att = [...vm2.newInitialAttachments]
                        getScores()
                        let payload = prepareHazardCreatePayload(vm2.currentHazardAction)
                        delete payload.ID
                        delete payload.attachments

                        if (window.location.href.includes("/tir") && vm2.incidentId) {
                            payload['incidentid'] = vm2.incidentId
                        }

                        if(vm2.canAssignMultipleUsersToActions==false){
                            vm.currentHazardAction.sha_action_by_who_per_id = [vm.currentHazardAction.sha_action_by_who_per_id]
                        }

                        if (!payload.HeaderDate)
                            payload.HeaderDate = dateToday.format('YYYY-MM-DDThh:mm')
                        
                        actionManagementService.createHazardAction(payload).then ((res) => {
                            vm2.currentHazardAction.ID = res.ID                           
                                
                                for (var i in ufl) {
                                    let fd = new FormData()
                                    fd.append("submission_hap_id", res['ID'])
                                    fd.append("submission_hap_file", ufl[i])
                                    fd.append("submission_hap_type", 'INITIAL')
                                    fd.append("haa_image_timestamp", moment.unix(ufl[i].lastModified/1000).format('YYYY-MM-DD HH:mm:ss'))


                                    if(ufl.length > 0) {

                                        actionManagementService.addHazardActionAttachments(fd).then((res) => {
                                            let sfiles = res.data.message["Successfull Files"]

                                            let attached_count = 0
            
                                            for(attached of sfiles.allowed_original){
                                                for(newA of att){
                                                    if(newA.comment){
                                                        if(attached==newA.file){
                                                            //call the add comment service.
                                                            newA.comment.com_reference_id = sfiles.ids[attached_count]
 
                                                            //call service to insert comment.
                                                            imageCommentService.saveComment(newA.comment)
            
                                                        }
                                                    }
                                                }
                                                attached_count++
                                            }
                                            
                                        })
 
                                    }
                                }
                                $scope.$emit('GENERAL_REFRESHDATA')
                                $scope.$emit('HAP_REFRESHDATA')
                                $scope.$emit('ADDACTION', vm2.currentHazardAction)
                                
                        })  
                        vm2.closeModal('hazardActionModal')
                    }
                              
            } else {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        function prepareHazardCreatePayload(payload) {
            let preparedPayload = {}

            preparedPayload.ID =  payload.id
            preparedPayload.submissionheaderid = payload.submissionheaderid
            
            if (!payload.HeaderDate)
                payload.HeaderDate = dateToday.format('YYYY-MM-DDThh:mm')

            preparedPayload.HeaderDate =  moment(payload.HeaderDate).format('YYYY-MM-DDThh:mm')
            preparedPayload.Site = payload.Site
            preparedPayload.JobNumber = payload.JobNumber
            preparedPayload.SiteLevel = payload.SiteLevel
            preparedPayload.Workplace = payload.Workplace
            preparedPayload.Supervisor = payload.Supervisor
            preparedPayload.hazard_type = payload.hazard_type
            preparedPayload.hazard_identification = payload.hazard_identification
            preparedPayload.hazard_description = payload.hazard_description
            preparedPayload.potential_risk = payload.potential_risk
            preparedPayload.immediate_action_required_and_performed = payload.immediate_action_required_and_performed
            if(!preparedPayload.immediate_action_required_and_performed) {
                preparedPayload.immediate_action_taken = ''
                preparedPayload.immediate_action_type = null
            } else {
                preparedPayload.immediate_action_taken = payload.immediate_action_taken
                preparedPayload.immediate_action_type = payload.immediate_action_type
            }
            preparedPayload.further_action_required = payload.further_action_required
            preparedPayload.recommended_action = payload.recommended_action            
            preparedPayload.action_by_who = payload.action_by_who
            preparedPayload.action_type = payload.action_type
            preparedPayload.action_by_when = payload.action_by_when
            preparedPayload.hazard_identification_score = payload.hazard_identification_score
            preparedPayload.potential_risk_score = payload.potential_risk_score
            preparedPayload.immediate_action_score = payload.immediate_action_score
            
            if (payload.sha_is_group_action == 'individual' ) {
                preparedPayload.sha_is_group_action = false
            } else if (payload.sha_is_group_action == 'group' ) {
                preparedPayload.sha_is_group_action = true
            }

            return preparedPayload


        }

        function prepareHazardEditPayload (payload) {
            let preparedPayload = {}

            preparedPayload.ID =  payload.id
            preparedPayload.submissionheaderid = payload.submissionheaderid
            
            if (!payload.HeaderDate)
                payload.HeaderDate = dateToday.format('YYYY-MM-DDThh:mm')

            preparedPayload.HeaderDate =  moment(payload.HeaderDate).format('YYYY-MM-DDThh:mm')
            preparedPayload.Site = payload.Site
            preparedPayload.JobNumber = payload.JobNumber
            preparedPayload.SiteLevel = payload.SiteLevel
            preparedPayload.Workplace = payload.Workplace
            preparedPayload.Supervisor = payload.Supervisor
            preparedPayload.hazard_type = payload.hazard_type
            preparedPayload.hazard_identification = payload.hazard_identification
            preparedPayload.hazard_description = payload.hazard_description
            preparedPayload.potential_risk = payload.potential_risk
            preparedPayload.immediate_action_required_and_performed = payload.immediate_action_required_and_performed
            if(!preparedPayload.immediate_action_required_and_performed)
            {
                preparedPayload.immediate_action_taken = ''
                preparedPayload.immediate_action_type = null
            }
            else
            {
                preparedPayload.immediate_action_taken = payload.immediate_action_taken
                preparedPayload.immediate_action_type = payload.immediate_action_type
            }
            preparedPayload.further_action_required = payload.further_action_required
            preparedPayload.recommended_action = payload.recommended_action            
            preparedPayload.action_by_who = payload.action_by_who
            preparedPayload.action_type = payload.action_type
            preparedPayload.action_by_when = payload.action_by_when
            preparedPayload.hazard_identification_score = payload.hazard_identification_score
            preparedPayload.potential_risk_score = payload.potential_risk_score
            preparedPayload.immediate_action_score = payload.immediate_action_score

            if (payload.sha_is_group_action == 'individual' ) {
                preparedPayload.sha_is_group_action = false
            } else if (payload.sha_is_group_action == 'group' ) {
                preparedPayload.sha_is_group_action = true
            }
            return preparedPayload
        }

        $scope.$on('CLOSEHAIMAGECOMMENTSMODAL',(event,data) => {

            let image_index = document.getElementById('relatedimageindex').innerText

            if(vm2.mode==='edit'){
                if(vm2.ImageFrom=='disk'){

                    vm2.currentHazardAction.attachments[vm2.editAttachmentIndex].com_comment= data.com_comment 
                    vm2.currentHazardAction.attachments[vm2.editAttachmentIndex].com_id=data.com_id
                    
                    if(vm2.currentHazardAction.attachments[vm2.editAttachmentIndex].com_comment !='' && vm2.currentHazardAction.attachments[vm2.editAttachmentIndex].com_comment != null){
                        let elem = document.getElementById('disk_comment_' + image_index)

                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('disk_comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                    
                }
                else if(vm2.ImageFrom =='memory'){
                   
                    vm2.newInitialAttachments[image_index].comment = data
                    vm2.newInitialAttachments[image_index].comment.com_reference_id = image_index

                    if(vm2.newInitialAttachments[image_index].comment){
                          if(vm2.newInitialAttachments[image_index].comment.com_comment !=''){
                            let elem = document.getElementById('comment_' + image_index)
                            elem.classList.remove('far')
                            elem.classList.add('fas')
                        } else {
                            let elem = document.getElementById('comment_' + image_index)
                            elem.classList.remove('fas')
                            elem.classList.add('far') 
                        }
                    }
                }
            }
            else
            {

                vm2.newInitialAttachments[image_index].comment = data
                vm2.newInitialAttachments[image_index].comment.com_reference_id = image_index

                if(vm2.newInitialAttachments[image_index].comment){
                    if(vm2.newInitialAttachments[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                }
            }

        })


        // this will update the scores for the three categories on the main object before submmitting
        function getScores() {
            // Potential Loss
            vm2.potentialLossList.forEach((rec)=> {
                if(rec.rld_id === vm2.currentHazardAction.potential_risk) {
                    vm2.currentHazardAction.potential_risk_score = rec.rld_score
                }
            })
            // Hazard Identification
            vm2.identificationList.forEach((rec)=> {
                if(rec.rld_id === vm2.currentHazardAction.hazard_identification) {
                    vm2.currentHazardAction.hazard_identification_score = rec.rld_score
                }
            })            
            // Immediate Action Type
            vm2.actionTypeList.forEach((rec)=> {
                if(rec.rld_id === vm2.currentHazardAction.immediate_action_type) {
                    vm2.currentHazardAction.immediate_action_score = rec.rld_score
                }
            }) 
        }

        //Function for form validation 
        vm2.validateForm = () => {
            let validated = validateFormFields('hazardForm')
            if(!vm2.checkRequired && validated)
                return true
            else
                return false
        }
        
        $scope.$on('distribution-list-added', (event, args) => {
            if(vm2.currentHazardAction !== undefined)
                $scope.$emit('addDistributionGroup', args, vm2.currentHazardAction.distribution)
        })

        $scope.$on('distribution-list-removed', (event, args) => {
            $scope.$emit('removeDistributionGroup',args)
        })

        vm2.editHazardAction = () =>{
            vm2.getFilteredEmployees()
            // cloning action data into new variable - to access the data when user modififes it accidentally
            vm2.clonedActionData = {...vm2.currentHazardAction}
            modifyCurrentHazardEditData()    
        }

        async function modifyCurrentHazardEditData() {         
            await addHistoricalOption('hazard_site', vm2.siteList, vm2.currentHazardAction.Site, vm2.currentHazardAction.Site_ltr_text)
            await addHistoricalOption('hazard_job_number', vm2.jobListSelect, vm2.currentHazardAction.JobNumber, vm2.currentHazardAction.JobNumber_ltr_text)
            await addHistoricalOption('hazard_level', vm2.levelListSelect, vm2.currentHazardAction.SiteLevel, vm2.currentHazardAction.SiteLevel_ltr_text)
            await addHistoricalOption('hazard_type', vm2.hazardTypeList, vm2.currentHazardAction.hazard_type, vm2.currentHazardAction.hazard_type_ltr_text)
            await addHistoricalOption('hazard_identification', vm2.identificationList, vm2.currentHazardAction.hazard_identification, vm2.currentHazardAction.hazard_identification_ltr_text)
            await addHistoricalOption('potential_loss1', vm2.potentialLossList, vm2.currentHazardAction.potential_risk, vm2.currentHazardAction.potential_risk_ltr_text)
            if(vm2.currentHazardAction.immediate_action_required_and_performed)
                await addHistoricalOption('immediate_action_type', vm2.actionTypeList, vm2.currentHazardAction.immediate_action_type, vm2.currentHazardAction.immediate_action_type_ltr_text)
            if(vm2.currentHazardAction.further_action_required)
                await addHistoricalOption('action_type', vm2.actionTypeList, vm2.currentHazardAction.action_type, vm2.currentHazardAction.action_type_ltr_text)
            await addHistoricalUserOption('action_supervisor', vm2.supervisorList, vm2.currentHazardAction.Supervisor, vm2.currentHazardAction.Supervisor_full_name)
            
            let by_who = [...vm2.currentHazardAction.action_by_who] 
            for(let l = 0; l < by_who.length; l++){

                await addHistoricalUserOption('action_by_who', vm2.employeeList, by_who[l], vm2.currentHazardAction.action_by_who_full_name[l])

            }

            if(vm2.currentHazardAction.immediate_action_required_and_performed || vm2.currentHazardAction.further_action_required){
                vm2.checkRequired = false
            }
            else{
                vm2.checkRequired = true
            }

            if(vm2.currentHazardAction.attachments){
                let image_index = 0
                vm2.currentHazardAction.attachments.forEach((attachment) => {
                    if(attachment.com_comment !='' && attachment.com_comment != null){
                        let elem = document.getElementById('disk_comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('disk_comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                    image_index++
                })    
            }
            $scope.$apply()
        }

        vm2.changeActionByWho = () => {
            if(vm2.currentHazardAction.action_by_who && vm2.currentHazardAction.action_by_who.length > 1 && vm2.mode ==='edit') {
                vm2.currentHazardAction.sha_is_group_action = 'group'
            }

        }


        const addHistoricalOption =  function (select, list, rld_id, ltr_text) {
            
            return new Promise((resolve, reject) => {
                if(rld_id && !list.some(t => t.rld_id === rld_id))
                {
                    let historicRecord = {}
                    historicRecord['rld_historical']= true
                    historicRecord['rld_id']= rld_id
                    let value = `${ltr_text} (${translateTag(8717)})` //Historical
                    if(select === 'hazard_job_number'){
                        historicRecord['fullJob']= value
                    }
                    else{
                        historicRecord['rld_name']= value
                    }
                    list.push(historicRecord)
                }
                if(select === 'hazard_site'){
                    vm2.getJobsLevels('edit')
                }                
                resolve(rld_id)
            })
        }

        const addHistoricalUserOption =  function (select, list, per_id, full_name) {
            return new Promise((resolve, reject) => {
                if(per_id && !list.some(t => t.per_id === per_id))
                {
                    let historicRecord = {
                        per_historical: true,
                        per_id: per_id,
                        per_full_name: `${full_name} (${translateTag(8717)})` //Historical                      
                    }
                    list.push(historicRecord)                 
                }
                resolve(per_id)
            })
        }
  
        $scope.$on('HARZARD_NEW_INCIDENT', () => {                 
            if(vm2.headerData.submission_header.length > 0){
                createHazardAction()               
                let h_data = vm2.headerData.submission_header[0]                
                vm2.currentHazardAction.HeaderDate = h_data.Header_date
                vm2.currentHazardAction.Supervisor = parseInt(h_data.supervisor)
                vm2.currentHazardAction.Workplace = h_data.workplace
                let check_site = vm2.siteList.find(rec => rec.rld_id === h_data.site);                
                if(check_site){                    
                    vm2.currentHazardAction.Site = h_data.site
                    vm2.getJobsLevels()
                }
                let check_job = vm2.jobList.find(rec => rec.rld_id === h_data.jobnumber);
                if(check_job){
                    vm2.currentHazardAction.JobNumber = h_data.jobnumber
                    vm2.getFilteredEmployees()
                }
                let check_level = vm2.levelList.find(rec => rec.rld_id === parseInt(h_data.sitelevel));                
                if(check_level){
                    vm2.currentHazardAction.SiteLevel = parseInt(h_data.sitelevel)
                }
                $scope.$apply()                
            }            
        })

        //Function to refresh all data
        function refreshData() {
            $q.all([
                listService.getSelectListData('ref_site'),
                listService.getSelectListData('ref_job'),
                listService.getSelectListData('ref_level'),
                listService.getSelectListData('ref_action_type'),
                listService.getSelectListData('ref_hazard_identification'),
                listService.getSelectListData('ref_potential_loss'),
                listService.getSelectListData('ref_hazard_type'),
                profileService.getAllEmployeeProfile(),
                profileService.getAllSupervisorProfile(),
                profileService.getDistributionList(),
                employeesService.getPersonProfile(),
                profileService.getFullEmployeeProfile()            
            ]).then((data) => {   
                createHazardAction()

                vm2.siteList = data[0]                
                vm2.jobList = data[1]
                vm2.jobList.forEach((job)=>{
                    job.fullJob = `(${job.rld_code}) - ${job.rld_name}`
                })
                vm2.levelList = data[2]
                vm2.actionTypeList = data[3]
                vm2.identificationList = data[4]
                vm2.potentialLossList = data[5]
                vm2.hazardTypeList = data[6]
                vm2.current_user_id = data[10].per_id                  
                vm2.fullEmployeeList = profileService.readFullEmployeeProfile()
            }).then((data)=>{                
                settingsService.getUserProfile(vm2.current_user_id).then((response) => {                       
                    vm2.siteList.forEach((rec)=>{
                        if(response.upr_site===rec.rld_id){                            
                            vm2.currentHazardAction.Site = response.upr_site
                            vm2.getJobsLevels()                            
                        }
                    })
                    vm2.jobListSelect.forEach((rec)=>{
                        if(response.upr_job==rec.rld_id){
                            vm2.currentHazardAction.JobNumber = response.upr_job                            
                            vm2.getFilteredEmployees()
                        }
                    })                    
                    vm2.levelListSelect.forEach((rec) => {
                        if(response.upr_level === rec.rld_id){
                            vm2.currentHazardAction.SiteLevel = response.upr_level                            
                        }
                    })
                    vm2.supervisorList = vm2.supervisorList ? vm2.supervisorList : []
                    vm2.supervisorList.forEach((rec)=>{
                        if(response.upr_supervisor_per === rec.per_id){
                            vm2.currentHazardAction.Supervisor = response.upr_supervisor_per
                        }
                    })   
                    if(response.distribution_list){
                        let email_list = []
                        response.distribution_list.forEach((d)=> {
                            email_list.push(d.email)
                        })
                        vm2.currentHazardAction.distribution = email_list
                    }                                        
                })
            })
        }
        refreshData()

        vm2.initializeSelect2 = ()=> {
            setTimeout(()=>{
            $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#hazardActionModal .modal-body`), escapeMarkup: function (text) { return text } })
                .on('select2:select', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list'))
                        $rootScope.$broadcast('distribution-list-added', event)
                    $(this).parent().find('label').addClass('filled')   
                })
                .on('select2:unselect', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list'))
                        $rootScope.$broadcast('distribution-list-removed', event)
                    $(this).parent().find('label').addClass('filled')
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()
            }, 500)
            $('.datepicker').pickadate({
                format: 'yyyy-mm-dd',
                onClose : function(){
                    this.$holder.blur()
                },
            }).removeAttr('readonly')
            .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                evt.preventDefault()
            })
        }

        vm2.AddComments = (index, from) => {
            document.getElementById('mode').innerText = ''
            document.getElementById('relatedimageindex').innerText = index
            document.getElementById('callingform').innerText = 'CLOSEHAIMAGECOMMENTSMODAL'
            document.getElementById('parentform').innerHTML = 5 // SubmissionHap Module	SubmissionHAPAttachments
            document.getElementById('savetomemory').innerHTML = "true"       

            vm2.ImageFrom = from
            if(vm2.mode ==='edit'){

                if(vm2.ImageFrom=='disk'){
                    // updating the comments only from the disk
                    vm2.editAttachmentIndex = index
                    if(vm2.currentHazardAction.attachments[index].com_comment || vm2.currentHazardAction.attachments[index].com_id){                 
                        document.getElementById('mode').innerText = vm2.mode
                        document.getElementById('savetomemory').innerHTML = "false"                      
                        document.getElementById('comment_id').innerHTML = vm2.currentHazardAction.attachments[index].com_id
                        document.getElementById('imageid').innerHTML = vm2.currentHazardAction.attachments[index].id 
                        document.getElementById('condition').innerHTML = ''
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS", vm2.currentHazardAction.attachments[index].com_comment)                        
                    } 
                    else{
                        document.getElementById('mode').innerText = vm2.mode
                        document.getElementById('savetomemory').innerHTML = "false"
                        document.getElementById('condition').innerHTML = 'AddCommentOnEmptyExistingImage'
                        document.getElementById('comment_id').innerHTML = vm2.currentHazardAction.attachments[index].com_id
                        document.getElementById('imageid').innerHTML = vm2.currentHazardAction.attachments[index].id  
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS", vm2.currentHazardAction.attachments[index].com_comment)
                    }
                }
                else if(vm2.ImageFrom=='memory'){
                    if(vm2.newInitialAttachments[index].comment){
                        document.getElementById('comment').value = vm2.newInitialAttachments[index].comment.com_comment
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm2.newInitialAttachments[index].comment.com_comment)
                    }
                    else{
                        document.getElementById('imageid').innerHTML = ''
                        document.getElementById('comment').value = ''
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                    }
                }
                else{
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                }
            }
            else{
                if(vm2.newInitialAttachments[index].comment){
                    document.getElementById('comment').value = vm2.newInitialAttachments[index].comment.com_comment
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm2.newInitialAttachments[index].comment.com_comment)
                } else{
                    document.getElementById('imageid').innerHTML = ''
                    document.getElementById('comment').value = ''
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                }
            }
        }
    }
})