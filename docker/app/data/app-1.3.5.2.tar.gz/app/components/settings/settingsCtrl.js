'use strict';
safeToDo.component("settingsForm", {
  // styling found in avatar.css
  templateUrl: 'app/components/settings/settings.html',
  // bindings: {    
  // },
  controllerAs: 'vm',

  controller: ['$compile', '$scope', '$timeout', '$q', '$sce', 'lineupService', 'listService', 'modalService','profileService', 'settingsService', 'employeesService', '$rootScope', 'select2Service',
    function ($compile, $scope, $timeout, $q, $sce, lineupService, listService, modalService, profileService, settingsService, employeesService, $rootScope, select2Service) {
      var vm = this
      vm.$onInit = () => {        
        vm.resetForm()
        refreshData()
        // get_user_profile()
        vm.headerValidation = true
        vm.initializeSelect2('settingsForm')              
      }

      vm.getToday = () => {
        return new Date().toJSON().slice(0, 10).replace(/-/g, '-');
      }
      vm.sites = []      
      vm.jobs = []
      vm.jobListSelect = []
      vm.levels = []  
      vm.levelSelect = []    
      vm.supervisorList = []
      vm.employeeList = []
      vm.disableSaveButton = false
      vm.showSubmit = true
      vm.showCancelModal = true
      vm.hidingSettingsViewer = false
      vm.openingSettingsViewer = false
      vm.warningMessage=true
      vm.loadMessage = translateTag(3965) // "Loading user profile settings.."
      // vm.themes = __env.themes
      // vm.languages =__env.languages
      vm.themes = [];

      vm.resetForm=  ()=> {
        vm.themes = [          
          {
             id: 'light',
             label: translateTag(3511)
          }
        ];

        vm.form = {
          settings: {
            upr_id: null,
            upr_per_id: null,
            upr_language:'',
            upr_theme_app:'',
            upr_site: '',
            upr_job: '',
            upr_supervisor_per: '',  
            upr_level:'',
            distribution_list:[],  
          }
        };
        
      }

      vm.closeViewer = () => {  
        vm.hidingSettingsViewer = true
        
      }   
      
      vm.getFilteredEmployees = () =>{            
        profileService.filterEmployeeListonJob(vm.form.settings.upr_job)
        vm.employeeList =  profileService.readFilterEmployeeListonJob()
        profileService.filterSupervisorListonJob(vm.form.settings.upr_job)
        vm.supervisorList = profileService.readFilterSupervisorListonJob()
        profileService.filterDistributionListonJob(vm.form.settings.upr_job)
        vm.distributionList = profileService.readFilterDistributionListonJob()
    }

      vm.applySettings = () => {
          settingsService.updateUserProfile(vm.prepareUserProfilePayload(vm.form.settings)).then((response) => {
            vm.loadMessage = translateTag(3794) // "Saving user profile settings"
            var expires = new Date()
			      expires.setFullYear(expires.getFullYear() + 2)
            document.cookie = "lang=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
            document.cookie = "lang=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/a;";
            document.cookie = `lang=${vm.form.settings.upr_language}; expires=${expires.toUTCString()}; path=/`
            vm.languages.forEach((rec)=>{
              if(rec.lng_name == vm.form.settings.upr_language) {
                localStorage.setItem('lang_id', rec.lng_id)
              }
            })
            vm.closeViewer()
            location.reload()
          })
      }

      vm.prepareUserProfilePayload = (payload) => {
        // making sure not sending undefined values as payload to backend.
        let data = {}        
        data.upr_language = payload.upr_language ? payload.upr_language : null
        data.upr_site_id = payload.upr_site ? payload.upr_site : null
        data.upr_job_id = payload.upr_job ? payload.upr_job : null
        data.upr_level_id = payload.upr_level ? payload.upr_level : null
        data.upr_supervisor_per_id = payload.upr_supervisor_per ? payload.upr_supervisor_per : null
        data.upr_theme_app = 'light' // there is no significnce for this field yet in APP. Hardcoded for now as a default value
        data.distribution_list = payload.distribution_list ? payload.distribution_list : []

        return data
      }

      vm.initializeSelect2 = (parent, section='')=> {
          setTimeout(()=>{ 
          $('.select-single, .select-multiple')
          .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} ${section}`), escapeMarkup: function (text) { return text } })
          .on('select2:select', (event) => {
              if (event.target.parentNode.querySelector('.distribution-list')){
                  $rootScope.$broadcast('distribution-list-added', event)
              }
              $(this).parent().find('label').addClass('filled')
          })
          .on('select2:unselect', (event) => {
              if (event.target.parentNode.querySelector('.distribution-list')){
                  $rootScope.$broadcast('distribution-list-removed', event)
              }
              $(this).parent().find('label').addClass('filled')
          })
          $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
          select2Service.select2Tags()
          if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
          $('.datepicker').pickadate({
            format: 'yyyy-mm-dd',
            onClose : function(){
              this.$holder.blur()
          },
          }).removeAttr('readonly')
          .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
            evt.preventDefault()
          })
          }, 100)
      }

      $scope.$on('distribution-list-added', (event, args) => {      
        if(vm.form !== undefined ||vm.form.settings !== undefined)  
          $scope.$emit('addDistributionGroup', args, vm.form.settings.distribution_list)
      })

      $scope.$on('distribution-list-removed', (event, args) => {
          $scope.$emit('removeDistributionGroup',args)
      })
      

      vm.translateLabels = (key) =>{      
        return translateTag(key)
      }      

      function refreshData(){
        $scope.$emit('STARTSPINNER', vm.loadMessage)
        $q.all([
          listService.getSelectListData('ref_site'),
          listService.getSelectListData('ref_job'),
          listService.getSelectListData('ref_level'),
          profileService.getAllSupervisorProfile(),
          settingsService.getEmployeesList(),
          employeesService.getPersonProfile(),
          settingsService.getLanguageList(),
          profileService.getDistributionList()
          ]).then((data) => {            
            vm.sites = data[0]
            vm.jobs = data[1]
            vm.jobs.forEach((job)=>{
              job.fullJob = `(${job.rld_code}) - ${job.rld_name}`
            })
            vm.levels = data [2]
            vm.current_user_per_id = data[5].per_id                        
            vm.languages = settingsService.readLanguagesList()
            vm.initializeSelect2('settingsForm')
            
          }).then(() => {            
            settingsService.getUserProfile(vm.current_user_per_id).then((response)=>{
              if(response!=="Record doesn't exist")
              {
                vm.form.settings = response
                vm.prepare_user_profile()                
              }
            })
            $scope.$emit('STOPSPINNER')
          })
      }      

      vm.prepare_user_profile = () => {      
        
        // checking user_visbility - if default site selected is not in vm.sites, then set upr_site to null.
        // do same for level and job
        let site_ids = []
        let job_ids = []
        vm.sites.forEach((site) => {site_ids.push(site.rld_id)})
        vm.jobs.forEach((job) => {job_ids.push(job.rld_id)})       

        if(site_ids.includes(vm.form.settings.upr_site) === false){
          vm.form.settings.upr_site=null
          vm.form.settings.upr_level=null
          vm.form.settings.upr_job = null
        }
        else if(vm.form.settings.upr_site !== null){
          vm.getJobsLevels()
        }
        
        // filter employees on employyevisibility only if upr_job is not null or undefined
        if(vm.form.settings.upr_job !== null && vm.form.settings.upr_job !== undefined){
          vm.getFilteredEmployees()
        }

        vm.form.settings.distribution_list = get_dlist(vm.form.settings.distribution_list)
        
        vm.initializeSelect2('settingsForm') 
      }

      function get_dlist (values){
          let dlist = []
          values.forEach ((rec) => {
            dlist.push(rec.email)
          })
          return dlist
      }
      
      vm.getJobsLevels = () => {        
        vm.jobListSelect = []     
        vm.jobs.forEach((rec) => {
            if(rec.rld_parent_detail_rld_id == vm.form.settings.upr_site)
                vm.jobListSelect.push(rec)
        })
        vm.levelSelect = []
        vm.levels.forEach((rec) => {
          if(rec.rld_parent_detail_rld_id == vm.form.settings.upr_site)
            vm.levelSelect.push(rec)
        })
      }      
    }
  ]
});