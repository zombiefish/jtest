﻿angular
  .module('safeToDo')
  .service('settingsService', ['$http', '$q',
    function ($http, $q) {
      let sites = []
      let fullJobs = []
      let fullLevels = []
      let allData = []
      let employees = []
      let employeeList = []
      let PPETypeList = [];
      let lineupJRAWorkplaceSteps = []
      let editLineupData = []
      let lineupData = []
      let lineupJRAListData = []
      let lineupJRAStepData = []
      let editWorkplaceData = []
      let editWorkersData = []
      let editMachineData = []
      let editPPEData = []
      let crewTypeList = []
      return {
        
        // retrieves the employee list
        getEmployeesList: () =>{
          return $http.get(`${__env.apiUrl}/api/employee/get-employee-list-profile/`).then((response) => {
            response.data.forEach((data) => {
              employees[data.per_id] = data.per_full_name
            })
            employeeList = response.data
          })
        },

         // retrieves all the languages
         getLanguageList: () =>{
          return $http.get(`${__env.apiUrl}/api/settings/get-languages/`).then((response) => {
            languageList = response.data
          })
        },

        // get-user-profile/<int:pk>/</int>
        getUserProfile: (payload) => {
          return  $http.get(`${__env.apiUrl}/api/settings/get-user-profile/${payload}/`).then((response) =>{ 
            return response.data
           }, (error) => { 
             console.log(error)
            })
        },

        updateUserProfile: (payload) => {          
          return  $http.post(`${__env.apiUrl}/api/settings/update-user-profile/`, payload).then((response) =>{
            return response
           }, (error) => { 
             console.log(error)
            })
        },

        // Get the complete Employee List
        readEmployeesList: () => {
          return employeeList;
        },

        // Get the complete Language list
        readLanguagesList: () => {
          return languageList;
        },
      }
      // end of Service
    }
  ])