safeToDo.component("mobileFrame", {
    templateUrl: 'app/components/mobileFrame/mobileFrame.html',
    bindings: {
        onSave: '&',
        onClose: '&',
        headerData: '<',
    },
    controllerAs: 'vm',
    controller: function ($q, $scope, $rootScope, $controller, $cookies, $sce, $timeout, $window,) {
        let vm = this

        vm.iframe = null
        vm.frameOpen = false
        vm.frameOpening = false
        vm.frameClosing = false
        vm.indexLoaded = false
        vm.mobileURL = $sce.trustAsResourceUrl(`${__env.mobileURL}login.html?fromApp=true`);
        vm.mobileFormId = null
        vm.frameExpanded = true
        vm.canExpandFrame = $window.innerWidth > 960
        vm.incidentId = null
        vm.moduleId = null

        vm.componentTranslateLabels = (key) => {
            return translateTag(key)
        }

        $scope.$on("OPENMOBILEFRAME", (event, message) => {
            vm.mobileFormId = message.activeFormID
            if(message.incidentId){
                vm.incidentId = message.incidentId
            }
            if(message.moduleId){
                vm.moduleId = message.moduleId
            }
            vm.frameOpening = true
            vm.frameOpen = true

            vm.iframe = document.getElementById("mobileFrame")

            if(vm.indexLoaded)
                sendMobileForm()
            
            $timeout(() => {
                vm.frameOpening = false
            }, 400)
        })

        vm.closeMobileFrame = () => {
            vm.frameOpening = false
            $timeout(() => {vm.frameClosing = true},1)

            $timeout(() => {
                vm.frameOpen = false
                vm.frameClosing = false
                vm.mobileFormId = null
            }, 400)
        }

        window.addEventListener('message', function (e) {
            if(e.data.includes("mobile-frame-close") || e.data.includes("mobile-loaded") || e.data.includes("index-loaded") || e.data.includes("mobile-frame-submit")){
                let message = JSON.parse(e.data)
                switch (message.name) {
                    case "mobile-frame-close":
                        vm.closeMobileFrame()
                        break
                    case "mobile-loaded":
                        $rootScope.$emit('MOBILE-LOADED')
                        break                        
                    case "index-loaded":
                        vm.indexLoaded = true
                        if(vm.frameOpen)
                            sendMobileForm()
                        break
                    case "mobile-frame-submit":
                        vm.closeMobileFrame()
                        $timeout(() => { // Delay for the mobile frame to close
                            $rootScope.$broadcast('REFRESH_FORMSUBMISSIONS')
                        }, 400)
                        break
                }
            }
        })

        sendMobileForm = () => {
            let message = {
                name: "mobile-form-id",
                data: 
                {
                    "mobileFormId":vm.mobileFormId,
                    "incidentId":vm.incidentId,
                    "moduleId": vm.moduleId
                }
            }
            vm.iframe.contentWindow.postMessage(JSON.stringify(message), '*')
        }

        vm.toggleCollapse = () => {
            vm.frameExpanded = !vm.frameExpanded
            $cookies.put('mobile-frame-expanded', vm.frameExpanded)
        }

        getFrameExpanded = () => {
            if ($cookies.get('mobile-frame-expanded') !== undefined && $cookies.get('mobile-frame-expanded') !== '') {
              vm.frameExpanded = ($cookies.get('mobile-frame-expanded') === 'true')
            } else {
              vm.frameExpanded = false
            }
            
            if (!vm.canExpandFrame)
                vm.frameExpanded = false

            $cookies.put('mobile-frame-expanded', vm.frameExpanded)
        }
        getFrameExpanded()

        $(window).on('resize', () => {
            vm.canExpandFrame = $window.innerWidth > 960

            if (!vm.canExpandFrame)
                vm.frameExpanded = false
        })
    }
})