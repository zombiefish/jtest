safeToDo.component("completeGeneralActionForm", {
    templateUrl: 'app/components/completeGeneralAction/completeGeneralAction.html',
    bindings: {
        modalId: '<',
        generalFollowup: '<',
        onSave: '&',
        onClose: '&'
    },
    controllerAs: 'vm',
    controller: function ($q, $scope, $element, $timeout, $filter, $compile, modalService, listService, profileService, actionManagementService, $rootScope, fileUploadService, imageCommentService) {
        let vm = this
        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        vm.newFollowupAttachments = []
        vm.genUploadFileList = []

        
        //Function to close the modal
        vm.closeModal = (modalId) => {
            modalService.Close(modalId)
            resetFormFieldClassList('generalCompleteForm')
            vm.submitted = false
            $scope.$emit('CLOSEMODAL')
        } 
        
        //Function to delete attachments
        vm.deleteFollowupAttachment = (index) => {  
            vm.deleteAttachmentConfirmationModal(index)  
            for (let image_index=0;image_index<vm.newFollowupAttachments.length;image_index++){
                if(vm.newFollowupAttachments[image_index].comment){
                    if(vm.newFollowupAttachments[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                } else {
                    let elem = document.getElementById('comment_' + image_index)
                    elem.classList.remove('fas')
                    elem.classList.add('far')
                }
            }    


        }

        vm.deleteIndex = null
        //Function to open delete Attachment Confirmation Modal
        vm.deleteAttachmentConfirmationModal = (index) => {
            vm.deleteIndex = index
            vm.modalElements = {
                title: translateTag(3416),  //"Delete Attachment?"
                message: `<div><p>${translateTag(1452)}</p></div>`, //"You are about to delete this attachment.Are you sure?"
                buttons: 
                    `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                    <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'CGACALLCONFIRMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("CGACALLCONFIRMODAL", (event,result) => {
            if (result=='button1') {
                vm.deleteInitAttachmentAfterConfirmation(vm.deleteIndex)
            }
        })

        //Function to delete initial attachments after click "ok" in Confirmation modal
        vm.deleteInitAttachmentAfterConfirmation = (index) => {
            vm.genUploadFileList.splice(index, 1)
            vm.newFollowupAttachments.splice(index, 1)     
            vm.deleteIndex = null
            modalService.Close('confirmModal')
        }

        //#region Functions to handle attachment uploads
        $scope.followupGeneralFileUploadChanged = (event)=> {

            let existingFileNames = []
            for(let i in vm.genUploadFileList) {
                existingFileNames.push(vm.genUploadFileList[i].name)
            }

            //Add newly selected files after checking for duplicates and correct file types
            vm.genUploadFileList = vm.genUploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, existingFileNames, true))
            
            //Get data from files to display in html
            fileUploadService.getFileUploadData(vm.genUploadFileList).then ((filesData) => {
                vm.newFollowupAttachments = filesData
                $scope.$apply() // Update html bindings
            })
        }

       vm.$onChanges = () => {        
            vm.newFollowupAttachments = []      
            vm.genUploadFileList = []
        }        
   

        //Function to complete genral action
        vm.closeGeneralFollowup = () => {
            resetFormFieldClassList('generalCompleteForm')
            
            if(vm.validateForm()) {
                vm.submitted = true
                payload = { 
                    sga_id: vm.generalFollowup.sga_id,
                    sga_action_is_complete: 1,
                    sga_completed_action_type_rld_id: vm.generalFollowup.sga_completed_action_type_rld_id,
                    sga_completed_action_by_who_per_id: vm.generalFollowup.sga_completed_action_by_who_per_id,
                    sga_completed_action_date: vm.generalFollowup.sga_completed_action_date,
                    sga_completed_action_taken: vm.generalFollowup.sga_completed_action_taken
                }
                vm.attachmentServiceResponse = null

                actionManagementService.closeGeneralAction(payload).then((res) => {
                    for (var i in vm.genUploadFileList) {
                        let fd = new FormData()
                        fd.append("sga_id", vm.generalFollowup.sga_id)
                        fd.append("gaa_file", vm.genUploadFileList[i])
                        fd.append("gaa_type", 'FOLLOWUP')
                        fd.append("gaa_image_timestamp",moment.unix(vm.genUploadFileList[i].lastModified/1000).format('YYYY-MM-DD HH:mm:ss'))
                           
                        if(vm.genUploadFileList.length > 0){
                            actionManagementService.addGeneralActionAttachments(fd).then((res) => {
                                vm.attachmentServiceResponse = res
                                let sfiles = res.data["Successfull Files"]
                                    let attached_count = 0
                                    sfiles.allowed_original.forEach((attached) =>  {
                                        vm.newFollowupAttachments.forEach((newA) =>{
                                            if(newA.comment){
                                                if(attached==newA.file){
                                                    //call the add comment service.
                                                    newA.comment.com_reference_id = sfiles.ids[attached_count]                                                    
                                                    //call service to insert comment.
                                                    imageCommentService.saveComment(newA.comment)    
                                                }
                                            }
                                        })
                                        attached_count++
                                    })
                            })
                        }
                        else {                            
                        }
                    }
                    $scope.$emit('COMPLETEACTION', vm.generalFollowup)
                    if(vm.genUploadFileList.length > 0){
                        $scope.$emit('GENERAL_REFRESHDATA', vm.attachmentServiceResponse)
                    }
                    vm.closeModal('completeGeneralActionModal')
                })                
            } else {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }        

        vm.convertTime = (timestamp) =>{
            return moment(timestamp).format("YYYY-MM-DD hh:mm:ss a")
        }

        vm.componentTranslateLabels = (key) => {
            return translateTag(key)
        }

        $scope.$on('GENERAL_FOLLOWUP_OPENED', () => {
            vm.generalFollowup.sga_completed_action_type_rld_id = addHistoricalOption('complete_action_type', vm.actionTypeList, vm.generalFollowup.sga_completed_action_type_rld_id, vm.generalFollowup.sga_completed_action_type_ltr_text)            
            profileService.filterEmployeeListonJob(vm.generalFollowup.JobNumber)
            vm.employeeList =  profileService.readFilterEmployeeListonJob()
            $scope.$apply()
        })

        function addHistoricalOption (select, list, rld_id, ltr_text) {
            if(rld_id && !list.some(t => t.rld_id === rld_id))
            {
                let historicRecord = {
                        rld_historical: true,
                        rld_id: rld_id,
                        rld_name: `${ltr_text} (${translateTag(8717)})` //Historical
                }
                list.push(historicRecord)
                $(`#${select}`).trigger('change')                
            }
            return rld_id
        }

        //Function for form validation
        vm.validateForm = () => {
            return validateFormFields('generalCompleteForm')
        }

        vm.$onInit= () => {
            listService.getSelectListData('ref_general_action').then((res) => {
                vm.actionTypeList = res
            })
            profileService.getAllEmployeeProfile().then((res)=>{
                vm.employeeList = profileService.readAllEmployeeProfile()                
            })
        }


        // functions to add comments to images
        vm.AddComments = (index, from) => {            
            document.getElementById('mode').innerText = ''
            document.getElementById('relatedimageindex').innerText = index
            document.getElementById('callingform').innerText = 'CLOSECOMPLTEGENERALACTIONIMAGECOMMENTSMODAL'
            document.getElementById('parentform').innerHTML = 7 // SubmissionHap Module	SubmissionHAPAttachments
            document.getElementById('savetomemory').innerHTML = "true"            

            vm.ImageFrom = from                             

            if(vm.ImageFrom=='memory'){                
                if(vm.newFollowupAttachments[index].comment){
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.newFollowupAttachments[index].comment.com_comment)
                    document.getElementById('comment').value = vm.newFollowupAttachments[index].comment.com_comment
                }
                else{
                    document.getElementById('imageid').innerHTML = ''
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                    document.getElementById('comment').value = ''
                }
            }
            else{
                if(vm.newFollowupAttachments[index].comment){
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.newFollowupAttachments[index].comment.com_comment)
                    document.getElementById('comment').value = vm.newFollowupAttachments[index].comment.com_comment
                }
                else{
                    document.getElementById('imageid').innerHTML = ''
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                    document.getElementById('comment').value = ''
                }
            }  
        }

        $scope.$on('CLOSECOMPLTEGENERALACTIONIMAGECOMMENTSMODAL',(event,data) => {                  
            let image_index = document.getElementById('relatedimageindex').innerText            
            if(vm.mode==='edit'){
                if(vm.ImageFrom=='disk'){                    
                    vm.hapModel.attachments[vm.editAttachmentIndex].com_comment= data.com_comment     
                    
                    if(vm.hapModel.attachments[vm.editAttachmentIndex].com_comment !='' && vm.hapModel.attachments[vm.editAttachmentIndex].com_comment != null){
                        let elem = document.getElementById('disk_comment_' + image_index)                        
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('disk_comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                    
                }
                else if(vm.ImageFrom =='memory'){
                   
                    vm.newFollowupAttachments[image_index].comment = data
                    vm.newFollowupAttachments[image_index].comment.com_reference_id = image_index                    
                    if(vm.newFollowupAttachments[image_index].comment){                        
                        if(vm.newFollowupAttachments[image_index].comment.com_comment !=''){
                            let elem = document.getElementById('comment_' + image_index)                            
                            elem.classList.remove('far')
                            elem.classList.add('fas')
                        } else {
                            let elem = document.getElementById('comment_' + image_index)
                            elem.classList.remove('fas')
                            elem.classList.add('far') 
                        }
                    }
                }
            }
            else
            {                                
                vm.newFollowupAttachments[image_index].comment = data
                vm.newFollowupAttachments[image_index].comment.com_reference_id = image_index               
             
                if(vm.newFollowupAttachments[image_index].comment){
                    if(vm.newFollowupAttachments[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                }
            }

        })
        // end functions to add comments to images        
        
    }
})