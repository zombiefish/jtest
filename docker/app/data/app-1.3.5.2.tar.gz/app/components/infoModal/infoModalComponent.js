safeToDo.component("infoModalComponent", {
    templateUrl: 'app/components/infoModal/infoModal.html',
    bindings: {
        currentInfo: '<',
        onSave: '&',
        bindings: '&',
    },
    controllerAs: 'vm',
    controller: function ( $controller, $q, $scope, $rootScope, $element, $timeout, modalService) {
        let vm = this

        vm.closeModal = (modalId) => { 
            modalService.Close(modalId)
        }

        vm.componentTranslateLabels = (key) => {
            return translateTag(key)
        }

    }
})