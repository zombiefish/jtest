'use strict'
safeToDo.component("topTenWidgetForm", {
    templateUrl: 'app/components/topTenWidget/topTenWidget.html',
    bindings: {
        data: "@",
        title: "@",
        subTitle: "@",
        infoData: "@"
    },
    controllerAs: 'vm',
    controller: function ($scope, $q,$element, $timeout, $filter, modalService) {
        let vm = this
        let dateToday = moment(new Date(), 'YYYY-MM-DD')      

        vm.$onInit = () => {
            vm.data = vm.data.replaceAll("|quote|", "'")
            vm.widgetData = JSON.parse(vm.data)
        }
        vm.translateLabels = (key) =>{      
            return translateTag(key)
        }

        vm.openInfoModal = (infoObject) => {
            $scope.$emit('OPEN_INFO_MODAL', infoObject)
        }
    }
})