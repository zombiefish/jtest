﻿'use strict';
angular
    .module('safeToDo')
    .service('jobFilterService', ['$window', '$http', '$rootScope', '$q', 'employeesService', 'supervisorsService', 'profileService', 'listService', 
        function ($window, $http, $rootScope, $q, employeesService, supervisorsService, profileService, listService) {
            let allSites = []
            let allJobs = []
            let allEmployees = []            
            let svc = {
                supervisors: [],
                supervisorLookup: [],
                jobLookup: {
                    clear: function () {
                        for (var key in this) {
                            if (typeof this[key] != 'function') delete this[key];
                        }
                    }
                },
                jobs: [],
                closedJobs: [],                
                outputFilterChange: (data) => {
                    let jobIdArray = svc.getFlatJobIdArray()
                    let supervisorArray = svc.getFlatSupervisorArray()
                    $window.sessionStorage.setItem('supervisors', JSON.stringify(supervisorArray))
                    $rootScope.$broadcast('job-filter-changed', { jobIds: jobIdArray, supervisors: supervisorArray })
                },
                getFlatJobIdArray: () => {
                    function extractActiveJobIdArray(siteArray) {
                        let activeJobIds = []
                        for (let s = 0; s < siteArray.length; s++) {
                            let siteRef = siteArray[s]
                            for (let j = 0; j < siteRef.Jobs.length; j++) {
                                let jobRef = siteRef.Jobs[j]
                                if (jobRef.LinkActive) {
                                    activeJobIds.push(jobRef.JobId)
                                }
                            }
                        }
                        return activeJobIds
                    }
                    $window.sessionStorage.setItem('activeJobs', JSON.stringify(svc.jobs))
                    $window.sessionStorage.setItem('closedJobs', JSON.stringify(svc.closedJobs))
                    let jobIdArray = extractActiveJobIdArray(svc.jobs)
                    let closedJobIdArray = extractActiveJobIdArray(svc.closedJobs)
                    jobIdArray = jobIdArray.concat(closedJobIdArray)
                    return jobIdArray
                },
                getFlatSupervisorArray: () => {
                    return svc.supervisorLookup
                },
                createJobsObject: (type = 'open') =>{
                    let jobObj = []
                    let jobType = type === 'open' ? 1 : 0
                    allSites.forEach((sit)=>{
                        let tempJobs = []
                        allJobs.forEach((job)=>{
                            if(sit.rld_id === job.rld_parent_detail_rld_id && job.rld_is_active === jobType) {
                                tempJobs.push({
                                    EmployeePK: 3135,
                                    Site: sit.rld_name,
                                    SiteDescription: sit.rld_name,
                                    Job: job.rld_code,
                                    JobId: job.rld_id,
                                    JobDescription: job.rld_name,
                                    JobStart: '2050-01-01T00:00:00',
                                    JobEnd: null,
                                    LinkActive: false,
                                    Active: true,
                                    Site_rld_id: sit.rld_id
                                })
                            } 
                        })
                        if(tempJobs.length > 0) {
                            jobObj.push({
                                SiteID: sit.rld_name,
                                Description: sit.rld_name,
                                Jobs: tempJobs,
                                JobLinkActive: false,
                                ActiveJobCount: 0,
                                TotalJobCount: tempJobs.length,
                                expanded: false,
                                moreHidden: false,
                                Site_rld_id: sit.rld_id
                            })
                        }
                    })
                    return jobObj
                },
                initializeJobDataFromSession: (employeeObj) => {
                    if(!employeeObj.jobsIds)
                        employeeObj.jobsIds = []

                    svc.jobLookup.clear()
                    let count = 0
                    function addJobsToLookup(lookupObject, siteArray) {
                        for (let i = 0; i < siteArray.length; i++) {
                            let site = siteArray[i]
                            for (let j = 0; j < site.Jobs.length; j++) {
                                let job = site.Jobs[j]
                            lookupObject[job.JobId] = job
                            count++
                            }
                        }
                    }

                    function addPersonJobsToLookup() {
                        for (let [key, value] of Object.entries(svc.jobLookup)) {
                            if(employeeObj.jobsIds.indexOf(value.JobId) != -1){
                                svc.jobLookup[key].LinkActive = true
                                }
                        }
                    }                    
                      
                    svc.jobs.length = 0
                    svc.closedJobs.length = 0
                    let sessionActiveJobs = JSON.parse($window.sessionStorage.getItem("activeJobs"))
                    let sessionClosedJobs = JSON.parse($window.sessionStorage.getItem("closedJobs"))

                    if (sessionActiveJobs && sessionActiveJobs.length > 0) {
                        Array.prototype.push.apply(svc.jobs, sessionActiveJobs)
                        addJobsToLookup(svc.jobLookup, svc.jobs)
                    }
                    else {
                        svc.jobs  = svc.createJobsObject('open')
                        addJobsToLookup(svc.jobLookup, svc.jobs)
                        addPersonJobsToLookup()
                    }
                    
                    if (sessionClosedJobs && sessionClosedJobs.length > 0){
                        Array.prototype.push.apply(svc.closedJobs, sessionClosedJobs)
                        addJobsToLookup(svc.jobLookup, svc.closedJobs)
                    }
                    else {
                        svc.closedJobs  = svc.createJobsObject('closed')
                        addJobsToLookup(svc.jobLookup, svc.closedJobs)
                        addPersonJobsToLookup()
                    }

                    svc.supervisorLookup.length = 0;
                    let sessionSupervisors = JSON.parse($window.sessionStorage.getItem("supervisors"))
                    if (sessionSupervisors && sessionSupervisors.length > 0)
                        Array.prototype.push.apply(svc.supervisorLookup, JSON.parse($window.sessionStorage.getItem("supervisors")))
                    else
                        svc.supervisorLookup.push(employeeObj.per_id)
                    
                    function initExpandedPropertiesOnSelf(jobsArray) {
                        for (var i = 0; i < jobsArray.length; i++) {
                            //base initial expandedness on site having active jobs or not
                            jobsArray[i].expanded = jobsArray[i].JobLinkActive
                            jobsArray[i].moreHidden = jobsArray[i].expanded 
                            //if there are no active/inactive jobs to separate, do away with this
                            if (jobsArray[i].TotalJobCount === jobsArray[i].ActiveJobCount) {
                                jobsArray[i].moreHidden = false
                            }
                        }
                    }
                    initExpandedPropertiesOnSelf(svc.jobs)
                    initExpandedPropertiesOnSelf(svc.closedJobs)
                    return({allJobs:{jobs: svc.jobs, closedJobs: svc.closedJobs}})
                },
                initializeJobDataProfileDefault:(employeeObj) => {
                    svc.jobs.length = 0
                    svc.closedJobs.length = 0
                    Array.prototype.push.apply(svc.jobs, employeeObj.ActiveJobs)
                    Array.prototype.push.apply(svc.closedJobs, employeeObj.ClosedJobs)
                    svc.jobLookup.clear()
                    function addJobsToLookup(lookupObject, siteArray) {
                        for (let i = 0; i < siteArray.length; i++) {
                            let site = siteArray[i]
                            for (let j = 0; j < site.Jobs.length; j++) {
                                let job = site.Jobs[j]
                                lookupObject[job.Job] = job
                            }
                        }
                    }
                    addJobsToLookup(svc.jobLookup, svc.jobs)
                    addJobsToLookup(svc.jobLookup, svc.closedJobs)
                    svc.supervisorLookup.length = 0;
                    svc.supervisorLookup.push(employeeObj.EmployeeName)

                    function initExpandedPropertiesOnSelf(jobsArray) {
                        for (let i = 0; i < jobsArray.length; i++) {
                            //base initial expandedness on site having active jobs or not
                            jobsArray[i].expanded = jobsArray[i].JobLinkActive
                            jobsArray[i].moreHidden = jobsArray[i].expanded 
                            //if there are no active/inactive jobs to separate, do away with this
                            if (jobsArray[i].TotalJobCount === jobsArray[i].ActiveJobCount) {
                                jobsArray[i].moreHidden = false
                            }
                        }
                    }
                    initExpandedPropertiesOnSelf(svc.jobs)
                    initExpandedPropertiesOnSelf(svc.closedJobs)
                },
                initializeSupervisorsData: (supervisors) => {

                    let superv = []
                    supervisors.forEach((sup)=>{
                    let jobList = [] 
                    let SiteList = [] 
                    let tList = []     
                        if(sup.employee_jobs){
                            jobList = sup.employee_jobs.split(',')
                            allJobs.forEach((jobs)=>{
                                let num = jobs.rld_id.toString()
                                    if(jobList.indexOf(num) >= 0) {
                                    tList.push({
                                        Active: false,
                                        Job: jobs.rld_id,
                                        LinkActive: false
                                        })
                                    }
                            })
                        }
                        let siteArr = []
                        // add sites into an array
                        if(sup.per_profile_site_ids){
                           let sites = sup.per_profile_site_ids.split(',')
                           if(sites.length > 0) {                                
                                sites.forEach((site)=>{
                                    siteArr.push(parseInt(site))
                                })
                            }
                        }
                                               
                        // if site only selected as employee's site, then need to add that site's jobs into the tList array
                        // validates siteArr and jobs > 0
                        // employee sites
                        // all sites and respective jobs array
                        // if employee site == all siteJob array.rld_id
                        // current employee jobs list 
                        // loop thru all sitejobs
                        // set flag=1 means employee profile defined with specific job
                        // set alreadyFlag=1 if the site is already part of active job

                        if(siteArr.length>0){
                            siteArr.forEach((siteId)=>{
                                let alreadyFlag = 0
                                svc.jobs.forEach((siteObj)=>{
                                    if(siteObj.Site_rld_id == siteId){
                                        let flag = 0
                                        tList.forEach((empjobObj)=> {
                                            siteObj.Jobs.forEach((siteJobs)=>{ 
                                                if(empjobObj.Job == siteJobs.JobId){
                                                    flag=1
                                                    alreadyFlag = 1                     
                                                }
                                            })
                                        })

                                        if(flag==0){
                                            siteObj.Jobs.forEach((siteJobs)=>{   
                                                tList.push({
                                                    Active: false,
                                                    Job: siteJobs.JobId,
                                                    LinkActive: false
                                                })
                                            })    
                                        }
                                    }
                                })

                                if(alreadyFlag == 0){
                                    svc.closedJobs.forEach((siteObj)=>{
                                        if(siteObj.Site_rld_id == siteId){
                                            let flag = 0
                                            tList.forEach((empjobObj)=> {
                                                siteObj.Jobs.forEach((siteJobs)=>{
                                                    if(empjobObj.Job == siteJobs.JobId){
                                                        flag=1
                                                    }
                                                })
                                            })

                                            if(flag==0){
                                                siteObj.Jobs.forEach((siteJobs)=>{   
                                                    tList.push({
                                                        Active: false,
                                                        Job: siteJobs.JobId,
                                                        LinkActive: false
                                                    })
                                                })    
                                            }
                                        }
                                    })
                                }
                            })
                        } 
                        superv.push({
                            ID: sup.per_id,
                            ExternalID: sup.per_id,
                            SupervisorName: sup.per_full_name,
                            Active: true,
                            Jobs: tList,
                            searchMatched: true,
                            SiteIds: siteArr,
                            user_is_active: sup.is_active
                        })
                    })
                    svc.supervisors.length = 0
                    Array.prototype.push.apply(svc.supervisors, superv)

                    $window.sessionStorage.setItem('supervisors', JSON.stringify(svc.supervisors))
                },
                loadFilters: () => {
                    return $q.all([
                        profileService.getPersonProfile(),
                        profileService.getAllEmployeeProfile(),
                        // listService.getJobList(),
                        // listService.getSiteList()
                        listService.getAllJobListByDataVisibility(),                        
                        listService.getSiteListByDataVisibility(),
                        
                    ]).then(()=>{
                        //    allJobs = listService.readJobs()   
                        //    allSites = listService.readSites()                          
                        allJobs = listService.readJobsByDataVisibility()
                        allSites = listService.readSitesByDataVisibility()

                        $window.sessionStorage.removeItem("activeJobs")
                        let initJobs = svc.initializeJobDataFromSession(profileService.readPersonProfile())
                        svc.jobs = initJobs.allJobs.jobs

                        svc.closedJobs = initJobs.allJobs.closedJobs
                        svc.initializeSupervisorsData(profileService.readAllEmployeeProfile())
                        svc.outputFilterChange()
                        return profileService.readAllEmployeeProfile()
                    })
                },
                profileDefault: () => {
                    return employeesService.getMeP(true)
                        .then(this.initializeJobDataProfileDefault)
                        .then(supervisorsService.getSupervisorsP)
                        .then(this.initializeSupervisorsData)
                        .then(this.outputFilterChange)
                }
            }
            return svc
        }])

safeToDo.component("stdJobFilter", {
    templateUrl: 'app/components/jobFilter/job-filter.html',
    bindings: {
        rightMenuClosed: '='
    },
    controllerAs: 'vm',

    controller: ['$rootScope', '$scope', '$window','jobFilterService', 'profileService',

        function ($rootScope, $scope, $window, jobFilterService, profileService) {
            let vm = this
            vm.supervisors = jobFilterService.supervisors
            vm.supervisorLookup = jobFilterService.supervisorLookup
            vm.jobs = jobFilterService.jobs
            vm.closedJobs = jobFilterService.closedJobs
            vm.jobLookup = jobFilterService.jobLookup
            vm.viewActiveJobsBit = true
            vm.viewActiveUsersBit = true
            vm.supervisorsExpanded = true
            vm.animate = false
            vm.activeUsersCount = 0
            vm.inactiveUsersCount = 0

            vm.viewActiveJobs = (bit) => {
                vm.viewActiveJobsBit = bit
            }

            vm.viewActiveUsers = (bit) => {
                vm.viewActiveUsersBit = bit
            }

            vm.setSiteHidden = (site) => {
                site.moreHidden = site.ActiveJobCount > 0 && site.ActiveJobCount < site.TotalJobCount
            }

            vm.toggleSiteExpanded = (site) => {
                vm.setSiteHidden(site)
                site.expanded = !site.expanded
            }

            vm.componentTranslateLabels = (key) => {
                return translateTag(key)
            }
            vm.active_users = getUsersByActivationStatus(1)
            vm.inactive_users = getUsersByActivationStatus(0)  
            vm.checkAllBoxes = (tf) => {
                let sitesRef = vm.viewActiveJobsBit == 1 ? vm.jobs : vm.closedJobs
                    for (let s = 0; s < sitesRef.length; s++) {
                        let siteRef = sitesRef[s]
                        for (let j = 0; j < siteRef.Jobs.length; j++) {
                            let jobRef = siteRef.Jobs[j]
                            jobRef.LinkActive = tf
                        }
                        siteRef.ActiveJobCount = tf ? siteRef.TotalJobCount : 0
                    }
            }

            vm.profileDefault = () => {
                $window.sessionStorage.removeItem("activeJobs")
                $window.sessionStorage.removeItem("closedJobs")
                $window.sessionStorage.removeItem("supervisors")
                jobFilterService.length = 0
                jobFilterService.supervisorLookup.length = 0
                vm.loadFilters()
            }

            vm.loadFilters = () => {
                jobFilterService.loadFilters().then((emp) =>{
                    vm.jobs = jobFilterService.jobs
                    vm.closedJobs = jobFilterService.closedJobs                            
                    vm.supervisors = jobFilterService.supervisors
                    vm.jobSearchChanged()
                    vm.countSelectedUsers()
                    vm.active_users = getUsersByActivationStatus(1)
                    vm.inactive_users = getUsersByActivationStatus(0)                     

                    profileService.getPersonProfile().then(()=>{
                        let userprofile = profileService.readPersonProfile()
                        let supervisor = vm.supervisors.filter(obj => {
                            return obj.ID === userprofile.per_id
                        })
                        if(supervisor.length > 0){
                            let jobLinkActiveSet = '-partial'
                            vm.setJobLinkActive(supervisor[0].Jobs, jobLinkActiveSet)
                        }
                    }) 
                })
            }

            function getUsersByActivationStatus (mode) {
                let users = []
                for (let i = 0; i < vm.supervisors.length; i++) {
                    if (vm.supervisors[i].user_is_active === mode){
                        users.push(vm.supervisors[i])
                    }
                }
                return users
            }
                
            vm.selectAll = () => {
                    vm.checkAllBoxes(true)
                  //  jobFilterService.outputFilterChange()
            }

            vm.clearAll = () => {
                    vm.checkAllBoxes(false)
                 //   jobFilterService.outputFilterChange()
            }

            vm.selectAllJobs = () => {
                if (vm.getCheckboxStateForAllJobs() == '-selected')
                    vm.clearAll()
                else
                    vm.selectAll()
            }

            vm.toggleJob = (job, site) => {
                job.LinkActive = !job.LinkActive
            //    jobFilterService.outputFilterChange(vm.jobs)
            }

            vm.check = ($event, site) => {
                $event.stopPropagation()
                let activeJobCount = countActiveJobs([site])
                //activate all jobs if not all checked, deactivate if all checked
                let activate = activeJobCount < site.TotalJobCount
                for (let i = 0; i < site.Jobs.length; i++) {
                    site.Jobs[i].LinkActive = activate
                }
                site.ActiveJobCount = activate ? site.TotalJobCount : 0
                vm.setSiteHidden(site)
              //  jobFilterService.outputFilterChange()
            }

            function countActiveJobs(siteArray) {
                let count = 0;
                    if (!siteArray) {
                        return count;
                    }
                    for (var i = 0; i < siteArray.length; i++) {
                        for (var j = 0; j < siteArray[i].Jobs.length; j++) {
                            count += siteArray[i].Jobs[j].LinkActive ? 1 : 0
                        }
                    }
                return count
            }

            function countClosedJobs(siteArray) {
                let count = 0
                    if (!siteArray) {
                        return count
                    }
                    for (let i = 0; i < siteArray.length; i++) {
                        for (let j = 0; j < siteArray[i].Jobs.length; j++) {
                            count += siteArray[i].Jobs[j].LinkActive ? 1 : 0
                        }
                    }
                return count
            }

            vm.activeJobCount = () => {
                return countActiveJobs(vm.jobs)
            }

            vm.closedJobCount = () => {
                return countClosedJobs(vm.closedJobs)
            }

            vm.getCheckboxStateForAllJobs = () => {
                    if (!vm.jobs )
                        return ''
                    let sitesRef = vm.viewActiveJobsBit == 1 ? vm.jobs : vm.closedJobs
                    let countJobs = vm.viewActiveJobsBit == 1 ? vm.activeJobCount() : vm.closedJobCount()
                    let countTotalJobs = 0
                    for (let i = 0; i < sitesRef.length; i++)
                        countTotalJobs += sitesRef[i].TotalJobCount
                    if (countJobs == countTotalJobs)
                        return '-selected'
                    else if (countJobs > 0)
                        return '-partial'
                    else
                        return ''
            }

            vm.jobsActive = (site) => {
                let siteJobCount = site.Jobs.length
                let activeJobCount = 0
                for (let i = 0; i < site.Jobs.length; i++) {
                    activeJobCount += site.Jobs[i].LinkActive ? 1 : 0
                    if (!site.Jobs[i].LinkActive && activeJobCount > 0) {
                        break
                    }
                }

                if (siteJobCount === activeJobCount) {
                    return 'all'
                }
                if (activeJobCount > 0) {
                    return 'some'
                }
                return 'none'
            }

            vm.getCheckboxState = (site) => {
                let state = vm.jobsActive(site);        
                switch (state) {
                    case 'none':
                        return ''
                    case 'some':
                        return '-partial'
                    case 'all':
                        return '-selected'
                }
            }

            vm.getCheckboxStateForAllSupervisors = () => {
                let fullCount = vm.viewActiveUsersBit ? vm.active_users.length * 2 : vm.inactive_users.length * 2
                let runningCount = 0
                for (let i = 0; i < vm.supervisors.length; i++) {
                    if (vm.supervisors[i].user_is_active == vm.viewActiveUsersBit){
                        if (vm.supervisors[i].Jobs.length == 0) {
                            fullCount -= 2
                            //jobless should not count toward full-check
                            continue
                        }

                        let checkState = vm.supervisorCheckState(vm.supervisors[i])
                        let stop = false

                        switch (checkState) {
                            case '-selected':
                                runningCount += 2
                                break;
                            case '-partial':
                                runningCount += 1
                                stop = true
                                break
                            default:
                                break
                        }
                        if (stop) break
                    }
                }
                if (runningCount === 0)
                    return ''
                if (runningCount < fullCount)
                    return '-partial'
                return '-selected'
            }

            vm.checkAllSupervisors = ($event) => {
                $event.stopPropagation()
                let supCheckState = vm.getCheckboxStateForAllSupervisors()
                let jobLinkActiveSet = supCheckState === '' || supCheckState === '-partial'
                let supervisorLinkActiveSet = supCheckState === '' || supCheckState === '-partial'
                for (let i = 0; i < vm.supervisors.length; i++) {
                    if (vm.supervisors[i].user_is_active == vm.viewActiveUsersBit){
                        vm.setJobLinkActive(vm.supervisors[i].Jobs, jobLinkActiveSet)
                        vm.setSupervisorActive(vm.supervisors[i], supervisorLinkActiveSet)
                    }
                }
             //   jobFilterService.outputFilterChange()
                vm.countSelectedUsers()
            }

            vm.toggleSupervisorsExpanded =() => {
                vm.supervisorsExpanded = !vm.supervisorsExpanded
            }

            vm.countSelectedUsers = () => {
                vm.activeUsersCount = 0
                vm.inactiveUsersCount = 0
                vm.supervisorLookup.forEach((sup_lookup)=>{
                    vm.supervisors.find((sup)=>{
                        if (sup.ID === sup_lookup) {
                            if (sup.user_is_active){
                                vm.activeUsersCount += 1
                            }else{
                                vm.inactiveUsersCount += 1
                            }
                        }
                    })
                })
            }
            
            vm.toggleSupervisor = (supervisor) => {
                let currentCheckState = vm.supervisorCheckState(supervisor)
                let jobLinkActiveSet = currentCheckState === '' || currentCheckState === '-partial'
                let supervisorActiveSet = currentCheckState === ''
                vm.setJobLinkActive(supervisor.Jobs, jobLinkActiveSet)
                vm.setSupervisorActive(supervisor, supervisorActiveSet)
              //  jobFilterService.outputFilterChange()
                vm.countSelectedUsers()
            }

            vm.setJobLinkActive = (jobArray, jobLinkActiveSet) => {
                for (let i = 0; i < jobArray.length; i++) {
                    if(vm.jobLookup[jobArray[i].Job])
                    vm.jobLookup[jobArray[i].Job].LinkActive = jobLinkActiveSet
                }
            }

            vm.setSupervisorActive = (supervisor, active) => {
                if (active) {
                    if (vm.supervisorLookup.indexOf(supervisor.ID) == -1){
                        vm.supervisorLookup.push(supervisor.ID)
                    }    
                }
                else {
                    vm.supervisorLookup.splice($.inArray(supervisor.ID, vm.supervisorLookup), 1)
                }
            }
                
            vm.supervisorCheckState = (supervisor) => {
                if (vm.supervisorLookup.indexOf(supervisor.ID) > -1 ) {
                    return '-selected'
                }
                else {
                    return ''
                }
            }

            vm.jobSearch = ''

            vm.jobSearchChanged = () => {
                let lcaseSearch = vm.jobSearch.toLowerCase()
                for (let s = 0; s < vm.jobs.length; s++) {
                    let siteRef = vm.jobs[s]
                    let siteOn = false
                    for (let j = 0; j < siteRef.Jobs.length; j++) {
                        let jobRef = siteRef.Jobs[j]
                        let lcaseJobName = jobRef.Job.toLowerCase()
                        jobRef.searchMatched = lcaseJobName.indexOf(lcaseSearch) > -1
                        siteOn = siteOn || jobRef.searchMatched
                    }
                    siteRef.searchMatched = siteOn;
                }

                for (let s = 0; s < vm.closedJobs.length; s++) {
                    let siteRef = vm.closedJobs[s]
                    let siteOn = false
                    for (let j = 0; j < siteRef.Jobs.length; j++) {
                        let jobRef = siteRef.Jobs[j]
                        let lcaseJobName = jobRef.Job.toLowerCase()
                        jobRef.searchMatched = lcaseJobName.indexOf(lcaseSearch) > -1
                        siteOn = siteOn || jobRef.searchMatched
                    }
                    siteRef.searchMatched = siteOn
                }

                for (let s = 0; s < vm.supervisors.length; s++) {
                    let sup = vm.supervisors[s]
                    let searchMatched = false
                    
                    let lcaseSupName = sup.SupervisorName.toLowerCase()
                    searchMatched = lcaseSupName.indexOf(lcaseSearch) > -1
                    sup.searchMatched = searchMatched
                }
            }
            vm.loadFilters()
            vm.filterData = () =>{
                let jobIdArray = jobFilterService.getFlatJobIdArray()
                let supervisorArray = jobFilterService.getFlatSupervisorArray()
                $window.sessionStorage.setItem('supervisors', JSON.stringify(supervisorArray))
                vm.rightMenuClosed = true
                $rootScope.$broadcast('job-filter-changed', { jobIds: jobIdArray, supervisors: supervisorArray })
            }
        }
    ]
})
