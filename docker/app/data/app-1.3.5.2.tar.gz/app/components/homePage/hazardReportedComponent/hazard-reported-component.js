﻿'use strict';

safeToDo.component("hazardReportedComponent", {
    templateUrl: 'app/components/homePage/hazardReportedComponent/hazard-reported.html',
    bindings: {
        attrb1: '<',
    },
    controllerAs: 'vm',

    controller: ['$rootScope', '$scope', 'homeService',
        function ($rootScope, $scope, homeService) {
            let vm = this
            vm.placeholderCheck = true
            vm.sitesData = null
            vm.dateRange = null
            vm.immediate_actions_only = {
                'roles': [],
                'total': []
            }
            vm.further_actions = {
                'roles': [],
                'total': []
            }
            vm.$onInit = () =>{
                // Function to load TRIFR widgets
                function refreshHazardReportedData (site_ids, start_date, end_date) {
                    let payload = {
                        "selected_site_ids" : site_ids,
                        "startDate": start_date,
                        "endDate": end_date
                    }
                    homeService.getHazardReportedData(payload).then(response=>{
                        vm.immediate_actions_only = response['immediate_actions_only']
                        vm.further_actions = response['further_actions']
                        vm.placeholderCheck = false
                        drawHazardReportedPlotly()    
                    })
                }

                vm.componentTranslateLabels = (key) => {
                    return translateTag(key)
                }

                $rootScope.$on("HAZARDREPORTEDCOMPONENT", (event, siteData) => {
                    vm.sitesData = siteData
                    if (vm.sitesData && vm.dateRange){
                        refreshHazardReportedData(vm.sitesData, vm.dateRange.start, vm.dateRange.end)
                    }
                })
    
                $scope.$on('DATERANGE', (event, dateRange)=> {
                    vm.dateRange = dateRange
                    if (vm.sitesData && vm.dateRange){
                        refreshHazardReportedData(vm.sitesData, vm.dateRange.start, vm.dateRange.end)
                    }
                })
                
                drawHazardReportedPlotly()
                function drawHazardReportedPlotly() {
                    let trace1 = {
                        x: vm.immediate_actions_only['roles'],
                        y: vm.immediate_actions_only['total'],
                        name: 'Immediate actions only',
                        type: 'bar',
                        marker:{
                            color: '#0072ce'
                        },
                    };
                      
                    let trace2 = {
                        x: vm.further_actions['roles'],
                        y: vm.further_actions['total'],
                        name: 'Further actions',
                        type: 'bar',
                        marker:{
                            color: 'F6BE00'
                        },
                    };
                    
                    let data = [trace1, trace2];
                    
                    let layout_data = {
                        barmode: 'stack',
                        height: 150,
                        showlegend: false,
                        xaxis: {
                            'autorange': true,
                            'showgrid': false,
                            'zeroline': false, 
                            'showline': false,
                            'visible': false 
                        },
                        margin: { t: 0, r: 15, l: 25, b: 30 }
                    };

                    let layout_empty = {
                        width: 300,
                        height: 150,
                        margin: { t: 0, r: 15, l: 25, b: 30 },
                        "xaxis": {
                            "visible": false
                        },
                        "yaxis": {
                            "visible": false
                        },
                        "annotations": [
                            {
                                "text": vm.componentTranslateLabels(2401),
                                "xref": "paper",
                                "yref": "paper",
                                "showarrow": false,
                                "font": {
                                    "size": 10
                                }
                            }
                        ]
                    }

                    let config = {
                        scrollZoom: true,
                        displayModeBar: false,
                        displaylogo: false, 
                        responsive: true
                    }
                    
                    Plotly.newPlot('hazard_reported', data, vm.placeholderCheck ? layout_empty : layout_data, config);  
                }
            }
        }
    ]
});