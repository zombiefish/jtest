'use strict';
safeToDo.component("documentToReviewComponent", {
    templateUrl: 'app/components/homePage/documentToReviewComponent/document-to-review.html',    
    bindings: {
    },
    controllerAs: 'vm',
    controller: ['homeService', '$location', '$window',
        function (homeService, $location, $window,) {        
            let vm = this
            vm.placeholderCheck = true;
            vm.loading = false
            vm.medal = null
            vm.documentData = {
                person: 0,
                site: 0,
                company: 0,
                person_total: 0,
                site_total: 0,
                company_total: 0
            }           
            homeService.getDocumentCountData().then(() => {
                vm.placeholderCheck = false;
                vm.documentData = prepareDocumentData(homeService.readDocumentCountData())
            })
            //Prepare data for page
            function prepareDocumentData (data) {
                let preparedData = data
                let largestCompletion = 0
                preparedData.personCompletion = getPercentageValue(data.person_total, data.person)
                preparedData.siteCompletion = getPercentageValue(data.site_total, data.site)
                preparedData.companyCompletion = getPercentageValue(data.company_total, data.company)
                if(preparedData.personCompletion > largestCompletion) {
                    largestCompletion = preparedData.personCompletion
                    vm.medal = 'person'
                }
                if(preparedData.siteCompletion > largestCompletion) {
                    largestCompletion = preparedData.siteCompletion
                    vm.medal = 'site'
                }
                if(preparedData.companyCompletion > largestCompletion) {
                    largestCompletion = preparedData.companyCompletion
                    vm.medal = 'company'
                }       
                return preparedData
            }

            vm.componentTranslateLabels = (key) => {
                return translateTag(key)
            }

            vm.documentsRedirect = (filter = 'Person') => {                        
                $location.path('/a/document-review')
                $window.sessionStorage.setItem('homepageRedirect_documentsFilter', filter)
            }

            let getPercentageValue = (total, pending) => {
                let complete = 0
                let final_result = 0
                if (total > 0){
                    complete = total - pending
                    final_result = Math.round(complete / total) * 100
                }
                return final_result
            }
        }
        
    ]   
   
})

