angular
    .module('safeToDo')
    .service('openActionsComponentService', ['$http',
        function ($http) {            
            return {               
                getOpenActionsDataComponent: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/home/get-home-open-actions-by-site/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to get home page open actions by sites', errorParams)
                    })
                },
            }        
        }
    ])