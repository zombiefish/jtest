'use strict';
safeToDo.component("openActionsComponent", {
    templateUrl: 'app/components/homePage/openActionsComponent/openActionsComponent.html',    
    bindings: {
        // page: 
    },
    controllerAs: 'vm',
    controller: ['$rootScope', '$window', 'openActionsComponentService', 'gridService', '$sce', '$timeout','$location',
        function ( $rootScope, $window, openActionsComponentService, gridService, $sce, $timeout, $location) {
            let vm = this
            vm.total_openActions = 0 
            vm.actionOptions = gridService.getCommonOptions()
            vm.placeholderCheck = true
            vm.sitesData = null
            
             //Set Ag-Grid colum values/settings
             let actionsColumns = [      
                {
                    field: "submitted_by",
                    headerName: " ",
                    minWidth: 140,
                    maxWidth: 220,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',                    
                },
                {
                    field: "assigned_to",
                    headerName: " ",
                    minWidth: 140,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "due_date",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 500,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        let actionDate = new Date(params.data.due_date)
                        let currentDate = new Date()
                        try {
                            if(!params.data.due_date)
                                return ('<div><div>')
                            else if (actionDate < currentDate)
                                return '<div style="color: #D20000;">' + params.data.due_date + '</div>'
                            else
                                return '<div>' + params.data.due_date + '</div>'                        
                        } catch (error) {
                            return '<div>' + params.data.due_date + '</div>'  
                        }
                        
                    }
                }, 
                {
                    field: "type",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 100,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },        
                
                {field:"action_type", hide:true},
                {field:"description", hide:true},
                {field:"id", hide:true},
                {field:"report_slug", hide:true},
                {field:"submitted_by_id", hide:true},
                {field:"submission_id", hide:true},
                
            ]
            vm.actionOptions.columnDefs = actionsColumns
            vm.actionOptions.pagination= false
            vm.actionOptions.gridAutoHeight = false
            //Update Ag-Grid size when window is resized
            $(window).on('resize', () => {
                $timeout(function () {
                    if (vm.actionOptions.api) {
                        vm.actionOptions.api.sizeColumnsToFit()
                    }
                })
            })

            function refreshOpenActions(sites){
                if(sites && sites.length > 0){
                    let homePageJobList = $window.sessionStorage.getItem('homePageJobList')
                    let payload = {
                        "sites": sites ,
                        "jobs": homePageJobList,
                    }
                    openActionsComponentService.getOpenActionsDataComponent(payload).then((response)=>{
                        vm.placeholderCheck = false
                        vm.total_openActions = response.openActionsCount
                        vm.openAction = response.openAction
                        if (vm.actionOptions.api) {
                            translateAgGridHeader (vm.actionOptions)
                            let model = vm.actionOptions.api.getFilterModel()
                            vm.actionOptions.api.setRowData(prepareGridData())
                            vm.actionOptions.api.redrawRows()
                            vm.actionOptions.api.sizeColumnsToFit()
                            vm.actionOptions.api.setFilterModel(model)
                        }
                    })
                }
                else{
                    vm.placeholderCheck = false
                    vm.total_openActions = 0
                    vm.openAction = []
                    if (vm.actionOptions.api) {
                        translateAgGridHeader (vm.actionOptions)
                        let model = vm.actionOptions.api.getFilterModel()
                        vm.actionOptions.api.setRowData(prepareGridData())
                        vm.actionOptions.api.redrawRows()
                        vm.actionOptions.api.sizeColumnsToFit()
                        vm.actionOptions.api.setFilterModel(model)
                    }
                }
            }

            function prepareGridData(data=vm.openAction) {            
                if(!data)
                    return []    
                let openActionsGridData = JSON.parse(JSON.stringify(data))
                openActionsGridData.forEach((rec) =>{                    
                    rec.exceptionFields = ['action_type', 'report_slug','submitted_by_id','id', 'submission_id']
                    rec.due_date = rec.due_date == null? '': moment(rec.due_date).format('YYYY-MM-DD')
                })
                return openActionsGridData
            }
    
    

            $rootScope.$on("OPENACTIONSCOMPONENT", (event, siteData) => {
                vm.placeholderCheck = true
                vm.sitesData = siteData
                if(vm.sitesData){
                    refreshOpenActions(vm.sitesData)
                }
            })

            vm.openActionsRedirect = (filter = 'homepage') => {
                $window.sessionStorage.setItem('homepageRedirect_actionsFilter', filter)
                $location.path('/a/action-management')
            }

            vm.componentTranslateLabels = (key) => {
                return translateTag(key)        
            }
            
            vm.actionOptions.onRowDoubleClicked = (row) => {
                if(row.data.report_slug == 'single_hazard_action'){
                    vm.viewReports(row.data.submission_id, 'hazard_report')
                }
                else if(row.data.report_slug == 'single_general_action'){
                    vm.viewReports(row.data.submission_id, 'general_actions_parent')
                }
            }  
            
            //Function to launch the reports
            vm.viewReports = (id=null, report) => {
                let lang_number = localStorage.getItem('lang_id')
                vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${report}/${id}?lang=${lang_number}`)
                $window.open(vm.reportURL, "_blank")
            }

        }
    ]
   
})