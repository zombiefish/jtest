﻿'use strict';

safeToDo.component("trifrChartsComponent", {
    templateUrl: 'app/components/homePage/trifrChartsComponent/trifr-chart.html',
    bindings: {
        attrb1: '<',
    },
    controllerAs: 'vm',

    controller: ['adminTrifrService', '$rootScope', '$scope',
        function (adminTrifrService, $rootScope, $scope) {
            let vm = this
            vm.trifr = 0
            vm.trir = 0
            vm.placeholderCheck = true
            vm.level_of_detail = null
            vm.sitesData = null 
            vm.dateRange = null
            vm.show_chart = 'trifr'

            vm.$onInit = () =>{
                // Function to load TRIFR widgets
                function refreshTRIFRWidgets (selected_sites,date_range) {
                    let payload = {"selected_site_ids" : selected_sites,
                                   "req_param" : "trifr_data", 
                                   "req_date_range": date_range}
                    adminTrifrService.getTrifrTrirTrackOption().then(res => {
                      vm.track_trifr = res
                      if (vm.track_trifr.trifr_track_option || vm.track_trifr.trir_track_option){
                        vm.show_chart = !vm.track_trifr.trifr_track_option ? 'trir' : 'trifr'
                        adminTrifrService.getTRIFRData(payload).then(response=>{
                          vm.trifr = response.trifr
                          vm.trir = response.trir
                          vm.level_of_detail = vm.componentTranslateLabels(response.level_of_detail)
                          if (response.level_of_detail == '3836'){
                            vm.trifr = response.trifr / selected_sites.length
                            vm.trir = response.trir / selected_sites.length
                          }
                          drawTRIFRPlotly()
                          vm.placeholderCheck = false
                        })
                      }
                    })
                    
                }

                $rootScope.$on("TRIFRCHARTSCOMPONENT", (event, siteData) => {
                  vm.placeholderCheck = true
                  vm.sitesData = siteData
                  if (vm.sitesData && vm.dateRange){
                    refreshTRIFRWidgets(vm.sitesData, vm.dateRange.dateType)
                  }
                })
  
                $scope.$on('DATERANGE', (event, dateRange)=> {
                  vm.placeholderCheck = true
                  vm.dateRange = dateRange
                  if (vm.sitesData && vm.dateRange){
                    refreshTRIFRWidgets(vm.sitesData, vm.dateRange.dateType)
                  }
                })

                drawTRIFRPlotly()

                vm.componentTranslateLabels = (key) => {
                    return translateTag(key)
                }
                
                function drawTRIFRPlotly (){
                  let data_trifr = [
                    {
                      type: "indicator",
                      mode: "gauge+number",
                      value: vm.trifr,
                      gauge: {
                        axis: {
                          range: [0, 100],
                          visible: true,
                          tickwidth: 1,
                          tickvals: [0, 25, 50, 75, 100],
                          tickmode: 'array',
                        },
                        bar: { color: "F6BE00" },
                        bgcolor: "white",
                        borderwidth: 0,
                        bordercolor: "gray",
                        steps: [
                          { range: [0, 100], color: '#0072ce'}
                        ]
                      }
                    }
                  ];

                  let data_trir = [
                    {
                      type: "indicator",
                      mode: "gauge+number",
                      value: vm.trir,
                      gauge: {
                        axis: {
                          range: [0, 100],
                          visible: true,
                          tickwidth: 1,
                          tickvals: [0, 25, 50, 75, 100],
                          tickmode: 'array',
                        },
                        bar: { color: "F6BE00" },
                        bgcolor: "white",
                        borderwidth: 0,
                        bordercolor: "gray",
                        steps: [
                          { range: [0, 100], color: '#0072ce'}
                        ]
                      }
                    }
                  ];
                  
                  let layout = {
                    width: 250,
                    height: 150,
                    margin: { t: 0, r: 30, l: 30, b: 10 },
                    font: { color: "#0072ce", family: "Arial" }
                  };

                  let config = {
                    displayModeBar: false,
                    displaylogo: false,
                    responsive: true
                }
                  if (document.getElementById('trifr_chart')){
                    Plotly.newPlot('trifr_chart', data_trifr, layout, config);
                  }
                  if (document.getElementById('trir_chart')){
                    Plotly.newPlot('trir_chart', data_trir, layout, config);
                  }   
                }
                
            }
        }
    ]
});