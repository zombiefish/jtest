'use strict';
safeToDo.component("submissionTargetComponent", {
    templateUrl: 'app/components/homePage/submissionTargetComponent/submission-target.html',    
    bindings: {
    },
    controllerAs: 'vm',
    controller: ['homeService', '$location', '$window',
        function (homeService, $location, $window,) {        
            let vm = this
            vm.placeholderCheck = true;
            vm.loading = false
            vm.medal = null            
            homeService.getTargetCountData().then(() => {
                vm.placeholderCheck = false;
                vm.data = homeService.readTargetCountData()   
                vm.percentValueMyPool = getPercentageValue(vm.data.person_complete, vm.data.person_total)
                vm.percentValueSite = getPercentageValue(vm.data.site_complete, vm.data.site_total)         
                vm.percentValueCompany = getPercentageValue(vm.data.company_complete, vm.data.company_total)
                
                let largestCompletionPercent = 0
                if (vm.percentValueMyPool > largestCompletionPercent){
                    vm.medal = 'person'
                    largestCompletionPercent = vm.percentValueMyPool
                }
                if (vm.percentValueSite > largestCompletionPercent){
                    vm.medal = 'site'
                    largestCompletionPercent = vm.percentValueSite
                }
                if (vm.percentValueCompany > largestCompletionPercent){
                    vm.medal = 'company'
                    largestCompletionPercent = vm.percentValueCompany
                }

                vm.companyOutstanding = getOutstanding(vm.data.company_total, vm.data.company_complete)
                vm.myPoolOutstanding = getOutstanding(vm.data.person_total, vm.data.person_complete)
                vm.mySiteOutstanding = getOutstanding(vm.data.site_total, vm.data.site_complete)

            })

            vm.componentTranslateLabels = (key) => {
                return translateTag(key)
            }

            vm.targetsRedirect = (filter = 'Person') => {
                $location.path('/a/toolbox')
                $window.sessionStorage.setItem('homepageRedirect_targetsFilter', filter)
            }

            let getPercentageValue = (complete, total, final_result) => {
                final_result = Math.round(isNaN(complete / total)? "0" : (complete / total) * 100) 
                return final_result
            }
            
            let getOutstanding = (total , complete, final_result) => {    
                final_result = (total - complete)  
                return final_result
            }
        }
        
    ]   
   
})

