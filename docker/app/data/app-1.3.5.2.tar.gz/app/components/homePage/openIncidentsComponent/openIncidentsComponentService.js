angular
    .module('safeToDo')
    .service('openIncidentsComponentService', ['$http',
        function ($http) {            
            return {               
                getopenIncidentsDataComponent: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/home/get-home-incidents-by-site/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to get home page open actions by sites', errorParams)
                    })
                },
            }        
        }
    ])