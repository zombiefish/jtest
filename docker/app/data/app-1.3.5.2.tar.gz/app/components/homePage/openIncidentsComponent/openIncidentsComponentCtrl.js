'use strict';
safeToDo.component("openIncidentsComponent", {
    templateUrl: 'app/components/homePage/openIncidentsComponent/openIncidentsComponent.html',    
    bindings: {
        // page: 
    },
    controllerAs: 'vm',
    controller: ['$rootScope', '$window', 'openIncidentsComponentService', 'gridService', '$sce', '$timeout', '$location', 'menuService',
        function ($rootScope, $window, openIncidentsComponentService, gridService, $sce, $timeout, $location, menuService) {
            let vm = this
            vm.total_openIncidents = 0 
            vm.incidentOptions = gridService.getCommonOptions()
            vm.placeholderCheck = true

            // implements the can view incidents
            menuService.getPagePermissions().then((data) => {
                vm.permissions = data
                vm.canViewIncidents = vm.permissions.includes('Can View Incidents') ? true : false
            })


            //Set Ag-Grid colum values/settings
            let incidentsColumns = [      
                {
                    field: "IncidentNumber",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 160,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',                    
                },
                {
                    field: "incident_type",
                    headerName: " ",
                    minWidth: 110,
                    maxWidth: 140,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "Short_Description",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 340,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "openDate",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 100,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        try {
                            if(!params.data.openDate)
                                return ('<div><div>')                        
                            else if (params.data.openDate>=31)
                                return '<div style="color: #D20000;">' + params.data.openDate + '</div>'
                            else
                                return '<div>' + params.data.openDate + '</div>'                        
                        } catch (error) {
                            return '<div>' + params.data.openDate + '</div>'  
                        }
                        
                    }
                },    
            ]
            vm.incidentOptions.columnDefs = incidentsColumns
            vm.incidentOptions.pagination= false
            vm.incidentOptions.gridAutoHeight = false
            //Update Ag-Grid size when window is resized
            $(window).on('resize', () => {
                $timeout(function () {
                    if (vm.incidentOptions.api) {
                        vm.incidentOptions.api.sizeColumnsToFit()
                    }
                })
            })
            function refreshopenIncidents(sites){
                if(sites && sites.length > 0){
                    let payload = {
                        sites: sites,
                        jobs: vm.homePageJobList
                    }
                    openIncidentsComponentService.getopenIncidentsDataComponent(payload).then((response)=>{
                        vm.placeholderCheck = false
                        vm.total_openIncidents = response.openIncidentsCount
                        vm.openIncidents = response.openIncidents
                        if (vm.incidentOptions.api) {
                            translateAgGridHeader (vm.incidentOptions)
                            let model = vm.incidentOptions.api.getFilterModel()                       
                            vm.incidentOptions.api.setRowData(prepareGridData())
                            vm.incidentOptions.api.redrawRows()
                            vm.incidentOptions.api.sizeColumnsToFit()
                            vm.incidentOptions.api.setFilterModel(model)
                        }
                    })
                }
                else{
                    vm.placeholderCheck = false
                    vm.total_openIncidents = 0
                    vm.openIncidents = []
                    if (vm.incidentOptions.api) {
                        translateAgGridHeader (vm.incidentOptions)
                        let model = vm.incidentOptions.api.getFilterModel()                       
                        vm.incidentOptions.api.setRowData(prepareGridData())
                        vm.incidentOptions.api.redrawRows()
                        vm.incidentOptions.api.sizeColumnsToFit()
                        vm.incidentOptions.api.setFilterModel(model)
                    }
                }
            }

            function prepareGridData(data=vm.openIncidents) {            
                if(!data)
                    return []    
                let openIncidentsGridData = JSON.parse(JSON.stringify(data))
                return openIncidentsGridData
            }

            $rootScope.$on("OPENINCIDENTSCOMPONENT", (event, siteData) => {
                vm.placeholderCheck = true
                vm.sitesData = siteData
                vm.homePageJobList = $window.sessionStorage.getItem('homePageJobList')
                vm.homePageSiteList = $window.sessionStorage.getItem('homePageSiteList')
                refreshopenIncidents(vm.sitesData)
            })

            vm.incidentsRedirect = (filter = 'homepage') => {
                $window.sessionStorage.setItem('homepageRedirect_incidentsFilter', filter)
                $location.path('/a/tir')
            }

            vm.componentTranslateLabels = (key) => {
                return translateTag(key)        
            } 
            
            vm.incidentOptions.onRowDoubleClicked = (row) => {
                if(!vm.canViewIncidents){
                    toastr.error(translateTag(3822)) // You do not have Permission
                    return
                }

                if(row.data.incident_type){
                    vm.viewReports(row.data.ID)
                }
                else{
                    toastr.warning(translateTag(9481)) // Unable to complete your request because there is no Preliminary Report attached to the Incident Report case file."
                }
            }
            
            //Function to launch the reports
            vm.viewReports = (submissionId=null) => {
                let lang_number = localStorage.getItem('lang_id')
                vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/preliminary_incident/${submissionId}?lang=${lang_number}`)
                $window.open(vm.reportURL, "_blank")
            }
        }
    ]
   
})