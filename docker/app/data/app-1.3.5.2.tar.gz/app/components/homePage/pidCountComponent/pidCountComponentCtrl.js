'use strict';
safeToDo.component("positiveCountComponent", {
    templateUrl: 'app/components/homePage/pidCountComponent/pidCountComponent.html',    
    bindings: {   
    },
    controllerAs: 'vm',
    controller: ['$rootScope', '$scope', 'pidCountComponentService', '$location', '$window',
        function ($rootScope, $scope, pidCountComponentService, $location, $window) {
            let vm = this
            vm.loading = false
            vm.sitesData = null
            vm.dateRange = null
            vm.total_comments = 0 
            vm.total_likes = 0 
            vm.total_pid_count = 0 
            vm.placeholderCheck = true

            function refreshPidCount(sites, start_date, end_date){
                if(sites && sites.length >0){
                    pidCountComponentService.getPidCountComponent(sites, start_date, end_date).then((response)=>{
                        vm.placeholderCheck = false
                        vm.total_comments = response.OutPut[0].total_comments    
                        vm.total_likes = response.OutPut[0].total_likes    
                        vm.total_pid_count = response.OutPut[0].total_pid_count                        
                    })
                }
                else{
                    resetControl()
                }
                
            }

            $rootScope.$on("PIDCOUNTCOMPONENT", (event, siteData) => {
                vm.placeholderCheck = true
                vm.sitesData = siteData
                if( vm.sitesData && vm.dateRange){
                    refreshPidCount(vm.sitesData, vm.dateRange.start, vm.dateRange.end)
                }
            })

            $scope.$on('DATERANGE', (event, dateRange)=> {
                resetControl()
                vm.dateRange = dateRange
                if( vm.sitesData && vm.dateRange){
                    vm.placeholderCheck = true
                    refreshPidCount(vm.sitesData, vm.dateRange.start, vm.dateRange.end)
                }
            })
            
            function resetControl(){
                vm.placeholderCheck = false
                vm.total_comments = 0 
                vm.total_likes = 0 
                vm.total_pid_count = 0 
               
            }

            vm.loadPidRedirect = (filter = 'homepage') => {
                $window.sessionStorage.setItem('homepageRedirect_pidFilter', filter)
                $window.sessionStorage.setItem('homePageRedirectDate', JSON.stringify(vm.dateRange))
                $location.path('/a/positive-id')
            }

        

        }
    ]
   
})