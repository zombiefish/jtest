angular
    .module('safeToDo')
    .service('pidCountComponentService', ['$http',
        function ($http) {            
            return {               
                getPidCountComponent: (payload, start_date, end_date) => {
                     payload = {
                        "sites_ids": payload ,
                        "start_date": start_date,
                        "end_date": end_date
                    }
                    return $http.post(`${__env.apiUrl}/api/home/get-home-pid-count-by-site-date/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to home page positive ids count', errorParams)
                    })
                },
            }        
        }
    ])