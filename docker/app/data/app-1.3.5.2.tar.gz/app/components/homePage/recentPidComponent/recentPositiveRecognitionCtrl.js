'use strict';
safeToDo.component("recentPositiveRecognition", {
    templateUrl: 'app/components/homePage/recentPidComponent/recentPositiveRecognition.html',    
    bindings: {
    },
    controllerAs: 'vm',
    controller: ['$rootScope', 'gridService', 'recentPositiveRecognitionService', '$timeout', '$sce', '$window',
        function ( $rootScope, gridService, recentPositiveRecognitionService, $timeout, $sce, $window) {
            let vm = this
            vm.loading = false
            vm.options = gridService.getCommonOptions()

             //Set Ag-Grid colum values/settings
            let pidColumns = [            
            {
                field: "submitted_by",
                headerName: " ",
                minWidth: 220,
                maxWidth: 280,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                sort: 'desc'
            },
            {
                field: "recognition_of",
                headerName: " ",
                minWidth: 200,
                maxWidth: 350,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',                    
            },
            {
                field: "recognition_type",
                headerName: " ",
                minWidth: 200,
                maxWidth: 300,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Description",
                headerName: " ",
                minWidth: 300,
                maxWidth: 400,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab']
            },           
            
            {field:"FormCreationDate", hide:true},
            {field:"Site", hide:true},
            ]
            vm.options.columnDefs = pidColumns
            vm.options.pagination= false
            vm.options.gridAutoHeight = false
            //Update Ag-Grid size when window is resized
            $(window).on('resize', () => {
                $timeout(function () {
                    if (vm.options.api) {
                        vm.options.api.sizeColumnsToFit()
                    }
                })
            })

            function refreshRecentPid(payload){
                if(payload && payload.sites && payload.sites.length > 0){
                    recentPositiveRecognitionService.getRecentPositiveRecognitions(payload).then((response)=>{
                        if (vm.options.api) {
                            translateAgGridHeader(vm.options)
                            let model = vm.options.api.getFilterModel()                       
                            vm.options.api.setRowData(prepareGridData(response.OutPut))
                            vm.options.api.redrawRows()
                            vm.options.api.sizeColumnsToFit()
                            vm.options.api.setFilterModel(model)
                        }
                    })   
                }
                else{
                    if (vm.options.api) {
                        translateAgGridHeader(vm.options)
                        let model = vm.options.api.getFilterModel()                       
                        vm.options.api.setRowData(prepareGridData([]))
                        vm.options.api.redrawRows()
                        vm.options.api.sizeColumnsToFit()
                        vm.options.api.setFilterModel(model)
                    }
                }           
                
            }
            
            $rootScope.$on("RECENTPIDCOMPONENT", (event, siteData) => {
                let jobIds = $window.sessionStorage.getItem("homePageJobList") ? $window.sessionStorage.getItem("homePageJobList") : ""
                let payload = {}
                payload.sites = siteData
                payload.jobs = jobIds
                refreshRecentPid(payload)
            })

            vm.componentTranslateLabels = (key) => {
                return translateTag(key)        
            }

            function prepareGridData(data) { 
                if(!data){
                    return []
                }
                let gridData = JSON.parse(JSON.stringify(data))
                gridData.forEach((rec) =>{                    
                    rec.exceptionFields = ['FormCreationDate', 'Site','pid','id', 'submissionId']
                })
                return gridData
            }
            //Function to launch the reports
            vm.viewReports = (id=null, report, pid_id) => {
                let lang_number = localStorage.getItem('lang_id')
                vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${report}/${id}?lang=${lang_number}&pr_id=${pid_id}`)
                $window.open(vm.reportURL, "_blank")
            }

            vm.options.onRowDoubleClicked = (row) => {
                if(row.data.submissionId)
                    vm.viewReports(row.data.submissionId, 'positive_recognition', row.data.pid)
            }
        }
    ]
   
})