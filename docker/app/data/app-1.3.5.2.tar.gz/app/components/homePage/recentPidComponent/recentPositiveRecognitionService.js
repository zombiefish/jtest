angular
    .module('safeToDo')
    .service('recentPositiveRecognitionService', ['$http',
        function ($http) {            
            return {               
                getRecentPositiveRecognitions: (payload) => {                   
                    return $http.post(`${__env.apiUrl}/api/home/get-home-pid-data-by-site/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load homepage recent positive data', errorParams)
                    })
                },
            }        
        }
    ])