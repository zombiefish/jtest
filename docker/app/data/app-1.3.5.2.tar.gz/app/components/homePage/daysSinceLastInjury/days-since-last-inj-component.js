'use strict';

safeToDo.component("daysSinceLastInjuryComponent", {
    templateUrl: 'app/components/homePage/daysSinceLastInjury/days-since-last_injury.html',
    bindings: {
        attrb1: '<',
    },
    controllerAs: 'vm',

    controller: ['$rootScope', 'adminTrifrService',
        function ($rootScope, adminTrifrService) {
            let vm = this
            vm.placeholderCheck = true;
            vm.sitesData = null

            vm.$onInit = () =>{
                // Function to load TRIFR widgets
                function refreshTRIFRWidgets (site_ids) {
                    let payload = {"selected_site_ids" : site_ids,"req_param" : "last_injury"}
                    adminTrifrService.getTRIFRData(payload).then(response=>{
                        if (response.days_since_last_injury_by_site !== null){
                            vm.daysSinceLastInjuryBySite = response.days_since_last_injury_by_site < 0 ? 0 : response.days_since_last_injury_by_site
                        }else{
                            vm.daysSinceLastInjuryBySite = '-'
                        }
                        if (response.days_since_last_injury_company_wide !== null){
                            vm.daysSinceLastInjuryCompanyWide = response.days_since_last_injury_company_wide < 0 ? 0 : response.days_since_last_injury_company_wide
                        }else{
                            vm.daysSinceLastInjuryCompanyWide = '-'
                        }
                        vm.placeholderCheck = false;
                    })
                }

                $rootScope.$on("DAYSSINCELASTINJURY", (event, siteData) => {
                    vm.placeholderCheck = true
                    vm.sitesData = siteData
                    if(vm.sitesData){
                        refreshTRIFRWidgets(vm.sitesData)
                    }
                })

                vm.componentTranslateLabels = (key) => {
                    return translateTag(key)
                }
            }
        }
    ]
});