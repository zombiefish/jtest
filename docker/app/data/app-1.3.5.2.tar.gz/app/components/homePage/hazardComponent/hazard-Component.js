﻿'use strict';

safeToDo.component("hazardComponent", {
    templateUrl: 'app/components/homePage/hazardComponent/hazard.html',
    bindings: {
        attrb1: '<',
    },
    controllerAs: 'vm',

    controller: ['$rootScope', '$scope', 'homeService','$q', '$window', '$location',
        function ($rootScope, $scope, homeService,$q, $window, $location) {
            let vm = this
            vm.sitesData = null
            vm.dateRange = null
            vm.layout = {
                annotations: [
                    {
                        text: null,
                        x: 0.5,
                        y: 0.6,
                        font: { size: 10 },
                        showarrow: false,
                    },
                    {
                        text: null,
                        x: 0.5,
                        y: 0.5,
                        font: { size: 20 },
                        showarrow: false,
                    } 
                ],
                font: {
                   family: 'Roboto',
                   size: 28
                },
                autosize: false,
                height: 178,
                width: 250,
                margin: {
                    l: 0,
                    r: 0,
                    b: 15,
                    t: 0,
                    pad: 0
                },
                showlegend: false,
                grid: {rows: 1, columns: 1}
              };

            let config = {
                locale: selectedLanguage,
                responsive: false,
                displayModeBar: false
              }

            let ultimateColors = 
                ['#046CC0', '#99C4EA', '#F5BC03', '#2EB4E5','#444348','#8185E7','#F9A35E','#90ED80','#F15C82']
            let colorArray = ['#0E6AC1', '#C0D7C5', '#64996B', '#097392', '#7FB5DB', '#FE9B56', '#B6D2EA', '#D55535', '#E59998', '#234234', '#FFF07C', '#D782B8', '#EF798A', '#20639B']
            
            vm.$onInit = () =>{
                //Get donut chart data
                function refreshDonutCharts (site_ids, start_date, end_date) {
                    let payload = {
                        "selected_site_ids" : site_ids,
                        "startDate": start_date,
                        "endDate": end_date
                    }
                    $q.all([ 
                        homeService.getHazardDonut(payload),
                        homeService.getPotentialsDonut(payload),
                        homeService.getActionDonut(payload),
                    ]).then(()=>{
                        vm.hazardDonutData = getDonutData(homeService.readHazardDonut())
                        vm.potentialDonutData = getDonutData(homeService.readPotentialsDonut())
                        vm.actionDonutData = getDonutData(homeService.readActionDonut())
                        let myDonutData=[
                            {name:'hazard-donut',data:vm.hazardDonutData, text:translateTag(1098)},
                            {name:'potential-donut',data:vm.potentialDonutData,text:translateTag(1144)},
                            {name:'action-donut',data:vm.actionDonutData,text:translateTag(1100)}
                        ]    

                        for(let i=0; i < myDonutData.length; i++){
                            let values=[]
                            let labels=[]
                            let ids = []
                            let myDonutGraphData = myDonutData[i]
                            for(let j=0; j < myDonutGraphData.data.data.length; j++){
                                let dataFields = myDonutGraphData.data.data[j]
                                values.push(dataFields.y)
                                labels.push(dataFields.name)
                                if (dataFields.id){
                                    ids.push(dataFields.id[0])
                                }
                            }
    
                            let data = [{
                                values: values,
                                labels: labels,
                                domain: {column: 0},
                                ids: ids,
                                hoverinfo: 'label+value',
                                textinfo: 'label',
                                textposition: 'outside',
                                textfont: {
                                    family: 'Roboto',
                                    size: 8
                                },
                                hole: .7,
                                type: 'pie',
                                marker: {
                                    colors: ultimateColors
                                },
                              },
                            ];
                            vm.layout.annotations[0].text=myDonutGraphData.text
                            vm.layout.annotations[1].text=myDonutGraphData.data.count
                            let layout = JSON.parse(JSON.stringify(vm.layout))   
                            layout.showlegend = false
                            Plotly.newPlot(myDonutGraphData.name, data, layout,config)
                            let plotlyChart = document.getElementById(myDonutGraphData.name)
                            // Triggered when a pie chart is hovered over
                            plotlyChart.on('plotly_hover', function(data){
                                var nCol = ['gray','gray','gray','gray','gray','gray','gray','gray','gray'];
                                nCol[data.points[0].pointNumber] = ultimateColors[data.points[0].pointNumber];
                                var update = {marker:{colors: nCol}};
                                Plotly.restyle(plotlyChart, update);
                            });
                            plotlyChart.on('plotly_unhover', function(data){
                                var update = {marker:{colors: ultimateColors}};
                                Plotly.restyle(plotlyChart, update);
                            });
                        }
                        let hazardPlot = document.getElementById('hazard-donut')
                        let actionPlot = document.getElementById('action-donut')
                        let potentialPlot = document.getElementById('potential-donut')
                        let seriesName = null
                        
                        // Triggered when a pie chart is clicked
                        hazardPlot.on('plotly_click', function(data){
                            seriesName = data.points[0].label === translateTag(688) ? data.points[0].label: data.points[0].id
                            handleChartClick(seriesName, 'hazard_identification')
                        });

                        actionPlot.on('plotly_click', function(data){
                            seriesName = data.points[0].label === translateTag(688) ? data.points[0].label: data.points[0].id
                            handleChartClick(seriesName, 'action_type')
                        });

                        potentialPlot.on('plotly_click', function(data){
                            seriesName = data.points[0].label === translateTag(688) ? data.points[0].label: data.points[0].id
                            handleChartClick(seriesName, 'potential_risk')
                        });

                        $scope.$emit('STOPSPINNER')
                    })
                }
                
                // Retrieve the date range from the Daterange component
                $rootScope.$on("HAZARDCOMPONENT", (event, siteData) => {
                    vm.sitesData = siteData
                    vm.homePageJobList = $window.sessionStorage.getItem('homePageJobList')
                    vm.homePageSiteList = $window.sessionStorage.getItem('homePageSiteList')
                    if (vm.sitesData && vm.dateRange){
                            refreshDonutCharts(vm.sitesData, vm.dateRange.start, vm.dateRange.end)
                    }
                })

                $scope.$on('DATERANGE', (event, dateRange)=> {
                    vm.dateRange = dateRange
                    if (vm.sitesData && vm.dateRange){
                        refreshDonutCharts(vm.sitesData, vm.dateRange.start, vm.dateRange.end)
                    }
                })
                
                // Function to prepare the payload for redirect when 'other' pie is clicked
                function handleChartClick(seriesName, queryParamName) {
                    let oList = []
                    let filter_payload = {
                        start_date: vm.dateRange.start,
                        end_date: vm.dateRange.end,
                        date_type: vm.dateRange.dateType,
                        values: [],
                        redirect_from: 'homepage',
                        job_ids: vm.homePageJobList,
                        site_ids: vm.homePageSiteList,
                        mode: queryParamName
                    }
                    if(seriesName === translateTag(688)){
                        switch(queryParamName) {
                            case "potential_risk":
                                oList = vm.potentialDonutData.rest
                                break
                            case "hazard_identification":
                                oList = vm.hazardDonutData.rest
                                break   
                            default:
                                oList = vm.actionDonutData.rest
                                break                 
                        }
                        oList.forEach((rec)=>{
                            rec.rld_id.forEach(element => {
                                filter_payload.values.push(element)
                            });                    
                        })
                    }
                    else {                
                        filter_payload.values= seriesName
                    }
                    $window.sessionStorage.setItem('hapFilter', JSON.stringify(filter_payload))
                    $window.sessionStorage.setItem('homePageRedirectDate', JSON.stringify(vm.dateRange))            
                    $location.path('/a/haps')
                }


                function getDonutData(data) {
                    let topN = 6                
                    let donutData = {
                        data: [],
                        rest:[],
                        count: 0
                    }
                    donutData.count += countDonut(data)
                    data.sort((a, b) => {
                        return b.value - a.value;
                    })
                    donutData.rest = data.slice(topN);
                    data = data.slice(0, topN);
                    data.forEach((rec)=>{
                        donutData.data.push({
                            name: rec.key,
                            y: rec.value,
                            id: rec.rld_id,                    
                        })
                    })
        
                    if (donutData.rest.length > 0) {
                        let restCount = 0
                        donutData.rest.forEach((rec) => {
                            restCount += rec.value
                        })
        
                        donutData.data.push({ name: translateTag(688), y: restCount, color: colorArray[Math.floor(Math.random() * 7)] }); // Other
                    }            
                    return(donutData)
                }  
                
                function countDonut(data) {
                    let total = 0
                    data.forEach((rec)=>{
                        total += rec.value
                    })
                    return(total)
                }

                vm.componentTranslateLabels = (key) => {
                    return translateTag(key)        
                }
                
                $('.carousel').carousel({
                    interval: false,
                  });
            }
        }
    ]
});