'use strict';

safeToDo.component("daysSinceLastIncidentComponent", {
    templateUrl: 'app/components/homePage/daysSinceLastIncident/days-since-last_incident.html',
    bindings: {
        attrb1: '<',
    },
    controllerAs: 'vm',

    controller: ['$rootScope', 'adminTrifrService',
        function ($rootScope, adminTrifrService) {
            let vm = this
            vm.placeholderCheck = true
            vm.sitesData = null
            
            vm.$onInit = () =>{
                // Function to load TRIFR widgets
                function refreshTRIFRWidgets (site_ids) {
                    let payload = {"selected_site_ids" : site_ids,"req_param" : "last_incident"}
                    adminTrifrService.getTRIFRData(payload).then(response=>{
                        if (response.days_since_last_incident_by_site !== null){
                            vm.daysSinceLastIncidentBySite = response.days_since_last_incident_by_site < 0 ? 0 : response.days_since_last_incident_by_site
                        }else{
                            vm.daysSinceLastIncidentBySite = '-'
                        }
                        if (response.days_since_last_incident_company_wide !== null){
                            vm.daysSinceLastIncidentCompanyWide = response.days_since_last_incident_company_wide < 0 ? 0 : response.days_since_last_incident_company_wide
                        }else{
                            vm.daysSinceLastIncidentCompanyWide = '-'
                        }
                        vm.placeholderCheck = false;
                    })
                }

                $rootScope.$on("DAYSSINCELASTINCIDENT", (event, siteData) => {
                    vm.placeholderCheck = true
                    vm.sitesData = siteData
                    if(vm.sitesData){
                        refreshTRIFRWidgets(vm.sitesData)
                    }
                    
                })
                vm.componentTranslateLabels = (key) => {
                    return translateTag(key)
                }
            }
        }
    ]
});