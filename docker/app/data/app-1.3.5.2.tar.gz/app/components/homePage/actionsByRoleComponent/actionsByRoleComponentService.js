angular
    .module('safeToDo')
    .service('actionsByRoleComponentService', ['$http',
        function ($http) {
            return {
                getActionsByRoleDataComponent: (payload) => {
                   
                    return $http.post(`${__env.apiUrl}/api/home/get-home-open-actions-by-site-role/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to get home open actions by sites, date and role', errorParams)
                    })
                },
            }        
        }
    ])