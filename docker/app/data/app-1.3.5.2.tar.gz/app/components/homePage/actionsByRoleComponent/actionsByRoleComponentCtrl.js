'use strict';
safeToDo.component("actionsByRoleComponent", {
    templateUrl: 'app/components/homePage/actionsByRoleComponent/actionsByRoleComponent.html',    
    bindings: {
    },
    controllerAs: 'vm',
    controller: ['$rootScope', '$scope', '$window', 'actionsByRoleComponentService', 'gridService', '$sce', '$timeout',
        function ($rootScope, $scope, $window, actionsByRoleComponentService, gridService, $sce, $timeout) {
            let vm = this
            vm.total_openActions = 0 
            vm.actionRoleOptions = gridService.getCommonOptions()
            vm.placeholderCheck = true
            vm.roleDisplayName = ""
            vm.startDate = ""
            vm.endDate = ""
            vm.aro_id = 0
            vm.roleList = null
            vm.sitesData = null
            vm.dateRange = null

             //Set Ag-Grid colum values/settings
             let actionsColumns = [      
                {
                    field: "submitted_by",
                    headerName: " ",
                    minWidth: 140,
                    maxWidth: 160,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',                    
                },
                {
                    field: "assigned_to",
                    headerName: " ",
                    minWidth: 140,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "due_date",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 500,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        let actionDate = new Date(params.data.due_date)
                        let currentDate = new Date()
                        try {
                            if(!params.data.due_date)
                                return ('<div><div>')                        
                            else if (actionDate < currentDate)
                                return '<div style="color: #D20000;">' + params.data.due_date + '</div>'
                            else
                                return '<div>' + params.data.due_date + '</div>'                        
                        } catch (error) {
                            return '<div>' + params.data.due_date + '</div>'  
                        }
                        
                    }
                },         
                {
                    field: "type",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 100,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {field:"action_type", hide:true},
                {field:"description", hide:true},
                {field:"id", hide:true},
                {field:"report_slug", hide:true},
                {field:"submitted_by_id", hide:true},
                {field:"submission_id", hide:true},
            ]
            vm.actionRoleOptions.columnDefs = actionsColumns
            vm.actionRoleOptions.pagination= false
            vm.actionRoleOptions.gridAutoHeight = false
            //Update Ag-Grid size when window is resized
            $(window).on('resize', () => {
                $timeout(function () {
                    if (vm.actionRoleOptions.api) {
                        vm.actionRoleOptions.api.sizeColumnsToFit()
                    }
                })
            })

            function refreshActionsByRole(){
                if( vm.sitesData && vm.startDate && vm.endDate && vm.sitesData.length > 0){
                    let homePageJobList = $window.sessionStorage.getItem('homePageJobList')
                    let payload = {
                        "sites": vm.sitesData ,
                        "jobs": homePageJobList,
                        "role_id": vm.aro_id,
                        "start_date": vm.startDate,
                        "end_date": vm.endDate
                    }
                    actionsByRoleComponentService.getActionsByRoleDataComponent(payload).then((response)=>{
                        vm.placeholderCheck = false
                        vm.total_openActions = response.open_action_role_count
                        vm.openAction = response.action_role_details
                        if (vm.actionRoleOptions.api) {
                            translateAgGridHeader (vm.actionRoleOptions)
                            let model = vm.actionRoleOptions.api.getFilterModel()                       
                            vm.actionRoleOptions.api.setRowData(prepareGridData())
                            vm.actionRoleOptions.api.redrawRows()
                            vm.actionRoleOptions.api.sizeColumnsToFit()
                            vm.actionRoleOptions.api.setFilterModel(model)
                        }
                    })
                }
                else{
                    vm.placeholderCheck = false
                    vm.total_openActions = 0
                    vm.openAction = []
                    if (vm.actionRoleOptions.api) {
                        translateAgGridHeader (vm.actionRoleOptions)
                        let model = vm.actionRoleOptions.api.getFilterModel()                       
                        vm.actionRoleOptions.api.setRowData(prepareGridData())
                        vm.actionRoleOptions.api.redrawRows()
                        vm.actionRoleOptions.api.sizeColumnsToFit()
                        vm.actionRoleOptions.api.setFilterModel(model)
                    }
                }
            }

            function prepareGridData(data=vm.openAction) {            
                if(!data)
                    return []    
                let openActionsGridData = JSON.parse(JSON.stringify(data))
                openActionsGridData.forEach((rec) =>{                    
                    rec.exceptionFields = ['action_type', 'report_slug','submitted_by_id','id', 'description', 'submission_id']
                    rec.due_date = rec.due_date == null? '': moment(rec.due_date).format('YYYY-MM-DD')
                })
                return openActionsGridData
            }
    
    

            $rootScope.$on("ACTIONSBYROLECOMPONENT", (event, siteData, roleList, defaultPersonRole) => {
                vm.placeholderCheck = true
                vm.sitesData = siteData
                vm.roleList  = roleList
                if (vm.roleList){
                    vm.roleList.forEach((role) => {
                        if(role.aro_id == defaultPersonRole){
                            vm.aro_id = role.aro_id
                            vm.roleDisplayName = role.aro_name_trans
                        }
                           
                    })
                    vm.aro_id = defaultPersonRole
                    refreshActionsByRole(vm.sitesData)
                }
            })

            vm.componentTranslateLabels = (key) => {
                return translateTag(key)        
            }

            $scope.$on('DATERANGE', (event, dateRange)=> {
                vm.placeholderCheck = true
                vm.dateRange = dateRange
                if(vm.dateRange){
                    vm.startDate = vm.dateRange.start
                    vm.endDate = vm.dateRange.end
                    refreshActionsByRole()
                }
            })
            
            vm.actionRoleOptions.onRowDoubleClicked = (row) => {
                if(row.data.report_slug == 'single_hazard_action'){
                    vm.viewReports(row.data.submission_id, 'hazard_report')
                }
                else if(row.data.report_slug == 'single_general_action'){
                    vm.viewReports(row.data.submission_id, 'general_actions_parent')
                }
            } 

            //Function to launch the reports
            vm.viewReports = (id=null, report) => {
                let lang_number = localStorage.getItem('lang_id')
                vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${report}/${id}?lang=${lang_number}`)
                $window.open(vm.reportURL, "_blank")
            }     
            
            vm.changeRole = (role) => {
                vm.roleDisplayName = role.aro_name_trans
                vm.aro_id = role.aro_id
                vm.placeholderCheck = true
                refreshActionsByRole()
            }

        }
    ]
   
})