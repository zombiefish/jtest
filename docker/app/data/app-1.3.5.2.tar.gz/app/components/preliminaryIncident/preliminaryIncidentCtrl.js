safeToDo.component("form224335", {
    templateUrl: 'app/components/preliminaryIncident/preliminaryIncident.html',
    bindings: {
        modalId: '<',
        shId: '<',
        allData: '<',
        mode: '<',
        incidentId: '<',
        onSave: '&',
        onClose: '&'
    },
    controllerAs: 'vm',
    controller: function ($scope, $rootScope, $q, listService, modalService, profileService, $compile, employeesService, settingsService, imageCommentService, fileUploadService, formsService, equipmentService) {
        let vm = this
        let dateToday = moment(new Date(), 'YYYY-MM-DD')    

        vm.siteList = []
        vm.jobList = []
        vm.jobListSelect = []
        vm.levelList = []
        vm.levelListSelect = []
        vm.employeeList = []
        vm.supervisorList = []
        vm.actionTypeList = []
        vm.incidentTypeList = []
        vm.distributionList = []
        vm.incidentTypeCategoryList = []
        vm.incidentTypeCategoryListSelect = []
        vm.incidentTypeDetailList = []
        vm.incidentTypeDetailListSelect = []
        vm.incidentShiftList = []
        vm.incidentShiftScheduleList = []
        vm.incidentDayRotationList = []
        vm.newAttachments = []
        vm.uploadFileList = []
        vm.currentAttachments = []
        vm.editForm = false
        vm.formFieldVisibilityList = []

        vm.equipmentSiteJobListData = []

        vm.translateLabels = (key) =>{      
            return translateTag(key)
          }
        
        $scope.$on("EDITFORMBYSHID-form-224335", (event,sh_id) => {
            vm.editForm = true
            getPreparedFormDataBySHID(sh_id)
        })

        function loadComments() {
            if(vm.currentAttachments){
                let image_index = 0
                vm.currentAttachments.forEach(attachment => {
                    let elem = document.getElementById('disk_comment_' + image_index)
                    if(attachment.com_comment !='' && attachment.com_comment != null){
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                    image_index++
                })
            }
        }

        function getPreparedFormDataBySHID (sh_id) {
            formsService.getFormDataBySHID(sh_id).then((response)=>{
                vm.currentPI = response.submission_data
                if(!vm.currentPI){
                    submission_language = response.submission_language
                    vm.modalElements = {
                        title: translateTag(2182),   //warning
                        message: `<div><p>${translateLabels(9137)} ${submission_language}. ${translateLabels(9138)} ${submission_language} ${translateLabels(9139)}</p></div>`, //This form has been submitted in ${submission_language}. Please switch your application language to ${submission_language} if you wish to edit this record.
                        buttons: `<button class='btn btn-primary btn-rounded' ng-click="vm.closeModal()" note="OK">{{vm.componentTranslateLabels(1405)}}</button>` 
                    }
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
                    return
                }
                vm.currentPI.level = parseInt(vm.currentPI.level)
                vm.currentPI.site = parseInt(vm.currentPI.site)
                vm.currentPI.job_number = parseInt(vm.currentPI.job_number)
                vm.currentPI.supervisor = parseInt(vm.currentPI.supervisor)
                vm.currentPI.headerdate = moment(vm.currentPI.headerdate).format("YYYY-MM-DD")
                vm.currentPI.reason_for_change = null
                vm.currentPI.form_name = '1003', // Preliminary Incident
                vm.currentAttachments = vm.currentPI.incident_pictures
                if(vm.currentAttachments){
                    vm.currentAttachments.forEach(attachment => {
                        attachment.imageDir = `${__env.imageUrl}/`
                    })
                }
                vm.getTypeCategoryDetail("edit")
                vm.getJobsLevels("edit")
                setTimeout(()=>{
                    modalService.Open("form-224335")
                    loadComments()
                    $scope.$emit("FORMSINITIALIZESELECT2", "form-224335")
                },100)
                vm.setEquipmentBySiteJob()
            })  
        }

        //Function to reset form
        function resetForm () {
            if(document.forms['preliminaryIncidentForm'])
                resetFormFieldClassList('preliminaryIncidentForm')
            
            vm.newAttachments = []
            vm.currentAttachments = []
            vm.uploadFileList = []
            vm.submitted = false
            vm.editForm = false

            vm.currentPI = {
                form_name: '1003', // Preliminary Incident
                incident_short_description: '',
                headerdate: dateToday.format("YYYY-MM-DD"),
                site: null,
                job_number: null,
                level: null,
                workplace: '',
                supervisor: null,
                incident_type: null,
                Incident_Type_Category: [],
                Incident_Type_Detail: [],
                incident_time: '',
                incident_shift: null,
                shift_schedule: null,
                other_shift_schedule_text: '',
                day_of_rotation: null,
                name_of_person_reporting_incident: null,
                other_reporting_incident: '',
                company_name: '',
                name_of_injury_person: null,
                other_injury_person: '',
                company_name_1: '',
                where_other_involved: '',
                other_1: null,
                other_1_text: '',
                company_name_2: '',
                other_2: null,
                other_2_text: '',
                company_name_3: '',
                other_3: null,
                other_3_text: '',
                company_name_4: '',
                incident_details: '',
                gas_or_temperature_required: '',
                why_not_gas_or_temperature_required: '',
                any_disruptions_of_process: '',
                why_not_any_disruptions_of_process: '',
                management_been_notifed: '',
                why_not_management_notifed: '',
                employee_direct_care_of_management: '',
                why_not_employee_care_of_management: '',
                testing_process_been_initiated: '',
                why_not_process_been_initiated: '',
                Report_Distribution1: []
            }
        }

        //Function to get jobs & levels at a site
        vm.getJobsLevels = (mode='new') => {
            let mainSite = ''
            if(mode==='new'){
                vm.currentPI.job_number = null
                vm.currentPI.level = null
            }
            vm.jobListSelect = []
            vm.levelListSelect = []
            vm.getFilteredEmployees()
            vm.siteList.forEach((rec) => {
                if(rec.rld_id == vm.currentPI.site)
                {
                    mainSite = rec.rld_id
                }
            })
            vm.jobList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id == mainSite)
                    vm.jobListSelect.push(rec)
            })
            vm.levelList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id == mainSite)
                    vm.levelListSelect.push(rec)
            })
            
        }

        //Function to get Type details
        vm.getTypeCategoryDetail = (mode="new") => {
            let mainType = null
            if (mode === "new"){
                vm.currentPI.Incident_Type_Category = []
                vm.currentPI.Incident_Type_Detail = []
            }
            vm.incidentTypeCategoryListSelect = []
            vm.incidentTypeDetailListSelect = []
            vm.incidentTypeList.forEach((rec) => {
                if(rec.rld_name == vm.currentPI.incident_type)
                {
                    mainType = rec.rld_id
                }
            })
            vm.incidentTypeCategoryList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id == mainType)
                    vm.incidentTypeCategoryListSelect.push(rec)
            })
            vm.incidentTypeDetailList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id == mainType)
                    vm.incidentTypeDetailListSelect.push(rec)
            }) 
        }        

        //Function to delete an attachment
        vm.deleteAttachment = (index) => {
            vm.deleteInitPara={
                mode:'init',
                index: index
            }
            vm.deleteAttachmentConfirmationModal(index)        
            for (let image_index=0;image_index<vm.newAttachments.length;image_index++){
                if(vm.newAttachments[image_index].comment){
                    if(vm.newAttachments[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                } else {
                    let elem = document.getElementById('comment_' + image_index)
                    elem.classList.remove('fas')
                    elem.classList.add('far')
                }
            }    
            
        }
        
        vm.deleteIndex = null
        //Function to open delete Attachment Confirmation Modal
        vm.deleteAttachmentConfirmationModal = (index) => {
            vm.deleteIndex = index    
            vm.modalElements = {
                title: translateTag(3416), //"Delete Attachment?"
                message: 
                    `<div>          
                        <p ng-if=${vm.deleteInitPara && vm.deleteInitPara.mode=='init'} note="You are about to delete this attachment.Are you sure?">${translateTag(1452)}</p>
                        <p ng-if=${!vm.deleteInitPara} note="You are about to delete this attachment. Undoing this will require IT support. Are you sure?">${translateTag(3635)}</p>
                    </div>`, 
                buttons: 
                    `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                    <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            }        
            document.getElementById('confirmcallingform').innerHTML = 'PRELIMINARYINCIDENTCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("PRELIMINARYINCIDENTCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.deleteInitAttachmentAfterConfirmation(vm.deleteInitPara)
            }
        })

        //Function to delete initial attachments after click "ok" in Confirmation modal
        vm.deleteInitAttachmentAfterConfirmation = (deleteInitPara) => {
            if(deleteInitPara && deleteInitPara.mode=="init"){
                vm.uploadFileList.splice(deleteInitPara, 1)
                vm.newAttachments.splice(deleteInitPara, 1)
            }
            else{
                formsService.removeFormSubmissionAttachments({
                    "id": vm.currentAttachments[vm.deleteIndex].id,
                    "com_id": vm.currentAttachments[vm.deleteIndex].com_id
                }).then((res)=>{
                    vm.currentAttachments.splice(vm.deleteIndex, 1)
                    vm.deleteIndex = null
                })
            }
            modalService.Close('confirmModal')
        }

        $scope.fileUploadChanged = (event)=> {

            let existingFileNames = []
            for(let i in vm.uploadFileList) {
                existingFileNames.push(vm.uploadFileList[i].name)
            }

            //Add newly selected files after checking for duplicates and correct file types
            vm.uploadFileList = vm.uploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, existingFileNames, true))
            
            //Get data from files to display in html
            fileUploadService.getFileUploadData(vm.uploadFileList).then ((filesData) => {
                vm.newAttachments = filesData
                $scope.$apply() // Update html bindings
            })
        }

        vm.convertTime = (timestamp) =>{
            return moment(timestamp).format("YYYY-MM-DD hh:mm:ss a")
        }

        vm.getFilteredEmployees = () =>{
            profileService.filterEmployeeListonJob(vm.currentPI.job_number)
            vm.employeeList =  profileService.readFilterEmployeeListonJob()
            profileService.filterSupervisorListonJob(vm.currentPI.job_number)
            vm.supervisorList = profileService.readFilterSupervisorListonJob()
            profileService.filterDistributionListonJob(vm.currentPI.job_number)
            vm.distributionList = profileService.readFilterDistributionListonJob()

            // get equipment job site list
            vm.setEquipmentBySiteJob()
        }

        vm.setEquipmentBySiteJob = () => {
            // Creating categories      
            let preop_site = vm.currentPI.site?vm.currentPI.site:""
            let preop_job = vm.currentPI.job_number?vm.currentPI.job_number:""
            vm.equipment_main_list = []
            if(preop_job) {    
      
              let siteJobLen =  vm.equipmentSiteJobListData.length
              for(let i=0; i<siteJobLen; i++){
                if(vm.equipmentSiteJobListData[i].psj_rld_site_id == preop_site && !vm.equipmentSiteJobListData[i].psj_rld_job_id) {
                  vm.equipment_main_list.push({
                    "group": translateTag(9561),
                    "value": `${vm.equipmentSiteJobListData[i].pet_equipment_identifier}|${vm.equipmentSiteJobListData[i].pet_id}`,
                    "label": `${vm.equipmentSiteJobListData[i].pet_equipment_identifier} ${vm.equipmentSiteJobListData[i].pet_equipment_name}`,
                    "sort": 1
                  })
                }
                if(vm.equipmentSiteJobListData[i].psj_rld_site_id == preop_site && vm.equipmentSiteJobListData[i].psj_rld_job_id == preop_job) {
                  vm.equipment_main_list.push({
                    "group": translateTag(9560),
                    "value": `${vm.equipmentSiteJobListData[i].pet_equipment_identifier}|${vm.equipmentSiteJobListData[i].pet_id}`,
                    "label": `${vm.equipmentSiteJobListData[i].pet_equipment_identifier} ${vm.equipmentSiteJobListData[i].pet_equipment_name}`,
                    "sort": 2
                  })
                }
              
                if(!vm.equipmentSiteJobListData[i].psj_rld_job_id && !vm.equipmentSiteJobListData[i].psj_rld_site_id) {
                  vm.equipment_main_list.push({
                    "group": translateTag(9562),
                    "value": `${vm.equipmentSiteJobListData[i].pet_equipment_identifier}|${vm.equipmentSiteJobListData[i].pet_id}`,
                    "label": `${vm.equipmentSiteJobListData[i].pet_equipment_identifier} ${vm.equipmentSiteJobListData[i].pet_equipment_name}`,
                    "sort": 3
                  })
                }
              }
              vm.equipment_main_list.push({
                "group": translateTag(688),
                "value": translateTag(688),
                "label": translateTag(688),
                "sort": 4
              })

            }
        }

    vm.saveNewCommentsAndAttachments = (submission_detail_id) => {
        let ufl = [...vm.uploadFileList]
        let att = [...vm.newAttachments]
        for (let i in ufl) {
            let fd = new FormData()
            fd.append("submission_detail_id", submission_detail_id)
            fd.append("form_field_description_id", 18806)
            fd.append("filename", ufl[i])
            fd.append("sde_image_timestamp", moment.unix(ufl[i].lastModified/1000).format('YYYY-MM-DD HH:mm:ss'))
        
            if(ufl.length > 0 ) {
                formsService.addFormSubmissionAttachments(fd).then((res) => {
                    let sfiles = res.message["Successfull Files"]
                    let attached_count = 0

                    for(attached of sfiles.allowed_original){
                        for(newA of att){
                            if(newA.comment){
                                if(attached==newA.file){
                                    newA.comment.com_reference_id = sfiles.ids[attached_count]
                                    //call service to insert comment.
                                    imageCommentService.saveComment(newA.comment)
                                }
                            }
                        }
                        attached_count++
                    }
                })
            }
        }
    }

    vm.createOrUpdatePI = () => {
        let payload = preparePayload(JSON.parse(JSON.stringify(vm.currentPI)))
        resetFormFieldClassList('preliminaryIncidentForm')
        if(validateFormFields('preliminaryIncidentForm')) {
            vm.submitted = true
            if(!vm.editForm){
                formsService.createFormSubmission(payload).then ((response) =>{
                    vm.saveNewCommentsAndAttachments(response.submission_detail_id)
                    vm.closeModal('form-224335')
                    $scope.$emit('REFRESH_FORMSUBMISSIONS') 
                })
            }else{
                formsService.updateFormSubmission(payload).then ((response) =>{
                    vm.saveNewCommentsAndAttachments(response.submission_detail_id)
                    vm.closeModal('form-224335')
                    vm.editForm = false
                    $scope.$emit('REFRESH_FORMSUBMISSIONS') 
                })
            }   
        } else {
            $rootScope.$broadcast("CALLCONFIRMMODAL")
        }
    }

        //Function to prepare payload data
        function preparePayload(payload) {
            let preparedPayload = payload
            preparedPayload.headerdate = moment(payload.headerdate, 'YYYY-MM-DDThh:mm:ss').format('YYYY-MM-DDThh:mm:ss')
            if(vm.editForm){
                preparedPayload.reason_for_change = preparedPayload.reason_for_change ? preparedPayload.reason_for_change : null
            }
            if(preparedPayload.where_other_involved == '0')
            {   
                preparedPayload.other_1 = ''
                preparedPayload.other_1_text = ''
                preparedPayload.company_name_2 = ''
                preparedPayload.other_2 = ''
                preparedPayload.other_2_text = ''
                preparedPayload.company_name_3 = ''
                preparedPayload.other_3 = ''
                preparedPayload.other_3_text = ''
                preparedPayload.company_name_4 = ''
            }
            if(preparedPayload.gas_or_temperature_required == '1')
                preparedPayload.why_not_gas_or_temperature_required = ''
            
            if(preparedPayload.any_disruptions_of_process == '1')
                preparedPayload.why_not_any_disruptions_of_process = ''

            if(preparedPayload.management_been_notifed == '1')
                preparedPayload.why_not_management_notifed = ''

            if(preparedPayload.employee_direct_care_of_management == '1' || preparedPayload.employee_direct_care_of_management == '-1')
                preparedPayload.why_not_employee_care_of_management = ''

            if(preparedPayload.testing_process_been_initiated == '1' || preparedPayload.testing_process_been_initiated == '-1')
                preparedPayload.why_not_process_been_initiated = ''

            preparedPayload.any_disruptions_of_process = preparedPayload.any_disruptions_of_process == '1'?"1":"0"
            preparedPayload.management_been_notifed = preparedPayload.management_been_notifed == '1'?"1":"0"

            preparedPayload = formsService.removePayloadHiddenFormFields(preparedPayload, vm.formFieldVisibilityList)

            return preparedPayload
        }

        //Function to close the modal
        vm.closeModal = (modalId) => {            
            modalService.Close(modalId)
            vm.employeeList = []
            vm.distributionList = []
            vm.supervisorList = []
            resetForm()
            refreshData()
        }

        vm.AddComments=(index, from) =>{
            document.getElementById('mode').innerText = ''
            document.getElementById('relatedimageindex').innerText = index
            document.getElementById('callingform').innerText = 'CLOSEPIIMAGECOMMENTSMODAL'  
            document.getElementById('parentform').innerHTML = 1
            document.getElementById('savetomemory').innerHTML = "true"

            vm.ImageFrom = from

            if (vm.editForm) {
                if(vm.ImageFrom=='disk'){
                    // updating the comments only from the disk                    
                    vm.editAttachmentIndex = index
                    if(vm.currentAttachments[index].com_comment || vm.currentAttachments[index].com_id){                    
                        document.getElementById('mode').innerText = 'edit'
                        document.getElementById('savetomemory').innerHTML = "false"                                         
                        document.getElementById('comment_id').innerHTML = vm.currentAttachments[index].com_id
                        document.getElementById('imageid').innerHTML = vm.currentPI.incident_pictures[index].id  
                        document.getElementById('condition').innerHTML = ''
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS", vm.currentAttachments[index].com_comment)                        
                    } 
                    else{
                        document.getElementById('mode').innerText = 'edit'
                        document.getElementById('savetomemory').innerHTML = "false"                      
                        document.getElementById('condition').innerHTML = 'AddCommentOnEmptyExistingImage'
                        document.getElementById('comment_id').innerHTML = vm.currentAttachments[index].com_id                        
                        document.getElementById('imageid').innerHTML = vm.currentPI.incident_pictures[index].id  
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS", vm.currentAttachments[index].com_comment)     

                    }
                }
                else if(vm.ImageFrom=='memory'){
                    if(vm.newAttachments[index].comment){
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.newAttachments[index].comment.com_comment)
                        document.getElementById('comment').value = vm.newAttachments[index].comment.com_comment
                    }
                    else{
                        document.getElementById('imageid').innerHTML = ''
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                        document.getElementById('comment').value = ''
                    }
                }
                else{
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                }
            }
            else{
                if(vm.newAttachments[index].comment){
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.newAttachments[index].comment.com_comment)
                    document.getElementById('comment').value = vm.newAttachments[index].comment.com_comment
                }else{
                    document.getElementById('imageid').innerHTML = ''
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                    document.getElementById('comment').value = ''
                }
            }
        }

        $scope.$on('CLOSEPIIMAGECOMMENTSMODAL',(event,data) => {
            let image_index = document.getElementById('relatedimageindex').innerText
            if(vm.editForm){
                if(vm.ImageFrom=='disk'){
                    vm.currentAttachments[vm.editAttachmentIndex].com_comment= data.com_comment 
                    vm.currentAttachments[vm.editAttachmentIndex].com_id=data.com_id    
                    let elem = document.getElementById('disk_comment_' + image_index)
                    if(vm.currentAttachments[vm.editAttachmentIndex].com_comment !='' && vm.currentAttachments[vm.editAttachmentIndex].com_comment != null){
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                }
                else if(vm.ImageFrom =='memory'){
                    vm.newAttachments[image_index].comment = data
                    vm.newAttachments[image_index].comment.com_reference_id = image_index

                    if(vm.newAttachments[image_index].comment){
                        if(vm.newAttachments[image_index].comment.com_comment !=''){
                            let elem = document.getElementById('comment_' + image_index)
                            elem.classList.remove('far')
                            elem.classList.add('fas')
                        } else {
                            let elem = document.getElementById('comment_' + image_index)
                            elem.classList.remove('fas')
                            elem.classList.add('far') 
                        }
                    }
                }
            }
            else
            {
                vm.newAttachments[image_index].comment = data
                vm.newAttachments[image_index].comment.com_reference_id = image_index
                document.getElementById('imageid').innerText = ''

                if(vm.newAttachments[image_index].comment.com_comment !=''){
                    let elem = document.getElementById('comment_' + image_index)
                    elem.classList.remove('far')
                    elem.classList.add('fas')
                } else {
                    let elem = document.getElementById('comment_' + image_index)
                    elem.classList.remove('fas')
                    elem.classList.add('far') 
                }
            }
        })

        $scope.$on('distribution-list-added', (event, args) => {
            if(vm.currentPI !== undefined)
                $scope.$emit('addDistributionGroup', args, vm.currentPI.Report_Distribution1)
        })

        $scope.$on('distribution-list-removed', (event, args) => {
            $scope.$emit('removeDistributionGroup',args)
        })

    vm.$onInit = () => {
        equipmentService.getEquipmentSiteJob().then((data)=>{
            vm.equipmentSiteJobListData = equipmentService.readEquipmentSiteJobList()
        })
    }

    vm.checkOther = () => {
        if(!vm.currentPI.equipment_involved.includes('Other')){
            vm.currentPI.equipment_involved_other=null
        }
    }

        //Function to refresh all data
        function refreshData() {
            $q.all([
                listService.getSiteListByDataVisibility(),
                listService.getJobListByDataVisibility(),
                listService.getSelectListData('ref_level'),
                listService.getSelectListData('ref_preliminary_incident_type'),
                listService.getSelectListData('ref_preliminary_incident_type_category'),
                listService.getSelectListData('ref_preliminary_incident_type_detail'),
                listService.getSelectListData('ref_shift'),
                listService.getSelectListData('ref_event_shift_schedule'),
                listService.getSelectListData('ref_days_of_rotation'),
                listService.getSelectListData('ref_action_type'),
                profileService.getAllEmployeeProfile(),
                profileService.getAllSupervisorProfile(),
                profileService.getDistributionList(),
                employeesService.getPersonProfile(),
                formsService.getFormFieldFilter({"form_id":224335})
            ]).then((data) => {
                resetForm()
                vm.siteList = listService.readSitesByDataVisibility()
                vm.jobList = listService.readJobsByDataVisibility()
                vm.jobList.forEach((job)=>{
                    job.fullJob = `(${job.rld_code}) - ${job.rld_name}`
                })
                vm.levelList = data[2]
                vm.incidentTypeList = data[3]
                vm.incidentTypeCategoryList = data[4]
                vm.incidentTypeDetailList = data[5]
                vm.incidentShiftList = data[6]
                vm.incidentShiftScheduleList = data[7]
                vm.incidentDayRotationList = data[8]
                vm.actionTypeList = data[9]
                vm.current_user_id = data[13].per_id
                vm.formFieldVisibilityList = data[14]
            }).then((data)=>{
                settingsService.getUserProfile(vm.current_user_id).then((response) => {
                    vm.siteList.forEach((rec)=>{
                        if(response.upr_site===rec.rld_id){
                            vm.currentPI.site = response.upr_site
                            vm.getJobsLevels()
                        }
                    })
                    vm.jobList.forEach((rec)=>{
                        if(response.upr_job==rec.rld_id){
                            vm.currentPI.job_number = response.upr_job
                            vm.getFilteredEmployees()
                        }
                    })
                    vm.levelList.forEach((rec) => {
                        if(response.upr_level === rec.rld_id){
                            vm.currentPI.level = response.upr_level
                        }
                    })
                    vm.supervisorList.forEach((rec)=>{
                        if(response.upr_supervisor_per === rec.per_id){
                            vm.currentPI.supervisor = rec.per_id
                        }
                    })
                    if(response.distribution_list){
                        let email_list = []
                        response.distribution_list.forEach((d)=>{
                            email_list.push(d.email)
                        })
                        vm.currentPI.Report_Distribution1 = email_list
                    }
                })

                formsService.removeHiddenFormFields('preliminaryIncidentForm', vm.formFieldVisibilityList)
            })
        }
        refreshData()

    //END

    }
    
})