﻿'use strict';

safeToDo.component("stdRootCauseAnalysisForm", {
    templateUrl: 'app/components/rootCauseAnalysisForm/root-cause-analysis-form.html',
    bindings: {
        modalId: '<',
        incident: '<',
        selectedHapId: '<',
        attachmentModalFiles: '<',
        //incidentActions: '<',
    },
    controllerAs: 'vm',
    controller: function ($scope, $rootScope, $element, $timeout, $compile, $interval, modalService, listService, employeesService, rootCauseAnalysisService, profileService) {
        var vm = this
        var elem = $($element)
        vm.currentUser = {}
        vm.disableSave = false
        vm.translateLabels = (key) =>{      
          return translateTag(key)
        }
        
        vm.initializeSelect2 = ()=>{
          setTimeout(()=>{ 
          $('.select-single,.select-multiple')
            .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%' , dropdownParent: $('#select2ParentRCA'), escapeMarkup: function (text) { return text }})
            .on('select2:select', () => {
               $(this).parent().find('label').addClass('filled');
            })
            $('.select2-selection__arrow b').addClass("fa fa-caret-down");                  // Add caret on selects
  
          }, 100)
          if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
          $('.datepicker').pickadate({
              format: 'yyyy-mm-dd',
              onClose : function(){
                this.$holder.blur()
            },
          }).removeAttr('readonly')
          .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
            evt.preventDefault()
          })
      }

        $scope.$on('CREATE_rootCauseAnalysisModal', (event, mass) => {
            resetForm();
            vm.initializeSelect2()
            startAutoSave()
        })

        $scope.$on('EDIT_rootCauseAnalysisModal', (event, data) => {
            resetForm()
            vm.editRootCauseID = data[0]
       
          rootCauseAnalysisService.getRootCauseAnalysis(vm.editRootCauseID).then((success) => {
                vm.form = success;
                // If the user didn't create any of these items, create an empty one for the user
                if (vm.form.immediate_causes.length == 0)
                    vm.form.immediate_causes.push(newImmediateCause());
                if (vm.form.basic_causes.length == 0)
                    vm.form.basic_causes.push(newBasicCause())
              vm.initializeSelect2()
              startAutoSave()
            }, (error) => {
                toastr.error(error);
            })
        })

      function startAutoSave() {
        // Start the autosave
          vm.autosave = $interval(() => {
            vm.saveForm('autosave')
              }, 60000)
      }

      vm.componentTranslateLabels = (key) => {
          return translateTag(key)
      }

      function resetForm() {
        vm.form = {
            root_cause_analysis: {
              ID: null,
              IncidentID: null,
              PreliminaryTypeID: null,
              PotentialLossID: null,
              ActualTypeID: null,
              IncidentTypeID: null,
              PreliminaryIncidentTypeCategoryID: null,
              PreliminaryIncidentTypeDetailID: null,
              ActualIncidentTypeCategoryID: null,
              ActualIncidentTypeDetailID: null,
              EventDetails: null,
              InvestigationFindings: null,
              SubmittedBy: null,
              SubmissionDate: null,
              LastUpdatedBy: null,
              LastUpdated: null
            },
            employees_involved: [],
            immediate_causes: [newImmediateCause()],
            basic_causes: [newBasicCause()],
            } // Form Object -- will contain all root-cause-analysis data

            $('.modal .scroll').scrollTop(0)
            document.forms['rootCauseAnalysis'].classList.remove('was-validated')
        }

      resetForm()

      function newImmediateCause() {
        return { ID: null, RootCauseAnalysisID: null, CauseType: null, Cause: null, Comments: null }
      }

      function newBasicCause() {
        return { ID: null, RootCauseAnalysisID: null, CauseType: null, CauseCategory: null, Cause: null, Comments: null }
      }

      function newAction() {
        return { RootCauseAnalysisID: null, Action: '' }
      }

      vm.addImmediateCause = function () {
        let lastIC = vm.form.immediate_causes[vm.form.immediate_causes.length - 1]
        if (lastIC['CauseType'] > 0 && lastIC['Cause'] > 0) {
            vm.form.immediate_causes.push(newImmediateCause())
        }
        else
          toastr.error(this.translateLabels(8410)) // "Please finish adding the current immediate cause."
          vm.initializeSelect2()
      }

      vm.removeBasicCause = (id) => {
        const delBasic = vm.form.basic_causes[id].ID
        let temp = JSON.parse(JSON.stringify(vm.form))
        let newcause = temp.basic_causes.filter((item, key) => {
          return key != id
        })
        let myBasicCauses = JSON.parse(JSON.stringify(newcause))
        // delete cause from DB here  then remove from array.
        rootCauseAnalysisService.removeBasicCause(delBasic).then((response) => {
          vm.form.basic_causes = myBasicCauses
              if (vm.form.basic_causes.length === 0) {
                 vm.form.basic_causes.push(newBasicCause())
                 vm.initializeSelect2()
              }
          toastr.success(`${vm.translateLabels(2573)} ${delBasic} ${vm.translateLabels(8480)}`) //Basic Cause ?? has been removed
        }, (error) => {
          console.log("Error Removing Basic Cause", error)
          });
      }

      vm.removeImmediateCause = (id) => {
        const del = vm.form.immediate_causes[id].ID
        let temp = JSON.parse(JSON.stringify(vm.form))
        let newcause = temp.immediate_causes.filter((item, key) => {
          return key != id
        })
        let mycauses = JSON.parse(JSON.stringify(newcause))
        // delete cause from DB here  then remove from array.
        rootCauseAnalysisService.removeImmediateCause(del).then((response) => {
            vm.form.immediate_causes = mycauses
              if (vm.form.immediate_causes.length === 0) {
                vm.form.immediate_causes.push(newImmediateCause());
                vm.initializeSelect2()
              }
          toastr.success(`${vm.translateLabels(2575)} ${del} ${vm.translateLabels(8480)}`) // Immediate Cause  ?? has been removed
        }, (error) => {
          console.log("Error Removing Immediate Cause", error)
        })
      }

      vm.addBasicCause = () => {
            let lastBC = vm.form.basic_causes[vm.form.basic_causes.length - 1]
            if (lastBC['CauseType'] > 0 && lastBC['CauseCategory'] > 0 && lastBC['Cause'] > 0)
                vm.form.basic_causes.push(newBasicCause())
            else
                toastr.error(vm.translateLabels(8581)) //Please finish adding the current basic cause
            
            vm.initializeSelect2()
      }

        // Drop Down List data
      listService.fetchRootCauseAnalysisLists().then(() => {
            vm.preliminaryTypes = listService.getPreliminaryTypes()
            vm.incidentTypes = listService.getIncidentTypes()
            vm.potentialLosses = listService.getPotentialLosses()
            vm.immediateCauses = listService.getImmediateCauses()
            vm.immediateCauseTypes = listService.getImmediateCauseTypes()
            vm.basicCauses = listService.getBasicCauses()
            vm.basicCauseTypes = listService.getBasicCauseTypes()
            vm.basicCauseCategories = listService.getBasicCauseCategories()
            vm.preliminaryIncidentTypeCategories = listService.getPreliminaryIncidentTypeCategories()
            vm.preliminaryIncidentTypeDetails = listService.getPreliminaryIncidentTypeDetails()
      })

      profileService.getAllEmployeeProfile().then(() =>{
            vm.employees = profileService.readAllEmployeeProfile();
            // if (vm.form.employees_involved.length > 0) {
            //     var empInvolvedDropdown = $(".employees_involved.dropdown");
            //     $(".employees_involved.dropdown").dropdown('set selected', vm.form.employees_involved);
            // }
      })
      

      profileService.getPersonProfile().then((profile)=>{
        let person =  profileService.readPersonProfile()
        vm.currentUser = { employeeID: person.per_id, name: person.per_full_name}
      })

      // vm.toggleInfo = () => {
      //   $(".alert").slideToggle()
      // }
      
      //Function to reset Dependent Dropdown when null
      vm.resetDependents = () =>{
        if (vm.form.root_cause_analysis.PreliminaryTypeID === undefined){
          vm.form.root_cause_analysis.PreliminaryIncidentTypeDetailID = null
          vm.form.root_cause_analysis.PreliminaryIncidentTypeCategoryID = null
        }
        if (vm.form.root_cause_analysis.ActualTypeID === undefined){
          vm.form.root_cause_analysis.ActualIncidentTypeCategoryID = null
          vm.form.root_cause_analysis.ActualIncidentTypeDetailID = null
        }
      }

      vm.resetDependentsForBasicCause = (index) => {
        if (vm.form.basic_causes[index].CauseType === undefined){
          vm.form.basic_causes[index].Cause = null
          vm.form.basic_causes[index].CauseCategory = null
        }
      }

      vm.resetDependentsForImmedCause = (index) => {
        if (vm.form.immediate_causes[index].CauseType === undefined){
          vm.form.immediate_causes[index].Cause = null
        }
      }

      vm.resetDependentsForBasicCauseCategory = (index) => {
        if (vm.form.basic_causes[index].CauseCategory === undefined){
          vm.form.basic_causes[index].Cause = null
        }
      }
         
      vm.saveForm = (mode='normal') => {
        vm.disableSave = true
        if(mode === 'normal') {
          if(validateFormFields('rootCauseAnalysis')){
            vm.form.root_cause_analysis.IncidentID = vm.incident.ID
            vm.form.root_cause_analysis.SubmittedBy = vm.currentUser.employeeID

            // This replaces Undefined values to null during JSON.stringify
            const replacer = (key, value) => typeof value === 'undefined' ? null : value

            rootCauseAnalysisService.upsertRootCauseAnalysis(JSON.parse(JSON.stringify(vm.form, replacer))).then((response) => {
              vm.disableSave = false
              vm.form.root_cause_analysis.ID = response['Received data'].root_cause_analysis.ID
              vm.closeModal(vm.modalId)
              $scope.$emit("Upsert_RootCauseAnalysis", vm.form.root_cause_analysis.ID)
            }, (error) => {
              console.log("Problem Saving RCA", error)
              vm.closeModal(vm.modalId)
            })
          } else {
            vm.disableSave = false
            $rootScope.$broadcast("CALLCONFIRMMODAL")
          }
        }
        else {
          // Then it is autosave
          vm.form.root_cause_analysis.IncidentID = vm.incident.ID
          vm.form.root_cause_analysis.SubmittedBy = vm.currentUser.employeeID
          // This replaces Undefined values to null during JSON.stringify
          const replacer = (key, value) => typeof value === 'undefined' ? null : value
          rootCauseAnalysisService.upsertRootCauseAnalysis(JSON.parse(JSON.stringify(vm.form, replacer))).then((response) => {
            vm.form.root_cause_analysis.ID = response.rca_id
            updateCauses(response.bc,response.ic, response.rca_id)
            vm.disableSave = false
            $scope.$emit("Upsert_RootCauseAnalysis", vm.form.root_cause_analysis.ID)
          }, (error) => {
            console.log("Problem Saving RCA", error)
          })
        }
      }

      function updateCauses(bc, ic, rca_id) {
        vm.form.basic_causes.forEach((rec,index)=>{
          rec.ID = bc[index]
          rec.RootCauseAnalysisID = rca_id
        })
        vm.form.immediate_causes.forEach((rec,index)=>{
          rec.ID = ic[index]
          rec.RootCauseAnalysisID = rca_id
        })
      }


      vm.completeForm = () => {
            $(".employees_involved.dropdown").dropdown('clear')
            vm.form.root_cause_analysis.IncidentID = vm.incident.ID
            vm.form.root_cause_analysis.SubmittedBy = vm.currentUser.employeeID
            rootCauseAnalysisService.completeRootCauseAnalysis(vm.form, vm.incident.ID).then((response) => {
                if (response.indexOf('Error') >= 0)
                    return

                vm.closeModal(vm.modalId)
                $scope.$emit("Upsert_RootCauseAnalysis", vm.form.root_cause_analysis.ID)
            })
        }

      vm.closeForm = () => {
        vm.closeModal(vm.modalId)
      }

      vm.closeModal = (id) => {
        resetForm()
        $(".resetSemanticUI.checkbox").checkbox('set unchecked', true)
        $(".instructions-section .checkbox").checkbox('set enabled', true)
        modalService.Close(id)
        $interval.cancel(vm.autosave)
      }

  }
});