﻿'use strict';

safeToDo.component("stdDateFilter", {
    templateUrl: 'app/components/datefilter/date-filter.html',
    bindings: {
        page: '<',
        type: '<',
        ctlrid: '<',
        donotshow: '<', // Please use this binding to specify the options not to be included in the dropdown. Also,please specify 'page' whenever 'donotshow' is defined in the calling event
        isfortrifr: '<'
    },
    controllerAs: 'vm',

    controller: ['$rootScope', '$scope', '$window', 'modalService',
        function ($rootScope, $scope, $window, modalService) {
          let vm = this
          let dateToday = moment(new Date(), 'YYYY-MM-DD')
          vm.dateDisplay = translateTag(3774) //Past 90 DAYS
          vm.$onChanges = (changesObj) => {
            vm.dateRangeConditions()
          }
          vm.$onInit = () =>{
            vm.show_filter_beginning = true
            vm.pageData = vm.page
            vm.controllerId = vm.ctlrid ? vm.ctlrid :'customDateRangeModal'
            document.getElementById("startingDate_label").innerHTML = translateTag(3775); //Start
            document.getElementById("endingDate_label").innerHTML = translateTag(3776); //End
            
            vm.range = {
              start: moment().subtract(90, 'days').format('YYYY-MM-DD'),
              end: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD'),
              dateType: '90'
            }
            vm.dateRangeConditions()
            $scope.$emit('DATERANGE', vm.range)
          }
          
          vm.dateRangeConditions = () => {
            if(vm.page === "30") {
              vm.dateDisplay = translateTag(3773) //Past 30 DAYS
              vm.range = {
                start: moment().subtract(30, 'days').format('YYYY-MM-DD'),
                end: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD'),
                dateType: '30'
              }
            }
            else if (vm.page === '90'){
              vm.dateDisplay = translateTag(3774) //Past 90 days
              vm.range = {
                start: moment().subtract(90, 'days').format('YYYY-MM-DD'),
                end: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD'),
                dateType: '90'
              }
            }
            else if (vm.page === 'beginning'){
              vm.dateDisplay = translateTag(1046) //Since the Beginning of Time
              vm.range = {
                start: "2000-01-01",
                end: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD'),
                dateType: 'beginning'
              }
            }
            else if (vm.page === 'document'){
              vm.show_filter_beginning = false
              vm.dateDisplay = translateTag(3773) //for documents 30 days
              vm.range = {
                start: moment().subtract(30, 'days').format('YYYY-MM-DD'),
                end: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD'),
                dateType: 'document_past_30_days'
              }              
            }
            else if (vm.page === 'ytd'){
              vm.show_filter_beginning = false
              vm.dateDisplay = translateTag(1096) //Year to Date
              vm.range = {
                start: `${dateToday.format('YYYY')}-01-01`,
                end: dateToday.format('YYYY-MM-DD'),
                dateType: "ytd"
              }              
            }
            else if (vm.page === 'custom'){
              vm.show_filter_beginning = false
              vm.range = {
                start: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD'),
                end: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD'),
                dateType: "custom"
              }
              if ($window.sessionStorage.getItem('homePageRedirectDate')){
                let custom_date = JSON.parse($window.sessionStorage.getItem('homePageRedirectDate'))
                vm.range.start = custom_date.start
                vm.range.end = custom_date.end
                let mStart = moment(vm.range.start)
                let mEnd = moment(vm.range.end)
                vm.dateDisplay = `${mStart.locale(selectedLanguage).format('MMMM D, YYYY')} - ${mEnd.locale(selectedLanguage).format('MMMM D, YYYY')}`
                vm.customRange = vm.range
                $window.sessionStorage.removeItem('homePageRedirectDate')
              }
            }
          }

          vm.customRange = {
            start: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD'),
            end: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD'),
            dateType: 'custom'
          }
          vm.setup = () =>{
            if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])

            let from_input = $('#startingDate-'+vm.controllerId).pickadate({format: 'yyyy-mm-dd'})
            .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
              evt.preventDefault()
            }),
            from_picker = from_input.pickadate('picker')
            let to_input = $('#endingDate-'+vm.controllerId).pickadate({format: 'yyyy-mm-dd'})
            .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
              evt.preventDefault()
            }),
            to_picker = to_input.pickadate('picker')
          
            // Check if there’s a “from” or “to” date to start with and if so, set their appropriate properties.
            if (from_picker.get('value')) {
              to_picker.set('min', from_picker.get('select'))
            }
            if (to_picker.get('value')) {
              from_picker.set('max', to_picker.get('select'))
            }
          
            // Apply event listeners in case of setting new “from” / “to” limits to have them update on the other end. If ‘clear’ button is pressed, reset the value.
            from_picker.on('set', function (event) {
              if (event.select) {                
                if(vm.page === 'document'){
                  let temp_date = moment(from_picker.get('value'), 'YYYY-MM-DD').add(1,'years').format('YYYY-MM-DD')
                  vm.customRange.end = temp_date
                  $scope.$apply()
                  to_picker.set('max', temp_date)
                }                     
                to_picker.set('min', from_picker.get('select'))
              } else if ('clear' in event) {
                to_picker.set('min', false)
                to_picker.set('max', false)
              }
            })            
            to_picker.on('set', function (event) {
              if (event.select) {
                from_picker.set('max', to_picker.get('select'))
              } else if ('clear' in event) {
                from_picker.set('max', false)
              }
            })
          }



          vm.cancelModal = (modal) => {
            modalService.Close(modal)
          }

          vm.changeDateRange = (mode) => {
            dateToday = moment(new Date(), 'YYYY-MM-DD')
            switch(mode) {
              case "Past 30 DAYS": vm.dateDisplay = translateTag(3773) //Past 30 DAYS
                vm.range.end = dateToday.format('YYYY-MM-DD')
                vm.range.start = dateToday.subtract(30, 'days').format('YYYY-MM-DD')
                vm.range.dateType = '30'
                $scope.$emit('DATERANGE', vm.range)
                break
              case "Past 90 DAYS": vm.dateDisplay = translateTag(3774) //Past 90 DAYS
                vm.range.end = dateToday.format('YYYY-MM-DD')
                vm.range.start = dateToday.subtract(90, 'days').format('YYYY-MM-DD')
                vm.range.dateType = '90'
                $scope.$emit('DATERANGE', vm.range)
                break
              case "Year to Date": vm.dateDisplay = translateTag(1096) //Year to Date
                vm.range.end = dateToday.format('YYYY-MM-DD')
                vm.range.start = `${dateToday.format('YYYY')}-01-01`
                vm.range.dateType = 'ytd'     
                $scope.$emit('DATERANGE', vm.range)
                break
              case "Since the Beginning of Time": vm.dateDisplay = translateTag(1046) //Since the Beginning of Time
                vm.range.end = dateToday.format('YYYY-MM-DD')
                vm.range.start = "2000-01-01"
                vm.range.dateType = 'beginning'  
                $scope.$emit('DATERANGE', vm.range)
                break
              case "Past 365 Days": vm.dateDisplay = translateTag(9367) // Rolling (365 days)
                vm.range.end = dateToday.format('YYYY-MM-DD')
                vm.range.start = dateToday.subtract(365, 'days').format('YYYY-MM-DD')
                vm.range.dateType = 'past_year'   
                $scope.$emit('DATERANGE', vm.range)
                break
              case "Custom":
                vm.setup()
                modalService.Open(vm.controllerId)
                break
              default: vm.dateDisplay = mode
                break
            }
          }

          vm.changeCustomDateRange = (modal) => {
            vm.range = vm.customRange
            let mStart = moment(vm.range.start)
            let mEnd = moment(vm.range.end)
            vm.dateDisplay = `${mStart.locale(selectedLanguage).format('MMMM D, YYYY')} - ${mEnd.locale(selectedLanguage).format('MMMM D, YYYY')}`
            $scope.$emit('DATERANGE', vm.range)
            modalService.Close(modal)
          }

          vm.componentTranslateLabels = (key) => {
            return translateTag(key)
          }
      }
    ]
});