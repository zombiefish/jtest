﻿'use strict';
safeToDo.component("stdInfoCard", {
    bindings: {
      title: '@',
      subtitle: '@',
      count: '@',
      buttonID: '@',
      labels: '@',
      tagdata1: '@',
      tagdata2: '@',
      tagdata3: '@',
      tagdata4: '@',
      tagdata5: '@'
    },
    templateUrl: 'app/components/infoCard/info-card.html',
    controllerAs: 'vm',
    controller: function ($scope, $element, $timeout, $filter) {
      var vm = this;
      vm.statCountLabels = {};
      vm.statCountData = {};
      vm.valueClicked = function () {
        // console.log("Click Me")
      }
      vm.$onInit = function () {
        vm.statCountLabels = JSON.parse(vm.labels)
       
      }; 
      
    }
});
