﻿'use strict';
safeToDo.component("userMenu", {
    // styling found in avatar.css
    templateUrl: 'app/components/avatar/avatar.html',
    bindings: {
        page: '<'
    },
    controllerAs: 'vm',

    controller: ['$compile','$scope', '$window', '$element', '$http', 'employeesService', 'settingsService','keycloakService', 'modalService', 

        function ($compile, $scope, $window, $element, $http, employeesService, settingsService, keycloakService, modalService) {
            var vm = this;
            var elem = $($element);
            vm.name = translateTag(3784) //Loading...
            vm.initials = "";
            // Show Test Badge if in Test Envirnment - Used Javascript instead of ng-show because it would flash
            if (window.location.hostname.split(".")[0].substring(0,4) ==='test')
                {
                    setTimeout(()=>{
                        document.getElementById('show-test-badge').classList.remove('d-none')  
                    },200)
                } 

            vm.$onInit = function () {
                processName(name);
                employeesService.getPersonProfile().then((emp_response)=>{
                    settingsService.getUserProfile(emp_response.per_id).then((response)=>{
                        if(getCookie('lang')!==response.upr_language){
                            let expires = new Date()
                            expires.setFullYear( expires.getFullYear() + 2)
                            document.cookie = "lang=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                            document.cookie = "lang=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/a;";
                            document.cookie = `lang=${response.upr_language}; expires= ${expires.toUTCString()}; path=/`
                            localStorage.setItem('lang_id', response.lng_id)
                            toastr.info(vm.componentTranslateLabels(8885))
                            setTimeout(() => {
                                location.reload()
                            }, 1000);
                        }
                    })
                })
            };

            function processName(name) {
                vm.name = JSON.parse($window.localStorage.getItem('token')).user_full_name
                vm.email = JSON.parse($window.localStorage.getItem('token')).email
             //   vm.initials = names[1].trim().substring(0, 1).toUpperCase() + names[0].substring(0, 1).toUpperCase();
            }

            // The event listener beforeunload gets triggered on close of a page / tab / or the browser itself. 
            window.addEventListener("beforeunload", function (e){
                $window.localStorage.setItem('legacy_session', keycloakService.keycloakObj().sessionId)
                if ($window.localStorage.getItem('token')) {
                    keycloakService.clearLegacySessionInSSO()
                }
            })

            vm.logOut = () => {
                $window.localStorage.removeItem('token')
                keycloakService.keycloakObj().logout([{post_logout_redirect_uri:`${__env.mainApi}/login.html`, id_token_hint : keycloakService.keycloakObj().idToken}])
            }

            vm.changePassword = () => {
                $http.get(`${__env.apiUrl}/api/user/change-password/`).then((response) => {
                }, (errorParams) => {
                    console.log('Failed to send the Change Password Email', errorParams)
                });
                modalService.Open('passwordResetModal');
            }

            vm.cancelModal =(modalId) =>{
                modalService.Close(modalId)
            }

            vm.openSettingsViewer = () => {
                $('#insertSettingsModal').html($compile(`<settings-form></settings-form>`)($scope))        
            }

            vm.componentTranslateLabels = (key) => {
                return translateTag(key)
            }
        }
    ]
});
