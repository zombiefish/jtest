angular
    .module('safeToDo')
    .service('vflAuditService', ['$http',
        function ($http) {
            
            return {
                
                createVFLAudit: (payload) => {
                    console.log("This is the VFL Audit payload", JSON.stringify( payload))
                    return $http.post(`${__env.apiUrl}/api/wafs/form-submission-engine/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create VFL Audit', errorParams)
                    })
                },
            //END
            }        
        }
    ])