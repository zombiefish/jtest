safeToDo.component("form138900", {
    // styling found in avatar.css
    templateUrl: 'app/components/vflAuditForm/vflAudit.html',
    bindings: {
        modalId: '<',
        allData: '<',
        mode: '<',
        incidentId: '<',
        onSave: '&',
        onClose: '&'
    },
    controllerAs: 'vm',
    controller: function ($scope,$rootScope, $q, vflAuditService, listService, modalService, profileService, $compile, employeesService, settingsService, menuService) {
        let vm = this
        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        vm.siteList = []
        vm.jobList = []
        vm.jobListSelect = []
        vm.levelList = []
        vm.levelListSelect = []
        vm.employeeList = []
        vm.supervisorList = []
        vm.auditTypeList = []
        vm.hazardTopicList = []
        vm.distributionList = []
        vm.distributionGroupList = []

        //Function to reset form
        function resetForm () {
            document.forms['VFLAuditForm'].classList.remove('was-validated')
            vm.currentVFL = {
                form_name: 1005,
                headerdate: dateToday.format("YYYY-MM-DD"),
                site: '',
                job_number: '',
                level: '',
                workplace: '',
                supervisor: '',
                audit_type: '',
                with_supervisour: '',
                hazard_topic: '',
                pre_audit_meeting_held: '',
                post_audit_meeting_held: '',
                area_visited: '',
                general_comments: '',
                observations: '',
                worker_interaction: '',
                employees_contacted: '',
                Report_Distribution1: []
            }
        }
        

        vm.componentTranslateLabels = (key) => {
            return translateTag(key)
        }

        //Function to get jobs & levels at a site
        vm.getJobsLevels = () => {
            let mainSite = ''
            vm.currentVFL.job_number = null
            vm.currentVFL.level = null
            vm.jobListSelect = []
            vm.levelListSelect = []
            vm.getFilteredEmployees()
            vm.siteList.forEach((rec) => {
                if(rec.rld_id == vm.currentVFL.site)
                { 
                    mainSite = rec.rld_id
                }
            })
            vm.jobList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id == mainSite)
                    vm.jobListSelect.push(rec)
            })
            vm.levelList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id == mainSite)
                    vm.levelListSelect.push(rec)
            })
        }

        vm.getFilteredEmployees = () =>{            
            profileService.filterEmployeeListonJob(vm.currentVFL.job_number)
            vm.employeeList =  profileService.readFilterEmployeeListonJob()
            profileService.filterSupervisorListonJob(vm.currentVFL.job_number)
            vm.supervisorList = profileService.readFilterSupervisorListonJob()
            profileService.filterDistributionListonJob(vm.currentVFL.job_number)
            vm.distributionList = profileService.readFilterDistributionListonJob()
        }

        $scope.$on('distribution-list-added', (event, args) => {
            if(vm.currentVFL !== undefined)
                $scope.$emit('addDistributionGroup', args, vm.currentVFL.Report_Distribution1)
        })

        $scope.$on('distribution-list-removed', (event, args) => {
            $scope.$emit('removeDistributionGroup',args)
         })

        //Function to create the VFL audit
        vm.createVFL = () => {
            let payload = preparePayload(JSON.parse(JSON.stringify(vm.currentVFL)))
            resetFormFieldClassList('VFLAuditForm')
            if(validateFormFields('VFLAuditForm')) {
                vflAuditService.createVFLAudit(payload).then ((response) =>{
                    vm.closeModal('form-138900')
                    $scope.$emit('REFRESH_FORMSUBMISSIONS')
                })
            } else {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        //Function to prepare payload data
        function preparePayload(payload) {
            let preparedPayload = payload
            
            preparedPayload.headerdate = moment(payload.headerdate, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DDThh:mm')
  
            return preparedPayload
        }

        //Function to close the modal
        vm.closeModal = (modalId) => {  
            resetForm()    
            vm.employeeList = []
            vm.supervisorList = []
            vm.distributionList = []
            modalService.Close(modalId)
            vm.loadDefaultSettings()
        }
        
        vm.parseGroup = (data) => {
            // console.log("DATA")

        }

        //Function to refresh all data
        function refreshData() {
            $q.all([
                listService.getSelectListData('ref_site'),
                listService.getSelectListData('ref_job'),
                listService.getSelectListData('ref_level'),
                listService.getSelectListData('ref_audit_type'),
                listService.getSelectListData('ref_hazard_identification'),
                profileService.getDistributionList(),
                profileService.getAllEmployeeProfile(),
                profileService.getAllSupervisorProfile(),
                employeesService.getPersonProfile()
            ]).then((data) => {
                resetForm()
                vm.siteList = data[0]
                vm.jobList = data[1]
                vm.jobList.forEach((job)=>{
                    job.fullJob = `(${job.rld_code}) - ${job.rld_name}`
                })
                vm.levelList = data[2]
                vm.auditTypeList = data[3]
                vm.hazardTopicList = data[4]
                // vm.employeeList = profileService.readAllEmployeeProfile()
                // vm.distributionList = profileService.readDistributionList()
                vm.distributionGroupList = profileService.readdistributionGroupList()
                // listDistributions()
                // vm.supervisorList = profileService.readAllSupervisorProfile()   
                vm.current_user_id = data[8].per_id
            }).then((data)=>{
                vm.loadDefaultSettings()
            })                    
        }
        vm.loadDefaultSettings = () =>  {
            settingsService.getUserProfile(vm.current_user_id).then((response) => {
                vm.siteList.forEach((rec)=>{
                    if(response.upr_site===rec.rld_id){
                        vm.currentVFL.site = response.upr_site
                        vm.getJobsLevels()                            
                    }
                })
                vm.jobList.forEach((rec)=>{
                    if(response.upr_job===rec.rld_id){
                        vm.currentVFL.job_number = response.upr_job
                        vm.getFilteredEmployees()
                    }
                })
                vm.levelList.forEach((rec) => {
                    if(response.upr_level === rec.rld_id){
                        vm.currentVFL.level = response.upr_level
                    }
                })
                vm.supervisorList.forEach((rec)=>{
                    if(response.upr_supervisor_per === rec.per_id){
                        vm.currentVFL.supervisor = rec.per_id
                    }
                })   
                if(response.distribution_list){
                    let email_list = []
                    response.distribution_list.forEach((d)=> {
                        email_list.push(d.email)
                    })
                    vm.currentVFL.Report_Distribution1 = email_list
                }                                        
            })
        }
        refreshData()
    //END
    }    
})