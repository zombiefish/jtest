angular
    .module('safeToDo')
    .service('imageCommentService', ['$http',
        function ($http) {
            return {
                saveComment: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/comments/add-comment/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create comment', errorParams)
                    })
                    return true
                },
                saveMultipleComment: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/comments/add-multiple-comment/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create comment', errorParams)
                    })
                    return true
                },
                updateComment: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/comments/update-comment/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create comment', errorParams)
                    })
                    return true  
                },
                deleteComment: (com_id) => {
                    return $http.post(`${__env.apiUrl}/api/comments/delete-comment/`, com_id).then((response) => {
                        // return response.data;
                    }, (args) => {
                        console.log('Failed to delete comment', args);
                    })
                },
            }
        }
    ])