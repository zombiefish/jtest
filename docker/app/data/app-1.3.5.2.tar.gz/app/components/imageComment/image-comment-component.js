'use strict'
safeToDo.component("commentsModal", {
    templateUrl: 'app/components/imageComment/image-comment.html',
    bindings: {
        modalId: '<',
        savetomemory: '<'
    },
    controllerAs: 'vm',
    controller: function($scope, modalService, imageCommentService, $window, $rootScope,$compile ) {
        let vm = this
        vm.commentValue = ''
        vm.com_cmt_id = null
        vm.com_id = null
        vm.mode = null
        vm.condition = null
        vm.imageid = null
        vm.receivedComment=''
        vm.showDelete = false
        vm.viewOnly = false
        vm.translateLabels = (key) => {
            return translateTag(key)
        }
        vm.modalTitle= vm.translateLabels(8917) //"Image comment"
        
        vm.close = (cancel) => {
            if(cancel){
                vm.commentValue=''
            }
            modalService.Close("imagecommentsmodal")
            let id = document.getElementById('mode').innerHTML

            let mode 
            if(id==''){
                mode = 0
            } else {
                mode = 1
            }
            document.getElementById('viewOnly').innerHTML=''
            let data = vm.preparePayload(mode)
            let behaviour = document.getElementById('callingform').innerHTML
            vm.commentValue = ''
            $rootScope.$broadcast(behaviour,data)
        }

        $scope.$on('RECIEVEROFCOMMENTS',(event,data,modalTitle) => {
            if(modalTitle){
                vm.modalTitle=modalTitle
            }
            document.forms['commentForm'].classList.remove('was-validated')
            vm.commentValue = vm.receivedComment=data
            if(data == null || data.trim() == ''){
                vm.showDelete = false
            } else {
                vm.showDelete = true
            }
            let viewOnly = document.getElementById('viewOnly').innerHTML
            vm.viewOnly = viewOnly == 'true' ? true : false
            modalService.Open('imagecommentsmodal')

        })

        vm.preparePayload = (mode) =>  {
            let rtrn = {}
            rtrn.callingform = document.getElementById('callingform').innerHTML
            vm.savetomemory = document.getElementById('savetomemory').innerHTML
            let edit = 1, add = 0
            if(mode == add || vm.savetomemory=='true'){
                rtrn.com_cmt_id = document.getElementById('parentform').innerHTML //vm.com_cmt_id
                rtrn.com_reference_id = vm.getAttachmentID()
            } else if(mode==edit && vm.savetomemory=='true') {
                rtrn.com_id = document.getElementById('mode').innerText
            }
            if(vm.savetomemory=='false') {     
                rtrn.com_id = document.getElementById('comment_id').innerHTML
            }  
            rtrn.com_comment = vm.commentValue
            return rtrn
        }

        vm.save = () => {  
            resetFormFieldClassList('commentForm')
            if(validateFormFields('commentForm')){
                vm.savetomemory = document.getElementById('savetomemory').innerHTML
                if( vm.savetomemory=='false'){   
                    let id = document.getElementById('mode').innerText // id = mode - coming as 'edit' / 'new'
                    let conditioncheck = document.getElementById('condition').innerText
                    let mode 
                    if(conditioncheck!= ''){
                        if(conditioncheck=='AddCommentOnEmptyExistingImage'){
                            mode = 0
                            vm.savetomemory='true'                        
                        }
                    }
                    else{
                        
                        if(id==''){
                            mode = 0
                        } else {
                            mode = 1
                        }
                    }


                    let payload = vm.preparePayload(mode)
                    if(payload.com_id){
                        imageCommentService.updateComment(payload).then((response) => {
                            vm.close()
                        })
                    } 
                    else {
                        if(document.getElementById('allowmultiple').innerHTML==1){
                            imageCommentService.saveMultipleComment(payload).then((response) => {
                                document.getElementById('comment_id').innerHTML=response.com_id
                                vm.close()
                            })
                        }
                        else{
                            imageCommentService.saveComment(payload).then((response) => {
                                document.getElementById('comment_id').innerHTML=response.com_id
                                vm.close()
                            })
                        }             
                    }            
                } else {
                    vm.close()
                }
            }
            else{
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }
          
        vm.cancel = () => {
            modalService.Close("imagecommentsmodal")
            vm.commentValue=''
        }

        $scope.$on('DIRECTDELETECOMMENT',(event,data) => {
            vm.commentValue = data
            vm.delete()        
        })

        vm.delete = () => {
            let id = document.getElementById('mode').innerText // id = mode - coming as 'edit' / 'new'
            let conditioncheck = document.getElementById('condition').innerText
            let mode 
            if(conditioncheck!= ''){
                if(conditioncheck=='AddCommentOnEmptyExistingImage'){
                    mode = 0
                    vm.savetomemory='true'                        
                }
            }
            else{
                
                if(id==''){
                    mode = 0
                } else {
                    mode = 1
                }
            }
            
            vm.savetomemory= document.getElementById('savetomemory').innerText            
            let data = vm.preparePayload(mode)
            if(vm.receivedComment || data.com_comment || data.com_id){
                if(vm.receivedComment){
                    vm.commentValue=vm.receivedComment
                    vm.commentToDelete = document.getElementById('comment_id').innerHTML
                }
                else{
                    vm.commentToDelete = data.com_id                    
                }
                vm.modalElements = {
                    title: translateLabels(9009),  //"Delete Comments"
                    message: `<div><p>${translateLabels(3455)}</p></div>`,   //"You are about to delete this comment.  Are you sure?"
                    buttons: `<button class='btn btn-outline-primary btn-rounded' ng-click="vm.return('button1')" note="Yes">{{vm.componentTranslateLabels(1379)}}</button>
                    <button class='btn btn-outline-primary btn-rounded' ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>` 
                }
                document.getElementById('confirmcallingform').innerHTML = 'RETURNCOMMENTCONFIRMRESULT' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
            }
            else{
                vm.confirmedDelete()
            }
        }

        $scope.$on("RETURNCOMMENTCONFIRMRESULT", (event,result) => {
            if (result=='button1') {
                vm.confirmedDelete()
            }
        })

        vm.confirmedDelete = () => {
            if(vm.commentToDelete){
                imageCommentService.deleteComment({"com_id": vm.commentToDelete}).then((response) => {
                    modalService.Close('confirmModal')
                })
            }
            vm.commentValue = ''
            vm.commentToDelete = ''
            document.getElementById('parentform').innerHTML=''
            document.getElementById('comment_id').innerHTML=''
            document.getElementById('mode').innerHTML=''
            modalService.Close('confirmModal')
            vm.close()
        }

        vm.getAttachmentID = () => {
            let rtrn =  document.getElementById('imageid').innerText
            return rtrn
        }


    }
})