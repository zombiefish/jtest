'use strict';
safeToDo.component("testBadge", {
    // styling found in avatar.css
    templateUrl: 'app/components/testBadge/testBadge.html',
    bindings: {
        page: '<'
    },
    controllerAs: 'testbadge',

    controller: ['$compile','$scope', '$window', '$element', 
        function ($compile, $scope, $window, $element,) {
            var testbadge = this
            if (__env.test_environment)
                {
                    let badges = document.getElementsByClassName('test-badge')
                    setTimeout(()=>{
                        for(let b = 0; b < badges.length; b++) {
                            badges[b].classList.remove('d-none')  
                        }

                    },500)
                } 
                testbadge.componentTranslateLabels = (key) => {
                return translateTag(key)
            }
        }
    ]
});
