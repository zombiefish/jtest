safeToDo.component("form339913", {
    // styling found in avatar.css
    templateUrl: 'app/components/employeeReview60DayForm/employeeReview60Day.html',
    bindings: {
        modalId: '<',
        allData: '<',
        mode: '<',
        incidentId: '<',
        onSave: '&',
        onClose: '&'
    },
    controllerAs: 'vm',
    controller: function ($scope, $q, employeeReview60DayService, listService, modalService, profileService, $compile, employeesService, settingsService, imageCommentService, $rootScope) {
        let vm = this
        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        vm.siteList = []
        vm.jobList = []
        vm.jobListSelect = []
        vm.levelList = []
        vm.levelListSelect = []
        vm.employeeList = []
        vm.supervisorList = []
        vm.distributionList = []
        vm.target = ''
        vm.mainButton = null
        vm.validateRadioBtns = false

        //Function to reset form
        function resetForm () {
            document.forms['employeeReview60DayForm'].classList.remove('was-validated')
            vm.validateRadioBtns = false
            vm.submitted = false

            vm.currentEmpRev = {
                form_name: '1000', //EMPLOYEE REVIEW 60 DAY
                headerdate: dateToday.format("YYYY-MM-DD"),
                site: null,
                job_number: null,
                level: null,
                workplace: '',
                supervisor: null,
                employee_name: null,
                pay_class: '',
                attitude_score: null,
                safety_score: null,
                performance_score: null,
                class_score: null,
                attendance_score: null,
                results: '',
                goals_1: '',
                goals_2: '',
                goals_3: '',
                employee_signature: '',
                evaluator_signature: '',
                manager_signature: '',
                employee_signature_img_time: '',
                evaluator_signature_img_time: '',
                manager_signature_img_time: '',
                Report_Distribution1: []
            }
        }

        //Function to get jobs & levels at a site
        vm.getJobsLevels = () => {
            let mainSite = vm.currentEmpRev.site
            vm.currentEmpRev.job_number = null
            vm.currentEmpRev.level = null
            vm.jobListSelect = []
            vm.levelListSelect = []
            vm.getFilteredEmployees()
            vm.jobList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id == mainSite)
                    vm.jobListSelect.push(rec)
            })
            vm.levelList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id == mainSite)
                    vm.levelListSelect.push(rec)
            })
            
        }

        vm.getFilteredEmployees = () =>{            
            profileService.filterEmployeeListonJob(vm.currentEmpRev.job_number)
            vm.employeeList =  profileService.readFilterEmployeeListonJob()
            profileService.filterSupervisorListonJob(vm.currentEmpRev.job_number)
            vm.supervisorList = profileService.readFilterSupervisorListonJob()
            profileService.filterDistributionListonJob(vm.currentEmpRev.job_number)
            vm.distributionList = profileService.readFilterDistributionListonJob()
        }

        vm.openSignModal = (e) => {
            if(e.target.tagName.toLowerCase() == 'i') // If clicked on <i>
                e.target = e.target.parentNode

            document.getElementById(`sigModalOK`).removeEventListener('click', signFunction)
            vm.mainButton = e.target
            vm.target = e.target.getAttribute('signaturename')
            $(`#${vm.target}`).val('')
            $(`#${vm.target}_img`).val('')
            $('#output').val('')
            modalService.Open('erev60SignatureModal')
            activateSignature()
        }

        function signFunction(e) {
            e.stopPropagation()
            let vecValue = document.querySelector('#output').value

            if (vecValue) {
                vm.currentEmpRev[vm.target] = $(`.sigPadModal .pad2`)[0].toDataURL('image/jpeg')
                $(`#${vm.target}`).next().val(vecValue)
                $(`#${vm.target}_img`).attr('src', $(`.sigPadModal .pad2`)[0].toDataURL('image/jpeg'))

                img_notes = vm.target + '_img_time'
                time = moment(new Date()).format('YYYY-MM-DD hh:mm:ss a')
                $(`[notes=${img_notes}]`)[0].value = time
                vm.currentEmpRev[img_notes] = time
                $(`[notes=${img_notes}]`)[0].parentElement.classList.remove("d-none")
            } else {
                $(`#${vm.target}`).val('')
                $(`#${vm.target}`).next().val('')
                $(`#${vm.target}_img`).attr('src', '')

                img_notes = vm.target + '_img_time'
                $(`[notes=${img_notes}]`)[0].value = ""
                vm.currentEmpRev[img_notes] = ""
                $(`[notes=${img_notes}]`)[0].parentElement.classList.add("d-none")
            }

            $(`#sigModal .output`).val('')

            if (vecValue) {
                vm.mainButton.innerHTML = `<i class="fa fa-pen" note="Re-sign"></i> ${translateTag(2243)}`
                $(`#${vm.target}`).prev().prev().children()[2].classList.remove('d-none')
                $(`#${vm.target}`).prev().prev().children()[1].classList.remove('d-none') // add comment button
                $(`#${vm.target}`).prev().prev().children()[0].classList.remove('invalid')
            }
            else {
                vm.mainButton.innerHTML = `<i class="fa fa-pen" note="Sign"></i> ${translateTag(1396)}`
                $(`#${vm.target}_img`).attr('src', '')
                $(`#${vm.target}`).prev().prev().children()[2].classList.add('d-none')
                $(`#${vm.target}`).prev().prev().children()[1].classList.add('d-none') // add comment button
                clearComment(vm.mainButton)
            }

            let sig = $('.sigPadModal').signaturePad({})
            sig.clearCanvas()

            modalService.Close('erev60SignatureModal')
        }

        function activateSignature() {
            $('canvas.pad2').attr({ "width": $('.pad2').parent().width(), "height": $('.pad2').parent().width() / 3 })
            setTimeout(() => {                
                let sig = $('.sigPadModal').signaturePad({
                    lineColour: "#ced4da",
                    drawOnly: true,
                    lineWidth: 0,
                    lineBottom: 10,
                    bgColour: 'rgb(255,255,255)'
                })
                sig.clearCanvas()

                document.getElementById(`sigModalOK`).addEventListener('click', signFunction)
                document.getElementById(`reSignButton`).addEventListener('click', (e) => {
                    canvas = e.target.parentNode.previousSibling.previousElementSibling.previousElementSibling
                    let sig = $('.sigPadModal').signaturePad({
                        lineColour: "#ced4da",
                        drawOnly: true,
                        lineWidth: 0,
                        lineBottom: 10,
                        bgColour: 'rgb(255,255,255)'
                    });
                    sig.clearCanvas()
                })
            }, 300)

        }

        $(`.clear_sign`).click((e) => {
            let clear_button
            if(e.target.tagName.toLowerCase() == 'i') // If clicked on <i>
                e.target = e.target.parentNode
       
            clear_button = e.target
            let id=clear_button.id

            let who = id.split('_')[0]
            vm.signed_by = who
            if(vm.signatureCommentObject[who]){
                if(vm.signatureCommentObject[who].com_comment !=''  && vm.signatureCommentObject[who].com_comment !==undefined  ){
                    vm.modalElements = {
                        title: translateTag(2777), //"Remove Signature/Comment?"
                        message: `<div><p>${translateTag(2781)}</p></div>`, //"Are you sure you want to remove the signature and associated comment from the form?"
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                    }  
                    document.getElementById('confirmcallingform').innerHTML = 'EMP60CALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
                    vm.button = clear_button

                } else {
                    clearSignature(clear_button)
                }
            } else {
                clearSignature(clear_button) 
            }
            
        })    
        
        $scope.$on("EMP60CALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.clear_signature_comment()
            }
        })
        
        vm.clear_signature_comment = () => {
            vm.signatureCommentObject[vm.signed_by]=null
            clearSignature(vm.button)
            modalService.Close('confirmModal')
        }
        function clearAllSign () {
            let signImgs = Array.from(document.getElementsByClassName("clear_sign"))

            signImgs.forEach ((clear_button) => {
                clearSignature(clear_button)
            })
            
        }
        
        function clearSignature(clear_button){
            clear_button.previousElementSibling.previousElementSibling.innerHTML = `<i class="fa fa-pen" note="Sign"></i> ${translateTag(1396)}`
            clear_button.parentNode.nextElementSibling.setAttribute('src', '')

            $(`[notes=${clear_button.parentNode.nextElementSibling.id + '_time'}]`)[0].value = ""
            vm.currentEmpRev[clear_button.parentNode.nextElementSibling.id + '_time'] = ""
            $(`[notes=${clear_button.parentNode.nextElementSibling.id + '_time'}]`)[0].parentElement.classList.add("d-none")

            vm.currentEmpRev[clear_button.previousElementSibling.getAttribute('signaturename')] = ''
            clear_button.parentNode.nextElementSibling.nextElementSibling.value = ''
            clear_button.parentNode.nextElementSibling.nextElementSibling.nextElementSibling.value = ''
            clear_button.parentNode.children[1].classList.add('d-none') //hide the add comment button.
            
            //clear comment
            clearComment(clear_button)
            clear_button.classList.add('d-none')
            if (clear_button.parentNode.nextElementSibling.nextElementSibling.hasAttribute('required')) {
                clear_button.previousElementSibling.classList.add('invalid')
            }

        }

        function clearComment(clear_button){
            let who = clear_button.parentNode.nextElementSibling.id.split('_')[0]
            let elem = document.getElementById(`${who}_comment`)
            elem.classList.remove('fas')
            elem.classList.add('far')  
            vm.signatureCommentObject[who] = null
        }

        //Function to create the employee review
        vm.createEmpRev = () => {
            let payload = preparePayload(JSON.parse(JSON.stringify(vm.currentEmpRev)))
            if(vm.validateForm()) {
                vm.submitted = true
                employeeReview60DayService.createEmployeeReview60Day(payload).then ((response) =>{

                     for(let signature of response.signature_ids){
                        let who = signature[1].split('_')[0]

                        if(vm.signatureCommentObject[who] !== null)
                            vm.signatureCommentObject[who]['com_reference_id'] = signature[0]
                    }
                  
                    for(let who in vm.signatureCommentObject){
                        if(vm.signatureCommentObject[who]!=null)
                            imageCommentService.saveComment(vm.signatureCommentObject[who])  
                    }
                    vm.closeModal('form-339913')
                    $scope.$emit('REFRESH_FORMSUBMISSIONS')
                })
            } else {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        //Function to prepare payload data
        function preparePayload(payload) {
            let preparedPayload = payload
            
            preparedPayload.headerdate = moment(payload.headerdate, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DDThh:mm')
  
            return preparedPayload
        }

        //Function to close the modal
        vm.closeModal = (modalId) => {    
            clearAllSign()        
            modalService.Close(modalId)
            vm.employeeList = []
            vm.supervisorList = []
            vm.distributionList = []
            resetForm()   
            refreshData()         
        }

        //Function for form validation
        vm.validateForm = () => {
            let validateFormFlag = validateFormFields('employeeReview60DayForm')
            vm.validateRadioBtns = true
            let formVal = document.forms['employeeReview60DayForm']
            formVal.classList.add('was-validated')
            let validated = true
            for (let a = 0; a < formVal.length; a++) {
              if (!formVal[a].validity.valid) {
                validated = false
              }
              if(formVal[a].id=='vector_employee'){
                if(formVal[a].value == ''){ 
                    document.getElementById('sign_button1').classList.add('invalid')
                    validated = false 
                }
              }

            }         
            // return validated
            
            if(validated && validateFormFlag)
                return true
            else
                return false  
        }

        // Open comment modal 'event'
        vm.AddComments = (who) => {
            vm.signed_by = who
            //set parameters for opening the modal here.
            document.getElementById('parentform').innerHTML = 1
            document.getElementById('savetomemory').innerHTML = true
            document.getElementById('callingform').innerHTML = 'CLOSE60IMAGECOMMENTSMODAL'  
            if(vm.signatureCommentObject[who]!=null) {
                $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.signatureCommentObject[who].com_comment)
            }else{$rootScope.$broadcast("RECIEVEROFCOMMENTS")}  
        }

        vm.signatureCommentObject = {
            employee : null,
            evaluator : null,
            manager : null
        }

        // Close comment modal 'event'
        $scope.$on('CLOSE60IMAGECOMMENTSMODAL',(event,data) => {
            let elem = document.getElementById(`${vm.signed_by}_comment`)
            if(data.com_comment==''){
                vm.signatureCommentObject[vm.signed_by] = null
            }
            if(data.com_comment){
                if(data.com_comment === '' || data.com_comment === null){
                    vm.signatureCommentObject[vm.signed_by] = null
                    elem.classList.remove('fas')
                    elem.classList.add('far')                
                }
                else{
                    elem.classList.remove('far')
                    elem.classList.add('fas')      
                    vm.signatureCommentObject[vm.signed_by] = data
                } 
            } else {
                let elem = document.getElementById(`${vm.signed_by}_comment`)
                elem.classList.remove('fas')
                elem.classList.add('far') 
            }          
        })
        // end comments


        $scope.$on('distribution-list-added', (event, args) => {
            if(vm.currentEmpRev !== undefined)
                $scope.$emit('addDistributionGroup', args, vm.currentEmpRev.Report_Distribution1)
        })

        $scope.$on('distribution-list-removed', (event, args) => {
            $scope.$emit('removeDistributionGroup', args)
        })

        vm.componentTranslateLabels = (key) => {
            return translateTag(key)
        }

        //Function to refresh all data
        function refreshData() {
            $q.all([
                listService.getSelectListData('ref_site'),
                listService.getSelectListData('ref_job'),
                listService.getSelectListData('ref_level'),
                profileService.getAllEmployeeProfile(),
                profileService.getAllSupervisorProfile(),
                profileService.getDistributionList(),
                employeesService.getPersonProfile()
            ]).then((data) => {
                resetForm()
                vm.siteList = data[0]
                vm.jobList = data[1]
                vm.levelList = data[2]
                vm.employeeList = profileService.readAllEmployeeProfile()
                vm.supervisorList = profileService.readAllSupervisorProfile()  
                vm.distributionList = profileService.readDistributionList()  
                vm.current_user_id = data[6].per_id
            }).then((data)=>{
                settingsService.getUserProfile(vm.current_user_id).then((response) => {
                    vm.siteList.forEach((rec)=>{
                        if(response.upr_site===rec.rld_id){
                            vm.currentEmpRev.site = response.upr_site
                            vm.getJobsLevels()
                        }
                    })
                    vm.jobList.forEach((rec)=>{
                        if(response.upr_job==rec.rld_id){
                            vm.currentEmpRev.job_number = response.upr_job
                            vm.getFilteredEmployees()
                        }
                    })
                    vm.levelList.forEach((rec) => {
                        if(response.upr_level === rec.rld_id){
                            vm.currentEmpRev.level = response.upr_level
                        }
                    })
                    vm.supervisorList.forEach((rec)=>{
                        if(response.upr_supervisor_per === rec.per_id){
                            vm.currentEmpRev.supervisor = response.upr_supervisor_per
                        }
                    })
                    if(response.distribution_list){
                        let email_list = []
                        response.distribution_list.forEach((d)=>{
                            email_list.push(d.email)
                        })                   
                        vm.currentEmpRev.Report_Distribution1 = email_list
                    }
                })
            })                      
        }

        refreshData()

    //END
    }
})