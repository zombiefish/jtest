angular
    .module('safeToDo')
    .service('employeeReview60DayService', ['$http',
        function ($http) {            
            return {                
                createEmployeeReview60Day: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/wafs/form-submission-engine/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create Employee Review 60 Day', errorParams)
                    })
                },
            //END
            }        
        }
    ])