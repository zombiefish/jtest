angular
  .module('safeToDo')
  .service('lotoProcedureService', ['$http',
    function ($http) {
        return {

            // create-loto-procedure
            createLOTOProcedure: (payload) => {
                return $http.post(`${__env.apiUrl}/api/loto/create-loto-procedure/`, payload).then((response) => {     
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to get Save LOTO Procedure', errorParams)
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    }
                })


            },
            getLOTOProcedure:(payload)  => {
                return $http.get(`${__env.apiUrl}/api/loto/get-single-loto-procedure/${payload.lth_id}/`).then((response) => {
                    return response.data
                }, (errorParams) => {
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    }
                })
            },
            checkEquipmentTypeID: (payload) =>{
                return $http.post(`${__env.apiUrl}/api/loto/check-equipment-type-id/`, payload).then((response) => {
                
                    return response.data
                }, (errorParams) => {
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    }
                })
            },
            updateLOTOProcedure:(payload)  => {
                return $http.post(`${__env.apiUrl}/api/loto/update-loto-procedure/`, payload).then((response) => {
                
                    return response.data
                }, (errorParams) => {
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    }
                })
            },
            createApprover:(payload) => {
                return $http.post(`${__env.apiUrl}/api/loto/create-approver/`, payload).then((response) => {
                    return response.data
                }, (errorParams) => {
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    } 
                })
            },
            deleteLOTOstepPicture:(payload) => {
                return $http.post(`${__env.apiUrl}/api/loto/delete-equipment-image/`, payload).then((response) => {
                    return response.data
                }, (errorParams) => {
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    } 
                })
            },

        }
    }
])
