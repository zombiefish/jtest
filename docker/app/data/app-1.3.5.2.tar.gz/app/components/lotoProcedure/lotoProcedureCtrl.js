'use strict';
safeToDo.component("lotoModal", {
    templateUrl: 'app/components/lotoProcedure/lotoProcedure.html',
    bindings: {
        lotoid: '@',
        mode: '@',
        doclocklotolockid : '@',
      },
    controllerAs: 'vm',
    controller: ["$scope","$rootScope","$q","listService","lotoEquipmentService","profileService","lotoProcedureService","modalService","employeesService","fileUploadService","$interval","documentLockService",
    function ($scope,$rootScope, $q, listService, lotoEquipmentService, profileService, lotoProcedureService, modalService,employeesService,fileUploadService, $interval,documentLockService ){
        let vm=this
        vm.per_id=null
        vm.translateLabels = (key) =>{
            return translateTag(key)
        }
        vm.sites = []
        vm.jobs = []
        vm.levels = []
        vm.jobsFiltered = []
        vm.levelsFiltered = []
        vm.allEquipment = []
        vm.employeeList = []
        vm.approverIDs = []
        vm.lockoutDeviceItems = vm.translateLabels(1075)
        vm.specialPPEItems = vm.translateLabels(1075)
        vm.accessoryItems = vm.translateLabels(1075)
        vm.showSign = false
        vm.showSave = true

        vm.newStep = (index) => {
            return {
                "lts_id": null,
                "lts_rld_energy_source": null,
                "lts_rld_lockout_device": null,
                "lts_rld_source_location": null,
                "special_ppe": null,
                "accessories": null,
                "lts_element_to_neutralize": null,
                "validation":[{'ltv_id' : null, "ltv_validation_item": ""}],                
                "lts_instruction": null,
                "lta_filename":"",
                "lta_timestamp":null,
                "lts_sort_order": index,
                "lta_id": null,
                "showBrowse": true,
                "attachment": ''
            }
            
        }

        vm.blankLOTOProcedure = {
            "lth_id":null,
            "lth_title":null,
            "lth_lte" : null,
            "lth_equipment_number":"",
            "chd_site" : null,
            "chd_level": null,
            "chd_job": null,
            "lth_chd": null,
            "chd_workplace":null,
            "lth_pre_lockout_instruction" : "",
            "approvers": [],
            "reviewers": [],
            "steps" :[vm.newStep(1)],
            "lth_executive_summary" : "",
            "lth_document_number": null
        }
        vm.currentLOTOProcedure = vm.blankLOTOProcedure
        vm.openingProcedureViewer = true
        vm.hidingProcedureViewer = false

        vm.closeViewer = () => {
            vm.hidingProcedureViewer = true 
            clearInterval(vm.lockModal)
            clearInterval(vm.countdownTimer)
            clearTimeout(vm.relieveLock)
            $interval.cancel(vm.autosave)
            vm.releaseDocument(vm.doclocklotolockid)

            if(document.getElementById("approverDialog")){
                document.getElementById("approverDialog").remove()
            }

            $scope.$emit('STARTSPINNER', translateTag(8479))
            $scope.$emit('CLOSELOTOPROCEDURE')

        }

        vm.initializeSelect2 = (parent, section = "") => {
            setTimeout(()=>{ 
                $('.select-single, .select-multiple')
                  .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent}  ${section}`), escapeMarkup: function (text) { return text } })
                  .on('select2:select', () => {
                      $(this).parent().find('label').addClass('filled')
                  })
                  $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
            }, 100)
        }        
        function dragAndSort(){
            $("#sortable").sortable({
                stop: function( event, ui ) {
                    vm.currentLOTOProcedure.steps.forEach((val, index) => {
                        let tmp = parseInt(event.target.children[index].firstElementChild.id.split('-').pop())
                        vm.currentLOTOProcedure.steps[tmp].lts_sort_order = index+1

                    });
                    let tmp_steps = []
                    vm.currentLOTOProcedure.steps.forEach((val, index) => {
                        let new_index = val.lts_sort_order-1
                        tmp_steps.splice(new_index,0,val)
                    });
                    vm.currentLOTOProcedure.steps = tmp_steps
                    $scope.$apply();
                }
 
            })
        }                    
               
        vm.startup = () => {
            return new Promise(resolve => {
                $q.all([
                    lotoEquipmentService.getAllEquipment(),
                    listService.getSelectListData('ref_energy_source'),
                    listService.getSelectListData('ref_lockout_devices'),
                    listService.getSelectListData('ref_source_and_location'),
                    listService.getSelectListData('ref_accessories'),
                    listService.getSelectListData('ref_personal_protective_equipment'),
                    employeesService.getPersonProfile() 
                ]).then((data) => {
                    vm.allEquipment = data[0]
                    vm.energySource = data[1]
                    vm.lockoutDevices = data[2]
                    vm.sourceLocation = data[3]
                    vm.accessories = data[4]
                    vm.ppe = data[5]
                    vm.per_id = data[6].per_id
                    vm.showSignButton()
                    vm.initializeSelect2('loto-viewer')
                    lotoStartup()
                    $scope.$emit('STOPSPINNER')
                    resolve(true)
                })
            })
        } // entry point to load the form.

        //Function to get jobs & levels at a site
        vm.getJobsLevels = () => {
            let mainSite = vm.currentLOTOProcedure.chd_site
            vm.jobsFiltered = []
            vm.levelsFiltered = []
            vm.jobs.forEach((rec) => {
                if (rec.rld_parent_detail_rld_id == mainSite)
                    vm.jobsFiltered.push(rec)
            })
            vm.levels.forEach((rec) => {
                if (rec.rld_parent_detail_rld_id == mainSite)
                    vm.levelsFiltered.push(rec)
            })
        }
        
        vm.getEquipmentType = () => {
            if(vm.currentLOTOProcedure.lth_lte){
                lotoEquipmentService.getSingleEquipment({"lte_id":vm.currentLOTOProcedure.lth_lte}).then(response => {
                    vm.currentLOTOProcedure.currentEquipment = response
                    if(response.lta_filename != null && response.lta_filename !=''){
                        vm.equipmentPictureURL =`${__env.imageUrl}loto_equipment_attachments/${response.lta_filename}`
                    } else {
                        vm.equipmentPictureURL=''
                    }
                })
            }
        }

        vm.checkUniqueIDEquipment = () => {

            return new Promise((resolve) => {
                if(vm.currentLOTOProcedure.lth_document_number == null || vm.currentLOTOProcedure.lth_document_number =='' || vm.currentLOTOProcedure.lth_document_number.split('.')[1] == 1){
                    let payload = {
                        "lth_lte" : vm.currentLOTOProcedure.lth_lte,
                        "lth_equipment_number" : vm.currentLOTOProcedure.lth_equipment_number
                    }
                    
                    lotoProcedureService.checkEquipmentTypeID(payload).then((response) => {
                        resolve(response.allow)
                    })  
                } else {

                    resolve(true)
                } 
            })
          
        }

        vm.addStep = () => {

            vm.currentLOTOProcedure.steps.push(vm.newStep(vm.currentLOTOProcedure.steps.length+1))
            vm.initializeSelect2('loto-viewer', '.modal-body')
            setTimeout(() => {
                dragAndSort()
            },100)
            vm.showSignButton()

        }
        vm.addValidation = (index) => {
            vm.currentLOTOProcedure.steps[index].validation.push({"ltv_id": null, "ltv_validation_item": ""})
        }
        vm.deleteValidation = (step, index) => {

            vm.currentLOTOProcedure.steps[step].validation.splice(index,1)
        } 

        vm.deleteStep = (index) => {

            if(vm.currentLOTOProcedure.steps[index].lta_id != null){
                let payload ={ "lta_id" : vm.currentLOTOProcedure.steps[index].lta_id }
                lotoProcedureService.deleteLOTOstepPicture(payload).then((response) => {
                    vm.currentLOTOProcedure.steps.splice(index,1)  
                    vm.saveLOTOProcedure()
                })
            } else {
                vm.currentLOTOProcedure.steps.splice(index,1)  
                vm.saveLOTOProcedure()  
            }
            vm.showSignButton()
            vm.initializeSelect2() 

            
        }
        vm.lockoutDevice = () => {
            let name = ''
            vm.lockoutDeviceItems = ''
            for(let s=0;s<vm.currentLOTOProcedure.steps.length; s++){
                for(let i=0;i<vm.lockoutDevices.length;i++){
                    if(vm.lockoutDevices[i].rld_id == vm.currentLOTOProcedure.steps[s].lts_rld_lockout_device){
                        if(!name.includes(vm.lockoutDevices[i].rld_name)){
                            name += vm.lockoutDevices[i].rld_name + ', '
                        }
                    }
                }
                vm.lockoutDeviceItems = name.slice(0,-2)
            }
            if(vm.lockoutDeviceItems == ''){
                vm.lockoutDeviceItems = vm.translateLabels(1075)
            }
        }
        
        vm.accessory = () => {
            let name = ''
            vm.accessoryItems = ''
            for(let s=0;s<vm.currentLOTOProcedure.steps.length; s++){
                if(vm.currentLOTOProcedure.steps[s].accessories != undefined){
                    for(let i=0;i<vm.accessories.length;i++){
                        for(let j=0;j<vm.currentLOTOProcedure.steps[s].accessories.length;j++){
                            if(vm.accessories[i].rld_id == vm.currentLOTOProcedure.steps[s].accessories[j]){
                                if(!name.includes(vm.accessories[i].rld_name)){
                                    name += vm.accessories[i].rld_name + ', '
                                }
                            }
                        }
                    }
                }
                vm.accessoryItems = name.slice(0,-2)
            }
            if(vm.accessoryItems == ''){
                vm.accessoryItems = vm.translateLabels(1075)
            }
        }

        vm.specialPPE = () => {
            let name = ''
            vm.specialPPEItems = ''
            for(let s=0;s<vm.currentLOTOProcedure.steps.length; s++){
                if(vm.currentLOTOProcedure.steps[s].special_ppe != undefined){
                    for(let i=0;i<vm.ppe.length;i++){
                        for(let j=0;j<vm.currentLOTOProcedure.steps[s].special_ppe.length;j++){
                            if(vm.ppe[i].rld_id == vm.currentLOTOProcedure.steps[s].special_ppe[j]){
                                if(!name.includes(vm.ppe[i].rld_name)){
                                    name += vm.ppe[i].rld_name + ', '
                                }
                            }
                        }
                    }
                }
                vm.specialPPEItems = name.slice(0,-2)
            }
            if(vm.specialPPEItems == ''){
                vm.specialPPEItems = vm.translateLabels(1075)
            }
        }

        vm.showSignButton = () => {
            // if the current user is an approver, show the submit button.
            let signed = false
            if(vm.approverIDs){

                if(vm.approverIDs.includes(vm.per_id)  && vm.currentLOTOProcedure.steps.length > 0 ){
                    vm.showSign = true
                } else {
                    vm.showSign = false
                    
                }
            } else {
                vm.showSign = false
            }
            if(vm.currentLOTOProcedure.approvers){
                for(let i=0;i<vm.currentLOTOProcedure.approvers.length;i++){
                    let app = vm.currentLOTOProcedure.approvers[i]
                    if(app.cap_per_id == vm.per_id && app.cap_is_approved){
                        vm.currentUserSigned = true
                        vm.showSave = false
                    }
                }
            }
            if(vm.mode =='view') {
                vm.showSave = false
                for(let i of vm.currentLOTOProcedure.approvers){ 
                    if(parseInt(i.cap_per_id)==parseInt(vm.per_id) && i.cap_is_approved==true){
                        vm.showSign = false
                    }   
                }
            } 
            if(vm.mode == 'viewexpired'){
                vm.showSave = false
                vm.showSign = false
            }
        }


        vm.saveLOTOProcedure= (m = null) =>{
            return new Promise((resolve) => {
                
                if(m!='autosave')
                    $scope.$emit('STARTSPINNER', translateTag(9362))
                if(vm.currentLOTOProcedure.lth_id == null){

                    vm.addToApprovers()
                    lotoProcedureService.createLOTOProcedure(vm.currentLOTOProcedure).then((results) => {

                        for(let i=0;i<vm.currentLOTOProcedure.steps.length;i++){
                            vm.currentLOTOProcedure.steps[i].validation = results.loto_procedure_data.steps[i].validation
                        }
                        toastr.success(translateTag(4278)) // Saved Successfully
                        vm.initializeSelect2('loto-viewer') 
                        $scope.$emit('STOPSPINNER')
                        vm.showSignButton()
                        for(let i=0;i<vm.currentLOTOProcedure.steps.length;i++){
                            vm.currentLOTOProcedure.steps[i].validation = results.loto_procedure_data.steps[i].validation
                            vm.currentLOTOProcedure.steps[i].lts_id = results.loto_procedure_data.steps[i].lts_id
                        }
                        vm.currentLOTOProcedure.lth_id = results.loto_procedure_data.lth_id
                        vm.currentLOTOProcedure.lth_document_number = results.loto_procedure_data.lth_document_number
                        vm.currentLOTOProcedure.approvers = results.loto_procedure_data.approvers
                        vm.doclocklotolockid = vm.currentLOTOProcedure.lth_id
                        resolve(true)
                    })

                } else {
                    // Update the procedure.
                    vm.addToApprovers()
                    lotoProcedureService.updateLOTOProcedure(vm.currentLOTOProcedure).then((results)=> {
                        for(let i=0;i<vm.currentLOTOProcedure.steps.length;i++){
                            vm.currentLOTOProcedure.steps[i].validation = results.loto_procedure_data.steps[i].validation
                            vm.currentLOTOProcedure.steps[i].lts_id = results.loto_procedure_data.steps[i].lts_id
                        }
                        vm.currentLOTOProcedure.lth_id = results.loto_procedure_data.lth_id
                        vm.currentLOTOProcedure.lth_document_number = results.loto_procedure_data.lth_document_number
                        vm.currentLOTOProcedure.approvers = results.loto_procedure_data.approvers
                        $scope.$emit('STOPSPINNER')
                        toastr.success(translateTag(4278)) // Saved Successfully
                        vm.showSignButton()
                        vm.initializeSelect2('loto-viewer')
                        resolve(true)
                    })

                }

            })
            
        }

        vm.submitLOTOProcedure = () => {
            //validate fields.
            let validate = validateFormFields("lotoModal")
            $scope.$emit("STOPSPINNER")
            if(!validate){
                $rootScope.$broadcast("CALLCONFIRMMODAL")

            } else {

                // if the current user has already signed or it has been signed by someone already then 
                // no need to check the unique equipment ID combination.

                let signed = false

                for(let i = 0;i<vm.currentLOTOProcedure.approvers.length;i++){
                    if(vm.currentLOTOProcedure.approvers[i].cap_is_approved){
                        signed = true
                    }
                }
                
                if(!signed){
                    vm.checkUniqueIDEquipment().then((allow) => {
                        if(allow){
                            vm.saveLOTOProcedure().then(() =>{

                                //show approvers dialog
                                modalService.Open('approverDialog')

                            })   
                        } else {
                            //set the equipment fields to not validated.
                            document.getElementById('lth_equipment_number').classList.add('invalid')
                            $rootScope.$broadcast("CALLCONFIRMMODAL")
                        }
                    
                    })
                } else {
                    vm.saveLOTOProcedure().then(() =>{

                        //show approvers dialog
                        modalService.Open('approverDialog')
                    })
                }
                 
            }


        
        }

        vm.signLOTOProcedure = () => {
            for(let i = 0; i < vm.currentLOTOProcedure.approvers; i++){
                let approver = vm.currentLOTOProcedure.approvers[i]
                if(approver.cap_per_id == vm.per_id){
                    approver.cap_is_approved = true
                }
            }

            let payload = {
                "lth_id": vm.currentLOTOProcedure.lth_id,
                "lth_executive_summary": vm.currentLOTOProcedure.lth_executive_summary
            }
            lotoProcedureService.createApprover(payload).then((response) => {
                //remove the sign and save buttons.
                modalService.Close('approverDialog')
                vm.saveLOTOProcedure()
                vm.showSave = false
                vm.mode = 'view'
                vm.currentUserSigned = true
                for(let i =0; i < vm.currentLOTOProcedure.steps.length;i++){
                    vm.currentLOTOProcedure.steps[i].showBrowse = false
                }
           })

        }

        vm.getApproverIDs = ()=>{
            vm.approverIDs = []
            for(let i = 0;i<vm.currentLOTOProcedure.approvers.length; i++){
                vm.approverIDs.push(vm.currentLOTOProcedure.approvers[i].cap_per_id)
            }
        }

        vm.addToApprovers = () => {
            vm.currentLOTOProcedure.approvers = vm.approverIDs
            vm.showSignButton()
        }

        vm.getBaseData = () => {
            return new Promise(resolve => {
                $q.all([
                    listService.getSelectListData('ref_site'),
                    listService.getSelectListData('ref_job'),
                    listService.getSelectListData('ref_level'),
                    profileService.getAllEmployeeProfile()
                ]).then((data) => {
                    vm.sites = data[0]
                    vm.jobs = data[1]
                    vm.levels = data[2]
                    vm.employeeList = profileService.readAllEmployeeProfile() 
                    resolve(true)
                })
            })
        }
        vm.$onInit = () => {
            // activate autosave.
            vm.autosave = $interval(() => {
                if(vm.mode != 'view'){
                    vm.saveLOTOProcedure('autosave')
                }
              }, 30000)
      
            let payload
            switch(vm.mode){
                case 'edit':
                    payload = {
                        "lth_id": vm.lotoid
                    }

                    vm.getBaseData().then(() => {
                        lotoProcedureService.getLOTOProcedure(payload).then((response) =>{
                            vm.currentLOTOProcedure = response    
                            vm.populateStepPictures()      
                            vm.getApproverIDs()
                            vm.getJobsLevels()
                            vm.startup().then(() => {
                               
                                //if a loto was saved without a step, then just add a step.
                                if(vm.currentLOTOProcedure.steps.length ==0){
                                    vm.currentLOTOProcedure.steps.push(vm.newStep(1))
                                    
                                }
                                vm.showSignButton()
                                vm.accessory()
                                vm.specialPPE()
                                vm.lockoutDevice()
                                vm.getEquipmentType()
                                dragAndSort()
                            }) 
                        })
                    })
                    break
                case 'new':
                    vm.getBaseData()
                    vm.startup()
                    dragAndSort()
                    vm.mode = 'edit'
                    break
                case 'view':
                    payload = {
                        "lth_id": vm.lotoid
                    }

                    vm.getBaseData().then(() => {
                        lotoProcedureService.getLOTOProcedure(payload).then((response) =>{
                            vm.currentLOTOProcedure = response    
                            vm.populateStepPictures()      
                            vm.getApproverIDs()
                            vm.getJobsLevels()
                            vm.startup().then(() => {
                                vm.showSignButton()
                                vm.accessory()
                                vm.specialPPE()
                                vm.lockoutDevice()
                                vm.getEquipmentType()
                                for(let i = 0;i<vm.currentLOTOProcedure.steps.length;i++){
                                    vm.currentLOTOProcedure.steps[i].showBrowse = false
                                }
                            }) 
                        })
                    })
                case 'viewexpired':
                    payload = {
                        "lth_id": vm.lotoid
                    }

                    vm.getBaseData().then(() => {
                        lotoProcedureService.getLOTOProcedure(payload).then((response) =>{
                            vm.currentLOTOProcedure = response    
                            vm.populateStepPictures()      
                            vm.getApproverIDs()
                            vm.getJobsLevels()
                            vm.startup().then(() => {
                                vm.accessory()
                                vm.specialPPE()
                                vm.lockoutDevice()
                                vm.getEquipmentType()
                                vm.mode = 'view'
                                vm.showSignButton()
                            }) 
                        })
                    })  
            }
            
        }
        
        vm.populateStepPictures= () => {
            for(let i = 0;i < vm.currentLOTOProcedure.steps.length; i ++){
                let fn = vm.currentLOTOProcedure.steps[i].lta_filename
                let display = true
                if(fn == null){
                    display = false
                } else if(fn.length == 0){
                    display = false
                }

                if(display == true){                    
                    vm.currentLOTOProcedure.steps[i].attachment = `${__env.imageUrl}loto_equipment_attachments/${fn}` 
                    vm.currentLOTOProcedure.steps[i].showBrowse =false
                } else {
                    vm.currentLOTOProcedure.steps[i].attachment=''
                    if(vm.mode=="view"){
                        vm.currentLOTOProcedure.steps[i].showBrowse = false
                        vm.showSign = false
                    }
                    else{
                        vm.currentLOTOProcedure.steps[i].showBrowse = true
                    }                    
                }
            }
        }

        vm.cancelApprover = () => {
            resetFormFieldClassList('lotoModal')
            modalService.Close('approverDialog')
        }
      
        vm.deleteLOTOPicture = (index) => {
            if(index != null){
                vm.currentLOTOProcedure.steps[index].lta_filename = ''
                vm.currentLOTOProcedure.steps[index].lta_timestamp = null
                vm.currentLOTOProcedure.steps[index].attachment = ''
                vm.currentLOTOProcedure.steps[index].showBrowse = true
                $scope.$emit('STARTSPINNER', translateTag(9362))    
                let payload = {
                    "lta_id": vm.currentLOTOProcedure.steps[index].lta_id
                }
                lotoProcedureService.deleteLOTOstepPicture(payload).then((response) => {
                    vm.saveLOTOProcedure()
                })
            }
        }
        vm.convertTime = (timestamp) =>{
            if(timestamp !=undefined){
                return moment(timestamp).format("YYYY-MM-DD hh:mm:ss a")
            }
        }
        $scope.lotoStepPictureChanged = (event)=> {
            //Get data from files to display in html
            let index = parseInt(event.currentTarget.id.split('_')[1])
            vm.uploadFile = fileUploadService.checkFileUpload(event.target.files, [], true)
            fileUploadService.getFileUploadData(vm.uploadFile).then((filesData) => {
                vm.currentLOTOProcedure.steps[index].attachment = filesData[0].url 

                vm.currentLOTOProcedure.steps[index].lta_filename = filesData[0].file 
                vm.currentLOTOProcedure.steps[index].lta_timestamp = filesData[0].timestamp
                vm.currentLOTOProcedure.steps[index].showBrowse = false 
                // Update html bindings
                vm.saveLOTOProcedure().then(() =>{

                    let lts_id = vm.currentLOTOProcedure.steps[index].lts_id
                    let fd = new FormData()
                    fd.append('lta_lts_id', lts_id)
                    fd.append('lta_filename', vm.uploadFile[0])
                    fd.append("lta_timestamp",  moment.unix(vm.uploadFile[0].lastModified/1000).format('YYYY-MM-DD HH:mm:ss'))
                    lotoEquipmentService.saveEquipmentAttachment(fd).then((response) => {

                        let id = response.data['Successfull Files']['ids'][0]
                        vm.currentLOTOProcedure.steps[index].lta_id = id
                    })
                })
            })
        }

        function lotoStartup() {
            startUpdateDocLock()
            //Zero the idle timer on mouse movement.
            $('#lotoModal').mousemove(function (e) {
              clearInterval(vm.lockModal)
              vm.idletime = 0
              startLockModal()
            })
      
            //Zero the idle timer on keypress event
            $('#lotoModal').keypress(function (e) {
                clearInterval(vm.lockModal)
                vm.idletime = 0
                startLockModal()
            })
          }
    

        // functions for document lock start__
        vm.continueEditingLOTO = () => {
            modalService.Close('confirmModal')
            vm.countdownSeconds = 60 
            vm.content = "01:00"
            document.getElementById('inactiveTime').textContent = ''
            vm.lockCheckModal = false
            vm.continueEditing = true
            clearInterval(vm.lockModal)
            clearTimeout(vm.relieveLock)
            clearInterval(vm.countdownTimer)
            vm.idletime = 0
            startLockModal()

        }
        
        function startUpdateDocLock(){
            vm.updateDocLockInterval = setInterval(() => {
                if(vm.doclocklotolockid){
                    $q.all([
                        documentLockService.intervalDocLock(vm.doclocklotolockid)
                    ]).then((response) => {
                    })
                }
            }, 30 * 1000)
        
        }

        function startLockModal(){
            vm.lockModal = setInterval(() => {
                vm.idletime = vm.idletime + 1 // 1 minute
                if(vm.idletime === 5){ // after 5 minutes of idle time open lockcheck modal
                    vm.continueEditing = false
                    vm.leaveEditing = false                        
                    vm.modalElementsLock = {
                        title: translateTag(3419),   //"Page inactive for 5 minutes" 
                        message: `<div style="text-align: center;"><h1 id ="inactiveTime" ></h1><p> ${translateTag(3420)}</p></div>`,  //"The entry will automatically save and close if no action is taken"
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Continue Working">{{vm.componentTranslateLabels(3421)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Save and Close">{{vm.componentTranslateLabels(3422)}}</button>`
                    }
                    document.getElementById('confirmcallingform').innerHTML = 'LOTOLOCKCALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsLock)
                    vm.lockCheckModal = true
                    startcountdownTimer()
                    vm.relieveLock = setTimeout(() => {
                        if (vm.lockCheckModal === true){
                            if (!vm.continueEditing && !vm.leaveEditing){
                                vm.leaveEditing = true
                                vm.saveLOTOProcedure()
                                vm.closeLockModal()
                            }
                        }
                    }, 60 * 1000);
                }                                        
            }, 60 * 1000);
        }

        $scope.$on("LOTOLOCKCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.continueEditingLOTO()
            } else if (result=='button2') {
                vm.closeLockModal()
            }
        })

        vm.closeLockModal = () => {
            modalService.Close("confirmModal")
            vm.saveLOTOProcedure()
            vm.closeViewer()
        }


        // function to release document lock
        vm.releaseDocument = (id) => {
            vm.payload = {}
            vm.payload.dlo_id = id
            return (
                $q.all([
                    documentLockService.closeDocLock(vm.payload).then((response) => {
                    })
                ])
            )
        }

        function startcountdownTimer(){
            vm.countdownTimer = setInterval(() => {
                if(vm.lockCheckModal === true && vm.countdownSeconds>=0){
                    vm.content = ''
                    if (vm.countdownSeconds === 60){
                        vm.content = "01:00"
                    }
                    else{
                        vm.content = "00:" + vm.countdownSeconds.toLocaleString('en-US', {
                            minimumIntegerDigits: 2,
                            useGrouping: false
                            }) 
                    }
                    document.getElementById('inactiveTime').textContent =  vm.content
                    vm.countdownSeconds = vm.countdownSeconds - 1   
                }                                         
            }, 1000)
        }

        // functions for document lock end___ 
    }]
})