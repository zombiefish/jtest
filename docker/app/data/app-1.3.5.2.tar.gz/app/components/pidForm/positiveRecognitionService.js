﻿angular
  .module('safeToDo')
  .service('positiveRecognitionService', ['$http', '$q',
    function ($http, $q) {

       return {
        createPositiveRecognition: (payload) => {
          return $http.post(`${__env.apiUrl}/api/recognition/add-positive-id/`, payload).then((response) => {
              return response.data
          }, (errorParams) => {
              console.log('Failed to create Positive Recognition', errorParams)
          })
       }, 
        addPositiveRecognitionAttachments: (payload) => {
          return $http.post(`${__env.apiUrl}/api/recognition/add-positive-id-attachments/`, payload,{
              // this cancels AngularJS normal serialization of request
              transformRequest: angular.identity,
              // this lets browser set `Content-Type: multipart/form-data` 
              // header and proper data boundary
              headers: {'Content-Type': undefined}}).then((response) =>{
              return response
          }, (errorParams) => {
              console.log('Failed to add general action attachment', errorParams)
          })
        }
      }
    }
  ])