safeToDo.component("positiveRecognitionForm", {
    templateUrl: 'app/components/pidForm/positiveRecognition.html',
    bindings: {
        modalId: '<',
        allData: '<',
    },
    controllerAs: 'vm',
    controller: function ($q,$controller, $scope,modalService, listService, profileService, positiveRecognitionService, $compile, employeesService, settingsService, imageCommentService,$window,$rootScope, fileUploadService) {
        let vm = this
        $controller('distributionGroupCtrl', {$scope: $scope})
        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        vm.siteList = []
        vm.jobList = []
        vm.jobListSelect = []
        vm.levelList = []
        vm.levelListSelect = []
        vm.recognitionTypeList = []
        vm.recognitionGivenList = []
        vm.employeeList = []
        vm.distributionList = []
        vm.supervisorList = []
        vm.newInitialAttachments = []
        vm.pidUploadFileList = []

        vm.$onInit = () => {
            refreshData()
        }

        //Function to close the modal
        vm.closeModal = (modalId) => {
            resetFormFieldClassList('recognitionForm')
            modalService.Close(modalId)
            createPositiveRecognition()   
            refreshData()      
            vm.newInitialAttachments = []
            vm.pidUploadFileList = []
            vm.employeeList = []
            vm.distributionList = []
            vm.supervisorList = []
            $scope.$emit('PID_CLOSEMODAL')
        }

        //Function to delete attachments
        vm.deleteInitialAttachment = (index) => {
            vm.deleteAttachmentConfirmationModal(index)  
            for (let image_index=0;image_index<vm.newInitialAttachments.length;image_index++){
                if(vm.newInitialAttachments[image_index].comment){
                    if(vm.newInitialAttachments[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                } else {
                    let elem = document.getElementById('comment_' + image_index)
                    elem.classList.remove('fas')
                    elem.classList.add('far')
                }
            }    
        }     

        vm.deleteIndex = null
        //Function to open delete Attachment Confirmation Modal
        vm.deleteAttachmentConfirmationModal = (index) => {
            vm.deleteIndex = index
            vm.modalElements = {
                title: translateTag(3416), //"Delete Attachment?"
                message: `<div><p>${translateTag(1452)}</p></div>`, //"You are about to delete this attachment.Are you sure?"
                buttons: 
                    `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                    <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'PRCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("PRCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.deleteInitAttachmentAfterConfirmation(vm.deleteIndex)
            }
        })

        //Function to delete initial attachments after click "ok" in Confirmation modal
        vm.deleteInitAttachmentAfterConfirmation = (index) => {
            vm.pidUploadFileList.splice(index, 1)
            vm.newInitialAttachments.splice(index, 1)  
            vm.deleteIndex = null
            modalService.Close('confirmModal')
        }

        vm.convertTime = (timestamp) =>{
            return moment(timestamp).format("YYYY-MM-DD hh:mm:ss a")
        }
        
        $scope.initialPositiveRecognitionUploadChanged = (event)=> {

            let existingFileNames = []
            for(let i in vm.pidUploadFileList) {
                existingFileNames.push(vm.pidUploadFileList[i].name)
            }

            //Add newly selected files after checking for duplicates and correct file types
            vm.pidUploadFileList = vm.pidUploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, existingFileNames, true))
            
            //Get data from files to display in html
            fileUploadService.getFileUploadData(vm.pidUploadFileList).then ((filesData) => {
                vm.newInitialAttachments = filesData
                $scope.$apply() // Update html bindings
            })
        }        

        //Function to reset form
        function createPositiveRecognition() {
            vm.submitted = false

            vm.currentPositiveRecognition = {
                HeaderDate: dateToday.format("YYYY-MM-DD"),
                Site: null,
                JobNumber: null,
                SiteLevel: null,
                Workplace: '',
                Supervisor: null,
                RecognitionType : null,
                EventDescription  : '',
                WasRecognitionGiven : null,
                RecognitionGivenType: null,
                RecognitionOf: [] ,
                Distribution: []
            }
            vm.newInitialAttachments = []
            vm.pidUploadFileList = []
        }

        vm.getFilteredEmployees = () =>{
            profileService.filterEmployeeListonJob(vm.currentPositiveRecognition.JobNumber)
            vm.employeeList =  profileService.readFilterEmployeeListonJob()
            profileService.filterSupervisorListonJob(vm.currentPositiveRecognition.JobNumber)
            vm.supervisorList = profileService.readFilterSupervisorListonJob()
            profileService.filterDistributionListonJob(vm.currentPositiveRecognition.JobNumber)
            vm.distributionList = profileService.readFilterDistributionListonJob()
        }

        //Function to get jobs & levels at a site
        vm.getJobsLevels = () => {
            let mainSite = vm.currentPositiveRecognition.Site
            vm.currentPositiveRecognition.JobNumber = null
            vm.currentPositiveRecognition.SiteLevel = null
            vm.jobListSelect = []
            vm.levelListSelect = []
            vm.getFilteredEmployees()
            vm.jobList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id == mainSite)
                    vm.jobListSelect.push(rec)
            })
            vm.levelList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id == mainSite)
                    vm.levelListSelect.push(rec)
            })            
        }

        vm.AddComments=(index) =>{
            document.getElementById('mode').innerText = '0'
            document.getElementById('relatedimageindex').innerText = index
            document.getElementById('imageid').innerText = index
            document.getElementById('callingform').innerHTML = 'CLOSEPOSIMAGECOMMENTSMODAL'
            document.getElementById('savetomemory').innerHTML = true
            document.getElementById('parentform').innerHTML = 6  
            
            if(vm.newInitialAttachments[index].comment){
                //editing.
                $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.newInitialAttachments[index].comment.com_comment)

            } else {
                $rootScope.$broadcast("RECIEVEROFCOMMENTS","")
 
            }
        }

        $scope.$on('CLOSEPOSIMAGECOMMENTSMODAL',(event,data) => {
            if(data.com_comment.comment !=''){
                let image_index = document.getElementById('relatedimageindex').innerText
                vm.newInitialAttachments[image_index].comment = data
                vm.newInitialAttachments[image_index].comment.com_reference_id = image_index
                if(vm.newInitialAttachments[image_index].comment){
                    if(vm.newInitialAttachments[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                }
            } else {
                let elem = document.getElementById('comment_' + image_index)
                elem.classList.remove('fas')
                elem.classList.add('far') 
            }
        })

        //Function to submit positive ID
        vm.submitPositiveRecognition = () => {
            let ufl = [...vm.pidUploadFileList]
            let att = [...vm.newInitialAttachments]    
            if(vm.validateForm())
            {
                vm.submitted = true
                positiveRecognitionService.createPositiveRecognition(vm.currentPositiveRecognition).then ((res) => {
                  for (let i in ufl) {
                        let fd = new FormData()
                        fd.append("SubmissionPositiveRecognitionID", res.submission_Positive_Recognition_Id)
                        fd.append("filename", ufl[i])
                        fd.append("spa_image_timestamp", moment.unix(ufl[i].lastModified/1000).format('YYYY-MM-DD HH:mm:ss'))
                        //Console log form data
                        for (let pair of fd.entries()) {
                            // console.log(pair[0]+ ' : ' + pair[1])
                        }
                        if(ufl.length > 0 ) {
                            positiveRecognitionService.addPositiveRecognitionAttachments(fd).then((res) => {
                                //save the comments here.
                                let sfiles = res.data.response["Successfull Files"]
                                let attached_count = 0
                                for(attached of sfiles.allowed_original){
                                    // console.log("UPLOAD FILE LIST", vm.pidUploadFileList)
                                    for(newA of att){
                                        if(newA.comment){
                                            if(attached==newA.file){
                                             
                                                newA.comment.com_reference_id = sfiles.ids[attached_count]
                                                imageCommentService.saveComment(newA.comment)

                                            }
                                        }
                                    }
                                    attached_count++
                                } 
                            })
                        }
                        else {
                            // $scope.$emit('PID_REFRESHDATA')
                            
                        }
                    }

                    $scope.$emit('PID_REFRESHDATA')
                    $scope.$emit('REFRESH_FORMSUBMISSIONS')
                    vm.closeModal('positiveRecognitionModal')
                 })              
                
            } else {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        //Function for form validation
        vm.validateForm = () => {
            return validateFormFields('recognitionForm')
        }
 
        $scope.$on('distribution-list-added', (event, args) => {
            if(vm.currentPositiveRecognition !== undefined)
                $scope.$emit('addDistributionGroup', args, vm.currentPositiveRecognition.Distribution)
        })

        $scope.$on('distribution-list-removed', (event, args) => {
            $scope.$emit('removeDistributionGroup',args)
        })

        vm.componentTranslateLabels = (key) => {
            return translateTag(key)
        }       

        //Function to refresh all data
        function refreshData() {
            $q.all([
                listService.getSelectListData('ref_site'),
                listService.getSelectListData('ref_job'),
                listService.getSelectListData('ref_level'),
                listService.getSelectListData('ref_recognition_type'),
                listService.getSelectListData('ref_recognition_given'),
                profileService.getAllEmployeeProfile(),
                profileService.getAllSupervisorProfile(),
                profileService.getDistributionList(),
                employeesService.getPersonProfile()
            ]).then((data) => {
                createPositiveRecognition()
                vm.siteList = data[0]
                vm.jobList = data[1]
                vm.jobList.forEach((job)=>{
                    job.fullJob = `(${job.rld_code}) - ${job.rld_name}`
                })
                vm.levelList = data[2]
                vm.recognitionTypeList = data[3]
                vm.recognitionGivenList = data[4]
                // vm.employeeList = profileService.readAllEmployeeProfile()
                // vm.supervisorList = profileService.readAllSupervisorProfile()
                // vm.distributionList = profileService.readDistributionList()   
                vm.current_user_id = data[8].per_id         
            }).then((data)=>{
                settingsService.getUserProfile(vm.current_user_id).then((response) => {
                    vm.siteList.forEach((rec)=>{
                        if(response.upr_site===rec.rld_id){
                            vm.currentPositiveRecognition.Site = response.upr_site
                            vm.getJobsLevels()
                        }
                    })
                    vm.jobList.forEach((rec)=>{
                        if(response.upr_job==rec.rld_id){
                            vm.currentPositiveRecognition.JobNumber = response.upr_job
                            vm.getFilteredEmployees()
                        }
                    })
                    vm.levelList.forEach((rec) => {
                        if(response.upr_level === rec.rld_id){
                            vm.currentPositiveRecognition.SiteLevel = response.upr_level
                        }
                    })
                    vm.supervisorList.forEach((rec)=>{
                        if(response.upr_supervisor_per === rec.per_id){
                            vm.currentPositiveRecognition.Supervisor = response.upr_supervisor_per
                        }
                    })

                    if(response.distribution_list){
                        let email_list = []
                        response.distribution_list.forEach((d)=>{
                            email_list.push(d.email)
                        })                   
                        vm.currentPositiveRecognition.Distribution = email_list
                    }
                })
            })    
        }
        refreshData()
        
    //End of controller
    }
})