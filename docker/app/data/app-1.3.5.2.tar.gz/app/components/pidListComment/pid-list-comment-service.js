angular
    .module('safeToDo')
    .service('pidListCommentService', ['$http',
        function ($http) {
            let commentLikes = [];

            return {
                deleteCommentLike: (pcl_id) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/delete-comment-like/`, pcl_id).then((response) => {
                        // return response.data;


                    }, (args) => {
                        console.log('Failed to delete comment like', args);
                    })
                },

                addCommentLike: (com_id) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/add-comment-like/`, com_id).then((response) => {
                        // return response.data;
                    }, (args) => {
                        console.log('Failed to add comment like', args);
                    })
                },


                getComment: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/get-comment-list/`, payload).then((response) => {
                        comment=response.data
                    }, (errorParams) => {
                        console.log('Failed to create comment', errorParams)
                    })
                },              


                getCommentLikes: (com_id) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/get-comment-likes/`, com_id).then((response) => {
                        commentLikes = response.data;
                    }, (args) => {
                        console.log('Failed to get comment like', args);
                    })
                },
                readCommentLikes: () => {
                    return commentLikes;
                },
                readComments: () => {
                    return comment
                }
            }
        }
    ])