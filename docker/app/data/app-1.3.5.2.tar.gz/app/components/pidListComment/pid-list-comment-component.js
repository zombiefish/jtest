'use strict'
safeToDo.component("pidListCommentsModal", {
    templateUrl: 'app/components/pidListComment/pid-list-comment.html',
    bindings: {
        modalId: '<',
        savetomemory: '<',
    },
    controllerAs: 'vm',
    controller: function($scope, modalService, pidListCommentService, positiveIdService, $window, $rootScope,gridService) {
        let vm = this
        vm.commentHistory = ''
        vm.com_cmt_id = null
        vm.com_id = null
        vm.mode = null
        vm.condition = null
        vm.imageid = null
        vm.options = gridService.getCommonOptions()
        
        let positiveIdListCommentsColumns = [
            {
                field: "review",
                headerName: " ", // Review
                minWidth: 125,
                maxWidth: 125,
                suppressMenu: true,
                cellRenderer: function (params) {
                    var can_edit_comment = vm.per_id == params.data.com_created_by_per_id

                    // thumbs up icon, show
                    return `<span title={{menu.translateLabels(751)}} class="pointer" ng-click="vm.like(data.com_id, data.liked_by_per)"><i class="fa fa-thumbs-up fa-lg  {{ data.liked_by_per ? \'text-secondary\' : \'\'}}"></i></span>
                        <span title={{menu.translateLabels(8674)}} class="source signoff-count" ng-class="{ transparent: !data.likes_count, pointer: !!data.likes_count }" ng-click="vm.viewLikeHistory(data);">{{data.likes_count}}</span>                            
                        <span ng-class="{ transparent: ${!can_edit_comment}, pointer: ${can_edit_comment} }" ng-click="vm.update(data)"><i class="fa fa-pen" note="Edit" ng-show="${can_edit_comment}" title="{{menu.translateLabels(1194)}}"></i></span>`

                },    
                valueGetter: function (params) {
                    return params.data.like_count
                },  
            },
            {
                field: 'com_id',
                hide: true,
                // sort: 'desc', removing sort for now in grid columns and updated the sort in stored procedure. 
            },
            {
                field:"com_comment",
                headerName:" ",          
                minWidth: 200,
                maxWidth: 700,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },   
            {
                field: "com_created_by",
                headerName: " ", // By Who
                minWidth: 50,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },     
            {
                field: "position",
                headerName: " ", // Position
                minWidth: 150,
                maxWidth: 200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },     
            {
                field: "dat_created_date",
                headerName: " ", // Date
                minWidth: 150,
                maxWidth: 200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
                valueGetter: function (params) {
                    return params.data.com_created_date ? params.data.com_created_date.substring(0,10) : ''
                },
            },
            {
                field: "",
                headerName: " ", // Like
                minWidth: 50,
                maxWidth: 50,
                cellRenderer: function (params) {
                    var can_delete_comment = vm.per_id == params.data.com_created_by_per_id

                    // thumbs up icon, show
                    return `<span ng-class="{ transparent: ${!can_delete_comment}, pointer: ${can_delete_comment} }" ng-click="vm.deletecomment(data)"><i class="fa fa-trash" note="Delete" ng-show="${can_delete_comment}" title="{{menu.translateLabels(1194)}}"></i></span>`
                },  
            },
            {
                field:"created_by_per_id",
                hide: true
            },                {
                field:"my_pcl_id",
                hide: true
            }    
            
        ]


        vm.options.columnDefs = positiveIdListCommentsColumns

        vm.like = (com_id, my_pcl_id) => {
            if (my_pcl_id) {
                // user already liked comment, remove like:
                vm.com_id= com_id
                vm.modalElements = {
                    title: translateTag(3828),  //"Remove Like?"
                    message: `<div><p>${translateTag(3827)}</p></div>`, //"Your record of liking this Positive Recognition will be erased. Continue?"
                    buttons: `<button class='btn btn-primary btn-rounded' ng-click="vm.return('button1')" note="Remove">{{vm.componentTranslateLabels(2434)}}</button>`//"Remove"
                }
                document.getElementById('confirmcallingform').innerHTML = 'RETURNPIDLISTCOMMENTDELETE' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements) 
            } else {
                // add like
                pidListCommentService.addCommentLike({"com_id": com_id}).then((response) => {
                    vm.load_data()
                })
            }
            // vm.load_data()
        }

        $scope.$on("RETURNPIDLISTCOMMENTDELETE", (event,result) => {
            if (result=='button1') {
                vm.confirmLikeDelete(vm.com_id)
            }
            modalService.Close("confirmModal")
        })

        vm.confirmLikeDelete = (com_id) => {
            pidListCommentService.deleteCommentLike({"clk_com_id": com_id}).then(() => {
                vm.load_data()
            })
        }
        

        vm.viewLikeHistory = (data) => {

            pidListCommentService.getCommentLikes({"com_id": data.com_id}).then(() => {                
                vm.currentLikeHistory = pidListCommentService.readCommentLikes().list_comment_likes
                vm.currentLikeHistory.map((rec)=>{
                    rec.name = rec.liked_by
                    rec.reviewed_date=rec.created_date
                    rec.pos=rec.position
                    delete rec.liked_by
                    delete rec.created_date
                    delete rec.position
                  })
                document.getElementById('historycallingform').innerHTML= 'PIDLISTCOMMENTSCALLHISTORYMODAL'
                $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentLikeHistory)
                modalService.Close("pidlistcommentsmodal")       
            })
        }

        $scope.$on("PIDLISTCOMMENTSCALLHISTORYMODAL", (event) => {            
            modalService.Open("pidlistcommentsmodal")     
        })

        vm.prepareParameter = (data) =>{
            vm.rowData=data
            document.getElementById('savetomemory').innerHTML = 'false'
            document.getElementById('parentform').innerHTML = 11
            document.getElementById('callingform').innerHTML= 'PIDLISTCOMMENTSCALLCOMMENTMODAL'
            document.getElementById('imageid').innerText = data.pid_id
            document.getElementById('comment_id').innerHTML = data.com_id // comment id              
            document.getElementById('mode').innerText = 1  //edit
        }

        vm.update = (data) =>{
            document.getElementById('mode').innerText = vm.mode
            modalService.Close('pidlistcommentsmodal')
            vm.commentValue = data.com_comment
            vm.modalTitle = translateLabels(8920)  //update comment
            vm.prepareParameter(data)   
            vm.send="update"
            $rootScope.$broadcast("RECIEVEROFCOMMENTS", vm.commentValue, vm.modalTitle)
        }

        vm.deletecomment = (data) => {
            vm.prepareParameter(data)
            $rootScope.$broadcast("DIRECTDELETECOMMENT",data.com_comment)
        }

        $scope.$on("PIDLISTCOMMENTSCALLCOMMENTMODAL", (event, data) => {
            if(!data.com_comment){
                vm.options.api.updateRowData({remove:[vm.rowData]})
            }
            document.getElementById('mode').innerText = ''  //reset mode
            if(vm.send=="update"){
                vm.rowData.com_comment=data.com_comment
                vm.rowData.com_created_date= moment().format('YYYY-MM-DD')
                modalService.Open('pidlistcommentsmodal')
            }
            vm.send==""  //reset
        })

        $scope.$on('CALLPIDLISTCOMMENTMODAL',(event,pid_id, per_id) => {
            vm.per_id = per_id
            vm.pid_id = pid_id
            vm.load_data()
        })

        vm.load_data = () => {   
            pidListCommentService.getComment({"submission_pid": vm.pid_id}).then(() => {
                vm.commentHistory = pidListCommentService.readComments()
                if(vm.commentHistory.list_comments.length) {
                    translateAgGridHeader(vm.options)                
                    vm.options.api.setRowData(preparePIDCommentGridData(vm.commentHistory))
                    vm.options.api.redrawRows()
                    vm.options.api.sizeColumnsToFit()
                    modalService.Open('pidlistcommentsmodal')
                }
            })
        }

        function preparePIDCommentGridData(data) {
            let gridData = JSON.parse(JSON.stringify(data.list_comments))
            gridData.forEach((rec) =>{                            
                rec.com_created_by = rec.created_by
                rec.exceptionFields = ['com_id', 'liked_by_per', 'likes_count', 'created_by','com_created_by_per_id']
                delete rec.created_by
                rec.ID = rec.com_id
                rec.com_created_date = rec.com_created_date ? rec.com_created_date.substring(0,10) : ''                
            })
            return gridData
        }

        vm.translateLabels = (key) => {
            return translateTag(key)
        }

        vm.returnCurrentPIDData=() => {
            let rowData = []
            vm.options.api.forEachNode((node) => rowData.push(node.data))
            let commentCounts=rowData.length
            let comment_by_per=false
            rowData.forEach((node) => {
                if (node.com_created_by_per_id == vm.per_id) {
                    comment_by_per=true
                    return
                }
            }) 
            return {commentCounts,comment_by_per}
        }

        vm.closeModal = (id, note='') => { 
            let behaviour = document.getElementById('pidlistcommentcallingform').innerHTML
            $rootScope.$broadcast(behaviour,vm.returnCurrentPIDData()) 
            modalService.Close(id)
        }
    }
})