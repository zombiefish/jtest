﻿'use strict';
safeToDo.component("stdResponsiveStringDisplayer", {
    template: `
                <div class="" title="{{ vm.string }}">
                    {{ vm.responsiveString }}
                </div>
                `,
    bindings: {
        string: '<'
    },
    controllerAs: 'vm',

    controller: ['$rootScope', '$scope', '$element', '$timeout', 'responsiveService',

        function ($rootScope, $scope, $element, $timeout, responsiveService) {
            var vm = this;
            var elem = $($element);
            vm.responsiveString = vm.string;
            var shortString = '';

            vm.$onInit = function () {
                $timeout(function () {
                    shortString = processString(vm.string);
                    chooseStringToDisplay();
                });
            };

            function processString(s) {
                var words;
                var rs = '';

                if (s != undefined) {
                    words = s.split(' ');
                    words.forEach(function (w, i) {
                        if (i == 0)
                            rs += w;
                        else
                            rs += w.substr(0, 3) + '.';
                        rs += ' ';
                    });
                }

                return rs.trim().toUpperCase();
            };

            function chooseStringToDisplay() {
                if ($rootScope.screenMode === 'lg') {
                    vm.responsiveString = vm.string;
                } else {
                    vm.responsiveString = shortString;
                }
            };

            $rootScope.$watch('screenMode', chooseStringToDisplay);
        }
    ]
});