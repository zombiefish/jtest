﻿safeToDo.component("stdAnalysisDateFilter", {
    templateUrl: 'app/components/analysisfilter/chart-filter.html',
    bindings: {
        index: "<"
    },
    controllerAs: 'vm',

    controller: ['$rootScope', '$scope', '$window', 'modalService', 'listService', '$q', 'profileService','menuService', 
        function ($rootScope, $scope, $window, modalService, listService, $q, profileService, menuService) {
          let vm = this
          vm.$onInit = () =>{
            vm.id = vm.index.split("_")[0]
            vm.typeOfFilter = vm.index.split("_")[1]
            vm.deSelectedYears = []
            vm.selectedYears = []
            vm.lang=selectedLanguage
            
            if (vm.typeOfFilter == "date") {    
              if(vm.id === 'undefined')  { console.log('err msg')}                      

                vm.dropdownDisplay =  vm.id.includes("default90") ? translateTag(3774) : translateTag(1046) //"Since the Beginning of Time"    
                let dateToday = moment(new Date(), 'YYYY-MM-DD')
                
                vm.range = {
                  // start_date: moment().subtract(90, 'days').format('YYYY-MM-DD'),
                  // start_date: "2000-01-01" ,
                  start_date : vm.id.includes("default90") ? dateToday.subtract(90, 'days').format('YYYY-MM-DD') : "2000-01-01",
                  end_date: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD')
                }
                
                vm.endDateId = 'endingDate_' + vm.id
                vm.startDateId = 'startingDate_' + vm.id
                vm.modalId = 'modal_' + vm.id
              
                $scope.$emit('FILTERCHANGE')  
    
                vm.customRange = {
                  start_date: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD'),
                  end_date: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD')
                }
              
             
            }
            else if (vm.typeOfFilter == "position"){
              $q.all([
                listService.getSelectListData('ref_position'),
            ]).then((data) => {
                vm.positionList = data[0].sort(dynamicSort("rld_name"));
                vm.curPositions = vm.positionList.map(a => a.rld_name);
                vm.curPositionsIds = vm.positionList.map(a => a.rld_id)
                vm.dropdownDisplay= String(vm.curPositions.length) +' '+ translateTag(3795) //' Positions Selected'
                $scope.$emit('FILTERCHANGE')
              })
            } 
            else if (vm.typeOfFilter == "site" && !vm.id.includes('single')){
              $q.all([
                listService.getSelectListData('ref_site'),
            ]).then((data) => {              

                vm.siteList = data[0]
                vm.curSites = vm.siteList.map(a => a.rld_name);
                vm.curSitesIds = vm.siteList.map(a => a.rld_id)
                siteids = []
                vm.dropdownDisplay= String(vm.curSites.length) + ' ' + translateTag(3796)  //'Sites Selected'
                $scope.$emit('FILTERCHANGE')
              })
            } else if (vm.typeOfFilter == 'active'){
              vm.dropdownDisplay = translateTag(3557)  //"active"
              vm.actionvalue = 'active'
              $scope.$emit('FILTERCHANGE')  
            }
            else if (vm.typeOfFilter == 'year'){
                vm.minIncidentYear =  $window.sessionStorage.getItem("incidentStartYear") ? Number($window.sessionStorage.getItem("incidentStartYear")) : 2015             
               
                let controlstr = vm.index.split("_")[0]
                let endYear = new Date().getFullYear();                
               
                if(vm.minIncidentYear!= ''){
                  vm.years =[]  
                  for (var i = vm.minIncidentYear; i <= endYear; i++){                      
                    vm.years.push(i)
                  }
                  vm.selectedYears = JSON.parse(JSON.stringify(vm.years))  
                  vm.dropdownDisplay = yearToDisplay(vm.years) 
                }
                // $scope.$emit('FILTERCHANGE')  

                setTimeout(()=> {                
                  let endYearFlag =false  
                  if(controlstr.includes("currentyear")){
                        for (var i = 0; i < vm.selectedYears.length; i++){ 
                          if(vm.selectedYears[i]!=endYear){ 
                            //let controlID = vm.index+vm.selectedYears[i]
                            document.getElementById(vm.index+vm.selectedYears[i]).style.color = 'black';
                            document.getElementById(vm.index+vm.selectedYears[i]).style.backgroundColor = 'white';
                            vm.dropdownDisplay = yearToDisplay([endYear])
                            vm.deSelectedYears.push(vm.selectedYears[i])

                          }
                        }
                        vm.selectedYears = JSON.parse(JSON.stringify([endYear]))
                  }

                  $scope.$emit('FILTERCHANGE')
                }, 1000)   
            }
            else if (vm.typeOfFilter == "site" && vm.id.includes('single')){
              $q.all([
                listService.getSelectListData('ref_site'),
              ]).then((data) => {              

                vm.siteList = data[0]
                siteids = []
                vm.dropdownDisplay=data[0][0].rld_name
                vm.curSites = [vm.siteList[0].rld_name]
                vm.curSitesIds = [vm.siteList[0].rld_id]   
                setTimeout(()=> {  
                  for(var i = 0; i < vm.siteList.length; i++){     
                    if(i==0){
                      document.getElementById(vm.index + data[0][i].rld_name).style.color = '#4285f4'
                      document.getElementById(vm.index + data[0][i].rld_name).style.backgroundColor = '#eee'
                    }
                    else{                
                    document.getElementById(vm.index + data[0][i].rld_name).style.color = 'black'
                    document.getElementById(vm.index + data[0][i].rld_name).style.backgroundColor = 'white'
                    }
                  }

                  $scope.$emit('FILTERCHANGE')  
                }, 1000)  
                
                             
              })
            }
          }

          function yearToDisplay(arrYear){
            let strYear = ''            
            if (arrYear.length >= 1){
              if(arrYear.length == 1){
                strYear = arrYear[0]
              }
              else{
                strYear = String(arrYear.length) + ' ' + translateTag(3823) //' Years Selected'
              }              
            }
            else{
              strYear = translateTag(3966)  //'No Year Selected'
            }
            return strYear
          }

          vm.addSingleSite = (sites, ids) => {
            if(sites.length == 1 && vm.curSites.includes(sites[0])) {
              const index = vm.curSites.indexOf(sites[0])
              if (index > -1) {
                vm.curSites.splice(index, 1);
                vm.curSitesIds.splice(index, 1);
              }
              document.getElementById(vm.index + sites[0]).style.color = 'black';
              document.getElementById(vm.index + sites[0]).style.backgroundColor = 'white';
            } 
            else {

              vm.curSites = []
              vm.curSitesIds = []
              vm.curSites.push.apply(vm.curSites, sites)
              vm.curSitesIds.push.apply(vm.curSitesIds, ids)

              setTimeout(()=> {
                for(var i = 0; i < vm.siteList.length; i++){ 
                  if(vm.siteList[i].rld_name == vm.curSites[0]){
                    element = document.getElementById(vm.index + vm.siteList[i].rld_name)
                    element.style.color = '#4285f4';
                    element.style.backgroundColor = '#eee';
                  }
                  else{
                    element = document.getElementById(vm.index + vm.siteList[i].rld_name)
                    element.style.color = 'black';
                    element.style.backgroundColor = 'white';
                  }
                }
              }, 1000)  
            }
            if (vm.curSites.length > 1) {
              vm.dropdownDisplay = String(vm.curSites.length) + ' '+translateTag(3796) //' Sites Selected'
            }
            else if (vm.curSites.length == 1) {
              vm.dropdownDisplay = vm.curSites[0]
            }
            else if (vm.curSites.length == 0) {
              vm.dropdownDisplay = translateTag(1759) //"Sites"
            }
          }
          

          vm.addSites = (sites, ids) => {            
            if(sites.length == 1 && vm.curSites.includes(sites[0])) {
              const index = vm.curSites.indexOf(sites[0])              
              if (index > -1) {
                vm.curSites.splice(index, 1);
                vm.curSitesIds.splice(index, 1);
              }
              document.getElementById(vm.index + sites[0]).style.color = 'black';
              document.getElementById(vm.index + sites[0]).style.backgroundColor = 'white';
            } else {
              vm.curSites.push.apply(vm.curSites, sites)
              vm.curSitesIds.push.apply(vm.curSitesIds, ids)
              for(let i in sites){
                element = document.getElementById(vm.index + sites[i])
                element.style.color = '#4285f4';
                element.style.backgroundColor = '#eee';
              }
            }
            if (vm.curSites.length > 1) {
              vm.dropdownDisplay = String(vm.curSites.length) + ' '+translateTag(3796) //' Sites Selected'
            }
            else if (vm.curSites.length == 1) {
              vm.dropdownDisplay = vm.curSites[0]
            }
            else if (vm.curSites.length == 0) {
              vm.dropdownDisplay = translateTag(1759) //"Sites"
            }
          }

          function dynamicSort(property) {
            var sortOrder = 1;
            if(property[0] === "-") {
                sortOrder = -1;
                property = property.substr(1);
            }
            return function (a,b) {
                /* next line works with strings and numbers, 
                 * and you may want to customize it to your needs
                 */
                var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
                return result * sortOrder;
            }
          }


          vm.addPositions = (positions, ids) => {
            if(positions.length == 1 && vm.curPositions.includes(positions[0])) {
              const index = vm.curPositions.indexOf(positions[0])
              if (index > -1) {
                vm.curPositions.splice(index, 1);
                vm.curPositionsIds.splice(index, 1);
              }
              document.getElementById(vm.index + positions[0]).style.color = 'black';
              document.getElementById(vm.index + positions[0]).style.backgroundColor = 'white';
            } else {
              vm.curPositions.push.apply(vm.curPositions, positions)
              vm.curPositionsIds.push.apply(vm.curPositionsIds, ids)
              for(let i in positions){
                element = document.getElementById(vm.index + positions[i])               
                element.style.backgroundColor = '#eee';
              }
            }
            if (vm.curPositions.length > 1) {
              vm.dropdownDisplay = String(vm.curPositions.length) + ' ' + translateTag(3795) //' Positions Selected'
            }
            else if (vm.curPositions.length == 1) {
              vm.dropdownDisplay = vm.curPositions[0]
            }
            else if (vm.curPositions.length == 0) {
              vm.dropdownDisplay = translateTag(3967)  //"Positions"
            }
          }

          vm.addYear=(varYear) => {           
            if(varYear.length > 0) {
              let yearSelected = varYear[0]
              const index = vm.deSelectedYears.indexOf(yearSelected)
              if(index === -1){
                  vm.deSelectedYears.push(yearSelected)                   
                  // find the index
                  const s_Index = vm.selectedYears.indexOf(yearSelected)               
                  if(s_Index > -1){
                    vm.selectedYears.splice(s_Index, 1)
                  } 
                  document.getElementById(vm.index+yearSelected).style.color = 'black';
                  document.getElementById(vm.index+yearSelected).style.backgroundColor = 'white';
              }
              else{
                vm.selectedYears.push(yearSelected)
                document.getElementById(vm.index+yearSelected).style.color = '#4285f4';
                document.getElementById(vm.index+yearSelected).style.backgroundColor = '#eee';
                vm.deSelectedYears.splice(index, 1)              
              }

              // sorting 
              vm.selectedYears= vm.selectedYears.sort(function(a, b) {
                return a - b;
              });
              vm.dropdownDisplay = yearToDisplay(vm.selectedYears)
            }
          }

          vm.addSelectSingleYear=(varYear) => {   
                
            if(varYear.length > 0) {
              let yearSelected = varYear[0]
              vm.deSelectedYears = []
              vm.selectedYears = []              

              for(var i = 0; i< vm.years.length; i++){
                if(vm.years[i] == yearSelected){
                  vm.selectedYears.push(vm.years[i])
                  document.getElementById(vm.index+vm.years[i]).style.color = '#4285f4';
                  document.getElementById(vm.index+vm.years[i]).style.backgroundColor = '#eee';
      
                }
                else{
                  vm.deSelectedYears.push(vm.years[i])
                  document.getElementById(vm.index+vm.years[i]).style.color = 'black';
                  document.getElementById(vm.index+vm.years[i]).style.backgroundColor = 'white';
                 
                }
              }
              // sorting 
              vm.selectedYears= vm.selectedYears.sort(function(a, b) {
                return a - b;
              });
              vm.dropdownDisplay = yearToDisplay(vm.selectedYears)
            }
          }


          vm.cancelModal = (modal) => {
            modalService.Close(modal)
          }

          function initializeDatePicker() {
            if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
            $('.datepicker').pickadate({
              format: 'yyyy-mm-dd',
              onClose : function(){
                this.$holder.blur()
            },
            }).removeAttr('readonly')
            .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
              evt.preventDefault()
            })
          }

          vm.changeDateRange = (mode) => {
            dateToday = moment(new Date(), 'YYYY-MM-DD')
            switch(mode) {
              case "Past 30 DAYS": vm.dropdownDisplay = translateTag(3773) //Past 30 DAYS
                vm.range.end_date = dateToday.format('YYYY-MM-DD')
                vm.range.start_date = dateToday.subtract(30, 'days').format('YYYY-MM-DD')
               

                break
              case "Past 90 DAYS": vm.dropdownDisplay = translateTag(3774) //Past 90 DAYS
                vm.range.end_date = dateToday.format('YYYY-MM-DD')
                vm.range.start_date = dateToday.subtract(90, 'days').format('YYYY-MM-DD')

                break
              case "Year to Date": vm.dropdownDisplay = translateTag(1096) //Year to Date
                vm.range.end_date = dateToday.format('YYYY-MM-DD')
                vm.range.start_date = `${dateToday.format('YYYY')}-01-01`                

                break
              case "Since the Beginning of Time": vm.dropdownDisplay = translateTag(1046) //Since the Beginning of Time
                vm.range.end_date = dateToday.format('YYYY-MM-DD')
                vm.range.start_date = "2000-01-01"    
  
                break
              case "Custom":
                initializeDatePicker() 
                modalService.Open(vm.modalId)
                return
              default: vm.dropdownDisplay = mode
                break
            }
            $scope.$emit('FILTERCHANGE')
          }

          vm.changeCustomDateRange = (modal) => {
            vm.range = vm.customRange

            let mStart = moment(vm.range.start_date).lang(`${selectedLanguage}`)
            let mEnd = moment(vm.range.end_date).lang(`${selectedLanguage}`)
            vm.dropdownDisplay = `${mStart.format('MMMM D, YYYY')} - ${mEnd.format('MMMM D, YYYY')}`

            $scope.$emit('FILTERCHANGE')
            modalService.Close(modal)
          }

          vm.changeActive = (active) => {
            vm.dropdownDisplay = active
            if(active=="active"){
              vm.dropdownDisplay=translateTag(3557)  //'active'
            }
            if(active=="inactive"){
              vm.dropdownDisplay=translateTag(3793)  //'inactive'
            }
            if(active=="all"){
              vm.dropdownDisplay=translateTag(1064)  //'all'
            }
            vm.actionvalue=active
            $scope.$emit('FILTERCHANGE')
          }

          vm.changePosition = (position,ids) => {         
            vm.addPositions([position,], [ids])
            $scope.$emit('FILTERCHANGE') 
          }

          vm.changeYear = (year) => { 
            if(vm.id.includes('single')){
              vm.addSelectSingleYear([year,])
            }
            else if(vm.id=== 'get-incident-by-site-month-year-currentyear'){          
              vm.addSelectSingleYear([year,])
            }
            else{        
              vm.addYear([year,])
            }
            $scope.$emit('FILTERCHANGE') 
          }

          vm.changeSite = (site, ids) => {
            if(vm.id.includes('single')){
              vm.addSingleSite([site,], [ids])
            }
            else{
              vm.addSites([site,], [ids])
            }
            $scope.$emit('FILTERCHANGE') 
          }

          vm.componentTranslateLabels = (key) => {
            return translateTag(key)
          }
      }
    ]
});
