safeToDo.component("mysdsFrame", {
    templateUrl: 'app/components/mysdsFrame/mysdsFrame.html',
    bindings: {
        onSave: '&',
        onClose: '&',
        headerData: '<',
    },
    controllerAs: 'vm',
    controller: function ($q, $scope, $rootScope, $controller, $compile, $cookies, $sce, $timeout, $window,) {
        let vm = this

        vm.iframe = null
        vm.frameOpen = false
        vm.frameOpening = false
        vm.frameClosing = false
        vm.indexLoaded = false
        vm.mobileFormId = null
        vm.frameExpanded = true
        vm.canExpandFrame = $window.innerWidth > 960
        vm.incidentId = null
        vm.moduleId = null

        vm.componentTranslateLabels = (key) => {
            return translateTag(key)
        }

        $scope.$on("OPENMYSDSFRAME", (event, message) => {
            $(`#mysdsBlock`).html('')
            $(`#mysdsBlock`).append($compile(`<iframe id="mysdsFrame" src="${__env.mysds_url}?token=${message}" title="" ></iframe>`)($scope))
            vm.frameOpening = true
            vm.frameOpen = true
            $timeout(() => {
                vm.frameOpening = false
            }, 400)
        })

        vm.closeMYSDSFrame = () => {
            vm.frameOpening = false
            $timeout(() => {vm.frameClosing = true},1)

            $timeout(() => {
                vm.frameOpen = false
                vm.frameClosing = false
                vm.mobileFormId = null
            }, 400)
        }

        vm.toggleCollapse = () => {
            vm.frameExpanded = !vm.frameExpanded
            $cookies.put('mobile-frame-expanded', vm.frameExpanded)
        }

        getFrameExpanded = () => {
            if ($cookies.get('mobile-frame-expanded') !== undefined && $cookies.get('mobile-frame-expanded') !== '') {
              vm.frameExpanded = ($cookies.get('mobile-frame-expanded') === 'true')
            } else {
              vm.frameExpanded = false
            }
            
            if (!vm.canExpandFrame)
                vm.frameExpanded = false

            $cookies.put('mobile-frame-expanded', vm.frameExpanded)
        }
        
        getFrameExpanded()

        $(window).on('resize', () => {
            vm.canExpandFrame = $window.innerWidth > 960
            if (!vm.canExpandFrame)
                vm.frameExpanded = false
        })
    }
})