﻿'use strict'
safeToDo.directive('customOnChange', () => {
    return {
      restrict: 'A',
      link: (scope, element, attrs) => {
        var onChangeHandler = scope.$eval(attrs.customOnChange)
        element.on('change', onChangeHandler)
        element.on('$destroy', () => {
          element.off()
        })
      }
    }
  })

safeToDo.component("stdHapForm", {
    templateUrl: 'app/components/hapForm/hap-form.html',
    bindings: {
        modalId: '<',
        hapModel: '<',
        incidentId: '<',
        mode: '<',
        onSave: '&',
        onClose: '&'
    },
    controllerAs: 'vm',
    controller: function ($scope, $element, $timeout, $filter, modalService, select2Service, listService, hapsService, profileService, actionManagementService, $compile, $window, $rootScope, imageCommentService) {
        let vm = this
        let elem = $($element)
        let chart
        vm.checkRequired = true
       
        profileService.getAllEmployeeProfile().then(() => {
            vm.employees = profileService.readAllEmployeeProfile()
        })

        function createHazardAction() {
            vm.submitted = false
            vm.hapModel = {
                ID: null,
                hazard_type: null,
                hazard_identification: null,
                hazard_description: '',
                potential_risk: '',
                immediate_action_required_and_performed: false,
                immediate_action_taken: '',
                further_action_required: false,
                recommended_action: '',
                immediate_action_type: null,
                action_by_who: null,
                action_type: '',
                action_complete_by_who: null,
                action_completed_date: null,
                action_by_when: null, 
                action_status: 'INCOMPLETE',
                completed_action_taken:'',
                completed_action_type:'',
                hazard_identification_score: 0,
                potential_risk_score: 0,
                immediate_action_score: 0,
                completed_action_score: 0,
                attachments: [],
                distribution: []
            }
        }

        vm.editAttachmentIndex= null

        
        vm.hazardTranslateLabels = (key) => {
            return translateTag(key)
        }

  

        vm.initializeSelect2 = ()=> {
            setTimeout(()=>{
            $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#tirHapModal .modal-body`), escapeMarkup: function (text) { return text } })
                .on('select2:select', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list'))
                        $rootScope.$broadcast('distribution-list-added', event)
                    $(this).parent().find('label').addClass('filled')   
                })
                .on('select2:unselect', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list'))
                        $rootScope.$broadcast('distribution-list-removed', event)
                    $(this).parent().find('label').addClass('filled')
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()

                $('.datepicker').pickadate({
                    format: 'yyyy-mm-dd',
                    onClose : function(){
                        this.$holder.blur()
                    },
                }).removeAttr('readonly') 
                .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                    evt.preventDefault()
                })
            }, 1000)
              
        }

        vm.actionTypes = listService.getActionTypes()
        vm.hazardTypes = []
        vm.hazardIdentifications = []
        vm.potentialLoss = []
        vm.localInitialFolder = ''
        vm.attachmentFiles = []
        vm.currentUser
        vm.hapUploadFileList = []    

        createHazardAction()


        listService.getHazardTypesP().then(() => {
            Array.prototype.push.apply(vm.hazardTypes, listService.getHazardTypes().A)
            vm.initializeSelect2()
        })

        listService.getHazardIdentificationsP().then(() => {
            Array.prototype.push.apply(vm.hazardIdentifications, listService.getHazardIdentifications().A)
        })

        listService.getPotentialLossP().then(() => {
            Array.prototype.push.apply(vm.potentialLoss, listService.getPotentialLoss().A)
        })

        profileService.getPersonProfile().then((res)=>{
            vm.currentUser = profileService.readPersonProfile()
        })

        $scope.fileUploadChanged = (event)=> {
            let validFiles = checkFileTypes(event.target.files)
            
            for (let h = 0; h < validFiles.length; h++) {
                vm.hapUploadFileList.push(validFiles[h])
            }

            function read_file(file) {
                return new Promise((resolve, reject) => {
                  var reader = new FileReader();
                  reader.onload = () => {
                    resolve({'url':reader.result,'timestamp':moment.unix(file.lastModified/1000).format('YYYY-MM-DD HH:mm:ss'), 'file':file.name})
                  };
                  reader.readAsDataURL(file)
                })
              }

            let promises = []; // collect all promises
            for (let file2 of vm.hapUploadFileList) {
                promises.push(read_file(file2));
            }
            Promise.all(promises) // wait for the resolutions
                .then(results => {
                    $scope.$apply(() => {
                        for (let result of results) {
                            if (vm.stepsModel.find(attach => attach.file === result.file)){                              
                            }else{
                                vm.stepsModel.push(result)
                            }
                        }
                    })

                    //Clears selected files from input
                    angular.forEach(
                        angular.element("input[type='file']"),
                        function(inputElem) {
                            angular.element(inputElem).val(null)
                        })
                })
        }

        function checkFileTypes(files) {
            let cleanFiles = []
            for (let h = 0; h < files.length; h++) {
                if(files[h].type === 'image/jpeg' || files[h].type === 'image/png') {
                    cleanFiles.push(files[h])
                }
                else{
                    toastr.error(vm.hazardTranslateLabels(3586))  // note="Only Pictures can be attached"
                }
            }
            let dupFiles = checkForDuplicates(cleanFiles)
           return dupFiles
        }    

        function checkForDuplicates(files) {
             let finalFiles = []
             files.forEach((data)=>{
                let found = false
                vm.hapUploadFileList.forEach((hap)=>{
                    if(hap.name === data.name){
                        found = true
                    }
                })
                if(!found){
                    finalFiles.push(data)
                } else {
                    toastr.error(`${data.name} ${translateTag(3587)}`)  //is already loaded  
                }
             })
             return finalFiles
        }

     

        vm.getInitialAttachments = () => {
            hapsService.getStagedAttachments(vm.localInitialFolder)
                .then((response) => {
                    vm.attachmentFiles.length = 0
                    vm.attachmentFiles.push.apply(vm.attachmentFiles, response)
                }, (args) => {
                 })
        }

        $scope.$watch('vm.hapModel', () => {            
            vm.checkAction()     
        })

        vm.deleteInitialAttachment = (index) => {
            vm.deleteInitPara={
                mode:'init',
                index: index
            }
            vm.deleteAttachmentConfirmationModal(index)
            for (let image_index=0;image_index<vm.stepsModel.length;image_index++){

                if(vm.stepsModel[image_index].comment){
                    if(vm.stepsModel[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                } else {
                    let elem = document.getElementById('comment_' + image_index)
                    elem.classList.remove('fas')
                    elem.classList.add('far')
                }
            }    
        }

        vm.cancelModal = (modalId) => { 
            vm.deleteInitPara=null
            modalService.Close(modalId)
        }

        vm.$onChanges = () => {
            vm.hapUploadFileList = []
            vm.stepsModel = []
            
            vm.initializeSelect2()            
        }
        
        vm.closeModal = (id) => {
            vm.submitted = false
            modalService.Close(id)            
            if (vm.onClose) {
                vm.onClose()
            }
            document.forms['hap'].classList.remove('was-validated')
        }

        function prepareHazardEditPayload (payload) {
            let preparedPayload = {}
            preparedPayload.ID =  payload.id
            preparedPayload.submissionheaderid = payload.submissionheaderid
            
            if (!payload.HeaderDate)
                payload.HeaderDate = dateToday.format('YYYY-MM-DDThh:mm')

            preparedPayload.HeaderDate =  moment(payload.HeaderDate).format('YYYY-MM-DDThh:mm')
            preparedPayload.Site = payload.Site
            preparedPayload.JobNumber = payload.JobNumber
            preparedPayload.SiteLevel = payload.SiteLevel
            preparedPayload.Workplace = payload.Workplace
            preparedPayload.Supervisor = payload.Supervisor
            preparedPayload.hazard_type = payload.hazard_type
            preparedPayload.hazard_identification = payload.hazard_identification
            preparedPayload.hazard_description = payload.hazard_description
            preparedPayload.potential_risk = payload.potential_risk
            preparedPayload.immediate_action_required_and_performed = payload.immediate_action_required_and_performed
            if(!preparedPayload.immediate_action_required_and_performed)
            {
                preparedPayload.immediate_action_taken = ''
                preparedPayload.immediate_action_type = ''
            }
            else
            {
                preparedPayload.immediate_action_taken = payload.immediate_action_taken
                preparedPayload.immediate_action_type = payload.immediate_action_type
            }
            preparedPayload.further_action_required = payload.further_action_required
            preparedPayload.recommended_action = payload.recommended_action            
            preparedPayload.action_by_who = payload.action_by_who
            preparedPayload.action_type = payload.action_type
            preparedPayload.action_by_when = payload.action_by_when
            preparedPayload.hazard_identification_score = payload.hazard_identification_score
            preparedPayload.potential_risk_score = payload.potential_risk_score
            preparedPayload.immediate_action_score = payload.immediate_action_score
            return preparedPayload
        }

        vm.convertoToFormData = (hapModel) =>{
            let fd = new FormData()
            fd.append('incidentId', vm.incidentId)
            fd.append('per_id', vm.currentUser.per_id)
            for (let [key, value] of Object.entries(hapModel)) {
                if(key === 'action_by_when') {
                    if(value){
                        let today = moment(value, 'YYYY-MM-DD')
                        fd.append(key, today.format("YYYY-MM-DD")) 
                    }else{
                        fd.append(key, '') 
                    }
                }else {
                    fd.append(key, value)                   
                }
            }

            if(!fd.get('further_action_required')) {
                fd.append('further_action_required', false)
            }
            if(!fd.get('immediate_action_required_and_performed')) {
                fd.append('immediate_action_required_and_performed', false)
            }
            if(!fd.get('immediate_action_type')) {
                fd.append('immediate_action_type', '')
            }
            if(!fd.get('immediate_action_taken')) {
                fd.append('immediate_action_taken', '')
            }
            if(!fd.get('action_status')) {
                fd.append('action_status', 'INCOMPLETE')
            }
            if(!fd.get('action_complete_by_who')) {
                fd.append('action_complete_by_who', '')
            }
            if(!fd.get('action_completed_date')) {
                fd.append('action_completed_date', null)
            }
            if(!fd.get('completed_action_taken')) {
                fd.append('completed_action_taken', '')
            }
            if(!fd.get('completed_action_type')) {
                fd.append('completed_action_type', '')
            }

            if(!fd.get('recommended_action')) {
                fd.append('recommended_action', '')
            }
            if(!fd.get('action_type')) {
                fd.append('action_type', '')
            }
            if(!fd.get('action_by_who')) {
                fd.append('action_by_who', null)
            }
            if(!fd.get('action_by_when')) {
                let today = moment(new Date(), 'YYYY-MM-DD')
                fd.append('action_by_when', today.format("YYYY-MM-DD")) 
            }
         return fd
        }

        vm.convertTime = (timestamp) =>{
            return moment(timestamp).format("YYYY-MM-DD hh:mm:ss a")
        }


        
        //Function to open delete Attachment Confirmation Modal
        let deleteIndex = null
        vm.deleteAttachmentConfirmationModal = (index) => {
            deleteIndex = index
            vm.modalElements = {
                title: translateTag(3416), //"Delete Attachment?"
                message:               
                `<div>          
                    <p ng-if=${vm.deleteInitPara && vm.deleteInitPara.mode=='init'} note="You are about to delete this attachment.Are you sure?">${translateTag(1452)}</p>
                    <p ng-if=${!vm.deleteInitPara} note="You are about to delete this attachment. Undoing this will require IT support. Are you sure?">${translateTag(3635)}</p>
                </div>`, 
                buttons: 
                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            } 
            document.getElementById('confirmcallingform').innerHTML = 'HAPFORMCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("HAPFORMCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.deleteExistingInitialAttachment(vm.deleteInitPara)
            }
            else if (result=='button2') {
                vm.cancelModal('confirmModal')
            }
        })

        //Function to delete existing attachments
        vm.deleteExistingInitialAttachment = (deleteInitPara) => {
            if(deleteInitPara && deleteInitPara.mode=="init"){
                vm.hapUploadFileList.splice(deleteInitPara.index, 1)
                vm.stepsModel.splice(deleteInitPara.index, 1)
            }
            else{
                let id = vm.hapModel.attachments[deleteIndex].id
                actionManagementService.removeHazardActionAttachment({haa_id: id}).then((res) =>{
                    vm.hapModel.attachments.splice(deleteIndex, 1)
                    deleteIndex = null
                })
            }            
            modalService.Close('confirmModal')
            vm.deleteInitPara=null
        }

        vm.createHap = () => {
            var validationMessage = hapsService.validateHap(vm.hapModel)
            let validateCondition = vm.validateForm()
            if(validateCondition){
                vm.submitted = true   
                if(vm.mode == "edit"){                   
                    let payload = prepareHazardEditPayload(vm.hapModel)
                    actionManagementService.updateHazardAction(payload).then ((res) => {
                        for (var i in vm.hapUploadFileList) {
                            let fd = new FormData()
                            fd.append("submission_hap_id", vm.hapModel.id)
                            fd.append("submission_hap_file", vm.hapUploadFileList[i])
                            fd.append("submission_hap_type", 'INITIAL')
                            fd.append("haa_image_timestamp", moment.unix(vm.hapUploadFileList[i].lastModified/1000).format('YYYY-MM-DD HH:mm:ss'))

                            if(vm.hapUploadFileList.length > 0) {
                                actionManagementService.addHazardActionAttachments(fd).then((res) => {
                                     let sfiles = res.data.message["Successfull Files"]
                                     let attached_count = 0
     
                                     sfiles.allowed_original.forEach((attached) =>  {
                                        vm.stepsModel.forEach((newA) =>{

                                            if(newA.comment){
                                                
                                                if(attached==newA.file){
                                                    //call the add comment service.
                                                    newA.comment.com_reference_id = sfiles.ids[attached_count]

                                                    //call service to insert comment.
                                                    imageCommentService.saveComment(newA.comment)
     
                                                }
                                             }
                                         })
                                         attached_count++
                                     })

                                })
                            }
                            else {
                            }
                        }
                        $scope.$emit('GENERAL_REFRESHDATA')
                        $scope.$emit('HAP_REFRESHDATA')
                        $scope.$emit('ADDACTION', vm.hapModel)
                        vm.closeModal('tirHapModal')
                    })    
                }
                else{
                    let hapFormData = vm.convertoToFormData(vm.hapModel) 
                    if (validationMessage) {
                        toastr.error(vm.hazardTranslateLabels(1403) + '-' + validationMessage)
                        vm.submitted = false
                        return
                    }
                    hapsService.createHap(hapFormData)
                    .then((response) => {
                        let submission_hap_ID = response.data.submission_hap_ID
                        for (var i in vm.hapUploadFileList) {
                            let fd = new FormData()
                            fd.append("submission_hap_id", submission_hap_ID)
                            fd.append("submission_hap_file", vm.hapUploadFileList[i])
                            fd.append("submission_hap_type", 'INITIAL')
                            fd.append("haa_image_timestamp", moment.unix(vm.hapUploadFileList[i].lastModified/1000).format('YYYY-MM-DD HH:mm:ss'))

                            if(vm.hapUploadFileList.length > 0) {
                                actionManagementService.addHazardActionAttachments(fd).then((res) => {
                                    let sfiles = res.data.message["Successfull Files"]
                                    let attached_count = 0
    
                                    // for(attached of sfiles.allowed_original){
                                    sfiles.allowed_original.forEach((attached) =>  {
                                        vm.stepsModel.forEach((newA) =>{
                                            if(newA.comment){
                                               
                                                if(attached==newA.file){
                                                    //call the add comment service.
                                                    newA.comment.com_reference_id = sfiles.ids[attached_count]

                                                    //call service to insert comment.
                                                    imageCommentService.saveComment(newA.comment)
    
                                                }
                                            }
                                        })
                                        attached_count++
                                    })

                                })
                            }
                            else {
                            }
                        }
                        $scope.$emit('GENERAL_REFRESHDATA')
                        $scope.$emit('HAP_REFRESHDATA')
                        $scope.$emit('ADDACTION', vm.hapModel)
                        vm.closeModal('tirHapModal')
                        $scope.$emit('CREATE_HAP', response)
                        if (vm.onSave) {
                            vm.onSave()
                        }
                        vm.closeModal(vm.modalId)
                        toastr.success(vm.hazardTranslateLabels(4238)) // note="Action Creation Complete!"
                    }, 
                    (failureArgs) => {
                        toastr.error(vm.hazardTranslateLabels(4239), failureArgs) // Failed to create action.
                    })
                }
            } 
            else {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        $scope.$on('HAZARD_EDIT_OPENED', () => {
            vm.hapModel.hazard_type = addHistoricalOption('hazard_type1', vm.hazardTypes, vm.hapModel.hazard_type, vm.hapModel.hazard_type_ltr_text)
            vm.hapModel.hazard_identification = addHistoricalOption('hazard_identification1', vm.hazardIdentifications, vm.hapModel.hazard_identification, vm.hapModel.hazard_identification_ltr_text)
            vm.hapModel.potential_risk = addHistoricalOption('potential_risk', vm.potentialLoss, vm.hapModel.potential_risk, vm.hapModel.potential_risk_ltr_text)
            if(vm.hapModel.immediate_action_required_and_performed)
                vm.hapModel.immediate_action_type = addHistoricalOption('immediate_action_type1', vm.actionTypes, vm.hapModel.immediate_action_type, vm.hapModel.immediate_action_type_ltr_text)
            if(vm.hapModel.further_action_required)
                vm.hapModel.action_type = addHistoricalOption('action_type1', vm.actionTypes, vm.hapModel.action_type, vm.hapModel.action_type_ltr_text)


            if(vm.hapModel.immediate_action_required_and_performed || vm.hapModel.further_action_required){
                vm.checkRequired = false
            }
            else{
                vm.checkRequired = true
            }

            if(vm.hapModel.attachments){
                let image_index = 0
                vm.hapModel.attachments.forEach((attachment) => {
                    if(attachment.com_comment !='' && attachment.com_comment != null){
                        let elem = document.getElementById('disk_comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('disk_comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                    image_index++
                })
            }
            $scope.$apply()
        })



        function addHistoricalOption (select, list, rld_id, ltr_text) {
            if(rld_id && !list.some(t => t.rld_id === rld_id))
            {
                let historicRecord = {
                        rld_historical: true,
                        rld_id: rld_id,
                        rld_name: `${ltr_text} (${translateTag(8717)})` //Historical
                }
                list.push(historicRecord)
                $(`#${select}`).trigger('change')
            }
            return rld_id
        }
      
        vm.checkAction = () =>{
            if(vm.hapModel.immediate_action_required_and_performed || vm.hapModel.further_action_required){          
                vm.checkRequired = false 
            }
            else{
                vm.checkRequired = true 
            }

            if(!vm.hapModel.immediate_action_required_and_performed){
                vm.hapModel.immediate_action_taken = ''
                vm.hapModel.immediate_action_type = null
            }

            if(!vm.hapModel.further_action_required){
                vm.hapModel.recommended_action = ''
                vm.hapModel.action_type = null
                vm.hapModel.action_by_who = null
                vm.hapModel.action_by_when= null
            }

            vm.initializeSelect2()
        } 

        vm.resetActionData = () =>{             
            if(vm.hapModel.immediate_action_required_and_performed || vm.hapModel.further_action_required){          
                vm.checkRequired = false 
            }
            else{
                vm.checkRequired = true 
            }

            if(!vm.hapModel.immediate_action_required_and_performed){
                vm.hapModel.immediate_action_taken = ''
                vm.hapModel.immediate_action_type = null
            }

            if(!vm.hapModel.further_action_required){
                vm.hapModel.recommended_action = ''
                vm.hapModel.action_type = null
                vm.hapModel.action_by_who = null
                vm.hapModel.action_by_when= null
            }

            vm.initializeSelect2()
        } 


        vm.validateForm = () => {
            let validated = false
            let validatedForm = true                  
            if(vm.hapModel.immediate_action_required_and_performed || vm.hapModel.further_action_required){    
                validated = true
                vm.checkRequired = false
            }
            else{
                validated = false 
                vm.checkRequired = true
            }     
            resetFormFieldClassList('hap')      
            validatedForm = validateFormFields('hap')
            if(validated && validatedForm)
                return true
            else
                return false

        }

        vm.AddComments = (index, from) => {
            document.getElementById('mode').innerText = ''
            document.getElementById('relatedimageindex').innerText = index
            document.getElementById('callingform').innerText = 'CLOSEHAPIMAGECOMMENTSMODAL'
            document.getElementById('parentform').innerHTML = 5 // SubmissionHap Module	SubmissionHAPAttachments
            document.getElementById('savetomemory').innerHTML = "true"  
            vm.ImageFrom = from

            if(vm.mode ==='edit'){
                if(vm.ImageFrom=='disk'){
                    // updating the comments only from the disk
                    vm.editAttachmentIndex = index
                    if(vm.hapModel.attachments[index].com_comment || vm.hapModel.attachments[index].com_id){                    
                        document.getElementById('mode').innerText = vm.mode
                        document.getElementById('savetomemory').innerHTML = "false"                      
                        document.getElementById('comment_id').innerHTML = vm.hapModel.attachments[index].com_id
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS", vm.hapModel.attachments[index].com_comment)                        
                    } 
                    else{
                        document.getElementById('mode').innerText = vm.mode
                        document.getElementById('savetomemory').innerHTML = "false"
                        document.getElementById('condition').innerHTML = 'AddCommentOnEmptyExistingImage'
                        document.getElementById('comment_id').innerHTML = vm.hapModel.attachments[index].com_id
                        document.getElementById('imageid').innerHTML = vm.hapModel.attachments[index].id  
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS", vm.hapModel.attachments[index].com_comment)     

                    }
                }
                else if(vm.ImageFrom=='memory'){
                    if(vm.stepsModel[index].comment){
                        document.getElementById('comment').value = vm.stepsModel[index].comment.com_comment
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.stepsModel[index].comment.com_comment)
                    }
                    else{
                        document.getElementById('imageid').innerHTML = ''
                        document.getElementById('comment').value = ''
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                    }
                }
                else{
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                }
            }
            else{
                if(vm.stepsModel[index].comment){
                    document.getElementById('comment').value = vm.stepsModel[index].comment.com_comment
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.stepsModel[index].comment.com_comment)
                }
                else{
                    document.getElementById('imageid').innerHTML = ''
                    document.getElementById('comment').value = ''
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                }
            }
        }

        $scope.$on('CLOSEHAPIMAGECOMMENTSMODAL',(event,data) => {
            let image_index = document.getElementById('relatedimageindex').innerText
            if(vm.mode==='edit'){
                if(vm.ImageFrom=='disk'){

                    vm.hapModel.attachments[vm.editAttachmentIndex].com_comment= data.com_comment     
                    
                    if(vm.hapModel.attachments[vm.editAttachmentIndex].com_comment !='' && vm.hapModel.attachments[vm.editAttachmentIndex].com_comment != null){
                        let elem = document.getElementById('disk_comment_' + image_index)

                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('disk_comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                    
                }
                else if(vm.ImageFrom =='memory'){
                   
                    vm.stepsModel[image_index].comment = data
                    vm.stepsModel[image_index].comment.com_reference_id = image_index
                    if(vm.stepsModel[image_index].comment){
                        if(vm.stepsModel[image_index].comment.com_comment !=''){
                            let elem = document.getElementById('comment_' + image_index)
                            elem.classList.remove('far')
                            elem.classList.add('fas')
                        } else {
                            let elem = document.getElementById('comment_' + image_index)
                            elem.classList.remove('fas')
                            elem.classList.add('far') 
                        }
                    }
                }
            }
            else
            {
                vm.stepsModel[image_index].comment = data
                vm.stepsModel[image_index].comment.com_reference_id = image_index
                if(vm.stepsModel[image_index].comment){
                    if(vm.stepsModel[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                }
            }

        })

    }
})