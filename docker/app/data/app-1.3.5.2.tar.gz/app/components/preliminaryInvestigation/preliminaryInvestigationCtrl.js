safeToDo.component("form220234", {
    templateUrl: 'app/components/preliminaryInvestigation/preliminaryInvestigation.html',
    bindings: {
        modalId: '<',
        shId: '<',
        allData: '<',
        mode: '<',
        investigationId: '<',
        onSave: '&',
        onClose: '&'
    },
    controllerAs: 'vm',
    controller: function ($scope, $rootScope, $q, listService, modalService, profileService, $compile, employeesService, settingsService, imageCommentService, fileUploadService, formsService) {
        let vm = this
        let dateToday = moment(new Date(), 'YYYY-MM-DD')

        vm.siteList = []
        vm.jobList = []
        vm.jobListSelect = []
        vm.levelList = []
        vm.levelListSelect = []
        vm.employeeList = []
        vm.supervisorList = []
        vm.incidentTypeList = []
        vm.distributionList = []
        vm.positionList = []
        vm.climateList = []
        vm.eventShiftList = []
        vm.eventShiftScheduleList = []
        vm.newAttachments = []
        vm.uploadFileList = []
        vm.currentAttachments = []
        vm.editForm = false

        vm.formFieldVisibilityList = []

        vm.translateLabels = (key) =>{
            return translateTag(key)
        }

        $scope.$on("EDITFORMBYSHID-form-220234", (event,sh_id) => {
            vm.editForm = true
            getPreparedPreInvestigationDataBySHID(sh_id)
        })

        function loadComments() {
            if(vm.currentAttachments){
                let image_index = 0
                vm.currentAttachments.forEach(attachment => {
                    let elem = document.getElementById('disk_comment_' + image_index)
                    if(attachment.com_comment !='' && attachment.com_comment != null){
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                    image_index++
                })
            }
        }

        function getPreparedPreInvestigationDataBySHID (sh_id) {
            formsService.getFormDataBySHID(sh_id).then((response)=>{
                vm.currentPI = response.submission_data
                if(!vm.currentPI){
                    submission_language = response.submission_language
                    vm.modalElements = {
                        title: translateTag(2182),   //warning
                        message: `<div><p>${translateLabels(9137)} ${submission_language}. ${translateLabels(9138)} ${submission_language} ${translateLabels(9139)}</p></div>`, //This form has been submitted in ${submission_language}. Please switch your application language to ${submission_language} if you wish to edit this record. 
                        buttons: `<button class='btn btn-primary btn-rounded' ng-click="vm.closeModal()" note="OK">{{vm.componentTranslateLabels(1405)}}</button>` 
                    }
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
                    return
                }
                vm.currentPI.level = parseInt(vm.currentPI.level)
                vm.currentPI.site = parseInt(vm.currentPI.site)
                vm.currentPI.job_number = parseInt(vm.currentPI.job_number)
                vm.currentPI.supervisor = parseInt(vm.currentPI.supervisor)
                vm.currentPI.headerdate = moment(vm.currentPI.headerdate).format("YYYY-MM-DD")
                vm.currentPI.reason_for_change = null
                vm.currentPI.form_name = '1002', // Preliminary Investigation
                vm.currentAttachments = vm.currentPI.workplace_conditions_photos
                if(vm.currentAttachments){
                    vm.currentAttachments.forEach(attachment => {
                        attachment.imageDir = `${__env.imageUrl}/`
                    })
                }
                vm.getJobsLevels("edit")
                setTimeout(()=>{
                    modalService.Open("form-220234")
                    loadComments()
                    $scope.$emit("FORMSINITIALIZESELECT2", "form-220234")
                },100)
            })   
        }

        //Function to reset form
        function resetForm () {
            if(document.forms['preliminaryInvestigationForm'])
                resetFormFieldClassList('preliminaryInvestigationForm')
            
            vm.newAttachments = []
            vm.uploadFileList = []
            vm.currentAttachments = []
            vm.submitted = false
            vm.editForm = false

            vm.task_planned_or_changed_options = [
                {tag: 2857,value: vm.translateLabels(2857)},
                {tag: 3756,value: vm.translateLabels(3756)},
                {tag: 688,value: vm.translateLabels(688)}
            ]

            vm.currentPI = {
                form_name: '1002', // Preliminary Investigation
                headerdate: dateToday.format("YYYY-MM-DD"),
                site: null,
                job_number: null,
                level: null,
                workplace: '',
                supervisor: null,
                investigator_1: null,
                investigator_2:null,
                investigator_3: null,
                investigator_4: null,
                investigator_5: null,
                investigation_time: '',
                event_type: null,
                event_location: null,
                event_date: '',
                event_time:'',
                event_shift: null,
                event_shift_schedule: null,
                event_shift_supervisor: null,
                scene_secured: '',
                event_detail_summary: null,
                who_involved: null,
                who_involved_position: null,
                others_involved: null,
                was_5pt_card_gathered: '',
                why_no: null,
                was_5pt_card_completed: '',
                why_no_1: null,
                was_statement_gathered:'',
                why_no_2: null,
                was_task_routine: '',
                why_no_3: null,
                describe_task_preformed: null,
                task_planned_or_changed: null,
                what_qualifications_required: null,
                who_witnessed: null,
                who_witnessed_position: null,
                Others_witnessed: null,
                why_no_4: null,
                equipment_tooling_involved: null,
                equipment_make_mode_unit_number: null,
                tooling_make_model_unit_number: null,
                safety_device_condition: null,
                ppe_involved_condition: null,
                worksite_details_layout: null,  
                detail_climate: null,
                detail_temperature: null,
                describe_overhead_conditions: null,
                describe_underfoot_conditions: null,
                describe_lighting_conditions: null,
                describe_environmental_noise: null,
                describe_environmental_ergonomics: null,
                describe_access_workplace: null,
                describe_workplace_housekeeping: null,
                other_comments_notes: null,
                Report_Distribution1: []
            }
        }

        //Function to get jobs & levels at a site
        vm.getJobsLevels = (mode='new') => {
            let mainSite = ''
            if(mode==='new'){
                vm.currentPI.job_number = null
                vm.currentPI.level = null
            }
            vm.jobListSelect = []
            vm.levelListSelect = []
            vm.getFilteredEmployees()
            vm.siteList.forEach((rec) => {
                if(rec.rld_id == vm.currentPI.site)
                {
                    mainSite = rec.rld_id
                }
            })
            vm.jobList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id == mainSite)
                    vm.jobListSelect.push(rec)
            })
            vm.levelList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id == mainSite)
                    vm.levelListSelect.push(rec)
            })
            
        }

        //Function to delete an attachment
        vm.deleteAttachment = (index) => {
            vm.deleteInitPara={
                mode:'init',
                index: index
            }
            vm.deleteAttachmentConfirmationModal(index)        
            for (let image_index=0;image_index<vm.newAttachments.length;image_index++){
                if(vm.newAttachments[image_index].comment){
                    if(vm.newAttachments[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                } else {
                    let elem = document.getElementById('comment_' + image_index)
                    elem.classList.remove('fas')
                    elem.classList.add('far')
                }
            }    
            
        }
        
        vm.deleteIndex = null
        //Function to open delete Attachment Confirmation Modal
        vm.deleteAttachmentConfirmationModal = (index) => {
            vm.deleteIndex = index    
            vm.modalElements = {
                title: translateTag(3416), //"Delete Attachment?"
                message: 
                    `<div>          
                        <p ng-if=${vm.deleteInitPara && vm.deleteInitPara.mode=='init'} note="You are about to delete this attachment.Are you sure?">${translateTag(1452)}</p>
                        <p ng-if=${!vm.deleteInitPara} note="You are about to delete this attachment. Undoing this will require IT support. Are you sure?">${translateTag(3635)}</p>
                    </div>`, 
                buttons: 
                    `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                    <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            }        
            document.getElementById('confirmcallingform').innerHTML = 'PRELIMINARYINVESTIGATIONCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("PRELIMINARYINVESTIGATIONCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.deleteInitAttachmentAfterConfirmation(vm.deleteInitPara)
            }
        })

        //Function to delete initial attachments after click "ok" in Confirmation modal
        vm.deleteInitAttachmentAfterConfirmation = (deleteInitPara) => {
            if(deleteInitPara && deleteInitPara.mode=="init"){
                vm.uploadFileList.splice(deleteInitPara, 1)
                vm.newAttachments.splice(deleteInitPara, 1)
            }
            else{
                formsService.removeFormSubmissionAttachments({
                    "id": vm.currentAttachments[vm.deleteIndex].id,
                    "com_id": vm.currentAttachments[vm.deleteIndex].com_id
                }).then((res)=>{
                    vm.currentAttachments.splice(vm.deleteIndex, 1)
                    vm.deleteIndex = null
                })
            }
            modalService.Close('confirmModal')
        }

        $scope.fileUploadChanged = (event)=> {

            let existingFileNames = []
            for(let i in vm.uploadFileList) {
                existingFileNames.push(vm.uploadFileList[i].name)
            }

            //Add newly selected files after checking for duplicates and correct file types
            vm.uploadFileList = vm.uploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, existingFileNames, true))
            
            //Get data from files to display in html
            fileUploadService.getFileUploadData(vm.uploadFileList).then ((filesData) => {
                vm.newAttachments = filesData
                $scope.$apply() // Update html bindings
            })
        }

        vm.convertTime = (timestamp) =>{
            return moment(timestamp).format("YYYY-MM-DD hh:mm:ss a")
        }

        vm.getFilteredEmployees = () =>{
            profileService.filterEmployeeListonJob(vm.currentPI.job_number)
            vm.employeeList =  profileService.readFilterEmployeeListonJob()
            profileService.filterSupervisorListonJob(vm.currentPI.job_number)
            vm.supervisorList = profileService.readFilterSupervisorListonJob()            
            profileService.filterDistributionListonJob(vm.currentPI.job_number)
            vm.distributionList = profileService.readFilterDistributionListonJob()
        }
        
        vm.saveNewCommentsAndAttachments = (submission_detail_id) => {
            let ufl = [...vm.uploadFileList]
            let att = [...vm.newAttachments]
            for (let i in ufl) {
                let fd = new FormData()
                fd.append("submission_detail_id", submission_detail_id)
                fd.append("form_field_description_id", 16928)
                fd.append("filename", ufl[i])
                fd.append("sde_image_timestamp", moment.unix(ufl[i].lastModified/1000).format('YYYY-MM-DD HH:mm:ss'))
            
                if(ufl.length > 0 ) {
                    formsService.addFormSubmissionAttachments(fd).then((res) => {
                        let sfiles = res.message["Successfull Files"]
                        let attached_count = 0
    
                        for(attached of sfiles.allowed_original){
                            for(newA of att){
                                if(newA.comment){
                                    if(attached==newA.file){
                                        newA.comment.com_reference_id = sfiles.ids[attached_count]
                                        //call service to insert comment.
                                        imageCommentService.saveComment(newA.comment)
                                    }
                                }
                            }
                            attached_count++
                        }
                    })
                }
            }
        }
    
        vm.createOrUpdatePI = () => {
            let payload = preparePayload(JSON.parse(JSON.stringify(vm.currentPI)))
            resetFormFieldClassList('preliminaryInvestigationForm')
            if(validateFormFields('preliminaryInvestigationForm')) {
                vm.submitted = true
                if(!vm.editForm){
                    formsService.createFormSubmission(payload).then ((response) =>{
                        vm.saveNewCommentsAndAttachments(response.submission_detail_id)
                        vm.closeModal('form-220234')
                        $scope.$emit('REFRESH_FORMSUBMISSIONS') 
                    })
                }else{
                    formsService.updateFormSubmission(payload).then ((response) =>{
                        vm.saveNewCommentsAndAttachments(response.submission_detail_id)
                        vm.closeModal('form-220234')
                        vm.editForm = false
                        $scope.$emit('REFRESH_FORMSUBMISSIONS') 
                    })
                }   
            } else {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        //Function to prepare payload data
        function preparePayload(payload) {
            let preparedPayload = payload
            if(vm.editForm){
                preparedPayload.reason_for_change = preparedPayload.reason_for_change ? preparedPayload.reason_for_change : null
            }
            preparedPayload.headerdate = moment(payload.headerdate, 'YYYY-MM-DDThh:mm:ss').format('YYYY-MM-DDThh:mm:ss')
            if(preparedPayload.was_5pt_card_gathered == '1' || preparedPayload.was_5pt_card_gathered == '-1')
                preparedPayload.why_no = ''

            if(preparedPayload.was_5pt_card_completed == '1' || preparedPayload.was_5pt_card_completed == '-1')
                preparedPayload.why_no_1 = ''

            if(preparedPayload.was_statement_gathered == '1' || preparedPayload.was_statement_gathered == '-1')
                preparedPayload.why_no_2 = ''
                
            if(preparedPayload.was_task_routine == '1' || preparedPayload.was_task_routine == '-1')
                preparedPayload.why_no_3 = ''

            if(preparedPayload.was_statement_gathered_from_witness == '1' || preparedPayload.was_statement_gathered_from_witness == '-1')
                preparedPayload.why_no_4 = ''
            
            preparedPayload = formsService.removePayloadHiddenFormFields(preparedPayload, vm.formFieldVisibilityList)

            return preparedPayload
        }

        //Function to close the modal
        vm.closeModal = (modalId) => {            
            modalService.Close(modalId)
            vm.employeeList = []
            vm.distributionList = []
            vm.supervisorList = []
            resetForm()
            refreshData()
        }
       
        vm.AddComments=(index, from) =>{
            document.getElementById('mode').innerText = ''
            document.getElementById('relatedimageindex').innerText = index
            document.getElementById('callingform').innerText = 'CLOSEPRELIMINARYINVESTIGATIONIMAGECOMMENTSMODAL'  
            document.getElementById('parentform').innerHTML = 1
            document.getElementById('savetomemory').innerHTML = "true"

            vm.ImageFrom = from

            if (vm.editForm) {
                if(vm.ImageFrom=='disk'){
                    // updating the comments only from the disk                    
                    vm.editAttachmentIndex = index
                    if(vm.currentAttachments[index].com_comment || vm.currentAttachments[index].com_id){                    
                        document.getElementById('mode').innerText = 'edit'
                        document.getElementById('savetomemory').innerHTML = "false"                                         
                        document.getElementById('comment_id').innerHTML = vm.currentAttachments[index].com_id
                        document.getElementById('imageid').innerHTML = vm.currentPI.workplace_conditions_photos[index].id  
                        document.getElementById('condition').innerHTML = ''
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS", vm.currentAttachments[index].com_comment)                        
                    } 
                    else{
                        document.getElementById('mode').innerText = 'edit'
                        document.getElementById('savetomemory').innerHTML = "false"   
                        document.getElementById('comment_id').innerHTML = vm.currentAttachments[index].com_id                       
                        document.getElementById('condition').innerHTML = 'AddCommentOnEmptyExistingImage'
                        document.getElementById('imageid').innerHTML = vm.currentPI.workplace_conditions_photos[index].id  
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS", vm.currentAttachments[index].com_comment)     

                    }
                }
                else if(vm.ImageFrom=='memory'){
                    if(vm.newAttachments[index].comment){
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.newAttachments[index].comment.com_comment)
                        document.getElementById('comment').value = vm.newAttachments[index].comment.com_comment
                    }
                    else{
                        document.getElementById('imageid').innerHTML = ''
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                        document.getElementById('comment').value = ''
                    }
                }
                else{
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                }
            }
            else{
                if(vm.newAttachments[index].comment){
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.newAttachments[index].comment.com_comment)
                    document.getElementById('comment').value = vm.newAttachments[index].comment.com_comment
                }else{
                    document.getElementById('imageid').innerHTML = ''
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                    document.getElementById('comment').value = ''
                }
            }
        }

        $scope.$on('CLOSEPRELIMINARYINVESTIGATIONIMAGECOMMENTSMODAL',(event,data) => {
            let image_index = document.getElementById('relatedimageindex').innerText
            if(vm.editForm){
                if(vm.ImageFrom=='disk'){
                    vm.currentAttachments[vm.editAttachmentIndex].com_comment= data.com_comment 
                    vm.currentAttachments[vm.editAttachmentIndex].com_id=data.com_id    
                    let elem = document.getElementById('disk_comment_' + image_index)
                    if(vm.currentAttachments[vm.editAttachmentIndex].com_comment !='' && vm.currentAttachments[vm.editAttachmentIndex].com_comment != null){
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                }
                else if(vm.ImageFrom =='memory'){
                    vm.newAttachments[image_index].comment = data
                    vm.newAttachments[image_index].comment.com_reference_id = image_index

                    if(vm.newAttachments[image_index].comment){
                        if(vm.newAttachments[image_index].comment.com_comment !=''){
                            let elem = document.getElementById('comment_' + image_index)
                            elem.classList.remove('far')
                            elem.classList.add('fas')
                        } else {
                            let elem = document.getElementById('comment_' + image_index)
                            elem.classList.remove('fas')
                            elem.classList.add('far') 
                        }
                    }
                }
            }
            else
            {
                vm.newAttachments[image_index].comment = data
                vm.newAttachments[image_index].comment.com_reference_id = image_index
                document.getElementById('imageid').innerText = ''

                if(vm.newAttachments[image_index].comment.com_comment !=''){
                    let elem = document.getElementById('comment_' + image_index)
                    elem.classList.remove('far')
                    elem.classList.add('fas')
                } else {
                    let elem = document.getElementById('comment_' + image_index)
                    elem.classList.remove('fas')
                    elem.classList.add('far') 
                }
            }
        })

        $scope.$on('distribution-list-added', (event, args) => {
            if(vm.currentPI !== undefined)
                $scope.$emit('addDistributionGroup', args, vm.currentPI.Report_Distribution1)
        })

        $scope.$on('distribution-list-removed', (event, args) => {
            $scope.$emit('removeDistributionGroup',args)
         })

        //Function to refresh all data
        function refreshData() {
            $q.all([
                listService.getSiteListByDataVisibility(),
                listService.getJobListByDataVisibility(),
                listService.getSelectListData('ref_level'),
                listService.getSelectListData('ref_incident_type'),
                listService.getSelectListData('ref_position'),
                listService.getSelectListData('ref_climate'),
                listService.getSelectListData('ref_shift'),
                listService.getSelectListData('ref_event_shift_schedule'),
                profileService.getAllEmployeeProfile(),
                profileService.getAllSupervisorProfile(),
                profileService.getDistributionList(),
                employeesService.getPersonProfile(),
                formsService.getFormFieldFilter({"form_id":220234})
            ]).then((data) => {
                resetForm()
                vm.siteList = listService.readSitesByDataVisibility()
                vm.jobList = listService.readJobsByDataVisibility()
                vm.jobList.forEach((job)=>{
                    job.fullJob = `(${job.rld_code}) - ${job.rld_name}`
                })
                vm.levelList = data[2]
                vm.incidentTypeList = data[3]
                vm.positionList = data[4]
                vm.climateList = data[5]
                vm.eventShiftList = data[6]
                vm.eventShiftScheduleList = data[7]
                vm.current_user_id = data[11].per_id
                vm.formFieldVisibilityList = data[12]
            }).then((data)=>{
                settingsService.getUserProfile(vm.current_user_id).then((response) => {
                    vm.siteList.forEach((rec)=>{
                        if(response.upr_site===rec.rld_id){
                            vm.currentPI.site = response.upr_site
                            vm.getJobsLevels()
                        }
                    })
                    vm.jobList.forEach((rec)=>{
                        if(response.upr_job==rec.rld_id){
                            vm.currentPI.job_number = response.upr_job
                            vm.getFilteredEmployees()
                        }
                    })
                    vm.levelList.forEach((rec) => {
                        if(response.upr_level === rec.rld_id){
                            vm.currentPI.level = response.upr_level
                        }
                    })
                    vm.supervisorList.forEach((rec)=>{
                        if(response.upr_supervisor_per === rec.per_id){
                            vm.currentPI.supervisor = rec.per_id
                        }
                    })
                    if(response.distribution_list){
                        let email_list = []
                        response.distribution_list.forEach((d)=>{
                            email_list.push(d.email)
                        })                   
                        vm.currentPI.Report_Distribution1 = email_list
                    }                    
                })
                
                try{
                    formsService.removeHiddenFormFields('preliminaryInvestigationForm', vm.formFieldVisibilityList)
                }
                catch(e){}

            })
        }
        refreshData()

    //END

    }
    
})