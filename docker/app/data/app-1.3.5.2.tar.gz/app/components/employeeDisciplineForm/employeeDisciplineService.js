angular
    .module('safeToDo')
    .service('employeeDisciplineService', ['$http',
        function ($http) {            
            return {                
                createEmployeeDiscipline: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/wafs/form-submission-engine/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create Employee Discipline Audit', errorParams)
                    })
                },
            //END
            }        
        }
    ])