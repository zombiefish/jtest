safeToDo.component("form248310", {
    // styling found in avatar.css
    templateUrl: 'app/components/employeeDisciplineForm/employeeDiscipline.html',
    bindings: {
        modalId: '<',
        allData: '<',
        mode: '<',
        incidentId: '<',
        onSave: '&',
        onClose: '&'
    },
    controllerAs: 'vm',
    controller: function ($scope, $q, employeeDisciplineService, listService, modalService, profileService, $compile, employeesService, settingsService, $rootScope, imageCommentService) {
        let vm = this
        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        vm.siteList = []
        vm.jobList = []
        vm.jobListSelect = []
        vm.levelList = []
        vm.levelListSelect = []
        vm.employeeList = []
        vm.supervisorList = []
        vm.distributionList = []
        vm.target = ''
        vm.mainButton = null

        //Function to reset form
        function resetForm() {
            document.forms['employeeDisciplineForm'].classList.remove('was-validated')
            vm.submitted = false

            vm.currentEmpDisc = {
                form_name: '998', //EMPLOYEE DISCIPLINE
                headerdate: dateToday.format("YYYY-MM-DD"),
                site: null,
                job_number: null,
                level: null,
                workplace: '',
                supervisor: null,
                employee_name: null,
                discipline_violation: '',
                event_type: '',
                counselled: '',
                event: '',
                signature_employee: '',
                signature_superintendent: '',
                signature_manager: '',
                signature_employee_img_time: '',
                signature_superintendent_img_time: '',
                signature_manager_img_time: '',
                Report_Distribution1: []
            }
        }

        //Function to get jobs & levels at a site
        vm.getJobsLevels = () => {
            let mainSite = vm.currentEmpDisc.site
            vm.currentEmpDisc.job_number = null
            vm.currentEmpDisc.level = null
            vm.jobListSelect = []
            vm.levelListSelect = []
            vm.getFilteredEmployees()
            vm.jobList.forEach((rec) => {
                if (rec.rld_parent_detail_rld_id == mainSite)
                    vm.jobListSelect.push(rec)
            })
            vm.levelList.forEach((rec) => {
                if (rec.rld_parent_detail_rld_id == mainSite)
                    vm.levelListSelect.push(rec)
            })

        }
        
        vm.getFilteredEmployees = () =>{            
            profileService.filterEmployeeListonJob(vm.currentEmpDisc.job_number)
            vm.employeeList =  profileService.readFilterEmployeeListonJob()
            profileService.filterSupervisorListonJob(vm.currentEmpDisc.job_number)
            vm.supervisorList = profileService.readFilterSupervisorListonJob()
            profileService.filterDistributionListonJob(vm.currentEmpDisc.job_number)
            vm.distributionList = profileService.readFilterDistributionListonJob()
        }

        vm.openSignModal = (e) => {
            if(e.target.tagName.toLowerCase() == 'i') // If clicked on <i>
                e.target = e.target.parentNode

            document.getElementById(`sigModalOK`).removeEventListener('click', signFunction)
            vm.mainButton = e.target
            vm.target = e.target.getAttribute('signaturename')
            $(`#${vm.target}`).val('')
            $(`#${vm.target}_img`).val('')
            $('#output').val('')
            modalService.Open('edisSignatureModal')
            activateSignature()
        }

        function signFunction(e) {
            e.stopPropagation()
            let vecValue = document.querySelector('#output').value

            if (vecValue) {
                vm.currentEmpDisc[vm.target] = $(`.sigPadModal .pad2`)[0].toDataURL('image/jpeg')
                $(`#${vm.target}`).next().val(vecValue)
                $(`#${vm.target}_img`).attr('src', $(`.sigPadModal .pad2`)[0].toDataURL('image/jpeg'))

                img_notes = vm.target + '_img_time'
                time = moment(new Date()).format('YYYY-MM-DD hh:mm:ss a')
                $(`[notes=${img_notes}]`)[0].value = time
                vm.currentEmpDisc[img_notes] = time
                $(`[notes=${img_notes}]`)[0].parentElement.classList.remove("d-none")
            } else {
                $(`#${vm.target}`).val('')
                $(`#${vm.target}`).next().val('')
                $(`#${vm.target}_img`).attr('src', '')

                img_notes = vm.target + '_img_time'
                $(`[notes=${img_notes}]`)[0].value = ""
                vm.currentEmpDisc[img_notes] = ""
                $(`[notes=${img_notes}]`)[0].parentElement.classList.add("d-none")
            }

            $(`#sigModal .output`).val('')

            if (vecValue) {
                vm.mainButton.innerHTML = `<i class="fa fa-pen" note="Re-sign"></i> ${translateTag(2243)}`
                // $(`#${vm.target}`).prev().prev().children()[1].classList.remove('d-none')
                $(`#${vm.target}`).prev().prev().children()[2].classList.remove('d-none') //clear sign
                $(`#${vm.target}`).prev().prev().children()[1].classList.remove('d-none') // add comment button
                $(`#${vm.target}`).prev().prev().children()[0].classList.remove('invalid')
            }
            else {
                vm.mainButton.innerHTML = `<i class="fa fa-pen" note="Sign"></i> ${translateTag(1396)}`
                $(`#${vm.target}_img`).attr('src', '')
                $(`#${vm.target}`).prev().prev().children()[1].classList.add('d-none')
                $(`#${vm.target}`).prev().prev().children()[2].classList.add('d-none')
                clearComment(vm.mainButton)
            }

            let sig = $('.sigPadModal').signaturePad({})
            sig.clearCanvas()

            modalService.Close('edisSignatureModal')
        }

        function activateSignature() {
            $('canvas.pad2').attr({ "width": $('.pad2').parent().width(), "height": $('.pad2').parent().width() / 3 })
            setTimeout(() => {                
                let sig = $('.sigPadModal').signaturePad({
                    lineColour: "#ced4da",
                    drawOnly: true,
                    lineWidth: 0,
                    lineBottom: 10,
                    bgColour: 'rgb(255,255,255)'
                })
                sig.clearCanvas()

                document.getElementById(`sigModalOK`).addEventListener('click', signFunction)
                document.getElementById(`reSignButton`).addEventListener('click', (e) => {
                    canvas = e.target.parentNode.previousSibling.previousElementSibling.previousElementSibling
                    let sig = $('.sigPadModal').signaturePad({
                        lineColour: "#ced4da",
                        drawOnly: true,
                        lineWidth: 0,
                        lineBottom: 10,
                        bgColour: 'rgb(255,255,255)'
                    });
                    sig.clearCanvas()
                })
            }, 300)
        }

        $(`.clear_sign`).click((e) => {
            let clear_button
            if(e.target.tagName.toLowerCase() == 'i') // If clicked on <i>
                e.target = e.target.parentNode
       
            clear_button = e.target
            let id=clear_button.id
            // 'employee_clear'
            let who = id.split('_')[0]
            vm.who = who
            if(vm.signatureCommentObject[who]){
                if(vm.signatureCommentObject[who].com_comment !='' && vm.signatureCommentObject[who].com_comment !==undefined ){ 
                    vm.modalElements = {
                        title: translateTag(2777), //"Remove Signature/Comment?"
                        message: `<div><p>${translateTag(2781)}</p></div>`, //"Are you sure you want to remove the signature and associated comment from the form?"
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                    }  
                    document.getElementById('confirmcallingform').innerHTML = 'EMPDESCALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
                    vm.button = clear_button

                } else {
                    clearSignature(clear_button)
                }
            } else {
                clearSignature(clear_button) 
            }
        })

        $scope.$on("EMPDESCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.clear_signature_comment()
            }
        })
        
        vm.clear_signature_comment = () => {
            vm.signatureCommentObject[vm.who]=null
            clearSignature(vm.button)
            modalService.Close('confirmModal')
        }

        function clearAllSign () {
            let signImgs = Array.from(document.getElementsByClassName("clear_sign"))
            signImgs.forEach ((clear_button) => {
                clearSignature(clear_button)
            })
        }

        function clearSignature(clear_button){
            clear_button.previousElementSibling.previousElementSibling.innerHTML = `<i class="fa fa-pen" note="Sign"></i> ${translateTag(1396)}`
            //clear_button.previousElementSibling.innerHTML = `<i class="fa fa-pen" note="Sign"></i> ${translateTag(1396)}`
            clear_button.parentNode.nextElementSibling.setAttribute('src', '')

            // timestamp related.
            $(`[notes=${clear_button.parentNode.nextElementSibling.id + '_time'}]`)[0].value = ""
            vm.currentEmpDisc[clear_button.parentNode.nextElementSibling.id + '_time'] = ""
            $(`[notes=${clear_button.parentNode.nextElementSibling.id + '_time'}]`)[0].parentElement.classList.add("d-none")
            vm.currentEmpDisc[clear_button.previousElementSibling.getAttribute('signaturename')] = ''            
            clear_button.parentNode.nextElementSibling.nextElementSibling.value = ''            
            clear_button.parentNode.nextElementSibling.nextElementSibling.nextElementSibling.value = ''
            clear_button.parentNode.children[1].classList.add('d-none') //hide the add comment button.
            clear_button.classList.add('d-none') // hide the clear button itself.
            if (clear_button.parentNode.nextElementSibling.nextElementSibling.hasAttribute('required')) {
                clear_button.previousElementSibling.classList.add('invalid')
            }
            // clear comment
            clearComment(clear_button)
        }     
        function clearComment(clear_button){
            let who = clear_button.parentNode.nextElementSibling.id.split('_')[1]
            let elem = document.getElementById(`${who}_comment`)
            elem.classList.remove('fas')
            elem.classList.add('far')  
            vm.signatureCommentObject[who] = null
        }   

        //Function to create the employee discipline
        vm.createEmpDisc = () => {
            let payload = preparePayload(JSON.parse(JSON.stringify(vm.currentEmpDisc)))
            if (vm.validateForm()) {
                vm.submitted = true
                employeeDisciplineService.createEmployeeDiscipline(payload).then((response) => {                    
                    // save comments 
                    let signature_ids = response.signature_ids
                    signature_ids.forEach(signature => {
                        let who = signature[1].split('_')[1]
                        if(vm.signatureCommentObject[who] !== null)
                            vm.signatureCommentObject[who]['com_reference_id'] = signature[0]
                    });

                    Object.keys(vm.signatureCommentObject).forEach(who => {
                        if(vm.signatureCommentObject[who] !== null)
                            imageCommentService.saveComment(vm.signatureCommentObject[who])
                      });
                    
                    vm.closeModal('form-248310')
                    $scope.$emit('REFRESH_FORMSUBMISSIONS')
                })
            } else {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }   
        }

        //Function to prepare payload data
        function preparePayload(payload) {
            let preparedPayload = payload

            preparedPayload.headerdate = moment(payload.headerdate, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DDThh:mm')

            return preparedPayload
        }

        //Function to close the modal
        vm.closeModal = (modalId) => {
            clearAllSign()
            modalService.Close(modalId)
            vm.employeeList = []
            vm.supervisorList = []
            vm.distributionList = []
            resetForm()
            refreshData()
        }
        
        //Function for form validation
        vm.validateForm = () => {
            let validateFormFlag = validateFormFields('employeeDisciplineForm')
            let formVal = document.forms['employeeDisciplineForm']
            formVal.classList.add('was-validated')
            let validated = true
            for (let a = 0; a < formVal.length; a++) {
                if (!formVal[a].validity.valid) {
                    validated = false
                } else if(formVal[a].id=='vector_employee'){
                    if(formVal[a].value == ''){ 
                        validated = false 
                        document.getElementById('sign_button1').classList.add('invalid')
                    }
                }
            }
            // return validated

            if(validated && validateFormFlag)
                return true
            else
                return false           
        }

        $scope.$on('distribution-list-added', (event, args) => {
            if(vm.currentEmpDisc !== undefined)
                $scope.$emit('addDistributionGroup', args, vm.currentEmpDisc.Report_Distribution1)
        })

        $scope.$on('distribution-list-removed', (event, args) => {
            $scope.$emit('removeDistributionGroup', args)
        })

        vm.componentTranslateLabels = (key) => {
            return translateTag(key)
        }

        //Function to refresh all data
        function refreshData() {
            $q.all([
                listService.getSelectListData('ref_site'),
                listService.getSelectListData('ref_job'),
                listService.getSelectListData('ref_level'),
                profileService.getAllEmployeeProfile(),
                profileService.getAllSupervisorProfile(),
                profileService.getDistributionList(),
                employeesService.getPersonProfile()
            ]).then((data) => {
                resetForm()
                vm.siteList = data[0]
                vm.jobList = data[1]
                vm.levelList = data[2]
                vm.employeeList = profileService.readAllEmployeeProfile()                
                vm.supervisorList = profileService.readAllSupervisorProfile()
                vm.distributionList = profileService.readDistributionList()
                vm.current_user_id = data[6].per_id
            }).then((data)=>{
                settingsService.getUserProfile(vm.current_user_id).then((response) => {
                    vm.siteList.forEach((rec)=>{
                        if(response.upr_site===rec.rld_id){
                            vm.currentEmpDisc.site = response.upr_site
                            vm.getJobsLevels()
                        }
                    })
                    vm.jobList.forEach((rec)=>{
                        if(response.upr_job==rec.rld_id){
                            vm.currentEmpDisc.job_number = response.upr_job
                            vm.getFilteredEmployees()
                        }
                    })
                    vm.levelList.forEach((rec) => {
                        if(response.upr_level === rec.rld_id){
                            vm.currentEmpDisc.level = response.upr_level
                        }
                    })
                    vm.supervisorList.forEach((rec)=>{
                        if(response.upr_supervisor_per === rec.per_id){
                            vm.currentEmpDisc.manager = rec.per_id
                        }
                    })
                    if(response.distribution_list){
                        let email_list = []
                        response.distribution_list.forEach((d)=>{
                            email_list.push(d.email)
                        })                   
                        vm.currentEmpDisc.Report_Distribution1 = email_list
                    }
                })
            })
        }

        refreshData()


        // Comments
        vm.signatureCommentObject = {
            employee: null,
            manager : null,
            superintendent : null
        }
        vm.AddComments = (who) => {            
            vm.signed_by = who
            //set parameters for opening the modal here.
            document.getElementById('parentform').innerHTML = 1
            document.getElementById('savetomemory').innerHTML = true
            document.getElementById('callingform').innerHTML = 'CLOSEDISCIPLINEIMAGECOMMENTSMODAL'  
            if(vm.signatureCommentObject[who]!=null) {
                $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.signatureCommentObject[vm.signed_by].com_comment)
            }else{$rootScope.$broadcast("RECIEVEROFCOMMENTS")}   
        }

        $scope.$on('CLOSEDISCIPLINEIMAGECOMMENTSMODAL',(event,data) => {                       
            let elem = document.getElementById(`${vm.signed_by}_comment`)
            if(data.com_comment==''){
                vm.signatureCommentObject[vm.signed_by] = null
            }
            if(data.com_comment){
                if(data.com_comment === '' || data.com_comment === null){
                    vm.signatureCommentObject[vm.signed_by] = null
                    elem.classList.remove('fas')
                    elem.classList.add('far')                
                }
                else{
                    elem.classList.remove('far')
                    elem.classList.add('fas')      
                    vm.signatureCommentObject[vm.signed_by] = data
                } 
            } else {
                let elem = document.getElementById(`${vm.signed_by}_comment`)
                elem.classList.remove('fas')
                elem.classList.add('far') 
            }          
        })
        // end comments
        

        //END
    }
})