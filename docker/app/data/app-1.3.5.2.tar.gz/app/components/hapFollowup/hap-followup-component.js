﻿'use strict'
safeToDo.component("stdHapFollowup", {
    templateUrl: 'app/components/hapFollowup/hap-followup.html',
    bindings: {
        modalId: '<',
        followup: '<',
        selectedHapId: '<',
        attachmentModalFiles: '<',
        selectedIncident: '<',
        followupAttachmentModalFiles: '<',
    },
    controllerAs: 'vm',
    controller: function ($scope, $element, $timeout, $filter, $compile, modalService, listService, hapsService, actionManagementService, profileService, $rootScope, fileUploadService, imageCommentService ) {
        var vm = this
        var elem = $($element)
        let today = moment(new Date(), 'YYYY-MM-DD')
        vm.employees = []
        vm.stepsModel = []
        vm.hapUploadFileList = []

        vm.$onInit = () => {
            profileService.getAllEmployeeProfile().then((res)=>{
                vm.employees = profileService.readAllEmployeeProfile()                
            })                      
            vm.actionTypes = listService.getActionTypes()      
            
            
        }
        vm.$onChanges = () => {
            vm.stepsModel = []      
            vm.hapUploadFileList = []

        }        
       
        //Function to close the modal
        vm.closeModal = (id) => {
            resetFormFieldClassList('followup')
            vm.submitted = false
            modalService.Close(id)
            $scope.$emit('CLOSEMODAL')
        }

        //Function to delete attachments
        vm.deleteFollowupAttachment = (index) => {
            vm.deleteAttachmentConfirmationModal(index)  
            for (let image_index=0;image_index<vm.stepsModel.length;image_index++){

                if(vm.stepsModel[image_index].comment){
                    if(vm.stepsModel[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                } else {
                    let elem = document.getElementById('comment_' + image_index)
                    elem.classList.remove('fas')
                    elem.classList.add('far')
                }
            }    
        }

        vm.deleteIndex = null
        //Function to open delete Attachment Confirmation Modal
        vm.deleteAttachmentConfirmationModal = (index) => {
            vm.deleteIndex = index
            vm.modalElements = {
                title: translateTag(3416), //"Delete Attachment?"
                message: `<div><p>${translateTag(1452)}</p></div>`, //"You are about to delete this attachment.Are you sure?"
                buttons: 
                    `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                    <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            }  
            document.getElementById('confirmcallingform').innerHTML = 'HAPFOLLOWCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("HAPFOLLOWCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.deleteInitAttachmentAfterConfirmation(vm.deleteIndex)
            }
        })

        //Function to delete initial attachments after click "ok" in Confirmation modal
        vm.deleteInitAttachmentAfterConfirmation = (index) => {   
            vm.hapUploadFileList.splice(index, 1)
            vm.stepsModel.splice(index, 1)
            vm.deleteIndex = null
            modalService.Close('confirmModal')
        }

        $scope.followupFileUploadChanged = (event)=> {

            let existingFileNames = []
            for(let i in vm.hapUploadFileList) {
                existingFileNames.push(vm.hapUploadFileList[i].name)
            }

            //Add newly selected files after checking for duplicates and correct file types
            vm.hapUploadFileList = vm.hapUploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, existingFileNames, true))
            
            //Get data from files to display in html
            fileUploadService.getFileUploadData(vm.hapUploadFileList).then ((filesData) => {
                vm.stepsModel = filesData
                $scope.$apply() // Update html bindings
            })
        }
       

        vm.convertTime = (timestamp) =>{
            return moment(timestamp).format("YYYY-MM-DD hh:mm:ss a")
        }

        vm.componentTranslateLabels = (key) => {
            return translateTag(key)
        }
        
        //Function to complete hazard action
        vm.updateFollowup = () => {            
            resetFormFieldClassList('followup')
            if(validateFormFields('followup')){
                vm.submitted = true
                vm.followup.action_status = 'COMPLETE'
                vm.followup.id = vm.selectedHapId
                
                let completeHapPayload = vm.prepareCompletePayload(vm.followup)
                hapsService.completeHazardAction(completeHapPayload)
                    .then((response) => {
                        let submission_hap_ID = vm.followup.id
                        for (var i in vm.hapUploadFileList) {
                            let fd = new FormData()
                            fd.append("submission_hap_id", submission_hap_ID)
                            fd.append("submission_hap_file", vm.hapUploadFileList[i])
                            fd.append("submission_hap_type", 'FOLLOWUP')
                            fd.append("haa_image_timestamp", moment.unix(vm.hapUploadFileList[i].lastModified/1000).format('YYYY-MM-DD HH:mm:ss'))

                            //Console log form data
                            for (var pair of fd.entries()) {
                                // console.log(pair[0]+ ' : ' + pair[1])
                            }

                            if(vm.hapUploadFileList.length > 0) {
                                actionManagementService.addHazardActionAttachments(fd).then((res) => {                                    
                                        let sfiles = res.data.message["Successfull Files"]
                                        let attached_count = 0
                                        sfiles.allowed_original.forEach((attached) =>  {
                                            vm.stepsModel.forEach((newA) =>{
                                                if(newA.comment){
                                                    if(attached==newA.file){
                                                        //call the add comment service.
                                                        newA.comment.com_reference_id = sfiles.ids[attached_count]
                                                        // console.log("saving")
                                                        //call service to insert comment.
                                                        imageCommentService.saveComment(newA.comment)    
                                                    }
                                                }
                                            })
                                            attached_count++
                                        })
                                    })
                                }
                                else {
                                }
                            }
                            $scope.$emit('COMPLETEACTION', vm.followup)
                            $scope.$emit('UPDATE_FOLLOWUP', vm.followup)
                            toastr.success(`${translateTag(2026)}!`) // Action Complete!
                            vm.closeModal(vm.modalId)
                    }, (failureArgs) => {
                        console.log("Error Updateing HAP", failureArgs)
                        toastr.error("Failed to save changes.")
                    })
            }
            else{
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        vm.prepareCompletePayload = (data) => {

            return {
                "action_complete_by_who" : data["action_complete_by_who"],
                "action_completed_date" : data["action_completed_date"],
                "completed_action_type" : data["action_type"],
                "completed_action_taken" : data["completed_action_taken"],
                "completed_action_score" : data["completed_action_score"],
                "submission_hap_id" : data["HapId"]
            }            
        }        

        $scope.$on('HAZARD_FOLLOWUP_OPENED', () => {
            vm.followup.completed_action_type = addHistoricalOption('completed_action_type', vm.actionTypes, vm.followup.completed_action_type, vm.followup.completed_action_type_ltr_text)
            profileService.filterEmployeeListonJob(vm.followup.JobNumber)
            vm.employees =  profileService.readFilterEmployeeListonJob()
            $scope.$apply()
        })

        function addHistoricalOption (select, list, rld_id, ltr_text) {
            if(rld_id && !list.some(t => t.rld_id === rld_id))
            {
                let historicRecord = {
                        rld_historical: true,
                        rld_id: rld_id,
                        rld_name: `${ltr_text} (${translateTag(8717)})` //Historical
                }
                list.push(historicRecord)
                $(`#${select}`).trigger('change')                
            }
            return rld_id
        }

        // functions to add comments to images
        vm.AddComments = (index, from) => {            
            document.getElementById('mode').innerText = ''
            document.getElementById('relatedimageindex').innerText = index
            document.getElementById('callingform').innerText = 'CLOSEHAPFIMAGECOMMENTSMODAL'
            document.getElementById('parentform').innerHTML = 5 // SubmissionHap Module	SubmissionHAPAttachments
            document.getElementById('savetomemory').innerHTML = "true"       

            vm.ImageFrom = from                        

            if(vm.ImageFrom=='memory'){                
                if(vm.stepsModel[index].comment){
                    document.getElementById('comment').value = vm.stepsModel[index].comment.com_comment
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.stepsModel[index].comment.com_comment)
                }
                else{
                    document.getElementById('imageid').innerHTML = ''
                    document.getElementById('comment').value = ''
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                }
            }
            else{
                if(vm.stepsModel[index].comment){
                    document.getElementById('comment').value = vm.stepsModel[index].comment.com_comment
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.stepsModel[index].comment.com_comment)
                } else {
                    document.getElementById('imageid').innerHTML = ''
                    document.getElementById('comment').value = ''
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                }
            }
        }

        $scope.$on('CLOSEHAPFIMAGECOMMENTSMODAL',(event,data) => {            
            let image_index = document.getElementById('relatedimageindex').innerText  
            if(vm.mode==='edit'){
                if(vm.ImageFrom=='disk'){                    
                    vm.hapModel.attachments[vm.editAttachmentIndex].com_comment= data.com_comment  
                    vm.hapModel.attachments[vm.editAttachmentIndex].com_id=data.com_id     
                    
                    if(vm.hapModel.attachments[vm.editAttachmentIndex].com_comment !='' && vm.hapModel.attachments[vm.editAttachmentIndex].com_comment != null){
                        let elem = document.getElementById('disk_comment_' + image_index)                        
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('disk_comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                    
                }
                else if(vm.ImageFrom =='memory'){
                   
                    vm.stepsModel[image_index].comment = data
                    vm.stepsModel[image_index].comment.com_reference_id = image_index                    
                    if(vm.stepsModel[image_index].comment){                        
                        if(vm.stepsModel[image_index].comment.com_comment !=''){
                            let elem = document.getElementById('comment_' + image_index)                            
                            elem.classList.remove('far')
                            elem.classList.add('fas')
                        } else {
                            let elem = document.getElementById('comment_' + image_index)
                            elem.classList.remove('fas')
                            elem.classList.add('far') 
                        }
                    }
                }
            }
            else
            {                
                vm.stepsModel[image_index].comment = data
                vm.stepsModel[image_index].comment.com_reference_id = image_index               
             
                if(vm.stepsModel[image_index].comment){
                    if(vm.stepsModel[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                }
            }

        })
        // end functions to add comments to images

        //Functions to get lists
        

        //End
    } 
})