﻿'use strict';
safeToDo.component("lineupForm", {
  // styling found in avatar.css
  templateUrl: 'app/components/lineupForm/lineup-component.html',
  bindings: {
    mode: '@',
    editlineupid: '@',
    doclocklineuplockid : '@'
  },
  controllerAs: 'vm',

  controller: ['$controller','$compile', '$rootScope', '$scope', '$timeout', '$q', '$sce', '$interval', 'lineupService', 'listService', 'modalService','profileService', 'documentLockService', 'equipmentService', 'select2Service' ,
    function ($controller, $compile, $rootScope, $scope, $timeout, $q, $sce, $interval, lineupService, listService, modalService, profileService, documentLockService, equipmentService, select2Service) {
      var vm = this
      vm.token = JSON.parse(localStorage.getItem('token')).access
      vm.eGroup_all = []
      vm.equipmentSiteJobListData = []
      vm.equipment_main_list = []
      $controller('distributionGroupCtrl', {$scope: $scope})
      

    vm.setEquipmentBySiteJob = () => {
      // Creating categories 
      // 9561 Equipment associated to Site selected
      // 9560 Equipment associated to Department/Job selected
      // 9562 Company-wide Equipment
      let preop_site = vm.form.lineup.Site?vm.form.lineup.Site:""
      let preop_job = vm.form.lineup.JobNumber?vm.form.lineup.JobNumber:""
      vm.equipment_main_list = []
      if(preop_job) {    

        let siteJobLen =  vm.equipmentSiteJobListData.length
        for(let i=0; i<siteJobLen; i++){
          if(vm.equipmentSiteJobListData[i].psj_rld_site_id == preop_site && !vm.equipmentSiteJobListData[i].psj_rld_job_id) {
            vm.equipment_main_list.push({
              "group": translateTag(9561),
              "value": `${vm.equipmentSiteJobListData[i].pet_equipment_identifier}|${vm.equipmentSiteJobListData[i].pet_poe_id}`,
              "label": `${vm.equipmentSiteJobListData[i].pet_equipment_identifier} ${vm.equipmentSiteJobListData[i].pet_equipment_name}`,
              "sort": 1
            })
          }
          if(vm.equipmentSiteJobListData[i].psj_rld_site_id == preop_site && vm.equipmentSiteJobListData[i].psj_rld_job_id == preop_job) {
            vm.equipment_main_list.push({
              "group": translateTag(9560),
              "value": `${vm.equipmentSiteJobListData[i].pet_equipment_identifier}|${vm.equipmentSiteJobListData[i].pet_poe_id}`,
              "label": `${vm.equipmentSiteJobListData[i].pet_equipment_identifier} ${vm.equipmentSiteJobListData[i].pet_equipment_name}`,
              "sort": 2
            })
          }
        
          if(!vm.equipmentSiteJobListData[i].psj_rld_job_id && !vm.equipmentSiteJobListData[i].psj_rld_site_id) {
            vm.equipment_main_list.push({
              "group": translateTag(9562),
              "value": `${vm.equipmentSiteJobListData[i].pet_equipment_identifier}|${vm.equipmentSiteJobListData[i].pet_poe_id}`,
              "label": `${vm.equipmentSiteJobListData[i].pet_equipment_identifier} ${vm.equipmentSiteJobListData[i].pet_equipment_name}`,
              "sort": 3
            })
          }
        }
      }
    }

      function resetReview(){
        vm.reviewData = {
          drm_document_type_rld_id: 3275, 
          drm_description: "", 
          drm_review_by_date: "" , 
          drm_expiry_date: '', 
          drm_non_expiring_document: 0, 
          drm_is_submitted: 1, 
          reviewers: [],
          id: null,
          type: 'lineup' 
        }
      }



      vm.$onInit = () => {
        equipmentService.getEquipmentSiteJob().then((data)=>{
          vm.equipmentSiteJobListData = equipmentService.readEquipmentSiteJobList()
        })

        // Activate the Autosave 
        vm.autosave = $interval(() => {
          vm.saveLineup('autosave')
        }, 30000)

        vm.resetForm()
        vm.headerValidation = true
        switch (vm.mode) {
          case 'recovery':
            vm.form = JSON.parse(localStorage.getItem('LineupRecovery'))
            vm.recoverLineup()
            vm.headerValidation = false
            break
          case 'edit':
            vm.editLineup(vm.editlineupid)
            lineupStartup()
            break
          default:
            // vm.initializeSelect2()
            vm.initializeSelect2('lineupForm')
            break
        }
      }

      function lineupStartup() {
        startUpdateDocLock()
        startLockModal()
          //Zero the idle timer on mouse movement.
        $('#lineupForm').mousemove(function (e) {
          clearInterval(vm.lockModal)
          vm.idletime = 0
          startLockModal()
        })
  
        //Zero the idle timer on keypress event
        $('#lineupForm').keypress(function (e) {
            clearInterval(vm.lockModal)
            vm.idletime = 0
            startLockModal()
        })
      }


      vm.translateLabels = (key) =>{
        return translateTag(key)
      }

      vm.getToday = () => {
        return new Date().toJSON().slice(0, 10).replace(/-/g, '-')
      }
      vm.sites = []
      vm.filled = ''
      vm.jobs = []
      vm.levels = []
      vm.jraList = []
      vm.jraSteps = []
      vm.ppe = []
      vm.selectPPE = ''
      vm.crewTypes = []
      vm.shiftTypes = []
      vm.EmailLineup = false
      vm.employees = []
      vm.employees_visibility = []
      vm.supervisor_visibility = []
      vm.allContactList = []
      vm.supervisorList = []
      vm.disableSaveButton = false
      vm.showSubmit = true
      vm.showCancelModal = true
      vm.employeeRef = []
      vm.emailList = []
      vm.machineTypes = []
      vm.headerValidation = true
      vm.workplaceCount = 0
      vm.employeeProfile = {}
      vm.disableYesButton = false
      vm.disableNoButton = false
      vm.hideingLineupViewer = false
      vm.openingLineupViewer = false
      vm.warningMessage=true
      vm.distributionList = []
      vm.disableSave = false
      vm.submitFormObj = {}
      vm.submitFlag = false

      vm.resetForm = () => {
        vm.submitFormObj = {}
        vm.form = {
          lineup: {
            ID: null,
            Site: null,
            JobNumber: null,
            Supervisor: null,
            LoggedIn: '',
            ClientRep: '',
            Crew: null,
            Date: '',
            LineupDate: vm.getToday(),
            Shift: null,
            ContactInfo: '',
            SafetyTopic: '',
            WorkplaceImpacts: '',
            CommunicationNotes: '',
            distribution:[]
          },
          Workplaces: []
        };
        vm.submitFlag = false
      }
      vm.custom = true
      
      $scope.$on('distribution-list-added', (event, args) => {
          if(vm.form !== undefined && vm.form.lineup !== undefined)
            $scope.$emit('addDistributionGroup', args, vm.form.lineup.distribution)
      })

      $scope.$on('distribution-list-removed', (event, args) => {
          $scope.$emit('removeDistributionGroup', args)
      })

      vm.accordianToggle = () => {
        vm.custom = vm.custom === false ? true : false
      }

      vm.workAlone = [
        {
          id: 1,
          label: vm.translateLabels(1379)  // yes
        },
        {
          id: 0,
          label: vm.translateLabels(1380)  // no
        }
      ]
      vm.idletime = 0
      vm.continueEditing = false
      vm.leaveEditing = false
      vm.lockCheckModal = false
      vm.countdownSeconds = 60

      // function to reset timestamp of document lock___ 
      function startUpdateDocLock(){
        vm.updateDocLockInterval = setInterval(() => {
            $q.all([
                documentLockService.intervalDocLock(vm.doclocklineuplockid)
            ]).then((response) => {
            })
        }, 30 * 1000)
      }

      function startLockModal(){
        vm.lockModal = setInterval(() => {
            vm.idletime = vm.idletime + 1 // 1 minute
            if(vm.idletime === 5){ // after 5 minutes of idle time open lockcheck modal
                vm.continueEditing = false
                vm.leaveEditing = false
                vm.modalElementsLock = {
                  title: translateTag(3419),   //"Page inactive for 5 minutes" 
                  message: `<div style="text-align: center;"><h1 id ="inactiveTime" ></h1><p> ${translateTag(3420)}</p></div>`,  //"The entry will automatically save and close if no action is taken"
                  buttons: 
                      `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Continue Working">{{vm.componentTranslateLabels(3421)}}</button>
                      <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Save and Close">{{vm.componentTranslateLabels(3422)}}</button>`
                }
                document.getElementById('confirmcallingform').innerHTML = 'LINEUPLOCKCALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsLock)
                vm.lockCheckModal = true
                startcountdownTimer()
                vm.relieveLock = setTimeout(() => {
                    if (vm.lockCheckModal === true){
                        if (!vm.continueEditing && !vm.leaveEditing){
                            vm.leaveEditing = true
                            vm.saveLineup('lock')                            
                        }
                    }
                }, 60 * 1000); // 60 seconds wait time
            }                                        
        }, 60 * 1000);
      }

      $scope.$on("LINEUPLOCKCALLCONFIRMMODAL", (event,result) => {
        if (result=='button1') {
            vm.continueEditingLineup()
        }
        else if (result=='button2') {
          vm.saveLineup('lock') 
        }
    })
      
      vm.continueEditingLineup = () => {
        modalService.Close('confirmModal')
        document.getElementById('inactiveTime').textContent = ''
        vm.countdownSeconds = 60
        vm.lockCheckModal = false
        vm.continueEditing = true
        clearInterval(vm.lockModal)
        clearInterval(vm.countdownTimer)
        clearTimeout(vm.relieveLock)
        vm.idletime = 0
        startLockModal()
      }
      
      function startcountdownTimer(){
        vm.countdownTimer = setInterval(() => {
            if(vm.lockCheckModal === true && vm.countdownSeconds>=0){
                vm.content =''                
                if (vm.countdownSeconds === 60){
                    vm.content = "01:00"
                }
                else{
                    vm.content = "00:" + vm.countdownSeconds.toLocaleString('en-US', {
                        minimumIntegerDigits: 2,
                        useGrouping: false
                      }) 
                }
                document.getElementById('inactiveTime').textContent =  vm.content
                vm.countdownSeconds = vm.countdownSeconds - 1   
            }                                       
        }, 1000)
      }

      vm.openModal = (modalId) => {
        if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
            $scope.$apply()

        $('.modal .scroll').scrollTop(0)

        modalService.Open(modalId)
        vm.initializeSelect2(modalId, '.modal-body')
      }

       //Function to close the viewer
      vm.closeViewer = () => {
        if(vm.mode === 'edit'){
          // release document___ 
          vm.releaseDocument(vm.doclocklineuplockid)
          clearInterval(vm.updateDocLockInterval)
          clearInterval(vm.lockModal)
          clearInterval(vm.countdownTimer)
          clearTimeout(vm.relieveLock)
          // Stop the Autosave
          $interval.cancel(vm.autosave)
          $scope.$emit("Upsert_Lineup", vm.form.lineup.ID);
        }
        vm.hideingLineupViewer = true
        vm.warningMessage = true
        vm.resetForm()
        $timeout(() => {
            vm.lineupViewerOpen = false
        }, 400)
      }

      // function to release document lock
      vm.releaseDocument = (id) => {
        vm.payload = {}
        vm.payload.dlo_id = id
        return (
            $q.all([
                documentLockService.closeDocLock(vm.payload).then((response) => {
                })
            ])
        )
      }

      vm.trimValue = (val) => {
        return (val.trim())
      }

      //Function to initialize select2
      vm.initializeSelect2 = (parent, section='')=> {
          setTimeout(()=>{ 
            $('.select-single, .select-multiple')
            .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} ${section}`), escapeMarkup: function (text) { 
              return text } })
            .on('select2:select', (event) => {
              if (event.target.parentNode.querySelector('.distribution-list'))
                $rootScope.$broadcast('distribution-list-added', event)
                
              $(this).parent().find('label').addClass('filled')
            })
            .on('select2:unselect', (event) => {
              if (event.target.parentNode.querySelector('.distribution-list'))
                  $rootScope.$broadcast('distribution-list-removed', event)
              $(this).parent().find('label').addClass('filled')
            })
            $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
            select2Service.select2Tags()
            if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
            $('.datepicker').pickadate({
              format: 'yyyy-mm-dd',
              onClose : function(){
                this.$holder.blur()
            },
            }).removeAttr('readonly')
            .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
              evt.preventDefault()
            })
          }, 100)
      }

      vm.closeModal = () => {
        modalService.Close('confirmModal');
        vm.showSubmit = false
        vm.disableSaveButton = false
      }

      vm.toggleInfo = () => {
        $(".alert").slideToggle();
      }

      vm.toggleEmail = (data) => {
        if (vm.EmailLineup === true) {
          vm.EmailLineup = false
        } else {
          vm.EmailLineup = true
        }
      }

      vm.generateSubmissionID = () => {
        return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
          (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
        )

      }

      toastr.options.closeButton = true
  
      vm.viewReports = (e, id) =>{        

        if(!e.ctrlKey)
        {
          let lang_number = localStorage.getItem('lang_id')
          vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.singleServeReportUrl}/${id}?lang=${lang_number}&t=${vm.token}`)
          $window.open(vm.reportURL, "_blank")
        }
      }


      // Load the sites and Jobs
      $q.all([
        //  listService.getExternalContactList(),
          lineupService.getSites(),
          lineupService.getPPETypes(selectedLanguage),
          lineupService.getCrewTypes(selectedLanguage),
          lineupService.getShiftTypes(selectedLanguage),
          lineupService.getEmployeesList(),
          lineupService.getEmployeesVisibilityList(),
          lineupService.getSupervisorVisibilityList(),
          profileService.getAllSupervisorProfile(),
          profileService.getDistributionList(),
         // equipmentService.getEquipment(),
          equipmentService.getEquipmentSummary()
        ]).then((data) => {
              vm.fullEquipmentList = collateSubmissions(equipmentService.readEquipmentSummary())
              vm.ppe = lineupService.readPPEList()
              vm.crewTypes = lineupService.readCrewTypeList()
              vm.shiftTypes = lineupService.readShiftTypeList()
              $q.all([
                  lineupService.getJobsList(),
                  lineupService.getLevelsList(selectedLanguage)
                ]).then(() => {
               //   vm.externalContactList = data[0]
                  vm.employees = lineupService.readEmployeesList()
                  vm.employees_visibility = lineupService.readEmployeesVisibilityList()
                  vm.allContactList = profileService.readDistributionList()
                  vm.supervisor_visibility = lineupService.readSupervisorVisibilityList()
                  vm.supervisorList = profileService.readAllSupervisorProfile()
                  vm.employees.forEach((data, index) => {
                    vm.employeeRef[data.per_id] = {
                      email: data.email
                    }
                  })
                  createDistributionlist() 
                  }).then(()=>{
                    vm.sites = lineupService.readSites()
                    vm.jobs = lineupService.getJobs(vm.form.lineup.Site)
                    vm.levels = lineupService.getLevels(vm.form.lineup.Site)
                    $scope.$emit('STOPSPINNER')
                    vm.initializeSelect2('lineupForm')
                    $scope.$emit('JOBSREADY')
              }) 
            })

      function collateSubmissions(submissions) {
        let myIDs = []
        let myRecs = []
        submissions.forEach((subs) => {
            // if (!myIDs.includes(`${subs.EquipmentIdentifier}${subs.equipment_desc}`)) {
            //   myIDs.push(`${subs.EquipmentIdentifier}${subs.equipment_desc}`)
              let EquipDesc = `${subs.EquipmentIdentifier} - ${subs.ltr_text}`
              let fullValue = `${subs.EquipmentIdentifier}|${subs.PreOpEquipmentID}`
              let equip= {
                FullDesc : EquipDesc,
                FullValue : fullValue
              }
              myRecs.push(equip)
            // }
        })            

        return myRecs
      }
  
            
      function createDistributionlist() {
        let fullList = []
        vm.allContactList.forEach((email)=>{
          fullList.push({"name":`${email.name}`, email: email.email})
        })
          vm.distributionList = fullList
          vm.distributionList.sort((a,b) => (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0))
      }

      vm.getMachineTypes = (workPlace, workerNumber, machineNumber) => {
        let mNumber = vm.form.Workplaces[workPlace].Workers[workerNumber].equipment[machineNumber].EquipmentNumber
        let pickedNumber = mNumber ? mNumber:null
        vm.form.Workplaces[workPlace].Workers[workerNumber].equipment[machineNumber].EquipmentList = []
        lineupService.getMachineTypes(mNumber).then((data) => {
          data.forEach((item) => {
            vm.form.Workplaces[workPlace].Workers[workerNumber].equipment[machineNumber].EquipmentList.push({
              ID: item.ID,
              Value: item.Value,
              Label: item.Label
            })
          })
          vm.form.Workplaces[workPlace].Workers[workerNumber].equipment[machineNumber].EquipmentList.push({
            ID: 'OTHER',
            Value: 60,
            Label: 'Other'
          })
        })
      }

      vm.validateSiteExists=()=>{
        if (vm.form.lineup.Site != '' || vm.form.lineup.Site !== undefined)
        vm.warningMessage=false
      else
        vm.warningMessage=true
      }

      vm.getJobsLevels = () => {
        vm.headerValidation = false
        vm.validateSiteExists()
        vm.setEquipmentBySiteJob()
        vm.jobs = lineupService.getJobs(vm.form.lineup.Site)
        vm.levels = lineupService.getLevels(vm.form.lineup.Site)
        setTimeout(() => {
          if (vm.form.Workplaces.length < 1 && vm.form.lineup.Site !== undefined )
            vm.addWorkplace()
        }, 100)
      }

      $scope.$on('JOBSREADY', (event) => {
        vm.getJRAList()
        $scope.$emit('JRAREADY')
      })

      $scope.$on('JRAREADY', (event) => {
        vm.form.Workplaces.forEach((wp)=>{
          vm.getJraSteps(wp)
        })
     
      })

      vm.getFilteredEmployees = () => {
        profileService.filterEmployeeListonJob(vm.form.lineup.JobNumber)
        vm.employees_visibility =  profileService.readFilterEmployeeListonJob()
        profileService.filterSupervisorListonJob(vm.form.lineup.JobNumber)
        vm.supervisor_visibility = profileService.readFilterSupervisorListonJob()
        profileService.filterDistributionListonJob(vm.form.lineup.JobNumber)
        vm.distributionList = profileService.readFilterDistributionListonJob()
      }

      vm.getJRAList = () => {
        let jobId = vm.form.lineup.JobNumber ? vm.form.lineup.JobNumber: 0
        vm.setEquipmentBySiteJob()
        // filter out people that do not have access to the job selected.
        vm.getFilteredEmployees()
        lineupService.getLineupJRAList(jobId).then((res)=>{
          vm.jraList = lineupService.readLineupJRAListData()
        })
      }

      vm.getJraSteps = (workplace) => {
        workplace.StepList = []
        if(workplace.WorkplaceJRA) {
          lineupService.getLineupJRAStepList(workplace.WorkplaceJRA).then((res)=>{

            workplace.StepList = lineupService.readLineupJRAStepData()
            vm.showJraStepData(workplace)
          })
        }
      }

      vm.showJraStepData = (wp) => {
        let stepData = []
        if(wp.Steps) {
          wp.Steps.forEach((step, index)=> {
            wp.StepList.forEach((data)=>{
              if(step == data.rmm_jsc_id) {
                stepData.push({
                  step: data.rmm_jsc_step,
                  controls: [],
                  additional_controls: []
                })
                stepData[index].controls = []
                data.threats.forEach((threat)=> {
                  threat.tags.forEach((tag)=>{
                    if(tag.rmm_jta_parent_tag_name === 'control_measures'){
                      stepData[index].controls.push(tag.tag)
                    }
                    if(tag.rmm_jta_parent_tag_name === 'additional_control_measures'){
                      stepData[index].additional_controls.push(tag.tag)
                    }
                  })
                })
              }
            })
          })
          wp.Controls = stepData
        }
      }

      vm.getLevelHazards = (site, level, workplace) => {        
        let reportUrl = ''
        let lang_number = localStorage.getItem('lang_id')
        vm.form.Workplaces[workplace].Hazards = ""
        // if(level){         
        //   lineupService.getHazards({ site: site, level: level }).then((response) => {            
        //     if (response.length > 0) {
        //       vm.form.Workplaces[workplace].Hazards = response
        if(level){
          lineupService.getHazards({ site_name: site, site_level: level , }).then(() => {
            let hazs = lineupService.readHazards()

            if (hazs!=null) {
              vm.form.Workplaces[workplace].Hazards = hazs
              localStorage.setItem('LineupRecovery', JSON.stringify(vm.form))
              vm.form.Workplaces[workplace].HazardsList = formatHazards(hazs)
              vm.form.Workplaces[workplace].Hazards.forEach((haz)=>{
                haz.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${haz.report_url}/${haz.submissionheaderid}?lang=${lang_number}&t=${vm.token}`)
              })

            }
          })
        }
      }

      vm.addWorkplace = (event) => {
        vm.showSubmit = true
        let wpNumber = vm.form.Workplaces.length
        vm.form.Workplaces[wpNumber] = {
          WorkplaceID: null,
          WorkplaceName: '',
          WorkplaceLevel: '',
          WorkplaceLevels : [],
          WorkplaceLineup: '',
          WorkplaceJRA: null,
          Controls: [],
          Steps: [],
          Workers: [],
          ppe: []
        }

        vm.form.Workplaces[wpNumber].Workers.push({
          Hazards: [],
          WorkerID: null,
          WorkerName: null,
          WorkerAlone: 0,
          equipment: [],
          ppe: []
          })
        let wpLayout = `
             <div class="card mb-4">
              <div class="card-header pt-0" id="heading${wpNumber}">
                <div class="row">
                  <div class="col-6">
                    <div class="md-form">
                      <select class="select-multiple" multiple name="WorkplaceLevel${wpNumber}" id="WorkplaceLevel${wpNumber}" ng-model="vm.form.Workplaces[${wpNumber}].WorkplaceLevels" ng-options="level.level as level.lable for level in vm.levels" ng-change="vm.getLevelHazards(vm.form.lineup.Site,vm.form.Workplaces[${wpNumber}].WorkplaceLevels,${wpNumber})" required>
                        <option value=""></option>
                      </select>
                      <label for="WorkplaceLevel${wpNumber}" ng-class="{filled:vm.isWorkplaceLevelFilled(${wpNumber}),active:vm.isWorkplaceLevelFilled(${wpNumber})}" note="Area/Level">${vm.translateLabels('621')}</label>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="md-form">
                      <input html-decode type="text" id="workplaceName${wpNumber}" name="workplaceName${wpNumber}" class="form-control" ng-model="vm.form.Workplaces[${wpNumber}].WorkplaceName" required>
                      <label for="workplaceName${wpNumber}" ng-class="{filled:vm.form.Workplaces[${wpNumber}].WorkplaceName,active:vm.form.Workplaces[${wpNumber}].WorkplaceName}" note="Workplace">${vm.translateLabels('959')}</label>
                    </div>
                  </div>
                  <div class="col-2 pt-4">
                    <button type="button" class="btn btn-link p-2 float-right" ng-click="vm.accordianToggle()" note="Toggle Workplace Visibility" title="${vm.translateLabels('3508')}" data-toggle="collapse" data-target="#collapse${wpNumber}" aria-expanded="false" aria-controls="collapseOne">
                      <i class="fas fa-chevron-up fa-lg"></i>
                    </button>
                    <button type="button" class="btn btn-flat p-2 float-right" note="Delete Workplace" title="${vm.translateLabels('3506')}" ng-click="vm.deleteEntryModal('Workplace',${wpNumber},${vm.form.Workplaces[wpNumber].WorkplaceID})">
                      <i class="far fa-trash-alt fa-lg mx-0"></i>
                    </button>
                  </div>
                  <div class="col-12">
                    <div class="md-form mt-0">
                      <textarea html-decode name="WorkplaceLineup0" id="WorkplaceLineup0" class="form-control md-textarea" ng-model="vm.form.Workplaces[${wpNumber}].WorkplaceLineup" length="300" maxlength="4000" required></textarea>
                      <label for="WorkplaceLineup" ng-class="{filled:vm.form.Workplaces[${wpNumber}].WorkplaceLineup,active:vm.form.Workplaces[${wpNumber}].WorkplaceLineup}" note="Lineup Details">${vm.translateLabels('1972')}</label>
                    </div>
                  </div>

                  <div class="col-12" ng-if="vm.form.Workplaces[${wpNumber}].Hazards">
                    <div class="accordion md-accordion" id="accordionHazards-${wpNumber}" role="tablist" aria-multiselectable="true">
                      <div class="card border-0 bg-transparent">
                        <div class="card-header px-3 pt-0 pb-2" role="tab" id="headingOne1">
                          <a class="collapsed" data-toggle="collapse" data-parent="#accordionHazards-${wpNumber}" ng-click="vm.accordianToggle()" data-target="#collapseHazards-${wpNumber}">
                            <h6 class="mb-0 text-danger" note="Open hazards at these levels">
                            ${vm.translateLabels('3509')} ({{vm.form.Workplaces[${wpNumber}].Hazards.length}})<i class="fas fa-angle-down rotate-icon"></i>
                            </h6>
                          </a>
                        </div>
                        <div id="collapseHazards-${wpNumber}" class="collapse" role="tabpanel" data-parent="#accordionHazards-${wpNumber}">
                          <div class="card-body">
                            <span ng-repeat="item in vm.form.Workplaces[${wpNumber}].HazardsList ">
                              <h6><strong note="Area/Level">${vm.translateLabels('621')}:{{(item)}}</strong> </h6>
                              <span ng-repeat="hazarditem in vm.form.Workplaces[${wpNumber}].Hazards | filter:item"> 
                                <span note="Workplace">${vm.translateLabels('959')}: <a href="{{hazarditem.reportURL}}" target="_blank">{{hazarditem.submissionheaderid__workplace}}</a></span><p note="Hazard">${vm.translateLabels('1320')}: {{hazarditem.hazard_description}}</p></span>
                              </span>
                            </span>
                          </div>
                        </div>
                        </div>
                      </div>
                    </div>

                
                  <div class="col-12">
                    <div class="md-form">
                      <select class="select-single" name="WorkplaceLJRA${wpNumber}" ng-model="vm.form.Workplaces[${wpNumber}].WorkplaceJRA" ng-options="jra.rmm_jra_id as jra.rmm_jra_title for jra in vm.jraList" ng-change="vm.getJraSteps(vm.form.Workplaces[${wpNumber}])">
                        <option value=""></option>
                      </select>
                      <label for="WorkplaceLJRA${wpNumber}" ng-class="{filled:vm.form.Workplaces[${wpNumber}].WorkplaceJRA, active:vm.form.Workplaces[${wpNumber}].WorkplaceJRA}">${vm.translateLabels('3510')}</label>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="md-form">
                      <select class="select-multiple" multiple name="WorkplaceLJRAStep${wpNumber}" id="WorkplaceLJRAStep${wpNumber}" ng-model="vm.form.Workplaces[${wpNumber}].Steps" ng-options="step.rmm_jsc_id as step.rmm_jsc_step for step in vm.form.Workplaces[${wpNumber}].StepList" ng-change="vm.showJraStepData(vm.form.Workplaces[${wpNumber}])">
                        <option value=""></option>
                      </select>
                      <label for="WorkplaceLJRAStep${wpNumber}" ng-class="{filled:vm.form.Workplaces[${wpNumber}].Steps.length,active:vm.form.Workplaces[${wpNumber}].Steps.length}">${vm.translateLabels('3546')}</label>
                    </div>
                  </div>   
                  <div class="col-12" ng-if="vm.form.Workplaces[${wpNumber}].Controls">
                    <div class="accordion md-accordion" id="accordionControls-${wpNumber}" role="tablist" aria-multiselectable="true">
                      <div class="card border-0 bg-transparent">
                        <div class="card-header px-3 pt-0 pb-2" role="tab" id="headingOne1">
                          <a class="collapsed" data-toggle="collapse" data-parent="#accordionControls-${wpNumber}" ng-click="vm.accordianToggle()" data-target="#collapseControls-${wpNumber}">
                            <h6 class="mb-0 text-primary">
            <!--Controls -->    ${vm.translateLabels('2478')} <i class="fas fa-angle-down rotate-icon"></i>
                            </h6>
                          </a>
                        </div>
                        <div id="collapseControls-${wpNumber}" class="collapse" role="tabpanel" data-parent="#accordionControls-${wpNumber}">
                          <div class="card-body">
                            <span ng-repeat="item in vm.form.Workplaces[${wpNumber}].Controls">
                              <span Note="Step">${vm.translateLabels('2262')}: <a href="{{item.reportURL}}" target="_blank">{{ item.step }} </a></span></br>
            <!--Control Measures-->    ${vm.translateLabels('2109')}: <span ng-repeat="control in item.controls track by $index">
                                  {{ control }}, 
                                 </span></br>
            <!--Additional Controls--> ${vm.translateLabels('2116')}: <span ng-repeat="addition in item.additional_controls track by $index">
                                 {{ addition }},
                             </span></br></br>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>                                 
                </div>
              </div>

              <div id="collapse${wpNumber}" class="collapse show" aria-labelledby="heading${wpNumber}" data-parent="#workplaceAccordion">
                <div class="card-body">
                  <div class="Workers0">
                    <div class="row">
                      <div class="col-4">
                        <div class="md-form">
                          <select class="select-single" id="WorkerName0${wpNumber}" name="WorkerName0${wpNumber}" ng-model="vm.form.Workplaces[${wpNumber}].Workers[0].WorkerName" ng-options="emp.per_id as emp.per_full_name for emp in vm.employees_visibility" required>
                            <option value=""></option>
                          </select>
                          <label for="WorkerName0${wpNumber}"  ng-class="{filled:vm.form.Workplaces[${wpNumber}].Workers[0].WorkerName,active:vm.form.Workplaces[${wpNumber}].Workers[0].WorkerName}" note="Worker Name">${vm.translateLabels('1208')}</label>
                        </div>
                      </div>
                      <div class="col-4">
                        <div class="md-form">
                          <select class="select-single" name="WorkerAlone0" ng-model="vm.form.Workplaces[${wpNumber}].Workers[0].WorkerAlone" ng-options="alone.id as alone.label for alone in vm.workAlone" required>
                            <option value=""></option>
                          </select>
                          <label for="WorkerAlone0" ng-class="vm.form.Workplaces[${wpNumber}].Workers[0].WorkerAlone >= 0 ? 'filled active' : ''" note="Working Alone?">${vm.translateLabels('1209')}</label>
                        </div>
                      </div>
                      <div class="col-4 pt-4">
                        <button type="button" class="btn btn-flat p-2 float-right  mx-0" note="Delete Worker" title="${vm.translateLabels('3548')}" ng-click="vm.deleteEntryModal('Worker',${wpNumber},0,${vm.form.Workplaces[wpNumber].Workers[0].WorkerID})">
                          <i class="far fa-trash-alt fa-lg"></i>
                        </button>
                      </div>
                      <div class="col-12">
                          <div class="md-form">
                            <select class="select-multiple" multiple name="PPE0${wpNumber}" id="PPE0${wpNumber}" nid="PPE0${wpNumber}" ng-model="vm.form.Workplaces[${wpNumber}].Workers[0].ppe" ng-options="ppe.rld_id as ppe.rld_name for ppe in vm.ppe">
                              <option value=""></option>
                            </select>
                            <label for="PPE0${wpNumber}" ng-class="{filled:vm.form.Workplaces[${wpNumber}].Workers[0].ppe.length,active:vm.form.Workplaces[${wpNumber}].Workers[0].ppe.length}" note="Special PPE">${vm.translateLabels('834')}</label>
                          </div>
                        </div>
                    </div>
                    <div class="equipment0"></div>
                    <div class="btn btn-flat px-0 font-weight-bolder text-primary" id="addEquipment" ng-click="vm.addEquipment(${wpNumber}, 0)"><i class="fa fa-plus"></i><span note="Add Equipment">  ${vm.translateLabels('1234')}</span></div>
                  </div>
                  </div>
                    <div class="card-footer">
                      <div class="row">
                        <div class="col-12">
                          <div class="btn btn-flat px-0 font-weight-bolder text-primary" id="addWorker" ng-click="vm.addWorker(${wpNumber})"><i class="fa fa-plus"></i><span note="Add Worker">  ${vm.translateLabels('1210')}</span> </div>
                        </div>
                      </div> 
                   </div>
                </div>
             </div>`
          $("#workplaceAccordion").append($compile(wpLayout)($scope))
          vm.initializeSelect2('lineupForm')
      }

      vm.removeWorkplace = (workPlaceNumber) => {
        if (vm.form.Workplaces.length > 0) {
          let tempform = JSON.parse(JSON.stringify(vm.form))
          let newWorkplaces = vm.form.Workplaces.filter((item, key) => {
            return key != workPlaceNumber
          })
          let myworkPlaces = JSON.parse(JSON.stringify(newWorkplaces))
          tempform.Workplaces = myworkPlaces
          vm.form = tempform
          setTimeout(() => {
            vm.resetWorkplace(myworkPlaces)
            vm.form = tempform
            $scope.$apply();
          }, 100);
        } else {
          toastr.error(`${vm.translateLabels('3567')}`)  // "You cannot remove the last Workplace"
        }
      }

      vm.getWorkPlaces = (number) => {
        let wp = vm.form.Workplaces[number].WorkplaceLevel
        return wp.split("|")
      }

      vm.isWorkplaceLevelFilled = (number) => {
        try{
          if(vm.form.Workplaces.length > 0){
            if(vm.form.Workplaces[number].WorkplaceLevels!=null){
              if(vm.form.Workplaces[number].WorkplaceLevels.length > 0 ){
                if(vm.form.Workplaces[number].WorkplaceLevels[0]) {
                  return true
                } else {
                  return false
                }
              } else {
                return false
              }
            } else {
              return false
            }
          } else {
            return false
          }
        } catch(err){
          return false
        }

      }

      vm.resetWorkplace = (newWorkplaces) => {
        $("#workplaceAccordion").html('')
        newWorkplaces.forEach((data, wpNumber) => {
          $("#workplaceAccordion").append($compile(`
            <div class="card mb-4">
              <div class="card-header pt-0" id="heading${wpNumber}">
                <div class="row">
                  <div class="col-6">
                    <div class="md-form">
                      <select class="select-multiple" multiple name="WorkplaceLevel${wpNumber}" id="WorkplaceLevel${wpNumber}" ng-model="vm.form.Workplaces[${wpNumber}].WorkplaceLevels" ng-options="level.level as level.lable for level in vm.levels" ng-change="vm.getLevelHazards(vm.form.lineup.Site,vm.form.Workplaces[${wpNumber}].WorkplaceLevels,${wpNumber})" required>
                        <option value=""></option>
                      </select>
                      <label for="WorkplaceLevel${wpNumber}" ng-class="{filled:vm.isWorkplaceLevelFilled(${wpNumber}),active:vm.isWorkplaceLevelFilled(${wpNumber})}" note="Area/Level">${vm.translateLabels('621')}</label>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="md-form">
                      <input html-decode type="text" id="workplaceName${wpNumber}" name="workplaceName${wpNumber}" class="form-control" ng-model="vm.form.Workplaces[${wpNumber}].WorkplaceName" required>
                      <label for="workplaceName${wpNumber}" ng-class="{filled:vm.form.Workplaces[${wpNumber}].WorkplaceName,active:vm.form.Workplaces[${wpNumber}].WorkplaceName}" note="Workplace">${vm.translateLabels('959')}</label>
                    </div>
                  </div>
                  <div class="col-2 pt-4">
                    <button type="button" class="btn btn-flat p-2 float-right mx-0" ng-click="vm.accordianToggle()" data-toggle="collapse" data-target="#collapse${wpNumber}" >
                      <i class="fas fa-chevron-up fa-lg"></i>
                    </button>
                    <button type="button" class="btn btn-flat p-2 float-right mx-0" note="Delete Workplace" title="${vm.translateLabels('3506')}" ng-click="vm.deleteEntryModal('Workplace',${wpNumber},${vm.form.Workplaces[wpNumber].WorkplaceID})">
                      <i class="far fa-trash-alt fa-lg mx-0"></i>
                    </button>
                  </div>
                  <div class="col-12">
                    <div class="md-form mt-0">
                      <textarea html-decode name="WorkplaceLineup${wpNumber}" id="WorkplaceLineup${wpNumber}" class="form-control md-textarea" ng-model="vm.form.Workplaces[${wpNumber}].WorkplaceLineup" length="300" maxlength="4000" required></textarea>
                      <label for="WorkplaceLineup${wpNumber}" ng-class="{filled:vm.form.Workplaces[${wpNumber}].WorkplaceLineup,active:vm.form.Workplaces[${wpNumber}].WorkplaceLineup}" note="Lineup Details">${vm.translateLabels('1972')}</label>
                    </div>
                  </div>
                  <div class="col-12" ng-if="vm.form.Workplaces[${wpNumber}].Hazards">
                  <div class="accordion md-accordion" id="accordionHazards-${wpNumber}" role="tablist" aria-multiselectable="true">
                    <div class="card border-0 bg-transparent">
                      <div class="card-header px-3 pt-0 pb-2" role="tab" id="headingOne1">
                        <a class="collapsed" data-toggle="collapse" data-parent="#accordionHazards-${wpNumber}" ng-click="vm.accordianToggle()" data-target="#collapseHazards-${wpNumber}">
                          <h6 class="mb-0 text-danger"  note="Open hazards at these levels">
                          ${vm.translateLabels('3509')} ({{vm.form.Workplaces[${wpNumber}].Hazards.length}})<i class="fas fa-angle-down rotate-icon"></i>
                          </h6>
                        </a>
                      </div>
                      <div id="collapseHazards-${wpNumber}" class="collapse" role="tabpanel" data-parent="#accordionHazards-${wpNumber}">
                        <div class="card-body">
                          <span ng-repeat="item in vm.form.Workplaces[${wpNumber}].HazardsList ">
                            <h6 class="mt-3"><strong note="Area/Level">${vm.translateLabels('621')}: {{item}}</strong> </h6>
                            <span ng-repeat="hazarditem in vm.form.Workplaces[${wpNumber}].Hazards | filter:item"> 
                              <span note="Workplace">${vm.translateLabels('959')}: <a href="{{hazarditem.reportURL}}" target="_blank">{{hazarditem.submissionheaderid__workplace}}</a></span><p note="Hazard">${vm.translateLabels('1320')}: {{hazarditem.hazard_description}}</p></span>
                            </span>
                          </span> 
                        </div>
                      </div>
                      </div>
                    </div>
                  </div>

              <div class="col-12">
                <div class="md-form">
                  <select class="select-single" name="WorkplaceLJRA${wpNumber}" ng-model="vm.form.Workplaces[${wpNumber}].WorkplaceJRA" ng-options="jra.rmm_jra_id as jra.rmm_jra_title for jra in vm.jraList" ng-change="vm.getJraSteps(vm.form.Workplaces[${wpNumber}])">
                    <option value=""></option>
                  </select>
                  <label for="WorkplaceLJRA${wpNumber}" ng-class="{filled:vm.form.Workplaces[${wpNumber}].WorkplaceJRA,active:vm.form.Workplaces[${wpNumber}].WorkplaceJRA}">${vm.translateLabels('3510')}</label>
                </div>
              </div>
              <div class="col-12">
                <div class="md-form">
                  <select class="select-multiple" multiple name="WorkplaceLJRAStep${wpNumber}" id="WorkplaceLJRAStep${wpNumber}" ng-model="vm.form.Workplaces[${wpNumber}].Steps" ng-options="step.rmm_jsc_id as step.rmm_jsc_step for step in vm.form.Workplaces[${wpNumber}].StepList" ng-change="vm.showJraStepData(vm.form.Workplaces[${wpNumber}])">
                    <option value=""></option>
                  </select>
                  <label for="WorkplaceLJRAStep${wpNumber}" ng-class="{filled:vm.form.Workplaces[${wpNumber}].Steps.length,active:vm.form.Workplaces[${wpNumber}].Steps.length}">${vm.translateLabels('3546')}</label>
                </div>
              </div> 
              <div class="col-12" ng-if="vm.form.Workplaces[${wpNumber}].Controls">
              <div class="accordion md-accordion" id="accordionControls-${wpNumber}" role="tablist" aria-multiselectable="true">
                <div class="card border-0 bg-transparent">
                  <div class="card-header px-3 pt-0 pb-2" role="tab" id="headingOne1">
                    <a class="collapsed" data-toggle="collapse" data-parent="#accordionControls-${wpNumber}" ng-click="vm.accordianToggle()" data-target="#collapseControls-${wpNumber}">
                      <h6 class="mb-0 text-primary">
                        Controls <i class="fas fa-angle-down rotate-icon"></i>
                      </h6>
                    </a>
                  </div>
                <div id="collapseControls-${wpNumber}" class="collapse" role="tabpanel" data-parent="#accordionControls-${wpNumber}">
                  <div class="card-body">
                    <span ng-repeat="item in vm.form.Workplaces[${wpNumber}].Controls">
                      <span note="Step">${vm.translateLabels('2262')}: <a href="{{item.reportURL}}" target="_blank">{{ item.step }} </a></span></br>
  <!--Control Measures-->    ${vm.translateLabels('2109')}: <span ng-repeat="control in item.controls track by $index">
                          {{ control }}, 
                         </span></br>
  <!--Additional Controls--> ${vm.translateLabels('2116')}: <span ng-repeat="addition in item.additional_controls track by $index">
                         {{ addition }},
                     </span></br></br>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </div>
          </div>
              <div id="collapse${wpNumber}" class="collapse show" aria-labelledby="heading${wpNumber}" data-parent="#workplaceAccordion">
                  <div class="card-body"></div>
                  <div class="card-footer">
                    <div class="row">
                      <div class="col-12">
                        <div class="btn btn-flat px-0 font-weight-bolder text-primary" id="addWorker" ng-click="vm.addWorker(${wpNumber})"><i class="fa fa-plus"></i><span note="Add Worker">  ${vm.translateLabels('1210')}</span> </div>
                      </div>
                    </div>
                  </div>
              </div>
            </div>`)($scope))
          vm.initializeSelect2('lineupForm')
          vm.resetWorkers(wpNumber, data.Workers)
        })
      }

      vm.addWorker = (workplaceNumber) => {
        vm.showSubmit = true
        let workerNumber = vm.form.Workplaces[workplaceNumber].Workers.length
        let dataPath = `vm.form.Workplaces[${workplaceNumber}].Workers[${workerNumber}]`
        vm.form.Workplaces[workplaceNumber].Workers[workerNumber] = {
          WorkerID: null,
          WorkerName: null,
          WorkerAlone: 0 ,
          equipment: [],
          ppe: []
        }
        $(`#collapse${workplaceNumber} .card-body`).append($compile(`
           <div class="Workers${workerNumber}">
             <div class="row">
                <div class="col-4">
                  <div class="md-form">
                    <select class="select-single" id="WorkerName${workplaceNumber}${workerNumber}" name="WorkerName${workplaceNumber}${workerNumber}" workerValue = "{{${dataPath}.WorkerName}}" ng-model="${dataPath}.WorkerName" ng-options="emp.per_id as emp.per_full_name for emp in vm.employees_visibility" required>
                      <option value=""></option>
                    </select>
                    <label for="WorkerName${workplaceNumber}${workerNumber}" ng-class="{filled:${dataPath}.WorkerName,active:${dataPath}.WorkerName}" note="Worker Name">${vm.translateLabels('1208')}</label>
                  </div>
                </div>
                <div class="col-4">
                  <div class="md-form">
                    <select class="select-single" id="WorkerAlone${workplaceNumber}${workerNumber}" name="WorkerAlone${workplaceNumber}${workerNumber}" ng-model="${dataPath}.WorkerAlone" ng-options="alone.id as alone.label for alone in vm.workAlone" required>
                      <option value=""></option>
                    </select>
                    <label for="WorkerAlone${workplaceNumber}${workerNumber}" ng-class="${dataPath}.WorkerAlone >= 0 ? 'filled active' : ''" note="Working Alone?">${vm.translateLabels('1209')}</label>
                  </div>
                </div>
                <div class="col-4 pt-4">
                  <button type="button" class="btn btn-flat p-2 float-right mx-0" note="Delete Worker" title="${vm.translateLabels('3548')}" ng-click="vm.deleteEntryModal('Worker',${workplaceNumber},${workerNumber},${vm.form.Workplaces[workplaceNumber].Workers[workerNumber].WorkerID})">
                    <i class="far fa-trash-alt fa-lg"></i>
                  </button>
                </div>
              <div class="col-12">
                  <div class="md-form">
                    <select class="select-multiple" multiple name="PPE${workplaceNumber}${workerNumber}"  id="PPE${workplaceNumber}${workerNumber}" ng-model="${dataPath}.ppe" ng-options="ppe.rld_id as ppe.rld_name for ppe in vm.ppe">
                      <option value=""></option>
                    </select>
                    <label for="PPE${workplaceNumber}${workerNumber}" ng-class="{filled:${dataPath}.ppe.length,active:${dataPath}.ppe.length}" note="Special PPE">${vm.translateLabels('834')}</label>
                  </div>
                </div>
             </div>
             <div class="equipment${workerNumber}"></div>
             <div class="btn btn-flat px-0 font-weight-bolder text-primary" id="addEquipment" ng-click="vm.addEquipment(${workplaceNumber}, ${workerNumber})"><i class="fa fa-plus"></i> <span note="Add Equipment">  ${vm.translateLabels('1234')}</span></div>
           </div>
         `)($scope))
        vm.initializeSelect2('lineupForm')
      }

      vm.removeWorker = (workplaceNumber, workerNumber) => {
          let tempform = JSON.parse(JSON.stringify(vm.form))
          let newWorkers = vm.form.Workplaces[workplaceNumber].Workers.filter(function (item, key) {
            return key != workerNumber
          })
          let myWorkers = JSON.parse(JSON.stringify(newWorkers))
          tempform.Workplaces[workplaceNumber].Workers = myWorkers
          vm.form = tempform
        setTimeout(() => {
            vm.form = tempform
            vm.resetWorkers(workplaceNumber)
            $scope.$apply()
            vm.initializeSelect2('lineupForm')
          }, 100)
      }

      vm.resetWorkers = (workplaceNumber) => {
        $(`#collapse${workplaceNumber} .card-body`).html('')
        vm.form.Workplaces[workplaceNumber].Workers.forEach((data, workerNumber) => {
          let dataPath = `vm.form.Workplaces[${workplaceNumber}].Workers[${workerNumber}]`
          $(`#collapse${workplaceNumber} .card-body`).append($compile(`
           <div class="Workers${workerNumber}">
             <div class="row">
                <div class="col-4">
                  <div class="md-form">
                    <select class="select-single" name="WorkerName${workplaceNumber}${workerNumber}" workerValue = "{{${dataPath}.WorkerName}}" ng-model="${dataPath}.WorkerName" ng-options="emp.per_id as emp.per_full_name for emp in vm.employees_visibility" required>
                      <option value=""></option>
                    </select>
                    <label for="WorkerName${workplaceNumber}${workerNumber}" ng-class="{filled:${dataPath}.WorkerName,active:${dataPath}.WorkerName}" note="Worker Name">${vm.translateLabels('1208')}</label>
                  </div>
                </div>
                <div class="col-4">
                  <div class="md-form">
                    <select class="select-single" name="WorkerAlone${workplaceNumber}${workerNumber}" ng-model="${dataPath}.WorkerAlone" ng-options="alone.id as alone.label for alone in vm.workAlone" required>
                      <option value=""></option>
                    </select>
                    <label for="WorkerAlone${workplaceNumber}${workerNumber}" ng-class="${dataPath}.WorkerAlone >= 0 ? 'filled active' : ''" note="Working Alone?">${vm.translateLabels('1209')}</label>
                  </div>
                </div>
                <div class="col-4 pt-4">
                  <button type="button" class="btn btn-flat p-2 float-right mx-0" note="Delete Worker" title="${vm.translateLabels('3548')}" ng-click="vm.deleteEntryModal('Worker',${workplaceNumber},${workerNumber},${vm.form.Workplaces[workplaceNumber].Workers[workerNumber].WorkerID})">
                    <i class="far fa-trash-alt fa-lg"></i>
                  </button>
                </div>
                <div class="col-12">
                  <div class="md-form">
                    <select class="select-multiple" multiple name="PPE${workplaceNumber}${workerNumber}"  id="PPE${workplaceNumber}${workerNumber}" ng-model="${dataPath}.ppe" ng-options="ppe.rld_id as ppe.rld_name for ppe in vm.ppe">
                      <option value=""></option>
                    </select>
                    <label for="PPE${workplaceNumber}${workerNumber}" ng-class="{filled:${dataPath}.ppe.length,active:${dataPath}.ppe.length}" note="Special PPE">${vm.translateLabels('834')}</label>
                  </div>
                </div>
             </div>
             <div class="equipment${workerNumber}"></div>
             <div class="btn btn-flat px-0 font-weight-bolder text-primary" id="addEquipment" ng-click="vm.addEquipment(${workplaceNumber}, ${workerNumber})"><i class="fa fa-plus"></i> <span note="Add Equipment">  ${vm.translateLabels('1234')}</span></div>
           </div>
         `)($scope))
         vm.initializeSelect2('lineupForm')
          vm.resetEquipment(workplaceNumber, workerNumber, data.equipment)
        })
      }

      vm.addEquipment = (workplaceNumber, workerNumber) => {
        vm.showSubmit = true
        let machineNumber = vm.form.Workplaces[workplaceNumber].Workers[workerNumber].equipment.length
        vm.form.Workplaces[workplaceNumber].Workers[workerNumber].equipment[machineNumber] = {
          EquipmentID: null,  
          EquipmentNumber: '',
          EquipmentType: '',
          EquipmentLocation: '',
          EquipmentList: [],
          EquipmentObj : '',
        }

      let dataPath = `vm.form.Workplaces[${workplaceNumber}].Workers[${workerNumber}].equipment[${machineNumber}]`

      $(`#collapse${workplaceNumber} .Workers${workerNumber} .equipment${workerNumber}`).append($compile(`  
            <div class="row" id="machine_${workplaceNumber}_${workerNumber}_${machineNumber}">
                <div class="col-6">
                <div class="md-form  mb-0">
                  <select class="select-single" id="equipmentItem${workplaceNumber}${workerNumber}${machineNumber}" 
                    name="equipmentItem${workplaceNumber}${workerNumber}${machineNumber}" 
                    ng-model="${dataPath}.EquipmentFullValue" 
                    ng-options="equip.value as equip.label for equip in vm.equipment_main_list">
                  </select>

                 <label ng-if="!vm.form.lineup.JobNumber" for="equipmentItem${workplaceNumber}${workerNumber}${machineNumber}" ng-class="{filled:${dataPath}.EquipmentFullValue,active:${dataPath}.EquipmentFullValue}" note="Equipment">${vm.translateLabels('9559')}</label>
                 <label ng-if="vm.form.lineup.JobNumber" for="equipmentItem${workplaceNumber}${workerNumber}${machineNumber}" ng-class="{filled:${dataPath}.EquipmentFullValue,active:${dataPath}.EquipmentFullValue}" note="Equipment">${vm.translateLabels('428')}</label>
                 </div>
              </div>
              <div class="col-5">
                  <div class="md-form mb-0">
                    <input html-decode type="text" name="equipmentLocation${workplaceNumber}${workerNumber}${machineNumber}" id="equipmentLocation${workplaceNumber}${workerNumber}${machineNumber}" class="form-control" ng-model="${dataPath}.EquipmentLocation" required>
                    <label for="equipmentLocation${workplaceNumber}${workerNumber}${machineNumber}"  ng-class="vm.filled"note="Equipment Location">${vm.translateLabels('451')}</label>
                  </div>
               </div>
              <div class="col-1 pt-4 mx-0">
                  <button type="button" class="btn btn-flat p-2 float-right" note="Delete Equipment" title="${vm.translateLabels('3552')}" ng-click="vm.deleteEntryModal('Equipment',${workplaceNumber},${workerNumber},${machineNumber},${vm.form.Workplaces[workplaceNumber].Workers[workerNumber].equipment[machineNumber].EquipmentID})">
                    <i class="far fa-trash-alt fa-lg mx-0"></i>
                  </button>
               </div>
            </div>
              `)($scope))
            vm.initializeSelect2('lineupForm')
      }

      vm.removeEquipment = (workplaceNumber, workerNumber, machineNumber) => {
        let tempform = JSON.parse(JSON.stringify(vm.form))
        let newMachine = vm.form.Workplaces[workplaceNumber].Workers[workerNumber].equipment.filter(function (item, key) {
          return key != machineNumber
        })
        let myMachines = JSON.parse(JSON.stringify(newMachine))
        tempform.Workplaces[workplaceNumber].Workers[workerNumber].equipment = myMachines
        vm.form = tempform
        $(`#collapse${workplaceNumber} .Workers${workerNumber} .equipment${workerNumber}`).html('')
        setTimeout(() => {
          vm.form = tempform
          vm.resetEquipment(workplaceNumber, workerNumber, myMachines)
          $scope.$apply();
        }, 100);
      }

      vm.resetEquipment = (workplaceNumber, workerNumber, newMachines) => {

        newMachines.forEach((data, machineNumber) => {
          let dataPath = `vm.form.Workplaces[${workplaceNumber}].Workers[${workerNumber}].equipment[${machineNumber}]`

          $(`#collapse${workplaceNumber} .Workers${workerNumber} .equipment${workerNumber}`).append($compile(`  
            <div class="row" id="machine_${workplaceNumber}_${workerNumber}_${machineNumber}">
               <div class="col-6 mb-0">
                <div class="md-form">
                <select class="select-single" id="equipmentItem${workplaceNumber}${workerNumber}${machineNumber}" 
                  name="equipmentItem${workplaceNumber}${workerNumber}${machineNumber}" 
                  ng-model="${dataPath}.EquipmentFullValue" 
                  ng-options="equip.value as equip.label for equip in vm.equipment_main_list"></select>
                  <label ng-if="!vm.form.lineup.JobNumber" for="equipmentItem${workplaceNumber}${workerNumber}${machineNumber}" ng-class="{filled:${dataPath}.EquipmentFullValue,active:${dataPath}.EquipmentFullValue}" note="Equipment">${vm.translateLabels('9559')}</label>
                  <label ng-if="vm.form.lineup.JobNumber" for="equipmentItem${workplaceNumber}${workerNumber}${machineNumber}" ng-class="{filled:${dataPath}.EquipmentFullValue,active:${dataPath}.EquipmentFullValue}" note="Equipment">${vm.translateLabels('428')}</label>                </div>
              </div>
               <div class="col-5 mb-0">
                  <div class="md-form">
                    <input html-decode type="text" name="equipmentLocation${workplaceNumber}${workerNumber}${machineNumber}" id="equipmentLocation${workplaceNumber}${workerNumber}${machineNumber}" class="form-control" ng-model="${dataPath}.EquipmentLocation" required>
                    <label for="equipmentLocation${workplaceNumber}${workerNumber}${machineNumber}" ng-class="{filled:${dataPath}.EquipmentLocation,active:${dataPath}.EquipmentLocation}" note="Equipment Location">${vm.translateLabels('451')}</label>
                  </div>
               </div>
              <div class="col-1 pt-4">
                  <button type="button" class="btn btn-flat p-2 float-right mx-0" note="Delete Equipment" title="${vm.translateLabels('3552')}" ng-click="vm.deleteEntryModal('Equipment',${workplaceNumber},${workerNumber},${machineNumber},${vm.form.Workplaces[workplaceNumber].Workers[workerNumber].equipment[machineNumber].EquipmentID})">
                    <i class="far fa-trash-alt fa-lg"></i>
                  </button>
               </div>
            </div>
              `)($scope))
        })
        vm.initializeSelect2('lineupForm')
      }

      vm.clearEntry = (mode, workplaceNumber, workerNumber, machineNumber) => {
        switch (mode) {
          case 'machine': vm.form.Workplaces[workplaceNumber].Workers[workerNumber].equipment[machineNumber].equipmentNumber = ''
            vm.form.Workplaces[workplaceNumber].Workers[workerNumber].equipment[machineNumber].equipmentType = ''
            break
        }
        setTimeout(function () { $('.eType').trigger('change'); }, 100);
        modalService.Close('confirmModal');
      }

      vm.deleteEntryModal = (type, workplaceNumber, workerNumber, machineNumber) => {
        vm.showSubmit = true
        vm.disableSaveButton = true
        vm.type = type
        vm.workplaceNumber = workplaceNumber 
        vm.workerNumber = workerNumber
        vm.machineNumber = machineNumber

        vm.modalElementsDelete = {
          title: translateTag(2182), //"Warning"
          message: `<div><p>${translateTag(3555)} ${type}</p></div>`, //"Are you Sure you wish to remove this"
          buttons: 
              `<button class='btn btn-outline-primary btn-rounded' ng-click="vm.return('button1')" note="No">{{vm.componentTranslateLabels(1380)}}</button>
              <button class='btn btn-primary btn-rounded' ng-click="vm.return('button2')" note="Yes">{{vm.componentTranslateLabels(1379)}}</button>`
        }
        document.getElementById('confirmcallingform').innerHTML = 'LINEUPDELETECALLCONFIRMMODAL' 
        $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsDelete)
      }

      $scope.$on("LINEUPDELETECALLCONFIRMMODAL", (event,result) => {
        if (result=='button1') {
          vm.closeModal('confirmModal')
        }
        else if (result=='button2') {
          vm.deleteEntry(vm.type, vm.workplaceNumber, vm.workerNumber, vm.machineNumber)
        }
      })

      vm.deleteEntry = (type, workplaceNumber, workerNumber, machineNumber) => {
        switch (type) {
          case "Equipment":
            lineupService.removeEntry({
              id: vm.form.Workplaces[workplaceNumber].Workers[workerNumber].equipment[machineNumber].EquipmentID,
              type: type
            }).then((res) => {
              vm.removeEquipment(workplaceNumber, workerNumber, machineNumber)
              }).then((res) => {
                vm.saveLineup('autosave')
              })
            break
          case "Worker": 
            if (vm.form.Workplaces[workplaceNumber].Workers.length > 1) {
              lineupService.removeEntry({
                id: vm.form.Workplaces[workplaceNumber].Workers[workerNumber].WorkerID,
                type: type
              }).then((res) => {
                vm.removeWorker(workplaceNumber, workerNumber)
                }).then((res) => {
                  vm.saveLineup('autosave')
                })
            }
            else {
              toastr.error(`${vm.translateLabels('3568')}`) //You cannot remove the last Worker from the Workplace
            }
            break
          case "Workplace": 
            if (vm.form.Workplaces.length > 1) {
              lineupService.removeEntry({
                id: vm.form.Workplaces[workplaceNumber].WorkplaceID,
                type: type
              }).then((res) => {
                vm.removeWorkplace(workplaceNumber)
              }).then((res) => {
                vm.saveLineup('autosave')
              })
            }
            else {
              toastr.error(`${vm.translateLabels('3567')}`)  // "You cannot remove the last Workplace"
            }
            break
          default: break
        }
        modalService.Close('confirmModal')
        vm.showSubmit = false
        vm.disableSaveButton = false
      }

      vm.recoverLineup = () => {
        vm.headerValidation = false
        vm.resetWorkplace(vm.form.Workplaces)
        vm.initializeSelect2('lineupForm')
      }

      function prepareSave() {
        if(!vm.form.lineup.Shift)
          vm.form.lineup.Shift = null
        if(!vm.form.lineup.Crew)
          vm.form.lineup.Crew = null
        if(!vm.form.lineup.Supervisor)
          vm.form.lineup.Supervisor = null
        if(!vm.form.lineup.Site)
          vm.form.lineup.Site = null
        if(!vm.form.lineup.JobNumber)
          vm.form.lineup.JobNumber = null
      }

      vm.saveLineup = (mode = 'normal') => {
        resetFormFieldClassList('lineupForm')
        let validatedForm = validateFormFields('lineupForm', true)
        if(validatedForm){
          vm.disableSaveButton = true
          // 'savedirect' as mode passing on save button click, to bypass and set the spinner ON
          // and change the mode to 'autosave' to fix the issue

          angular.copy(vm.form, vm.submitFormObj)
          if(mode == 'savedirect'){
            $scope.$emit('STOPSPINNER')
            $scope.$emit('STARTSPINNER', this.translateLabels(3894))  //"Saving lineup. Please wait."
            mode='autosave'
          }

          if(mode !== 'autosave') {
            vm.showSubmit = true
            vm.showCancelModal = false
            $scope.$emit('STOPSPINNER')
            $scope.$emit('STARTSPINNER', this.translateLabels(3894)) //"Saving lineup. Please wait."
          }
          else {
            vm.showSubmit = true
            vm.showCancelModal = false
          }
            vm.form.lineup.ClientRep =  vm.form.lineup.ClientRep ?  vm.form.lineup.ClientRep:""
            vm.form.lineup.ContactInfo =  vm.form.lineup.ContactInfo ? vm.form.lineup.ContactInfo:""
            vm.form.lineup.SafetyTopic =  vm.form.lineup.SafetyTopic ? vm.form.lineup.SafetyTopic: ""
            vm.form.lineup.WorkplaceImpacts =  vm.form.lineup.WorkplaceImpacts ? vm.form.lineup.WorkplaceImpacts: ""
            vm.form.lineup.CommunicationNotes =  vm.form.lineup.CommunicationNotes ? vm.form.lineup.CommunicationNotes:""
            prepareSave()
            lineupService.upsertLineup(vm.form.lineup).then(function (response) {
              vm.form.lineup.ID = response.lineupId
              let payload = {
                "payload": vm.form.lineup.distribution,
                "lineupId": vm.form.lineup.ID
              }
              lineupService.upsertDistribution(payload).then((data)=>{
              }).catch((err)=>{
                console.log("Error Updating Distribution", err)
              })

              // Spool up the Workplace Data
              let wpArray = []
  
              // Save the Workplaces
              vm.form.Workplaces.forEach((wp) => {
                //pipe delimit the workplace level, multiple levels allowed.
                wp.WorkplaceLevel = wp.WorkplaceLevel ? wp.WorkplaceLevel : []
                let wplevels = wp.WorkplaceLevels ? wp.WorkplaceLevels.join('|') : ''

                wpArray.push({
                  LineupID: vm.form.lineup.ID,
                  WorkplaceID: wp.WorkplaceID,
                  WorkplaceName: wp.WorkplaceName ? wp.WorkplaceName : "",
                  WorkplaceJRA: wp.WorkplaceJRA?wp.WorkplaceJRA:null,
                  WorkplaceLevel: wplevels,
                  WorkplaceLineup: wp.WorkplaceLineup ? wp.WorkplaceLineup: ""
                })
              })
              if(mode !== 'autosave') {
              //  $scope.$emit("Upsert_Lineup", vm.form.lineup.ID)
              }
              // Save the Workers
              return wpArray
            }, (error) => {
            }).then((data) => {
              lineupService.upsertWorkplaces(data).then((response) => {
                let workArray = []
                let stepsArray = []
                response.ids.forEach((wp, index) => {
                  vm.form.Workplaces[index].WorkplaceID = wp
                })
                let wpCount = 0;
                vm.form.Workplaces.forEach((wp) => {
                  let wkIndex = 0
                  wp.Workers.forEach((work) => {
                    workArray.push({
                      LineupID: vm.form.lineup.ID,
                      WorkplaceID: wp.WorkplaceID,
                      WorkplaceIndex: wpCount,
                      WorkerID: work.WorkerID,
                      WorkerIndex: wkIndex,
                      WorkerName: work.WorkerName ? work.WorkerName : null,
                      WorkerAlone: !!work.WorkerAlone ? work.WorkerAlone : 0
                    })
                    wkIndex++
                  })

                  // Now lets Create the Payload for Steps
                  wp.Steps.forEach((step) => {
                    stepsArray.push({
                      rmm_jls_lineup_id: vm.form.lineup.ID,
                      rmm_jls_workplace_id: wp.WorkplaceID,
                      rmm_jls_step_id: step,
                    })
                  })
                  wpCount++
                })
                // Save the Equipment
              
                return  { workers: workArray, steps: stepsArray, lineup: vm.form.lineup.ID }
              }, (error) => {
              }).then((wpdata)=>{
                let payload = {
                  payload: wpdata.steps,
                  lineupId: wpdata.lineup
                }
                // Here is where we will upload the Staps
                lineupService.insertLineupJRASteps(payload).then((response) => {
              
                return(wpdata.workers)
                }, (error) => {
                  return(wpdata.workers)

              }).then((mydata) => {
                  lineupService.upsertWorkers(mydata).then((response) => {
                    if(response){
                      mydata.forEach((wdata, index) => {
                        vm.form.Workplaces[wdata.WorkplaceIndex].Workers[wdata.WorkerIndex].WorkerID = response.ids[index]
                      })
                    }
                    let equipArray = []
                    let ppeArray = []
                    let wpCount = 0;
                    vm.form.Workplaces.forEach((wp) => {
                      let wkIndex = 0
                      wp.Workers.forEach((work) => {
                        // Take care of the Equipment
                        let machIndex = 0
                        work.equipment.forEach((mach) => {
                          let equipNum=null
                          let equipType=null
                          if(mach.EquipmentFullValue){
                            let machineSplit =mach.EquipmentFullValue.split('|')
                            equipNum = machineSplit[0]
                            equipType = machineSplit[1]
                          }
                          equipArray.push({
                            LineupID: vm.form.lineup.ID,
                            WorkplaceID: wp.WorkplaceID,
                            WorkplaceIndex: wpCount,
                            WorkerID: work.WorkerID,
                            WorkerIndex: wkIndex,
                            EquipmentID: mach.EquipmentID,
                            EquipmentIndex: machIndex,
                            EquipmentLocation: mach.EquipmentLocation ? mach.EquipmentLocation: "",
                            EquipmentNumber: equipNum,
                            EquipmentType: equipType
                          })
                          machIndex++
                        })
                        wkIndex++
                      })
                      // End of Machines
                      // take care of the PPE
                      wkIndex = 0
                      wp.Workers.forEach((work) => {
                        work.ppe.forEach((ppeselect) => {
                          ppeArray.push({
                            WorkerID: work.WorkerID,
                            PPEID: ppeselect,
                            LineupID: vm.form.lineup.ID,
                            WorkplaceID: wp.WorkplaceID
                          })
                        })
                        wkIndex++
                      })
                      //end of PPE
                      wpCount++
                    })                   
                    return { equip: equipArray, ppe: ppeArray, lineup: vm.form.lineup.ID }
                  }).then((mdata) => {
                    lineupService.upsertEquipment(mdata.equip).then((response) => {
                      mdata.equip.forEach((data, index) => {
                        vm.form.Workplaces[data.WorkplaceIndex].Workers[data.WorkerIndex].equipment[data.EquipmentIndex].EquipmentID = response.ids[index]
                      })
                      return (mdata)
                    })
                      .then((mdata) => {                
                        lineupService.removePPE(vm.form.lineup.ID).then((response) => {
                          return mdata
                        }).then((mdata) => {
                          lineupService.insertPPE(mdata.ppe).then((response) => {
                            return (mdata)
                          }).then((res) => {
                            $scope.$emit('STOPSPINNER')
                          })
                        })
                      }).then(()=> {
                        if(mode==='lock')
                        { 
                            setTimeout(() => {
                            mode = 'normal'
                            modalService.Close('confirmModal')
                            $scope.$emit("Upsert_Lineup", vm.form.lineup.ID);
                            vm.closeViewer()
                          }, 1000);
                        }
                        else { 
                            if(mode !== 'autosave') {
                              setTimeout(() => {
                                vm.editLineup(vm.form.lineup.ID, mode, true)
                                if (mode === 'normal')
                                  vm.showSubmit = false
                              }, 1000)
                            }
                            else 
                            { 
                              // Initialize a new document as an edited document after autosave
                              if(vm.mode !== 'edit') {
                                vm.mode = 'edit'
                                vm.doclocklineuplockid = vm.form.lineup.ID
                                lineupStartup()
                              } 
                              vm.disableSaveButton = false
                              vm.showSubmit = false
                            }

                      } 
                    }) 
                  })
                })
              })
            })

            angular.copy(vm.form, vm.submitFormObj)
        }
        else{
          $rootScope.$broadcast("CALLCONFIRMMODAL")
        }
      }

      vm.editLineup = (id, mode = 'normal', saved = false) => {
        toastr.options.progressBar = true
        if(mode != 'autosave') {
          $scope.$emit('STARTSPINNER', vm.translateLabels('3560')) // Loading lineups. Please wait.
        }
      //  vm.resetForm()

        $q.all([
          lineupService.getLineup(id),
          lineupService.getLineupDistribution(id),
          lineupService.getWorkplaces(id),
          lineupService.getWorkers(id),
          lineupService.getMachines(id),
          lineupService.getPPEData(id),
          lineupService.getLineupJRAWorkplaceSteps(id),
        ]).then(() => {
          vm.form.lineup = lineupService.readLineup()[0]
          vm.form.lineup.Site = parseInt(vm.form.lineup.Site)
          vm.form.lineup.Shift = vm.form.lineup.Shift ? parseInt(vm.form.lineup.Shift) : null
          vm.form.lineup.distribution = lineupService.readLineupDistribution()
          vm.form.lineup.LineupDate ? vm.form.lineup.LineupDate = vm.form.lineup.LineupDate.substring(0, 10) : vm.form.lineup.LineupDate
          vm.form.Workplaces = lineupService.readWorkplaces()
          vm.getJobsLevels
          lineupService.readWorkplaces().forEach((workp, indexwp) => {
            workp.Steps = []
            workp.WorkplaceLevels = workp.WorkplaceLevel.split("|")
            lineupService.readlineupJRAWorkplaceSteps().forEach((step)=> {
              if(workp.WorkplaceID === step.rmm_jls_workplace_id) {
                workp.Steps.push(step.rmm_jls_step_id)
              }
            })
            vm.form.Workplaces[indexwp].Workers = []
            let w = 0
            lineupService.readWorkers().forEach((worker, indexw) => {
              if (worker.WorkplaceID === workp.WorkplaceID) {
                vm.form.Workplaces[indexwp].Workers.push(worker)
                vm.form.Workplaces[indexwp].Workers[w].equipment = []
                vm.form.Workplaces[indexwp].Workers[w].ppe = []
                let m = 0
                lineupService.readMachines().forEach((mach, indexm) => {
                  if (mach.WorkerID === worker.WorkerID) {
                    mach.EquipmentFullValue = `${mach.EquipmentNumber}|${mach.EquipmentType}`
                    vm.form.Workplaces[indexwp].Workers[w].equipment.push(mach)
                    m++
                  }
                })
                lineupService.readPPE().forEach((ppedata, indexppe) => {
                  if (ppedata.WorkerID === worker.WorkerID) {
                    vm.form.Workplaces[indexwp].Workers[w].ppe.push(ppedata.PPEID)
                  }
                })
                w++
              }
            })
          })
        }).then(() => {
          localStorage.setItem('LineupRecovery', JSON.stringify(vm.form))
          vm.headerValidation = false
          if (mode != 'autosave' && !saved){
            vm.resetWorkplace(vm.form.Workplaces)
          }
          }).then(() => {
            vm.form.Workplaces.forEach((data, index) => {
            if(data.WorkplaceLevel.length > 0){
              data.WorkplaceLevels.map((rec)=>{
                rec=rec.toString()
              })
              let req = {
                  site_name: vm.form.lineup.Site.toString(), site_level: data.WorkplaceLevels 
              }
               lineupService.getHazards(req).then(() => {
                let lang_number = localStorage.getItem('lang_id')
                data.Hazards = lineupService.readHazards()
                formatHazards(data.Hazards)
                data.HazardsList = formatHazards(data.Hazards)
                if (data.Hazards.length > 0) {
                  data.Hazards.forEach((haz)=>{
                    haz.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${haz.report_url}/${haz.submissionheaderid}?lang=${lang_number}&t=${vm.token}`)
                  })
                  localStorage.setItem('LineupRecovery', JSON.stringify(vm.form))
                }
              })
            }
            
            })
          }).then((res) => {
            if (mode === 'normal'){
              vm.showSubmit = false
              vm.disableSaveButton = false
              vm.showCancelModal = true
              vm.validateSiteExists()
              if(vm.sites.length) {
                $scope.$emit('STOPSPINNER')
              }

            }
            if(saved)
              $scope.$emit('JOBSREADY')
          
            })
      }

      function formatHazards(data) {
        let allHazards = []
        data.forEach((haz)=>{
          if(!allHazards.includes(haz.LevelName))
            allHazards.push(haz.LevelName)
        })
        return allHazards
      }

      vm.submitLineup = () => {
        $scope.$emit('STARTSPINNER',"") 
        vm.closeModal('confirmModal')
        vm.disableYesButton = true
        try{
          vm.formSubmission = {
            formDescriptionId: 1084,
            submissionId: vm.generateSubmissionID().toUpperCase(),
            formCreationDate: vm.submitFormObj.lineup.LineupDate,
            site: vm.submitFormObj.lineup.Site,
            jobNumber: vm.submitFormObj.lineup.JobNumber,
            level: vm.submitFormObj.Workplaces[0].WorkplaceLevels[0],
            workplace: vm.submitFormObj.Workplaces[0].WorkplaceName,
            supervisor: vm.submitFormObj.lineup.Supervisor,
            supervisorId: vm.employeeProfile.SupervisorId,
            isArchived: false,
            syncDate: vm.getToday(),
            headerDate: vm.getToday(),
            submissionDate: vm.getToday(),
            duration: 0,
            reportSent: false
          }
          lineupService.submitLineupFormHeader(vm.formSubmission).then((res) => {
            return (res.data.ID)
          }).then((headResult) => {
            lineupService.submitLineupFormDetail(headResult).then((res) => {
              return ({ head: headResult, detail: res.data.Payload.id })
            }).then((subid) => {
              let subData = {
                SubmittedBy: vm.submitFormObj.lineup.LoggedIn,
                SubmissionHeaderID: subid.head,
                LineupID: vm.submitFormObj.lineup.ID
              }
              lineupService.submitLineupForm(subData).then((res) => {
                return subid
              }).then((res) => {
                // Area that will send the Data to create the Document for Review
                resetReview()
                vm.reviewData.reviewers = vm.collectEmployeeEmail()
                // Setup DRM Description              
                let siteName = vm.sites.filter(site => {
                  return site.rld_id === vm.submitFormObj.lineup.Site
                })[0].rld_name
                vm.reviewData.drm_description = `${siteName} - ${vm.submitFormObj.lineup.LineupDate}`
                vm.reviewData.id = vm.submitFormObj.lineup.ID
                lineupService.submitReviewDocument(vm.reviewData).then((res) => {
                      return subid
                    }).then((res) => {
                      if(vm.submitFormObj.lineup.distribution.length > 0) {
                        let payload= {
                          "lineupId" : res.head,
                          "distribution": vm.submitFormObj.lineup.distribution
                        }

                        lineupService.emailLineupDistribution(payload).then((res) => {
                        })
                      }
                $scope.$emit("Upsert_Lineup", vm.submitFormObj.lineup.ID)
                vm.closeViewer()
              })
            })
            })
          })
        }catch(err){
        }

      }

      vm.closeConfirmModal = () => {
       // vm.disableNoButton = true
        vm.showSubmit = false
        vm.disableSaveButton = false
        vm.closeModal('confirmModal')
      }

      // this will display the modal when submitting and will determine if the form is Valid or not then allow the submission
      vm.submitModal = () => {
        let output = ''
        vm.showSubmit = true
        vm.disableSaveButton = true

        let savePromise = new Promise(function (resolve, reject) {
          $interval.cancel(vm.autosave) // cancel the interval
          vm.saveLineup('autosave')
          resolve("Success")
        })
        $scope.$emit('STARTSPINNER', this.translateLabels(3894))  //"Saving lineup. Please wait."
        savePromise.then((res) => {
          resetFormFieldClassList('lineupForm')
          if (vm.ValidateLineup()) {
            vm.modalElementsSubmit = {
              title: translateTag(2182), //"Warning"
              message: `<div><p>${translateTag(3564)} ${translateTag(3565)} ${translateTag(3566)}</p></div>`, //"Are you sure you want to submit the Lineup? No changes will be permitted after it is submitted. A document will be created for all workers to review."
              buttons: 
                  `<button class='btn btn-outline-primary btn-rounded' ng-click="vm.return('button1')" note="No">{{vm.componentTranslateLabels(1380)}}</button>
                  <button class='btn btn-primary btn-rounded' ng-click="vm.return('button2')" note="Yes">{{vm.componentTranslateLabels(1379)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'LINEUPSUBMITCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsSubmit)
          }
          else {
            document.getElementById('confirmcallingform').innerHTML = 'LINEUPSUBMITCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL")
          }
        })
      }

      $rootScope.$on("LINEUPSUBMITCALLCONFIRMMODAL", (event,result) => {
        if (result=='button1') {
          vm.closeConfirmModal()
        }
        else if (result=='button2') {
          if(!vm.submitFlag){
            vm.disableNoButton = true
            vm.disableYesButton = true
            vm.submitFlag = true
            vm.submitLineup()            
          }
        }
      })      

      // Validate the Current Lineup Form
      vm.ValidateLineup = () => {
         return validateFormFields('lineupForm')
      }

      // This will glean all of the people in the lineup and prepare an email list to add to the explode table
      vm.collectEmployeeEmail = () => {
        vm.form.Workplaces.forEach((wpdata, index) => {
          wpdata.Workers.forEach((wdata, index) => {
           if (!vm.emailList.find((n) => n == wdata.WorkerName )) {
            vm.emailList.push(wdata.WorkerName)
           }
          })
        })
      // Remove Supervisor from Review List as Per Gus SOF-7586
        // if (!vm.emailList.find((n) => n == vm.form.lineup.Supervisor)) {
        //   vm.emailList.push(parseInt(vm.form.lineup.Supervisor))
        // }
        return vm.emailList
      }

      // End of Component
    }
  ]
});