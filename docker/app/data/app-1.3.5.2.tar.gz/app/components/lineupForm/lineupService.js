﻿angular
  .module('safeToDo')
  .service('lineupService', ['$http', '$q',
    function ($http, $q) {
      let sites = []
      let fullJobs = []
      let fullLevels = []
      let allData = []
      let employees = []
      let employeeList = []
      let employeeVisibilityList = []
      let supervisorVisibilityList = []
      let PPETypeList = []
      let lineupJRAWorkplaceSteps = []
      let editLineupData = []
      let lineupData = []
      let lineupJRAListData = []
      let lineupJRAStepData = []
      let lineupDistribution = []
      let editWorkplaceData = []
      let editWorkersData = []
      let editMachineData = []
      let editPPEData = []
      let crewTypeList = []
      let hazards = []
      let shiftList = []

      translateLabels = (key) =>{
        return translateTag(key)
      }

      return {
         // Service that will take the lineup data and either insert or update the Lineup Data
        upsertLineup: (data) => {
          return $http.post(`${__env.apiUrl}/api/lineup/add-and-update-lineup-by-lineup-id/`, data).then((response) => {
              return response.data
            }, (errorParams) => {
              console.log('Failed to create Lineup Record', errorParams)
            //  toastr.error(errorParams.data.error)
              return errorParams.data.error
            })
        },
        upsertDistribution: (data) => {
          return $http.post(`${__env.apiUrl}/api/lineup/insert-distribution/`, data).then((response) => {
              return response.data
            }, (errorParams) => {
              console.log('Failed to create Lineup Record', errorParams)
            //  toastr.error(errorParams.data.error)
              return errorParams.data.error
            })
        },
        getLineupDistribution: (data) => {
          return $http.post(`${__env.apiUrl}/api/lineup/get-lineup-distribution/`, data).then((response) => {
              lineupDistribution = response.data
            }, (errorParams) => {
              console.log('Failed to create Lineup Record', errorParams)
            //  toastr.error(errorParams.data.error)
              return errorParams.data.error
            })
        },
        emailLineupDistribution: (data) => {
          return $http.post(`${__env.apiUrl}/api/lineup/email-lineup-distribution/`, data).then((response) => {
              return response.data
            }, (errorParams) => {
              console.log('Failed to Email Lineup Record', errorParams)
             // toastr.error(errorParams.data.error)
              return errorParams.data.error
            })
        },
        // Service that will take all workeplace data and either insert or update the Workplaces 
        upsertWorkplaces: (data) =>{
          return $http.post(`${__env.apiUrl}/api/lineup/add-and-update-workplace-by-lineup-id/`, data).then((response) =>{
              return response.data
            }, (errorParams) => {
              console.log('Failed to create Lineup Record', errorParams)
           //   toastr.error(errorParams.data.error)
              return errorParams.data.error
            })
        },
        // Service that will take all workers data and either insert or update the workers
        upsertWorkers: (data) =>{
          return $http.post(`${__env.apiUrl}/api/lineup/add-and-update-workers-by-lineup-id/`, data).then((response) => {
              return response.data
            }, (errorParams) => {
              console.log('Failed to create worker Records', errorParams)
            //  toastr.error(errorParams.data.error)
             // return errorParams.data.error
            });
        },
        // Service that will take all equionent data and either insert or update the equipment
        upsertEquipment: (data) =>{
          return $http.post(`${__env.apiUrl}/api/lineup/add-and-update-equipment-by-lineup-id/`, data).then((response) => {
              return response.data
            }, (errorParams) =>{
              console.log('Failed to create Equipment Records', errorParams)
          //    toastr.error(errorParams.data.error)
              return errorParams.data.error
            });
        },
        // Remove all PPE from a given Lineup
        removePPE: (data) => {
          return $http.post(`${__env.apiUrl}/api/lineup/remove-lineup-ppe-by-lineup_id/`, data).then((response) => {
            return response.data;
          }, (errorParams) => {
            console.log('Failed to remove PPE Records', errorParams);
        //    toastr.error(errorParams.data.error);
            return errorParams.data.error;
          });
        },
        // Add PPE Equipment to a lineup
        insertPPE: (data) => {
          return $http.post(`${__env.apiUrl}/api/lineup/insert-lineup-ppe-by-lineup_id/`, data).then((response) => {
            return response.data;
          }, (errorParams) => {
            console.log('Failed to create PPE Records', errorParams);
        //    toastr.error(errorParams.data.error);
            return errorParams.data.error;
          });
        },
        // Retrieve all of the PPE for a Lineup
        getPPEData: (id) => {
          return $http.post(`${__env.apiUrl}/api/lineup/get-lineup-ppe-by-id/`,{id:id}).then((response) => {
            editPPEData = response.data;
          }, (errorParams) => {
            console.log('Failed to retrieve PPE Records', errorParams);
        //    toastr.error(errorParams.data.error);
            return errorParams.data.error;
          });
        },
        //retreive the JRA list based on a JOB ID from the REF List
        getLineupJRAList: (id) => {
          return $http.post(`${__env.apiUrl}/api/lineup/get-lineup-jra-list/`,{rmm_jra_job:id}).then((response) => {
            lineupJRAListData = response.data;
          }, (errorParams) => {
            console.log('Failed to retrieve PPE Records', errorParams);
          //  toastr.error(errorParams.data.error);
            return errorParams.data.error;
          });
        },
        // Retrieve all of the Steps for a particular workplace based on lineup
        getLineupJRAWorkplaceSteps: (id) => {
          return $http.post(`${__env.apiUrl}/api/lineup/get-lineup-jra-workplace-steps/`,{rmm_jls_lineup_id:id}).then((response) => {
            lineupJRAWorkplaceSteps = response.data;
          }, (errorParams) => {
            console.log('Failed to retrieve PPE Records', errorParams);
          //  toastr.error(errorParams.data.error);
            return errorParams.data.error;
          });
        },

        insertLineupJRASteps: (payload) => {
          return $http.post(`${__env.apiUrl}/api/lineup/insert-lineup-jra-steps/`,payload).then((response) => {
            return response.data;
          }, (errorParams) => {
            console.log('Failed to insert Lineup Steps', errorParams);
         //   toastr.error(errorParams.data.error);
            return errorParams.data.error;
          });
        },

        getLineupJRAStepList: (id) => {
          return $http.post(`${__env.apiUrl}/api/lineup/get-lineup-jra-steps/`,{rmm_jra_id:id}).then((response) => {
            lineupJRAStepData = response.data;
          }, (errorParams) => {
            console.log('Failed to retrieve PPE Records', errorParams);
         //   toastr.error(errorParams.data.error);
            return errorParams.data.error;
          });
        },
        
        // Submit the lineup form by adding an entry in the Submission Header Table.
        submitLineupFormHeader: (formdata) => {
          return $http.post(`${__env.apiUrl}/api/lineup/submit-lineup-header/`, formdata).then((response) => {
            return response
          }, (args) => {
         //   console.log('Failed to Submit Lineup.', args);
          })
        },
        // Add the entry into the Submission Details table
        submitLineupFormDetail: (id) => {
          return $http.post(`${__env.apiUrl}/api/lineup/submit-lineup-detail/`, {"id": id}).then((response) => {
            return response
          }, (args) => {
        //    console.log('Failed to Submit Lineup Detail.', args);
          })
        },
        // Make the Update to the LineupFormHeader table with SubmissionHeaderID and Submitted by and Date
        submitLineupForm: (data) => {
          return $http.post(`${__env.apiUrl}/api/lineup/update-submit-line-up/`, data).then((response) => {
            return response
          }, (args) => {
            console.log('Failed to Submit Lineup.', args);
          })
        },
        
        // service to send the Lineup EMails
        submitReviewDocument: (payload) => {
          return $http.post(`${__env.apiUrl}/api/lineup/line-up-pdf/`, payload).then((response) => {
            return response
          }, (args) => {
            console.log('Failed to Create DRM Document.', args);
          })
        },
        // Service that will remove entries from the lineup
        removeEntry: (data) => {
          return $http.post(`${__env.apiUrl}/api/lineup/remove-line-up-entry/`, data).then((response) => {
            toastr.success(translateLabels(3820)) // Entry removed
          return response.data
          }, (errorParams) => {
            console.log('Failed to remove Entry', errorParams)
      //      toastr.error(errorParams.data.error)
            return errorParams.data.error
          })
        },
        // Service to remove the selected lineup
        removeLineup: (data) =>{
          return $http.post(`${__env.apiUrl}/api/lineup/remove-line-up-by-id/`, {"id" :data}).then((response) => {
            toastr.success(translateLabels(3819)) //Lineup removed
            return response.data
          }, (errorParams) => {
          //  console.log('Failed to archive Entry', errorParams)
            if(errorParams.status === 403 && errorParams.data.detail)
            {
              toastr.error(errorParams.data.detail)
            }
            else{
              toastr.error(errorParams.data.error)
            }
            return errorParams.data.error
          })
        },
        // Service to archive (set Archive Flag in SQL) the selected Submitted lineup
        archiveLineup: (data) => {
          return $http.post(`${__env.apiUrl}/api/lineup/archive-lineup-by-id/`, {"id" :data}).then((response) => {
            toastr.success(translateLabels(3821)) // Lineup Archived
            return response.data
          }, (errorParams) => {
            console.log('Failed to archive Entry', errorParams)
            if(errorParams.status === 403 && errorParams.data.detail)
            {
          //    toastr.error(errorParams.data.detail)
            }
            else{
              toastr.error(errorParams.data.error)
            }
            return errorParams.data.error
          })
        },
        // retrieves the employee list
        getEmployeesList: () =>{
          return $http.get(`${__env.apiUrl}/api/employee/get-employee-list-profile/`).then((response) => {
            response.data.forEach((data) => {
              employees[data.per_id] = data.per_full_name
            })
            employeeList = response.data
          })
        },
        // retrieves the visibility supervisor list
        getSupervisorVisibilityList: () => {
          return $http.get(`${__env.apiUrl}/api/employee/get-employee-list-uv/supervisor/`).then((response) => {
            supervisorVisibilityList = response.data.Employee_list
          })
        },
        // retrieves the visibility employee list
        getEmployeesVisibilityList: () => {
          return $http.get(`${__env.apiUrl}/api/employee/get-employee-list-uv/all/`).then((response) => {
            employeeVisibilityList = response.data.Employee_list
          })
        },
        // get single lineup
        getLineup: (id) => {
          return $http.post(`${__env.apiUrl}/api/lineup/get-lineup-by-id/`,{id:id}).then((response) =>{
            editLineupData = response.data
          }, (args) => {
            console.log('Failed to load Single Lineup Data.', args);
          })
        },
        // Get completed list of current lineups
        getLineups: (payload) => {
          return $http.post(`${__env.apiUrl}/api/lineup/get-lineup-list/`, payload).then((response) => {
            if(response.data.message){
              toastr.error(translateLabels(3822)) // You do not have permission
            }else {
              lineupData = getNames(response.data)
            }
          }, (args) => {
            console.log('Failed to load Lineup Data.', args)
          })
        },
        // retrieves the Workplaces when assembling the Lineup Object.
        getWorkplaces: (id) =>{
          return $http.post(`${__env.apiUrl}/api/lineup/get-lineup-workplaces/`,{id:id}).then((response) => {
            editWorkplaceData = response.data
          })
        },
        // retrieves the Workers when assembling the Lineup Object.
        getWorkers: (id)=> {
          return $http.post(`${__env.apiUrl}/api/lineup/get-lineup-workers/`,{id:id}).then((response) => {
            editWorkersData = response.data
          })
        },
        // retrieves the Equipment when assembling the Lineup Object.
        getMachines: (id) =>{
          return $http.post(`${__env.apiUrl}/api/lineup/get-lineup-machines/`,{id:id}).then((response) => {
            let machlist = []
            let i = 0
            response.data.forEach((rec, recindex) => {
              if (machlist.length === 0) {
                machlist.push(rec)
                machlist[i].index = i
                machlist[i].EquipmentList = [{ ID: rec.EquipmentNumber, Label: rec.Label, Value: rec.EquipmentType }]
                i++
              }
              else {
                let match = false
                machlist.forEach((arr, index) => {
                  if (arr.EquipmentID === rec.EquipmentID) {
                    machlist[arr.index].EquipmentList.push({ ID: rec.EquipmentNumber, Label: rec.Label, Value: rec.EquipmentType })
                    match = true
                  }
                })
                if (!match) {
                  machlist.push(rec)
                  machlist[i].index = i
                  machlist[i].EquipmentList = [{ ID: rec.EquipmentNumber, Label: rec.Label, Value: rec.EquipmentType }]
                  i++
                }
              }
            })
            editMachineData = machlist
          })
        },
        // retrieves the Machine type when selecting a michine number.
        getMachineTypes: (machine) => {
          return $http.post(`${__env.apiUrl}/api/lineup/get-lineup-machines-list/`,{machine:machine}).then((response) => {
            return response.data
          })
        },
        // retrieve list of PPE Types
        getPPETypes: (lang) => {
          return $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_special_ppe","language": lang  }).then((response) => {
            PPETypeList = response.data
          })
        },
        getCrewTypes: (lang) => {
          return $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_crew","language": lang  }).then((response) => {
            crewTypeList = response.data
          })
        },
        getShiftTypes: (lang) => {
          return $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_shift","language": lang }).then((response) => {
            shiftList = response.data
          })
        },
        // retrieve a list of sites
        getSites: () => {
          //return  $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_site" })
          return $http.get(`${__env.apiUrl}/api/employee/get-filtered-site-job/site/`,)
          .then((response) =>{  
            sites = response.data.sites
           // return response.data
           }, (error) => { 
             console.log(error)
            })
        },
        getJobsList: (site) => {
          // return  $http.post(`${__env.apiUrl}/api/listmanifest/get-active-list-manifest-data-by-condition/`, { "validatorStr": "ref_job" })
          return $http.get(`${__env.apiUrl}/api/employee/get-filtered-site-job/job/`,)
          .then((response) =>{ 
            compileJobs(response.data.jobs, sites)
            return(response.data)
           }, (error) => { 
             console.log(error)
            })
        },
        // Get a list of the Levels
        getLevelsList: (lang) => {
          return  $http.post(`${__env.apiUrl}/api/listmanifest/get-list-manifest-data-by-condition/`, { "validatorStr": "ref_level" ,"language": lang })
          .then((response) =>{ 
            compileLevels(response.data, sites)
            return(response.data)
           }, (error) => { 
             console.log(error)
            })
        },
        // retrieve a list of JOBS when selecting a site
        getJobs: (site) => {
          let myJobs = []
          fullJobs.forEach((job) => {
            if (job.site === site) {
              myJobs.push({ jobnumber: job.jobnumber, lable: job.lable, id: job.jobId})
            }
          })
          return myJobs
        },
        // Retrieve a list of Levels after selecting a Site
        getLevels: (site) => {
          let myLevels = []
          fullLevels.forEach((level) => {
            if (level.site === site) {
              myLevels.push({ level: level.level, lable: level.lable })
            }
          })
          return myLevels
        },
        // Get the Users Profile of the person logged into the current session.
        getLoggedInViewpointID: ()=> {
          return $http.get(`/api/employees/viewpoint`).then((response) => {
            return response.data
          })
        },

        // Get list of hazards using Site and Level
        getHazards: (data) => {
          // return $http.post(`${__env.apiUrl}/api/lineup/get-incomplete-submissionhap-by-site-and-level/`, {"Site_Name": data.site, "Site_Level": data.level}).then((response) => {
          //   return response.data
          // console.log("REQUEST DATA",data)
          return $http.post(`${__env.apiUrl}/api/lineup/get-incomplete-submissionhap-by-site-and-level/`, data).then((response) => {
            hazards = response.data 
          }, (args) => {
            console.log('Failed to load Lineup Data.', args);
          })
        },
        readHazards: () => {
          return hazards
        },
        // read one lineup
        readLineup: () => {
          return editLineupData
        },
        // read entire list of lineups
        readLineups: ()=> {
          return lineupData
        },
        readLineupJRAListData: ()=> {
          return lineupJRAListData
        },
        readLineupJRAStepData: ()=> {
          return lineupJRAStepData
        },
        readlineupJRAWorkplaceSteps: () =>{
          return lineupJRAWorkplaceSteps
        },
        // Read all of the Workplaces
        readLineupDistribution: () => {
          return lineupDistribution
        },
        // Read all of the Workplaces
        readWorkplaces: () => {
          return editWorkplaceData
        },
        // Read all of the Workers
        readWorkers: () => {
          return editWorkersData
        },
        // Read all of the Equipment
        readMachines: () => {
          return editMachineData
        },
        // Get the complete Employee List
        readEmployeesList: () => {
          return employeeList;
        },
        // Get the complete Employee List
        readEmployeesVisibilityList: () => {
          return employeeVisibilityList
        },
        // Get the complete Employee List
        readSupervisorVisibilityList: () => {
          return supervisorVisibilityList
        },
        // REad the List of PPE Types
        readPPEList: () => {
          return PPETypeList
        },
        readCrewTypeList: () => {
          return crewTypeList
        },
        readShiftTypeList: () => {
          return shiftList
        },
        // Read all of the PPE Data for a lineup
        readPPE: () => {
          return editPPEData
        },
        // read the list of loaded sites
        readSites: () => {
          return sites
        }

        // end of return
          }

      function getSitesData(data){
        data.map((rec)=>{
          rec.rld_id = rec.rld_id.toString()
        })
        return data;
      }

      function compileJobs(jobs,sites){
        fullJobs = []
          jobs.forEach((job)=>{
              sites.forEach((site)=>{
                if(job.rld_parent_detail_rld_id === site.rld_id){
                  fullJobs.push({ jobnumber: job.rld_code, lable: job.rld_name, site: site.rld_id, jobId: job.rld_id })
                }
              })
          })
      }

      function compileLevels(levels,sites){
        fullLevels = []
        levels.forEach((level)=>{
            sites.forEach((site)=>{
              if(level.rld_parent_detail_rld_id === site.rld_id){
                fullLevels.push({ level: level.rld_id.toString(), lable: level.rld_name, site: site.rld_id })
              }
            })
        })
      }

      function getNames (data) {
        data.map((data) => {
          data.SupervisorName = employees[data.Supervisor]
          data.CreatedByName = employees[data.CreatedBy]
        // return data
        })
        return data
      }
      // end of Service
    }
  ])