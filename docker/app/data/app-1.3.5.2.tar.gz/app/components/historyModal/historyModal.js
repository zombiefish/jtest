﻿'use strict';
safeToDo.component("historyModal", {
  templateUrl: 'app/components/historyModal/historyModal.html',
  bindings: {
}, 
  controllerAs: 'vm',
  controller: function ($compile, $scope, $rootScope,$q, $element,modalService) {
      var vm = this;
      vm.mode = null

      vm.translateLabels = (key) => {
        return translateTag(key)
      }
 
      vm.modalElements = {
        title: vm.translateLabels(1128) //"Like",
      }        

      $scope.$on("CALLHISTORYMODAL", (event,data,title) => {
        vm.currentHistory=data
        if(title){
          vm.modalElements.title=title
        }
        modalService.Open('historyModal')
      })

      vm.closeModal = (modalId) => {
        modalService.Close(modalId);
        let behaviour = document.getElementById('historycallingform').innerHTML
        $rootScope.$broadcast(behaviour)
       }
      // end of controller
    }
})