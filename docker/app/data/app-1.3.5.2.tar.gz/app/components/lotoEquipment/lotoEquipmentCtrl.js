'use strict';
safeToDo.component("equipmentModal", {
    templateUrl: 'app/components/lotoEquipment/lotoEquipment.html',
    controllerAs: 'vm',
    controller: ["lotoEquipmentService","$q","gridService","modalService","fileUploadService","$scope","i18nService","$rootScope",
    function (lotoEquipmentService, $q,gridService,modalService,fileUploadService,$scope,i18nService,$rootScope ) {
        var vm = this
        vm.uploadFile = []

        vm.equipmentOptions =  gridService.getCommonOptions()
        vm.equipmentSearch = ''
        vm.equipmentOptions.pagination = false
        vm.systemLanguages = null

        let equipmentColumns = [
        
        {
            field: "lte_name",
            headerName: "",
            minWidth: 1000,
            maxWidth: 3000,
            suppressMenu: true,
            cellRenderer: "tippyCellRenderer",
            filter: 'agSetColumnFilter', 
            menuTabs: ['filterMenuTab']
        },
        {
            field: " ", 
            headerName: "",
            minWidth: 45,
            maxWidth: 45,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: function (params) {
            return `<span class="pointer text-left" ng-click="vm.edit('${params.data.lte_id}')"><i class="fa fa-pen" note="Edit" title="{{vm.translateLabels(1194)}}"></i></span>`
            }
        },
      ] 

        vm.setupEquipmentTypes = () => {
            for(let i=0;i<vm.systemLanguages.languages.length;i++){
                vm.currentEquipmentType.equipment_names.push({
                    "lng_description" : vm.systemLanguages.languages[i].lng_description_text,
                    "ltr_lng_id": vm.systemLanguages.languages[i].lng_id,
                    "lng_default": vm.systemLanguages.languages[i].lng_default,
                    "ltr_text" : ""

                })
                
            }
        }
        vm.equipmentOptions.columnDefs = equipmentColumns  
        vm.resetEquipment = () =>{
            vm.showFile = false
            vm.currentEquipmentType ={
                "lte_id": null,
                "equipment_names":[],
                "lta_filename":null,
                "lta_timestamp": null,
                "lta_id" : null
            }
            if(!vm.systemLanguages){
                $q.all(
                    [i18nService.getLanguages()]
                ).then((data) => {
                    vm.systemLanguages = data[0]
                    vm.setupEquipmentTypes()

                })
            } else {

                vm.setupEquipmentTypes()
            }

        }
        vm.refresh = () => {
            vm.resetEquipment()
            vm.equipmentOptions.api.sizeColumnsToFit()
            $q.all([
                lotoEquipmentService.getAllEquipment(),
            ]).then((data) =>{
                let gridData = data[0]
                translateAgGridHeader(vm.equipmentOptions)
                vm.equipmentOptions.api.setRowData(gridData)
                vm.equipmentOptions.api.sizeColumnsToFit()
                $scope.$emit('STOPSPINNER')
            })
        }

        vm.equipmentOptions.onGridReady= () => {
           vm.refresh()
      }
        vm.openingEquipmentViewer = true
        vm.hidingEquipmentViewer = false

        vm.translateLabels = (key) =>{
            return translateTag(key)
        }

        vm.closeViewer = () => {
            vm.hidingEquipmentViewer = true 
            modalService.Close('EditEquipmentType')
            $('#EditEquipmentType').remove()

        }

        vm.edit = (id) => {
            let payload= {
                "lte_id" : id
            }
            $q.all([
                lotoEquipmentService.getSingleEquipment(payload),
            ]).then((data) => {
               
                if(data){
                    vm.currentEquipmentType = data[0]
                    vm.showFile = (vm.currentEquipmentType.lta_filename !='' && vm.currentEquipmentType.lta_filename !=null)
                    if(vm.showFile){
                        vm.currentEquipmentType.url = `${__env.imageUrl}loto_equipment_attachments/${vm.currentEquipmentType.lta_filename}`
                    }

                    modalService.Open('EditEquipmentType')
                    resetFormFieldClassList('EditEquipment')
                }
            })

        }

        vm.addEquipmentType = () => {
            vm.resetEquipment()
            resetFormFieldClassList('EditEquipment')
            modalService.Open('EditEquipmentType')
        }
        vm.closeEquipmentType = () => {
            resetFormFieldClassList('EditEquipment')
            modalService.Close('EditEquipmentType')
        }

        vm.equipmentSearchChanged = () => {
            vm.equipmentOptions.api.setQuickFilter(vm.equipmentSearch);
        }

        vm.saveEquipmentType = () => {
            let validate = validateFormFields('EditEquipment', false)

            if(validate){
                $scope.$emit('STARTSPINNER', translateTag(8479))
                let payload = vm.currentEquipmentType
                
                // remove equipment translation objects that are not populated.
                for (let a = payload.equipment_names.length-1; a >= 0; a--) {
                    if (payload.equipment_names[a].ltr_text == '') {
                        payload.equipment_names.splice(a,1)
                    }
                }
                if(vm.currentEquipmentType.lte_id){
                    //existing equipment type.

                    lotoEquipmentService.updateEquipmentType(payload).then(response => {

                        if(response.status==200){
                            if(vm.uploadFile!=null && vm.uploadFile.length > 0){
                                let att = vm.attachmentFormData(response.data)
                                lotoEquipmentService.saveEquipmentAttachment(att).then((response) => {
                                    vm.refresh()
                                })
                            } else {
                                vm.refresh()
                            
                            }
                        } else {
                            vm.refresh()
                            resetFormFieldClassList('EditEquipment')
                        }
                    })
                } else {
                    // new equipment type.
                    lotoEquipmentService.saveEquipmentType(payload).then( (response) => {
                        if(vm.currentEquipmentType.lta_filename != null && vm.currentEquipmentType.lta_filename != ''){
                            let att = vm.attachmentFormData(response.data)
                            lotoEquipmentService.saveEquipmentAttachment(att).then((response) => {
                                vm.refresh()
                            })
                        } else {
                            vm.refresh()
                        }
                    })
                }
                modalService.Close('EditEquipmentType')
            }
        }
        vm.convertTime = (timestamp) =>{
            return moment(timestamp).format("YYYY-MM-DD hh:mm:ss a")
        }
        vm.attachmentFormData = (fileinfo) =>{

            let fd = new FormData()
            fd.append('lta_lte', fileinfo.lte_id)
            if(vm.uploadFile!=null){
                fd.append('lta_filename', vm.uploadFile[0])
                fd.append("lta_timestamp", moment.unix(vm.uploadFile[0].lastModified/1000).format('YYYY-MM-DD HH:mm:ss'))
            } else {
                fd.append('lta_filename','')
                fd.append("lta_timestamp", '')
            }
            return fd
        }

        //#region Functions to handle attachment uploads
        $scope.lotoEquipmentPictureChanged = (event)=> {

            //Get data from files to display in html
            vm.uploadFile = fileUploadService.checkFileUpload(event.target.files, [], true)
            fileUploadService.getFileUploadData(vm.uploadFile).then((filesData) => {

                vm.currentEquipmentType.url = filesData[0].url  
                vm.currentEquipmentType.lta_filename = filesData[0].file
                vm.currentEquipmentType.lta_timestamp = vm.uploadFile[0].lastModified
                vm.showFile = true 
                $scope.$apply() // Update html bindings
            })
        }

        vm.deleteEquipmentPicture = () => {

            vm.currentEquipmentType.lta_filename = null
            vm.uploadFile = null
            vm.currentEquipmentType.url = null
            vm.currentEquipmentType.lta_timestamp = null
            vm.showFile = false
            if(vm.currentEquipmentType.lte_id != null){
                let payload = {
                    "lta_id" : vm.currentEquipmentType.lta_id
                }
                lotoEquipmentService.deleteEquipmentAttachment(payload).then(response => {
                    
                })
            }
        }
        vm.askDeletePicture = () => {
            vm.modalElements = {
                title: translateTag(3416), //"Delete Attachment?"
                message:               
                `<div>          
                    <p note="You are about to delete this attachment. Undoing this will require IT support. Are you sure?">${translateTag(3635)}</p>
                </div>`, 
                buttons: 
                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            } 
            document.getElementById('confirmcallingform').innerHTML = 'LOTOEQUIPCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("LOTOEQUIPCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.deleteEquipmentPicture()
                modalService.Close('confirmModal')
            } else if (result=='button2') {
                modalService.Close('confirmModal')
            }
        })

    }

    ]
});

