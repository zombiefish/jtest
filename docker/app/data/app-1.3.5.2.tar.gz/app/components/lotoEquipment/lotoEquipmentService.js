angular
  .module('safeToDo')
  .service('lotoEquipmentService', ['$http', 
      function ($http) {
        let equipmentList
        return {
            
            // Service that will take the lineup data and either insert or update the Lineup Data
            getAllEquipment: () => {
                return $http.get(`${__env.apiUrl}/api/loto/get-equipment-list`).then((response) => {     
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to load Equipment list', errorParams)
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                        equipmentList = []
                    }
                })
            },
            getSingleEquipment : (payload) => {
                return $http.post(`${__env.apiUrl}/api/loto/get-single-equipment/`, payload).then((response) => {     
                    return response.data
                }, (errorParams) => {
                    console.log('Failed to get Equipment', errorParams)
                    if(errorParams.status === 403 && errorParams.data.detail){
                        toastr.error(errorParams.data.detail)
                    }
                })
            },
            saveEquipmentType : (payload) => {
                return $http.post(`${__env.apiUrl}/api/loto/create-loto-equipment/`, payload).then(response =>{
                    return response

                }, (errorParams) => {
                    console.log("Error Params", errorParams)
                })
            },
            saveEquipmentAttachment : (payload) => {
                return $http.post(`${__env.apiUrl}/api/loto/add-loto-equipment-attachment/`, payload,{
                    // this cancels AngularJS normal serialization of request
                    transformRequest: angular.identity,
                    // this lets browser set `Content-Type: multipart/form-data` 
                    // header and proper data boundary
                    headers: {'Content-Type': undefined}}).then((response) =>{
                    return response
                }, (errorParams) => {
                    console.log("Error Params", errorParams)
                })
            },
            updateEquipmentType  :(payload) => {
                return $http.post(`${__env.apiUrl}/api/loto/update-equipment/`, payload).then(response => {
                    return response
                }, (errorParams) => {
                    console.log("Error Params", errorParams)
                })

            },
            deleteEquipmentAttachment : (payload) => {
                return $http.post(`${__env.apiUrl}/api/loto/delete-equipment-image/`, payload).then(response => {
                }, (errorParams) => {
                    console.log("Error Params", errorParams)
                })
            }  
        } 
    }
     
])