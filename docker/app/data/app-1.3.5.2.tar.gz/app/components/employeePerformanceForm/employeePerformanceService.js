angular
    .module('safeToDo')
    .service('employeePerformanceService', ['$http',
        function ($http) {            
            return {                
                createEmployeePerformance: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/wafs/form-submission-engine/`, payload).then((response) => {
                    return response.data
                    }, (errorParams) => {
                        console.log('Failed to create Employee Performance Review', errorParams)
                    })
                },
            //END
            }        
        }
    ])