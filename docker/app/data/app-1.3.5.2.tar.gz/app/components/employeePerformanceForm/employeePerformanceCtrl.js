safeToDo.component("form372318", {
    // styling found in avatar.css
    templateUrl: 'app/components/employeePerformanceForm/employeePerformance.html',
    bindings: {
        modalId: '<',
        allData: '<',
        mode: '<',
        incidentId: '<',
        onSave: '&',
        onClose: '&'
    },
    controllerAs: 'vm',
    controller: function ($scope, $q, $sce, employeePerformanceService, listService, modalService, profileService, adminUserService, $compile, employeesService, settingsService, imageCommentService,$rootScope) {
        let vm = this
        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        vm.siteList = []
        vm.jobList = []
        vm.jobListSelect = []
        vm.levelList = []
        vm.levelListSelect = []
        vm.employeeList = []
        vm.supervisorList = []
        vm.distributionList = []
        vm.target = ''
        vm.positions = []
        vm.mainButton = null
        vm.validateRadioBtns = false

        //Function to reset form
        function resetForm () {
            document.forms['employeePerformanceForm'].classList.remove('was-validated')
            vm.validateRadioBtns = false
            vm.submitted = false

            vm.currentEmpPerform = {
                form_name: '2179', //EMPLOYEE PERFORMANCE
                headerdate: dateToday.format("YYYY-MM-DD"),
                site: null,
                job_number: null,
                level: null,
                workplace: '',
                supervisor: null,
                employee_name: null,
                probation_evaluation_period:'',
                evaluation_completed_by: null,
                employee_position: null,
                evaluation_date:dateToday.format("YYYY-MM-DD"),
                dependability: null,
                work_performance: null,
                cooperativeness: null,
                communication: null,
                adaptability: null,
                problem_solving: null,
                leadership: null,
                overall_performance_comments: '',
                overall_performance_rating: null,
                employee_development_goals: '',
                employee_goals: '',
                evaluation_feedback: '',
                signature_employee: '',
                signature_reviewer: '',
                signature_employee_img_time: '',
                signature_reviewer_img_time: '',
                Report_Distribution1: []
            }
        }

        //Function to get jobs & levels at a site
        vm.getJobsLevels = () => {
            let mainSite = vm.currentEmpPerform.site
            vm.currentEmpPerform.job_number = null
            vm.currentEmpPerform.level = null
            vm.jobListSelect = []
            vm.levelListSelect = []
            vm.getFilteredEmployees()
            vm.jobList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id === mainSite)
                    vm.jobListSelect.push(rec)
            })
            vm.levelList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id === mainSite)
                    vm.levelListSelect.push(rec)
            })
            
        }

        vm.getFilteredEmployees = () =>{            
            profileService.filterEmployeeListonJob(vm.currentEmpPerform.job_number)
            vm.employeeList =  profileService.readFilterEmployeeListonJob()
            profileService.filterSupervisorListonJob(vm.currentEmpPerform.job_number)
            vm.supervisorList = profileService.readFilterSupervisorListonJob()
            profileService.filterDistributionListonJob(vm.currentEmpPerform.job_number)
            vm.distributionList = profileService.readFilterDistributionListonJob()
        }

        vm.openSignModal = (e) => {
            if(e.target.tagName.toLowerCase() == 'i') // If clicked on <i>
                e.target = e.target.parentNode

            document.getElementById(`sigModalOK`).removeEventListener('click', signFunction)
            vm.mainButton = e.target
            vm.target = e.target.getAttribute('signaturename')
            $(`#${vm.target}`).val('')
            $(`#${vm.target}_img`).val('')
            $('#output').val('')
            modalService.Open('eperSignatureModal')
            activateSignature()
        }

        function signFunction(e) {
            e.stopPropagation()
            let vecValue = document.querySelector('#output').value
            if (vecValue) {
                // Signature stuff.
                vm.currentEmpPerform[vm.target] = $(`.sigPadModal .pad2`)[0].toDataURL('image/jpeg')
                $(`#${vm.target}`).next().val(vecValue)
                $(`#${vm.target}_img`).attr('src', $(`.sigPadModal .pad2`)[0].toDataURL('image/jpeg'))
                //timestamp stuff
                img_notes = vm.target + '_img_time'
                time = moment(new Date()).format('YYYY-MM-DD hh:mm:ss a')
                $(`[notes=${img_notes}]`)[0].value = time
                vm.currentEmpPerform[img_notes] = time
                $(`[notes=${img_notes}]`)[0].parentElement.classList.remove("d-none")
            } else {
                //revert the modal if there is no signature.
                $(`#${vm.target}`).val('')
                $(`#${vm.target}`).next().val('')
                $(`#${vm.target}_img`).attr('src', '')

                //reset the timestamp.
                img_notes = vm.target + '_img_time'
                $(`[notes=${img_notes}]`)[0].value = ""
                vm.currentEmpPerform[img_notes] = ""
                $(`[notes=${img_notes}]`)[0].parentElement.classList.add("d-none")
            }

            $(`#sigModal .output`).val('')

            if (vecValue) {
                // add the resign button.
                vm.mainButton.innerHTML = `<i class="fa fa-pen" note="Re-sign"></i> ${translateTag(2243)}`
                $(`#${vm.target}`).prev().prev().children()[2].classList.remove('d-none') //clear sign
                $(`#${vm.target}`).prev().prev().children()[1].classList.remove('d-none') // add comment button
                $(`#${vm.target}`).prev().prev().children()[0].classList.remove('invalid') // sign
            }
            else {
                //
                vm.mainButton.innerHTML = `<i class="fa fa-pen" note="Sign"></i> ${translateTag(1396)}`
                $(`#${vm.target}_img`).attr('src', '')
                $(`#${vm.target}`).prev().prev().children()[2].classList.add('d-none')
                $(`#${vm.target}`).prev().prev().children()[1].classList.add('d-none')
                clearComment(vm.mainButton)
            }

            let sig = $('.sigPadModal').signaturePad({})
            sig.clearCanvas()

            modalService.Close('eperSignatureModal')
        }

        function activateSignature() {
            $('canvas.pad2').attr({ "width": $('.pad2').parent().width(), "height": $('.pad2').parent().width() / 3 })
            setTimeout(() => {                
                let sig = $('.sigPadModal').signaturePad({
                    lineColour: "#ced4da",
                    drawOnly: true,
                    lineWidth: 0,
                    lineBottom: 10,
                    bgColour: 'rgb(255,255,255)'
                })
                sig.clearCanvas()

                document.getElementById(`sigModalOK`).addEventListener('click', signFunction)
                document.getElementById(`reSignButton`).addEventListener('click', (e) => {
                    canvas = e.target.parentNode.previousSibling.previousElementSibling.previousElementSibling
                    let sig = $('.sigPadModal').signaturePad({
                        lineColour: "#ced4da",
                        drawOnly: true,
                        lineWidth: 0,
                        lineBottom: 10,
                        bgColour: 'rgb(255,255,255)'
                    });
                    sig.clearCanvas()
                })
            }, 300)

        }
        vm.clear_signature_comment = () => {
            vm.signatureCommentObject[vm.signed_by]=null
            clearSignature(vm.button)
            modalService.Close('confirmModal')
        }

        $(`.clear_sign`).click((e) => {
            let clear_button

            if(e.target.tagName.toLowerCase() == 'i') // If clicked on <i>
                e.target = e.target.parentNode
            clear_button = e.target
            let id=clear_button.id
            let who = id.split('_')[0]
            vm.signed_by = who
            if(vm.signatureCommentObject[who]){
                 if(vm.signatureCommentObject[who].com_comment !='' && vm.signatureCommentObject[who].com_comment !==undefined ){
                    vm.modalElements = {
                        title: translateTag(2777), //"Remove Signature/Comment?"
                        message: `<div><p>${translateTag(2781)}</p></div>`, //"Are you sure you want to remove the signature and associated comment from the form?"
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                    }  
                    document.getElementById('confirmcallingform').innerHTML = 'EMPPERCALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
                    vm.button = clear_button
                } else {
                    clearSignature(clear_button)
                }
            } else {
                clearSignature(clear_button) 
            }
        })        
        
        $scope.$on("EMPPERCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.clear_signature_comment()
            }
        })        
        
        function clearAllSign () {
            let signImgs = Array.from(document.getElementsByClassName("clear_sign"))

            signImgs.forEach ((clear_button) => {
                clearSignature(clear_button)
            })
            
        }

        function clearSignature(clear_button){
            clear_button.previousElementSibling.previousElementSibling.innerHTML = `<i class="fa fa-pen" note="Sign"></i> ${translateTag(1396)}`
            clear_button.parentNode.nextElementSibling.setAttribute('src', '')

            $(`[notes=${clear_button.parentNode.nextElementSibling.id + '_time'}]`)[0].value = ""
            vm.currentEmpPerform[clear_button.parentNode.nextElementSibling.id + '_time'] = ""
            $(`[notes=${clear_button.parentNode.nextElementSibling.id + '_time'}]`)[0].parentElement.classList.add("d-none")

            vm.currentEmpPerform[clear_button.previousElementSibling.getAttribute('signaturename')] = ''
            clear_button.parentNode.nextElementSibling.nextElementSibling.value = ''
            clear_button.parentNode.nextElementSibling.nextElementSibling.nextElementSibling.value = ''
            clear_button.parentNode.children[1].classList.add('d-none') //hide the add comment button.
            
            // clear comment
            clearComment(clear_button)

            clear_button.classList.add('d-none')
            if (clear_button.parentNode.nextElementSibling.nextElementSibling.hasAttribute('required')) {
                clear_button.previousElementSibling.classList.add('invalid')
            }

        }

        function clearComment(clear_button){
            let who = clear_button.parentNode.nextElementSibling.id.split('_')[1]
            let elem = document.getElementById(`${who}_comment`)
            elem.classList.remove('fas')
            elem.classList.add('far')  
            vm.signatureCommentObject[who] = null
        }

        vm.validateSig = () =>{
            document.getElementById('sign_button1').classList.remove('invalid') 
            document.getElementById('sign_button2').classList.remove('invalid') 
            let rev = document.getElementById('vector_reviewer')
            let emp = document.getElementById('vector_employee')
            if(rev.value.length==0 || emp.value.length==0){
                if(emp.value.length==0){
                    document.getElementById('sign_button1').classList.add('invalid') 
                }
                if(rev.value.length==0){
                    document.getElementById('sign_button2').classList.add('invalid')
                }
                return false
            }
            return true
        }
        //Function to create the employee review
        vm.createEmpRev = () => {
            let payload = preparePayload(JSON.parse(JSON.stringify(vm.currentEmpPerform)))
            let pass1, pass2;
            pass1 = vm.validateSig()
            pass2 = vm.validateForm()

            if(pass1 && pass2) {
            
                vm.submitted = true
                employeePerformanceService.createEmployeePerformance(payload).then ((response) =>{

                    for(let signature of response.signature_ids){
                        let who = signature[1].split('_')[1]
                        if(vm.signatureCommentObject[who] !== null)
                            vm.signatureCommentObject[who]['com_reference_id'] = signature[0]
                    }
                  
                    for(let who in vm.signatureCommentObject){
                        if(vm.signatureCommentObject[who]!=null)
                            imageCommentService.saveComment(vm.signatureCommentObject[who])  
                    }

                    vm.closeModal('form-372318')
                    $scope.$emit('REFRESH_FORMSUBMISSIONS')
                })
            } else {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        vm.signatureCommentObject = {
            employee : null,
            reviewer: null
        }
        // Open comment modal 'event'
        vm.AddComments = (who) => {
            vm.signed_by = who
            //set parameters for opening the modal here.
            document.getElementById('parentform').innerHTML = 1
            document.getElementById('savetomemory').innerHTML = true
            document.getElementById('callingform').innerHTML = 'CLOSEPERIMAGECOMMENTSMODAL'  
            if(vm.signatureCommentObject[who]!=null) {
                $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.signatureCommentObject[who].com_comment)
            }else{$rootScope.$broadcast("RECIEVEROFCOMMENTS")}  
        }
    

        // Close comment modal 'event'
        $scope.$on('CLOSEPERIMAGECOMMENTSMODAL',(event,data) => {
            let elem = document.getElementById(`${vm.signed_by}_comment`)
            if(data.com_comment==''){
                vm.signatureCommentObject[vm.signed_by] = null
            }
            if(data.com_comment){
                if(data.com_comment === '' || data.com_comment === null){
                    vm.signatureCommentObject[vm.signed_by] = null
                    elem.classList.remove('fas')
                    elem.classList.add('far')                
                }
                else{
                    elem.classList.remove('far')
                    elem.classList.add('fas')      
                    vm.signatureCommentObject[vm.signed_by] = data
                } 
            } else {
                let elem = document.getElementById(`${vm.signed_by}_comment`)
                elem.classList.remove('fas')
                elem.classList.add('far') 
            } 
        })


        //Function to prepare payload data
        function preparePayload(payload) {
            let preparedPayload = payload
            preparedPayload.employee_name = getEmployeeName(preparedPayload.employee_name)
            preparedPayload.evaluation_completed_by = getEmployeeName(preparedPayload.evaluation_completed_by)            
            preparedPayload.headerdate = moment(payload.headerdate, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DDThh:mm')
            return preparedPayload
        }

        //Function to close the modal
        vm.closeModal = (modalId) => {    
            clearAllSign()        
            modalService.Close(modalId)
            vm.employeeList = []
            vm.supervisorList = []
            vm.distributionList = []
            resetForm()
            refreshData()            
        }

        //Function for form validation
        vm.validateForm = () => {
            let validateFormFlag = validateFormFields('employeePerformanceForm')
            vm.validateRadioBtns = true
            let formVal = document.forms['employeePerformanceForm']
            formVal.classList.add('was-validated')
     
            let validated = true
            for (let a = 0; a < formVal.length; a++) {
                if (!formVal[a].validity.valid) {
                    validated = false
                    if (document.getElementById(`vector_employee`).value=="") {
                        document.getElementById('sign_button1').classList.add('invalid')
                        validated = false
                    }
                    if (document.getElementById(`vector_reviewer`).value=="") {
                        document.getElementById('sign_button2').classList.add('invalid')
                        validated = false
                    }
                }    
            }
            // return validated
            if(validated && validateFormFlag)
                return true
            else
                return false  
        }

        $scope.$on('distribution-list-added', (event, args) => {
            if(vm.currentEmpPerform !== undefined)
                $scope.$emit('addDistributionGroup', args, vm.currentEmpPerform.Report_Distribution1)
        })

        $scope.$on('distribution-list-removed', (event, args) => {
            $scope.$emit('removeDistributionGroup', args)
        })

        vm.componentTranslateLabels = (key) => {
            return translateTag(key)
        }

        vm.componentTranslateLabelsHTML = (key) => {
            return $sce.trustAsHtml(translateTag(key))
        }

        //Function to refresh all data
        function refreshData() {
            $q.all([
                listService.getSelectListData('ref_site'),
                listService.getSelectListData('ref_job'),
                listService.getSelectListData('ref_level'),
                profileService.getAllEmployeeProfile(),
                profileService.getAllSupervisorProfile(),
                profileService.getDistributionList(),
                profileService.getAllHumanResourceList(),
                adminUserService.getPositions(selectedLanguage),
                employeesService.getPersonProfile()
            ]).then((data) => {
                resetForm()
                vm.siteList = data[0]
                vm.jobList = data[1]
                vm.levelList = data[2]
                vm.employeeList = profileService.readAllEmployeeProfile()
                vm.supervisorList = profileService.readAllSupervisorProfile()  
                vm.distributionList = profileService.readDistributionList()
                vm.positions = adminUserService.getPositionList()
                vm.current_user_id = data[8].per_id
            }).then((data)=>{
                settingsService.getUserProfile(vm.current_user_id).then((response) => {
                    vm.siteList.forEach((rec)=>{
                        if(response.upr_site===rec.rld_id){
                            vm.currentEmpPerform.site = response.upr_site
                            vm.getJobsLevels()
                        }
                    })
                    vm.jobList.forEach((rec)=>{
                        if(response.upr_job==rec.rld_id){
                            vm.currentEmpPerform.job_number = response.upr_job
                            vm.getFilteredEmployees()
                        }
                    })
                    vm.levelList.forEach((rec) => {
                        if(response.upr_level === rec.rld_id){
                            vm.currentEmpPerform.level = response.upr_level
                        }
                    })
                    vm.supervisorList.forEach((rec)=>{
                        if(response.upr_supervisor_per === rec.per_id){
                            vm.currentEmpPerform.supervisor = rec.per_id
                        }
                    })  
                    if(response.distribution_list){
                        let email_list = []
                        response.distribution_list.forEach((d)=>{
                            email_list.push(d.email)
                        })                   
                        vm.currentEmpPerform.Report_Distribution1 = email_list
                    }    
                })
            })                          
        }

        //#region Functions to convert ID's to Names
        function getEmployeeName(value) {
            let name = value
            vm.employeeList.forEach((emp)=>{
            if(emp.per_id == value) {
              name = emp.per_full_name
            }
          })
          return name
        }

        refreshData()

    //END
    }
})