safeToDo.component("generalActionForm", {
    templateUrl: 'app/components/generalAction/generalAction.html',
    bindings: {
        modalId: '<',
        currentGeneralAction: '<',
        mode: '<',
        hapModel: '<',
        incidentId: '<',
        onSave: '&',
        onClose: '&',
        headerData: '<',
    },
    controllerAs: 'vm',
    controller: function ($q, $scope,$controller,$compile,modalService,fileUploadService, listService, profileService, actionManagementService, $compile, employeesService, settingsService,$window,$rootScope, imageCommentService, menuService ) {
        let vm = this
        $controller('distributionGroupCtrl', {$scope: $scope})

        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        vm.siteList = []
        vm.jobList = []
        vm.jobListSelect = []
        vm.levelList = []
        vm.levelListSelect = []
        vm.actionTypeList = []
        vm.employeeList = []
        vm.supervisorList = []
        vm.distributionList = []
        vm.current_user_id = null
        vm.formName = null
        vm.canAssignMultipleUsersToActions = null

        vm.newInitialAttachments = []
        vm.genUploadFileList = []

        menuService.getPagePermissions().then((data) => {
            vm.permissions = data      
            vm.canAssignMultipleUsersToActions = vm.permissions.includes('Can Assign Action to Multiple Users') ? true : false
        })


        //Function to close the modal
        vm.closeModal = (modalId) => {
            resetFormFieldClassList('generalForm')
            modalService.Close(modalId)
            createGeneralAction()
            refreshData()
            vm.newInitialAttachments = []
            vm.genUploadFileList = []
            vm.employeeList = []
            vm.supervisorList = []
            vm.distributionList = []
            $scope.$emit('CLOSEMODAL')
        }
        vm.cancelModal = (modalId) => { 
            vm.deleteInitPara=null
            modalService.Close(modalId)
        }

        vm.$onInit = () => {
            refreshData()            
        }

        //Function to delete local attachments
        vm.deleteInitialAttachment = (index) => {            
            vm.deleteInitPara={
                mode:'init',
                index: index
            }
            vm.deleteAttachmentConfirmationModal(index)
            for (let image_index=0;image_index<vm.newInitialAttachments.length;image_index++){
                if(vm.newInitialAttachments[image_index].comment){
                    if(vm.newInitialAttachments[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                } else {
                    let elem = document.getElementById('comment_' + image_index)
                    elem.classList.remove('fas')
                    elem.classList.add('far')
                }
            }                
        }

        //Function to open delete Attachment Confirmation Modal
        let deleteIndex = null
        vm.deleteAttachmentConfirmationModal = (index) => {
            deleteIndex = index
            vm.modalElements = {
                title: translateTag(3416), //"Delete Attachment?"
                message:               
                `<div>          
                    <p ng-if=${vm.deleteInitPara && vm.deleteInitPara.mode=='init'} note="You are about to delete this attachment.Are you sure?">${translateTag(1452)}</p>
                    <p ng-if=${!vm.deleteInitPara} note="You are about to delete this attachment. Undoing this will require IT support. Are you sure?">${translateTag(3635)}</p>
                </div>`, 
                buttons: 
                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            } 
            document.getElementById('confirmcallingform').innerHTML = 'GACALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("GACALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.deleteExistingInitialAttachment(vm.deleteInitPara)
            }
            else if (result=='button2') {
                vm.cancelModal('confirmModal')
            }
        })

        //Function to delete existing attachments
        vm.deleteExistingInitialAttachment = (deleteInitPara) => {
            if(deleteInitPara && deleteInitPara.mode=="init"){
                vm.genUploadFileList.splice(deleteInitPara, 1)
                vm.newInitialAttachments.splice(deleteInitPara, 1)
            }
            else{
                let id = vm.currentGeneralAction.attachments[deleteIndex].gaa_id
                actionManagementService.removeGeneralActionAttachment({gaa_id: id}).then((res) =>{
                vm.currentGeneralAction.attachments.splice(deleteIndex, 1)
                deleteIndex = null
                })
            }            
            modalService.Close('confirmModal')
            vm.deleteInitPara=null
        }

        $scope.initialGeneralFileUploadChanged = (event)=> {

            let existingFileNames = []
            for(let i in vm.genUploadFileList) {
                existingFileNames.push(vm.genUploadFileList[i].name)
            }

            //Add newly selected files after checking for duplicates and correct file types
            vm.genUploadFileList = vm.genUploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, existingFileNames, true))

            //Get data from files to display in html
            fileUploadService.getFileUploadData(vm.genUploadFileList).then ((filesData) => {
                vm.newInitialAttachments = filesData
                $scope.$apply() // Update html bindings
            })
        }

        //Function to reset form to new
        function createGeneralAction() {
            vm.submitted = false
            vm.currentGeneralAction = {
                sga_id : null,
                HeaderDate: dateToday.format("YYYY-MM-DD"),
                Site: null,
                JobNumber: null,
                SiteLevel: null,
                Workplace: '',
                Supervisor: null,
                sga_action_is_complete : 0,
                sga_completed_action_type_rld_id  : null,
                sga_completed_action_taken : null,
                sga_action_type_rld_id: null,
                sga_action_by_who_per_id: null,
                sga_action_by_when: '',
                sga_created_date: null,
                sga_created_by_per_id: null,
                sga_completed_action_date: null,
                sga_recommended_action: '',
                attachments: [],
                distribution: [],
                sga_is_group_action: 'individual'
            }  
        }  
        
        vm.$onChanges = () => {
            if(vm.currentGeneralAction.sga_id != null){
                vm.editGeneralAction()
            }
            vm.getJobsLevels('edit')        
        }

        //Function to get Jobs & Levels for a site
        vm.getJobsLevels = (mode) => {            
            vm.jobListSelect = []
            vm.levelListSelect = []
            
            if(vm.currentGeneralAction !== undefined){
                if(vm.currentGeneralAction.Site === undefined || vm.currentGeneralAction.Site === null){
                    vm.currentGeneralAction.JobNumber = null
                    vm.currentGeneralAction.SiteLevel = null
                    vm.getFilteredEmployees()
                    return
                }
            }            
            if(!vm.currentGeneralAction || !vm.siteList.some(t => t.rld_id === vm.currentGeneralAction.Site))
                return

            let mainSite = vm.currentGeneralAction.Site
            if(mode != 'edit')
            {
                vm.currentGeneralAction.JobNumber = null
                vm.currentGeneralAction.SiteLevel = null
            }

            if(vm.clonedActionData !== undefined && mainSite === vm.clonedActionData.Site && vm.siteList.some(t => t.rld_id === vm.clonedActionData.Site && t.rld_historical)){    
                addHistoricalOption('general_job_number', vm.jobListSelect, vm.clonedActionData.JobNumber, vm.clonedActionData.JobNumber_ltr_text)
                addHistoricalOption('general_level', vm.levelListSelect, vm.clonedActionData.SiteLevel, vm.clonedActionData.SiteLevel_ltr_text)
                return
            }


            vm.jobList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id === mainSite)
                    vm.jobListSelect.push(rec)
            })
            vm.levelList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id === mainSite)
                    vm.levelListSelect.push(rec)
            })
        }

        profileService.getPersonProfile().then((res)=>{
            vm.currentUser = profileService.readPersonProfile()
        })

        vm.getFilteredEmployees = () =>{
            profileService.filterEmployeeListonJob(vm.currentGeneralAction.JobNumber)
            vm.employeeList =  profileService.readFilterEmployeeListonJob()
            profileService.filterSupervisorListonJob(vm.currentGeneralAction.JobNumber)
            vm.supervisorList = profileService.readFilterSupervisorListonJob()
            profileService.filterDistributionListonJob(vm.currentGeneralAction.JobNumber)
            vm.distributionList = profileService.readFilterDistributionListonJob()
        }
        

        vm.convertTime = (timestamp) =>{
            return moment(timestamp).format("YYYY-MM-DD hh:mm:ss a")
        }        

        vm.setGroup = () => {

            if(vm.currentGeneralAction.sga_is_group_action == 'group'){
                vm.currentGeneralAction.sga_is_group_action = true 
            } else if(vm.currentGeneralAction.sga_is_group_action=='individual') {
                vm.currentGeneralAction.sga_is_group_action = false
            } else {
                vm.currentGeneralAction.sga_is_group_action = false
            }

        }
        vm.submitGeneralAction = () => {
            resetFormFieldClassList('generalForm')
            if(validateFormFields('generalForm')){
                vm.submitted = true

                vm.setGroup()

                if(vm.mode === 'edit') {
                    let payload = prepareGeneralEditPayload(vm.currentGeneralAction)
                    actionManagementService.updateGeneralAction(payload).then ((res) => {
                        for (let i in vm.genUploadFileList) {
                            let fd = new FormData()
                            fd.append("sga_id", payload.sga_id)
                            fd.append("gaa_file", vm.genUploadFileList[i])
                            fd.append("gaa_type", 'INITIAL')
                            fd.append("gaa_image_timestamp",moment.unix(vm.genUploadFileList[i].lastModified/1000).format('YYYY-MM-DD HH:mm:ss'))
                            let attachments_list = [...vm.newInitialAttachments]

                            if(attachments_list.length > 0 ) {
                                actionManagementService.addGeneralActionAttachments(fd).then((res) => {
                                    let sfiles = res.data["Successfull Files"]
                                    let attached_count = 0
                                    for(attached of sfiles.allowed_original){
                                        for(newA of attachments_list){
                                            if(newA.comment){
                                                if(attached==newA.file){
                                                    //call the add comment service.
                                                    newA.comment.com_reference_id = sfiles.ids[attached_count]
                                                    //call service to insert comment.
                                                    imageCommentService.saveComment(newA.comment)    
                                                }
                                            }
                                        }
                                        attached_count++
                                    }    
                                })
                            }
                        }  
                        $scope.$emit('GENERAL_REFRESHDATA')
                        $scope.$emit('ADDACTION', vm.currentGeneralAction)
                        vm.closeModal('generalActionModal')              
                    })
                } else {                    
                    if (window.location.href.includes("/tir") && vm.incidentId) {
                        vm.currentGeneralAction['incidentid'] = vm.incidentId
                    }
                    if(vm.canAssignMultipleUsersToActions==false){
                        vm.currentGeneralAction.sga_action_by_who_per_id = [vm.currentGeneralAction.sga_action_by_who_per_id]
                    }

                    actionManagementService.createGeneralAction(vm.currentGeneralAction).then ((res) => {
                        vm.currentGeneralAction.sga_id = res.ID

                        for (let i in vm.genUploadFileList) {
                            let fd = new FormData()                            
                            fd.append("sga_id", res['ID'])
                            fd.append("gaa_file", vm.genUploadFileList[i])
                            fd.append("gaa_type", 'INITIAL')
                            fd.append("gaa_image_timestamp",moment.unix(vm.genUploadFileList[i].lastModified/1000).format('YYYY-MM-DD HH:mm:ss')) 
                            let attachments_list = [...vm.newInitialAttachments]
                            if(attachments_list.length > 0 ) {
                                actionManagementService.addGeneralActionAttachments(fd).then((res) => {                                    
                                    let sfiles = res.data["Successfull Files"]
                                    let attached_count = 0
                                    for(attached of sfiles.allowed_original){
                                        for(newA of attachments_list){
                                            if(newA.comment){                                               
                                                if(attached==newA.file){
                                                    //call the add comment service.
                                                    newA.comment.com_reference_id = sfiles.ids[attached_count]
                                                    //call service to insert comment.
                                                    imageCommentService.saveComment(newA.comment)    
                                                }
                                            }
                                        }
                                        attached_count++
                                    }

                                })
                            }
                        }
                        $scope.$emit('GENERAL_REFRESHDATA')                            
                        $scope.$emit('ADDACTION', vm.currentGeneralAction)
                        vm.closeModal('generalActionModal')
                    })
                }
            }
            else{
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }

        function prepareGeneralEditPayload (payload) {
            let preparedPayload = {}
            preparedPayload.sga_id = payload.sga_id
            preparedPayload.sga_submission_header = payload.sga_submission_header
            preparedPayload.HeaderDate = payload.HeaderDate
            preparedPayload.Site = payload.Site
            preparedPayload.JobNumber = payload.JobNumber
            preparedPayload.SiteLevel = payload.SiteLevel
            preparedPayload.Workplace = payload.Workplace
            preparedPayload.Supervisor = payload.Supervisor
            preparedPayload.sga_action_type_rld_id = payload.sga_action_type_rld_id
            preparedPayload.sga_action_by_who_per = payload.sga_action_by_who_per_id
            preparedPayload.sga_action_by_when = payload.sga_action_by_when
            preparedPayload.sga_recommended_action = payload.sga_recommended_action
            return preparedPayload
        }

        $scope.$on('distribution-list-added', (event, args) => {
            if(vm.currentGeneralAction !== undefined)
                $scope.$emit('addDistributionGroup', args, vm.currentGeneralAction.distribution)
        })

        $scope.$on('distribution-list-removed', (event, args) => {
            $scope.$emit('removeDistributionGroup', args)
        })

        vm.editGeneralAction = () =>{
            vm.getFilteredEmployees()
            // cloning action data into new variable - to access the data when user modififes it accidentally
            vm.clonedActionData = {...vm.currentGeneralAction}
            modifyCurrentGeneralEditData()    
        }

        async function modifyCurrentGeneralEditData(){
            await addHistoricalOption('general_site', vm.siteList, vm.currentGeneralAction.Site, vm.currentGeneralAction.Site_ltr_text)
            await addHistoricalOption('general_job_number', vm.jobListSelect, vm.currentGeneralAction.JobNumber, vm.currentGeneralAction.JobNumber_ltr_text)
            await addHistoricalOption('general_level', vm.levelListSelect, vm.currentGeneralAction.SiteLevel, vm.currentGeneralAction.SiteLevel_ltr_text)
            await addHistoricalUserOption('general_supervisor', vm.supervisorList, vm.currentGeneralAction.Supervisor, vm.currentGeneralAction.Supervisor_full_name)
            
            let by_who = [...vm.currentGeneralAction.sga_action_by_who_per_id] 
            for(let l = 0; l < by_who.length; l++){
                await addHistoricalUserOption('action_by_who', vm.employeeList, by_who[l], vm.currentGeneralAction.sga_action_by_who_per_full_name[l])
            }
         
            await addHistoricalOption('action_type', vm.actionTypeList, vm.currentGeneralAction.sga_action_type_rld_id, vm.currentGeneralAction.sga_action_type_ltr_text)
            if(vm.currentGeneralAction.attachments){
                let image_index = 0
                vm.currentGeneralAction.attachments.forEach((attachment) => {                    
                    if(attachment.com_comment !='' && attachment.com_comment != null){
                        let elem = document.getElementById('disk_comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('disk_comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                    image_index++
                })
            }
            $scope.$apply()
        }

        const addHistoricalOption =  function (select, list, rld_id, ltr_text) {
            
            return new Promise((resolve, reject) => {
                if(rld_id && !list.some(t => t.rld_id === rld_id))
                {
                    let historicRecord = {}
                    historicRecord['rld_historical']= true
                    historicRecord['rld_id']= rld_id
                    let value = `${ltr_text} (${translateTag(8717)})` //Historical
                    if(select === 'general_job_number'){
                        historicRecord['fullJob']= value
                    }
                    else{
                        historicRecord['rld_name']= value
                    }
                    list.push(historicRecord)
                }
                if(select === 'general_site'){
                    vm.getJobsLevels('edit')
                }                
                resolve(rld_id)
            })
        }

        const addHistoricalUserOption =  function (select, list, per_id, full_name) {
            return new Promise((resolve, reject) => {
                if(per_id && !list.some(t => t.per_id === per_id))
                {
                    let historicRecord = {
                        per_historical: true,
                        per_id: per_id,
                        per_full_name: `${full_name} (${translateTag(8717)})` //Historical                      
                    }
                    list.push(historicRecord)                 
                }
                resolve(per_id)
            })
        }

        $scope.$on('GENERAL_NEW_INCIDENT', () => {            
            if(vm.headerData.submission_header.length > 0){
                createGeneralAction()
                let h_data = vm.headerData.submission_header[0]                
                vm.currentGeneralAction.HeaderDate = h_data.Header_date
                vm.currentGeneralAction.Supervisor = parseInt(h_data.supervisor)
                vm.currentGeneralAction.Workplace = h_data.workplace
                let check_site = vm.siteList.find(rec => rec.rld_id === h_data.site);                
                if(check_site){                    
                    vm.currentGeneralAction.Site = h_data.site
                    vm.getJobsLevels()
                }
                let check_job = vm.jobList.find(rec => rec.rld_id === h_data.jobnumber);
                if(check_job){
                    vm.currentGeneralAction.JobNumber = h_data.jobnumber
                    vm.getFilteredEmployees()
                }
                let check_level = vm.levelList.find(rec => rec.rld_id === parseInt(h_data.sitelevel));                
                if(check_level){
                    vm.currentGeneralAction.SiteLevel = parseInt(h_data.sitelevel)
                }
                $scope.$apply()                
            }            
        })                

        vm.componentTranslateLabels = (key) => {
            return translateTag(key)
        }

        vm.showGroupIndividual= () => {
            return (vm.canAssignMultipleUsersToActions==true && vm.currentGeneralAction.sga_action_by_who_per_id.length > 1)
        }
        
        vm.changeActionByWho = () => {
            if(vm.currentGeneralAction.sga_action_by_who_per_id && vm.currentGeneralAction.sga_action_by_who_per_id.length > 1 && vm.mode ==='edit') {
                vm.currentGeneralAction.sga_is_group_action = 'group'
            }
        }

        vm.disableGroupIndividual = () => {
            return (vm.mode == 'edit')
        }
        //Function to refresh all data
        function refreshData() {
            $q.all([
                listService.getSelectListData('ref_site'),
                listService.getSelectListData('ref_job'),
                listService.getSelectListData('ref_level'),
                listService.getSelectListData('ref_general_action'),
                profileService.getAllEmployeeProfile(),
                profileService.getAllSupervisorProfile(),
                profileService.getDistributionList(),
                employeesService.getPersonProfile()
            ]).then((data) => {
                createGeneralAction()
                vm.siteList = data[0]
                vm.jobList = data[1]
                vm.jobList.forEach((job)=>{
                    job.fullJob = `(${job.rld_code}) - ${job.rld_name}`
                })
                vm.levelList = data[2]
                vm.actionTypeList = data[3]                
                vm.current_user_id = data[7].per_id                  
            }).then((data)=>{                
                vm.populateSettingsData()
            })                      
        }

        vm.populateSettingsData = () => {
            settingsService.getUserProfile(vm.current_user_id).then((response) => {
                vm.siteList.forEach((rec)=>{
                    if(response.upr_site===rec.rld_id){
                        vm.currentGeneralAction.Site = response.upr_site
                        vm.getJobsLevels()
                    }
                })
                vm.jobList.forEach((rec)=>{
                    if(response.upr_job==rec.rld_id){
                        vm.currentGeneralAction.JobNumber = response.upr_job
                        vm.getFilteredEmployees()
                    }
                })
                vm.levelList.forEach((rec) => {
                    if(response.upr_level === rec.rld_id){
                        vm.currentGeneralAction.SiteLevel = response.upr_level
                    }
                })
                vm.supervisorList = vm.supervisorList ? vm.supervisorList : []
                vm.supervisorList.forEach((rec)=>{
                    if(response.upr_supervisor_per === rec.per_id){
                        vm.currentGeneralAction.Supervisor = response.upr_supervisor_per
                    }
                })
                if(response.distribution_list){
                    let email_list = []
                    response.distribution_list.forEach((d)=>{
                        email_list.push(d.email)
                    })                   
                    vm.currentGeneralAction.distribution = email_list
                }

            })
        }


        // refreshData()


        vm.AddComments = (index, from) => {  
            document.getElementById('mode').innerHTML = ''
            document.getElementById('relatedimageindex').innerText = index
            document.getElementById('callingform').innerText = 'CLOSEGENERALACTIONIMAGECOMMENTSMODAL'
            document.getElementById('parentform').innerHTML = 7 // SubmissionHap Module	SubmissionHAPAttachments
            document.getElementById('savetomemory').innerHTML = "true"   

            vm.ImageFrom = from

            if(vm.mode ==='edit'){                

                if(vm.ImageFrom=='disk'){
                    // updating the comments only from the disk                    
                    vm.editAttachmentIndex = index
                    if(vm.currentGeneralAction.attachments[index].com_comment || vm.currentGeneralAction.attachments[index].com_id){                    
                        document.getElementById('mode').innerText = vm.mode
                        document.getElementById('savetomemory').innerHTML = "false"                      
                        document.getElementById('comment_id').innerHTML = vm.currentGeneralAction.attachments[index].com_id
                        document.getElementById('imageid').innerHTML = vm.currentGeneralAction.attachments[index].gaa_id  
                        document.getElementById('condition').innerHTML = ''
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS", vm.currentGeneralAction.attachments[index].com_comment)                        
                    } 
                    else{
                        document.getElementById('mode').innerText = vm.mode
                        document.getElementById('savetomemory').innerHTML = "false"
                        document.getElementById('condition').innerHTML = 'AddCommentOnEmptyExistingImage'
                        document.getElementById('comment_id').innerHTML = vm.currentGeneralAction.attachments[index].com_id                        
                        document.getElementById('imageid').innerHTML = vm.currentGeneralAction.attachments[index].gaa_id  
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS", vm.currentGeneralAction.attachments[index].com_comment)     

                    }
                }
                else if(vm.ImageFrom=='memory'){
                    if(vm.newInitialAttachments[index].comment){
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.newInitialAttachments[index].comment.com_comment)
                        document.getElementById('comment').value = vm.newInitialAttachments[index].comment.com_comment
                    }
                    else{
                        document.getElementById('imageid').innerHTML = ''
                        $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                        document.getElementById('comment').value = ''
                    }
                }
                else{
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                }
            }
            else{
                if(vm.newInitialAttachments[index].comment){
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.newInitialAttachments[index].comment.com_comment)
                    document.getElementById('comment').value = vm.newInitialAttachments[index].comment.com_comment
                }else{
                    document.getElementById('imageid').innerHTML = ''
                    $rootScope.$broadcast("RECIEVEROFCOMMENTS",'')
                    document.getElementById('comment').value = ''
                }
            } 
        }

        $scope.$on('CLOSEGENERALACTIONIMAGECOMMENTSMODAL',(event,data) => { 
            let image_index = document.getElementById('relatedimageindex').innerText            
            if(vm.mode==='edit'){
                if(vm.ImageFrom=='disk'){                    
                    vm.currentGeneralAction.attachments[vm.editAttachmentIndex].com_comment= data.com_comment 
                    vm.currentGeneralAction.attachments[vm.editAttachmentIndex].com_id=data.com_id    
                    
                    if(vm.currentGeneralAction.attachments[vm.editAttachmentIndex].com_comment !='' && vm.currentGeneralAction.attachments[vm.editAttachmentIndex].com_comment != null){
                        let elem = document.getElementById('disk_comment_' + image_index)                        
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('disk_comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                    
                }
                else if(vm.ImageFrom =='memory'){
                   
                    vm.newInitialAttachments[image_index].comment = data
                    vm.newInitialAttachments[image_index].comment.com_reference_id = image_index

                    if(vm.newInitialAttachments[image_index].comment){
                        if(vm.newInitialAttachments[image_index].comment.com_comment !=''){
                            let elem = document.getElementById('comment_' + image_index)
                            elem.classList.remove('far')
                            elem.classList.add('fas')
                        } else {
                            let elem = document.getElementById('comment_' + image_index)
                            elem.classList.remove('fas')
                            elem.classList.add('far') 
                        }
                    }
                }
            }
            else
            {
                // let image_index = document.getElementById('relatedimageindex').innerText
                vm.newInitialAttachments[image_index].comment = data
                vm.newInitialAttachments[image_index].comment.com_reference_id = image_index
                
                if(vm.newInitialAttachments[image_index].comment){
                    if(vm.newInitialAttachments[image_index].comment.com_comment !=''){
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('far')
                        elem.classList.add('fas')
                    } else {
                        let elem = document.getElementById('comment_' + image_index)
                        elem.classList.remove('fas')
                        elem.classList.add('far') 
                    }
                }
            }

        })
        
    //End of controller
    }
})