angular
    .module('safeToDo')
    .service('employeeReviewAnnualService', ['$http',
        function ($http) {            
            return {                
                createEmployeeReviewAnnual: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/wafs/form-submission-engine/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create Employee Annual Review', errorParams)
                    })
                },
            //END
            }        
        }
    ])