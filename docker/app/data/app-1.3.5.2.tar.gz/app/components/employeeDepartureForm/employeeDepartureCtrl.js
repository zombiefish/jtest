safeToDo.component("form372328", {
    // styling found in avatar.css
    templateUrl: 'app/components/employeeDepartureForm/employeeDeparture.html',
    bindings: {
        modalId: '<',
        allData: '<',
        mode: '<',
        incidentId: '<',
        onSave: '&',
        onClose: '&'
    },
    controllerAs: 'vm',
    controller: function ($scope,$rootScope, $q, employeeDepartureService, listService, modalService, profileService, adminUserService, $compile, employeesService, settingsService) {
        let vm = this
        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        vm.siteList = []
        vm.reasonDepartureList = []
        vm.employeePerformanceSafetyList = []
        vm.employeePerformanceAttendanceList = []
        vm.employeePerformanceAttitudeList = []
        vm.employeePerformanceCareList = []
        vm.assetsCollectedList = []
        vm.jobList = []
        vm.jobListSelect = []
        vm.levelList = []
        vm.levelListSelect = []
        vm.employeeList = []
        vm.supervisorList = []
        vm.distributionList = []
        vm.target = ''
        vm.mainButton = null
        vm.current_user_id = null
        vm.positions = []

        //Function to reset form
        function resetForm () {
            document.forms['employeeDepartureForm'].classList.remove('was-validated')
            vm.submitted = false
            vm.reason_departure_option = null
            vm.currentEmpDep = {
                form_name: '2178',//EMPLOYEE DEPARTURE
                employee_name: null,
                site: null,
                job_number: null,
                level: null,    
                workplace: '',
                supervisor: null,                           
                headerdate: dateToday.format("YYYY-MM-DD"),
                departure_date: dateToday.format("YYYY-MM-DD"),
                employee_position: null,
                reason_departure: null, 
                provide_notice: null,
                pay_mining_bonus: '',
                pay_zero_harm: '',
                other_reasons: '',
                departure_code: '',
                performance_safety: null,
                performance_attendance: null,
                performance_attitude: null,
                performance_care: null,
                recommended_rehire: '',
                assets_collected: [],
                arrangement_assets: false,
                additional_information: '',
                Report_Distribution1: []
            }
        }

        //Function to create the employee Departure
        vm.createEmpDisc = () => {
            let payload = preparePayload(JSON.parse(JSON.stringify(vm.currentEmpDep)))
            if(vm.validateForm()) {
                vm.submitted = true
                employeeDepartureService.createEmployeeDeparture(payload).then ((response) =>{
                    vm.closeModal('form-372328')
                    $scope.$emit('REFRESH_FORMSUBMISSIONS')

                })
            } else {
                $rootScope.$broadcast("CALLCONFIRMMODAL")
            }
        }
        //Function to get jobs at a site
        vm.getJobsLevels = () => {
            let mainSite = vm.currentEmpDep.site != undefined ? vm.currentEmpDep.site : null
            vm.currentEmpDep.job_number = null
            vm.currentEmpDep.level = null            
            vm.jobListSelect = []
            vm.levelListSelect = []
            vm.jobList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id === mainSite)
                    vm.jobListSelect.push(rec)
            })
            vm.levelList.forEach((rec) => {
                if(rec.rld_parent_detail_rld_id === mainSite)
                    vm.levelListSelect.push(rec)
            })
            
        }

        //Function to prepare payload data
        function preparePayload(payload) {
            let preparedPayload = payload
            preparedPayload.arrangement_assets = preparedPayload.arrangement_assets === true ? 'True' : 'False'
            if((preparedPayload.reason_departure == "Quit [E00]" || preparedPayload.reason_departure == "Code E - Quit") && preparedPayload.provide_notice == "0"  || preparedPayload.reason_departure == "Dismissal"  || preparedPayload.reason_departure == "Code M - Dismissal"){
                preparedPayload.pay_mining_bonus = preparedPayload.pay_mining_bonus === true ? 'True' : 'False'
                preparedPayload.pay_zero_harm = preparedPayload.pay_zero_harm === true ? 'True' : 'False'
            }
            preparedPayload.headerdate = moment(payload.headerdate, 'YYYY-MM-DDThh:mm').format('YYYY-MM-DDThh:mm')
            return preparedPayload
        }


        //Function to close the modal
        vm.closeModal = (modalId) => {    
            modalService.Close(modalId)
            resetForm()        
            refreshData()
            vm.employeeList = []
            vm.supervisorList = []
            vm.distributionList = []
        }

        //Function for form validation
        vm.validateForm = () => { 
            resetFormFieldClassList('employeeDepartureForm')
            return validateFormFields('employeeDepartureForm')
         }

        $scope.$on('distribution-list-added', (event, args) => {
            if(vm.currentEmpDep !== undefined) 
                $scope.$emit('addDistributionGroup', args, vm.currentEmpDep.Report_Distribution1)
        })

        $scope.$on('distribution-list-removed', (event, args) => {
            $scope.$emit('removeDistributionGroup', args)
        })

        vm.changeReasonOption = () =>{            
            //initialize the choosed items
            vm.currentEmpDep.other_reasons=vm.currentEmpDep.provide_notice =vm.currentEmpDep.pay_mining_bonus= vm.currentEmpDep.pay_zero_harm= null
            if (vm.currentEmpDep.reason_departure){
                vm.reason_departure_option = vm.reasonDepartureList.find((data) => data.rld_name===vm.currentEmpDep.reason_departure).rld_option
            } else {
                vm.reason_departure_option = null
            }
        }

        vm.componentTranslateLabels = (key) => {
            return translateTag(key)
        }

        vm.getFilteredEmployees = () =>{
            if(vm.currentEmpDep.job_number)
            {
                profileService.filterEmployeeListonJob(vm.currentEmpDep.job_number)
                vm.employeeList =  profileService.readFilterEmployeeListonJob()
                profileService.filterSupervisorListonJob(vm.currentEmpDep.job_number)
                vm.supervisorList = profileService.readFilterSupervisorListonJob()
                profileService.filterDistributionListonJob(vm.currentEmpDep.job_number)
                vm.distributionList = profileService.readFilterDistributionListonJob()
                concatenateEmployeeNumber()
            }
        }

        // Function to concatenate employee_number to name for Employee Dropdown options
        function concatenateEmployeeNumber () {
            if(vm.employeeList != undefined && vm.employeeList.length > 0){
                vm.emp_dpr_employeeList = []
                vm.emp_dpr_employeeList = JSON.parse(JSON.stringify(vm.employeeList))
                vm.emp_dpr_employeeList.forEach((emp)=>{
                    if (emp.employee_number){
                        emp.per_full_name = emp.employee_number + ' - ' + emp.per_full_name
                    }
                })
            }            
        }

        //Function to refresh all data
        function refreshData() {
            $q.all([
                listService.getSelectListData('ref_site'),
                listService.getSelectListData('ref_job'),
                listService.getSelectListData('ref_level'),
                listService.getSelectListData('ref_reason_departure'),
                listService.getSelectListData('ref_employee_performance'),
                listService.getSelectListData('ref_assets_collected'),
                profileService.getAllEmployeeProfile(),
                profileService.getAllSupervisorProfile(),
                profileService.getDistributionList(),
                profileService.getAllHumanResourceList(),
                adminUserService.getPositions(selectedLanguage),
                employeesService.getPersonProfile()                
            ]).then((data) => {
                resetForm()
                vm.siteList = data[0]                
                vm.jobList = data[1]
                vm.levelList = data[2]
                vm.reasonDepartureList = data[3]
                vm.reasonDepartureList=vm.reasonDepartureList.sort((a, b) => a.rld_name.toString().localeCompare(b.rld_name.toString(), selectedLanguage, {ignorePunctuation: true}))  //alphabetic
                vm.employeePerformanceSafetyList = data[4]
                vm.employeePerformanceAttendanceList = data[4]
                vm.employeePerformanceAttitudeList = data[4]
                vm.employeePerformanceCareList = data[4]
                vm.assetsCollectedList = data[5]
                // vm.employeeList = profileService.readAllEmployeeProfile()
                // vm.supervisorList = profileService.readAllSupervisorProfile()  
                // vm.distributionList = profileService.readDistributionList()
                vm.positions = adminUserService.getPositionList()
                vm.current_user_id = data[11].per_id
            }).then((data)=>{
                settingsService.getUserProfile(vm.current_user_id).then((response) => {
                    vm.siteList.forEach((rec)=>{
                        if(response.upr_site===rec.rld_id){
                            vm.currentEmpDep.site = response.upr_site
                            vm.getJobsLevels()
                        }
                    })
                    vm.jobList.forEach((rec)=>{
                        if(response.upr_job==rec.rld_id){
                            vm.currentEmpDep.job_number = response.upr_job
                            vm.getFilteredEmployees()
                        }
                    })                    
                    vm.supervisorList.forEach((rec)=>{
                        if(response.upr_supervisor_per === rec.per_id){
                            vm.currentEmpDep.supervisor = rec.per_id
                        }
                    })
                    if(response.distribution_list){
                        let email_list = []
                        response.distribution_list.forEach((d)=>{
                            email_list.push(d.email)
                        })                   
                        vm.currentEmpDep.Report_Distribution1 = email_list
                    }
                })
            })      
        }

        refreshData()

        function getEmployeeName(value) {
            let name = value
            vm.employeeList.forEach((emp)=>{
            if(emp.per_id == value) {
                name = emp.per_full_name
            }
            })
            return name
        }
    }    
})