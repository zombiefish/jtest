﻿'use strict';
safeToDo.component("confirmModal", {
  templateUrl: 'app/components/confirmModal/confirmModal-component.html',
  bindings: {
    // formName: '<',
    // savetomemory: '<'
},
  controllerAs: 'vm',
  controller: function ($compile, $scope, $rootScope,$q, $element,modalService) {
      var vm = this;

      vm.componentTranslateLabels = (key) => {
        return translateTag(key)
      }

      $scope.$on("CALLCONFIRMMODAL", (event,Data) => {
        if(Data){
          vm.modalElements=Data
        }
        else{
          vm.modalElements = {
            title: translateTag(2182),   //warning
            message: `<div><p>${translateTag(2183)}</p>
            <p>${translateTag(9266)}</p>
            <h3><table class="table"><tr><td>{{</td><td>}}</td><td>==</td><td>===</td><td>&&</td><td>- -</td><td>++</td><td>||</td><td>//</td><td>*/</td><td>/*</td></tr></table></h3></div>`,  //"The form has fields that need attention. Please see fields marked in red."
            buttons: `<button class='btn btn-primary btn-rounded' ng-click="vm.closeModal()" note="OK">{{vm.componentTranslateLabels(1405)}}</button>` 
          }
        }
        $('#confirmModal .message').html($compile(vm.modalElements.message)($scope)) 
        $('#confirmModal .buttons').html($compile(vm.modalElements.buttons)($scope))
        setTimeout(() => {
            modalService.Open('confirmModal');
            $scope.$apply();
        }, 500)
      })

      vm.closeModal = () => {
        if(document.getElementById('confirmcallingform').innerHTML=='UPDATESBULKTRAININGCALLCONFIRMMODAL'){
          vm.return('button2')
        }
        else if(document.getElementById('confirmcallingform').innerHTML=='LINEUPSUBMITCALLCONFIRMMODAL'){
          vm.return('button1')
        }
        else{
          modalService.Close('confirmModal');
        }        
       }

       vm.return  = (button) => {
        let behaviour = document.getElementById('confirmcallingform').innerHTML
          $rootScope.$broadcast(behaviour,button)
       }

      // end of controller
    }
})