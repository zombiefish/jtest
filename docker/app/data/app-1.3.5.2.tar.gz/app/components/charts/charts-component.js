﻿'use strict';

$(document).ready(function () {
    //The language object is global and it can't be set on each chart initiation. Instead, use Highcharts.setOptions to set it before any chart is initiated.
    //http://api.highcharts.com/highcharts/lang
    Highcharts.setOptions({
        lang: sofvie_highCharts_languages[`${selectedLanguage}`]
    });
});

safeToDo.component("stdDonutChart", {
    bindings: {
        title: '@',
        count: '<',
        data: '<',
        valueClicked: '&'
    },
    templateUrl: 'app/components/charts/donut-chart.html',
    controllerAs: 'vm',
    controller: function ($scope, $element, $timeout, $filter) {
        var vm = this;
        var elem = $($element);
        var chart;

        var titleStyleOptions = JSON.parse(JSON.stringify({
            "fontSize": "60px",
            "line-height": "75px",
            "font-weight": "600",
						"fontFamily": "Roboto"
        }));

        var subtitleStyleOptions = JSON.parse(JSON.stringify({
            "fontSize": "16px",
            "line-height": "20px"
        }));

        function updateTitleStyle(count) {
            var countLen = (count + '').length;
            if (countLen > 4) {
                titleStyleOptions.fontSize = "42px";
            } else {
                titleStyleOptions.fontSize = "60px";
            }
        }

        vm.$onInit = function () {
            $timeout(function () {
                //DOM has finished rendering
                buildChart();
                redrawchart();
            },1000);

        };

        vm.$onChanges = function (changesObj) {
            if (changesObj.count && changesObj.count.currentValue != null && chart) {
                updateTitleStyle(changesObj.count.currentValue);
                var titleOptions = { text: $filter('number')(changesObj.count.currentValue, 0), style: titleStyleOptions };
                if (chart.title)
                    chart.title.update(titleOptions);
                else {
                    chart.setTitle(titleOptions);
                }
            }
            if (chart && changesObj.data && changesObj.data.currentValue[0].y != null) {
                chart.series[0].setData(changesObj.data.currentValue);
            }
            if (chart && changesObj.title && changesObj.title.currentValue != null) {
                chart.setTitle(null, { text: changesObj.title.currentValue });
            }
        };

        function redrawchart() {
            var w = $('.chart-sizer-container .chart-sizer').first().width();
            
            var width = w;
            var height = width * (3 / 4);
            // setsize will trigger the graph redraw 
            chart.setSize(
                width, height, true
            );

            var fontSizeSubtitle = width < 300 ? "12" : "16";
            chart.title.update({
                y: height / 2 - 5
            });

            chart.subtitle.update({
                y: height / 2 + 15
                ,style: { fontSize: fontSizeSubtitle + 'px' }
            });
        }

        $(window).resize(redrawchart);

        $scope.$on('menu-width-changed', function () {
            $timeout(function () {
                redrawchart();
            }, 200);
        });

        function buildChart() {
            var containerId = 'container-' + vm.title;
            updateTitleStyle(vm.count);
            chart = Highcharts.chart(containerId, {
                chart: {
                    type: 'pie',
                    marginTop: 10
                },
                credits: { enabled: false },
                title: {
                    text: $filter('number')(vm.count, 0),
                    style: titleStyleOptions,
                    floating: true,
                    align: 'center',
                    x: 0,
                    y:200
                },
                subtitle: {
                    text: vm.title.toUpperCase(),
                    style: subtitleStyleOptions,
                    floating: true,
                    align: 'center',
                    x: 0,
                    //y: 160
                },
                exporting: { enabled: false },
                plotOptions: {
                    pie: {
                        shadow: false,
                        cursor: 'pointer',
                    }
                },
                tooltip: { valueSuffix: '' },
                series: [{
                    name: vm.title,
                    data: vm.data,
                    size: '75%',
                    innerSize: '85%',
                    dataLabels: {
                        formatter: function () {
                            // display only if larger than 1
                            return this.y > 0 && this.point.name != 'Zero_state' ? this.point.name + ': ' +
                                this.y : null;
                        },
                        distance: 10,
                        style: {
                            "color": '#6B6866;',
                           
                            "fontWeight": "400"
                        }
                    },
                    point: {
                        events: {
                            click: function (event) {
                                vm.valueClicked({ event: this });
                            }
                        }
                    }
                }]
            });
        };
    }
});

safeToDo.component("homeDonutChart", {
    bindings: {
        title: '@',
        count: '<',
        data: '<',
        valueClicked: '&'
    },
    templateUrl: 'app/components/charts/donut-chart.html',
    controllerAs: 'vm',
    controller: function ($scope, $element, $timeout, $filter) {
        var vm = this;
        var elem = $($element);
        var chart;

        var titleStyleOptions = JSON.parse(JSON.stringify({
            "fontSize": "60px",
            "line-height": "60px",
						"font-weight": "600",
						"fontFamily": "Roboto"
        }));

        var subtitleStyleOptions = JSON.parse(JSON.stringify({
            "fontSize": "16px",
            "line-height": "20px"
        }));

        function updateTitleStyle(count) {
            var countLen = (count + '').length;
            if (countLen > 4) {
                titleStyleOptions.fontSize = "42px";
            } else {
                titleStyleOptions.fontSize = "60px";
            }
        }

        vm.$onInit = function () {
            $timeout(function () {
                //DOM has finished rendering
                buildChart();
            }, 1000);

        };

        vm.$onChanges = function (changesObj) {
              if (changesObj.count && changesObj.count.currentValue != null && chart) {
                updateTitleStyle(changesObj.count.currentValue);
                var titleOptions = { text: $filter('number')(changesObj.count.currentValue, 0), style: titleStyleOptions };
                if (chart.title)
                    chart.title.update(titleOptions);
                else {
                    chart.setTitle(titleOptions);
                }
            }
            if (chart && changesObj.data && changesObj.data.currentValue[0].y != null) {
                chart.series[0].setData(changesObj.data.currentValue);
            }
            if (chart && changesObj.title && changesObj.title.currentValue != null) {
                chart.setTitle(null, { text: changesObj.title.currentValue });
            }
        };

        function redrawchart() {
            var w = $('.chart-sizer-container .chart-sizer').first().width();

            var width = w;
            var height = width * (3 / 4);
            // setsize will trigger the graph redraw 
            chart.setSize(
                width, height, true
            );

            var fontSizeSubtitle = width < 300 ? "12" : "16";
            chart.title.update({
                y: height / 2 - 5
            });

            chart.subtitle.update({
                y: height / 2 + 15
                , style: { fontSize: fontSizeSubtitle + 'px' }
            });
        }

      //  $(window).resize(redrawchart);

        $scope.$on('menu-width-changed', function () {
            $timeout(function () {
             //   redrawchart();
            }, 200);
        });

        function buildChart() {
             var containerId = 'container-' + vm.title;
          updateTitleStyle(vm.count);

          let donutChartOptions = {
            chart: {
              type: 'pie',
              marginTop: 10
            },
            credits: { enabled: false },
          //  colors: ['#0E6AC1', '#C0D7C5', '#097392', '#7FB5DB', '#FE9B56', '#B6D2EA', '#D55535', '#E59998', '#234234', '#FFF07C', '#D782B8', '#EF798A', '#20639B'],
            title: {
              text: $filter('number')(vm.count, 0),
              style: titleStyleOptions,
              floating: true,
              align: 'center',
              x: 0,
              y: 210
            },
            subtitle: {
              text: vm.title,
              style: subtitleStyleOptions,
              floating: true,
              align: 'center',
              x: 0,
              y: 150
            },
            exporting: { enabled: false },
            plotOptions: {
              pie: {
                shadow: false,
                cursor: 'pointer',
              },
              series: {
                colorByPoint: true
            }
            },
            tooltip: { valueSuffix: '' },
            series: [{
              name: vm.title,
              data: vm.data,
              size: '75%',
              innerSize: '85%',
              dataLabels: {
                formatter: function () {
                  // display only if larger than 1
                  return this.y > 0 && this.point.name != 'Zero_state' ? this.point.name + ': ' +
                    this.y : null;
                },
                distance: 10,
                style: {
                  "color": '#6B6866;',
                  "fontWeight": "400"
                }
              },
              point: {
                events: {
                  click: function (event) {
                    vm.valueClicked({ event: this });
                  }
                }
              }
            }]
          }
          Highcharts.setOptions({
       //     colors: ['#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4']
          });
          chart = Highcharts.chart(containerId, donutChartOptions );
        };
    }
});

safeToDo.component("stdDonutChart2", {
    bindings: {
        chartName: '<',
        title: '<',
        count: '<',
        data: '<',
        valueClicked: '&'
    },
    templateUrl: 'app/components/charts/donut-chart-2.html',
    controllerAs: 'vm',
    controller: function ($scope, $element, $timeout, $filter) {
        var vm = this;
        var elem = $($element);
        var chart;

        var titleStyleOptions = JSON.parse(JSON.stringify({
            "fontSize": "60px",
            "color": "#6B6866",
            "line-height": "75px",
            "font-weight": "300"
        }));

        var subtitleStyleOptions = JSON.parse(JSON.stringify({
            "fontSize": "16px",
            "color": "#6B6866", 
            "line-height": "20px"
        }));

        vm.$onInit = function () {
            $timeout(function () {
                //DOM has finished rendering

                buildChart();
                redrawchart();
            });

        };

        vm.$onChanges = function (changesObj) {
            if (changesObj.count && changesObj.count.currentValue != null && chart) {
                var titleOptions = { text: $filter('number')(changesObj.count.currentValue, 1), style: titleStyleOptions };
                if (chart.title)
                    chart.title.update(titleOptions);
                else {
                    chart.setTitle(titleOptions);
                }
            }
            if (chart && changesObj.data && changesObj.data.currentValue[0].y != null) {
                chart.series[0].setData(changesObj.data.currentValue);
            }
            if (chart && changesObj.title && changesObj.title.currentValue != null) {
                chart.setTitle(null, { text: changesObj.title.currentValue });
            }
        };

        function redrawchart() {
            var w = $('#container-' + vm.chartName).closest('.widget').width();

            var width = w;
            var height = width * (3 / 4);
            // setsize will trigger the graph redraw 
            chart.setSize(
                width, height, true
            );

            var fontSizeSubtitle = width < 300 ? "12" : "16";
            chart.title.update({
                y: height / 2 - 5
            });

            chart.subtitle.update({
                y: height / 2 + 15
                , style: { fontSize: fontSizeSubtitle + 'px' }
            });
        }

        $(window).resize(redrawchart);

        $scope.$on('menu-width-changed', function () {
            $timeout(function () {
                redrawchart();
            }, 200);
        });

        function buildChart() {
            var containerId = 'container-' + vm.chartName;
            chart = Highcharts.chart(containerId, {
                chart: {
                    type: 'pie',
                    width: 400,
                    height: 300,
                    marginTop: 10
                },
                credits: { enabled: false },
                title: {
                    text: $filter('number')(vm.count, 0),
                    style: titleStyleOptions,
                    floating: true,
                    align: 'center',
                    x: 0,
                    y: 140
                },
                subtitle: {
                    text: vm.title.toUpperCase(),
                    style: subtitleStyleOptions,
                    floating: true,
                    align: 'center',
                    x: 0,
                    y: 160
                },
                exporting: { enabled: false },
                plotOptions: {
                    pie: {
                        shadow: false,
                        cursor: 'pointer',
                    }
                },
                tooltip: { valueSuffix: '' },
                series: [{
                    name: vm.title,
                    data: vm.data,
                    size: '75%',
                    innerSize: '85%',
                    dataLabels: {
                        formatter: function () {
                            // display only if larger than 1
                            return this.y > 0 && this.point.name != 'Zero_state' ? this.point.name + ': ' +
                                this.y : null;
                        },
                        distance: 10,
                        style: {
                            "color": '#6B6866;',
                            "fontWeight": "400"
                        }
                    },
                    point: {
                        events: {
                            click: function (event) {
                                vm.valueClicked({ event: this });
                            }
                        }
                    }
                }]
            });
        };
    }
});

safeToDo.component("stdAreaChart", {
    template: `
                <div id="container-{{vm.title}}"></div>
                `,
    bindings: {
        title: '<',
        series1: '<',
        series2: '<',
        series3: '<',
        valueClicked: '&'
    },
    controllerAs: 'vm',
    controller: function ($scope, $element, $timeout, $filter) {
        var vm = this;
        var elem = $($element);
        var chart;

        var titleStyleOptions = JSON.parse(JSON.stringify({
            "fontSize": "60px",
            "color": "#6B6866",
            "line-height": "75px",
            "font-weight": "300"
        }));

        var subtitleStyleOptions = JSON.parse(JSON.stringify({
            "fontSize": "16px",
            "color": "#6B6866",
            "line-height": "20px"
        }));

        function updateTitleStyle(count) {
            var countLen = (count + '').length;
            if (countLen > 5) {
                titleStyleOptions.fontSize = "42px";
            } else {
                titleStyleOptions.fontSize = "60px";
            }
        }

        vm.$onInit = function () {
            $timeout(function () {
                //DOM has finished rendering
                buildChart();
            });

        };

        vm.$onChanges = function (changesObj) {
            if (changesObj.count && changesObj.count.currentValue != null && chart) {
                updateTitleStyle(changesObj.count.currentValue);
                var titleOptions = { text: $filter('number')(changesObj.count.currentValue, 0), style: titleStyleOptions };
                if (chart.title)
                    chart.title.update(titleOptions);
                else {
                    chart.setTitle(titleOptions);
                }
            }
            if (chart && changesObj.series1) {
                if (changesObj.series1.currentValue[0] != null)
                    chart.series[0].setData(changesObj.series1.currentValue);
                else
                    chart.series[0].setData([]);

            }
            
            if (chart && changesObj.series2) {
                if (changesObj.series2.currentValue[0] != null) 
                    chart.series[1].setData(changesObj.series2.currentValue);
                else
                    chart.series[1].setData([]);
            }
            
            if (chart && changesObj.series3) {
                if (changesObj.series3.currentValue[0] != null) 
                    chart.series[2].setData(changesObj.series3.currentValue);
                else
                    chart.series[2].setData([]);
            }
        };

        $(window).resize(function () {
            redraw();
        });

        $scope.$on('menu-width-changed', function () {
            $timeout(function () {
                redraw();
            }, 200);
        });

        function redraw() {
            var widthChartGroup = $('.trend-charts.hap-trends').width();
            var widthChartInfo = $('.trend-charts.hap-trends .chart-info').width();
            chart.setSize(
                widthChartGroup - widthChartInfo - 130, undefined, true
            );
        };

        function buildChart() {
            var containerId = 'container-' + vm.title;
            updateTitleStyle(vm.count);
            chart = Highcharts.chart(containerId, {
                chart: {
                    type: 'area'
                },
                credits: { enabled: false },
                title: {
                    text: ''
                },
                legend: {
                    itemStyle: {
                        color: '#2E2D2C',
                        fontSize: '14px',
                        lineHeight: '18px',
                        fontWeight: '400'
                    },
                    labelFormat: "{name}",
                },
                xAxis: {
                    title: {
                        text: translateTag(124)
                    },
                    type: 'datetime',
                    dateTimeLabelFormats: {
                        day: '%e of %b'
                    }

                },
                yAxis: {
                    title: {
                        text: translateTag(817)
                    },
                    labels: {
                        formatter: function () {
                            return this.value;
                        }
                    }
                },
                tooltip: {
                    pointFormat: '{series.name} score <b>{point.y:,.0f}</b>'
                },
                plotOptions: {
                    area: {
                        marker: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 3,
                            states: {
                                hover: {
                                    enabled: true
                                }
                            }
                        }
                    },
                    series: {
                        fillOpacity: 0.1,
                    }
                },
                series: [{
                        name: translateTag(1158),
                        data: vm.series1,
                        color: '#E33E3E'
                    },
                    {
                        name: translateTag(1144),
                        data: vm.series2,
                        color: '#4A90E2'
                    },
                    {
                        name: translateTag(1067),
                        data: vm.series3,
                        color: '#8EC229'
                    }
                ]
            });
        };
    }
});

safeToDo.component("stdBarChart", {
    template: `
                <div id="container-{{vm.chartTitle}}" style=" border-top: none;"></div> 
                `,
    bindings: {
        chartTitle: '<',
        series1: '<',
        series2: '<',
        series3: '<',
        series4: '<',
        categories: '<',
        formIds: '<',
        valueClicked: '&'
    },
    controllerAs: 'vm',
    controller: function ($scope, $element, $timeout, $filter, $location) {
        var vm = this;
        var elem = $($element);
        var chart;

        vm.$onInit = function () {
            $timeout(function () {
                //DOM has finished rendering
                buildChart();
            });

        };

        vm.$onChanges = function (changesObj) {
            if (chart && changesObj.categories) {
                chart.xAxis[0].setCategories(changesObj.categories.currentValue);
            }
            if (chart && changesObj.series1) {
                if (changesObj.series1.currentValue[0] != null)
                    chart.series[0].setData(changesObj.series1.currentValue);
                else
                    chart.series[0].setData([]);

            }
            if (chart && changesObj.series2) {
                if (changesObj.series2.currentValue[0] != null)
                    chart.series[1].setData(changesObj.series2.currentValue);
                else
                    chart.series[1].setData([]);
            }
            if (chart && changesObj.series3) {
                if (changesObj.series3.currentValue[0] != null)
                    chart.series[2].setData(changesObj.series3.currentValue);
                else
                    chart.series[2].setData([]);
            }
            if (chart && changesObj.series4) {
                if (changesObj.series4.currentValue[0] != null)
                    chart.series[3].setData(changesObj.series4.currentValue);
                else
                    chart.series[3].setData([]);
            }
            $(window).trigger("resize", 99);
            $(window).trigger("resize", 100);
        };

        $(window).resize(function () {
         //   chart.reflow();
        });

        function buildChart() {
            var containerId = 'container-' + vm.chartTitle;
            chart = Highcharts.chart(containerId, {
                chart: {
                    type: 'bar',
                    spacingBottom: 20,
                    spacingTop: 20,
                    spacingLeft: 20,
                    spacingRight: 20,
                },
                title: {
                    text: null
                },
                xAxis: {
                    categories: vm.categories,
                    title: {
                        text: null
                    },
                    labels: {
                        style: {
                            color: '#2E2D2C',
                            fontSize: '14'
                        }
                    }
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: null,
                    },
                    labels: {
                        overflow: 'justify'
                    }
                },
                legend: {
                    layout: 'horizontal',
                    align: 'center',
                    verticalAlign: 'bottom',
                },
                credits: {
                    enabled: false
                },
                series: [{
                    name: 'Targets (You)',
                    data: vm.series1,
                    color: '#D3D824'
                }, {
                    name: 'Actuals (You)',
                    data: vm.series2,
                    color: '#4A90E2'
                },
                {
                    name: 'Targets (Company Average)',
                    data: vm.series3,
                    color: '#ffaf08'
                }, {
                    name: 'Actuals (Company Average)',
                    data: vm.series4,
                    color: '#1cd2dc'
                }],
                plotOptions: {
                    series: {
                        cursor: 'pointer',
                        events: {
                            click: function (event) {
                                var t = this;

                                var formId = vm.formIds[event.point.index];

                                $location.url('/a/forms/' + formId);
                                $scope.$apply();
                            }
                        }
                    }
                }
            });
        };
    }
});

safeToDo.component("stdGaugeChart", {
    template: `
                <div id="container-{{vm.chartTitle}}"></div>
                `,
    bindings: {
        chartTitle: '<',
        series1: '<',
        ymax: '<'
    },
    controllerAs: 'vm',
    controller: function ($scope, $element, $timeout, $filter, $location) {
        var vm = this;
        var elem = $($element);
        var chart;

        vm.$onInit = function () {
            $timeout(function () {
                //DOM has finished rendering
                buildChart();
            });

        };

        vm.$onChanges = function (changesObj) {
            if (chart && changesObj.series1) {
                if (changesObj.series1.currentValue[0] != null)
                    chart.series[0].setData(changesObj.series1.currentValue);
                else
                    chart.series[0].setData([]);

            }
            if (chart && changesObj.ymax) {
                chart.yAxis[0].update({
                    max: changesObj.ymax.currentValue
                }); 
            }
        };

        var gaugeOptions = {

            chart: {
                type: 'solidgauge'
            },

            title: null,

            pane: {
                center: ['50%', '85%'],
                size: '140%',
                startAngle: -90,
                endAngle: 90,
                background: {
                    backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || '#EEE',
                    innerRadius: '60%',
                    outerRadius: '100%',
                    shape: 'arc',
                    backgroundColor: '#FFF',
                    shape: 'arc',
                    //borderColor: '#fff'
                }
            },

            tooltip: {
                enabled: false
            },

            // the value axis
            yAxis: {
                stops: [
                    [0.1, '#55BF3B'], // green
                    [0.5, '#55BF3B'], // green
                    [0.7, '#DDDF0D'], // yellow
                    [0.9, '#DF5353'] // red
                ],
                lineWidth: 0,
                minorTickInterval: null,
                tickAmount: 2,
                title: {
                    y: -50
                },
                labels: {
                    y: 16
                }
            },

            plotOptions: {
                solidgauge: {
                    dataLabels: {
                        y: 5,
                        borderWidth: 0,
                        useHTML: true
                    }
                }
            }
        };

        function buildChart() {
            var containerId = 'container-' + vm.chartTitle;
            chart = Highcharts.chart(containerId, Highcharts.merge(gaugeOptions, {
                yAxis: {
                    min: 0,
                    max: vm.ymax,
                    title: {
                        text: null
                    }
                },

                legend: {
                    align: 'right',
                    verticalAlign: 'top',
                    layout: 'vertical',
                    x: 0,
                    y: 100
                },

                credits: {
                    enabled: false
                },

                series: [{
                    name: 'Days to Completion',
                    data: vm.series1, //[60],
                    dataLabels: {
                        format: '<div style="text-align:center"><span style="font-size:25px;color:' +
                        ((Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black') + '">{y}</span><br/>' +
                        '<span style="font-size:14px;color:silver">Average days taken to complete an action</span></div>'
                    },
                },

                ]

            }));
        };
    }
});