﻿angular
    .module('safeToDo')
    .service('homeService', ['$http',
        function ($http) {
          let actionsData = []
          let openActionsCount = 0
          let openIncidentCount = 0  
          let incidentBreakdownCount = 0       
          let submissionsData = []
          let submissionsCompanyData = []
          let hazardDountData = []
          let potentialsDountData = []
          let actionDountData = []
          let targetCountData = {}
          let actionCountData = {}
          let incidentCountData = {}
          let documentCountData = {}

          let colors = {
                new: '#666666',
                inProgress: '#5EB500',
                imported: '#5EB500',
                received: '#0E98E7',
                inReview: '#F78200',
                released: '#F78200',
                pending: '#DF4343',
                sent: '#F78200',
                onHold: '#DF4343',
                complete: '#0E98E7',
                zeroState: '#eeeeee',
                red: '#E33E3E',
                blue: '#4A90E2',
                yellow: '#D3D824',
                green: '#8EC229',
                orange: '#F5A623'
            }

          function getOnlyOpenActionCount(data) {
                let count = 0;
            for (let a = 0; a < data.length; a++) {
              if (data[a].Status !== 'COMPLETE') {
                     count++
                  }
              }
                return (count)
          }

          function getOnlyOpenActions(data) {
            let newActions = []
            for (let a = 0; a < data.length; a++) {
              if (data[a].Status !== 'COMPLETE') {
                newActions.push(data[a])
              }
            }
            return (newActions)
          }

          return {
                getActionsFP: (filter) => {
                    return $http.post(`${__env.apiUrl}/api/action/get-action-list-by-condition/`, filter).then((response) => {
                    actionsData = getOnlyOpenActions(response.data);
                        }, (args) => {
                            console.log('Failed to load actions.', args)
                        })
                    },

                getHazardDonut: (filter) => {
                    return $http.post(`${__env.apiUrl}/api/donut-charts/hazard-donut/`, filter).then((response) => {
                        hazardDountData = response.data
                    }, (args) => {
                        console.log('Failed to load hazard data.', args)
                    })
                },

                getPotentialsDonut: (filter) => {
                    return $http.post(`${__env.apiUrl}/api/donut-charts/potential-risk-donut/`, filter).then((response) => {
                        potentialsDountData =  response.data
                    }, (args) => {
                        console.log('Failed to load potentials data .', args)
                    })
                },   

                getActionDonut: (filter) => {
                    return $http.post(`${__env.apiUrl}/api/donut-charts/action-type-donut/`, filter).then((response) => {
                        actionDountData =  response.data
                    }, (args) => {
                        console.log('Failed to load actions data.', args)
                    })
                                
                }, 
                getOpenActionsFP: (filter) => {
                    allFilter = JSON.parse(JSON.stringify(filter))
                    allFilter.CreatedBy = "%"
                    allFilter.CompletedByMe = false
                    allFilter.StartDate = '2017-01-01'
                    allFilter.EndDate = '2020-12-31'
                    return $http.post(`${__env.apiUrl}/api/action/get-action-list-by-condition/`, filter).then((response) => {
                        openActionsCount = getOnlyOpenActionCount(response.data)
                        openActionsData = getOnlyOpenActions(response.data)
                        }, (args) => {
                                console.log('Failed to load actions.', args)
                        })
                    },

                getPersonOpenActionsCount: (filter) =>{
                    return $http.post(`${__env.apiUrl}/api/action/get-open-action-count-by-person_date/`, filter).then((response) => {
                        openActionsCount = response.data[0]
                    }, (args) => {
                        console.log('Failed to personal open action count.', args)
                    });
                },

                getPersonIncidentCount: (filter) =>{
                    return $http.post(`${__env.apiUrl}/api/incident-management/get-open-incident-count-by-person_site_date/`, filter).then((response) => {
                        openIncidentCount = response.data[0].incidentCountOnSites
                    }, (args) => {
                        console.log('Failed to personal incident count.', args)
                    });
                },  

                getIncidentBreakdown: (filter) =>{
                    return $http.post(`${__env.apiUrl}/api/incident-management/get-incident-breakdown-by-person_site_date/`, filter).then((response) => {
                        incidentBreakdownCount = response.data[0]
                    },(args) => {
                        console.log('Failed to incident Breakdowns', args)
                    });
                },

                // getTargetCountData: () => {
                //     return $http.get(`${__env.apiUrl}/api/drm/get-all-targets-counts/`).then((response) => {
                //         targetCountData = response.data
                //     }, (args) => {
                //         console.log('Failed to load Target Count Data', args)
                //     });
                // },

                getActionCountData: () => {
                    return $http.get(`${__env.apiUrl}/api/action/get-all-actions-counts/`).then((response) => {
                        actionCountData = response.data
                    }, (args) => {
                        console.log('Failed to load Action Count Data', args)
                    })
                },

                getTargetCountData: () => {
                    return $http.get(`${__env.apiUrl}/api/target/get-all-targets-statistics/`).then((response) => {
                        targetCountData = response.data
                    }, (errorParams) => {
                        console.log('Failed to load Action Count Data', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                        }
                    })
                },            

                getIncidentCountData: () => {
                    return $http.get(`${__env.apiUrl}/api/incident-management/get-all-incidents-counts/`).then((response) => {
                        incidentCountData = response.data
                    }, (args) => {
                        console.log('Failed to load Incident Count Data', args)
                    })
                },

                getDocumentCountData: () => {
                    return $http.get(`${__env.apiUrl}/api/drm/get-all-documents-counts/`).then((response) => {
                        documentCountData = response.data
                    }, (args) => {
                        console.log('Failed to load Document Count Data', args)
                    });
                },

                getHazardReportedData: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/home/get-hazard-reported-by-role/`, payload).then((response) => {
                        return response.data
                    }, (args) => {
                        console.log('Failed to load Hazard reported data', args)
                    });
                },

                getHomeDashboardData: () => {
                    return $http.get(`${__env.apiUrl}/api/home/get-home-dashboard_data/`).then((response) => {
                        return response.data
                    }, (args) => {
                        console.log('Failed to load Hazard dashboard data', args)
                    });
                },
                getHomeAllRoleList: (mode = "active") => {                
                    return $http.get(`${__env.apiUrl}/api/sofvie-auth/get-role-list/${mode}/`).then((response) =>{
                       return response.data
                    }, (errParams) => {
                        if(errParams.status === 403 && errParams.data.detail)
                        {
                            return false
                        }
                    })
                }, 

                readTargetCountData: () => {
                    return targetCountData
                },

                readActionCountData: () => {
                    return actionCountData
                },

                readIncidentCountData: () => {
                    return incidentCountData
                },

                readDocumentCountData: () => {
                    return documentCountData
                },

                readHazardDonut:() =>{
                        return hazardDountData
                    },

                readPotentialsDonut:()=> {
                    return potentialsDountData
                },

                readActionDonut:() => {
                    return actionDountData
                },

                readActionsData: () => {
                    return actionsData
                },

                readAllActionsData: () => {
                    return allActionsData
                },

                readPersonOpenActionsCount: () => {
                    return openActionsCount
                },

                readPersonIncidentCount: () => {
                    return openIncidentCount
                },
                readIncidentBreakdown: () => {
                    return  incidentBreakdownCount
                },

                readSubmissionsData: () => {
                    return submissionsData
                },

                readCompanySubmissionsData: () => {
                return submissionsCompanyData
                },

                readValidForms: () => {
                    let formsDataA = []
                    Object.keys(actualsData).forEach((key, index) => {
                        formsDataA.push(key)
                    })
                    Object.keys(targetsData).forEach((key, index) => {
                        if (!formsDataA.includes(key)) {
                            formsDataA.push(key)
                        }
                    })
                        return formsDataA
                    },

                readActualsData: () => {
                    let forms = this.readValidForms();
                    let actualsDataA = []
                    Object.keys(targetsData).forEach((key, index) => {
                        if (actualsData[key] > 0) {
                            actualsDataA.push(actualsData[key])
                        }
                        else {
                            actualsDataA.push(0)
                        }
                    })
                    return actualsDataA
                    },

                readTargetsData: () => {
                    let targetsDataA = []
                    Object.keys(targetsData).forEach((key, index) => {
                        targetsDataA.push(targetsData[key])
                    })
                    return targetsDataA
                },

                readActualsAllData: () => {
                    let actualsDataA = []
                    Object.keys(targetsAllData).forEach((key, index) => {
                        if (actualsAllData[key] > 0)
                            actualsDataA.push(actualsAllData[key])
                        else
                            actualsDataA.push(0)
                    })
                    return actualsDataA
                },

                readTargetsAllData: () => {
                    let targetsDataA = []
                    Object.keys(targetsAllData).forEach((key, index) => {
                        targetsDataA.push(targetsAllData[key])
                    });

                    return targetsDataA
                },

                readTurnaroundTimeData: () => {
                    let turnaroundTimeDataA = []
                    let zero_state = false
                    if (turnaroundTimeData.error) {
                        zero_state = true
                        turnaroundTimeDataA.push({ name: 'No data', y: 0, color: colors.zeroState })
                    }
                    else {
                        turnaroundTimeDataA.push({ name: 'Actual', y: turnaroundTimeData.actualDaysToCorrect, color: colors.orange })
                        turnaroundTimeDataA.push({ name: 'Planned', y: turnaroundTimeData.plannedDaysToCorrect, color: colors.blue })
                    }
                    return turnaroundTimeDataA
                },

                readTurnaroundTimeAllData: () => {
                    let turnaroundTimeAllDataA = []
                    let zero_state = false

                    if (turnaroundTimeAllData.error) {
                        zero_state = true
                        turnaroundTimeAllDataA.push({ name: 'No data', y: 0, color: colors.zeroState })
                    }
                    else {
                        turnaroundTimeAllDataA.push({ name: 'Actual', y: turnaroundTimeAllData.actualDaysToCorrect, color: colors.orange })
                        turnaroundTimeAllDataA.push({ name: 'Planned', y: turnaroundTimeAllData.plannedDaysToCorrect, color: colors.blue })
                    }

                    return turnaroundTimeAllDataA
                },

                readTurnaroundTimeYMax: () => {
                        return turnaroundTimeYMax
                    },

                readTurnaroundTimeDonutData: () => {
                        let turnaroundTimeDataA = []
                        let zero_state = false
                        if (turnaroundTimeData.length == 0 && turnaroundTimeAllData.length == 0) {
                            zero_state = true
                            newData.push({ name: 'No data', y: 0, color: colors.zeroState })
                        }
                        else {
                            turnaroundTimeDataA.push({ name: 'You', y: turnaroundTimeData.actualDaysToCorrect, color: colors.orange })
                            turnaroundTimeDataA.push({ name: 'Company', y: turnaroundTimeAllData.actualDaysToCorrect, color: colors.blue })
                        }
                        return turnaroundTimeDataA
                },
            }
        }
    ])