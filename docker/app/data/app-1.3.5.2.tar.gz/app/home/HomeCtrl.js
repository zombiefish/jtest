﻿function getTextWidth(text, font) {
    // re-use canvas object for better performance
    var canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement("canvas"));
    var context = canvas.getContext("2d");
    context.font = font;
    var metrics = context.measureText(text);
    return metrics.width;
}
angular
    .module('safeToDo')
    .controller('HomeCtrl', ['select2Service', '$timeout', '$scope', '$rootScope', '$sce', '$q', '$window', '$location', 'homeService', 'menuService' , 'listService', 'employeesService', 'adminTrifrService', 'profileService',
      function (select2Service,$timeout, $scope, $rootScope, $sce, $q, $window, $location, homeService, menuService, listService, employeesService, adminTrifrService, profileService) {
        let vm = this
        vm.homePageName = JSON.parse($window.localStorage.getItem('token')).user_full_name
        vm.defaultselectedSites= []
        vm.defaultUserProfileSites= []
        vm.mobileDisabled = true
        vm.siteList = []
        vm.rolesList = []
        vm.defaultPersonRole = 0
        vm.loadMessage = translateTag(8300)
        $scope.$emit('STARTSPINNER', vm.loadMessage)
        vm.toolTipSites = ''
        vm.isSelectAll = false
        vm.canCreatePrelimaryIncident = false
        vm.canCreatePrelimaryInvestigation = false
        vm.defaultJobs = []
        vm.jobList = []
        vm.allUsers = []

        selectAll()

        $rootScope.$on("MOBILE-LOADED", (event,result) => {
            vm.mobileDisabled = false
            $scope.$digest()
        })

        //Function to initialize select2
        vm.initializeSelect2 = (parent, section='') => {
            $timeout(() => {
            $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} ${section}`), escapeMarkup: function (text) { return text }})
                .on('select2:select', () => {
                    $(this).parent().find('label').addClass('filled');
                })
            $('.select2-selection__arrow b').addClass("fa fa-caret-down");
            select2Service.select2Tags_2_max()
            }, 500)
        }

        $('#home_site').change(function(){
            if($("#home_site option[value='-1']").is(':selected')){
                if(!vm.isSelectAll){
                    selectAll()
                    vm.isSelectAll = true
                }
                else{
                    deSelectAll()
                    vm.isSelectAll = false
                }
            }
        })

        function selectAll(){
            $('#home_site option').prop('selected', true)
            $("#home_site option[value='-1']").prop('selected', false)
        }

        function deSelectAll(){
            $('#home_site option').prop('selected', false)
            $("#home_site option[value='-1']").prop('selected', false)
        }

        vm.initializeSelect2("siteselection")    

        // setting the homepage permissions
        vm.setHomePermissions = () => {
            //Get permissions for the user
            menuService.getPagePermissions().then((data) => {
                vm.permissions = data
                vm.canViewLineup = vm.permissions.includes('Can View Lineup') ? true : false
            })

            // setting permission for create Preliminary Investigation and Preliminary Incident
            menuService.getCreateMobileFormsPermission().then((permissions) => {
                if(permissions.data.find((list) => list.FormID == 224335)){
                    vm.canCreatePrelimaryIncident = true  
                }
                if(permissions.data.find((list) => list.FormID == 220234)){
                    vm.canCreatePrelimaryInvestigation = true  
                }
            })
        }

        vm.setHomePermissions()



        // Function to redirect to the lineup page
        vm.openLineup = () => {            
            $location.path('/a/lineup')
        }
       
        bindSiteControl()

        function bindSiteControl(){
            $q.all([
                employeesService.getPersonProfile(),
                listService.getSelectListData('ref_site'),
                homeService.getHomeAllRoleList(),
                homeService.getHomeDashboardData(),
                adminTrifrService.getTrifrTrirTrackOption(),
                listService.getAllJobListByDataVisibility(),
                profileService.getAllEmployeeProfile(),
            ]).then((data) => {
                vm.getUserProfile = data[0]
                vm.siteList = data[1]
                if(vm.siteList && vm.siteList.length>0){
                    var select = document.getElementById("home_site")
                    var option = document.createElement('option')
                    option.text =  translateTag(8684)
                    option.value =  -1
                    select.add(option, 0)
                }
                vm.rolesList = data[2]
                vm.dashboardData = data[3].output
                vm.track_trifr = data[4]
                vm.dashboardLine1 = $sce.trustAsHtml(vm.dashboardData.line1.line)
                vm.dashboardLine2 = $sce.trustAsHtml(vm.dashboardData.line2.line)
                vm.dashboardLine3 = $sce.trustAsHtml(vm.dashboardData.line3.line)
                vm.dashboardLine4 = $sce.trustAsHtml(vm.dashboardData.line4.line)
                if(vm.getUserProfile.siteIds != null && vm.getUserProfile.siteIds){
                    if(vm.getUserProfile.siteIds.length > 0){
                        vm.defaultselectedSites = vm.getUserProfile.siteIds.split(', ').map(element => {
                            return Number(element)
                        })
                        vm.defaultUserProfileSites = vm.defaultselectedSites

                        vm.toolTipSites = vm.getUserProfile.sites
                    } 
                }
                if(vm.getUserProfile.jobsIds != null && vm.getUserProfile.jobsIds){
                    if(vm.getUserProfile.jobsIds.length > 0){
                        vm.defaultJobs = vm.getUserProfile.jobsIds.split(', ').map(element => {
                            return Number(element)
                        })                       
                    } 
                }

                if(vm.getUserProfile.role_ids != null && vm.getUserProfile.role_ids){
                    if(vm.getUserProfile.role_ids.length > 0)
                        vm.defaultPersonRole = vm.getUserProfile.role_ids.split(",")[0]
                }

                // 1 - Jobs are not select in profile means need to select all jobids for selected sites
                // 2 - identify the jobs for the user profile
                vm.refJobs = listService.readJobsByDataVisibility() 
                setDefaultJobIds()

                let supervisors = profileService.readAllEmployeeProfile()
                vm.allUsers.length = 0;
                for (var i = 0; i < supervisors.length; i++) {
                    vm.allUsers.push(supervisors[i].per_id);
                }

                $window.sessionStorage.removeItem("homePagePersonList")
                $window.sessionStorage.setItem("homePagePersonList", vm.allUsers)
            }).then(()=> {
                $window.sessionStorage.removeItem("homePageJobList")
                $window.sessionStorage.setItem("homePageJobList", vm.jobList)
                $window.sessionStorage.removeItem("homePageSiteList")
                $window.sessionStorage.setItem("homePageSiteList", vm.defaultselectedSites)  
                $rootScope.$broadcast("PIDCOUNTCOMPONENT",vm.defaultselectedSites)
                $rootScope.$broadcast("RECENTPIDCOMPONENT",vm.defaultselectedSites)
                $rootScope.$broadcast("DAYSSINCELASTINCIDENT",vm.defaultselectedSites)
                $rootScope.$broadcast("DAYSSINCELASTINJURY",vm.defaultselectedSites)
                $rootScope.$broadcast("HAZARDREPORTEDCOMPONENT",vm.defaultselectedSites)
                $rootScope.$broadcast("HAZARDCOMPONENT",vm.defaultselectedSites)
                $rootScope.$broadcast("TRIFRCHARTSCOMPONENT",vm.defaultselectedSites)
                $rootScope.$broadcast("OPENINCIDENTSCOMPONENT",vm.defaultselectedSites)
                $rootScope.$broadcast("OPENACTIONSCOMPONENT",vm.defaultselectedSites)
                $rootScope.$broadcast("ACTIONSBYROLECOMPONENT",vm.defaultselectedSites, vm.rolesList, vm.defaultPersonRole)              

                vm.initializeSelect2("siteselection")
                $scope.$emit('STOPSPINNER')
            })
        }
         
        // button click for selected sites 
        vm.siteApplyFilter = () =>{
            $q.all([
                setDefaultJobIds()
            ]).then(()=> {
                $window.sessionStorage.removeItem("homePageJobList")
                $window.sessionStorage.setItem("homePageJobList", vm.jobList)
                $window.sessionStorage.removeItem("homePageSiteList")
                $window.sessionStorage.setItem("homePageSiteList", vm.defaultselectedSites)
                $rootScope.$broadcast("PIDCOUNTCOMPONENT",vm.defaultselectedSites)
                $rootScope.$broadcast("RECENTPIDCOMPONENT",vm.defaultselectedSites)
                $rootScope.$broadcast("DAYSSINCELASTINCIDENT",vm.defaultselectedSites)
                $rootScope.$broadcast("DAYSSINCELASTINJURY",vm.defaultselectedSites)
                $rootScope.$broadcast("HAZARDREPORTEDCOMPONENT",vm.defaultselectedSites)
                $rootScope.$broadcast("HAZARDCOMPONENT",vm.defaultselectedSites)
                $rootScope.$broadcast("TRIFRCHARTSCOMPONENT",vm.defaultselectedSites)   
                $rootScope.$broadcast("OPENINCIDENTSCOMPONENT",vm.defaultselectedSites)
                $rootScope.$broadcast("OPENACTIONSCOMPONENT",vm.defaultselectedSites)
                $rootScope.$broadcast("ACTIONSBYROLECOMPONENT",vm.defaultselectedSites, vm.rolesList,  vm.defaultPersonRole)
                // get site to display in tooltip
                vm.getSiteSelectedTooltip()
            })
        }

        function setDefaultJobIds(){
            vm.jobList = []
            if(vm.defaultselectedSites && vm.defaultselectedSites.length > 0){
                vm.defaultselectedSites.forEach(siteEle => {     
                        let jobsIdsForSite = []
                        // checking the selected site is part of the default site - for data visibility
                        if(vm.defaultUserProfileSites.includes(siteEle)){
                            let jobForSite = vm.refJobs.filter(item => {return item.rld_parent_detail_rld_id==siteEle})
                        
                            // job objects to integer rld_id
                            jobForSite.forEach(job => {
                                jobsIdsForSite.push(job.rld_id)
                            })
                        }  
                        // 'allJobsOnSite' all jobs in the selected site is present or not in the default array
                        let isJobExists = findJobExists(jobsIdsForSite)
                        vm.refJobs.forEach(jobEle => {                       
                            if(jobEle.rld_parent_detail_rld_id === siteEle){ // site matched
                                let isJobIdAvailable = vm.defaultJobs.includes(jobEle.rld_id) // job available or not in defaultjob array
                                if(vm.defaultJobs.length == 0 || isJobIdAvailable || !isJobExists){
                                    vm.jobList.push(jobEle.rld_id)
                                }
                            }
                        })
                    
                })
                vm.jobList = removeDuplicates(vm.jobList)
            } 
        }

        function findJobExists(alljobsonsite){
            let isExists = false

            // alljobsonsite.forEach(job => {
            for (let i = 0; i < alljobsonsite.length; i++) {
                isExists = vm.defaultJobs.includes(alljobsonsite[i])
                if(isExists == true) {break}
            }
            return isExists
        }

        function removeDuplicates(arr) {
            return arr.filter((item, 
                index) => arr.indexOf(item) === index);
        }

        vm.openForm = (activeFormID) =>{
            let message={activeFormID:null,incidentId:null,moduleId:null}    
            message.activeFormID=activeFormID
            $rootScope.$broadcast("OPENMOBILEFRAME", message)
        }

        vm.homePageRedirect = (navigateTo) => {
            if (navigateTo === 'actions'){
                vm.actionsRedirect()
            }else if (navigateTo === 'documents'){
                vm.documentsRedirect()
            }else if (navigateTo === 'incidents'){
                vm.incidentsRedirect()
            }else if (navigateTo === 'targets'){
                vm.targetsRedirect()
            }
        }

        vm.actionsRedirect = (filter = 'Person') => {            
            $location.path('/a/action-management')
            $window.sessionStorage.setItem('homepageRedirect_actionsFilter', filter)
        }

        vm.targetsRedirect = (filter = 'Person') => {
            $location.path('/a/toolbox')
            $window.sessionStorage.setItem('homepageRedirect_targetsFilter', filter)
        }

        vm.incidentsRedirect = (filter = 'Person') => {            
            $location.path('/a/tir')
            $window.sessionStorage.setItem('homepageRedirect_incidentsFilter', filter)
        }

        vm.documentsRedirect = (filter = 'Person') => {                        
            $location.path('/a/document-review')
            $window.sessionStorage.setItem('homepageRedirect_documentsFilter', filter)
        }

        //Refresh home page components when any form is submitted
        $scope.$on('REFRESH_FORMSUBMISSIONS', (event) => {
            $timeout(() => { vm.siteApplyFilter()
            }, 2000)
        })

        $('#siteselection').mouseover(function() { 
            $(this).attr('title', vm.toolTipSites)
        })

        vm.getSiteSelectedTooltip = () =>{
            vm.toolTipSites = ''
            vm.siteList.forEach((rec) => {
                if(vm.defaultselectedSites.indexOf(rec.rld_id) > -1){
                    vm.toolTipSites += rec.rld_name + '; '
                }
            })
        }
    }])