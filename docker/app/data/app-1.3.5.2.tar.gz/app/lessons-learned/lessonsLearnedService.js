angular
    .module('safeToDo')
    .service('lessonsLearnedService', ['$http',
        function ($http) {
            let lessonsList = []

            return {
                getLessonsList: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/llm/get-lesson-learned-list/`, payload).then((response) => {
                        lessonsList = response.data
                    }, (errorParams) => {
                        console.log('Failed to load Lessons', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail){
                            toastr.error(errorParams.data.detail)
                            lessonsList = []
                            window.location.href = "/";
                        }
                    })
                },
                getHazardActions: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/llm/get-lesson-learned-hazard-action/`, payload).then((response) => {
                         // permission validation check - "Can View Lessons Learned"
                         if(response.data.accessMsg){
                            toastr.error(response.data.accessMsg)
                            return []
                         }
                         else
                            return response.data
                    }, (errorParams) => {
                        console.log('Failed to load hazard actions', errorParams)
                    })
                },
                getGeneralActions: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/llm/get-lesson-learned-general-action/`, payload).then((response) => {
                        // permission validation check - "Can View Lessons Learned"
                        if(response.data.accessMsg){
                            toastr.error(response.data.accessMsg)
                            return []
                        }
                        else
                            return response.data
                    }, (errorParams) => {
                        console.log('Failed to load general actions', errorParams)
                    })
                },
                getLessonAttachments: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/llm/get-lessons-learned-attachments/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to load lesson attachments', errorParams)
                    })
                },

                createLesson: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/llm/add-lesson-learned/`, payload).then((response) => {
                       return response.data
                    }, (errorParams) => {
                        console.log('Failed to create lesson', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },
                updateLesson: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/llm/update-lesson-learned/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to update lesson', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },

                archiveLesson: (IdList) => {
                    var patchList = []
                    for (var i = 0; i < IdList.length; i++) {
                        patchList.push({ llm_id: IdList[i]})
                    }
                    return $http.post(`${__env.apiUrl}/api/llm/archive-lesson-learned/`, patchList).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to archive lesson', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })
                },

                acknowledgeLesson: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/llm/lesson-learned-acknowledged/`, payload).then((response) => {
                        // permission validation check - "Can Manage Lessons Learned"
                        if(response.data.accessMsg){
                            toastr.error(response.data.accessMsg)
                            return []
                        }
                        else
                             return response
                    }, (errorParams) => {
                        console.log('Failed to acknowledge lesson', errorParams)
                    })
                },
                unacknowledgeLesson: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/llm/lesson-learned-unacknowledged/`, payload).then((response) => {
                        // permission validation check - "Can Manage Lessons Learned"
                        if(response.data.accessMsg){
                            toastr.error(response.data.accessMsg)
                            return []
                        }
                        else
                             return response
                    }, (errorParams) => {
                        console.log('Failed to unacknowledge lesson', errorParams)
                    })
                },

                addLessonGeneralAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/llm/add-lesson-learned-general-action/`, payload).then((response) => {
                        if(response.data.accessMsg){
                        toastr.error(response.data.accessMsg)
                        return []
                        }
                        else
                            return response.data

                    }, (errorParams) => {
                        console.log('Failed to add lesson general action', errorParams)
                    })
                },
                addLessonHazardAction: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/llm/add-lesson-learned-hazard-action/`, payload).then((response) => {
                        // permission validation check - "Can Manage Lessons Learned"
                        if(response.data.accessMsg){
                            toastr.error(response.data.accessMsg)
                            return []
                            }
                            else
                                return response.data
                    }, (errorParams) => {
                        console.log('Failed to add lesson hazard action', errorParams)
                    })
                },

                addLessonAttachments: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/llm/add-lessons-learned-attachments/`, payload,{
                        // this cancels AngularJS normal serialization of request
                        transformRequest: angular.identity,
                        // this lets browser set `Content-Type: multipart/form-data` 
                        // header and proper data boundary
                        headers: {'Content-Type': undefined}}).then((response) =>{
                        return response
                    }, (errorParams) => {
                        console.log('Failed to add lesson attachment', errorParams)
                    })
                },
                removeLessonAttachments: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/llm/remove-lessons-learned-attachments/`, payload).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to lesson attachments', errorParams)
                    })
                }, 

                // Returns list 
                readLessonsList: () => {
                    return lessonsList
                },

            //End
            }
        }
    ])