angular
    .module('safeToDo')
    .controller('lessonsLearnedCtrl', ['$scope', '$timeout', '$q', '$window', '$sce', '$interval', 'gridService', 'select2Service',
      'lessonsLearnedService', 'listService', 'modalService', 'profileService', 'employeesService','menuService', 'actionManagementService', '$compile', 'documentLockService','imageCommentService','$rootScope', 'fileUploadService','exportCSV',
        function ($scope, $timeout, $q, $window, $sce, $interval, gridService, select2Service, lessonsLearnedService, listService, 
            modalService, profileService, employeesService, menuService, actionManagementService, $compile, documentLockService,imageCommentService, $rootScope, fileUploadService, exportCSV) {
            var vm = this
            
            let dateToday = moment(new Date(), 'YYYY-MM-DD')
            vm.employeeList = []
            vm.fullEmployeeList = []
            vm.currentAcknowledgeHistory = []
            vm.userId = null
            vm.siteList = []
            vm.jobList = []
            vm.jobListSelect = []
            vm.actionTypeList = []
            vm.singleServeReportUrl = 'lessons_learned'
            vm.LLDataContext = {}
            vm.topSearch = ''
            vm.archiveCount = 0
            vm.deleteAttCount = 0
            vm.lessonsData = []
            vm.attachmentData = []
            vm.uploadFileList= []
            vm.actionDisabled = true
            vm.attActionDisabled = true
            vm.canArchiveSubmissions = true
            vm.canManageLessonsLearned = true
            vm.lessonViewerOpen = false
            vm.hideingLessonViewer = false
            vm.openingLessonViewer = false
            vm.currentAcknowledge = null
            vm.loadMessage = translateTag(3585) //Loading lessons learned. Please wait.
            vm.generalEditData = {}
            vm.hazardEditData = {}
            vm.autoSave = null

            vm.continueEditing = false
            vm.leaveEditing = false
            vm.idletime = 0
            vm.countdownSeconds = 60
            
            vm.llm_show_check_box = false

            //Get permissions for the user
            menuService.getPagePermissions().then((data) => {
                vm.permissions = data

                vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
                vm.canManageLessonsLearned = vm.permissions.includes('Can Manage Lessons Learned') ? true : false
                vm.canManageActionItems = vm.permissions.includes('Can Manage Action Items') ? true : false
                vm.canCloseAllActions = vm.permissions.includes('Can Close All Actions') ? true : false
            })

            $scope.$on('DATERANGE', (range) => {
                vm.mainDateFilter = {
                    start_date: moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD'),
                    end_date: moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')
                }
                refreshData()
              })

            //Function to clear the form feilds
            vm.resetForm = () => {
                resetFormFieldClassList('lessonForm')
                vm.jobListSelect = []
                vm.attachmentData = []
                vm.submitted = false
                vm.currentLesson = 
                {
                    llm_id: null,
                    llm_site_rld: null,
                    llm_job_rld: null,
                    llm_title: '',
                    llm_scope: '',
                    llm_summary: '',
                    llm_success: '',
                    llm_opportunity: '',
                    llm_other_participant: '',
                    llm_is_submitted: false,
                    llm_created_by_per: null,
                    llm_date: dateToday.format("YYYY-MM-DD"),
                    participants: [],
                    participantsList: [],
                    actions: [],
                    general_actions: [],
                    hazard_actions: []
                }

                vm.dlo_id = null
                vm.docLockMessage = ''
                vm.docLockStatus = false
                vm.countdownSeconds = 60
                vm.lockCheckModal = false
                vm.continueEditing = false
                vm.idletime = 0
                vm.leaveEditing = false
                vm.llm_show_check_box = false
            }

            vm.getFilteredEmployees = () =>{            
                profileService.filterEmployeeListonJob(vm.currentLesson.llm_job_rld)
                vm.employeeList =  profileService.readFilterEmployeeListonJob()                
            }

            $scope.fileUploadChanged = (event)=> {

                //Add newly selected files after checking for duplicates and correct file types
                vm.uploadFileList = vm.uploadFileList.concat(fileUploadService.checkFileUpload(event.target.files, []))

                if(vm.uploadFileList.length > 0)
                    addAttachments()
            }

            //Function for the top search bar
            vm.topSearchChanged = () =>{
                vm.lessOptions.api.setQuickFilter(vm.topSearch)
            }

            //Function to open archive confirmation Modal
            vm.archiveConfirmationModal = () => {
                vm.archiveCount = vm.lessOptions.api.getSelectedRows().length
                vm.modalElementsArchive = {
                    title: translateTag(3574), //"Archive Lesson?"
                    message: `<div><p>${translateTag(3580)} ${vm.archiveCount} ${translateTag(3583)}</p></div>`, //"You are about to archive {{lessonsCtrl.archiveCount}} lessons. Undoing this will require IT support. Are you sure?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                }
                document.getElementById('confirmcallingform').innerHTML = 'LLARCHIVECALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsArchive)
            }

            $scope.$on("LLARCHIVECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.lessArchive()
                }
            })
    
            //Function to archive the selected rows
            vm.lessArchive = () => {
                var rows = vm.lessOptions.api.getSelectedRows()
                if (rows.length > 0) {
                    var ids = []
                    for (var i = 0; i < rows.length; i++) {
                        if (rows[i].dlo_status){
                            ids.push(rows[i].llm_id)
                        }
                        else{
                            // You cannot Archive while Document is being edited
                            throwToastr('warning',translateTag(9116),2000)
                        }
                    }
                    lessonsLearnedService.archiveLesson(ids).then((r) => {
                        refreshData()
                    })
                }    
                modalService.Close('confirmModal')
            }
    
            //Funtion to export the selected rows to CSV file
            vm.exportCSV = () => {                
                let rows = JSON.parse(JSON.stringify(vm.lessOptions.api.getSelectedRows()))
                exportCSV.export_csv(rows, translateTag(1036))
            }

            //Funtion to open a report in a new tab
            vm.viewReports = (e, id) =>{
                if(!e.ctrlKey){                    
                    lang_number = localStorage.getItem('lang_id')                    
                    vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.singleServeReportUrl}/${id}?lang=${lang_number}`)
                    $window.open(vm.reportURL, "_blank")
                }
            }

            //Funtion to open a attachment file in a new tab
            vm.openAttachment = (name) => {
                vm.attachmentURL =  $sce.trustAsResourceUrl(`${__env.imageUrl}/lessons_learned/${name}`)
                $window.open(vm.attachmentURL, "_blank")
            }

            //#region Funtions to convert ID to Name
            function getEmployeeName(value) {
                let name = value
                vm.fullEmployeeList.forEach((emp)=>{
                if(emp.per_id == value) {
                    name = emp.per_full_name
                }
                })
                return name
            }


            function getEmployeeNames(values  ) {
                if(values == null){
                    return ''
                } else {
                    let by_who = []
                    let len = values.length
                    for(let l = 0;l < len; l++) {
                        by_who.push(getEmployeeName(values[l]))
                    }
                    return by_who.join("; ")
                }
             }

            function getEmployeeID(value) {
                let nameID = value
                vm.fullEmployeeList.forEach((emp)=>{
                if(emp.per_full_name == value) {
                    nameID = emp.per_id
                }
            })
            return nameID
            }

            function getSiteName(value) {
                let name = value
                vm.site_name.forEach((s)=>{
                if(s.rld_id == value) {
                    name = s.rld_name
                }
                })
                return name
            }

            function getJobNumber(value) {
                let name = value
                vm.job_name.forEach((j)=>{
                if(j.rld_id == value) {
                    name = j.rld_code
                }
                })
                return name
            }
            //#endregion

            //Function to get jobs at site
            vm.getJobs = () => {
                let mainSite = null
                vm.currentLesson.llm_job_rld = null
                vm.jobListSelect = []
                mainSite = vm.currentLesson.llm_site_rld
                vm.jobList.forEach((rec) => {
                    if(rec.rld_parent_detail_rld_id == mainSite)
                        vm.jobListSelect.push(rec)
                })
            }

            vm.lessOptions = gridService.getCommonOptions()
            vm.attachmentOptions = gridService.getCommonOptions()
            //Function to disable action button if no rows are selected
            vm.lessOptions.onSelectionChanged = () => {            
                var selectedRows = vm.lessOptions.api.getSelectedRows()
                vm.actionDisabled = selectedRows.length == 0
                $scope.$apply()
            }
            vm.attachmentOptions.onSelectionChanged = () => {
                var selectedRows = vm.attachmentOptions.api.getSelectedRows()
                vm.attActionDisabled = selectedRows.length == 0
                $scope.$apply()
            }

            //Set Ag-Grid colum values/settings
            let lessColumns = [
                {
                    headerName: '',
                    field: 'dummyCheckbox',
                    maxWidth: 50,
                    minWidth: 50,
                    checkboxSelection: true,
                    suppressMenu: true,
                    suppressSorting: true,
                    headerCheckboxSelection: true,
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    field: "review",
                    headerName: " ",
                    minWidth: 125,
                    maxWidth: 125,
                    suppressMenu: true,
                    cellRenderer: (params) => {                     
                    return `<span ng-show="${params.data.llm_is_submitted}" ng-click="lessonsCtrl.signoff(data)" class="{{ data.hasAcknowledged ? 'text-success ' : 'pointer'}}" note="Review Submission" title="{{menu.translateLabels(3431)}}"><i class="far fa-file-alt fa-lg"></i></span>`
                        + `<span class="fa-1x fa-stack" style="width: 1.25em;" ng-class="{ transparent: ${!vm.canManageLessonsLearned}, pointer: ${vm.canManageLessonsLearned}}" ng-hide="${params.data.llm_is_submitted}" ng-click="lessonsCtrl.openViewer('edit', ${params.data.llm_id})"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title="{{menu.translateLabels(1194)}}"></i> <i ng-show="${!params.data.dlo_status}" class="fas fa-ban fa-stack-1x text-danger" note="is updating the document, please wait." title="${params.data.dlo_person} {{menu.translateLabels(3423)}}"></i></span>`
                        + `<span note="Submission Review History" title="{{menu.translateLabels(3430)}}" class="source signoff-count" ng-class="{ transparent: (!data.reviewedCount > 0 || !data.llm_is_submitted), pointer: (data.reviewedCount > 0 && data.llm_is_submitted) }" ng-click="lessonsCtrl.viewAcknowledgeHistory(data);">{{ data.reviewedCount }}</span>`
                        + `<span class="pointer text-left" ng-click="lessonsCtrl.viewReports($event, ${params.data.llm_id})"><i class="fa fa-external-link-alt" note="Launch Report" title="{{menu.translateLabels(3429)}}"></i></span>`
                    },
                    valueGetter: function (params) {
                        return params.data.reviewedCount
                    },
                },
                {
                    field: '',
                    hide: true,                
                    valueGetter: function (params) {
                        if (params.data.llm_is_submitted)
                            return '2_submitted'
                        else
                            return '1_Draft'
                    },
                    sort: 'asc',
                },
                {
                    field: "llm_submitted_date",
                    headerName: " ",
                    minWidth: 140,
                    maxWidth: 140,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                    sort: 'desc'
                },
                {
                    field: "llm_submitted_by_per",
                    headerName: " ",
                    minWidth: 100,
                    maxWidth: 150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',                    
                },
                {
                    field: "llm_title",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "llm_created_date",
                    headerName: " ",
                    minWidth: 120,
                    maxWidth: 120,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab']
                },
                {
                    field: "llm_site_rld",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 250,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',                
                },
                {
                    field: "llm_job_rld",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },                
                {
                    field: "participantsList",
                    headerName: " ",
                    minWidth: 200,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer'
                },
                {
                  field: "status",
                  headerName: " ",
                  maxWidth: 85,
                  minWidth: 85,
                  suppressMenu: false,
                  filter: 'agSetColumnFilter',
                  menuTabs: ['filterMenuTab'],
                  cellRenderer: 'tippyCellRenderer',
                  valueGetter: (params) => {
                      return params.data.llm_is_submitted == false ? translateTag(1399) : translateTag(3557) //Active
                  },                  
                },
                {field:"llm_id", hide:true},
                {field:"hasAcknowledged", hide:true},
                {field:"llm_created_by_per", hide:true},
                {field:"participantsList", hide:true},
                {field:"reviewersList", hide:true},
                {field:"reviewedCount", hide:true},
                {field:"llm_summary", hide:true},
                {field:"llm_success", hide:true},
                {field:"llm_scope", hide:true},
                {field:"llm_opportunity", hide:true},
                {field:"llm_other_participant", hide:true},
                {field:"llm_job_rld", hide:true},
                {field:"llm_is_submitted", hide:true},
                {field:"llm_created_date", hide:true},
                {field:"llm_modified_by_per", hide:true},
                {field:"llm_modified_date", hide:true},
            ]
            vm.lessOptions.columnDefs = lessColumns
            vm.lessOptions.defaultColDef = {
                cellStyle : (params) =>{
                    if(params.data.llm_is_submitted){
                        return { "cursor": "pointer !important"}
                    }
                } 
            }
            vm.lessOptions.onCellClicked  = (params) => {          
                if(params.column.colDef.field!=='review' && params.data.llm_is_submitted){
                    vm.openViewer('view', params.data.llm_id)
                }
            }

            let attachmentColumns = [
                {
                    headerName: '',
                    field: 'dummyCheckbox',
                    maxWidth: 50,
                    minWidth: 50,
                    checkboxSelection: (params) =>{
                        return params.data.lat_llm_show_check_box
                    }, 
                    suppressMenu: true,
                    suppressSorting: true,
                    headerCheckboxSelection: true,
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    //Added the id to the Ag-Grid and hid it. Used to sort the grid to show newest submissions first
                    field: 'lat_id',
                    hide: true,
                    sort: 'desc',
                },
                {
                    field: "lat_created_by_per",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',                    
                },
                {
                    field: "lat_created_date",
                    headerName: " ",
                    minWidth: 150,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "lat_file_name",
                    headerName: " ",
                    minWidth: 150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        return `<span class="pointer clip" ng-click='lessonsCtrl.openAttachment(${cleanDoubleCurly(JSON.stringify(params.value))})'><a class="source" href="#" ng-non-bindable>${params.value}</a></span>`
                    }              
                },   
                {
                    field:"comment",
                    headerName:"Comment",
                    minWidth:150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        if(params.data.com_id == null || params.data.com_comment=='' || params.data.com_comment==null){
                            return `<i class="far fa-comment pointer" note="Add Comment" title="{{menu.translateLabels(8921)}}" ng-click='lessonsCtrl.AddComments(${cleanDoubleCurly(JSON.stringify(params.data))})'></i>`
                        } else {
                            return `<i class="fa fa-comment pointer" note="Edit Comment" title="{{menu.translateLabels(9043)}}" ng-click='lessonsCtrl.AddComments(${cleanDoubleCurly(JSON.stringify(params.data))})'></i>`
                        }
                        
                    } 
                }      
            ]
            vm.attachmentOptions.columnDefs = attachmentColumns
            
            
            vm.AddComments=(data) =>{
                document.getElementById('mode').innerText = data.com_id
                document.getElementById('comment').value = data.com_comment ? data.com_comment.replaceAll("'","&#39") : null 
                document.getElementById('callingform').innerHTML= 'CLOSEIMAGECOMMENTSMODAL'
                document.getElementById('savetomemory').innerHTML = "false"
                document.getElementById('parentform').innerHTML = 2
                document.getElementById('imageid').innerText = data.lat_id    
                document.getElementById('comment_id').innerHTML = data.com_id 
                $rootScope.$broadcast("RECIEVEROFCOMMENTS", data.com_comment ) 
            }

            vm.signoff = (LLData) => {
                vm.LLDataContext = LLData
                if(LLData.hasAcknowledged) {
                    toastr.success(translateTag(3588)) //You have already acknowledged this Lesson
                } 
                else {   
                    vm.modalElementsAcknowledge = {
                        title: translateTag(3578), //"Lesson Review?"
                        message: `<div><p>${translateTag(3579)}</p></div>`, //"You are confirming that you have reviewed this Lesson. This cannot be undone. Continue?"
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Review">{{vm.componentTranslateLabels(1188)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                    }                 
                    document.getElementById('confirmcallingform').innerHTML = 'LLACKNOWLEDGECALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsAcknowledge)
                 }
            }
            
            $scope.$on("LLACKNOWLEDGECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.addAcknowledge()
                }
            })

            //Function to add/remove an acknowledgment to a lesson via the Ag-Grid
            vm.addAcknowledge = () => {
                let payload = {}
                payload.lla_llm_id = vm.LLDataContext.llm_id
                vm.currentAcknowledge = vm.LLDataContext
                    lessonsLearnedService.acknowledgeLesson(payload).then (() => {  
                        refreshData()
                        modalService.Close('confirmModal')
                    })
            }
    
            //Function to open the Acknowledge History modal
            vm.viewAcknowledgeHistory = (lessData) => {
                if(!lessData.reviewedCount > 0 || !lessData.llm_is_submitted)
                    return

                vm.currentAcknowledgeHistory = []
                lessData.acknowledgements.forEach((rev) => {
                    let acknowledgment = {
                        name: getEmployeeName(rev.lla_per),
                        reviewed_date: rev.lla_modified_date,
                        pos: rev.lla_position
                    }
                    vm.currentAcknowledgeHistory.push(acknowledgment)
                })
                $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentAcknowledgeHistory,translateLabels(3575)) //"Lesson Reviews"
            }

            //Function to check if the current user has Acknowledged this lesson
            function checkAcknowledged (lessData) {
                let response = false            
                lessData.acknowledgements.forEach((rev) => {
                    if(rev.lla_per == vm.userId)
                    {
                    response = true
                    }
                })
                return response
            }

            //Function to open the viewer
            vm.openViewer = (mode='new', id) => {
                
                // Activate Autosave
                if(mode !== 'view') {
                    vm.autosave = $interval(() => {
                        vm.saveLesson('autosave')
                       vm.mode = vm.currentMode
                    }, 20000)
                }


                if(!vm.canManageLessonsLearned)
                    return

                if(mode === 'new')
                {
                    vm.hideingLessonViewer = false
                    vm.lessonViewerOpen = true
                    vm.openingLessonViewer = true
                    vm.currentMode = 'new'
                    vm.initializeSelect2('newLessonLearned')
                    refreshAttachments()
                }
                else if(mode==='edit')
                {      
                    vm.documentDetails = {}
                    vm.documentDetails.dlo_document_id = id
                    vm.documentDetails.dlo_dlt_id = 7 //LLM
                    $q.all([
                        documentLockService.docLock(vm.documentDetails)
                    ]).then((response) => {
                        vm.dlo_id = response[0].dlo_id
                        vm.docLockStatus = response[0].status
                        vm.docLockMessage = response[0].message
                        vm.docLockTime = response[0].time
                        if (!vm.docLockStatus){
                            throwToastr('warning',vm.docLockMessage,2000)
                        }   
                    }).then(()=>{
                        if(vm.docLockStatus === true){
                            vm.currentMode = 'edit'
                            // implementing toastr with default timeout
                            toastr.options.progressBar = true
                            vm.hideingLessonViewer = false
                            vm.lessonViewerOpen = true
                            vm.openingLessonViewer = true
                            throwToastr('info', translateTag(3589), 3000) //Loading data...
                                    
                            vm.lessonsData.forEach((lessData)=>{
                                if(id == lessData.llm_id) {
                                    vm.currentLesson = JSON.parse(JSON.stringify(lessData))
                                    vm.jobListSelect = []
                                    let mainSite = vm.currentLesson.llm_site_rld
                                    vm.jobList.forEach((rec) => {
                                        if(rec.rld_parent_detail_rld_id == mainSite)
                                            vm.jobListSelect.push(rec)
                                    })
                                    if(vm.currentLesson.llm_job_rld){
                                        vm.getFilteredEmployees()
                                    }        
                                    vm.currentLesson.participants = getParticipants(vm.currentLesson.participants)
                                    vm.currentLesson.llm_date = moment(vm.currentLesson.llm_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                                    if(!vm.currentLesson.llm_is_submitted){
                                        vm.llm_show_check_box = true
                                    }

                                    refreshActions(lessData.llm_id)
                                    refreshAttachments(lessData.llm_id)
                                }
                            })

                            vm.initializeSelect2('newLessonLearned')
                            $timeout(() => {
                                vm.openingLessonViewer = false                
                            }, 400)
                            
                            startUpdateDocLock()
                            startLockModal()

                            //Zero the idle timer on mouse movement.
                            $('#newLessonLearned').mousemove(function (e) {
                                clearInterval(vm.lockModal)                
                                vm.idletime = 0
                                startLockModal()
                            });

                            //Zero the idle timer on keypres event
                            $('#newLessonLearned').keypress(function (e) {
                                clearInterval(vm.lockModal)
                                vm.idletime = 0
                                startLockModal()    
                            });
                        }
                    })          
                    
                }
                else if(mode==='view'){
                    toastr.options.progressBar = true
                            vm.hideingLessonViewer = false
                            vm.lessonViewerOpen = true
                            vm.openingLessonViewer = true
                            throwToastr('info', translateTag(3589), 3000) //Loading data...

                            vm.lessonsData.forEach((lessData)=>{
                                if(id == lessData.llm_id) {
                                    vm.currentLesson = JSON.parse(JSON.stringify(lessData))
        
                                    vm.jobListSelect = []
                                    let mainSite = vm.currentLesson.llm_site_rld
                                    vm.jobList.forEach((rec) => {
                                        if(rec.rld_parent_detail_rld_id == mainSite)
                                            vm.jobListSelect.push(rec)
                                    })
        
                                    vm.currentLesson.participants = getParticipants(vm.currentLesson.participants)
                                    vm.currentLesson.llm_date = moment(vm.currentLesson.llm_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
        
                                    refreshActions(lessData.llm_id)
                                    refreshAttachments(lessData.llm_id)
                                }
                            })

                            vm.initializeSelect2('newLessonLearned')
                            $timeout(() => {
                                vm.openingLessonViewer = false                
                            }, 400)
                }
            }

            // functions for document lock start__

            vm.continueEditingLLM = () => {
                modalService.Close('confirmModal')
                vm.countdownSeconds = 60
                vm.lockCheckModal = false
                vm.continueEditing = true
                document.getElementById('inactiveTime').textContent = ''
                clearInterval(vm.lockModal)
                clearTimeout(vm.relieveLock)
                clearInterval(vm.countdownTimer)

                vm.idletime = 0
                startLockModal()

            }
            
            function startUpdateDocLock(){
                vm.updateDocLockInterval = setInterval(() => {
                    $q.all([
                        documentLockService.intervalDocLock(vm.dlo_id)
                    ]).then((response) => {
                    })
                }, 30 * 1000)
            }

            function startLockModal(){
                vm.lockModal = setInterval(() => {
                    vm.idletime = vm.idletime + 1 // 1 minute
                    if(vm.idletime === 5){ // after 5 minutes of idle time open lockcheck modal
                        vm.continueEditing = false
                        vm.leaveEditing = false
                        vm.modalElementsLock = {
                            title: translateTag(3419),   //"Page inactive for 5 minutes" 
                            message: `<div style="text-align: center;"><h1 id ="inactiveTime" ></h1><p> ${translateTag(3420)}</p></div>`,  //"The entry will automatically save and close if no action is taken"
                            buttons: 
                                `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Continue Working">{{vm.componentTranslateLabels(3421)}}</button>
                                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Save and Close">{{vm.componentTranslateLabels(3422)}}</button>`
                        }
                        document.getElementById('confirmcallingform').innerHTML = 'LLLOCKCALLCONFIRMMODAL' 
                        $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsLock)
                        vm.lockCheckModal = true
                        startcountdownTimer()
                        vm.relieveLock = setTimeout(() => {
                            if (vm.lockCheckModal === true){
                                if (!vm.continueEditing && !vm.leaveEditing){
                                    vm.leaveEditing = true
                                    vm.saveLesson()
                                    vm.closeViewer()
                                }
                            }
                        }, 60 * 1000);
                    }                                        
                }, 60 * 1000);
            }

            $scope.$on("LLLOCKCALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.continueEditingLLM()
                }
                else if (result=='button2') {
                    vm.closeLockModal()
                }
            })

            vm.closeLockModal = () => {
                vm.saveLesson()
                vm.closeViewer()
            }

            function startcountdownTimer(){
                vm.countdownTimer = setInterval(() => {
                    if(vm.lockCheckModal === true && vm.countdownSeconds>=0){
                        vm.content = '01:00'
                        if (vm.countdownSeconds === 60){
                            vm.content = "01:00"
                        }
                        else{
                            vm.content = "00:" + vm.countdownSeconds.toLocaleString('en-US', {
                                minimumIntegerDigits: 2,
                                useGrouping: false
                              }) 
                        }
                        document.getElementById('inactiveTime').textContent =  vm.content
                        vm.countdownSeconds = vm.countdownSeconds - 1   
                    }                                        
                }, 1000)
            }

            // functions for document lock end___ 

            //Function to refresh the action data
            function refreshActions (id) {
                payload = {
                    llm_id: id
                }
                vm.currentLesson.actions = []
                lessonsLearnedService.getHazardActions(payload).then((response) => {
                    vm.currentLesson.hazard_actions = response.Hazard_Action
                    if(vm.currentLesson.hazard_actions != null) {
                        vm.currentLesson.hazard_actions.forEach((haz) =>
                        {
                            haz['can_close_action'] = vm.canCloseAllActions
                            if(!vm.canCloseAllActions){
                                if(haz.sha_created_by_per_id == vm.userId || haz.action_by_who.includes(vm.userId)){
                                    haz['can_close_action'] = true
                                }else{
                                    haz['can_close_action'] = false
                                }
                            }
                            haz.lla_action_type = 'Hazard'  
                            haz.action_by_who = getEmployeeNames(haz.action_by_who)
                            vm.currentLesson.actions.push(haz)
                        })
                    }
                })
                lessonsLearnedService.getGeneralActions(payload).then((response) => {
                    vm.currentLesson.general_actions = response.general_actions
                    if(vm.currentLesson.general_actions != null) {
                        vm.currentLesson.general_actions.forEach((gen) =>
                        {
                            gen['can_close_action'] = vm.canCloseAllActions
                            if(!vm.canCloseAllActions){
                                if(gen.sga_created_by_per_id == vm.userId || gen.sga_action_by_who_per_id.includes(vm.userId)){
                                    gen['can_close_action'] = true
                                }else{
                                    gen['can_close_action'] = false
                                }
                            }
                            gen.lla_action_type = 'General'
                            gen.recommended_action = gen.sga_recommended_action
                            gen.action_by_who = getEmployeeNames(gen.sga_action_by_who_per_id)
                            gen.action_by_when = gen.sga_action_by_when
                            vm.currentLesson.actions.push(gen)
                        })
                    }
                })
            }

            $scope.$on('CLOSEIMAGECOMMENTSMODAL', (event) => {
                refreshAttachments(vm.currentLesson.llm_id)
            })

            //Function to refresh/get attachment data
            function refreshAttachments (id) {
                if(id)
                {
                    payload = {
                        llm_id: id
                    }
                    lessonsLearnedService.getLessonAttachments(payload).then((response) => {
                        vm.attachmentData = response
                    
                        if (vm.attachmentOptions.api) {
                            translateAgGridHeader (vm.attachmentOptions)
                            vm.attachmentOptions.paginationPageSize = 15
                            vm.attachmentOptions.api.setRowData(prepareAttachmentsGridData(vm.attachmentData))
                            vm.attachmentOptions.api.redrawRows()
                            vm.attachmentOptions.api.sizeColumnsToFit()
                        }
                    })
                }
                else if (vm.attachmentOptions.api) {
                    translateAgGridHeader (vm.attachmentOptions)
                    vm.attachmentOptions.paginationPageSize = 15
                    vm.attachmentOptions.api.setRowData([])
                    vm.attachmentOptions.api.redrawRows()
                    vm.attachmentOptions.api.sizeColumnsToFit()
                }
            }

            function prepareAttachmentsGridData(data) {
                let gridData = JSON.parse(JSON.stringify(data))
                
                gridData.forEach((rec) =>{
                    rec.exceptionFields = ['']
                    rec.com_comment = rec.com_comment ? rec.com_comment.replaceAll("'","&#39") : null
                    rec.lat_created_by_per = getEmployeeName(rec.lat_created_by_per)
                    rec.lat_modified_by_per = getEmployeeName(rec.lat_modified_by_per)
                    rec.lat_created_date = moment(rec.lat_created_date).format('YYYY-MM-DD')
                    rec.lat_modified_date = rec.lat_modified_date? moment(rec.lat_modified_date).format('YYYY-MM-DD') : '' 
                    rec.lat_llm_show_check_box = vm.llm_show_check_box
                })
                return gridData
            }

            //Function to add attachments
            function addAttachments (att)
            {
                if(vm.currentMode === "new") {
                    if (validateFormFields('lessonForm', true)) {
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentLesson)))
                        payload.llm_is_submitted = false

                        lessonsLearnedService.createLesson(payload).then((response) => {
                            vm.currentLesson.llm_id = response.llm_id
                            resetFormFieldClassList('lessonForm')
                            let fd = new FormData()
                            for (let i in vm.uploadFileList) {
                                fd.append("llm_id", vm.currentLesson.llm_id)
                                fd.append("lat_files", vm.uploadFileList[i])
                            }
                            lessonsLearnedService.addLessonAttachments(fd).then((res) => {
                                refreshAttachments(vm.currentLesson.llm_id)
                                vm.uploadFileList = []
                            })
                            refreshData()
                            vm.llm_show_check_box = true
                            toastr.success(translateTag(8866)) //Lesson Saved                            
                        })
                    }
                    else{
                        $rootScope.$broadcast("CALLCONFIRMMODAL")
                    }
                }
                else {
                    let fd = new FormData()
                    for (let i in vm.uploadFileList) {
                        fd.append("llm_id", vm.currentLesson.llm_id)
                        fd.append("lat_files", vm.uploadFileList[i])
                    }
                    lessonsLearnedService.addLessonAttachments(fd).then((res) => {
                        refreshAttachments(vm.currentLesson.llm_id)
                        vm.uploadFileList = []
                    })
                }                
            }

            //Function to open delete confirmation Modal
            vm.deleteAttachmentConfirmationModal = () => {
                vm.deleteAttCount = vm.attachmentOptions.api.getSelectedRows().length
                vm.modalElementsDelete = {
                    title: translateTag(3416), //"Delete Attachment?"
                    message: `<div><p>${translateTag(3581)} ${vm.deleteAttCount} ${translateTag(3417)}</p></div>`, //"You are about to delete {{lessonsCtrl.deleteAttCount}} attachments. Undoing this will require IT support. Are you sure?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Yes">{{vm.componentTranslateLabels(1379)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
                }
                document.getElementById('confirmcallingform').innerHTML = 'LLDELETECALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsDelete)
            }

            $scope.$on("LLDELETECALLCONFIRMMODAL", (event,result) => {
                if (result=='button1') {
                    vm.deleteAttachment()
                }
            })

            //Function to delete the selected attachment rows
            vm.deleteAttachment = () => {
                var rows = vm.attachmentOptions.api.getSelectedRows()
                if (rows.length > 0) {
                var ids = []
                for (var i = 0; i < rows.length; i++) {
                    ids.push({ lat_id: rows[i].lat_id})
                }
                lessonsLearnedService.removeLessonAttachments(ids).then((r) => {
                    refreshAttachments(vm.currentLesson.llm_id)
                })
                }    
                modalService.Close('confirmModal')
            }

            //Function to close the viewer
            vm.closeViewer = () => {                
                modalService.Close('confirmModal')
                vm.employeeList = []
                vm.hideingLessonViewer = true
                vm.releaseDocument(vm.dlo_id).then((response) => {
                })
                clearInterval(vm.countdownTimer)
                clearInterval(vm.updateDocLockInterval)
                clearInterval(vm.lockModal)
                // Stop the autosave
                $interval.cancel(vm.autosave)
                vm.resetForm()
                refreshData()
                $timeout(() => {
                    vm.lessonViewerOpen = false
                }, 400)
            }

            // function to release document lock
            vm.releaseDocument = (id) => {
                payload = {}
                payload.dlo_id = id
                return (
                    $q.all([
                        documentLockService.closeDocLock(payload).then((response) => {
                        })
                    ])
                )
            }


            //Function to open modals
            vm.openModal = (modalId) => {
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()

                $('.modal .scroll').scrollTop(0)

                modalService.Open(modalId)
                vm.initializeSelect2(modalId, '.modal-body')
            }

            //Function to open the create action modals
            vm.openActionModal = (modalId) => {
                vm.actionMode = 'new'
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()

                $('.modal .scroll').scrollTop(0)

                if(vm.currentMode === "new") {
                    resetFormFieldClassList('lessonForm')
                    if (validateFormFields('lessonForm', true)){
                        vm.currentMode = 'edit'
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentLesson)))
                        payload.llm_is_submitted = false

                        lessonsLearnedService.createLesson(payload).then((response) => {
                            vm.currentLesson.llm_id = response.llm_id
                            toastr.success(translateTag(1111)) //Lesson Saved //Missing
                            resetFormFieldClassList('lessonForm')
                            modalService.Open(modalId)
                            vm.initializeSelect2(modalId, '.modal-body')
                            refreshData()
                        })
                    } 
                    else {
                        $rootScope.$broadcast("CALLCONFIRMMODAL")
                    }
                   
                }
                else{
                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId, '.modal-body')
                }
            }

            //Function to open the edit action modals
            vm.openActionEditModal = (modalId, id) => {
                vm.actionMode = 'edit'
                if(modalId === 'generalActionModal') {
                    openGeneralEdit(id, modalId)
                }
                else if(modalId === 'hazardActionModal') {
                    openHazardEdit(id, modalId)
                }
            }

            //Function to prepare data to edit a general action
            function openGeneralEdit(id, modalId) {
                actionManagementService.getGeneralActionSingle({sga_id: id}).then ((response) => {
                    vm.generalEditData = response

                    vm.generalEditData.Site = parseInt(vm.generalEditData.Site)
                    vm.generalEditData.JobNumber = parseInt(vm.generalEditData.JobNumber)
                    vm.generalEditData.SiteLevel = parseInt(vm.generalEditData.SiteLevel)
                    vm.generalEditData.Supervisor = parseInt(vm.generalEditData.Supervisor)

                    vm.generalEditData.HeaderDate = moment(vm.generalEditData.HeaderDate).format('YYYY-MM-DD')
                    vm.generalEditData.sga_action_by_who_per_id = vm.generalEditData.sga_action_by_who_per

                    let i = 0
                    let initialAtt = JSON.parse(JSON.stringify(vm.generalEditData.attachments))
                    initialAtt.forEach((att) => {
                        if(att.gaa_type === 'FOLLOWUP')
                            vm.generalEditData.attachments.splice(i, 1)
                        else
                            i++
                    })
                    
                    vm.generalEditData.attachments.forEach((att) => {
                        att.imageDir = `${__env.imageUrl}/`
                    })
                    
                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()            

                    $('.modal .scroll').scrollTop(0)

                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId, '.modal-body')
                })
            }

            //Function to prepare data to edit a hazard action
            function openHazardEdit(id, modalId) {
                actionManagementService.getHazardActionSingle({hap_id: id}).then ((response) => {
                    vm.hazardEditData = response
                    vm.hazardEditData.Site = parseInt(vm.hazardEditData.Site)
                    vm.hazardEditData.JobNumber = parseInt(vm.hazardEditData.JobNumber)
                    vm.hazardEditData.SiteLevel = parseInt(vm.hazardEditData.SiteLevel)
                    vm.hazardEditData.Supervisor = parseInt(vm.hazardEditData.Supervisor)

                    vm.hazardEditData.HeaderDate = moment(vm.hazardEditData.HeaderDate).format('YYYY-MM-DD')

                    let i = 0
                    let initialAtt = JSON.parse(JSON.stringify(vm.hazardEditData.attachments))
                    initialAtt.forEach((att) => {
                        if(att.attachmenttype === 'FOLLOWUP')
                            vm.hazardEditData.attachments.splice(i, 1)
                        else
                            i++
                    })

                    vm.hazardEditData.attachments.forEach((att) => {
                        att.imageDir = `${__env.imageUrl}/`
                    })
                    
                    if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                        $scope.$apply()            

                    $('.modal .scroll').scrollTop(0)

                    modalService.Open(modalId)
                    vm.initializeSelect2(modalId, '.modal-body')
                })
            }

            //Function to open the complete action modals
            vm.completeActionModal = (action) => {
                if(action.lla_action_type === 'General')
                {
                    actionManagementService.getGeneralActionSingle({sga_id: action.sga_id}).then ((response) => {
                        vm.generalFollowup = response
                        vm.generalFollowup.sga_completed_action_date = dateToday.format('YYYY-MM-DD')
                        vm.generalFollowup.sga_action_by_who_per_id = getEmployeeName(vm.generalFollowup.sga_action_by_who_per)
                        if(vm.generalFollowup.sga_completed_action_by_who_per != null)
                            vm.generalFollowup.sga_completed_action_by_who_per_id = parseInt(getEmployeeID(vm.generalFollowup.sga_completed_action_by_who_per))
                        vm.generalFollowup.attachment_files_initial = []
                        vm.generalFollowup.attachment_files_followup = []

                        vm.generalFollowup.attachments.forEach((attRec) => {
                            if(attRec.gaa_type == 'INITIAL')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                vm.generalFollowup.attachment_files_initial.push(attRec) 
                            }
                            else if(attRec.gaa_type == 'FOLLOWUP')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                vm.generalFollowup.attachment_files_followup.push(attRec) 
                            }
                        })

                        vm.openModal('completeGeneralActionModal')
                        setTimeout(()=>{
                            $scope.$broadcast('GENERAL_FOLLOWUP_OPENED')
                        },100) 
                    })
                }
                else
                {
                    actionManagementService.getHazardActionSingle({hap_id: action.id}).then ((response) => {
                        vm.followup = response
                        vm.followup.action_completed_date = dateToday.format('YYYY-MM-DD')
                        vm.followup.action_complete_by_who = (vm.followup.action_complete_by_who && vm.followup.action_complete_by_who != 'None') ? parseInt(getEmployeeID(vm.followup.action_complete_by_who)) : null
                        vm.followup.attachmentModalFiles = []
                        vm.followup.followupAttachmentModalFiles = []

                        vm.followup.attachments.forEach((attRec) => {
                            if(attRec.attachmenttype === 'INITIAL')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                attRec.AttachmentFileName = attRec.attachmentfilename
                                vm.followup.attachmentModalFiles.push(attRec) 
                            }
                            else if(attRec.attachmenttype === 'FOLLOWUP')
                            {
                                attRec.imageDir = `${__env.imageUrl}/`
                                attRec.AttachmentFileName = attRec.attachmentfilename
                                vm.followup.followupAttachmentModalFiles.push(attRec) 
                            }
                        })
                        
                        vm.followup.HapId = action.id
                        vm.followup.action_by_who_name = getEmployeeName(action.action_by_who)

                        vm.openModal('hapFollowupComponent')
                        setTimeout(()=>{
                            $scope.$broadcast('HAZARD_FOLLOWUP_OPENED')
                        },100)
                    })
                }
            }

            //Function to save the lesson
            vm.saveLesson = (mode = 'normal') => {
                resetFormFieldClassList('lessonForm')
                if (validateFormFields('lessonForm', true)){
                    vm.submitted = true
                    if(vm.currentMode === "new") {
                        let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentLesson)))
                        payload.llm_is_submitted = false
                        lessonsLearnedService.createLesson(payload).then((response) => {
                            if(mode === 'normal') {
                                refreshData()
                                vm.closeViewer()
                            }
                            else {
                                vm.currentLesson.llm_id = response.llm_id
                                vm.currentMode = "edit"
                                vm.submitted = false
                                clearInterval(vm.lockModal)
                                clearInterval(vm.updateDocLockInterval)
                                startUpdateDocLock()
                                startLockModal()
                                autoSaveRefresh()
                            }
                        })
                    }
                    else{
                        let payload = preparePayload('edit', JSON.parse(JSON.stringify(vm.currentLesson)))
                        payload.llm_is_submitted = false

                        lessonsLearnedService.updateLesson(payload).then((response) => {
                            if(mode === 'normal') {
                                refreshData()
                                vm.closeViewer()
                            }
                            else{
                                vm.submitted = false
                                autoSaveRefresh()
                            }
                        })
                    }
                }
                else{
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }

            //Function to submit the lesson
            vm.submitLesson = () => {
                if (vm.validateLesson()){
                    vm.submitted = true
                    if(vm.currentMode === "new") {
                        let payload = preparePayload('new',  JSON.parse(JSON.stringify(vm.currentLesson)))
                        payload.llm_is_submitted = true
                        lessonsLearnedService.createLesson(payload).then((response) => {
                            refreshData()
                            vm.closeViewer()
                        })
                    }
                    else{
                        let payload = preparePayload('edit',  JSON.parse(JSON.stringify(vm.currentLesson)))
                        payload.llm_is_submitted = true
                        lessonsLearnedService.updateLesson(payload).then((response) => {
                            refreshData()
                            vm.closeViewer()
                        })
                    }
                } else {
                    $rootScope.$broadcast("CALLCONFIRMMODAL")
                }
            }
            

            //Function to prepare payload data
            function preparePayload(mode='new', payload) {
                let preparedPayload = {}
                if(mode == 'edit')
                {
                    preparedPayload.llm_id = payload.llm_id
                    preparedPayload.llm_site_rld = payload.llm_site_rld
                    preparedPayload.llm_job_rld = payload.llm_job_rld
                }
                else
                {
                    preparedPayload.llm_site_rld_id = payload.llm_site_rld
                    preparedPayload.llm_job_rld_id = payload.llm_job_rld
                }

                preparedPayload.llm_title = payload.llm_title ? payload.llm_title : ''
                preparedPayload.llm_scope = payload.llm_scope
                preparedPayload.llm_summary = payload.llm_summary
                preparedPayload.llm_success = payload.llm_success
                preparedPayload.llm_opportunity = payload.llm_opportunity
                preparedPayload.llm_date = payload.llm_date !== undefined ? moment(payload.llm_date, 'YYYY-MM-DD').format('YYYY-MM-DD') : 
                moment(dateToday.format("YYYY-MM-DD"), 'YYYY-MM-DD').format('YYYY-MM-DD')
                
                preparedPayload.llm_other_participant = payload.llm_other_participant
                preparedPayload.participants = payload.participants
    
                return preparedPayload
            }

            //Function to add an action to a lesson
            vm.addAction = (actionData) => {
                payload = {}
                
                if('sga_id' in actionData)
                {
                    payload.llg_llm = vm.currentLesson.llm_id
                    payload.llg_sga = actionData.sga_id

                    lessonsLearnedService.addLessonGeneralAction(payload).then((response) => {
                        refreshActions(vm.currentLesson.llm_id)
                    })                
                }
                else if('ID' in actionData)
                {   

                    payload.llh_llm =  vm.currentLesson.llm_id
                    payload.llh_sha = actionData.ID

                    lessonsLearnedService.addLessonHazardAction(payload).then((response) => {
                        refreshActions(vm.currentLesson.llm_id)
                    })
                }
            }

            //Function to remove completed actions from the grid
            vm.completeAction = (actionData) => {
                refreshActions(vm.currentLesson.llm_id)          
            }

            //Funtion to initialize select2
            vm.initializeSelect2 = (parent, section='')=> {
                setTimeout(()=>{ 
                $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} ${section}`), escapeMarkup: function (text) { return text } })
                .on('select2:select', () => {
                    $(this).parent().find('label').addClass('filled')
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()
                if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
                $('.datepicker').pickadate({
                    format: 'yyyy-mm-dd',
                    onClose : function(){
                        this.$holder.blur()
                    },
                }).removeAttr('readonly')
                .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                    evt.preventDefault()
                })
                preventFutureDatePickerInit()
                }, 100)
            }

            //Listeners
            $scope.$on('CLOSEMODAL', (event) => {
                vm.initializeSelect2('newLessonLearned')
            })

            $scope.$on('ADDACTION', (event, data) => {
                if(data && vm.actionMode != 'edit')
                    vm.addAction(data)
                else{
                    refreshActions(vm.currentLesson.llm_id)
                }
            })

            $scope.$on('COMPLETEACTION', (event, data) => {
                if(data)
                    vm.completeAction(data)
            })
            // Function to refresh while in autosave mode
            function autoSaveRefresh() {
                lessonsLearnedService.getLessonsList(vm.mainDateFilter).then((data) =>{
                    vm.lessonsData = lessonsLearnedService.readLessonsList()
                    if (vm.lessOptions.api) {
                        translateAgGridHeader (vm.lessOptions)
                        let model = vm.lessOptions.api.getFilterModel()
                        vm.lessOptions.paginationPageSize = 15
                        vm.lessOptions.api.setRowData(prepareLessonsGridData())
                        vm.lessOptions.api.redrawRows()
                        vm.lessOptions.api.sizeColumnsToFit()
                        vm.lessOptions.api.sizeColumnsToFit()
                        vm.lessOptions.api.setFilterModel(model)
                    }
                })
            }

            //Function to refresh data and Ag-Grid
            function refreshData() {
                $scope.$emit('STARTSPINNER', vm.loadMessage)
            $q.all([   
                listService.getSelectListData('ref_site'),
                listService.getSelectListData('ref_job'),
                listService.getSelectListData('ref_general_action'),
                employeesService.getPersonProfile(),
                profileService.getAllEmployeeProfile(),
                profileService.getFullEmployeeProfile(),
                lessonsLearnedService.getLessonsList(vm.mainDateFilter),
                listService.getFullSiteList(),
                listService.getFullJobList(),
            ]).then((data) => {
                vm.siteList = data[0]
                vm.jobList = data[1]
                vm.actionTypeList = data[2]
                vm.userId = data[3].per_id
                vm.fullEmployeeList = profileService.readFullEmployeeProfile() 
                vm.lessonsData = lessonsLearnedService.readLessonsList()
                vm.site_name = listService.readFullSites()
                vm.job_name = listService.readFullJobs()
                if (vm.lessOptions.api) {
                    translateAgGridHeader (vm.lessOptions)
                    let model = vm.lessOptions.api.getFilterModel()
                    vm.lessOptions.paginationPageSize = 15
                    vm.lessOptions.api.setRowData(prepareLessonsGridData())
                    vm.lessOptions.api.redrawRows()
                    vm.lessOptions.api.sizeColumnsToFit()
                    vm.lessOptions.api.sizeColumnsToFit()
                    vm.lessOptions.api.setFilterModel(model)
                }
                $scope.$emit('STOPSPINNER', vm.loadMessage)
                vm.actionDisabled = true
            })
            }
            vm.resetForm()
            vm.lessonViewerOpen = true
            vm.lessonViewerOpen = false

            //Function to prepare Ag-Grid data with string values
            function prepareLessonsGridData() {
                let lessGridData = JSON.parse(JSON.stringify(vm.lessonsData))
                lessGridData.forEach((rec) =>{
                    rec.exceptionFields = ['general_actions', 'hazard_actions', 'acknowledgements', 'participants', 'llm_enable', 'dlo_enable', 'dlo_person', 'dlo_status','lat_llm','lat_llm_show_check_box']
                    rec.llm_created_by_per = getEmployeeName(rec.llm_created_by_per)
                    rec.llm_modified_by_per = getEmployeeName(rec.llm_modified_by_per)
                    rec.llm_submitted_by_per = rec.llm_is_submitted == 1 ? getEmployeeName(rec.llm_submitted_by_per) : ''
                    rec.llm_site_rld = getSiteName(rec.llm_site_rld)
                    rec.llm_job_rld = getJobNumber(rec.llm_job_rld)
                    rec.participants = getParticipants(rec.participants)                

                    rec.llm_created_date = moment(rec.llm_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                    rec.llm_modified_date = rec.llm_modified_date? moment(rec.llm_modified_date, 'YYYY-MM-DD').format('YYYY-MM-DD') : '' 
                    rec.llm_is_submitted  = rec.llm_is_submitted == 1 ? true : false
                    rec.llm_is_submitted ? rec.llm_submitted_date = moment(rec.llm_submitted_date, 'YYYY-MM-DD').format('YYYY-MM-DD') : rec.llm_submitted_date = ''

                    rec.reviewedCount = rec.acknowledgements.length
                    rec.hasAcknowledged = checkAcknowledged(rec)
                    if(rec.dlo_enable.length !== 0){
                        rec.dlo_status = rec.dlo_enable[0].dlo_enable
                        rec.dlo_person = rec.dlo_enable[0].dlo_person
                    }
                    else{
                        rec.dlo_status = true
                        rec.dlo_person = null
                    }

                    rec.participantsList = ''
                    let plist = []
                    rec.participants.forEach((par) => {
                      plist.push(getEmployeeName(par))
                    })
                    rec.participantsList = plist.join(' - ')

                    rec.reviewersList = ''
                    let rlist = []
                    rec.acknowledgements.forEach((rev) => {
                        rlist.push(getEmployeeName(rev.lla_per))
                    })
                    rec.reviewersList = rlist.join(' - ')
                })
                return lessGridData
            }

            //Function to prepare Participants
            function getParticipants (values)
            {
                let participants = []
                values.forEach ((rec) => {
                    participants.push(rec.llp_per)
                })
                return participants
            }

            // Fuction to check if all modal feilds are valid
            vm.validateLesson = () => {
                return validateFormFields('lessonForm')
            }

            //Update Ag-Grid size when window is resized
            $(window).on('resize', () => {
                $timeout(function () {
                    if (vm.lessOptions.api) {
                        vm.lessOptions.api.sizeColumnsToFit()
                    }
                    if (vm.attachmentOptions.api) {
                        vm.attachmentOptions.api.sizeColumnsToFit()
                    }
                })
            })
            
        //END
        }
    ])