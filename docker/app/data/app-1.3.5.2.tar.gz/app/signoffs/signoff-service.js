﻿angular
    .module('safeToDo')
    .service('signoffService', ['$http',
        function ($http) {


            return {
                addSignoff: (headerId) => {
                  return $http.post(`${__env.apiUrl}/api/signoff/add-signoff/`, {SubmissionHeaderID: headerId}).then((data) => {
                            if(data.data.accessMsg){
                                toastr.error(data.data.accessMsg)
                                return []
                            }
                            else
                                 return data.data

                        },(status) => {
                            console.log(`Signoff post failed`, status);
                            return null
                        })
                },
                deleteSignoff: (signoffId) => {
                    return $http.post(`${__env.apiUrl}/api/signoff/remove-signoff/`, {"SignoffId": signoffId})
                        .then(() => {
                            return true
                        },(status) => {
                            console.log('Signoff delete failed - ', status)
                            return false
                        })
                },
                getSignoffsByHeader: (headerId) => {
                    return $http.post(`${__env.apiUrl}/api/signoff/get-form-signoffs/`, {'SubmissionHeaderID': headerId, "language": selectedLanguage })
                        .then((response) => {
                            // console.log("This is the DATA from the Signoff list", response.data.Payload)
                            // return response.data.Payload;

                            if(response.data.accessMsg){
                                toastr.error(response.data.accessMsg)
                                return []
                            }
                            else
                                 return response.data.Payload

                        }, (status) => {
                            console.log('Signoff get failed - ',status);
                            return null;
                        });
                }
            };
        }
    ]);