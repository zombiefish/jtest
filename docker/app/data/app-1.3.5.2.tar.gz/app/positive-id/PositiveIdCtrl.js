﻿angular
    .module('safeToDo')
    .controller('PositiveIdCtrl', ['$scope', '$compile','$timeout', '$rootScope','$q',  '$window', '$sce', 'gridService','$location', '$window', 'employeesService', 'gridService', 'positiveIdService', 'modalService','profileService','listService','complianceService','formsService','$translate','$translatePartialLoader',
        function ($scope, $compile, $timeout,$rootScope,$q, $window, $sce, gridService,$location, $window, employeesService, gridService, positiveIdService, modalService, profileService,listService,complianceService, formsService, $translate,$translatePartialLoader) {
            var vm = this
            
            $translate.use(selectedLanguage)
            vm.start_date_filter = true
            vm.targets = [];
            vm.supervisors = [];
            vm.frequencies = [];
            vm.forms = [];
            vm.hazards = [];
            vm.options = gridService.getCommonOptions()
            vm.topSearch = ''
            setTimeout(()=>{
                vm.loadMessage = translateTag(3722) // note="Loading positive recognition page. Please wait."
            },100)

            vm.employeeList = []
            vm.isFromHomePage = false
            vm.defaultDateFilter = '30'
            vm.curPage = "General" 
            vm.loadGraphsFilter = ""
            vm.loadTop10Filter = ""
            vm.loadGeneralFilter = {
                start_date: moment().subtract(90, 'days').format('YYYY-MM-DD'),
                end_date: moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD')
            }
        
            vm.monthNamesLong = [{name:'January', short: 'Jan', number: '01'},
            {name: 'February', short: 'Feb', number: '02'} ,
            {name:'March', short: 'Mar', number:'03'} , 
            {name:'April', short: 'Apr', number:'04'}, 
            {name:'May', short: 'May', number:'05'}, 
            {name:'June', short: 'June', number:'06'}, 
            {name:'July', short: 'July', number:'07'}, 
            {name:'August', short: 'Aug', number:'08'}, 
            {name:'September', short: 'Sept', number:'09'}, 
            {name:'October', short: 'Oct', number:'10'}, 
            {name:'November', short: 'Nov', number:'11'}, 
            {name:'December', short: 'Dec', number:'12'}]
            vm.monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
            vm.years = [2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030]

            vm.currentInfo = {}

            let filterObject = {
                Jobs:[]
            }

            function getMonthFromString(mon) {
                return new Date(Date.parse(mon + " 1, 2017")).getMonth() + 1;
            }

          

            vm.refreshPage = () =>{
                // setting default as false every refresh
                vm.isFromHomePage = false

                if($window.sessionStorage.getItem('homepageRedirect_pidFilter', true) !== null){
                    if($window.sessionStorage.getItem("homepageRedirect_pidFilter") == 'homepage'){
                        $window.sessionStorage.removeItem("homepageRedirect_pidFilter")
                        // setting it's reredirected from the homepage.
                        vm.isFromHomePage = true
                        if($window.sessionStorage.getItem('homePageRedirectDate', true) !== null){
                            let dateRedirect = JSON.parse($window.sessionStorage.getItem("homePageRedirectDate"))
                            vm.defaultDateFilter = dateRedirect.dateType ? dateRedirect.dateType : '30'
                        }
                    }
                }
                

                $scope.$on('DATERANGE', (range) => {
                    if($location.url() === '/a/positive-id'){
                        vm.mainDateFilter = {
                            start_date: moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD'),
                            end_date: moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')
                        }

                        if(vm.isFromHomePage){
                            if($window.sessionStorage.getItem('homePageRedirectDate', true) !== null){
                                let dateRedirect = JSON.parse($window.sessionStorage.getItem("homePageRedirectDate"))
                                vm.defaultDateFilter = dateRedirect.dateType ? dateRedirect.dateType : '30'
                                vm.mainDateFilter = {
                                    start_date: moment(dateRedirect.start,'YYYY-MM-DD').format('YYYY-MM-DD'),
                                    end_date: moment(dateRedirect.end,'YYYY-MM-DD').format('YYYY-MM-DD')
                                }
                                $window.sessionStorage.removeItem('homePageRedirectDate')
                            }
                        }

                        $window.sessionStorage.setItem('start_month', moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('MM'))
                        $window.sessionStorage.setItem('start_year', moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY'))
                        $window.sessionStorage.setItem('end_month', moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('MM'))
                        $window.sessionStorage.setItem('end_year', moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY'))
                        $window.sessionStorage.setItem('start_date', moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD'))
                        $window.sessionStorage.setItem('end_date', moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD'))
                        if(!vm.start_date_filter)
                            {
                                vm.filterChartsPID('start')
    
                            }
    
                        if (vm.curPage == "General"){
                            vm.loadGeneralFilter = vm.mainDateFilter
                        }
                        else if (vm.curPage == "Top10"){
                            vm.loadTop10Filter = vm.mainDateFilter
                        }
                        else if (vm.curPage == "Graphs"){
                            vm.loadGraphsFilter = vm.mainDateFilter
                        }
                        vm.start_date_filter = false
                    }
                })

            }

            vm.refreshPage()

            var currentDate = new Date();
            let dateToday = moment(new Date(), 'YYYY-MM-DD')
            function getMonthName(month, type='long'){
                let theMonth = ''
               vm.monthNamesLong.forEach((mth)=>{
                   if(mth.number === month) {
                    theMonth =  type === 'long'? mth.name : nth.short
                   }
                })
                return theMonth
            }

            vm.dateFilter = {
                start_month: $window.sessionStorage.getItem("start_month") ? $window.sessionStorage.getItem("start_month") : dateToday.format("MM"),
                start_year: $window.sessionStorage.getItem("start_year") ? Number($window.sessionStorage.getItem("start_year")) : currentDate.getFullYear(),
                end_month: $window.sessionStorage.getItem("end_month") ? $window.sessionStorage.getItem("end_month") : dateToday.format("MM"),
                end_year: $window.sessionStorage.getItem("end_year") ? Number($window.sessionStorage.getItem("end_year")) : currentDate.getFullYear(),
                getFormattedRange: () => {
                    var start = getMonthName(vm.dateFilter.start_month) + " " + this.start_year
                    var end = getMonthName(vm.dateFilter.end_month) + " " + this.end_year
                    if (start == end) {
                        return start
                    }

                    return start + " - " + end;
                },
                validate: () => {
                    if (this.start_year > this.end_year) {
                        return false
                    }
                    if (this.start_year == this.end_year) {
                        if (getMonthFromString(this.start_month) > getMonthFromString(this.end_month)) {
                            return false
                        }
                    }

                    return true;
                }
            }


            //Function for the top search bar
            vm.topSearchChanged = () =>{
                vm.options.api.setQuickFilter(vm.topSearch)
            }
            
            vm.openModal = (id) => {
                modalService.Open(id)
            };

            vm.closeModal = (id) => {
                modalService.Close(id);
                vm.click = true   // set click to true after the likes are refreshed
            }
            
            let token = JSON.parse(window.localStorage.getItem('token'))
        
            function parseJwt (token) {
                var base64Url = token.split('.')[1]
                var base64 = base64Url.replace('-', '+').replace('_', '/')
                return JSON.parse(window.atob(base64))
            }
    
            function getEmployeePos(value){
                let pos  
                vm.employeeList.forEach((emp)=>{
                    if(emp.user_id == value) {
                        pos = emp.pos
                        return
                    }
                })
                return pos
            }


            vm.click = true // set click to true on load
            vm.like = (headerId, mylikeid, headerData) => {        
                if(vm.click){ //check if user has already clicked - to prevent multiple clicks
                    vm.click = false  // set click to false on click 
                    if (mylikeid > 0) {
                        vm.comment_data = headerData
                        vm.mylikeid = headerData.mylikeid

                        vm.modalElements = {
                            title: translateLabels(3828),  //"Remove Like?"
                            message: `<div><p>${translateTag(3827)}</p></div>`, //"Your record of liking this Positive Recognition will be erased. Continue?"
                            buttons: `<button class='btn btn-primary btn-rounded' ng-click="vm.return('button1')" note="Remove">{{vm.componentTranslateLabels(2434)}}</button>`//"Remove"
                        }
                        document.getElementById('confirmcallingform').innerHTML = 'RETURNPIDCOMMENTDELETE' 
                        $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
                    } else {                        
                        positiveIdService.addLike(headerId)
                            .then((res) => {
                                if (res.status===201) {
                                    vm.refreshLikes(headerId, res.data.like_id)
                            }
                        })
                    }
                }            
            }

            $scope.$on("RETURNPIDCOMMENTDELETE", (event,result) => {
                if (result=='button1') {
                    vm.confirmLikeDelete(vm.mylikeid, vm.comment_data)
                }
                modalService.Close("confirmModal")
            })

            // refreshing likes after like is added on person from same submissionID
            // getting list of signed_by for each person in the submissionID and when user signs check if current user is in the list and update like count accordingly
            vm.refreshLikes = (headerId, like_id) => {
                let rowData = []
                vm.options.api.forEachNode((node) => rowData.push(node.data))
                let currentUserId = vm.currentUser.per_id
                rowData.forEach((node) => {
                    if (node.pid_id == headerId) {
                        node.mylikeid=like_id
                        if (!node.signed_by.includes(currentUserId.toString())) {
                            node.likeCount++
                            node.signed_by.push(currentUserId.toString())
                        }
                    }
                }) 
                let model = vm.options.api.getFilterModel()
                vm.options.api.setRowData(rowData)
                vm.options.api.redrawRows()
                vm.options.api.setFilterModel(model)
                vm.click = true   // set click to true after the likes are refreshed
            }

            vm.confirmLikeDelete = (mylikeid, headerData) => {
                vm.comment_data = null
                vm.mylikeid = null             
                positiveIdService.deleteLike(mylikeid)
                    .then(function (success) {
                        if (success) {                                
                            headerData.mylikeid = 0
                            headerData.likeCount = headerData.likeCount - 1 < 0 ? 0 : headerData.likeCount - 1
                            headerData.signed_by = headerData.signed_by.filter(function(item) { return item !== vm.currentUser.per_id.toString() })  
                        }
                    })
                vm.click = true  // set click to true after the grid is refreshed                
            }

            vm.viewLikeHistory = (rowData) => {
                if (!rowData.likeCount) {
                    return
                }
                vm.currentLikeHistory = [];

                positiveIdService.getLikesByHeader(rowData.pid_id, rowData.RecognitionOf).then((data) => {
                    data.map((rec)=>{
                        rec.name = rec.SigningName
                        rec.reviewed_date=rec.SigningTimestamp
                        rec.pos=rec.prl_position
                        delete rec.SigningName
                        delete rec.SigningTimestamp
                        delete rec.prl_position
                      })
                    vm.currentLikeHistory = data
                    $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentLikeHistory)
                })
            }

            let positiveIdColumns = [
                {
                    field: "likeCount",
                    headerName: " ", // Likes
                    minWidth: 125,
                    maxWidth: 125,
                    suppressMenu: true,
                    cellRenderer: function (params) {
                        return `<span title=${params.data.liked_by_per ? "{{menu.translateLabels(9050)}}" : "{{menu.translateLabels(9049)}}"} class="pointer" ng-click="pid.like(data.pid_id, data.mylikeid, data)"><i class="fa fa-thumbs-up fa-lg  {{ data.mylikeid > 0 ? \'text-secondary\' : \'\'}}"></i></span>`    
                            + '<span title={{menu.translateLabels(8674)}} class="source signoff-count" ng-class="{ transparent: !data.likeCount, pointer: !!data.LikeCount }" ng-click="pid.viewLikeHistory(data);"> {{ data.likeCount }}</span>'
                            + `<span class="pointer text-left" ng-click="pid.viewReports($event, ${params.data.parent_submission_id}, ${params.data.pid_id})"><i class="fa fa-external-link-alt" note="Launch Report" title="{{menu.translateLabels(3429)}}"></i></span>`
                    },    
                    valueGetter: function (params) {
                        return params.data.likeCount
                    },  
                },
                {
                    field: 'ID',
                    hide: true,
                    // sort: 'desc', removing sort for now in grid columns and updated the sort in stored procedure. 
                },
                {
                    field: "commentCount",
                    headerName:" ", //Comment
                    minWidth:150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: (params) => {
                        if(params.data.comment_by_per){
                            // ***yellow bubble
                            comment = `<i class="fa fa-comment text-secondary" title={{menu.translateLabels(8921)}} ng-click='pid.addComments(${JSON.stringify(params.data).replaceAll("'","&#39")})'></i>`
                        }else if(params.data.commentCount>0){
                            comment = `<i class="fa fa-comment " title={{menu.translateLabels(8921)}} ng-click='pid.addComments(${JSON.stringify(params.data).replaceAll("'","&#39")})'></i>`
                        }                        
                        else {
                            comment = `<i class="far fa-comment " title={{menu.translateLabels(8921)}} ng-click='pid.addComments(${JSON.stringify(params.data).replaceAll("'","&#39")})'></i>`
                        }
                        return comment + '<span title={{menu.translateLabels(8922)}} class="source signoff-count" ng-class="{ transparent: !data.commentCount, pointer: !!data.commentCount }" ng-click="pid.viewCommentHistory(data);"> {{ data.commentCount }}</span>'
                    } 
                },
                {
                    field: "submission_date",
                    headerName: " ", // Submission Date
                    minWidth: 170,
                    maxWidth: 170,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "submitted_by_name",
                    headerName: " ", // Submitted By
                    minWidth: 150,
                    maxWidth: 200,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "RecognitionOfName",
                    headerName: " ", // For
                    minWidth: 150,
                    maxWidth: 200,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "type",
                    headerName: " ", // Type
                    minWidth: 200,
                    maxWidth: 400,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "EventDescription",
                    headerName: " ",//Event Description
                    minWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "header_date",
                    headerName: " ", // Date
                    minWidth: 150,
                    maxWidth: 150,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',                    
                },
                {
                    field: "Site",
                    headerName: " ", // Site
                    minWidth: 200,
                    maxWidth: 300,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "job",
                    headerName: " ", // Job Name
                    minWidth: 150,
                    maxWidth: 200,
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    cellRenderer: 'tippyCellRenderer',
                }, 
                {
                    field:"RecognitionOf",
                    hide: true
                }              
                
            ]
            
            vm.options.columnDefs = positiveIdColumns

            vm.addComments=(data) =>{
                vm.comment_data = data    
                vm.commentValue = ''
                vm.modalTitle = translateLabels(8921)  //Add comment
                document.getElementById('savetomemory').innerHTML = "false"
                document.getElementById('parentform').innerHTML = 11
                document.getElementById('callingform').innerHTML= 'CLOSEPOSITIVEIDIMAGECOMMENTSMODAL'
                document.getElementById('comment_id').innerHTML = '' // comment id    
                document.getElementById('imageid').innerText = data.pid_id
                document.getElementById('allowmultiple').innerHTML = 1 //allow multiple
                $rootScope.$broadcast("RECIEVEROFCOMMENTS", vm.commentValue, vm.modalTitle)
            }

            $scope.$on("CLOSEPOSITIVEIDIMAGECOMMENTSMODAL", (event, data) => {
                if(data.com_comment){
                    vm.comment_data.commentCount++
                    vm.comment_data.comment_by_per=true  
                    vm.refreshRowData(vm.comment_data)
                }
                vm.commentValue=''
            })

            vm.refreshRowData = (data) => {
                let rowData = []
                vm.options.api.forEachNode((node) => rowData.push(node.data))
                rowData.forEach((node) => {
                    if (node.pid_id == data.pid_id) {
                        node.commentCount=data.commentCount
                        node.comment_by_per=data.comment_by_per
                        node.likeCount=data.likeCount
                        node.signed_by=data.signed_by
                        node.mylikeid = data.mylikeid            
                    }
                }) 
                vm.options.api.setRowData(rowData)
            }
            
            vm.viewCommentHistory = (rowData) => {
                vm.comment_data=rowData
                document.getElementById('pidlistcommentcallingform').innerHTML= 'PIDCALLPIDLISTCOMMENTMODAL'                
                $rootScope.$broadcast("CALLPIDLISTCOMMENTMODAL", rowData.pid_id, vm.currentUser.per_id);
            }

            $scope.$on("PIDCALLPIDLISTCOMMENTMODAL", (event, data) => {
                vm.comment_data.commentCount=data.commentCounts
                vm.comment_data.comment_by_per=data.comment_by_per
                vm.refreshRowData(vm.comment_data)
            })


            vm.hideDropdowns = () => {
                $('.filter-dropdown').removeClass('show')
            }

            $(window).click((e) => {
                $('.filter-dropdown').removeClass('show')
            })

            $('.sites').scroll((e) => {
                $('.filter-dropdown').removeClass('show')
            })

            vm.loadTop10 = () => {
                vm.loadTop10Filter = checkForFilterChange(vm.loadTop10Filter, "Top10")               
            }

            vm.loadGraphs = () => {
                vm.loadGraphsFilter = checkForFilterChange(vm.loadGraphsFilter, "Graphs")
            }

            vm.loadGeneral = () => {
                vm.loadGeneralFilter = checkForFilterChange(vm.loadGeneralFilter, "General")
            }
            
            //Funtion to open a report in a new tab
            vm.viewReports = (e, submission_id, pr_id) =>{
                if(!e.ctrlKey){
                    lang_number = localStorage.getItem('lang_id')
                    vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/positive_recognition/${submission_id}?lang=${lang_number}&pr_id=${pr_id}`)
                    $window.open(vm.reportURL, "_blank")
                }                
            }

            function validateFilter(filter){
                if(!filter.Jobs)
                    filter.Jobs = [999999999]
                if(!filter.Supervisors)
                    filter.Supervisors = [999999999]                    
            }

            function checkForFilterChange(currentPageFilter, curPage) {
                if (vm.curPage != curPage){
                    vm.curPage = curPage
                    if (vm.curPage !== "General" && currentPageFilter['start_date'] == vm.mainDateFilter["start_date"] && currentPageFilter["end_date"] == vm.mainDateFilter["end_date"]) {                     
                    }
                    else {
                        vm.filterChartsPID()
                        return vm.mainDateFilter
                    }
                }
                return currentPageFilter
            }


            function refreshFiltersPID(filterObject, mode) {
                $scope.$emit('STARTSPINNER', vm.loadMessage)
                let pidFilter = {
                    start_date : filterObject.StartDate,
                    end_date : filterObject.EndDate,
                    users : filterObject.Supervisors,
                    jobs : filterObject.Jobs,
                    values : [],
                    mode: "",
                    toggle : filterObject.toggles
                }
                
                $window.sessionStorage.setItem('siteFilter', JSON.stringify(pidFilter).replaceAll("'","&#39"))
                $window.sessionStorage.setItem('siteBackFilter', JSON.stringify(pidFilter).replaceAll("'","&#39"))
                filterObject.users = filterObject.users ? filterObject.users:[99999999]
                filterObject.Jobs = filterObject.Jobs ? filterObject.Jobs:[999999]
                filterObject.Supervisors = filterObject.Supervisors ? filterObject.Supervisors:[999999]
                if(filterObject.Jobs.length == 0) {
                     filterObject.Jobs = [999999]
                }
                if(filterObject.Supervisors.length == 0) {
                    filterObject.Supervisors = [999999]
               }
                if(filterObject.Jobs.length > 0 && filterObject.Supervisors.length > 0)

                {
                validateFilter(filterObject)
                services = []
                
                if (vm.curPage === "Top10") {
                    services = [positiveIdService.getTop10PositionsRecognized(filterObject),                   
                        positiveIdService.getTop10OneWordPositive(filterObject),
                        positiveIdService.getTop10TwoWordPositive(filterObject)]
                }
                else if (vm.curPage === "General") {   
         
                    services = [
                    positiveIdService.getPositiveIdsFP(filterObject),
                    positiveIdService.getHazardsToPositiveIdFP(filterObject),
                    profileService.getAllEmployeeProfile(),
                    profileService.getPersonProfile()
                    ]

                }
                    $q.all(services).then(() => {
                        let supervisors = profileService.readAllEmployeeProfile()
                            vm.supervisors.length = 0;
                            for (var i = 0; i < supervisors.length; i++) {
                                vm.supervisors.push(supervisors[i]);
                            }
                        let frequencies = listService.getFrequencies();
                            vm.frequencies.length = 0;
                            for (var i = 0; i < frequencies.length; i++) {
                                vm.frequencies.push(frequencies[i]);
                            }

                            if (vm.curPage == "General") {
                                vm.positiveIds = positiveIdService.readPositiveIdData();
                                vm.currentUser = profileService.readPersonProfile();                                
                                if (vm.options.api) {
                                    translateAgGridHeader (vm.options)
                                    vm.options.api.setRowData(preparePositiveIDGridData(vm.positiveIds));
                                    vm.options.api.redrawRows();
                                    vm.options.api.sizeColumnsToFit();
                                }
                                vm.employeeList = profileService.readAllEmployeeProfile()
                                vm.positiveIdCount = vm.positiveIds.length;                                
                                vm.hazardsToPositiveIdAll = positiveIdService.readHazardsToPositiveIdAll();                                
                                $scope.$emit('STOPSPINNER')
                            }
                            else if (vm.curPage == "Graphs") {
                                dateRange={
                                    "start_date": filterObject.StartDate,
                                    "end_date": filterObject.EndDate,             
                                }
                                vm.getPositiveBySite(dateRange)
                                vm.getPositiveByMonthAndYear(dateRange)
                                vm.getPositiveVSIncident(dateRange)
                                $scope.$emit('STOPSPINNER')
                            } else if (vm.curPage == "Top10") {
                                vm.top10PositionsRecognizedData = positiveIdService.readTop10PositionsRecognized()
                                vm.top10OneWordPositiveData = positiveIdService.readTop10OneWordPositive()
                                vm.top10TwoWordPositiveData = positiveIdService.readTop10TwoWordPositive()

                                vm.loadWidgetComponent('top10PositionsRecognized', vm.top10PositionsRecognizedData, translateTag(3686), translateTag(1277), 'pidTop10Position')               // note="Top 10 Positions Recognized"   // note="Position"                      
                                vm.loadWidgetComponent('top10OneWordPositive', vm.top10OneWordPositiveData, translateTag(3684), translateTag(2159), 'pidTop10OneWord')                       // note="Top 10 One Word Themes"        // note="One Word Theme"                        
                                vm.loadWidgetComponent('top10TwoWordPositive', vm.top10TwoWordPositiveData, translateTag(3685), translateTag(2161), 'pidTop10TwoWord')                       // note="Top 10 Two Word Themes"        // note="Two Word Theme"                    
                                $scope.$emit('STOPSPINNER')
                            }


                        })
                    }
                else {
                    if(mode != 'start'){
                        $scope.$emit('STOPSPINNER')
                        toastr.error(translateTag(8626))   //"You Must Select Supervisors and Jobs"
                    }
                }    
            }

            vm.getPositiveBySite = (dateRange) => {
                $q.all([
                    positiveIdService.getPositiveBySite(dateRange)
                ]).then((response)=>{
                    layout = JSON.parse(JSON.stringify(vm.layout).replaceAll("'","&#39"))
                    if (response[0][0].x[0] == 'No Data to Show'){
                        layout.showlegend = false
                    }
                    layout.xaxis.title.text = translateTag(828) // note="Site"
                    layout.yaxis2.title.text = translateTag(3852)  // "Average Recognitions Per Person"
                    layout.legend.y = -1
                    Plotly.newPlot('get-positive-count-by-site', response[0], layout,config)
                })
            }

            vm.loadWidgetComponent = (divId, data, title,subTitle, infoData) => {
                let widgetData = []
                data.forEach((item) => {
                    if(item.keyword=="No Data To Show"){
                        item.keyword=translateTag(3838)
                    }
                    else if(item.keyword=="N/A"){
                        item.keyword=translateTag(1381)
                    }
                    widgetData.push({id:item.id, keyword: item.keyword.toString().replaceAll("'","&#39"), trend:item.trend})
                })
                vm.newdata = JSON.stringify(widgetData).replaceAll("'","&#39")
                $('#'+divId).html($compile(`  
                    <top-ten-widget-form data='${vm.newdata}' title='${title.toString().replaceAll("'","&#39")}' sub-title='${subTitle.toString().replaceAll("'","&#39")}' info-data="${infoData}"></top-ten-widget-form>
                `)($scope))
            }
 
            function preparePositiveIDGridData(data) {
                let gridData = JSON.parse(JSON.stringify(data).replaceAll("'","&#39"))
                gridData.forEach((rec) =>{
                  rec.exceptionFields = ['submitted_by', 'pid_id', 'job_id', 'RecognitionOf', 'mylikeid','MyLikeID', 'like_id', 'signed_by','liked_by_per','comment_by_per', 'parent_form_description_id', 'parent_submission_id', 'JobNumber']
                  rec.endfix = ['_name', 'Name']

                  rec.ID = rec.pid_id
                  rec.header_date = moment(rec.header_date).format('YYYY-MM-DD')
                  rec.submission_date = moment(rec.submission_date).format('YYYY-MM-DD')

                })

                return gridData
            }


            $scope.$on("$destroy", () => {
                $(window).off('resize');
                $(window).off('click');
                $('.sites').off('resize');
            })

            /*
                Positive ID grid
            */

            $scope.$on('menu-width-changed', () => {
                $timeout(function () {
                    vm.options.api.sizeColumnsToFit();
                }, 500);
            })

            //Update Ag-Grid size when window is resized
            $(window).on('resize', () => {
                $timeout(() => {
                    if (vm.options.api) {
                        vm.options.api.sizeColumnsToFit()
                    }
                })
            })


            /*
                Date filter Stuff
            */
            vm.getStartDate = () => {
                if (vm.dateFilter.start_month && vm.dateFilter.start_year) {
                    var monthNum = vm.dateFilter.start_month
                    var sd =`${vm.dateFilter.start_year}-${monthNum}-01`
                    return sd
                }
                return null
            }

            vm.getEndDate = () => {
                
                if (vm.dateFilter.end_month && vm.dateFilter.end_year) {
                    var monthNum = vm.dateFilter.end_month
                    momentEndDate = moment(`${vm.dateFilter.end_year}-${monthNum}-01`,'YYYY-MM-DD')
                    var ed = `${vm.dateFilter.end_year}-${monthNum}-${momentEndDate.endOf('month').format('DD')}`
                    return ed
                }
                return null;
            }

            vm.getDateFilterDescription = () => {
                return vm.dateFilter.getFormattedRange();
            }

            vm.dateFilterMenu = ($event) => {
                $event.stopPropagation();
                vm.hideDropdowns();
                var actions = $('#dateFilterDropdown');
                actions.addClass('show');
            }

            vm.dateFilterValid = () => {
                return vm.dateFilter.validate();
            }

            /*
                Filter Stuff
            */

            vm.rightMenuClosed = true

            $scope.$on('job-filter-changed', (event, args) => {
                if($location.url() === '/a/positive-id'){
                    vm.jobIdArray = args.jobIds
                    vm.supervisorsArray = args.supervisors
                    vm.filterChartsPID()                    
                }             
            })

            vm.layout = {
                showlegend: true,
                legend: {"orientation": "h", 
                        "font":{
                        "family":"Arial", 
                        "size":18
                        },
                        "yanchor":"bottom",
                        "y":-0.5,
                        "xanchor":"center",
                        "x":0.5
                    },
                xaxis: {
                    title: {
                        text: "",
                        font: {
                            family:"Arial",
                            size: 14,
                        //   color: "Black"
                        },  
                    },
                    showgrid:false
                },
                yaxis: {
                    title: {
                        text: translateTag(3854),// 'Positive Recognition Count',
                        font: {
                            family: "Arial",
                            size: 14,
                        //   color: 'black'
                        },
                    },
                    zeroline: false,
                },
                yaxis2: {
                    title: {
                        text: '',
                        font: {
                        family: "Arial",
                        size: 14,
                        // color: 'black'
                        },
                    },
                    zeroline: false,
                    overlaying: 'y', 
                    side: 'right',
                    showgrid:false
                }, 
                barmode:'group'  
            };
            var config = {locale: selectedLanguage,  displaylogo: false,responsive: true}

            vm.getPositiveBySite = (dateRange) => {
                $q.all([
                    positiveIdService.getPositiveBySite(dateRange)
                ]).then((response)=>{
                    layout = JSON.parse(JSON.stringify(vm.layout).replaceAll("'","&#39"))
                    if (response[0][0].x[0] == 'No Data to Show'){
                        layout.showlegend = false
                    }
                    layout.xaxis.title.text = translateTag(828) // note="Site"
                    layout.yaxis2.title.text = translateTag(3852)  // "Average Recognitions Per Person"
                    layout.legend.y = -1
                    Plotly.newPlot('get-positive-count-by-site', response[0], layout,config)
                })
            }

            vm.getPositiveByMonthAndYear = (dateRange) => {
                $q.all([
                    positiveIdService.getPositiveByMonthAndYear(dateRange)
                ]).then((response)=>{
                    layout = JSON.parse(JSON.stringify(vm.layout).replaceAll("'","&#39"))
                    if (response[0][0].x[0] == 'No Data to Show'){
                        layout.showlegend = false
                    }
                    layout.yaxis.title.text = translateTag(3854)
                    layout.xaxis.title.text = translateTag(2050) // note="Month"
                    Plotly.newPlot('get-positive-count-by-month-and-year', response[0], layout,config)
                })
            }

            vm.getPositiveVSIncident = (dateRange) => {
                $q.all([
                    positiveIdService.getPositiveVSIncident(dateRange)
                ]).then((response)=>{
                    layout = JSON.parse(JSON.stringify(vm.layout).replaceAll("'","&#39"))
                    if (response[0][0].x[0] == 'No Data to Show'){
                        layout.showlegend = false
                    }
                    layout.xaxis.title.text = translateTag(1133) // note="Date Range"
                    layout.yaxis2.title.text =  translateTag(3853)    // "Incident Count"
                    Plotly.newPlot('positive-vs-incident', response[0], layout,config)
                })

            }

            function setFiltersForHomepageRedirect(filterObject){
                let supervisorsList = $window.sessionStorage.getItem("homePagePersonList") ? $window.sessionStorage.getItem("homePagePersonList").split(",").map(Number) : []
                $window.sessionStorage.removeItem("homePagePersonList")
                supervisorsList.forEach((item) => {
                    filterObject.Supervisors.push(item)
                })    
                filterObject.Jobs = $window.sessionStorage.getItem("homePageJobList") ? $window.sessionStorage.getItem("homePageJobList").split(",").map(Number) : []
                return filterObject
            }

            vm.filterChartsPID = (mode='normal') => {
                filterObject.Jobs = vm.jobIdArray
                filterObject.Supervisors = vm.supervisorsArray
                filterObject.toggles = vm.toggles
                let startDate = vm.mainDateFilter.start_date
                let endDate = vm.mainDateFilter.end_date
                if(vm.isFromHomePage){
                    filterObject = setFiltersForHomepageRedirect(filterObject)
                    vm.isFromHomePage = false
                }

                if (startDate)
                    filterObject.StartDate = startDate
                    filterObject.start_date = startDate //sarath
                if (endDate)
                    filterObject.EndDate = endDate
                    filterObject.end_date = endDate //sarath
                // getWidegtData(filterObject, mode)
                refreshFiltersPID(filterObject, mode)
                dateRange={
                    "start_date": filterObject.StartDate,
                    "end_date": filterObject.EndDate,             
                }
                $scope.dateRange = dateRange
            }

            

            vm.showHelp = (id) => {
                $('.modal .scroll').scrollTop(0)
                modalService.Open(id)
            }

            let infoObjects = {
                pidCountSite: {
                    title: translateTag(3681), // Positive Recognition Count By Site
                    toolTip: translateTag(8808), // The chart displays the total count as well as the per person average positive recognition submissions grouped by site. The left side vertical axis shows the total number of submissions at a site for the time period selected. On the right side vertical axis we can see the count for the average number of submissions for the selected time period.
                    list: [
                        {
                            label: translateTag(828), // Site
                            description: translateTag(8809) // Sites that have positive recognitions submitted during the selected time span
                        },
                        {
                            label: translateTag(3854), // Positive Recognition Count
                            description: translateTag(8810) // Total number of positive recognitions submitted per site
                        },
                        {
                            label: translateTag(3852), // Average Recognitions per Person
                            description: translateTag(8811) // The average number or of positive recognitions per person at each site
                        }
                    ]
                },
                pidCountMonthYear: {
                    title: translateTag(3682), // Positive Recognition Count by Month and Year
                    toolTip: translateTag(8812), // The chart displays the total number of positive recognitions submitted each month for the time period selected. If multiple years are selected, each year is represented by a different line.
                    list: [
                        {
                            label: translateTag(3854), // Positive Recognition Count
                            description: translateTag(8813) // The total number of positive recognitions submitted
                        },
                        {
                            label: translateTag(2050), // Month
                            description: translateTag(8794) // Displays the months contained in the time period selected
                        }
                    ]
                },
                pidRecognitionIncident: {
                    title: translateTag(3683), // Positive Recognition vs. Incident Counts
                    toolTip: translateTag(8815), // The chart compares the number of positive recognitions submitted and the number of incidents submitted, over a period of time, in an attempt to find a correlation between the two data points. The left side vertical axis represents the number of positive recognitions submitted while the right side vertical axis represents the number of incidents submitted.
                    list: [
                        {
                            label: translateTag(1133), // Date Range
                            description: translateTag(8738) // The time period selected from the page filter
                        },
                        {
                            label: translateTag(3854), // Positive Recognition Count
                            description: translateTag(8813) // The total number of positive recognitions submitted
                        },
                        {
                            label: translateTag(3853), // Incident Count
                            description: translateTag(8816) // The total number of incidents submitted
                        }
                    ]
                },
                pidTop10OneWord: {
                    title: translateTag(3684), // Top 10 One Word Themes
                    toolTip: translateTag(8799), // The list compares the data from the current time span selected with the data from the same period of time that preceded it. The word with the highest count of mentions is displayed at the top of the list. The trend shows the change in item position in the hierarchy between the current and previous time span.
                    list: [
                        {
                            label: "#", // # 
                            description: translateTag(8761) // Order of items with the highest count at 1 and lowest count at 10
                        },
                        {
                            label: translateTag(2159), // One Word Theme
                            description: translateTag(8818) // A single word that is commonly used in the Event Description field
                        },
                        {
                            label: translateTag(2157), // Trend
                            description: translateTag(8763) // The difference in position of item in current time period compared to previous time period
                        }
                    ]
                },
                pidTop10TwoWord: {
                    title: translateTag(3685), // Top 10 Two Word Themes
                    toolTip: translateTag(8819), // The list compares the data from the current time span selected with the data from the same period of time that preceded it. The pair of words with the highest count of mentions is displayed at the top of the list. The trend shows the change in item position in the hierarchy between the current and previous time span.
                    list: [
                        {
                            label: "#", // # 
                            description: translateTag(8761) // Order of items with the highest count at 1 and lowest count at 10
                        },
                        {
                            label: translateTag(2161), // Two Word Theme
                            description: translateTag(8820) // A pair of words that is commonly used in the Event Description field
                        },
                        {
                            label: translateTag(2157), // Trend
                            description: translateTag(8763) // The difference in position of item in current time period compared to previous time period
                        }
                    ]
                },
                pidTop10Position: {
                    title: translateTag(3686), // Top 10 Positions Recognized
                    toolTip: translateTag(8821), // The list compares the data from the current time span selected with the data from the same period of time that preceded it. The positions that have the highest number of mentions is displayed at the top of the list. The trend shows the change in item position in the hierarchy between the current and previous time span.
                    list: [
                        {
                            label: "#", // # 
                            description: translateTag(8761) // Order of items with the highest count at 1 and lowest count at 10
                        },
                        {
                            label: translateTag(1277), // Position
                            description: translateTag(8820) // The position of a user within the company
                        },
                        {
                            label: translateTag(2157), // Trend
                            description: translateTag(8763) // The difference in position of item in current time period compared to previous time period
                        }
                    ]
                }
            }

            vm.openInfoModal = (infoObject) => {
                vm.currentInfo = infoObjects[infoObject]
                modalService.Open('infoModalComponent')
            }

            $scope.$on('OPEN_INFO_MODAL', (event, data) => {
                vm.openInfoModal(data)
            })

        }])