﻿angular
    .module('safeToDo')
    .service('positiveIdService', ['$http',
        function ($http) {
            let positiveIdData = []
            let hazardsToPositiveId = {}
            let hazardsToPositiveIdAll = {}
            let pidComments = []

            let getTop10PositionsRecognizedData = ''
            let getTop10OneWordPositiveData = ''
            let getTop10TwoWordPositiveData = ''

            let color_palette = ["#0072ce", "#66aae2", "#F7BD03","#00447c", "#6e94ba", "#7272ad", "#d8bd87", "#447259", "#474747", "#b3bccf", 
            "#99bcac", "#a9ddff", "#96a9aa", "#001e60", "#777777", "#005ba5", "#0087b3", "#002e52", "#99c7eb", "#a4a1d5", "#00445a", 
            "#378ddc", "#424686", "#fcecb3", "#9c6492", "#16492d", "#d193ae", "#eacfce", "#8a7fd0", "#616699", "#006586", "#ddab00", 
            "#c292cd", "#d6d3ff", "#5f3c79", "#00a9e0", "#ffb359", "#58cad3"]

            let noData = [{type:'bar', x: [translateTag(3838)], y: [0]}] // note="No Data to Show"

            function checkNull(y){
                c = 0
                for(let i in y){
                    if(y[i] != null){
                        c += 1
                        if(c > 1){
                            return false
                        }
                    }
                }
                return true
            }

            return {
                addLike: (headerId) => {
                    var signoff = {
                        submission_pid: headerId,                        
                    }     
                    return $http.post(`${__env.apiUrl}/api/recognition/add-likes/`, signoff)
                        .then((data) => {                            
                            return data
                        },
                        (status) => {
                            console.log('`Like` post failed - ', status)
                            return null
                        })
                },
                deleteLike: (signoffId) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/delete-likes-by-like-id/`,{ "like_id": signoffId })
                        .then(() => {
                            return true
                        },(data, status) =>{
                            console.log('`Like` delete failed - ' + status)
                            return false
                        })
                },
                getLikesByHeader: (headerId, recognitionOf) => {                    
                    return $http.post(`${__env.apiUrl}/api/recognition/get-likes-by-positive-recognition-id/`,{"recognition_id": headerId, "recognition_of":recognitionOf })
                        .then((data) => {
                            return data.data
                        },(data, status) =>{
                            console.log('`Like` get failed - ', status)
                            return null;
                        })
                },
                getPositiveIdsFP: (filter) => {
                  return $http.post(`${__env.apiUrl}/api/recognition/get-recognition-list/`, filter).then((response) => {
                        positiveIdData = response.data                        
                    }, (args) => {
                        console.log('Failed to load positive ids.',args)
                    })
                },  
                getCommentsByPID: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/get-comment-list/`, payload).then((response) => {
                        pidComments = response.data;

                    }, (args) => {
                        console.log('Failed to load comments data', args);
                    })
                },              
                getHazardsToPositiveIdFP: (filter) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/get-positive-hazard-ratio/`, filter).then((response) => {
                        hazardsToPositiveIdAll = response.data
                    }, (args) => {
                        console.log('Failed to load positive ids.', args)
                    });
                },

                getTop10PositionsRecognized: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/get-top-10-recognition-position-pid/`, dateRange).then((response) => { 
                        getTop10PositionsRecognizedData = response.data
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },
       
                getTop10OneWordPositive: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/get-top-10-one-word-theme-pid/`, dateRange).then((response) => { 
                        getTop10OneWordPositiveData = response.data
                        return response.data                    
                        
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getTop10TwoWordPositive: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/get-top-10-two-word-theme-pid/`, dateRange).then((response) => { 
                        getTop10TwoWordPositiveData = response.data
                        return response.data                    
                        
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                getPositiveBySite: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/pid-count-by-site/`, dateRange).then((response) => { 
                        if (response.data == 'No Data to Show'){
                            return noData
                        }
                        else{
                            data=[]
                            data.push({
                                type: 'bar',
                                x: response.data.x_axis,
                                y: response.data.y_axis[0],                                
                                name: translateTag(3854), // 'Positive Recognition Count',
                                yaxis: 'y',
                                offsetgroup: 1,
                                }
                            ), 
                            data.push({
                                type: 'bar',
                                x: response.data.x_axis,
                                y: response.data.y_axis[1],
                                marker: {
                                    color: 'rgb(247,189,3)'
                                },
                                name: translateTag(3852), // 'Average Recognitions Per Person',
                                yaxis: 'y2',
                                offsetgroup: 2,                                
                                }
                            ) 
                        }                 
                        return data     
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },
                
                getPositiveByMonthAndYear: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/pid-count-by-month-and-year/`, dateRange).then((response) => { 
                        if (response.data == 'No Data to Show'){
                            return noData
                        }
                        else{
                            // month_name = translateTag(agGridFieldTags[response.data[year].hazard_month_name])
                            curdata = response.data
                            data=[]
                            year = ""
                            for(let i in curdata){
                                if (year != curdata[i].pid_year) {
                                    if (year != '' && checkNull(data[data.length - 1].y)){
                                            data[data.length - 1].mode = 'markers'
                                    }
                                    year = curdata[i].pid_year
                                    data.push({
                                        type: 'scatter',
                                        // x: ["January","February","March","April","May","June","July","August","September","October","November","December"],
                                        x: [translateTag(2135),translateTag(2136),translateTag(2137),translateTag(2138),translateTag(2139),translateTag(2140),translateTag(2141),translateTag(2142),translateTag(2143),translateTag(2144),translateTag(2145),translateTag(2146)],
                                        y: [null, null, null, null, null, null, null, null, null, null, null, null],
                                        mode: 'lines',
                                        name: year,
                                        line: {
                                        color: color_palette[data.length],
                                        width: 1
                                        }
                                    })
                                }
                                data[data.length - 1].y[parseInt(curdata[i].pid_month_num) - 1] = parseInt(curdata[i].pid_count)
    
                            }
                            if (checkNull(data[data.length - 1].y)){
                                data[data.length - 1].mode = 'markers'
                            }
                            return data 
                        }    
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })


                },

                getPositiveVSIncident: (dateRange) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/pid-vs-incident-count/`, dateRange).then((response) => { 
                        if (response.data == 'No Data to Show'){
                            return noData
                        }
                        else{
                            data=[]
                            data.push({
                                type: 'scatter',
                                x: response.data.x_axis,
                                y: response.data.y_axis[0],
                                mode: 'lines',
                                name: translateTag(751), // note="Positive Recognition"
                                line: {
                                color: 'rgb(3,114,206)',
                                width: 1
                                }
                            }) 
                            data.push({
                                type: 'scatter',
                                x: response.data.x_axis,
                                y: response.data.y_axis[1],
                                mode: 'lines',
                                name: translateTag(1170), // note="Incident"
                                yaxis: 'y2',
                                line: {
                                color: 'rgb(247,189,3)',
                                width: 1
                                }
                            }) 
                        }
                        return data    
                    }, (args) => {
                        console.log('Failed to load action trend data.', args)
                    })
                },

                readPositiveIdData: () => {                 
                    return positiveIdData
                },
                readHazardsToPositiveId: () =>{
                    return hazardsToPositiveId
                },
                readHazardsToPositiveIdAll: () =>{
                    return hazardsToPositiveIdAll
                },
                readTop10PositionsRecognized:()=>{
                    return getTop10PositionsRecognizedData
                },
                readTop10OneWordPositive:()=>{
                    return getTop10OneWordPositiveData
                },
                readTop10TwoWordPositive:()=>{
                    return getTop10TwoWordPositiveData
                },
                readPositiveIdComments: () => {
                    return pidComments
                },
            }
        }
    ])