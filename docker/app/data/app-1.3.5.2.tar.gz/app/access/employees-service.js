﻿angular
    .module('safeToDo')
    .service('employeesService', ['$http',
        function ($http) {

            var employeesPromise = $http.get('/api/Employees' + '?bust=' + new Date().getTime())
                .then(function (response) {
                    for (var i = 0; i < response.data.length; i++) {
                        employees.O[response.data[i].ID] = response.data[i];
                        employees.A.push(response.data[i]);
                    }
                }, function (args) {
                    console.log('Failed to load employees.');
                    console.log(args);
                });

            var employees = {
                O: {},
                A: []
            };

            var meP = $http.get('/api/Employees/me')
                .then(function (params) {
                    params.data.error = '';
                    return params.data;
                }, function (errParams) {
                    var errorObj = {};
                    if (errParams.status == 404) {
                        errorObj.error = 'User not found - Contact a system administrator';
                    }
                    return errorObj;
                });

            return {

                createClient: function (client) {
                    return $http.post('/api/Employees/Client', client)
                        .then(function (response) {
                            toastr.success('Client created successfully.');
                            return response.data;
                        }, function (errorParams) {
                            console.log('Failed to create client:', client);
                            console.log(errorParams);
                            toastr.error(errorParams.data.error, { tapToDismiss: true, timeout: 7000 });

                            return errorParams.data.error;
                        });
                },
                getEmployeesP: function () {
                    return employeesPromise;
                },
                getEmployees: function () {
                    return employees;
                },
                getEmployeeP: function (employeePK) {
                    return $http.get('/api/Employees/' + employeePK + '?bust=' + new Date().getTime())
                        .then(function (response) {
                            if (!!employees.O[response.data.ID + '']) //overwrite old in-memory copy
                                Object.assign(employees.O[response.data.ID + ''], response.data);

                            return response.data;
                        }, function (args) {
                            console.log('Failed to load employees.');
                            console.log(args);
                        });
                },
                getEmployeeJobs: function (employeePK) {
                    return $http.get('/api/Employees/' + employeePK + '/Jobs?bust=' + new Date().getTime())
                        .then(function (response) {
                            return response.data;
                        }, function (args) {
                            console.log('Failed to load employee jobs for employee ' + employeePK);
                            console.log(args);
                        });
                },
                toggleEmployeeJob: function (job) {
                    var empId = job.EmployeePK;
                    var jobId = job.Job;
                    var linkActive = job.LinkActive; //since we're toggling link, place opposite of current into url'
                    return $http.put('/api/Employees/' + empId + '/Jobs/' + jobId + '/link/' + (linkActive ? 0 : 1))
                        .then(function (success) {
                            return !linkActive;
                        });
                },
                setAllJobs: function (employeePK, onOff, activeJobs) {
                    return $http.put('/api/Employees/' + employeePK + '/jobs/' + activeJobs + '/links/' + onOff);
                },
                setAllSiteJobs: function (employeePK, onOff, activeJobs, siteId) {
                    return $http.put('/api/Employees/' + employeePK + '/jobs/' + activeJobs + '/sites/' + siteId + '/links/' + onOff);
                },
                getMeP: function (refresh) {
                    if (!refresh)
                        return meP;
                    meP = $http.get('/api/Employees/me')
                      .then(function (params) {
                            params.data.error = '';
                            return params.data;
                        }, function (errParams) {
                            var errorObj = {};
                            if (errParams.status == 404) {
                                errorObj.error = 'User not found - Contact a system administrator';
                            }
                            return errorObj;
                        });
                    return meP;
                },
                getPersonProfile: () =>{
                    let personProfile = $http.get(`${__env.apiUrl}/api/userprofile/get-person-profile/${selectedLanguage}/`).then((params)=> {
                        params.data.error = '';
                        return params.data[0];
                      }, (errParams) => {
                          var errorObj = {};
                          if (errParams.status == 404) {
                              errorObj.error = 'User not found - Contact a system administrator';
                          }
                          return errorObj;
                      });
                    return personProfile
                }
            };
        }
    ]);