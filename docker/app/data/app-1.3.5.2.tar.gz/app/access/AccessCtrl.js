﻿function getTextWidth(text, font) {
    // re-use canvas object for better performance
    var canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement("canvas"));
    var context = canvas.getContext("2d");
    context.font = font;
    var metrics = context.measureText(text);
    return metrics.width;
}

angular
    .module('safeToDo')
    .controller('AccessCtrl', ['$scope', '$routeParams', '$timeout', '$document', '$q', 'employeesService', 'authService', 'gridService', 'modalService', 'listService', function ($scope, $routeParams, $timeout, $document, $q, employeesService, authService, gridService, modalService, listService) {
        var vm = this;
        vm.canManageAccess = false;
        vm.options = gridService.getCommonOptions();
        vm.groupGridOptions = gridService.getCommonOptions();
        vm.employees = [];
        vm.topSearch = "";
        vm.topSearchChanged = function () {
            vm.options.api.onFilterChanged();
            vm.groupGridOptions.api.onFilterChanged();
        };
        vm.options.isExternalFilterPresent = function () {
            return vm.topSearch !== "";
        };
        vm.options.doesExternalFilterPass = function (gridRow) {
            for (var property in gridRow.data) {
                if (gridRow.data.hasOwnProperty(property)) {
                    //any property in the row matches search box
                    if ((gridRow.data[property] + "").toLowerCase().indexOf(vm.topSearch.toLowerCase()) > -1) {
                        return true;
                    }
                }
            }
            return false;
        };
        vm.groupGridOptions.isExternalFilterPresent = function () {
            return vm.topSearch !== "";
        };
        vm.groupGridOptions.doesExternalFilterPass = function (gridRow) {
            for (var property in gridRow.data) {
                if (gridRow.data.hasOwnProperty(property)) {
                    //any property in the row matches search box
                    if ((gridRow.data[property] + "").toLowerCase().indexOf(vm.topSearch.toLowerCase()) > -1) {
                        return true;
                    }
                }
            }
            return false;
        };
        vm.editModel = {
            EmployeeID: null,
            EmployeeName: null,
            clearOther: function () {
                for (var property in this.other) {
                    if (this.other.hasOwnProperty(property)) {
                        this.other[property] = null;
                    }
                }
            },
            clear: function () {
                this.EmployeeID = null;
                this.EmployeeName = null;
                this.clearOther();
            },
            other: {},
            copyOther: function (copyFrom) {
                for (var property in this.other) {
                    if (this.other.hasOwnProperty(property)
                        && copyFrom.hasOwnProperty(property)) {
                        this.other[property] = copyFrom[property];
                    }
                }
            },
            copyOtherTo: function (copyTo) {
                for (var property in this.other) {
                    if (this.other.hasOwnProperty(property)) {
                        copyTo[property] = this.other[property];
                    }
                }
            },
            copy: function (copyFrom) {
                this.EmployeeID = copyFrom.ID;
                this.EmployeeName = copyFrom.EmployeeName;
                this.copyOther(copyFrom);
            },
            copyTo: function (copyToObj) {
                copyToObj.ID = this.EmployeeID;
                copyToObj.EmployeeName = this.EmployeeName;
                this.copyOtherTo(copyToObj);
            },
            getForSave: function () {
                var saveUserRoles = {};
                saveUserRoles.RoleMaskList = [];
                saveUserRoles.EmployeeID = this.EmployeeID;
                for (var property in this.other) {
                    if (this.other.hasOwnProperty(property)) {
                        var pieces = property.split('_');
                        var pieceId = pieces[pieces.length - 1];
                        saveUserRoles.RoleMaskList.push({ RoleID: pieceId, Active: this.other[property]});
                    }
                }
                return saveUserRoles;
            },
        };

        vm.groupEditModel = {
            GroupID: null,
            Name: null,
            clearOther: function () {
                for (var property in this.other) {
                    if (this.other.hasOwnProperty(property)) {
                        this.other[property] = null;
                    }
                }
            },
            clear: function () {
                this.GroupID = null;
                this.GroupName = null;
                this.clearOther();
            },
            other: {},
            copyOther: function (copyFrom) {
                for (var property in this.other) {
                    if (this.other.hasOwnProperty(property)
                        && copyFrom.hasOwnProperty(property)) {
                        this.other[property] = copyFrom[property];
                    }
                }
            },
            copyOtherTo: function (copyTo) {
                for (var property in this.other) {
                    if (this.other.hasOwnProperty(property)) {
                        copyTo[property] = this.other[property];
                    }
                }
            },
            copy: function (copyFrom) {
                this.GroupID = copyFrom.ID;
                this.Name = copyFrom.Name;
                this.copyOther(copyFrom);
            },
            copyTo: function (copyToObj) {
                copyToObj.ID = this.GroupID;
                copyToObj.Name = this.Name;
                this.copyOtherTo(copyToObj);
            },
            getForSave: function () {
                var saveGroupRoles = {};
                saveGroupRoles.RoleMaskList = [];
                saveGroupRoles.GroupID = this.GroupID;
                for (var property in this.other) {
                    if (this.other.hasOwnProperty(property)) {
                        var pieces = property.split('_');
                        var pieceId = pieces[pieces.length - 1];
                        saveGroupRoles.RoleMaskList.push({ RoleID: pieceId, Active: this.other[property] });
                    }
                }
                return saveGroupRoles;
            },
        };

        var defWidth = 10;
        var employeeTableColumns = [
            {
                field: "EmployeeName", headerName: "Employee", minWidth: 300, maxWidth: 300, 
                cellRenderer: function (params) {
                    var email = params.data.Email == null ? '' : params.data.Email;
                    var name = params.data.EmployeeName;
                    return '<div><div class="supervisor-name">' + name + '</div><div class="supervisor-email">' + email + '</div></div>';
                },
            },
            //{
            //    field: "Sites", headerName: "Jobs", valueGetter: function (params) {
            //        var sites = params.data[params.colDef.field];
            //        return concatSiteData(sites);
            //    }
            //},
            //{
            //    field: "ADLogin", headerName: "Network Login", maxWidth: 200
            //},
            //{
            //    field: "FastFieldAccount", headerName: "Fast Field Login", maxWidth: 250
            //},
            {
                colId: "actions",
                suppressMenu: true,
                headerName: "",
                minWidth: 50,
                maxWidth: 50,
                cellRenderer: function (params) {
                    return '<span class="flex-actions" ng-click="access.actionsMenu('
                        + params.data.ID
                        + ', ' + params.rowIndex + ', $event);"><img class="jump-icon" src="images/icon-more-dots.svg" /></span>';
                }
            },
        ];

        vm.groupGridOptions.columnDefs = [{ field: "Name", headerName: "Name", minWidth: 300, maxWidth: 300 }, {
            colId: "actions",
            suppressMenu: true,
            headerName: "",
            minWidth: 50,
            maxWidth: 50,
            cellRenderer: function (params) {
                return '<span class="flex-actions" ng-click="access.groupActionsMenu('
                    + params.data.ID
                    + ', ' + params.rowIndex + ', $event);"><img class="jump-icon" src="images/icon-more-dots.svg" /></span>';
            }
        }];

        vm.whichActionMenu = 'employee';
        vm.actionsMenu = function (employeeId, rowIndex, $event) {
            $event.stopPropagation();
            vm.whichActionMenu = 'employee';
            vm.rowContextId = employeeId;
            if (rowIndex !== null) {
                vm.rowContextIndex = rowIndex;
            }
            var y = $event.pageY;
            var x = 70;
            var actions = $('#userActionDropdown');
            actions.addClass('show');
            actions.css({ top: y, right: x });
        };
        vm.groupActionsMenu = function (groupId, rowIndex, $event) {
            $event.stopPropagation();
            vm.whichActionMenu = 'group';
            vm.groupRowContextId = groupId;
            if (rowIndex !== null) {
                vm.groupRowContextIndex = rowIndex;
            }
            var y = $event.pageY;
            var x = 70;
            var actions = $('#groupActionDropdown');
            actions.addClass('show');
            actions.css({ top: y, right: x });
        };

        vm.closeModal = function (id) {
            modalService.Close(id);
        };
        vm.options.getRowNodeId = function (data) {
            return data.ID;
        };
        vm.groupGridOptions.getRowNodeId = function (data) {
            return data.ID;
        };

        vm.save = function () {
            var saveO = vm.editModel.getForSave();
            authService.updateRoleMask(saveO)
                .then(function () {
                    // console.log('role mask save success - refreshing employee');
                    vm.closeModal('userEditModal');
                    employeesService.getEmployeeP(saveO.EmployeeID)
                        .then(function (data) {
                            var node = vm.options.api.getRowNode(saveO.EmployeeID);
                            node.setData(data);
                            vm.options.api.refreshCells({
                                rowNodes: [node],
                                force: true
                            });
                            // console.log('employee refreshed')
                        });
                });
        };

        vm.saveGroup = function () {
            var saveO = vm.groupEditModel.getForSave();
            authService.updateGroupRoleMask(saveO)
                .then(function () {
                    // console.log('role mask save success - refreshing group');
                    vm.closeModal('groupEditModal');
                    authService.getGroupP(saveO.GroupID)
                        .then(function (data) {
                            var node = vm.groupGridOptions.api.getRowNode(saveO.GroupID);
                            node.setData(data);
                            // console.log('group refreshed')
                        });
                });
        };

        function concatSiteData(sites) {
            var siteListString = "";
            for (var i = 0; i < sites.length; i++) {
                if (sites[i].EmployeeJobCount > 0) {
                    siteListString += sites[i].SiteDescription + " (" + sites[i].EmployeeJobCount + "), ";
                }
            }

            siteListString = siteListString.slice(0, -2);
            return siteListString;
        }

        vm.jobSearch = "";
        vm.jobSearchChanged = function () {
            var lcaseJobSearch = vm.jobSearch.toLowerCase();

            for (var s = 0; s < vm.jobs.length; s++) {
                var siteRef = vm.jobs[s];
                var siteOn = false;
                for (var j = 0; j < siteRef.Jobs.length; j++) {
                    var jobRef = siteRef.Jobs[j];
                    var lcaseJobName = jobRef.Job.toLowerCase();
                    jobRef.searchMatched = lcaseJobName.indexOf(lcaseJobSearch) > -1;
                    siteOn = siteOn || jobRef.searchMatched;
                }
                siteRef.searchMatched = siteOn;
            }
        };
        vm.options.columnDefs = employeeTableColumns;
        vm.options.headerHeight = 100;

        vm.groupGridOptions.headerHeight = 100;

        var defWidth = 10;
        vm.options.onColumnResized = function (params) {
            if (params.column.colDef.field === 'Sites') {
                defWidth = params.column.actualWidth;
            }
        };

        vm.rightMenuClosed = true;
        vm.viewActiveJobsBit = true;

        vm.viewActiveJobs = function (bit) {
            vm.viewActiveJobsBit = bit;
        };

        vm.closeMenu = function () {
            vm.rightMenuClosed = true;
        };
        vm.toggleJob = function (job, site) {
        //    console.log(job);
            employeesService.toggleEmployeeJob(job)
                .then(function (newValue) {
                    job.LinkActive = newValue;
                    site.ActiveJobCount += newValue ? 1 : -1;
                    if (vm.viewActiveJobsBit == 1)
                        vm.activeJobCount += newValue ? 1 : -1;
                    else
                        vm.closedJobCount += newValue ? 1 : -1;
                    vm.refreshEmployee(vm.currentRow);
                });
        };

        vm.check = function ($event, site) {
            $event.stopPropagation();

            //activate all jobs if not all checked, deactivate if all checked
            var activate = site.ActiveJobCount < site.TotalJobCount;
            for (var i = 0; i < site.Jobs.length; i++) {
                site.Jobs[i].LinkActive = activate;
            }

            site.ActiveJobCount = activate ? site.TotalJobCount : 0;

            employeesService.setAllSiteJobs(vm.selectedEmployee.ID, activate, vm.viewActiveJobsBit, site.SiteID)
                .then(function () {
                    vm.refreshEmployee(vm.currentRow);
                });

            vm.setSiteHidden(site);
            //vm.filterCharts();
        };

        vm.jobsActive = function (site) {
            if (site.ActiveJobCount === site.TotalJobCount) {
                return 'all';
            }
            if (site.ActiveJobCount > 0) {
                return 'some';
            }
            return 'none';
        };

        vm.getCheckboxState = function (site) {
            var state = vm.jobsActive(site);
            switch (state) {
                case 'none':
                    return '';
                case 'some':
                    return '-partial';
                case 'all':
                    return '-selected';
            }
        };

        vm.setSiteHidden = function (site) {
            site.moreHidden = site.ActiveJobCount > 0 && site.ActiveJobCount < site.TotalJobCount;
        };

        vm.toggleSiteExpanded = function(site) {
            if (site.expanded) { //toggling site expansion off should reset its 'show more' section
                site.moreHidden = true;
            }
            site.expanded = !site.expanded;
        };

        vm.jobs = [];
        vm.filteredJobs;
        vm.selectedEmployee = null;
        vm.currentRow = null;

        function employeeRowClicked(params) {
            vm.currentRow = params.node;
            vm.selectedEmployee = params.data;
            employeesService.getEmployeeJobs(params.data.ID)
                .then(function (result) {
                    // console.log(result);
                    vm.rightMenuClosed = false;
                    vm.jobs.length = 0;

                    vm.jobs = result.ActiveJobs;
                    vm.closedJobs = result.ClosedJobs;
                    vm.activeJobCount = 0;
                    vm.closedJobCount = 0;

                    for (var i = 0; i < vm.jobs.length; i++) {
                        //base initial expandedness on site having active jobs or not
                        vm.jobs[i].expanded = vm.jobs[i].JobLinkActive;
                        vm.jobs[i].moreHidden = vm.jobs[i].expanded; //if there are no active/inactive jobs to separate, do away with this
                        if (vm.jobs[i].TotalJobCount === vm.jobs[i].ActiveJobCount) {
                            vm.jobs[i].moreHidden = false;
                        }
                        vm.activeJobCount += vm.jobs[i].ActiveJobCount;
                    }

                    for (var i = 0; i < vm.closedJobs.length; i++) {
                        //base initial expandedness on site having active jobs or not
                        vm.closedJobs[i].expanded = vm.closedJobs[i].JobLinkActive;
                        vm.closedJobs[i].moreHidden = vm.closedJobs[i].expanded; //if there are no active/inactive jobs to separate, do away with this
                        if (vm.closedJobs[i].TotalJobCount === vm.closedJobs[i].ActiveJobCount) {
                            vm.closedJobs[i].moreHidden = false;
                        }
                        vm.closedJobCount += vm.closedJobs[i].ActiveJobCount;
                    }
                    vm.jobSearchChanged();
                });
        };

        vm.edit = function () {
            // console.log('edit ' + vm.rowContextId);
            vm.mode = 'Edit';
            editTargetRef = vm.getEditObject();
            vm.editModel.copy(editTargetRef);

            vm.openModal('userEditModal');
        };

        vm.editGroup = function () {
            // console.log('edit ' + vm.groupRowContextId);
            vm.mode = 'Edit';
            editTargetRef = vm.getGroupEditObject();
            vm.groupEditModel.copy(editTargetRef);

            vm.openModal('groupEditModal');
        };

        vm.openModal = function (id) {
            if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                $scope.$apply();

            modalService.Open(id);
        };

        vm.getEditObject = function () {
            return vm.options.api.getRowNode(vm.rowContextId).data;
        };

        vm.getGroupEditObject = function () {
            return vm.groupGridOptions.api.getRowNode(vm.groupRowContextId).data;
        };

        // disabled at the request of Mat - currently wants Employee Job association to be 100% automated
        //vm.options.onRowDoubleClicked = employeeRowClicked;

        vm.refreshEmployee = function (currentRow) {
            var rowRef = currentRow;
            employeesService.getEmployeeP(rowRef.data.ID)
                .then(function (ret) {
                    rowRef.data = ret;
                    var updateNodes = [rowRef];
                    vm.options.api.refreshRows(updateNodes);
                    $timeout(function () {
                        vm.options.api.sizeColumnsToFit();
                    }, 500);
                });
        };

        vm.checkAllBoxes = function (tf) {
            var sitesRef = vm.viewActiveJobsBit == 1 ? vm.jobs : vm.closedJobs;
            //if (vm.viewActiveJobsBit == 1)
            //    vm.activeJobCount = tf == 1 ? sitesRef.length : 0;
            //else
            //    vm.closedJobCount = tf == 1 ? sitesRef.length : 0;
            var count = 0;
            for (var s = 0; s < sitesRef.length; s++) {
                var siteRef = sitesRef[s];
                for (var j = 0; j < siteRef.Jobs.length; j++) {
                    var jobRef = siteRef.Jobs[j];
                    jobRef.LinkActive = tf;
                    count += tf;
                }
                siteRef.ActiveJobCount = tf ? siteRef.TotalJobCount : 0;
            }
            if (vm.viewActiveJobsBit == 1)
                vm.activeJobCount = count;
            else
                vm.closedJobCount = count;

        };
        
        vm.selectAll = function () {
            if (vm.selectedEmployee == null)
                return;

            employeesService.setAllJobs(vm.selectedEmployee.ID, 1, vm.viewActiveJobsBit)
                .then(function () {
                    vm.checkAllBoxes(true);
                    vm.refreshEmployee(vm.currentRow);
                });
        };

        vm.clearAll = function () {
            employeesService.setAllJobs(vm.selectedEmployee.ID, 0, vm.viewActiveJobsBit)
                .then(function () {
                    vm.checkAllBoxes(false);
                    vm.refreshEmployee(vm.currentRow);
                });
        };

        // vm.rolesLookup = {};
        // authService.getRolesP()
        //     .then(function (ret) {
        //         for (var i = 0; i < ret.length; i++) {
        //             vm.rolesLookup['Role_' + ret[i].Role] = ret[i];

        //             vm.options.columnDefs.push(
        //                 {
        //                 field: "Role_" + ret[i].Role,
        //                 headerName: ret[i].RoleName,
        //                 headerTooltip: ret[i].RoleName,
        //                 maxWidth: 240,
        //                 minwidth: 100,
        //                 valueGetter: function (params) {
        //                   var groupFieldName = 'G' + params.colDef.field;
        //                   if (!!params.data[groupFieldName]) {
        //                     return 'YES';
        //                   }
        //                   return gridService.yesNoValueGetter(params);
        //                 },

        //                     cellRenderer: function (params) {
        //                         var groupFieldName = 'G' + params.colDef.field;
        //                         if (!!params.data[groupFieldName]) {
        //                             return '<span class="overridden-value" title="Overridden by Group">'
        //                                 + gridService.valToYesNo(params.data[params.colDef.field])
        //                                 + '</span><span class="new-value">YES</span>';
        //                         }
        //                         return params.value;
        //                     },
        //                 });
        //             vm.editModel.other["Role_" + ret[i].Role] = null;

        //             vm.groupGridOptions.columnDefs.push(
        //                 {
        //                 field: "Role_" + ret[i].Role,
        //                 headerName: ret[i].RoleName,
        //                 headerTooltip: ret[i].RoleName,
        //                 maxWidth: 300,
        //                 minWidth: 100,
        //                 valueGetter: gridService.yesNoValueGetter
        //             });

        //             vm.groupEditModel.other["Role_" + ret[i].Role] = null;
        //         }
                
        //         vm.options.api.setColumnDefs(vm.options.columnDefs);
        //         vm.groupGridOptions.api.setColumnDefs(vm.groupGridOptions.columnDefs);
        //     });

        // vm.groups = [];

        // authService.getGroupsP()
        //     .then(function (ret) {
        //         for (var i = 0; i < ret.length; i++) {
        //             vm.groups.push(ret[i]);
        //         }
        //         vm.groupGridOptions.api.setRowData(vm.groups);
        //         vm.groupGridOptions.api.redrawRows();
        //         $timeout(function () {
        //             vm.groupGridOptions.api.sizeColumnsToFit();
        //         }, 500);    
        //     });

        // employeesService.getEmployeesP().then(function () {
        //     vm.employees = employeesService.getEmployees().A;
        //     // Only display employees with AD Logins
        //     vm.employees = vm.employees.filter(function (emp) {
        //         //if (emp.Email && emp.Email.indexOf('technicagroup.com') !== -1) return true;
        //         if (emp.ADLogin && emp.ADLogin.length > 0) return true;
        //         return false;
        //   });
        //   if (vm.options.api) {
        //     vm.options.api.setRowData(vm.employees);
        //     vm.options.api.redrawRows();
        //     $timeout(function () {
        //       vm.options.api.sizeColumnsToFit();
        //     }, 500);
        //   }
        // });

        // employeesService.getMeP().then(function (userData) {
        //     for (var i = 0; i < userData.Roles.length; i++) {
        //         if (userData.Roles[i] === 'CanManageAccess') {
        //             vm.canManageAccess = true;
        //         }
        //     }
        // });
        
        // /* 
        //  * Adding clients 
        //  * */
        // vm.sites = [];
        // vm.jobs = [];
        // $q.all([
        //     //$http.get('/api/Lists/Sites').then(function (response) { return response.data; }, function (error) { console.log(error); }),
        //     listService.getJobsP(),
        //     listService.getSitesP()
        // ])
        // .then(function (responses) {
        //     vm.jobs = responses[0];
        //     vm.sites = responses[1];
        // });

        // vm.newClient = {
        //     FirstName: null
        //     , LastName: null
        //     , EmployeeType: null
        //     , LastSite: null
        //     , ADLogin: null
        //     , Email: null
        //     , Jobs: []
        // };

        // function resetSemanticUI() {
        //     $('.ui.dropdown').dropdown();

        //     // Clear Employees Involved dropdown
        //     $('.search.ui.dropdown').dropdown('clear');

        // };

        // function resetForm() {
        //     vm.newClient = {
        //         FirstName: null
        //         , LastName: null
        //         , EmployeeType: null
        //         , LastSite: null
        //         , ADLogin: null
        //         , Email: null
        //         , Jobs: []
        //     };
        //     //    employees_involved: [],
        //     //    immediate_causes: [newImmediateCause()],
        //     //    basic_causes: [newBasicCause()],

        //     //}; // Form Object -- will contain all root-cause-analysis data
        // };

        // vm.addClient = function () {
        //     console.log('add new client ');
        //     vm.openModal('clientAddModal');
        //     resetForm();
        //   $('.select-multiple').select2({ allowClear: true, placeholder: "", width: '100%' });
        // };

        // vm.cancelClient = function () {
        //     vm.closeModal('clientAddModal');
        // };

        // vm.saveClient = function () {
        //     employeesService.createClient(vm.newClient).then(function (response) {
        //         console.log('new client created');

        //         if (response && response.indexOf('Error') >= 0) {
        //             vm.openModal('clientAddModal');
        //             return;
        //         }
        //         else 
        //             vm.closeModal('clientAddModal');

        //     });
        // };

        // $scope.$on('menu-width-changed', function () {
        //     $timeout(function () {
        //         vm.options.api.sizeColumnsToFit();
        //         vm.groupGridOptions.api.sizeColumnsToFit();
        //     }, 500);
        // });

        // angular.element($document[0].body).bind("click", function (event) {
        //     $('.dropdown-content').removeClass('show');
        // });

        // $(window).on('resize', function () {
        //     $timeout(function () {
        //         vm.options.api.sizeColumnsToFit();
        //         vm.groupGridOptions.api.sizeColumnsToFit();
        //     });
        // });

        // $scope.$on("$destroy", function () {
        //     $(window).off('resize');
        // });

        // function jobListHeight() {
        //     var height = $(window).outerHeight() - $('.filter-drawer-header').outerHeight(true);
        //     $('.job-list').css({ "max-height": height - 50 + "px" });
        // }

        // $(function () {
        //     jobListHeight();
        // });
    }]);