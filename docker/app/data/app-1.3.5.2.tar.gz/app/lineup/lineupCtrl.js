﻿angular
  .module('safeToDo')
  .controller('LineupCtrl', ['$scope','$rootScope', '$timeout', '$window', '$q', '$compile', '$sce','modalService', 'lineupService', 
  'gridService', 'signoffService' , 'profileService', 'menuService', 'documentLockService', 'exportCSV',
    function ($scope,$rootScope, $timeout, $window, $q, $compile, $sce, modalService, lineupService, 
      gridService, signoffService, profileService, menuService, documentLockService, exportCSV) {
      vm = this
      
      vm.topSearch = "";
      vm.lineupData = []
      vm.employeeList = []
      vm.fullEmployeeList = []
      vm.signoffIdContext = 0
      vm.headerDataContext = {}
      vm.employeeProfile = {}
      vm.selectedRows = []
      vm.LineupDataContext = {}
      vm.lineupState = null
      vm.actionDisabled = true
      vm.canArchiveSubmissions = false
      vm.canManageLineup = false
      

      vm.translateLabels = (key) =>{      
        return translateTag(key)
      }
      vm.loadMessage = vm.translateLabels('3560') // "Loading lineups. Please wait."
      vm.openModal = (id, mode = 'new', lineupID, lineupLockID) => {
        if(mode === 'new'){
          $scope.$emit('STARTSPINNER', vm.loadMessage)
          $('#insertModal').html($compile(`  
            <lineup-form mode="${mode}" editlineupid="${lineupID}" doclocklineupid="${lineupLockID}"></lineup-form>
          `)($scope))
        }
        else if (mode === 'edit'){
            vm.documentDetails = {}
            vm.documentDetails.dlo_document_id = lineupID
            vm.documentDetails.dlo_dlt_id = 6 //Lineup
            $q.all([
                documentLockService.docLock(vm.documentDetails)
            ]).then((response) => {
                vm.dlo_id = response[0].dlo_id
                vm.docLockStatus = response[0].status
                vm.docLockMessage = response[0].message
                vm.docLockTime = response[0].time
                if (!vm.docLockStatus){
                    throwToastr('warning',vm.docLockMessage,2000)
                }   
            }).then(()=> {
              if(vm.docLockStatus === true){
                lineupLockID = vm.dlo_id
                $('#insertModal').html($compile(`  
                  <lineup-form mode="${mode}" editlineupid="${lineupID}" doclocklineuplockid="${lineupLockID}"></lineup-form>
                `)($scope))
              }
            })
        }

        if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
          $scope.$apply();

        $('.modal .scroll').scrollTop(0);
        modalService.Open(id);
      }

      $scope.$on('DATERANGE', (range) => {
        vm.mainDateFilter = {
            start_date: moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD'),
            end_date: moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')
        }
        vm.refresh()
      })

      //Get permissions for the user
      menuService.getPagePermissions().then((data) => {
        vm.permissions = data
        vm.canViewLineup = vm.permissions.includes('Can View Lineup') ? true : false
        if(!vm.canViewLineup) {
          window.location.href = "/";
        }
        vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
        vm.canManageLineup = vm.permissions.includes('Can Manage Lineup') ? true : false
      })

      vm.lineupOptions = gridService.getCommonOptions();

      vm.getToday = () => {
        return new Date().toJSON().slice(0, 10).replace(/-/g, '-');
      }


      //Get permissions for the user
      menuService.getPagePermissions().then((data) => {
        vm.permissions = data
        vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
    })

      vm.previousLineupModalList = (id)=> {
        vm.openModal(id)
      }

      vm.resetForm =  ()=> {
        vm.dlo_id = null
        vm.docLockMessage = ''
        vm.docLockStatus = false

        vm.form = {
          lineup: {
            ID: '',
            Site: '',
            SiteId: '',
            JobNumber: '',
            Supervisor: '',
            LoggedIn: '',
            ClientRep: '',
            Crew: '',
            Date: '',
            Shift: '',
            ContactInfo: '',
            SafetyTopic: '',
            WorkplaceImpacts: '',
            CommunicationNotes: '',
          },
          Workplaces: []
        };
      }

      vm.resetForm()

      profileService.getPersonProfile().then((response) => {
        vm.employeeProfile = profileService.readPersonProfile()
        vm.form.lineup.LoggedIn = vm.employeeProfile.per_id
      })

      vm.topSearchChanged = () =>{
        vm.lineupOptions.api.onFilterChanged()
      }

      vm.lineupOptions.isExternalFilterPresent = () => {
        return vm.topSearch !== ""
      }

      vm.lineupOptions.doesExternalFilterPass = (gridRow) => {
        if (vm.topSearch.indexOf('?') === 0) {
          var submissionId = vm.topSearch.replace('?submissionId=', '');
          if (gridRow.data['ID'] == submissionId) {
            return true
          }
          return false
        } else {
          for (var property in gridRow.data) {
            if (gridRow.data.hasOwnProperty(property)) {
              //any property in the row matches search box
              if ((gridRow.data[property] + "").toLowerCase().indexOf(vm.topSearch.toLowerCase()) > -1) {
                return true
              }
            }
          }
          return false
        }
      }

      vm.viewReports = (e, SubmissionHeaderID=null, id=null) => {
        if(!e.ctrlKey){
          lang_number = localStorage.getItem('lang_id')          
          if (SubmissionHeaderID) {
            vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/lineup/${SubmissionHeaderID}?lang=${lang_number}`)
          } else {
            vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/lineup_draft/${id}?lang=${lang_number}`)
          }
          $window.open(vm.reportURL, "_blank")
        }

      }

      let lineupColumns = [
        {
          headerName: '',
          field: 'dummyCheckbox',
          // width: 50,
          minWidth: 50,
          maxWidth:50,
          checkboxSelection: true,
          suppressMenu: true,
          suppressSorting: true,
          headerCheckboxSelection: true,
          headerCheckboxSelectionFilteredOnly: true,
        },
        {
          field: "review", headerName: " ", minWidth: 125, maxWidth: 125, suppressMenu: true,
          cellRenderer: function (params) {
            let isSubmitted = params.data.SubmittedBy != null ? true : false
              return `<span ng-show="${isSubmitted}" ng-click="lineup.signoff(data)" class="{{ data.MySignoffID ? 'text-success' : 'pointer'}}" note="Review Submission" title="${vm.translateLabels('3431')}"><i class="far fa-file-alt fa-lg"></i></span>`
                    + `<span class="pointer fa-1x fa-stack" style=" width: 1.25em;" ng-hide="${isSubmitted} || !lineup.canManageLineup"  ng-click="lineup.openModal('LineupModal','edit',${params.data.ID}, null)"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title="${vm.translateLabels('1194')}"></i> <i ng-show="${!params.data.dlo_status}" class="fas fa-ban fa-stack-1x text-danger" title="${params.data.dlo_person} ${vm.translateLabels(3423)}"></i></span>`
                    + `<span title = "${vm.translateLabels('3430')}" note="Submission Review History" class="source signoff-count" ng-class="{ transparent: !data.signoffCount, pointer: !!data.signoffCount }" ng-click="lineup.lineupSignoffHistory(data);">{{ data.signoffCount }}</span>`
                    + `<span class="pointer text-left" ng-click="lineup.viewReports($event, ${params.data.SubmissionHeaderID}, ${params.data.ID})"> <i class="fa fa-external-link-alt" note="Launch Report" title="${vm.translateLabels('3429')}"></i></span>`
          },
          valueGetter: function (params) {
            return params.data.signoffCount
          },
        },
        {
          field: '',
          hide: true,                
          valueGetter: function (params) {
              if (params.data.SubmittedBy != null)
                  return '2_submitted'
              else
                  return '1_Draft'
          },
          sort: 'asc',
      },
        {
          field: "SubmissionDate",
          headerName: " ",
          minWidth: 150,
          maxWidth: 150,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        },
        {
          field:"ID",
          hide:true,
          sort: 'desc',
        },
        {
          field: "CreatedDate",
          headerName: " ",
          minWidth: 150,
          maxWidth: 150,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
          sort: 'desc',
        },
        {
          field: "SubmittedBy",
          headerName: " ",
          minWidth: 150,
          maxWidth: 250,          
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        },        
        {
          field: "Shift",
          headerName: " ",
          minWidth: 150,
          maxWidth: 150,          
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
         // cellRenderer: 'tippyCellRenderer',
        },
        {
          field: "LineupDate",
          headerName: " ",
          minWidth: 150,
          maxWidth: 150,          
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        },
        {
          field: "Site",
          headerName: " ",
          minWidth: 150,
          maxWidth: 300,          
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        },
        {
          field: "JobNumber",
          headerName: " ",
          minWidth: 150,
          maxWidth: 300,          
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        },
        {
          field: "SupervisorName",
          headerName: " ",
          minWidth: 150,
          maxWidth: 300,          
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        },        
        {
          field: "Status",
          headerName: " ",
          minWidth: 85,
          maxWidth: 85,          
          // suppressMenu: true, 
          // suppressSorting: true,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
          valueGetter: function (params) {
            let isSubmitted = params.data.SubmittedBy != null ? true : false
            return `${isSubmitted == false ? translateTag('1399') : translateTag('3557')}`;
          },
        },
        {
          field:"ContactInfo",
          hide: true
        },
        {
          field:"SafetyTopic",
          hide: true
        },
        {
          field: "WorkplaceImpacts",
          hide: true
        },
        {
          field: "CommunicationNotes",
          hide:true
        },
        {
          field:"UpdatedDate",
          hide:true
        },
        {
          field: "UpdatedBy",
          hide:true
        },
        {
          field: "Crew",
          hide:true
        },
        {
          field:"ClientRep",
          hide:true
        },
        {
          field:"CreatedDate",
          hide:true
        },
        {
          field:"LineupDate",
          hide:true
        },
        {
         field:"SubmissionHeaderID",
         hide:true 
        },
        {
          field:"CreatedBy",
          hide:true,
          valueGetter: function(params) {
            return getEmployeeName(params.data.CreatedBy)
          }
        }
      ]
      // refresh the AG-Grid for Lineups
      vm.refresh = ()=>{
        $scope.$emit('STARTSPINNER', vm.loadMessage)
        lineupService.getEmployeesList().then(() => {
          $q.all([
            lineupService.getLineups(vm.mainDateFilter),
            profileService.getAllEmployeeProfile(),
            profileService.getFullEmployeeProfile()
          ]).then( () => {
            setTimeout(() => {
              vm.lineupData = lineupService.readLineups()
              vm.employeeList = profileService.readAllEmployeeProfile()
              vm.fullEmployeeList = profileService.readFullEmployeeProfile()
              if(vm.lineupOptions.api != null)
              {
                translateAgGridHeader(vm.lineupOptions)
                let model = vm.lineupOptions.api.getFilterModel()
                vm.lineupOptions.api.setRowData(prepareLineupGridData(lineupService.readLineups()));
                vm.lineupOptions.api.redrawRows();
                vm.lineupOptions.api.sizeColumnsToFit();
                vm.lineupOptions.api.sizeColumnsToFit();
                vm.lineupOptions.api.setFilterModel(model)
              }
              $scope.$emit('STOPSPINNER')
            }, 2000)
          })
        })
      }

      //Function to prepare Lineup data for the grid/tippy
      function prepareLineupGridData(data) {
        let gridData = JSON.parse(JSON.stringify(data))
        gridData.forEach((rec) =>{ 
            rec.exceptionFields = ['name_crew', 'name_site', 'name_job_number', 'name_shift','Archive', 'ErrorMsg', 'Supervisor', 'CreatedBy', 'dlo_enable', 'dlo_person', 'dlo_status','SubmissionHeaderID_id']
            rec.prefix = ['']
            rec.endfix = ['Name']
            rec.CreatedDate = moment(rec.CreatedDate).format('YYYY-MM-DD')
            rec.Site = rec.name_site
            rec.Shift = rec.name_shift
            rec.JobNumber = rec.name_job_number
            rec.Crew = rec.name_crew
            if(rec.SubmissionDate!=null)
              rec.SubmissionDate = moment(rec.SubmissionDate).format('YYYY-MM-DD')
            else
              rec.SubmissionDate = ''

              rec.SubmissionHeaderID = rec.SubmissionHeaderID_id
              rec.LineupDate = moment(rec.LineupDate).format('YYYY-MM-DD')
              rec.UpdatedDate = moment(rec.UpdatedDate).format('YYYY-MM-DD')
              rec.SubmittedBy = getEmployeeName(rec.SubmittedBy)
              rec.UpdatedBy = getEmployeeName(rec.UpdatedBy)
              // rec.dlo_status = rec.dlo_enable!=null ? rec.dlo_enable : true
              // rec.dlo_person = rec.dlo_per_fullname

            if(rec.dlo_enable.length !== 0){
              rec.dlo_status = rec.dlo_enable[0].dlo_enable
              rec.dlo_person = rec.dlo_enable[0].dlo_person
            }
            else{
                rec.dlo_status = true
                rec.dlo_person = null
            }
            if(!rec.SupervisorName){
              rec.SupervisorName =''
            }
            // Trim all text fields
            Object.keys(rec).map((k) => {
              if(typeof rec[k] === 'string')
                rec[k] = rec[k].trim()
            })
        })
        return gridData
      }

      //Funtion to convert employee ID to Name
      function getEmployeeName(value) {
        let name = value
        vm.fullEmployeeList.forEach((emp)=>{
            if(emp.per_id == value) {
                name = emp.per_full_name
            }
        })
        return name
      }

      // set additional options for the Lineup AG-Grid
      vm.lineupOptions.columnDefs = lineupColumns
      vm.lineupOptions.rowSelection = 'multiple'
      vm.lineupOptions.onSelectionChanged = (event)=> {
        vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
        vm.actionDisabled = vm.lineupOptions.api.getSelectedRows().length > 0 ? false: true 
        vm.selectedRows = vm.lineupOptions.api.getSelectedRows();
        if (vm.selectedRows.length > 0) {
          vm.lineupState = vm.selectedRows[0].SubmittedBy ? translateTag(1224) : translateTag(3088)  // archive: Delete
          if(!vm.selectedRows[0].SubmittedBy && vm.canManageLineup) {
            vm.canArchiveSubmissions = true
          }
        } else {
          vm.lineupState = null
        }
        $timeout(function () { $scope.$apply() })
      }

      // make a copy of the lineup
      vm.copyLineup = ()=>{
        if (vm.selectedRows.length === 1) {
          let id = vm.selectedRows[0].ID
            $q.all([
              lineupService.getLineup(id),
              lineupService.getWorkplaces(id),
              lineupService.getWorkers(id),
              lineupService.getMachines(id),
              lineupService.getPPEData(id),
              lineupService.getLineupJRAWorkplaceSteps(id)
            ]).then(() => {
              vm.form.lineup = lineupService.readLineup()[0]
              vm.form.lineup.LineupDate = vm.getToday()
              vm.form.lineup.ID = null
              vm.form.Workplaces = lineupService.readWorkplaces()
              vm.getJobsLevels
              lineupService.readWorkplaces().forEach((workp, indexwp) => {
                workp.Steps = []
                lineupService.readlineupJRAWorkplaceSteps().forEach((step)=> {
                  if(workp.WorkplaceID === step.rmm_jls_workplace_id) {
                    workp.Steps.push(step.rmm_jls_step_id)
                  }
                })
                vm.form.Workplaces[indexwp].Workers = []
                let w = 0
                lineupService.readWorkers().forEach((worker, indexw) => {
                  if (worker.WorkplaceID === workp.WorkplaceID) {
                    vm.form.Workplaces[indexwp].Workers.push(worker)
                    vm.form.Workplaces[indexwp].Workers[w].equipment = []
                    vm.form.Workplaces[indexwp].Workers[w].ppe = []
                    let m = 0;
                    lineupService.readMachines().forEach((mach, indexm) => {
                      if (mach.WorkerID === worker.WorkerID) {
                        vm.form.Workplaces[indexwp].Workers[w].equipment.push(mach)
                        vm.getMachineTypes(indexwp, w, m)
                        m++
                      }
                    })
                    lineupService.readPPE().forEach((ppedata, indexppe) => {
                      if (ppedata.WorkerID === worker.WorkerID) {
                        vm.form.Workplaces[indexwp].Workers[w].ppe.push(ppedata.PPEID)
                      }
                    })
                    w++
                  }
                })
              })
            }).then((res) => {
              // Passing mode as copyLineup
              vm.saveLineup('copyLineup')
            })
        }
        else {
          toastr.error(translateTag(8889))   //"You Must Select only one"
        }

      }

      vm.getMachineTypes = (workPlace, workerNumber, machineNumber) => {
        let mNumber = vm.form.Workplaces[workPlace].Workers[workerNumber].equipment[machineNumber].EquipmentNumber
        vm.form.Workplaces[workPlace].Workers[workerNumber].equipment[machineNumber].EquipmentList = []
        lineupService.getMachineTypes(mNumber).then((data) => {
          data.forEach((item) => {
            vm.form.Workplaces[workPlace].Workers[workerNumber].equipment[machineNumber].EquipmentList.push({
              ID: item.ID,
              Value: item.Value,
              Label: item.Label
            })
          })
          vm.form.Workplaces[workPlace].Workers[workerNumber].equipment[machineNumber].EquipmentList.push({
            ID: 'OTHER',
            Value: 60,
            Label: 'Other'
          })
        })
      }

      // save the surrent lineup
      vm.saveLineup = (mode = 'normal') => {
        vm.savemode = mode
        lineupService.upsertLineup(vm.form.lineup).then(function (response) {
          vm.form.lineup.ID = response.lineupId
          localStorage.setItem('LineupRecovery', JSON.stringify(vm.form))
          // Spool up the Workplace Data
          let wpArray = []
          // Save the Workplaces
          vm.form.Workplaces.forEach((wp) => {
            wpArray.push({
              LineupID: vm.form.lineup.ID,
              WorkplaceID: null,
              WorkplaceName: wp.WorkplaceName,
              WorkplaceLevel: wp.WorkplaceLevel,
              WorkplaceLineup: wp.WorkplaceLineup,
              WorkplaceJRA: wp.WorkplaceJRA
            })
          })
          $scope.$emit("Upsert_Lineup", vm.form.lineup.ID);
          // Save the Workers
          return wpArray
        }, function (error) {
        }).then((data) => {
          lineupService.upsertWorkplaces(data).then(function (response) {
            let workArray = []
            let stepsArray = []
            response.ids.forEach((wp, index) => {
              vm.form.Workplaces[index].WorkplaceID = wp
            })
            let wpCount = 0;
            vm.form.Workplaces.forEach((wp) => {
              let wkIndex = 0
              wp.Workers.forEach((work) => {
                workArray.push({
                  LineupID: vm.form.lineup.ID,
                  WorkplaceID: wp.WorkplaceID,
                  WorkplaceIndex: wpCount,
                  WorkerID: null,
                  WorkerIndex: wkIndex,
                  WorkerName: work.WorkerName,
                  WorkerAlone: work.WorkerAlone
                })
                wkIndex++
              })

            // Now lets Create the Payload for Steps
            wp.Steps.forEach((step) => {
              stepsArray.push({
                rmm_jls_lineup_id: vm.form.lineup.ID,
                rmm_jls_workplace_id: wp.WorkplaceID,
                rmm_jls_step_id: step,
              })
            })

              wpCount++
            })
            // Save the Equipment
            return  { workers: workArray, steps: stepsArray, lineup: vm.form.lineup.ID }
          }, function (error) {
            console.log("There was an Error when saving the Workplaces", error)
          }).then((wpdata)=>{
              let payload = {
                payload: wpdata.steps,
                lineupId: wpdata.lineup
              }
              // Here is where we will upload the Staps
              lineupService.insertLineupJRASteps(payload).then((response) => {
              return(wpdata.workers)
              }, (error) => {
                return(wpdata.workers)
            })
            .then((mydata) => {
              lineupService.upsertWorkers(mydata).then(function (response) {
                mydata.forEach((wdata, index) => {
                  vm.form.Workplaces[wdata.WorkplaceIndex].Workers[wdata.WorkerIndex].WorkerID = response.ids[index]
                })
                let equipArray = []
                let ppeArray = []
                let wpCount = 0;
                vm.form.Workplaces.forEach((wp) => {
                  let wkIndex = 0
                  wp.Workers.forEach((work) => {
                    let machIndex = 0
                    work.equipment.forEach((mach) => {
                      equipArray.push({
                        LineupID: vm.form.lineup.ID,
                        WorkplaceID: wp.WorkplaceID,
                        WorkplaceIndex: wpCount,
                        WorkerID: work.WorkerID,
                        WorkerIndex: wkIndex,
                        EquipmentID: null,
                        EquipmentIndex: machIndex,
                        EquipmentLocation: mach.EquipmentLocation,
                        EquipmentNumber: mach.EquipmentNumber,
                        EquipmentType: mach.EquipmentType
                      })
                      machIndex++
                    })
                    wkIndex++
                  })
                  // End of Workers
                    // take care of the PPE
                    wkIndex = 0
                    wp.Workers.forEach((work) => {
                      work.ppe.forEach((ppeselect) => {
                        ppeArray.push({
                          WorkerID: work.WorkerID,
                          PPEID: ppeselect,
                          LineupID: vm.form.lineup.ID,
                          WorkplaceID: wp.WorkplaceID
                        })
                      })
                      wkIndex++
                    })

                  wpCount++
                })
                return { equip: equipArray, ppe: ppeArray, lineup: vm.form.lineup.ID }
              }).then((mdata) => {
                lineupService.upsertEquipment(mdata.equip).then(function (response) {
                  mdata.equip.forEach((data, index) => {
                    vm.form.Workplaces[data.WorkplaceIndex].Workers[data.WorkerIndex].equipment[data.EquipmentIndex].equipmentID = response.ids[index]
                  })
                  return mdata
                 // localStorage.setItem('LineupRecovery', JSON.stringify(vm.form))
                })                    
                .then((mdata) => {
                  lineupService.removePPE(vm.form.lineup.ID).then((response) => {
                    return mdata
                  }).then((mdata) => {
                    lineupService.insertPPE(mdata.ppe).then((response) => {
                      return (mdata)
                    }).then((res) => {
                      toastr.success(`Lineup Copied`);
                      // Opening the copied lineup in the viewer
                      if (vm.savemode === 'copyLineup'){
                        if (vm.form.lineup.ID){
                          vm.openModal('LineupModal', 'edit', vm.form.lineup.ID, null)
                        }
                      }
                    })
                  })
                })
              })
            })
          })
        })
      }

      //archive or delete the selected lineup
      vm.archiveDeleteLineup = () => {        
        let sel_draft_ids = []
        let sel_submitted_ids = []
        vm.selectedRows.forEach(row => {
          if (row.SubmittedBy) {
            if (row.dlo_status) {
              sel_submitted_ids.push(row.ID)
            }
            else {
              // You cannot Archive while Document is being edited
              throwToastr('warning',translateTag(9116),2000)
            }
          } 
          else {
            if (row.dlo_status) {
              sel_draft_ids.push(row.ID)
            }
            else {
              // You cannot Archive while Document is being edited
              throwToastr('warning',translateTag(9116),2000)
            }
          }
        })

        if (sel_draft_ids.length > 0) {
            lineupService.removeLineup(sel_draft_ids).then((response) =>{
              $scope.$emit("Upsert_Lineup", vm.form.lineup.ID)
              modalService.Close('confirmModal')
            })
        }

        if(sel_submitted_ids.length > 0){
          lineupService.archiveLineup(sel_submitted_ids).then((response) =>{
            $scope.$emit("Upsert_Lineup", vm.form.lineup.ID)
            modalService.Close('confirmModal')
          })
        }
      }

     //Funtion to export the selected rows to CSV file
      vm.exportCSV = () => {        
        let rows = JSON.parse(JSON.stringify(vm.lineupOptions.api.getSelectedRows()))
        exportCSV.export_csv(rows, translateTag(993))
      }
      
      vm.signoff = (headerData) => {
        vm.LineupDataContext = headerData
        if(headerData.MySignoffID > 0) {
            toastr.success(vm.translateLabels(3486))  //"You have already Acknowledged this Document"
        } 
        else {
          vm.modalElementsAcknowledge = {
            title: translateTag(3571), // "Lineup Review?" 
            message: `<div><p>${translateTag(3572)}</p></div>`, //"Your acknowledgement of reviewing this submission will be recorded. Continue?"
            buttons: 
                `<button class='btn btn-primary btn-rounded m-0' ng-click="vm.return('button1')" note="Review">{{vm.componentTranslateLabels(1188)}}</button>
                <button class='btn btn-outline-primary btn-rounded m-0 mr-3' ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
          }
          document.getElementById('confirmcallingform').innerHTML = 'LINEUPACKNOWLEDGECALLCONFIRMMODAL' 
          $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsAcknowledge)
        }
      }

      $scope.$on("LINEUPACKNOWLEDGECALLCONFIRMMODAL", (event,result) => {
        if (result=='button1') {
            vm.addAcknowledge()
        }
      })

      // Add a signoff record to the lineup form
      vm.addAcknowledge = () => {
        signoffService.addSignoff(vm.LineupDataContext.SubmissionHeaderID)
          .then((newSignoffId) => {
            if (newSignoffId != null) {
              vm.LineupDataContext.MySignoffID = newSignoffId.Payload
              vm.LineupDataContext.signoffCount = vm.LineupDataContext.signoffCount + 1
            }
           // vm.refresh()
            modalService.Close('confirmModal')
          })
      }

      // remove the signoff from the signoff
      vm.confirmSignoffDelete = (mySignoffId, headerData) => {
        vm.headerDataContext = null;
        vm.signoffIdContext = null;
        signoffService.deleteSignoff(mySignoffId)
          .then((success) =>{
            if (success) {
              headerData.MySignoffID = 0;
              headerData.signoffCount = headerData.signoffCount - 1;
              //Change count and ID in row
              modalService.Close('confirmModal');
            }
          })
      }

      //show history
      vm.lineupSignoffHistory = (rowData) => {
        if (!rowData.signoffCount) {
          return;
        }
        vm.currentSignoffHistory = []
        signoffService.getSignoffsByHeader(rowData.SubmissionHeaderID).then((data) => {
          data.map((rec)=>{
            rec.name = rec.SigningName
            rec.reviewed_date=rec.SigningTimestamp
            rec.pos=rec.sus_position
            delete rec.SigningName
            delete rec.SigningTimestamp
            delete rec.sus_position
          })
          vm.currentSignoffHistory = data
          $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentSignoffHistory,translateLabels(3733)) //"Submission Reviews"
        })
      }
      // Invoke a refresh to the page then the Upsert_lineup emitter is used

      vm.deleteEntryModal = () => {
        vm.modalElementsRemove = {
          title: translateTag(3561), // Remove Lineup 
          message: `<div><p>${translateTag(3563)}</p></div>`, //`Are you sure you wish to remove/archive this lineup ?`
          buttons: 
              `<button class='btn btn-outline-primary btn-rounded' ng-click="vm.closeModal()" note="No">{{vm.componentTranslateLabels(1380)}}</button>
              <button class='btn btn-primary btn-rounded' ng-click="vm.return('button1')" note="Yes">{{vm.componentTranslateLabels(1379)}}</button>`
        }  
        document.getElementById('confirmcallingform').innerHTML = 'LINEUPCALLCONFIRMMODAL' 
        $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsRemove)
      }

      $scope.$on("LINEUPCALLCONFIRMMODAL", (event,result) => {
        if (result=='button1') {
            vm.archiveDeleteLineup()
        }
    })

      $scope.$on("Upsert_Lineup", (evt, data) => {
       vm.refresh()
      })

      $(window).on('resize', () =>{
        $timeout(() => {
          if(vm.lineupOptions.api)
            vm.lineupOptions.api.sizeColumnsToFit()
        })
      })
      // End of Controller
    }
  ]);