angular.module('angularTranslateApp', ['pascalprecht.translate'])
  .config(($translateProvider, $translatePartialLoaderProvider ) => {
    $translateProvider.useMissingTranslationHandlerLog()
    $translateProvider.useLoader('$translatePartialLoader', {
      urlTemplate: '/locales/translation/translation_{lang}.json'
    })
    $translatePartialLoaderProvider.addPart('team')
    $translateProvider.preferredLanguage('en')  
    $translateProvider.useSanitizeValueStrategy('escape')
})