﻿angular
  .module('safeToDo')
  .controller('ToolboxCtrl', ['$scope','$timeout', '$q', '$sce', '$window', 'toolboxService', 'gridService', 'homeService',
    function ($scope, $timeout,  $q, $sce, $window, toolboxService, gridService, homeService) {
      vm = this
      vm.targetOptions = gridService.getCommonOptions()
      vm.submissionsOptions = gridService.getCommonOptions()
      vm.isSubFiltered = true

      
      vm.translateLabels = (key) =>{      
        return translateTag(key)
      }

      vm.topSearch = ''
      vm.loadMessage = vm.translateLabels("3465")  //Loading toolbox. Please wait.
      vm.page = {
        'page': 'toolbox'
      }

      //Function for the top search bar
      vm.topSearchChanged = () =>{
        vm.submissionsOptions.api.setQuickFilter(vm.topSearch)
      }

      // Target Table Rendering

      let targetColumns = [
        {
          field: "form_name",
          headerName: "Form",
          minWidth: 200,
          cellRenderer: (params) => {                
            return `<span class="clip" ng-non-bindable>${params.value}</span>`
          },
          filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab']
        },
        {
          field: "frequency",
          headerName: "Frequency",
          minWidth: 100,
          cellRenderer: (params) => {                
            return `<span class="clip" ng-non-bindable>${params.value}</span>`
          },
          filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab']
        },
        {
          field: "target",
          headerName: "Target",
          minWidth: 80,
          filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab']
        },
        {
          field: "completed",
          headerName: "Completed",
          minWidth: 80,
          filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab']
        },
        {
          field: "todo",
          headerName: "To do",
          minWidth: 80,
          filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab']
        }
      ]
      vm.targetOptions.columnDefs = targetColumns
      vm.targetOptions.headerHeight = 35

      //Submission Table Rendering
      let submissionsColumns = [
        {
          field: "",
          headerName: "",
          width: 40,
          suppressSizeToFit: true,
          suppressMenu: true,
          cellRenderer: function (params) {
            return `<span class="pointer text-left" ng-click="toolbox.viewReports($event, ${params.data.ID},'${params.data.ReportURL}','${params.data.rpt_output_type}')"><i class="fa fa-external-link-alt" note="Launch Report" title="${vm.translateLabels("3429")}"></i></span>`
          }, filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab']
        },
        {
          field: 'ID',
          headerName: "ID",
          hide: true,
          sort: 'desc',
        },
        {
          field: "FormSubmissionDate",
          headerName: "Submission Date",
          minWidth: 170,
          maxWidth: 170,
          menuTabs: ['filterMenuTab'],
          filter: 'agSetColumnFilter'
        },
        {
          field: "ReportName",
          headerName: "Type",
          minWidth: 150,
          maxWidth: 250,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
          sort: 'asc',
        },
        {
          field: "Site",
          headerName: "Site",
          minWidth: 150,
          maxWidth: 250,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        },
        {
          field: "JobNumber",
          headerName: "Job Number",
          minWidth: 150,
          maxWidth: 150,
          cellRenderer: 'tippyCellRenderer',
        },
        {
          field: "SiteLevel",
          headerName: "Level",
          minWidth: 150,
          maxWidth: 150,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        },
        {
          field: "Workplace",
          headerName: "Workplace",
          minWidth: 150,
          filter: 'agSetColumnFilter',
          menuTabs: ['filterMenuTab'],
          cellRenderer: 'tippyCellRenderer',
        },
        {field:"ReportURL", hide:true}
      ]

      vm.submissionsOptions.columnDefs = submissionsColumns
      vm.submissionsOptions.headerHeight = 35

      function sizeToFit(grid) {
        if(grid.api){
          grid.api.sizeColumnsToFit();
        }
      }

      $(window).on('resize', () => {
        $timeout(() => {
          sizeToFit(vm.submissionsOptions) 
          if(vm.submissionsOptions.api){
            vm.submissionsOptions.api.sizeColumnsToFit()
          }
          if(vm.targetOptions.api){
            vm.targetOptions.api.sizeColumnsToFit()
          }
        })
      })

      //Get targets data for Card
    function refreshTargets () {
      vm.targetsData = {
          "person_total" : 0,
          "person_complete" : 0,
          "site_total": 0,
          "site_complete": 0,
          "company_total": 0,
          "company_complete": 0,
          "person": 0,
          "site": 0,
          "company": 0
      }

      $q.all([ 
          homeService.getTargetCountData(),
      ]).then(()=>{
          vm.targetsData = prepareTargetData(homeService.readTargetCountData())
      })
    }
      refreshTargets()

    function prepareTargetData (data) {
        preparedData = data
        let largestCompletion = 0
        preparedData.medal = 'Person'
        preparedData.person = data.person_total - data.person_complete
        preparedData.site = data.site_total - data.site_complete
        preparedData.company = data.company_total - data.company_complete
        preparedData.personCompletion = data.person_total != 0 ? Math.round(data.person_complete / data.person_total  * 100) : 0
        if(preparedData.personCompletion > largestCompletion) {
            largestCompletion = preparedData.personCompletion
            preparedData.medal = 'Person'
        }
        preparedData.siteCompletion = data.site_total != 0 ? Math.round(data.site_complete / data.site_total  * 100) : 0
        if(preparedData.siteCompletion > largestCompletion) {
            largestCompletion = preparedData.siteCompletion
            preparedData.medal = 'Site'
        }
        preparedData.companyCompletion = data.company_total != 0 ? Math.round(data.company_complete / data.company_total  * 100) : 0
        if(preparedData.companyCompletion > largestCompletion) {
            largestCompletion = preparedData.companyCompletion
            preparedData.medal = 'Company'
        }
                
        return preparedData
    }
      
    function refresh() {
      $scope.$emit('STARTSPINNER', vm.loadMessage)
      $q.all([
        toolboxService.getEmployeeTargets(),
        toolboxService.getEmployeeTargetSubmissions(selectedLanguage),
      ]).then(() => {
          if (vm.targetOptions.api) {
            vm.targetOptions.paginationPageSize = 10
            translateAgGridHeader (vm.targetOptions)
            vm.targetOptions.api.setRowData(toolboxService.readEmployeeTargets());
            vm.targetOptions.api.redrawRows();
            vm.targetOptions.api.resetRowHeights()
            vm.targetOptions.api.sizeColumnsToFit();

          if (vm.submissionsOptions.api) {
            vm.submissionsOptions.paginationPageSize = 10
            translateAgGridHeader (vm.submissionsOptions)
            vm.submissionsOptions.api.setRowData(toolboxService.readEmployeeTargetSubmissions());
            vm.submissionsOptions.api.redrawRows();
            vm.submissionsOptions.api.resetRowHeights()
            vm.submissionsOptions.api.sizeColumnsToFit();
          }
        }
        $scope.$emit('STOPSPINNER')
      })
    }

    refresh()

    vm.viewReports = (e, id, report, output) =>{
      token = JSON.parse(localStorage.getItem('token')).access
      report = report ? report : 'custom_form'
      if(!e.ctrlKey) {
        lang_number = localStorage.getItem('lang_id')
        vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${report}/${id}?lang=${lang_number}`)
        $window.open(vm.reportURL, "_blank")  
      }
    }

    vm.showTargetSubmissions = () =>{
      toolboxService.getEmployeeTargetSubmissions(selectedLanguage).then(()=>{
        if (vm.submissionsOptions.api) {
          vm.submissionsOptions.paginationPageSize = 10
          vm.submissionsOptions.api.setRowData(toolboxService.readEmployeeTargetSubmissions())
          vm.submissionsOptions.api.redrawRows();
          vm.submissionsOptions.api.resetRowHeights()
          vm.submissionsOptions.api.sizeColumnsToFit()
          vm.isSubFiltered = true
        }
      })
    }

    vm.clearFilter =() => {
      toolboxService.getAllEmployeeSubmissions(selectedLanguage).then(()=>{
        if (vm.submissionsOptions.api) {
          vm.submissionsOptions.paginationPageSize = 10
          translateAgGridHeader (vm.submissionsOptions)
          vm.submissionsOptions.api.setRowData(toolboxService.readAllEmployeeSubmissions())
          vm.submissionsOptions.api.redrawRows();
          vm.submissionsOptions.api.resetRowHeights()
          vm.submissionsOptions.api.sizeColumnsToFit()
          vm.isSubFiltered = false
        }
      })
    }
        // End of Controller
 }])