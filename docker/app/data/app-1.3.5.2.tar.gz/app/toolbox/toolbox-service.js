﻿angular
  .module('safeToDo')
  .service('toolboxService', ['$http', '$q', 'targetsService', 
    function ($http) {
      let employeeTargets = []
      let employeeTargetSubmissions = []
      let employeeAllSubmissions = []

      return {
        getEmployeeTargets: () => {
          return $http.get(`${__env.apiUrl}/api/target/get-employee-targets/app/`).then((response) => {
                    employeeTargets = response.data
                }, function (errorParams) {
                    console.log('Failed to load submissions.', errorParams)
                    if(errorParams.status === 403 && errorParams.data.detail)
                      toastr.error(errorParams.data.detail)
                  
                });
        },  
        getEmployeeTargetSubmissions: (lang) => {
          return $http.post(`${__env.apiUrl}/api/target/get-employee-target-submissions/`, {"lang": lang}).then((response) => {
                    employeeTargetSubmissions = response.data
                }, function (errorParams) {
                    console.log('Failed to load submissions.', errorParams)
                    if(errorParams.status === 403 && errorParams.data.detail)
                      toastr.error(errorParams.data.detail)
                });
        },  
        getAllEmployeeSubmissions: (lang) => {
          return $http.post(`${__env.apiUrl}/api/target/get-all-employee-submissions/`, {"lang": lang}).then((response) => {
              employeeAllSubmissions = response.data
            }, (errorParams) => {
                console.log('Failed to load submissions.', errorParams)
                if(errorParams.status === 403 && errorParams.data.detail)
                      toastr.error(errorParams.data.detail)
          })
        },                                              
        readEmployeeTargets: () => {
          return employeeTargets
        },  
        readEmployeeTargetSubmissions: () => {
          return employeeTargetSubmissions
        },
        readAllEmployeeSubmissions: () => {
          return employeeAllSubmissions
        }                   
      }
    }])
