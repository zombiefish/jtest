﻿angular
    .module('safeToDo')
    .service('gapsService', ['$http',
        function ($http) {
            function getObjectWithFormattedDates(input) {
                var inputWithGoodDates = {};
                for (var property in input) {
                    if (input.hasOwnProperty(property)) {
                        if (Object.prototype.toString.call(input[property]) === "[object Date]") {
                            inputWithGoodDates[property] = input[property].toJSON().split('T')[0];
                        } else if (property.indexOf('date') > -1 || property.indexOf('by_when') > -1) { // HACK: I don't like this
                            var dt = new Date(input[property]);
                            var parts = input[property].split('/')
                            if (parts[0].length == 1)
                                parts[0] = '0' + parts[0];

                            if (parts[1].length == 1)
                                parts[1] = '0' + parts[1];

                            var newDate = parts[2] + '-' + parts[0] + '-' + parts[1];

                            inputWithGoodDates[property] = newDate;
                        } else {
                            inputWithGoodDates[property] = input[property];
                        }
                    }
                }
                return inputWithGoodDates;
            }
            return {
                getHaps: function (submissionHeaderId, currentUser) {
                    if (!!submissionHeaderId) {
                        // return $http.get('/api/submissions/' + submissionHeaderId + "/haps" + '?bust=' + new Date().getTime())
                        return $http.post(`${__env.apiUrl}/api/submission/get-submissionhap-by-headerid/`, { "submissionHeaderID": '"'+  submissionHeaderId + '"' })
                            .then(function (response) {

                                return response.data;
                            }, function (args) {
                                console.log('Failed to load HAPs.');
                                console.log(args);
                            });
                    } else {
                        //get all
                        var url = '/api/haps/';
                        url += currentUser ? currentUser : '';
                        url += '?bust=' + new Date().getTime();
                        url = `${__env.apiUrl}/api/submission/get-submission-hap`
                        return $http.get(url)
                            .then(function (response) {
                                //Check for error

                                var firstRow = response.data[0];
                                if (firstRow && firstRow['error']) {
                                    toastr.error(firstRow['error']);
                                    return null;
                                }
                                let userData = []
                                let count = 0;
                                for (let a = 0; a < response.data.length; a++) {
                                    if (response.data[a].Supervisor === currentUser) {
                                        userData[count] = response.data[a];
                                        count++;
                                    }
                                }
                                return response.data
                            }, function (args) {
                                console.log('Failed to load HAPs.');
                                console.log(args);
                                toastr.error(args['statusText']);
                            });
                    }
                },
                getHapsByFilter: function (filter, currentUser) {
                    return $http.post(`${__env.apiUrl}/api/submission/get-submission-hap/`).then(function (response) {
                        //Check for error
                        var firstRow = response.data[0];
                        if (firstRow && firstRow['error']) {
                            toastr.error(firstRow['error']);
                            return null;
                        }
                        
                        return response.data;
                    }, function (args) {
                        console.log('Failed to load HAPs');
                        console.log(args);
                        return [];
                    });
                },
                stageHapFiles: function () {
                    return $http.post('/api/localfiles')
                        .then(function (params) {
                            return params.data;
                        },
                            function (failParams) {
                                console.log('HAP File Stage Failed');
                            });
                },
                getStagedAttachments: function (stageFolder) {
                    return $http.get('/api/haps/initial/' + stageFolder + '/f' + '?bust=' + new Date().getTime())
                        .then(function (response) {
                            return response.data;
                        }, function (args) {
                            console.log('Failed to load followup attachments');
                        });
                },
                deleteInitialAttachment: function (folderName, fileName) {
                    return $http.delete('/api/haps/initial/' + folderName + '/' + encodeURI(fileName))
                        .then(function (response) {
                            return fileName;
                        }, function (args) {
                            console.log('');
                        });
                },
                validateHap: function (hap) {
                    console.log("Validating the Haps", hap)
                    if (!hap.hazard_type) return "Hazard Type required.";
                    if (!hap.hazard_identification) return "Hazard Identification required.";
                    if (!hap.hazard_description) return "Hazard Description required.";
                    if (!hap.potential_risk) return "Potential Loss required."

                    if (hap.recommended_action
                        || hap.action_by_who
                        || hap.action_type
                        || hap.action_by_when) {
                        // replace explicit "followup?" question with requiring all fields if 1 is filled in
                        if (!hap.recommended_action) return "Recommended Action required."
                        if (!hap.action_by_who) return "By Who required."
                        if (!hap.action_type) return "Action Type required."
                        if (!hap.action_by_when) return "By When required."
                    }
                },

                createHap: function (formData) {
                  //  var hapWithGoodDates = getObjectWithFormattedDates(hapModel);
                 //   console.log("This is the Hap Data", hapWithGoodDates)
                    return $http.post(`${__env.apiUrl}/api/incident-management/create-hap/`, formData, {
                        // this cancels AngularJS normal serialization of request
                        transformRequest: angular.identity,
                        // this lets browser set `Content-Type: multipart/form-data` 
                        // header and proper data boundary
                        headers: {'Content-Type': undefined}}).then((response)=>{
                        console.log("This is the Haps Response", response)
                    });
                },
                //api/incident-management/create-hap/
                updateFollowup: function (formData) {
                  return $http.post(`${__env.apiUrl}/api/incident-management/update-hap-followup/`, formData, {
                    // this cancels AngularJS normal serialization of request
                    transformRequest: angular.identity,
                    // this lets browser set `Content-Type: multipart/form-data` 
                    // header and proper data boundary
                    headers: {'Content-Type': undefined}})
                  .then(function (response) {
                    return response.data;
                }, function (args) {
                    console.log('Failed to load followup attachments')
                    })
                },
                
                getInitialAttachments: function (hapId) {
                    return $http.post(`${__env.apiUrl}/api/hap/get-submission-attachment-by-hapid/`, { "hapid": hapId, "hap_type": 'INITIAL'})
                        .then(function (response) {
                            return response.data;
                        }, function (args) {
                            console.log('Failed to load followup attachments');
                    });
                },

                getFollowupAttachments: function (hapId) {
                    return $http.post(`${__env.apiUrl}/api/hap/get-submission-attachment-by-hapid/`, { "hapid": hapId, "hap_type": 'FOLLOWUP'})
                        .then(function (response) {
                            return response.data;
                        }, function (args) {
                            console.log('Failed to load followup attachments');
                    });
                },

                deleteFollowupAttachment: function (hapId, fileName) {
                    return $http.delete('/api/haps/' + hapId + '/followup/f/' + encodeURI(fileName))
                        .then(function (response) {
                            return fileName;
                        }, function (args) {
                            console.log('');
                    });
                },
                getHap: function (hapId) {
                    console.log("This is the HAP ID", hapId)
                    return $http.post(`${__env.apiUrl}/api/hap/get-individual-hap/`, { "hapid": hapId})
                        .then(function (response) {
                            return response.data;
                        }, function (args) {
                            console.log('Failed to load hap');
                    });
                }
            };
        }
    ]);