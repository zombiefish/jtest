﻿function getTextWidth(text, font) {
    // re-use canvas object for better performance
    var canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement("canvas"));
    var context = canvas.getContext("2d");
    context.font = font;
    var metrics = context.measureText(text);
    return metrics.width;
}

angular
    .module('safeToDo')
    .controller('GapsCtrl', ['$scope', '$rootScope','$routeParams', '$window', '$q', 'formsService', 'hapsService', 'gridService', 'select2Service',
    'modalService', 'listService', 'sitesService', 'profileService', 'employeesService', 'actionManagementService' ,'exportCSV', 'menuService', function ($scope,$rootScope, $routeParams, $window, $q,
        formsService, hapsService, gridService, select2Service, modalService, listService, sitesService, profileService, 
        employeesService,actionManagementService, exportCSV, menuService) {
        let vm = this
        
        vm.currentUserName = null
        vm.currentUserID = null
        vm.employeeList = []
        vm.fullEmployeeList = []
        vm.actionTypeList = []
        vm.actionMode = 'new'
        vm.generalEditData = {}
        vm.loadMessage = translateTag(3658) //Loading general actions page. Please wait.
        vm.canArchiveSubmissions = false
        vm.mobileDisabled = true

        $rootScope.$on("MOBILE-LOADED", (event,result) => {
            vm.mobileDisabled = false
            $scope.$digest()
        })
        
        //Get permissions for the user
        menuService.getPagePermissions().then((data) => {
            vm.permissions = data         
            vm.canManageActionItems = vm.permissions.includes('Can Manage Action Items') ? true : false
            vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
            vm.canCloseAllActions = vm.permissions.includes('Can Close All Actions') ? true : false

        })

        if (!!$routeParams.hazard) {
            if (!Array.isArray($routeParams.hazard)) {
                vm.hazard = [$routeParams.hazard]
            } else {
                vm.hazard = $routeParams.hazard
            }
        }

        if (!!$routeParams.action) {
            if (!Array.isArray($routeParams.action)) {
                vm.action = [$routeParams.action]
            } else {
                vm.action = $routeParams.action
            }
        }

        if (!!$routeParams.potential_risk) {
            if (!Array.isArray($routeParams.potential_risk)) {
                vm.potential_risk = [$routeParams.potential_risk]
            } 
            else {
                    vm.potential_risk = $routeParams.potential_risk
            }
            for (let a = 0; a < vm.potential_risk.length; a++) {
                if (vm.potential_risk[a] === 'Catastrophic - Fatal, Property $1M  , Equip. $100K  ')
                    vm.potential_risk[a] = 'Catastrophic - Fatal, Property $1M +, Equip. $100K +'
                if (vm.potential_risk[a] === 'Catastrophic - Fatal, Property $1M  , Equip. $100K  |10')
                    vm.potential_risk[a] = 'Catastrophic - Fatal, Property $1M +, Equip.$100K +| 10'
            }
        }

        if (!!$routeParams.start_date) {
            vm.start_date = $routeParams.start_date
            vm.is_query_filtered = true
        }

        if (!!$routeParams.end_date) {
            vm.end_date = $routeParams.end_date;
        }

        if (!!$routeParams.form) {
            formsService.getTopFormDescriptionsP()
                .then(function () {
                    if (!Array.isArray($routeParams.form)) {
                        vm.form = [$routeParams.form]
                    } else {
                        vm.form = $routeParams.form
                    }
                    vm.formLookup = formsService
                        .getTopFormDescriptions().OR
                })
        }

        if (!!$routeParams.has_hazard) {
            vm.has_hazard = true
        }

        if (!!$routeParams.has_action) {
            vm.has_action = true
        }

        if (!!$routeParams.has_potential_risk) {
            vm.has_potential_risk = true
        }

        vm.options = gridService.getCommonOptions()
        vm.actionTypes = listService.getActionTypes()

        $scope.$on('DATERANGE', (range) => {
            vm.mainDateFilter = {
                start_date: moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD'),
                end_date: moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')
            }
            loadGaps()
         //   mainLoadHaps()
        })


        //Function to reset generalFollowup object
        vm.generalFollowup = {
                ID: 0,
                recommended_action: 'placeholder',
                action_type: '',
                action_by_who: 'johnny placeholder',
                action_by_when: '2017-05-17',
                action_status: 'Incomplete',
                action_complete_by_who: 'the dude',
                action_completed_date: new Date('2017-05-20'),
                completed_action_taken: 'test',
                completed_action_type: ''
        }

        vm.currentRow = {}
        vm.topSearch = ""
        vm.employees = listService.getEmployees().A
        vm.topSearchChanged = () => {
                vm.options.api.onFilterChanged()
        }

        vm.options.isExternalFilterPresent = () => {
            return vm.topSearch !== "" || (vm.is_query_filtered && (vm.action || vm.form))
        }

        vm.options.doesExternalFilterPass = function (gridRow) {
                //topSearch
                if (vm.topSearch != '') {
                    for (var property in gridRow.data) {
                        if (gridRow.data.hasOwnProperty(property)) {
                            //any property in the row matches search box
                            if ((gridRow.data[property] + "").toLowerCase().indexOf(vm.topSearch.toLowerCase()) > -1) {
                                return true;
                            }
                        }
                    }
                }

                //action query
                if (vm.action != undefined) {
                    for (var i = 0; i < vm.action.length; i++) {
                        if (gridRow.data['immediate_action_type'] == vm.action[i]
                            || gridRow.data['completed_action_type'] == vm.action[i]) {
                            return true;
                        }
                    }
                }

                //form query
                if (vm.form != undefined) {
                    var pass = false;
                    for (var i = 0; i < vm.form.length; i++) {
                        if (gridRow.data['FormID'] == vm.formLookup[vm.form[i]]) {
                            pass = true;
                            break;
                        }
                    }

                    if (pass) {
                        if (vm.has_action) {
                            if (gridRow.data['immediate_action_type']
                                || gridRow.data['completed_action_type']) {
                                return true;
                            }
                        }

                        if (vm.has_hazard) {
                            if (gridRow.data['hazard_type']) {
                                return true;
                            }
                        }

                        if (vm.has_potential_risk) {
                            if (gridRow.data['potential_risk']) {
                                return true;
                            }
                        }
                    }
                }

                return false;
        }

        vm.options.dateComponent = JUIDateComponent
        vm.actionsDisabled = false
        vm.options.onSelectionChanged = (params) => {
            vm.actionsDisabled = vm.options.api.getSelectedRows().length != 0
            $scope.$apply()
        }

        //Function to open archive confirmation Modal
        vm.archiveConfirmationModal = (action) => {
            
            vm.archiveCount = vm.options.api.getSelectedRows().length
            
            vm.modalElements = {
                title: translateLabels(1355),  //"Archive Action?"
                message: `<div><p>${translateTag(3580)} ${vm.archiveCount} ${translateTag(3582)}</p></div>`, //"submissions. Undoing this will require IT support. Are you sure?"
                buttons: 
                    `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('archiveGeneralAction')" notes="Yes">${translateTag(1379)}</button>
                    <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" notes="Cancel" >${translateTag(1257)}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'ACTIONCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("ACTIONCALLCONFIRMMODAL", (event,result) => {
            if (result=='archiveGeneralAction') {
                vm.generalArchive()
            }
        })

        vm.generalArchive = () => {
            let rows = vm.options.api.getSelectedRows()
             if (rows.length > 0) {
                 let payload = []
                 rows.forEach((row)=>{
                     payload.push({sga_id: row.sga_id})
                 })
                actionManagementService.archiveGeneralAction(payload).then((r) => {
                    if (r === true) {
                        refreshData()
                    }
                })
            }
            else    
                toastr.error(translateTag(3816)) // "No Rows Selected")
            modalService.Close('confirmModal')
        }

        //Function to open complete general action modal
        vm.options.onRowDoubleClicked = (params) => {
            if(params.data.sga_action_is_complete === translateTag(2045)){
                // if action COMPLETE, do not open edit modal - add invisble class
                return
            }   
            if(!vm.canCloseAllActions){
                if(params.data.created_by_per_id != vm.currentUserID && !params.data.sga_action_by_who_per_id.includes(vm.currentUserID)){
                    toastr.success(translateTag(9525)) // You can only close actions created by you or assigned to you.
                    return
                }
            }  

            actionManagementService.getGeneralActionSingle({sga_id: params.data.sga_id}).then((response)=>
            {
                vm.generalFollowup = response
                vm.actionID = vm.generalFollowup.sga_id
                vm.generalFollowup.sga_completed_action_by_who_per_id = parseInt(getEmployeeID(vm.generalFollowup.sga_completed_action_by_who_per))
                vm.generalFollowup.sga_action_by_who_per_id = getEmployeeName(vm.generalFollowup.sga_action_by_who_per)
                vm.generalFollowup.attachment_files_initial = []
                vm.generalFollowup.attachment_files_followup = []
                vm.generalFollowup.attachments.forEach((attRec) => {
                    if(attRec.gaa_type == 'INITIAL')
                    {
                        attRec.imageDir = `${__env.imageUrl}/`
                        vm.generalFollowup.attachment_files_initial.push(attRec) 
                    }
                    else if(attRec.gaa_type == 'FOLLOWUP')
                    {
                        attRec.imageDir = `${__env.imageUrl}/`
                        vm.generalFollowup.attachment_files_followup.push(attRec) 
                    }
                })
                vm.initializeSelect2('completeGeneralActionModal')
                vm.openModal('completeGeneralActionModal')
                setTimeout(()=>{
                    $scope.$broadcast('GENERAL_FOLLOWUP_OPENED')
                },100) 
            })
        }

        $scope.$on('GET_FOLLOWUP_ATTACHMENTS', (event, response, id) => {
            if (vm.currentRow.data.ID === id) {
                vm.currentRow.data.FollowupAttachments.length = 0
                vm.currentRow.data.FollowupAttachments.push.apply(vm.currentRow.data.FollowupAttachments, response)
                let updateNodes = [vm.currentRow]
                vm.options.api.refreshRows(updateNodes)
            }
        })

        $scope.$on('UPDATE_FOLLOWUP', (event, response) => {
                let payload = response.config.data
                vm.currentRow.data.action_complete_by_who = payload.action_complete_by_who
                vm.currentRow.data.action_completed_date = payload.action_completed_date
                vm.currentRow.data.completed_action_taken = payload.completed_action_taken
                vm.currentRow.data.completed_action_type = payload.completed_action_type
                vm.currentRow.data.action_status = payload.action_status;
                let updateNodes = [vm.currentRow]
                vm.options.api.refreshRows(updateNodes)
        })

        $scope.$on('GENERAL_REFRESHDATA', (event) => {
            refreshData()
        })

        vm.attachmentModalFiles = []

        //Function to open modals
        vm.openModal = (id) => {
            vm.actionMode = 'new'    //reset mode
            if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                $scope.$apply()

            $('.modal .scroll').scrollTop(0)
            modalService.Open(id)
            vm.initializeSelect2(id)
        }

        vm.openGenModal = (modalId, mode = 'new', id) => {  
            vm.actionMode = mode
            if(mode === 'edit' && modalId === 'generalActionModal') {
                openGeneralEdit(id, modalId)
            }
            else
            {
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()

                $('.modal .scroll').scrollTop(0)
                modalService.Open(modalId)
                vm.initializeSelect2(modalId)
            }            
        }

        //Function to close modals
        vm.closeModal =  (id) => {
            modalService.Close(id)
        }

        //Function to prepare data to edit a general action
        function openGeneralEdit(id, modalId) {
            actionManagementService.getGeneralActionSingle({sga_id: id}).then ((response) => {
                vm.generalEditData = response

                vm.generalEditData.Site = parseInt(vm.generalEditData.Site)
                vm.generalEditData.JobNumber = parseInt(vm.generalEditData.JobNumber)
                vm.generalEditData.SiteLevel = parseInt(vm.generalEditData.SiteLevel)
                vm.generalEditData.Supervisor = parseInt(vm.generalEditData.Supervisor)

                vm.generalEditData.HeaderDate = moment(vm.generalEditData.HeaderDate, 'YYYY-MM-DD' ).format('YYYY-MM-DD')
                vm.generalEditData.sga_action_by_who_per_id = vm.generalEditData.sga_action_by_who_per

                let i = 0
                let initialAtt = JSON.parse(JSON.stringify(vm.generalEditData.attachments))
                initialAtt.forEach((att) => {
                    if(att.gaa_type === 'FOLLOWUP')
                        vm.generalEditData.attachments.splice(i, 1)
                    else
                        i++
                })
                
                vm.generalEditData.attachments.forEach((att) => {
                    att.imageDir = `${__env.imageUrl}/`
                })
                
                if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                    $scope.$apply()            

                $('.modal .scroll').scrollTop(0)

                modalService.Open(modalId)
                vm.initializeSelect2(modalId)
            })
        }

        //Functions to convert names to IDs
        function getEmployeeName(value) {
            let name = value
            vm.fullEmployeeList.forEach((emp)=>{
              if(emp.per_id == value) {
                name = emp.per_full_name
              }
            })
            return name
        }      

        function getActionTypeName(value) {
            let name = value
            vm.actionTypeList.forEach((at)=>{
            if(at.rld_id == value) {
              name = at.rld_name
            }
          })
          return name
        }

        function getEmployeeID(value) {
            let nameID = value
            vm.fullEmployeeList.forEach((emp)=>{
            if(emp.per_full_name == value) {
                nameID = emp.per_id
            }
            })
            return nameID
        }

        function getActionTypeID(value) {
            let nameID = value
            vm.actionTypeList.forEach((at)=>{
            if(at.rld_name == value) {
              nameID = at.rld_id
            }
          })
          return nameID
        }
          
        vm.selectedHapId = 0
        vm.attachmentMode = 'INITIAL'

        vm.options.defaultColDef = {
            filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab'],
            headerCheckboxSelection: (params) => {
                let displayedColumns = params.columnApi.getAllDisplayedColumns()
                let thisIsFirstColumn = displayedColumns[0] === params.column
                return thisIsFirstColumn
            },
            checkboxSelection: (params) => {
                let displayedColumns = params.columnApi.getAllDisplayedColumns()
                let thisIsFirstColumn = displayedColumns[0] === params.column
                return thisIsFirstColumn
            }
        }

        vm.deleteFollowupAttachment = (hapId, fileName) => {
            hapsService.deleteFollowupAttachment(hapId, fileName)
                .then((fn) => {
                    vm.getFollowupAttachments(hapId)
                })
        }

        var hapColumns = [
            { field: "dummyCheckbox", headerName: "", width: 50, suppressMenu: true, suppressSorting: true, headerCheckboxSelectionFilteredOnly: true },
            {
                children: [
                    {
                        field: "",
                        headerName: "",
                        width: 35,
                        suppressMenu: true,
                        cellRenderer: function (params) {
                            let invisible = params.data.sga_action_is_complete === translateTag(2045) ? 'invisible' : ''

                          return `<span class="pointer ${invisible}" ng-if="gaps.canManageActionItems" ng-click="gaps.openGenModal('generalActionModal','edit', ${params.data.sga_id})"><i class="fa fa-pen" style="padding: 5px" note="Edit" title="{{menu.translateLabels(1194)}}"></i></span>`
                        }, 
                        filter: 'agSetColumnFilter', 
                        menuTabs: ['filterMenuTab']
                    },
                    {
                        field: "review",
                        headerName: " ",
                        suppressMenu: true,
                        suppressSorting: true,
                        cellRenderer: function (params) {
                            let formData = params.data.Form
                            if(formData === 'GENERAL REPORT PARENT')
                                formData = 'GENERAL REPORT'
                            return `<a class="source clip" href="/a/forms/${params.data.FormDescriptionID}?submissionId=${params.data.sga_submission_header_id}">${formData}</a>`
                        },
                        width: 200,
                    },                    
                    {
                        //Added the id to the Ag-Grid and hid it. Used to sort the grid to show newest submissions first
                        field: 'sga_id',
                        hide: true,
                        sort: 'desc',
                    },
                    { 
                        field: "submitted_date",
                        headerName: " ",
                        width: 160,
                        // filter: 'agDateColumnFilter',
                        filter: 'agSetColumnFilter',
                        menuTabs: ['filterMenuTab'],
                        // filterParams: gridService.dateFilterParams,
                        cellRenderer: 'tippyCellRenderer',
                    }, 
                    { 
                        field: "submitted_by",
                        headerName: " ",
                        width: 200,
                        // filter: 'agDateColumnFilter',
                        filter: 'agSetColumnFilter',
                        menuTabs: ['filterMenuTab'],
                        filterParams: gridService.dateFilterParams,
                        cellRenderer: 'tippyCellRenderer',
                    },
                    {
                        field: "HeaderDate",
                        headerName: " ",
                        width: 160,
                        // filter: 'agDateColumnFilter',
                        filter: 'agSetColumnFilter',
                        menuTabs: ['filterMenuTab'],
                        filterParams: gridService.dateFilterParams,
                        cellRenderer: 'tippyCellRenderer',
                    },
                    { field: "Site", headerName: " ", cellRenderer: 'tippyCellRenderer' },
                    { field: "ID", hide: true, sort: 'desc'},
                    { field: "JobNumber", headerName: " ", cellRenderer: 'tippyCellRenderer', width: 120},
                    { field: "SiteLevel", headerName: " ", cellRenderer: 'tippyCellRenderer' },
                    { field: "Workplace", headerName: " ", cellRenderer: 'tippyCellRenderer', width:350 },
                    { field: "Supervisor", headerName: " ", cellRenderer: 'tippyCellRenderer'}
                    ]
            },
            //recommended followup
            {
                headerName: translateTag(1215),
                children: [
                { field: "sga_recommended_action", headerName: " " , cellRenderer: 'tippyCellRenderer', hide: false},
                  { field: "sga_action_type_rld_id", headerName: " ", cellRenderer: 'tippyCellRenderer', hide: false},
                  { field: "sga_action_by_who", headerName: " ", cellRenderer: 'tippyCellRenderer', hide: false},
                  { field: "sga_action_by_when", 
                    hide: false, 
                    headerName: " ", 
                    // filter: 'agDateColumnFilter', 
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                    // filterParams: gridService.dateFilterParams, 
                    // cellRenderer: gridService.dateCellRenderer             
                    filterParams: gridService.dateFilterParams,
                    cellRenderer: 'tippyCellRenderer',
                },
               
                ]
            },
            //actual followup
            {
                headerName: translateTag(1216),
                children: [
                  { field: 'sga_action_is_complete', headerName: " ", width: 120, cellRenderer: 'tippyCellRenderer'
                  },
                  { field: "sga_completed_action_taken", headerName: " ", cellRenderer: 'tippyCellRenderer', hide: false},
                  { field: "sga_completed_action_type_rld_id", headerName: " ", cellRenderer: 'tippyCellRenderer', hide: false},
                  { field: "sga_completed_action_by_who", headerName: " ", cellRenderer: 'tippyCellRenderer', hide: false},
                  { field: "sga_completed_action_date", 
                    headerName: " ", hide: false,                     
                    filter: 'agSetColumnFilter',
                    menuTabs: ['filterMenuTab'],
                },
                  
                ]
            }
        ]

        vm.options.columnDefs = hapColumns
        vm.exportCSV = () => {
            let rows = JSON.parse(JSON.stringify(vm.options.api.getSelectedRows()))
            exportCSV.export_csv(rows, translateTag(1324))
        }       

        vm.exportPressed = function () {
            $('#myDropdown').addClass('show');
        }

        $(window).click(function (e) {
            $('#myDropdown').removeClass('show');
        })

        function applyQuerySetFilter(queryValue, columnField, dictionary) {
            if (!queryValue) {
                return;
            }
            var filterComponent = vm.options.api.getFilterInstance(columnField);
            var filterArray = [];
            if (Array.isArray(queryValue)) {
                for (var i = 0; i < queryValue.length; i++) {
                    filterArray.push(queryValue[i]);
                }
            } else {
                filterArray.push(queryValue);
            }

            // OR set filter model and update
            filterComponent.setModel({
                type: 'set',
                values: filterArray
            });
            filterComponent.onFilterChanged()
        }

        function applyDateBetweenFilter(startDate, endDate, columnField) {
            if (startDate == undefined || endDate == undefined) {
                return;
            }

            var filterComponent = vm.options.api.getFilterInstance(columnField);

            filterComponent.setModel({
                type: 'inRange',
                dateFrom: startDate,
                dateTo: endDate
            });
            filterComponent.onFilterChanged()
        }

        vm.applyQueryFilters = function () {
            applyQuerySetFilter(vm.hazard, 'hazard_identification', sitesService.dictHazardType);
            applyQuerySetFilter(vm.potential_risk, 'potential_risk', sitesService.dictPotentialRisk);
            applyDateBetweenFilter(vm.start_date, vm.end_date, 'FormSubmissionDate');
        }

        vm.clearAllFilters = () => {
            vm.is_query_filtered = false
            $window.sessionStorage.removeItem('home_filter')
            refreshData()
        }

        function filterActionsByUser(hapData) {
            for (let a = 0; a < hapData.length; a++) {
                if (hapData[a].sga_action_by_who_per_id != vm.currentUserID || hapData[a].sga_action_is_complete === 1) {
                    hapData.splice(a, 1)
                    a--;
                }
            }
            return (hapData);
        }

        function refreshLists() {
            $q.all([
                listService.getSelectListData('ref_general_action'),
                profileService.getAllEmployeeProfile(),
                profileService.getFullEmployeeProfile()
            ]).then((data) => {
                vm.employeeList = profileService.readAllEmployeeProfile()
                vm.fullEmployeeList = profileService.readFullEmployeeProfile()
                vm.actionTypeList = data[0]
            })                    
        }

        function refreshData() {
            $q.all([
                employeesService.getPersonProfile(),
                listService.getSelectListData('ref_general_action'),
                profileService.getAllEmployeeProfile(),
                profileService.getFullEmployeeProfile()
            ]).then((data) => {
                vm.currentUserName = data[0].per_full_name;
                vm.currentUserID = data[0].per_id;
                vm.actionTypeList = data[1]
                vm.employeeList = profileService.readAllEmployeeProfile()
                vm.fullEmployeeList = profileService.readFullEmployeeProfile()
                // refreshLists()
            }).then(()=>{
                loadGaps()
            })                    
        }
        // refreshLists()
        refreshData()
       
        function loadGaps() {

            $scope.$emit('STARTSPINNER', vm.loadMessage)
            vm.actionsDisabled = false
                actionManagementService.getGeneralActionsList({filter: 'Range', status: 'All', range: vm.mainDateFilter})
                        .then(function (response) {
                            let genData = actionManagementService.readGeneralActionsList().OutPut
                            if ($window.sessionStorage.getItem('home_filter', true) !== null) {
                                vm.is_query_filtered = true;
                                filterActionsByUser(genData);
                            }
                            loadGeneralActionResponse(genData)
                            $scope.$emit('STOPSPINNER')
                        })
        }

        function loadGeneralActionResponse(gapObjects) {
            $q.all([                
                prepareGeneralActionsGridData(gapObjects)
            ]).then((response)=>{
                try{
                    translateAgGridHeader(vm.options)
                    let model = vm.options.api.getFilterModel()
                    vm.options.api.setRowData(response[0])
                    vm.options.api.redrawRows()
                    vm.options.api.setFilterModel(model)
                }
                catch(e){}
            })
        }

        //Function to prepare General Data for the grid/tippy
        function prepareGeneralActionsGridData(generalData) {
            let generalActionsGridData = JSON.parse(JSON.stringify(generalData))            
            generalActionsGridData.forEach((rec) =>{
                rec.exceptionFields = ['further_action_required', 'sga_enable', 'sga_enote', 'sga_action_by_who_per_id', 'created_by_per_id']

                rec.sga_recommended_action = rec.sga_recommended_action === 'undefined' ? ' ' : rec.sga_recommended_action
                rec.sga_modified_by_per_id = getEmployeeName(rec.sga_modified_by_per_id)
                rec.created_by_per_id = rec.sga_created_by_per_id
                rec.sga_created_by_per_id = getEmployeeName(rec.sga_created_by_per_id)
                rec.submitted_by = getEmployeeName(rec.submitted_by)
                
                rec.sga_action_is_complete = rec.sga_action_is_complete?translateTag(2045):translateTag(5028) //'Complete':'Incomplete'

                if(rec.HeaderDate != null)
                    rec.HeaderDate = moment(rec.HeaderDate, 'YYYY-MM-DD').format('YYYY-MM-DD')
                
                rec.sga_completed_action_date = rec.sga_completed_action_date != null? moment(rec.sga_completed_action_date).format('YYYY-MM-DD'): null
                rec.sga_created_date = moment(rec.sga_created_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                rec.sga_modified_date = rec.sga_modified_date == null? '' :  moment(rec.sga_modified_date).format('YYYY-MM-DD')
                rec.submitted_date = moment(rec.submitted_date).format('YYYY-MM-DD')
                rec.Supervisor = getEmployeeName(rec.Supervisor)
            })
            return generalActionsGridData
        }
        
        vm.showHelp = function (id) {
            vm.openModal(id);
        }

        vm.openForm = () =>{
            let message={activeFormID:null,incidentId:null,moduleId:null}            
            vm.activeFormID='372298'
            message.activeFormID=vm.activeFormID
            $rootScope.$broadcast("OPENMOBILEFRAME", message)
        }

        //Refresh grid when any form is submitted
        $scope.$on('REFRESH_FORMSUBMISSIONS', (event) => {
            refreshData()
        })

        //Function to initialize select2
        vm.initializeSelect2 = (parent)=> {
            setTimeout(()=>{
            $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} .modal-body`), escapeMarkup: function (text) { return text } })
                .on('select2:select', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list'))
                        $rootScope.$broadcast('distribution-list-added', event)
                    $(this).parent().find('label').addClass('filled')
    
                    
    
                })
                .on('select2:unselect', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list'))
                        $rootScope.$broadcast('distribution-list-removed', event)
                    $(this).parent().find('label').addClass('filled')
                })

                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()
            }, 100)
            if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
            $('.datepicker').pickadate({
                format: 'yyyy-mm-dd',
                onClose : function(){
                    this.$holder.blur()
                },
            })
            .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                evt.preventDefault()
            })
            
            preventFutureDatePickerInit()

            let pickadateTranslations = sofvie_pickatime_languages[`${selectedLanguage}`]
            $('.timepicker').pickatime({
                donetext: pickadateTranslations.done,
                cleartext: pickadateTranslations.clear,
                twelvehour: true, 
                'default': '24:00'
            })
        }

    //END
    }
])