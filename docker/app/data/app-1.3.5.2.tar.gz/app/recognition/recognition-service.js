﻿angular
    .module('safeToDo')
    .service('recognitionService', ['$http',
        function ($http) {

            return {
                getRecognitions: function (dateFilters) {
                    return $http.post(`${__env.apiUrl}/api/submission/get-submission-pid/`, dateFilters)
                        .then(function (response) {
                            return response.data;
                        }, function (args) {
                            console.log('Failed to load navigation.');
                            console.log(args);
                        })
                },                

                archiveRecognition: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/recognition/archive-positive-recognition/`, payload).then((response) => {
                        return true                        
                    }, (errorParams) => {
                        console.log('Failed to archive general action', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })                    
                },
            }
        }
        
    ]);