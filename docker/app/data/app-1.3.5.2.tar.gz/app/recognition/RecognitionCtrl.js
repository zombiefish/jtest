﻿function getTextWidth(text, font) {
    // re-use canvas object for better performance
    var canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement("canvas"));
    var context = canvas.getContext("2d");
    context.font = font;
    var metrics = context.measureText(text);
    return metrics.width;
}

angular
    .module('safeToDo')
    .controller('RecognitionCtrl', ['$scope','$timeout','$rootScope','$routeParams', 'menuService', 'recognitionService', 'gridService', 'select2Service', 'listService', 'modalService', 'exportCSV',
    function ($scope,$timeout,$rootScope,$routeParams,menuService, recognitionService, gridService, select2Service, listService, modalService, exportCSV) {
        var vm = this;
        
        vm.options = gridService.getCommonOptions();
        vm.actionTypes = listService.getActionTypes();
        vm.currentRow = {}
        vm.topSearch = ""
        vm.canArchiveSubmissions = false
        vm.mobileDisabled = true
        //Get permissions for the user
        menuService.getPagePermissions().then((data) => {
            vm.permissions = data         
            vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
        })

        setTimeout(()=>{
            vm.loadMessage = translateTag(3772) //Loading recognitions page. Please wait.
        },100)

        $rootScope.$on("MOBILE-LOADED", (event,result) => {
            vm.mobileDisabled = false
            $scope.$digest()
        })

        // refreshData ()

        if (!!$routeParams.ID) {
            vm.topSearch = '?ID=' + $routeParams.ID;
        }
        vm.employees = listService.getEmployees().A;
        vm.topSearchChanged = function () {
            vm.options.api.onFilterChanged();
        };
        vm.options.isExternalFilterPresent = function () {
            return vm.topSearch !== "";
        };

        vm.options.doesExternalFilterPass = function (gridRow) {
            if (vm.topSearch.indexOf('?') === 0) {
            //    console.log("This is a Special One", vm.topSearch)
                var submissionId = vm.topSearch.replace('?ID=', '');
             //   console.log("This is the Grid Row data",gridRow.data)
                if (gridRow.data['ID'] == submissionId) {
                    return true;
                }
                return false;
            } else {
                for (var property in gridRow.data) {
                    if (gridRow.data.hasOwnProperty(property)) {
                        //any property in the row matches search box
                        if ((gridRow.data[property] + "").toLowerCase().indexOf(vm.topSearch.toLowerCase()) > -1) {
                            return true;
                        }
                    }
                }
                return false;
            }
        };

        vm.options.dateComponent = JUIDateComponent;
        vm.actionsDisabled = false
        vm.options.onSelectionChanged = function (params) {
            vm.actionsDisabled = vm.options.api.getSelectedRows().length != 0;
            $scope.$apply();
        }       

        //Function to open archive confirmation Modal
        vm.archiveConfirmationModal = (action) => {
            
            vm.archiveCount = vm.options.api.getSelectedRows().length
            
            vm.modalElements = {
                title: translateLabels(1355),  //"Archive Action?"
                message: `<div><p>${translateTag(3580)} ${vm.archiveCount} ${translateTag(3582)}</p></div>`, //"submissions. Undoing this will require IT support. Are you sure?"
                buttons: 
                    `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('archiveHazardAction')" notes="Yes">${translateTag(1379)}</button>
                    <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" notes="Cancel" >${translateTag(1257)}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'ACTIONCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElements)
        }

        $scope.$on("ACTIONCALLCONFIRMMODAL", (event,result) => {
            if (result=='archiveHazardAction') {
                vm.recognitionArchive()
            }
        })

        //Functions to archive the actions
        vm.recognitionArchive = () => {
            let rows = vm.options.api.getSelectedRows()
            if (rows.length > 0) {
                let payload = {
                    'pr_ids':[]
                }
                rows.forEach((row)=>{
                    payload['pr_ids'].push(row.ID)
                })
                recognitionService.archiveRecognition(payload).then((r) => {
                    if (r === true) {
                        refreshData()
                    }
                })
            }
            else    
                toastr.error(translateTag(3816)) // "No Rows Selected")
            modalService.Close('confirmModal')
        }
        
        //Column settings for Ag-grid
        vm.options.defaultColDef = {
            minWidth: 200,
            filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab'],
            headerCheckboxSelection: function (params) {
                var displayedColumns = params.columnApi.getAllDisplayedColumns();
                var thisIsFirstColumn = displayedColumns[0] === params.column;
                return thisIsFirstColumn;
            },
            checkboxSelection: function (params) {
                var displayedColumns = params.columnApi.getAllDisplayedColumns();
                var thisIsFirstColumn = displayedColumns[0] === params.column;
                return thisIsFirstColumn;
            }
        }       

        var PIDColumns = [
            { field: "dummyCheckbox", headerName: "", minWidth: 50, maxWidth: 50,suppressMenu: true, suppressSorting: true, headerCheckboxSelectionFilteredOnly: true },
            {
               // headerName: "Header",
                children: [
                    {
                    field: "review",
                    headerName: " ",
                    suppressMenu: true,
                    suppressSorting: true,
                    cellRenderer: function (params) {
                        if(params.data.SubmissionHeaderID) {
                            return `<a class="source clip" href="/a/forms/${params.data.FormDescriptionID}?submissionId=${params.data.SubmissionHeaderID}" ng-non-bindable>${params.data.FormName}</a>`
                        }
                        else{
                            return `<div class="clip" ng-non-bindable>${params.data.FormName}</div>`;
                        }
                    },
                    minWidth: 200
                },
                { field: "ID", sort: 'desc', hide: true },
                { 
                    field: "FormSubmissionDate",
                    headerName: " ",
                    minWidth: 160,
                    filter: 'agDateColumnFilter',
                    filterParams: gridService.dateFilterParams,
                    cellRenderer: 'tippyCellRenderer',
                },
                { 
                    field: "SubmittedBy",
                    headerName: " ",
                    filter: 'agDateColumnFilter',
                    filterParams: gridService.dateFilterParams,
                    cellRenderer: 'tippyCellRenderer',
                },
                {
                    field: "HeaderDate",
                    headerName: " ",
                    minWidth: 160,
                    filter: 'agDateColumnFilter',
                    filterParams: gridService.dateFilterParams,
                    cellRenderer: 'tippyCellRenderer',
                },                 
                  { field: "Site", headerName: " ", cellRenderer: 'tippyCellRenderer' },                  
                  { field: "JobNumber", headerName: " ", cellRenderer: 'tippyCellRenderer', minWidth: 150,},
                  { field: "SiteLevel", headerName: " ", cellRenderer: 'tippyCellRenderer' },
                  { field: "Workplace", headerName: " ", cellRenderer: 'tippyCellRenderer' },
                  { field: "Supervisor", headerName: " ", cellRenderer: 'tippyCellRenderer' }
                ]
            },
            {
                headerName: translateTag(751), //Positive Recognition
                children: [
                    { field: "recognition_of", headerName: " ", cellRenderer: 'tippyCellRenderer'},
                    { field: "RecognitionType", headerName: " ", cellRenderer: 'tippyCellRenderer' },
                    { field: "EventDescription", headerName: " ", cellRenderer: 'tippyCellRenderer'},
                    { field: "WasRecognitionGiven", headerName: " ", valueGetter: gridService.yesNoValueGetter },
                ]
            }
        ];

        vm.options.columnDefs = PIDColumns;
        vm.exportCSV = function () {
            let rows = JSON.parse(JSON.stringify(vm.options.api.getSelectedRows()))
            exportCSV.export_csv(rows, translateTag(2561))
        };       

        vm.exportPressed = function () {
            $('#myDropdown').addClass('show');
        };

        $scope.$on('DATERANGE', (range) => {
            vm.mainDateFilter = {
                start_date: `${moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD')} 00:00:00.000`,
                end_date: `${moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD')} 23:59:59.000`
            }
            refreshData()
        })
 
        function refreshData() {  
            $scope.$emit('STARTSPINNER', vm.loadMessage)
            vm.actionsDisabled = false
            if (localStorage.getItem("navToFormSubFiltersPID")) {
                vm.mainDateFilter = JSON.parse(localStorage.getItem("navToFormSubFiltersPID"))
                vm.mainDateFilter.start_date = `${vm.mainDateFilter.start_date} 00:00:00.000`
                vm.mainDateFilter.end_date = `${vm.mainDateFilter.end_date} 23:59:59.000`
            }

            localStorage.removeItem("navToFormSubFiltersPID")
            recognitionService.getRecognitions(vm.mainDateFilter).then(function (recObjects) {
                let recRows
                recRows = recObjects
                translateAgGridHeader(vm.options)
                let model = vm.options.api.getFilterModel()
                vm.options.api.setRowData(preparePositiveIDGridData(recRows))
                vm.options.api.redrawRows()
                vm.options.api.sizeColumnsToFit()
                vm.options.api.setFilterModel(model)
                $scope.$emit('STOPSPINNER')
            })
        }

        //Function to prepare Data for the grid/tippy
        function preparePositiveIDGridData(data) {
            let gridData = JSON.parse(JSON.stringify(data))            
            gridData.forEach((rec) =>{
                rec.exceptionFields = ['Attachments', 'SubmissionID', 'attachment_count', 'SubmissionHeaderLabel', 'WasRecognitionGiven_annotate', 'SubmissionHeaderID','spr_archived_by_per_id','spr_archived_date','spr_enable','spr_enote','id']
                rec.FormSubmissionDate = moment(rec.FormSubmissionDate).format('YYYY-MM-DD')

                rec.HeaderDate = moment(rec.HeaderDate).format('YYYY-MM-DD')
                rec.WasRecognitionGiven = rec.WasRecognitionGiven_annotate.toString()
            })
            return gridData
        }

        vm.openModal = function (id) {
            if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                $scope.$apply();

            $('.modal .scroll').scrollTop(0)
            modalService.Open(id)
            vm.initializeSelect2(id)
        };

        vm.closeModal = function (id) {
            modalService.Close(id);
        };

        vm.selectedRecognitionId = 0;
        vm.attachmentModalFiles = [];
        vm.openAttachmentModal = function (recogId, attachmentsArray) {
            vm.attachmentModalFiles.length = 0;
            vm.selectedRecognitionId = recogId;
            vm.attachmentModalFiles.push.apply(vm.attachmentModalFiles, attachmentsArray);
            vm.openModal('recogModal');
        };

        $scope.$on('PID_REFRESHDATA', (event) => {
            refreshData()
        })

        vm.openForm = () =>{        
            let message={activeFormID:null,incidentId:null,moduleId:null}    
            vm.activeFormID='166071'
            message.activeFormID=vm.activeFormID
            $rootScope.$broadcast("OPENMOBILEFRAME", message)
        }

        //Refresh grid when any form is submitted
        $scope.$on('REFRESH_FORMSUBMISSIONS', (event) => {
            refreshData()
        })

        //Function to initialize select2
        vm.initializeSelect2 = (parent)=> {
            setTimeout(()=>{
            $('.select-single, .select-multiple')
                .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} .modal-body`), escapeMarkup: function (text) { return text } })
                .on('select2:select', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list'))
                    $rootScope.$broadcast('distribution-list-added', event)
                    $(this).parent().find('label').addClass('filled')
                })
                .on('select2:unselect', (event) => {
                    if (event.target.parentNode.querySelector('.distribution-list'))
                        $rootScope.$broadcast('distribution-list-removed', event)
                    $(this).parent().find('label').addClass('filled')
                })
                $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
                select2Service.select2Tags()
            }, 100)
            if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
            $('.datepicker').pickadate({
                format: 'yyyy-mm-dd', 
                onClose : function(){
                    this.$holder.blur()
                },
            })
            .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
                evt.preventDefault()
            })

            let pickadateTranslations = sofvie_pickatime_languages[`${selectedLanguage}`]
            $('.timepicker').pickatime({
                donetext: pickadateTranslations.done,
                cleartext: pickadateTranslations.clear,
                twelvehour: true, 
                'default': '24:00'
            })
        }

        //Update Ag-Grid size when window is resized
        $(window).on('resize', () => {
            $timeout(function () {
                if (vm.options.api) {
                    vm.options.api.sizeColumnsToFit()
                }
            })
        })

    //END
    }
])