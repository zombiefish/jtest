angular
    .module('safeToDo')
    .controller('documentReviewCtrl', ['$scope', '$timeout', '$q', '$window', '$sce', 'gridService', '$location' ,
      'documentReviewService', 'listService', 'modalService', 'select2Service', 'profileService', 'employeesService', 'menuService', '$compile', 'documentLockService', '$rootScope', 'imageCommentService', 'fileUploadService','exportCSV',
      function ($scope, $timeout, $q, $window, $sce, gridService, $location, documentReviewService, listService, modalService, select2Service,
        profileService, employeesService, menuService, $compile, documentLockService, $rootScope, imageCommentService, fileUploadService, exportCSV) {
        var vm = this
        
        let dateToday = moment(new Date(), 'YYYY-MM-DD')
        vm.employeeList = []
        vm.fullEmployeeList = []
        vm.currentAcknowledgeHistory = []
        vm.topSearch = ''
        vm.defaultDateFilter = '30'
        vm.usefulLinkSearch = ''
        vm.userId = null
        vm.archiveCount = 0
        vm.largeDocument = false
        vm.invalidDocument = false
        vm.archiveAction = ''
        vm.showAnother = true
        vm.addAnother = false
        vm.addAnotherLink = false
        vm.nonExpiry = false
        vm.companyWide = false
        vm.actionDisabled = true
        // vm.revisionDisabled = false
        vm.actionLinkDisabled = true
        canArchiveSubmissions = false
        vm.canManageDocuments = false
        vm.canManageOwnDocuments = false
        vm.advancedManagement = false
        vm.uploadFile = null
        vm.documentsData = []
        vm.usefulLinkData = []
        vm.DocDataContext = {}
        vm.sendemailFlag = false
        vm.usefulLinkDatContext = {}
        vm.loadMessage = translateTag(3474) //Loading documents. Please wait.
        vm.singleServeReportUrl = 'document_review'
        vm.attachmentType = [
          {
            name: translateTag(3484), //Document Upload
            value: 'document'
          },
          {
            name: translateTag(2165), //Link
            value: 'link'
          }
        ]
        vm.continueEditing = false
        vm.leaveEditing = false
        vm.idletime = 0
        vm.countdownSeconds = 60
        vm.archiveDoc = false
        vm.archiveUsefulLink = false
        vm.showOfflineDocs = false
        
        vm.dlo_id = null
        vm.docLockMessage = ''
        vm.docLockStatus = false

        $scope.$on('DATERANGE', (range) => {
          vm.mainDateFilter = {
              start_date: moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD'),
              end_date: moment(range.targetScope.vm.range.end,'YYYY-MM-DD').add(1, 'days').format('YYYY-MM-DD')
          }
          refreshData()
        })

        //Function to clear the form feilds
        vm.resetForm = () => {
          resetFormFieldClassList('docForm')
          vm.addAnother = false
          vm.nonExpiry = false
          vm.companyWide = false
          vm.submitted = false
          vm.docCopy = false
          vm.sendemailFlag = false

          vm.dlo_id = null
          vm.docLockMessage = ''
          vm.docLockStatus = false
          vm.countdownSeconds = 60
          vm.lockCheckModal = false
          vm.continueEditing = false
          vm.idletime = 0
          vm.leaveEditing = false

          vm.currentDocument = 
            {
              drm_id: null,
              drm_document_type_rld: null,
              drm_description: '',
              drm_review_by_date: dateToday.format("YYYY-MM-DD"),
              drm_expiry_date: dateToday.add(1, 'days').format("YYYY-MM-DD"),
              drm_non_expiring_document: 0,
              drm_filename: '',
              drm_created_by_per_id : null,
              drm_created_date: '2020-06-04',
              drm_modified_date: '2020-06-04',
              drm_modified_by_per_id: null,
              drm_enable: true,
              drm_enote: '',
              drm_is_submitted: false,
              drm_submitted_date: null,
              reviewers: [],
              reviewersList: [],
              drm_attachment_type:null,
              drm_url: '',
              drm_available_offline: false
            }
        }


        //Function to clear the form feilds
        vm.resetUsefulLinkForm = () => {
          resetFormFieldClassList('usefulLinkForm')
          vm.addAnotherLink = false
          vm.submitted = false

          vm.currentUsefulLink = 
            {
              ulm_id: null,
              ulm_description: '',
              ulm_link: '',
              ulm_created_date:dateToday.format('YYYY-MM-DD'),
              ulm_created_by_per_id:null,
              ulm_created_by_per_full_name:null,
              ulm_modified_by_per_id: null,
              reviewers: [{
                ulr_per_id: null,
                ulr_per_full_name: null,
                ulr_reviewed_date: dateToday.format('YYYY-MM-DD'),
              }]
            }
        }

        //Function to clear the External reviewer form feilds
        vm.resetExternalReviewerForm = () => {
          resetFormFieldClassList('drmExternalReviewerForm')
          vm.submitted = false
          vm.drmExternalReviewer = 
            {
              der_drm: null,
              der_first_name: null,
              der_last_name: null,
              der_position: null,
              der_company: null,
              der_signature_file_name: null
            }
        }

        //Get permissions for the user
        menuService.getPagePermissions().then((data) => {
          vm.permissions = data
          vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
          vm.canManageDocuments = vm.permissions.includes('Can Manage Documents') ? true : false
          vm.canManageOwnDocuments = vm.permissions.includes('Can Manage Own Documents') ? true : false
          vm.advancedManagement = vm.permissions.includes('Can View Advanced Document Management') ? true : false

          if(!vm.permissions.includes('Can View Documents'))
            $location.path( "/" )
      })

        //Function for the top search bar
        vm.topSearchChanged = () =>{
          vm.docOptions.api.setQuickFilter(vm.topSearch)
        }
        vm.usefulLinkSearchChanged = () =>{
          vm.usefulLinkOptions.api.setQuickFilter(vm.usefulLinkSearch)
        }

        //Function to open archive confirmation Modal
        vm.archiveConfirmationModal = (action) => {
          vm.archiveDoc = false
          vm.archiveUsefulLink = false

          if(action==='document'){
            vm.archiveDoc = true
            vm.archiveAction = action
            vm.archiveCount = vm.docOptions.api.getSelectedRows().length
          }
          else if(action==='usefulLink'){
            vm.archiveUsefulLink = true
            vm.archiveAction = action
            vm.archiveCount = vm.usefulLinkOptions.api.getSelectedRows().length
          }
          vm.modalElementsArchive = {
            title: translateTag(4271), // Archive?
            message: `<div><p>${translateTag(3580)} ${vm.archiveCount} ${translateTag(3582)}</p></div>`, //"You are about to archive {{docCtrl.archiveCount}} submissions. Undoing this will require IT support. Are you sure?"
            buttons: 
                `<button class="btn btn-primary btn-rounded m-0" ng-if=${vm.archiveDoc} ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                <button class="btn btn-primary btn-rounded m-0" ng-if=${vm.archiveUsefulLink} ng-click="vm.return('button2')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
          }
          document.getElementById('confirmcallingform').innerHTML = 'DRARCHIVECALLCONFIRMMODAL' 
          $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsArchive)
        }
        
        $scope.$on("DRARCHIVECALLCONFIRMMODAL", (event,result) => {
          if (result=='button1') {
              vm.archive('document')
          }
          else if (result=='button2') {
            vm.archive('usefullink')
          }
        })

        function addHistoricalOption (select, list, rld_id, ltr_text) {
          if(rld_id && !list.some(t => t.rld_id === rld_id))
          {
              let historicRecord = {
                      rld_historical: true,
                      rld_id: rld_id,
                      rld_name: `${ltr_text} (${translateTag(8717)})` //Historical
              }
              list.push(historicRecord)              
          }
          return rld_id
        }

        //Function to archive the selected rows
        vm.archive = (action) => {
          if(action === 'document'){
            var rows = vm.docOptions.api.getSelectedRows()
            if (rows.length > 0) {
              var ids = []
              for (var i = 0; i < rows.length; i++) {
                  ids.push(rows[i].drm_id)                    
              }
              documentReviewService.archiveDocument(ids).then((r) => {
                refreshData()
              })
            }
          }
          if(action === 'usefullink'){
            var rows = vm.usefulLinkOptions.api.getSelectedRows()
            if (rows.length > 0) {
              var ids = []
              for (var i = 0; i < rows.length; i++) {
                  ids.push(rows[i].ulm_id)                    
              }
              documentReviewService.archiveUsefulLink(ids).then((r) => {
                refreshData()
              })
            }
          }
          modalService.Close('confirmModal')
        }

        //Funtion to export the selected rows to CSV file
        vm.exportCSV = () => {          
          let rows = JSON.parse(JSON.stringify(vm.docOptions.api.getSelectedRows()))
          rows.forEach(row => {
            delete row['dlo_status']
            for(let [key, value] of Object.entries(row)){
              if(typeof value === 'object'){
                delete row[key]
              }
            }
          });
          exportCSV.export_csv(rows,translateTag(1344))
        }

        vm.exportUsefulLinkCSV = ()=>{          
          let rows = JSON.parse(JSON.stringify(vm.usefulLinkOptions.api.getSelectedRows()))
          rows.forEach(row => {
            for(let [key, value] of Object.entries(row)){
              if(typeof value === 'object'){
                delete row[key]
              }
            }
          });
          exportCSV.export_csv(rows,translateTag(1773))
        }

        //Functions to handle file uploads
        $scope.fileUploadChanged = (event)=> {

          //Add newly selected files after checking for duplicates and correct file types
          vm.uploadFile = fileUploadService.checkFileUpload(event.target.files, [])[0]
          if(vm.uploadFile)
          {
            vm.currentDocument.drm_filename = vm.uploadFile.name
            checkFileSize(vm.uploadFile)
            $scope.$apply()
          }          
        }
        
        //Funtion to check for large file types that wont be avalible offline
        function checkFileSize(file) {
          vm.fileMessage = true         
          vm.showOfflineDocs = false

          if(file.size < 5000000) {
            vm.invalidDocument = false
            vm.largeDocument = false
            vm.showOfflineDocs = true
            vm.fileMessage = false
          } else {
            vm.largeDocument = false
            totalMB = file.size / 1000000
            if (totalMB > 50 ) {
              vm.currentDocument.drm_file_size_kb = `${totalMB.toFixed(2)} Mb`
              vm.currentDocument.drm_available_offline = false
              vm.invalidDocument = true              
            } else {
              vm.invalidDocument = false
              vm.largeDocument = true
            }
            
            vm.currentDocument.drm_file_size_kb = `${totalMB.toFixed(2)} Mb`
            vm.currentDocument.drm_available_offline = false
          }
        }        

        //Funtion to open a report in a new tab
        vm.viewReports = (e, id) =>{
          if(!e.ctrlKey){
            lang_number = localStorage.getItem('lang_id')
            vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.singleServeReportUrl}/${id}?lang=${lang_number}`)
            $window.open(vm.reportURL, "_blank")  
          }       
        }

        //Funtion to open a attachment file in a new tab
        vm.openAttachment = (name) => {
          vm.attachmentURL =  $sce.trustAsResourceUrl(`${__env.imageUrl}/documents_attachments/${name}`)
          $window.open(vm.attachmentURL, "_blank")
        }

        vm.signoff = (DocData) => {
          if(!DocData.drm_is_submitted)
            return

          vm.DocDataContext = DocData
          if(DocData.hasAcknowledged) {
              toastr.success(translateTag(3486)) //You have already Acknowledged this Document
          } 
          else {
            vm.modalElementsAcknowledge = {
              title: translateTag(3480), //"Document Review?"
              message: `<div><p>${translateTag(3481)}</p></div>`, //"You are confirming that you have reviewed this Document. This cannot be undone. Continue?"
              buttons: 
                  `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Review">{{vm.componentTranslateLabels(1188)}}</button>
                  <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'DRACKNOWLEDGECALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsAcknowledge)
          }
        }

        $scope.$on("DRACKNOWLEDGECALLCONFIRMMODAL", (event,result) => {
          if (result=='button1') {
              vm.addAcknowledge('document')
          }
        })

        vm.signOffReviewExternal = (modalId) => {
          if (vm.ValidateForm('drmExternalReviewerForm')){
            var rows = vm.docOptions.api.getSelectedRows()
            vm.drmExternalReviewer.der_drm = rows[0].drm_id
            if (vm.drmExternalReviewer.der_signature_file_name === null || vm.drmExternalReviewer.der_signature_file_name === ""
            || vm.drmExternalReviewer.der_signature_file_name === undefined){
              throwToastr("warning", translateTag(3487), 2000) //Please sign to review
              return
            }
            let payload = vm.drmExternalReviewer            
            documentReviewService.addExternalReviewer(payload).then((response)=>{
              if (response.der_id){                
                // save comments 
                let image_id = response.der_id
                let who = 'external_reviewer'
                if(vm.signatureCommentObject[who] !== null)
                    vm.signatureCommentObject[who]['com_reference_id'] = image_id              

                Object.keys(vm.signatureCommentObject).forEach(who => {
                    if(vm.signatureCommentObject[who] !== null)
                        imageCommentService.saveComment(vm.signatureCommentObject[who])
                  });
                refreshData()
              }
            })
            modalService.Close(modalId)
           
          }
          else{
            $rootScope.$broadcast("CALLCONFIRMMODAL")
          }
        }   

        vm.signoffUsefulLink = (Data) => {
          if(!Data.ulm_is_submitted)
            return

          vm.usefulLinkDatContext = Data
          if(Data.hasAcknowledged) {
              toastr.success(translateTag(3486)) //You have already Acknowledged this Document
          } 
          else {
            vm.modalElementsAcknowledgeULM = {
              title: translateTag(3490), //"Useful Link Review?"
              message: `<div><p>${translateTag(3491)}</p></div>`, //"You are confirming that you have reviewed this Useful Link. This cannot be undone. Continue?"
              buttons: 
                  `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Review">{{vm.componentTranslateLabels(1188)}}</button>
                  <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            }
            document.getElementById('confirmcallingform').innerHTML = 'DRACKNOWLEDGEULMCALLCONFIRMMODAL' 
            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsAcknowledgeULM)
          }          
        }
        
        $scope.$on("DRACKNOWLEDGEULMCALLCONFIRMMODAL", (event,result) => {
          if (result=='button1') {
              vm.addAcknowledge('usefullink')
          }
        })

        //Funtion to add an acknowledgment to a document via the Ag-Grid
        vm.addAcknowledge = (action) => {          
          let payload = {}
          if(action === 'document'){
            payload.drm_id = vm.DocDataContext.drm_id
            documentReviewService.acknowledgeDocument(payload).then ((response) => {
              refreshData()
            })
          }
          if(action === 'usefullink'){
            payload.ulr_ulm = vm.usefulLinkDatContext.ulm_id
            documentReviewService.acknowledgeUsefulLink(payload).then ((response) => {
              refreshData()
            })
          } 
          modalService.Close('confirmModal')     
        }

        //Function to open the Acknowledge History modal
        vm.viewAcknowledgeHistory = (docData) => {
          if(!docData.reviewedCount > 0 || !docData.drm_is_submitted)
            return
          vm.currentAcknowledgeHistory = []
          docData.reviewed_reviewers.forEach((rev) => {
              let acknowledgment = {
                name: getEmployeeName(rev.drr_per_id),
                pos: rev.drr_position,
                reviewed_date: rev.drr_reviewed_date
              }
              vm.currentAcknowledgeHistory.push(acknowledgment)
          })
          docData.external_reviewers.forEach((ex_rev) => {
            
              let acknowledgment = {
                name: ex_rev.der_last_name+", "+ex_rev.der_first_name ,
                pos: ex_rev.der_position,
                reviewed_date: ex_rev.der_created_date
              }
              vm.currentAcknowledgeHistory.push(acknowledgment)
          })
          $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentAcknowledgeHistory,translateLabels(3478))  //"Document Reviews"
        }

        vm.viewAcknowledgeHistoryULM = (ulmData) => {          
          if(!ulmData.reviewedCount > 0 || !ulmData.ulm_is_submitted)
            return
          
          vm.currentAcknowledgeHistory = []
          ulmData.reviewers.forEach((rev) => {
          let acknowledgment = {
            name: getEmployeeName(rev.ulr_reviewed_by_per),
            pos : rev.ulr_position,
            reviewed_date: rev.ulr_reviewed_date
          }
          vm.currentAcknowledgeHistory.push(acknowledgment)            
          })
          $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentAcknowledgeHistory,translateLabels(3479))  //"Useful Link Reviews"
        }


        //Function to check if the current user has Acknowledged this document
        function checkAcknowledged (data, action) {
          let response = false
          if(action === 'document'){
            data.reviewed_reviewers.forEach((rev) => {
              if(rev.drr_per_id == vm.userId) {
                response = true
              }                
            })
          }
          if(action === 'usefullink'){
            if(data.reviewers){
              data.reviewers.forEach((rev) => {
                if(rev.ulr_reviewed_by_per == vm.userId && data.ulm_id == rev.ulr_ulm)
                {
                  response = true
                }
              })
            }            
          }          
          return response
        }
        //Function to check if the current user must Acknowledge this document
        function checkRequiredAcknowledge (docData) {
          let response = false
          docData.reviewers.forEach((rev) => {
            if(rev.drr_per_id == vm.userId)
            {
              response = true
            }
          })
          return response
        }

        //Funtion to convert employee ID to Name
        function getEmployeeName(value) {
          let name = value
          vm.fullEmployeeList.forEach((emp)=>{
            if(emp.per_id == value) {
              name = emp.per_full_name
            }
          })
          return name
        }

        //Funtion to convert document type ID to Name
        function getDocumentType(value) {
          let name = value
          vm.documentTypeList.forEach((typ)=>{
            if(typ.rld_id == value) {
              name = typ.rld_name
            }
          })
          return name
        }
        
        vm.docOptions = gridService.getCommonOptions()
        //Function to disable action button if no rows are selected
        vm.docOptions.onSelectionChanged = () => {
          var selectedRows = vm.docOptions.api.getSelectedRows()
          vm.actionDisabled = selectedRows.length == 0
          viewSelections()
          $scope.$apply()
        }

        vm.openTestLink = (url)=>{
          window.open(url, '_blank')
        }

        vm.checkEditPermissions = (invisible, ngShow, created_by) => {          
          if(vm.canManageDocuments === true){
            invisible = ''
          }
          else if(vm.canManageOwnDocuments == true && created_by == vm.userFullName){
            invisible = ''
          }
          if(vm.canManageDocuments === false && vm.canManageOwnDocuments === false){
            ngShow = "ng-show = ''"
          }
          return {'invisible' : invisible, 'ngShow': ngShow}
        }

        //Set Ag-Grid colum values/settings
        let docColumns = [
          {
              headerName: '',
              field: 'dummyCheckbox',
              maxWidth: 50,
              minWidth: 50,
              checkboxSelection: true,
              suppressMenu: true,
              suppressSorting: true,
              headerCheckboxSelection: true,
              headerCheckboxSelectionFilteredOnly: true,
          },
          {
            field: '',
            hide: true,                
            valueGetter: function (params) {
                if (params.data.drm_is_submitted)
                    return '2_submitted'
                else
                    return '1_Draft'
            },
            sort: 'asc',
          },
          {
              field: "review",
              headerName: " ",
              maxWidth: 135, 
              minWidth: 135, 
              suppressMenu: true,
              cellRenderer: (params) => {

                // Adding Permissions to edit button, on canManageDocuments and CanManageOwnDocuments
                // using invisible style to show/hide the button, 
                // ngShow to align the review buttons with other document edit permission

                let invisible = 'invisible'
                let ngShow = ''
                editPermissions = vm.checkEditPermissions(invisible, ngShow, params.data.drm_created_by_per_id)    
                invisible = editPermissions['invisible']
                ngShow = editPermissions['ngShow']

                return `<span class="fa-1x fa-stack pointer mr-2 ${invisible}" ${ngShow} style=" width: 1.25em;" ng-click="docCtrl.openModal('documentModal','edit', ${params.data.drm_id})"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title="{{menu.translateLabels(1194)}}"></i> <i ng-show="${!params.data.dlo_status}" class="fas fa-ban fa-stack-1x text-danger" note="is updating the document, please wait." title="${params.data.dlo_person} {{menu.translateLabels(3423)}}"></i></span>`
                    + `<span ng-class="{ transparent: ${!params.data.drm_is_submitted}, pointer: ${params.data.drm_is_submitted} }" ng-click="docCtrl.signoff(data)" class="{{ data.hasAcknowledged ? 'text-success' : ''}}" note="Review Submission" title="{{menu.translateLabels(3431)}}"><i class="far fa-file-alt fa-lg"></i></span>`
                    + `<span note="Submission Review History" title="{{menu.translateLabels(3430)}}" class="source signoff-count" ng-class="{ transparent: (!data.reviewedCount > 0 || !data.drm_is_submitted), pointer: (data.reviewedCount > 0 && data.drm_is_submitted) }" ng-click="docCtrl.viewAcknowledgeHistory(data);">{{ data.reviewedCount }}</span>`
                    + `<span class="pointer text-left" ng-click="docCtrl.viewReports($event, ${params.data.drm_id})"><i class="fa fa-external-link-alt" note="Launch Report" title="{{menu.translateLabels(3429)}}"></i></span>`
              },
              valueGetter: function (params) {
                  return params.data.reviewedCount
              },
          },
          {
            field: '',
            headerName: " ",
            minWidth: 200,
            maxWidth: 200,
            hide: true,            
            valueGetter: function (params) {
                let nonExpiry = params.data.drm_non_expiring_document
                let reviewed = params.data.hasAcknowledged
                let requireReview = params.data.requiredAcknowledge
                let dueDate = new Date(params.data.drm_review_by_date)
                let expiryDate = new Date(params.data.drm_expiry_date)
                let currentDate = new Date()
                if (dueDate < currentDate && !reviewed && requireReview)
                    return '1_Overdue'
                else if (!reviewed && requireReview)
                    return '2_Due'
                else
                    return '3_Reviewed_NotRequired'
            },
          },
          {
            field: "required_reviewers",
            headerName: " ",
            minWidth: 150,
            maxWidth: 150,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: (params) =>{
                return '<div>' +params.data.mandatory_reviewed_count + ` ${translateTag(1131)} ` + params.data.mandatory_reviewers_count +' </div>'
            },
          },
          {
            field: "drm_created_date",
            headerName: " ",
            minWidth: 130,
            maxWidth: 130,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: 'tippyCellRenderer',
            sort: 'desc'
          },
          
          {
            field: "drm_submitted_date",
            headerName: " ",
            minWidth: 150,
            maxWidth: 150,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: 'tippyCellRenderer',
            sort: 'desc'
          },
          {
            field: "drm_submitted_by_per",
            headerName: " ",
            minWidth: 150,
            maxWidth: 250,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: 'tippyCellRenderer'
          },
          {
              field: "drm_review_by_date",
              headerName: " ",
              minWidth: 140,
              maxWidth: 140,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: 'tippyCellRenderer',
              cellRenderer: (params) => {
                let dueDate = new Date(params.data.drm_review_by_date)
                let reviewed = params.data.hasAcknowledged
                let requireReview = params.data.requiredAcknowledge
                let currentDate = new Date()
                if (dueDate < currentDate && !reviewed && requireReview)
                    return '<div style="color: #D20000;">' + params.data.drm_review_by_date + '</div>'
                else
                    return '<div>' + params.data.drm_review_by_date + '</div>'
              },
          },
          {
              field: "drm_expiry_date",
              headerName: " ",
              minWidth: 150,
              maxWidth: 150,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: (params) => {
                let expiryDate = new Date(params.data.drm_expiry_date)
                let currentDate = new Date()
                if (expiryDate < currentDate)
                    return '<div style="color: #D20000;">' + params.data.drm_expiry_date + '</div>'
                else
                    return '<div>' + params.data.drm_expiry_date + '</div>'
              }
          },
          {
              field: "drm_document_type_rld_name",
              headerName: " ",
              minWidth: 100,
              maxWidth: 200,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: 'tippyCellRenderer',
              getQuickFilterText: (params) => {
                return getEmployeeName(params.value)
              },
          },
          {
              field: "drm_description",
              headerName: " ",
              minWidth: 200,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: 'tippyCellRenderer',
          },
          {
              field: "",
              headerName: " ",
              minWidth: 200,
              maxWidth: 300,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: (params) => {
                return `<span class="pointer clip" ng-click='docCtrl.openAttachment(${cleanDoubleCurly(JSON.stringify(params.value))})'><a class="source" href="#" ng-non-bindable>${params.value}</a></span>`
              },
              hide:true
          },
          {
            field: "drm_filename",
            headerName: " ",
            cellRenderer: (params)=>{
              if(params.data.drm_attachment_type === 'document'){                
                return `<span class="pointer clip" ng-click='docCtrl.openAttachment(${cleanDoubleCurly(JSON.stringify(params.data.drm_filename))})'><a class="source" href="#" ng-non-bindable>${params.data.drm_filename}</a></span>`                 
              }
              else if (params.data.drm_attachment_type === 'link'){
                return `<span class="pointer clip" ng-click='docCtrl.openTestLink(${cleanDoubleCurly(JSON.stringify(params.data.drm_url))})'><a class="source" href="#" ng-non-bindable>${params.data.drm_url}</a></span>`
              }
            },
            minWidth: 200,
            maxWidth: 300,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
          },     
          {
            field: "status",
            headerName: " ",
            maxWidth: 80,
            minWidth: 80,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: (params) => {
              let nonExpiry = params.data.drm_non_expiring_document
              let dueDate = new Date(params.data.drm_review_by_date)
              let expiryDate = new Date(params.data.drm_expiry_date)
              let currentDate = new Date()
              let draft = `<span class="clip">{{menu.translateLabels(1399)}}</span>` //Draft
              if (expiryDate < currentDate || dueDate < currentDate)
                  draft = '<span class="clip" style="color: #D20000;">{{menu.translateLabels(1399)}}</span>'   

              if(params.data.drm_is_submitted == false)
                return draft
              else if (params.data.drm_is_submitted && (expiryDate > currentDate || nonExpiry))
                return `<span class="clip">{{menu.translateLabels(3557)}}</span>` //Active
              else
                return `<span class="clip">{{menu.translateLabels(3494)}}</span>` //Expired
            },
            valueGetter: (params) => {
              let nonExpiry = params.data.drm_non_expiring_document
              let expiryDate = new Date(params.data.drm_expiry_date)
              let currentDate = new Date()

              if(params.data.drm_is_submitted == false)
                return translateTag(1399) // Draft
              else if (params.data.drm_is_submitted && (expiryDate > currentDate || nonExpiry))
                return translateTag(3557) // Active
              else
                return translateTag(3494) // Expired
            },
          },
          {field:"drm_created_by_per_id",hide:true},
          {field:"drm_created_date",hide:true},
          {field:"drm_document_type_rld",hide:true},
          {field:"drm_enable",hide:true},
          {field:"drm_id",hide:true},
          {field:"drm_is_company_wide",hide:true},
          {field:"drm_is_submitted",hide:true},
          {field:"drm_modified_by_per_id",hide:true},
          {field:"drm_modified_date",hide:true},
          {field:"drm_non_expiring_document",hide:true},
          {field:"hasAcknowledged",hide:true},
          {field:"requiredAcknowledge",hide:true},
          {field:"reviewedCount",hide:true},
          {field:"reviewedList",hide:true},
          {field:"mandatoryReviewersList",hide:true},

        ]
        vm.docOptions.columnDefs = docColumns      


        //Useful Links

        vm.usefulLinkOptions = gridService.getCommonOptions()
        vm.usefulLinkOptions.onSelectionChanged = () => {
          let selectedRows = vm.usefulLinkOptions.api.getSelectedRows()
          vm.actionLinkDisabled = selectedRows.length == 0
          $scope.$apply()
        }

        let usefulLinkColumns =[
          {
            headerName: '',
            field: 'dummyCheckbox',
            maxWidth: 50,
            minWidth: 50,
            checkboxSelection: true,
            suppressMenu: true,
            suppressSorting: true,
            headerCheckboxSelection: true,
            headerCheckboxSelectionFilteredOnly: true,
          },
          {
              field: "review",
              headerName: " ",
              maxWidth: 135, 
              minWidth: 135, 
              suppressMenu: true,
              cellRenderer: (params) => {
                // Adding Permissions to edit button, on canManageDocuments and CanManageOwnDocuments
                // using invisible style to show/hide the button, 
                // ngShow to align the review buttons with other document edit permission

                let invisible = 'invisible'
                let ngShow = ''
                editPermissions = vm.checkEditPermissions(invisible, ngShow, params.data.ulm_created_by_per_id) 
                invisible = editPermissions['invisible']
                ngShow = editPermissions['ngShow']

                return `<span class="pointer pr-2 ${invisible}" ${ngShow} ng-click="docCtrl.openModalUsefulLink('usefulLinkModal','edit', ${params.data.ulm_id})"><i class="fa fa-pen" style="padding: 5px" note="Edit" title="{{menu.translateLabels(1194)}}"></i></span>`
                    + `<span ng-class="{ transparent: ${!params.data.ulm_is_submitted}}" ng-click="docCtrl.signoffUsefulLink(data)" class="{{ data.hasAcknowledged ? 'text-success ' : 'pointer'}}" note="Review Submission" title="{{menu.translateLabels(3431)}}"><i class="far fa-file-alt fa-lg"></i></span>`
                    + `<span note="Submission Review History" title="{{menu.translateLabels(3430)}}" class="source signoff-count" ng-class="{ transparent: (!data.reviewedCount > 0 || !data.ulm_is_submitted), pointer: (data.reviewedCount > 0 && data.ulm_is_submitted) }" ng-click="docCtrl.viewAcknowledgeHistoryULM(data);">{{ data.reviewedCount }}</span>`
              },
              valueGetter: function (params) {
                return params.data.reviewedCount
              },
            },
            {
              field: "ulm_created_date",              
              headerName: " ",
              minWidth: 130,
              maxWidth: 130,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: 'tippyCellRenderer',
            },
            {
              field: "ulm_is_submitted",
              hide: true,
              sort: 'asc'
            },
            {
              field: "ulm_submitted_date",              
              headerName: " ",
              minWidth: 150,
              maxWidth: 150,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: 'tippyCellRenderer',
              sort: 'desc'
            },
            {
              field: "ulm_submitted_by_per_id",
              headerName: " ",
              minWidth: 150,
              maxWidth: 250,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: (params) => {        
                return getEmployeeName(params.value)
              }
            },
            {
              field: "ulm_description",
              headerName: " ",
              minWidth: 200,
              filter: 'agSetColumnFilter',
              menuTabs: ['filterMenuTab'],
              cellRenderer: 'tippyCellRenderer',
          },
          {
            field: "ulm_link",
            headerName: " ",
            minWidth: 200,
            maxWidth: 300,
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            cellRenderer: (params) => {
              return `<span class="pointer clip" ng-click='docCtrl.openTestLink(${cleanDoubleCurly(JSON.stringify(params.value))})'><a class="source" href="#" ng-non-bindable>${params.value}</a></span>`
            }
        },
      ]
        vm.usefulLinkOptions.columnDefs = usefulLinkColumns

      // Function to disable External Reviewer option on selecting a draft document / selecting more than 1 document
      function viewSelections() {
        let extrnl_reviewer_row = vm.docOptions.api.getSelectedRows()
        vm.disableExternalReviewer = true
        if (extrnl_reviewer_row.length === 1){
          if(extrnl_reviewer_row[0].drm_is_submitted){
            vm.disableExternalReviewer = false
          }
        }
      }

      vm.checkCopyRevisionPermissions = (rows) =>{
        if(vm.canManageOwnDocuments === true && vm.canManageDocuments === false){
          if(rows[0].drm_created_by_per_id !== vm.userFullName){
            return false
          }
        }
        return true
      }


        //Function used to open edit/add document modals
        vm.openModal = (modalId, mode='new', id) => {
          dateToday = moment(new Date(), 'YYYY-MM-DD')
          document.getElementById('sendEmailNotification').checked = false
          resetFormFieldClassList('docForm')
          vm.showOfflineDocs = false
          if(mode === 'new')
          {            
            vm.currentMode = 'new'
            vm.showAnother = true
            vm.resetForm()
            modalService.Open(modalId)
            vm.initializeSelect2(modalId)
          }
          else if (mode === 'revision'){
            vm.currentMode = 'revision'
            vm.resetForm()
            let rows = vm.docOptions.api.getSelectedRows()
            checkCopyRevisionPermissions = vm.checkCopyRevisionPermissions(rows)
            if(checkCopyRevisionPermissions === false){
              throwToastr('error',translateTag(3822),3000)
                    return
            }
            

            if (rows.length > 0 && rows.length < 2) {          
              
              vm.documentsData.forEach((docData)=>{
                if(rows[0].drm_id == docData.drm_id) { 
                  vm.currentDocument = JSON.parse(JSON.stringify(docData))
                  if (vm.currentDocument.drm_is_submitted == 0){
                    throwToastr('error',translateTag(3865),3000)
                    return
                  }
                  else {
                  
                  vm.currentDocument.drm_document_type_rld=vm.currentDocument.drm_document_type_rld_id
                  vm.currentDocument.drm_is_submitted = false
                  vm.currentDocument.drm_expiry_date = moment(vm.currentDocument.drm_expiry_date).format('YYYY-MM-DD')
                  vm.currentDocument.drm_review_by_date = moment(vm.currentDocument.drm_review_by_date).format('YYYY-MM-DD')
                  vm.currentDocument.drm_non_expiring_document == 1 ? vm.nonExpiry = true : vm.nonExpiry = false
                  vm.companyWide = vm.currentDocument.drm_is_company_wide                  
                  
                  if(vm.nonExpiry)
                    vm.currentDocument.drm_expiry_date = translateTag(1381) //N/A
  
                  vm.currentDocument.reviewersList = []
                  if(!vm.companyWide)
                  {
                    vm.currentDocument.reviewers.forEach((rev) => {
                      vm.currentDocument.reviewersList.push(rev.drr_per_id)
                    })
                  }  
                  vm.currentDocument.drm_filename = ''
                  modalService.Open(modalId)
                  vm.initializeSelect2(modalId)
                }
                
              }
              })
            

             
            }

            else {
              throwToastr('warning', translateTag(3424),2500)
                    return
            }
          }
          else if (mode === 'copy')
          {
            vm.currentMode = 'new'
            vm.showAnother = false
            vm.resetForm()           

            let rows = vm.docOptions.api.getSelectedRows()
            checkCopyRevisionPermissions = vm.checkCopyRevisionPermissions(rows)
            if(checkCopyRevisionPermissions === false){
              throwToastr('error',translateTag(3822),3000)
                    return
            }
            if (rows.length > 0 && rows.length < 2) {          
              vm.docCopy = true
              vm.documentsData.forEach((docData)=>{
                if(rows[0].drm_id == docData.drm_id) {                 
                  vm.currentDocument = JSON.parse(JSON.stringify(docData))
                  vm.currentDocument.drm_document_type_rld=vm.currentDocument.drm_document_type_rld_id
                  vm.currentDocument.drm_is_submitted = false
                  vm.currentDocument.drm_expiry_date = moment(vm.currentDocument.drm_expiry_date).format('YYYY-MM-DD')
                  vm.currentDocument.drm_review_by_date = moment(vm.currentDocument.drm_review_by_date).format('YYYY-MM-DD')
                  vm.currentDocument.drm_non_expiring_document == 1 ? vm.nonExpiry = true : vm.nonExpiry = false
                  vm.companyWide = vm.currentDocument.drm_is_company_wide
                  
                  if(vm.nonExpiry)
                    vm.currentDocument.drm_expiry_date = translateTag(1381) //N/A
  
                  vm.currentDocument.reviewersList = []
                  if(!vm.companyWide)
                  {
                    vm.currentDocument.reviewers.forEach((rev) => {
                      vm.currentDocument.reviewersList.push(rev.drr_per_id)
                    })
                  }  
                  vm.currentDocument.drm_filename = ''
                }
              })

              modalService.Open(modalId)
              vm.initializeSelect2(modalId)
            }
            else {
              toastr.error(translateTag(3488)) //Select only one row
            }
            vm.initializeSelect2(modalId)
          }
          else if(mode==='edit'){
            vm.resetForm()
            vm.documentDetails = {}
            vm.documentDetails.dlo_document_id = id
            vm.documentDetails.dlo_dlt_id = 8 //DOCUMENTS
            $q.all([
                documentLockService.docLock(vm.documentDetails)
            ]).then((response) => {
                vm.dlo_id = response[0].dlo_id
                vm.docLockStatus = response[0].status
                vm.docLockMessage = response[0].message
                vm.docLockTime = response[0].time
                if (!vm.docLockStatus){
                    throwToastr('warning',vm.docLockMessage,2000)
                }   
            }).then(()=> {
              if(vm.docLockStatus===true){                
                  vm.currentMode = 'edit'
                  vm.showAnother = false
                  vm.showOfflineDocs = false                 
      
                  // implementing toastr with default timeout
                  // toastr.options.progressBar = true
                  // throwToastr('info',"Loading data...",2000)
      
                  vm.documentsData.forEach((docData)=>{
                    if(id == docData.drm_id) {
                      vm.currentDocument = JSON.parse(JSON.stringify(docData))
                      vm.currentDocument.drm_document_type_rld=vm.currentDocument.drm_document_type_rld_id
                      vm.currentDocument.drm_expiry_date = moment(vm.currentDocument.drm_expiry_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                      vm.currentDocument.drm_review_by_date = moment(vm.currentDocument.drm_review_by_date, 'YYYY-MM-DD').format('YYYY-MM-DD')
                      vm.currentDocument.drm_non_expiring_document == 1 ? vm.nonExpiry = true : vm.nonExpiry = false
                      vm.companyWide = vm.currentDocument.drm_is_company_wide
                      vm.currentDocument.drm_attachment_type = vm.currentDocument.drm_attachment_type
                      if(vm.currentDocument.drm_is_submitted){
                        vm.disableURL = true
                      }
                      // check to see if the file Size is Larger than 5 mb
                      totalMB = vm.currentDocument.drm_file_size / 1000000
                      vm.currentDocument.drm_file_size_kb = `${totalMB.toFixed(2)} Mb`
                      if(vm.currentDocument.drm_file_size && vm.currentDocument.drm_file_size > 5000000){
                        vm.showOfflineDocs = false
                        vm.largeDocument = true
                      }
                      else {
                        vm.showOfflineDocs = true
                        vm.largeDocument = false
                      }
                    //  if(vm.currentDocument.drm_available_offline)
                       // vm.showOfflineDocs = true
      
                      if(vm.nonExpiry)
                        vm.currentDocument.drm_expiry_date = translateTag(1381) //N/A
      
                      vm.currentDocument.reviewersList = []
                      if(!vm.companyWide)
                      {
                        vm.currentDocument.reviewers.forEach((rev) => {
                          vm.currentDocument.reviewersList.push(rev.drr_per_id)
                        })
                      }
                      addHistoricalOption("document_type",vm.documentTypeList,vm.currentDocument.drm_document_type_rld, vm.currentDocument.drm_document_type_rld_name)
                    }
                  })
                  modalService.Open(modalId)
                  vm.initializeSelect2(modalId)

                  startUpdateDocLock() // Interval function to update to timestamp every 2 minutes
                  startLockModal() // Interval function after inactive page

              }
            })
          }
        }

        // functions for document lock start__

            //Zero the idle timer on mouse movement.
          $('#docForm').mousemove(function (e) {
              clearInterval(vm.lockModal)                
              vm.idletime = 0
              startLockModal()
          });

          //Zero the idle timer on keypres event
          $('#docForm').keypress(function (e) {
              clearInterval(vm.lockModal)
              vm.idletime = 0
              startLockModal()
          });

          vm.continueEditingDRM = () => {
              vm.lockCheckModal = false
              vm.closeLockModal('confirmModal')
              vm.countdownSeconds = 60
              vm.continueEditing = true
              document.getElementById('inactiveTime').textContent = ''
              clearInterval(vm.lockModal)
              clearInterval(vm.countdownTimer)
              clearTimeout(vm.relieveLock)
              vm.idletime = 0
              startLockModal()
          }
         
          function startUpdateDocLock(){
              vm.updateDocLockInterval = setInterval(() => {
                  $q.all([
                      documentLockService.intervalDocLock(vm.dlo_id)
                  ]).then((response) => {
                  })
              }, 30 * 1000)
          }
          vm.openLockModal = (modalId) => {
            modalService.Open(modalId)
          }

          function startLockModal(){
              vm.lockModal = setInterval(() => {
                  vm.idletime = vm.idletime + 1 // 1 minute
                  if(vm.idletime === 5){ // after 5 minutes of idle time open lockcheck modal
                      vm.continueEditing = false
                      vm.leaveEditing = false
                      vm.modalElementsLock = {
                        title: translateTag(3419),   //"Page inactive for 5 minutes" 
                        message: `<div style="text-align: center;"><h1 id ="inactiveTime" ></h1><p> ${translateTag(3420)}</p></div>`,  //"The entry will automatically save and close if no action is taken"
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Continue Working">{{vm.componentTranslateLabels(3421)}}</button>
                            <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.return('button2')" note="Save and Close">{{vm.componentTranslateLabels(3422)}}</button>`
                      }
                      document.getElementById('confirmcallingform').innerHTML = 'DRLOCKCALLCONFIRMMODAL' 
                      $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsLock)
                      vm.lockCheckModal = true
                      startcountdownTimer()
                      vm.relieveLock = setTimeout(() => {
                          if (vm.lockCheckModal === true){
                              if (!vm.continueEditing && !vm.leaveEditing){
                                  vm.leaveEditing = true
                                  clearInterval(vm.updateDocLockInterval)
                                  clearInterval(vm.lockModal)
                                  clearInterval(vm.countdownTimer)
                                  clearTimeout(vm.relieveLock)
                                  vm.closeLockModal('confirmModal')
                              }
                          }
                      }, 60 * 1000);
                  }                                        
              }, 60 * 1000);
          }

          $scope.$on("DRLOCKCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.continueEditingDRM()
            }
            else if (result=='button2') {
                vm.closeLockModal('confirmModal')
            }
        })

          function startcountdownTimer(){
              vm.countdownTimer = setInterval(() => {
                  if(vm.lockCheckModal === true && vm.countdownSeconds>=0){
                    vm.content = ''
                    document.getElementById('inactiveTime').textContent = ''
                    if (vm.countdownSeconds === 60){
                        vm.content = "01:00"
                    }
                    else{
                        vm.content = "00:" + vm.countdownSeconds.toLocaleString('en-US', {
                            minimumIntegerDigits: 2,
                            useGrouping: false
                          }) 
                    }
                    document.getElementById('inactiveTime').textContent =  vm.content
                    vm.countdownSeconds = vm.countdownSeconds - 1   
                }                                        
              }, 1000)
          }

          vm.closeLockModal = (modalId) => {
            clearInterval(vm.lockModal)
            clearInterval(vm.countdownTimer)
            clearTimeout(vm.relieveLock)
            modalService.Close(modalId)
            if(vm.lockCheckModal) {
              documentLockService.closeDocLock({dlo_id: vm.dlo_id}).then((response) => {
                refreshData()
                vm.closeModal('documentModal')
              })
            }
          }

          // functions for document lock end___ 


        vm.openModalUsefulLink = (modalId, mode='new', id) => {
          resetFormFieldClassList('usefulLinkForm')
          if(mode === 'new')
          {            
            vm.currentMode = 'new'
            vm.showAnother = true
            vm.resetUsefulLinkForm()
          }
          else {       
            vm.currentMode = 'edit'
            vm.showAnother = false
            vm.resetUsefulLinkForm()

            vm.usefulLinkData.data.forEach((ulmData)=>{
              if(id == ulmData.ulm_id) {
                vm.currentUsefulLink = JSON.parse(JSON.stringify(ulmData))
                vm.currentUsefulLink.ulm_description = vm.currentUsefulLink.ulm_description
                vm.currentUsefulLink.ulm_link = vm.currentUsefulLink.ulm_link
              }
            })
          }

          modalService.Open(modalId)
          vm.initializeSelect2(modalId)
        }

        // Function to open External Reviewer Modal
        vm.openExternalReviewerModal = () =>{
          if (vm.docOptions.api.getSelectedRows().length > 1){
            throwToastr('warning', translateTag(3424), 2000) //Restricted to one record at a time
            return 
          }
          vm.resetExternalReviewerForm()
          clearAllSign ()
          vm.sponser_name = getEmployeeName(vm.userId)
          modalService.Open("drm_external_reviewer_modal")
        }

        vm.openSignModal = (e) => {
          document.getElementById(`sigModalOK`).removeEventListener('click', signFunction)
          vm.mainButton = e.currentTarget
          vm.target =  e.currentTarget.getAttribute('signaturename')
          $(`#${vm.target}`).val('')
          $(`#${vm.target}_img`).val('')
          $('#output').val('')
          modalService.Open('drSignatureModal')
          activateSignature()
      }

      function signFunction(e){ 
          e.stopPropagation()
          let vecValue = document.querySelector('#output').value
          if(vecValue){
              vm.drmExternalReviewer[vm.target] = $(`.sigPadModal .pad2`)[0].toDataURL('image/jpeg')
              $(`#${vm.target}`).next().val(vecValue)
              $(`#${vm.target}_img`).attr('src',$(`.sigPadModal .pad2`)[0].toDataURL('image/jpeg'))
          } else {
              $(`#${vm.target}`).val('')
              $(`#${vm.target}`).next().val('')
              $(`#${vm.target}_img`).attr('src','')
          }

          $(`#sigModal .output`).val('')

          if(vecValue) {            
              vm.mainButton.innerHTML = `<i class="fa fa-pen" note="Re-sign"></i> ${translateTag(2243)}`
              $(`#${vm.target}`).prev().prev().children()[2].classList.remove('d-none')
              $(`#${vm.target}`).prev().prev().children()[1].classList.remove('d-none') // add comment button
              $(`#${vm.target}`).prev().prev().children()[0].classList.remove('invalid')
          } 
          else {
              vm.mainButton.innerHTML = `<i class="fa fa-pen" note="Sign"></i> ${translateTag(1396)}`
              $(`#${vm.target}_img`).attr('src','')
              $(`#${vm.target}`).prev().prev().children()[1].classList.add('d-none')
              $(`#${vm.target}`).prev().prev().children()[2].classList.add('d-none') // add comment button
              clearComment()
          }
          
          let sig = $('.sigPadModal').signaturePad({})
          sig.clearCanvas()
          

          modalService.Close('drSignatureModal')
      }

      function activateSignature(){
        $('canvas.pad2').attr({"width": $('.pad2').parent().width(),"height":$('.pad2').parent().width()/3})
          setTimeout(()=>{              
                  let sig = $('.sigPadModal').signaturePad({
                  lineColour: "#ced4da",
                  drawOnly: true,
                  lineWidth: 0,
                  lineBottom: 10,
                  bgColour: 'rgb(255,255,255)'
              })
              sig.clearCanvas()

              document.getElementById(`sigModalOK`).addEventListener('click',signFunction)
              document.getElementById(`reSignButton`).addEventListener('click',(e) =>{  
              canvas = e.target.parentNode.previousSibling.previousElementSibling.previousElementSibling
              let sig = $('.sigPadModal').signaturePad(	{
                  lineColour: "#ced4da",
                  drawOnly: true,
                  lineWidth: 0,
                  lineBottom: 10,
                  bgColour: 'rgb(255,255,255)'
                  });
                  sig.clearCanvas()
              })
          },300)            
      }

      $(`.clear_sign`).click((e) => {
 
        let clear_button
        if(e.target.tagName.toLowerCase() == 'i') // If clicked on <i>
            e.target = e.target.parentNode
   
        clear_button = e.target
        let id=clear_button.id
        let who = id
        vm.who = who
        if(vm.signatureCommentObject[who]){
          if(vm.signatureCommentObject[who].com_comment !='' && vm.signatureCommentObject[who].com_comment !==undefined ){ 
            vm.modalElementsRemoveSig = {
              title: translateTag(2777), //"Remove Signature/Comment?"
              message: `<div><p>${translateTag(2781)}</p></div>`, //"Are you sure you want to remove the signature and associated comment from the form?"
              buttons: 
                  `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="YES">{{vm.componentTranslateLabels(1379)}}</button>
                  <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>`
            }
              document.getElementById('confirmcallingform').innerHTML = 'DRREMOVESIGCALLCONFIRMMODAL' 
              $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsRemoveSig)
              vm.button = clear_button
            } else {
                clearSignature(clear_button)
            }
        } else {
            clearSignature(clear_button) 
        }  
      })
              
      $scope.$on("DRREMOVESIGCALLCONFIRMMODAL", (event,result) => {
        if (result=='button1') {
            vm.clear_signature_comment()
        }
      })
      
      function clearSignature(clear_button){

          clear_button.previousElementSibling.previousElementSibling.innerHTML = `<i class="fa fa-pen" note="Sign"></i> ${translateTag(1396)}`
          clear_button.parentNode.nextElementSibling.setAttribute('src','')

          vm.drmExternalReviewer[clear_button.previousElementSibling.getAttribute('signaturename')] = ''
          clear_button.parentNode.nextElementSibling.nextElementSibling.value = ''
          clear_button.parentNode.nextElementSibling.nextElementSibling.nextElementSibling.value = ''
          clear_button.classList.add('d-none')
          clear_button.parentNode.children[1].classList.add('d-none') //hide the add comment button.

          if(clear_button.parentNode.nextElementSibling.nextElementSibling.hasAttribute('required')){
              clear_button.previousElementSibling.classList.add('invalid')
          }
          clearComment()
      }  

      vm.clear_signature_comment = () => {
        vm.signatureCommentObject[vm.who]=null
        clearSignature(vm.button)
        modalService.Close('confirmModal')
      }

      function clearComment(){

        // Clear the comment value and replace the bubble.
        let who = 'external_reviewer'
        let elem = document.getElementById(`${who}_comment`)        
        elem.classList.remove('fas')
        elem.classList.add('far')  
        vm.signatureCommentObject[who] = null
    }

      function clearAllSign () {

        // Clear all signatures.
        let signImgs = Array.from(document.getElementsByClassName("clear_sign"))

        signImgs.forEach ((img) => {
            img.previousElementSibling.previousElementSibling.innerHTML = `<i class="fa fa-pen" note="Sign"></i> ${translateTag(1396)}`
            img.parentNode.nextElementSibling.setAttribute('src','')

            img.parentNode.nextElementSibling.nextElementSibling.value = ''
            img.parentNode.nextElementSibling.nextElementSibling.nextElementSibling.value = ''
            img.classList.add('d-none')
            img.parentNode.children[1].classList.add('d-none') //hide the add comment button.


            if(img.parentNode.nextElementSibling.nextElementSibling.hasAttribute('required')){
                img.previousElementSibling.classList.add('invalid')
            }               
        })
        clearComment()
    }

        //Function to toggle expiry date value to "N/A" if it is non expiry
        vm.toggleNonExpiry = () => {
          if(vm.nonExpiry)
          {
            vm.currentDocument.drm_expiry_date = translateTag(1381)
          }
          else{
            vm.currentDocument.drm_expiry_date = moment(vm.currentDocument.drm_review_by_date, "YYYY-MM-DD").add(1, 'days').format('YYYY-MM-DD')
          }
        }

        vm.reviewByChanged = () => {
          if(vm.currentDocument.drm_review_by_date >= vm.currentDocument.drm_expiry_date)
            vm.currentDocument.drm_expiry_date = moment(vm.currentDocument.drm_review_by_date, "YYYY-MM-DD").add(1, 'days').format('YYYY-MM-DD')
        }

        //Function to toggle reviwers list to empty
        vm.toggleCompanyWide = () => {          
            if(vm.companyWide) {
                vm.currentDocument.reviewersList = []
                vm.initializeSelect2('documentModal')
            }
        }

        //Function to save the document
        vm.saveDoc = (mode) => {
          if (vm.ValidateForm('docForm')){
            $scope.$emit('STARTSPINNER', vm.loadMessage)

            vm.submitted = true
            if(vm.currentMode === "new" || vm.currentMode === 'revision') {
              let payload = preparePayload('new', JSON.parse(JSON.stringify(vm.currentDocument)))
              
              if(mode === 'save'){
                payload.drm_is_submitted = false
              }
              else if(mode === 'submit'){
                payload.drm_is_submitted = true
              }
              documentReviewService.createDocument(payload).then((response) => {               
                
                let fd = new FormData()
                fd.append('drm_id', response.drm_id)
                fd.append('drm_file', vm.uploadFile)
                // In the case where the submission is a file, set the filesize.               
                if(vm.uploadFile){
                  fd.append('drm_file_size', vm.uploadFile.size)
                }
                fd.append('drm_attachment_type',payload.drm_attachment_type)
                fd.append('drm_available_offline', payload.drm_available_offline?payload.drm_available_offline:false)
                
                // Console log form data  keep this to check the formdata
                // for (let pair of fd.entries()) {
                //     console.log(pair[0] + ' : ' + pair[1])
                // }

                if(payload.drm_attachment_type === 'document'){
                  documentReviewService.addAttachment(fd).then((attResponse) => {
                    vm.uploadFile = null
                    startRefresh()
                  })
                }
                else {
                  startRefresh()
                }
                
                function startRefresh() {
                  if(vm.addAnother)
                  {
                    refreshData()
                    vm.resetForm()
                    vm.initializeSelect2('documentModal')
                    return
                  }
                  else 
                  {
                    clearInterval(vm.lockModal)
                    clearInterval(vm.countdownTimer)
                    clearInterval(vm.updateDocLockInterval)
                    clearTimeout(vm.relieveLock)
                    documentLockService.closeDocLock({dlo_id: vm.dlo_id}).then((response) => {
                      refreshData()
                      vm.closeModal('documentModal')
                    })
                  }
                }
              })
            }
            else{
              let payload = preparePayload('edit', JSON.parse(JSON.stringify(vm.currentDocument)))
              
              if(mode === 'save') {
                payload.drm_is_submitted = false
              }
              else if(mode === 'submit' && !payload.drm_is_submitted) {
                payload.drm_is_submitted = true
              }

              documentReviewService.updateDocument(payload).then((response) => {
                let fd = new FormData()
                fd.append('drm_id', payload.drm_id)
                fd.append('drm_file', vm.uploadFile)
                // In the case where the submission is a file, set the filesize.
                if(vm.uploadFile) {
                  fd.append('drm_file_size', vm.uploadFile.size)
                }
                fd.append('drm_attachment_type',payload.drm_attachment_type)                
                fd.append('drm_available_offline', payload.drm_available_offline)

                if(payload.drm_attachment_type === 'document' && vm.uploadFile) {
                  documentReviewService.addAttachment(fd).then((attResponse) => {
                    vm.uploadFile = null
                    startRefresh()
                  })
                }
                else {
                  startRefresh()
                }

                function startRefresh() {
                  clearInterval(vm.lockModal)
                  clearInterval(vm.countdownTimer)
                  clearInterval(vm.updateDocLockInterval)
                  clearTimeout(vm.relieveLock)
                  documentLockService.closeDocLock({dlo_id: vm.dlo_id}).then((response) => {
                    refreshData()
                    vm.closeModal('documentModal')
                  })
                }
              })
            }
          } else {
            $rootScope.$broadcast("CALLCONFIRMMODAL")
          }
        }

        //Function to prepare payload data
        function preparePayload(mode='new', payload) {
            let preparedPayload = {}
            if(mode == 'edit')
            {
                preparedPayload.drm_id = payload.drm_id
            }
            
            if(vm.companyWide == false)
            {
                preparedPayload.reviewers = payload.reviewersList
            }
            preparedPayload.drm_is_company_wide = vm.companyWide
            preparedPayload.drm_document_type_rld = payload.drm_document_type_rld
            preparedPayload.drm_description = payload.drm_description
            preparedPayload.drm_review_by_date = payload.drm_review_by_date
            vm.nonExpiry ? preparedPayload.drm_expiry_date = undefined : preparedPayload.drm_expiry_date = payload.drm_expiry_date
            preparedPayload.drm_non_expiring_document = vm.nonExpiry
            preparedPayload.drm_is_submitted = payload.drm_is_submitted
            preparedPayload.drm_attachment_type = payload.drm_attachment_type
            preparedPayload.drm_url = payload.drm_attachment_type === 'link' ? payload.drm_url : ''
            preparedPayload.drm_filename = vm.currentDocument.drm_filename
            preparedPayload.drm_available_offline = payload.drm_attachment_type === 'document' ? payload.drm_available_offline : false
            // preparedPayload.send_email_flag = document.getElementById('sendEmailNotification').checked
            preparedPayload.send_email_flag = vm.sendemailFlag
           
            preparedPayload.is_revision = false
            preparedPayload.revision_drm_id = false
            
            if(vm.currentMode === 'revision'){
              preparedPayload.is_revision = true
              preparedPayload.revision_drm_id = payload.drm_id
            }
            return preparedPayload
        }


        vm.saveUsefulLink = (mode) => {
          if (vm.ValidateForm('usefulLinkForm')){
            if(!validURL(vm.currentUsefulLink.ulm_link)) {
              toastr.error(translateTag(9473)) // Invalid URL
              return null
            }
            vm.submitted = true
            if(vm.currentMode === "new") {
              let payload = prepare_ulm_Payload('new', JSON.parse(JSON.stringify(vm.currentUsefulLink)))
              if(mode === 'save'){
                payload.ulm_is_submitted = false
              }
              else if(mode === 'submit'){
                payload.ulm_is_submitted = true
                //payload.ulm_submitted_date = dateToday.format("YYYY-MM-DDThh:mm")
              }
              documentReviewService.createUsefulLink(payload).then((response)=>{
                if(vm.addAnotherLink)
                {
                  resetUsefulLinkList()
                  vm.resetUsefulLinkForm()
                  vm.initializeSelect2('usefulLinkModal')
                  return
                }
                else{
                  resetUsefulLinkList()
                }
                vm.closeModal('usefulLinkModal')
              })
            }
            else{
              let payload = prepare_ulm_Payload('edit', JSON.parse(JSON.stringify(vm.currentUsefulLink)))
              if(mode === 'save'){
                payload.ulm_is_submitted = false
              }
              else if(mode === 'submit'){
                payload.ulm_is_submitted = true
                payload.ulm_submitted_date = dateToday.format("YYYY-MM-DDThh:mm")
              }
              documentReviewService.updateUsefulLink(payload).then((response)=>{
                let fd = new FormData()
                fd.append('ulm_id', response.ulm_id)
                refreshData()
                vm.closeModal('usefulLinkModal')                
              })
            }
          } else {
            $rootScope.$broadcast("CALLCONFIRMMODAL")
          }
        }
      

        function prepare_ulm_Payload(mode='new', payload) {
          let preparedPayload = {}
          if(mode === 'edit')
          {
              preparedPayload.ulm_id = payload.ulm_id
          }
          preparedPayload.ulm_description = payload.ulm_description
          preparedPayload.ulm_link = payload.ulm_link

          return preparedPayload
      }

        //Fuction used to close modals
        vm.closeModal = (modalId) => {
          modalService.Close(modalId)
          vm.resetForm()
          vm.resetUsefulLinkForm()
        }

        vm.cancelDocModal = () => {
          clearInterval(vm.lockModal)
          clearInterval(vm.countdownTimer)
          clearInterval(vm.updateDocLockInterval)
          clearTimeout(vm.relieveLock)
          documentLockService.closeDocLock({dlo_id: vm.dlo_id}).then((response) => {
            vm.closeModal('documentModal')
          })
        }

        //Fuction used to close modals
        vm.cancelModal = (modalId) => {
          if(modalId==='drm_external_reviewer_modal'){
            clearAllSign()
          } 
          modalService.Close(modalId)
        } 

        //Function to clear filter
        vm.clearFilter = () => {
          vm.getFilterType = 'None'
          refreshData()                     
        }

        function validURL(str) {
          var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
            '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
            '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
            '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
            '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
            '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
          return !!pattern.test(str);
        }

        // Fuction to check if all modal feilds are valid
        vm.ValidateForm = (form) => {
          let validated = validateFormFields(form, false, {link_text:['//'], document_url:['//']})
          if(form === 'docForm'){
            if(vm.currentDocument.drm_attachment_type === 'document' && vm.currentDocument.drm_filename === ''){
              validated = false
              resetFormFieldClassList(form)
              toastr.error(translateTag(1354)) //Please upload a Document for review
            }
            else if(vm.currentDocument.drm_attachment_type === 'link' && vm.currentDocument.drm_url === ''){
              validated = false
              resetFormFieldClassList(form)
              toastr.error(translateTag(3489)) //Please upload a Document Link for review
            }
            else if(vm.currentDocument.drm_attachment_type === 'link' && !validURL(vm.currentDocument.drm_url)){
              validated = false
              resetFormFieldClassList(form)
              toastr.error(translateTag(9473)) // Invalid URL
            }
          }          
          return validated
        }

        //Funtion to initialize select2
        vm.initializeSelect2 = (parent)=> {
          setTimeout(()=>{ 
          $('.select-single, .select-multiple')
            .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} .modal-body`), escapeMarkup: function (text) { return text } })
            .on('select2:select', () => {
              $(this).parent().find('label').addClass('filled')
            })
            $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
            select2Service.select2Tags()
          }, 100)
          if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
          $('#reviewBy').pickadate({
            format: 'yyyy-mm-dd',
            onClose : function(){
              this.$holder.blur()
            },
            onOpen: function () {
              this.set("min", new Date())
            }
          }).removeAttr('readonly')
          .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
            evt.preventDefault()
          })

          $('#expiryDate').pickadate({
            format: 'yyyy-mm-dd',
            onClose : function(){
              this.$holder.blur()
            },
            onOpen: function () {
              this.set("min", moment(vm.currentDocument.drm_review_by_date, "YYYY-MM-DD").add(1, 'days').toDate())
            }
          }).removeAttr('readonly')
          .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
            evt.preventDefault()
          })
        }

        function resetUsefulLinkList() {
          documentReviewService.getUsefulLinkList(vm.mainDateFilter).then (()=>{
            vm.usefulLinkData = documentReviewService.readUsefulLinksList()
            if (vm.usefulLinkOptions.api) {
              translateAgGridHeader (vm.usefulLinkOptions)
              let modelUsefulLink = vm.usefulLinkOptions.api.getFilterModel()
              vm.usefulLinkOptions.paginationPageSize = 10
              vm.usefulLinkOptions.api.setRowData(prepareUsefulLinkGridData())
              vm.usefulLinkOptions.api.redrawRows()
              vm.usefulLinkOptions.api.sizeColumnsToFit()
              vm.usefulLinkOptions.api.setFilterModel(modelUsefulLink)
            }
          })
        }
        //Function to refresh data and Ag-Grid
        function refreshData() {
          $scope.$emit('STARTSPINNER', vm.loadMessage)
          if ($window.sessionStorage.getItem('homepageRedirect_documentsFilter') == 'Person') {
            vm.defaultDateFilter = 'beginning'
            vm.getFilterType = 'Person'
          }
          else if ($window.sessionStorage.getItem('homepageRedirect_documentsFilter') == 'Site') {
            vm.defaultDateFilter = 'beginnig'
            vm.getFilterType = 'Site'
          }
          else if ($window.sessionStorage.getItem('homepageRedirect_documentsFilter') == 'Company') {
            vm.defaultDateFilter = 'beginnig'
            vm.getFilterType = 'Company'
          }
          else if (vm.getFilterType == null){
            vm.defaultDateFilter = '30'
            vm.getFilterType = 'None'
          }
          $q.all([   
            employeesService.getPersonProfile(),
            listService.getSelectListData('ref_document_type'),
            profileService.getAllEmployeeProfile(),
            profileService.getFullEmployeeProfile(),
            documentReviewService.getDocumentsList({filter:vm.getFilterType, range: vm.mainDateFilter}),
            documentReviewService.getUsefulLinkList(vm.mainDateFilter)
          ]).then((data) => {
            vm.fullEmployeeList = profileService.readFullEmployeeProfile() 
            vm.employeeList = profileService.readAllEmployeeProfile()
            vm.userId = data[0].per_id
            vm.userFullName = getEmployeeName(vm.userId)
            vm.documentTypeList = data[1]
            vm.documentsData = documentReviewService.readDocumentsList()
            vm.usefulLinkData = documentReviewService.readUsefulLinksList()
            if (vm.docOptions.api) {
              translateAgGridHeader (vm.docOptions)
              let modelDoc = vm.docOptions.api.getFilterModel()
              vm.docOptions.paginationPageSize = 10
              vm.docOptions.api.setRowData(prepareDocumentsGridData())
              vm.docOptions.api.redrawRows()
              vm.docOptions.api.sizeColumnsToFit()
              vm.docOptions.api.setFilterModel(modelDoc)
            }
            if (vm.usefulLinkOptions.api) {
              translateAgGridHeader (vm.usefulLinkOptions)
              let modelUsefulLink = vm.usefulLinkOptions.api.getFilterModel()
              vm.usefulLinkOptions.paginationPageSize = 10
              vm.usefulLinkOptions.api.setRowData(prepareUsefulLinkGridData())
              vm.usefulLinkOptions.api.redrawRows()
              vm.usefulLinkOptions.api.sizeColumnsToFit()
              vm.usefulLinkOptions.api.setFilterModel(modelUsefulLink)
            }
            vm.actionDisabled = true
            vm.actionLinkDisabled = true
            vm.archiveDoc = false
            vm.archiveUsefulLink = false            
         
          }).then(() => {
            if (vm.docOptions.api)
              vm.docOptions.api.sizeColumnsToFit()
            if (vm.usefulLinkOptions.api)
              vm.usefulLinkOptions.api.sizeColumnsToFit()

              $scope.$emit('STOPSPINNER')
              $window.sessionStorage.removeItem('homepageRedirect_documentsFilter')

          })
        }
      //  refreshData()

        //Function to prepare Ag-Grid data with string values
        function prepareDocumentsGridData() {

          let docGridData = JSON.parse(JSON.stringify(vm.documentsData))

          docGridData.forEach((rec) =>{
            rec.exceptionFields = ['drm_enable', 'reviewed_reviewers', 'drm_file_size', 'reviewers', 'dlo_enable', 'dlo_person', 'dlo_person', 'dlo_status', 'drm_offline_attachment', 'drm_url', 'mandatory_reviewed_count', 'mandatory_reviewers_count', 'drm_document_type_rld_id', 'hasAcknowledged', 'requiredAcknowledge', 'external_reviewers']
            rec.drm_created_by_per_id = getEmployeeName(rec.drm_created_by_per_id)
            rec.drm_modified_by_per_id = getEmployeeName(rec.drm_modified_by_per_id)
            rec.drm_submitted_by_per = rec.drm_is_submitted == 1 ? getEmployeeName(rec.drm_created_by_per_id) : ''
            rec.drm_document_type_rld = getDocumentType(rec.drm_document_type_rld_id)
            rec.hasAcknowledged = checkAcknowledged(rec , 'document')
            rec.requiredAcknowledge = checkRequiredAcknowledge(rec)

            rec.drm_created_date = moment(rec.drm_created_date).format('YYYY-MM-DD')
            rec.drm_expiry_date = moment(rec.drm_expiry_date).format('YYYY-MM-DD')
            rec.drm_review_by_date = moment(rec.drm_review_by_date).format('YYYY-MM-DD')
            rec.drm_modified_date = moment(rec.drm_modified_date).format('YYYY-MM-DD')
            rec.drm_submitted_date = rec.drm_submitted_date ? moment(rec.drm_submitted_date).format('YYYY-MM-DD'): ''
            rec.drm_is_submitted = rec.drm_is_submitted == 1 ? true : false
            if(!rec.drm_is_submitted)
              rec.drm_submitted_date = ''

            rec.drm_non_expiring_document == 1 ? rec.drm_non_expiring_document = true : rec.drm_non_expiring_document = false
            if(rec.drm_non_expiring_document)
              rec.drm_expiry_date = translateTag(1381) //N/A

            rec.reviewedList = ''
            rec.mandatoryReviewersList = ''

            if(rec.dlo_enable.length !== 0){
              rec.dlo_status = rec.dlo_enable[0].dlo_enable
              rec.dlo_person = rec.dlo_enable[0].dlo_person
            }
            else{
                rec.dlo_status = true
                rec.dlo_person = null
            }
            
            rec.reviewedCount = 0
            //mandatory_reviewers count
            rec.mandatory_reviewers_count = rec.reviewers.length
            rec.mandatory_reviewed_count = 0            
            
            if(rec.drm_is_company_wide)
            {
              rec.mandatoryReviewersList = translateTag(1094) //Company Wide
            }
            else
            {
              rec.reviewers.forEach((rev) => {
                rec.mandatoryReviewersList += (`${getEmployeeName(rev.drr_per_id)}; `)
              })
            }

            rec.reviewed_reviewers.forEach((rev) => {
              rec.reviewedList += (`${getEmployeeName(rev.drr_per_id)}; `)
              rec.reviewedCount += 1

              if(rev.drr_is_mandatory)
                rec.mandatory_reviewed_count += 1
            })

            rec.external_reviewers.forEach((rev) => {
              rec.reviewedList += (`${rev['der_last_name']}, ${rev['der_first_name']}; `)
              rec.reviewedCount += 1
            })
          })

          return docGridData
        }


        //Function to prepare AG-Grid data for usefull link
        function prepareUsefulLinkGridData(){
          let usefulLinkGridData = JSON.parse(JSON.stringify(vm.usefulLinkData.data))

          usefulLinkGridData.forEach((rec) =>{
            rec.exceptionFields = ['ulm_enable', 'ulm_submitted_by_per_id']
            rec.ulm_created_by_per_id = getEmployeeName(rec.ulm_created_by_per_id)
            rec.ulm_modified_by_per_id = getEmployeeName(rec.ulm_modified_by_per_id)
            rec.ulm_submitted_by_per = getEmployeeName(rec.ulm_submitted_by_per_id)

            rec.ulm_created_date = moment(rec.ulm_created_date).format('YYYY-MM-DD')
            rec.ulm_modified_date = rec.ulm_modified_date == null? '': moment(rec.ulm_modified_date).format('YYYY-MM-DD')
            rec.ulm_submitted_date = moment(rec.ulm_submitted_date).format('YYYY-MM-DD')
            rec.ulm_is_submitted = rec.ulm_is_submitted == 1 ? true : false
            if(!rec.ulm_is_submitted)
              rec.ulm_submitted_date = ''
            rec.reviewedList = ''
            rec.reviewedCount = 0
            rec.hasAcknowledged = checkAcknowledged(rec, 'usefullink')
            rec.reviewers.forEach((rev) => {
              rec.reviewedList += (` -  ${getEmployeeName(rev.ulr_reviewed_by_per)}`)
              rec.reviewedCount += 1
            })
            
          })
          return usefulLinkGridData
        }

        //Update Ag-Grid size when window is resized
        $(window).on('resize', () => {
          $timeout(function () {
            if (vm.docOptions.api)
                vm.docOptions.api.sizeColumnsToFit()
            if (vm.usefulLinkOptions.api)
                vm.usefulLinkOptions.api.sizeColumnsToFit()
          })
        })



      // Comments
      vm.signatureCommentObject = {
        external_reviewer: null
      }

      vm.AddComments = (who) => {            
          vm.signed_by = who
          //set parameters for opening the modal here.
          document.getElementById('parentform').innerHTML = 10
          document.getElementById('savetomemory').innerHTML = true
          document.getElementById('callingform').innerHTML = 'CLOSEDISCIPLINEIMAGECOMMENTSMODAL'  
          if(vm.signatureCommentObject[who]!=null) {
            $rootScope.$broadcast("RECIEVEROFCOMMENTS",vm.signatureCommentObject[vm.signed_by].com_comment)
          }else{$rootScope.$broadcast("RECIEVEROFCOMMENTS")}   
      }

      $scope.$on('CLOSEDISCIPLINEIMAGECOMMENTSMODAL',(event,data) => {                       
          // Close comment modal event.
          let elem = document.getElementById(`${vm.signed_by}_comment`)
          
          if(data.com_comment === '' || data.com_comment === null){
              vm.signatureCommentObject[vm.signed_by] = null
              elem.classList.remove('fas')
              elem.classList.add('far')                
          }
          else{
              elem.classList.remove('far')
              elem.classList.add('fas')      
              vm.signatureCommentObject[vm.signed_by] = data
          }            

      })
      // end comments
         
      //END
      }
    ])