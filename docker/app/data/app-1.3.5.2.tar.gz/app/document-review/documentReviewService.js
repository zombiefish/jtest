angular
    .module('safeToDo')
    .service('documentReviewService', ['$http',
        function ($http) {
            let documentList = []
            let usefulLinkList = []
            let documentNamesList = []

            return {
                getDocumentsList: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/drm/get-all-documents/`, payload).then((response) => {
                        documentList = response.data
                    }, (errorParams) => {
                        console.log('Failed to load Documents', errorParams)
                    })
                },

                createDocument: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/drm/create-document/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create document', errorParams)
                    })
                },
                updateDocument: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/drm/update-document/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to update document', errorParams)
                    })
                },

                addAttachment: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/drm/add-attachment/`, payload,{
                        // this cancels AngularJS normal serialization of request
                        transformRequest: angular.identity,
                        // this lets browser set `Content-Type: multipart/form-data` 
                        // header and proper data boundary
                        headers: {'Content-Type': undefined}}).then((response) =>{
                        return response
                    }, (errorParams) => {
                        console.log('Failed to add attachment', errorParams)
                    })
                },

                updateAttachment: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/drm/update-attachment/`, payload,{
                        // this cancels AngularJS normal serialization of request
                        transformRequest: angular.identity,
                        // this lets browser set `Content-Type: multipart/form-data` 
                        // header and proper data boundary
                        headers: {'Content-Type': undefined}}).then((response) =>{
                        return response
                    }, (errorParams) => {
                        console.log('Failed to update attachment', errorParams)
                    })
                },

                archiveDocument: (IdList) => {
                    var patchList = []
                    for (var i = 0; i < IdList.length; i++) {
                        patchList.push({ drm_id: IdList[i]})
                    }
                    return $http.post(`${__env.apiUrl}/api/drm/archive-document/`, patchList).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to archive document', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })                    
                },

                acknowledgeDocument: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/drm/acknowledge-document/`, payload).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to acknowledge document', errorParams)
                    })                    
                },

                // Useful link endpoints

                createUsefulLink: (payload) => {

                    return $http.post(`${__env.apiUrl}/api/drm/add-useful-link/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create useful link', errorParams)
                    })
                },

                updateUsefulLink: (payload) => {

                    return $http.post(`${__env.apiUrl}/api/drm/update-useful-link/`, payload).then((response) => {
                        console.log('DONE!!')
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create useful link', errorParams)
                    })
                },

                getUsefulLinkList: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/drm/get-useful-link/`, payload).then((response) => {
                        usefulLinkList = response.data
                    }, (errorParams) => {
                        console.log('Failed to load Documents', errorParams)
                    })
                },

                archiveUsefulLink: (IdList) => {
                    var patchList = []
                    for (var i = 0; i < IdList.length; i++) {
                        patchList.push({ ulm_id: IdList[i]})
                    }
                    return $http.post(`${__env.apiUrl}/api/drm/archive-useful-link/`, patchList).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to archive document', errorParams)
                        if(errorParams.status === 403 && errorParams.data.detail)
                            toastr.error(errorParams.data.detail)
                    })                    
                },
                acknowledgeUsefulLink: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/drm/acknowledge-useful-link/`, payload).then((response) => {
                        return response
                    }, (errorParams) => {
                        console.log('Failed to acknowledge document', errorParams)
                    })                    
                },

                addExternalReviewer: (payload) => {
                    return $http.post(`${__env.apiUrl}/api/drm/review-external/`, payload).then((response) => {
                        return response.data
                    }, (errorParams) => {
                        console.log('Failed to create External reviewer', errorParams)
                    })
                },

                getDocumentNameList: () => {
                    return $http.get(`${__env.apiUrl}/api/drm/get-document-names/`).then((response) => {
                        documentNamesList = response.data
                    }, (errorParams) => {
                        console.log('Failed to load Document Names', errorParams)
                    })
                },

                // Returns list 
                readDocumentsList: () => {
                    return documentList
                },

                readUsefulLinksList: () => {
                    return usefulLinkList
                },

                readDocumentNamesList: () => {
                    return documentNamesList
                }
            }
        }
    ])