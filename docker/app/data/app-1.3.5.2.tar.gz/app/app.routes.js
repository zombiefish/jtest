﻿// Application routes will start with /a/ so server can catch and redirect to index properly when user deep links.
angular
    .module('safeToDo')
    .config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
        $routeProvider
          .when('/a/home', {
            templateUrl: '/app/home/home.html'
          })
          .when('/login', {
            templateUrl: 'phpinfo.php'
          })
          .when('/a/toolbox', {
            templateUrl: '/app/toolbox/toolbox.html'
          })
          .when('/a/toolboxlineup', {
            templateUrl: '/app/toolbox/toolboxlineup.html'
          })
          .when('/a/profile', {
                templateUrl: '/app/profile/profile.html'
          })
          .when('/a/positive-id', {
            templateUrl: '/app/positive-id/positive-id.html'
          })
          .when('/a/sites', {
            templateUrl: '/app/sites/sites.html'
          })
          .when('/a/haps', {
            templateUrl: 'app/haps/haps.html'
          })
          .when('/a/gaps', {
            templateUrl: 'app/gaps/gaps.html'
          })
          .when('/a/recognition', {
            templateUrl: 'app/recognition/recognition.html'
          })
          .when('/a/forms/:formDescriptionId', {
            templateUrl: 'app/forms/forms.html'
          })
          .when('/a/reports', {
            templateUrl: 'app/reports/reports.html',
            permission: 'Can View Reports'
          })
          .when('/a/action-management', {
            templateUrl: 'app/action-management/actionManagement.html',
          })
          .when('/a/document-review', {
            templateUrl: 'app/document-review/documentReview.html',
            permission: 'Can View Documents'
          })
          .when('/a/lessons-learned', {
            templateUrl: 'app/lessons-learned/lessonsLearned.html',
            permission: 'Can View Lessons Learned'
          })
          .when('/a/decision-log', {
            templateUrl: 'app/decision-log/decisionLog.html',
            permission: 'Can View Decision Log'
          })
          .when('/a/tir', {
            templateUrl: 'app/tir/tir.html',
            permission: 'Can View Incidents'
          })
          .when('/a/pentaho', {
            templateUrl: 'app/pentaho/pentaho.html'
          })
          .when('/a/lineup', {
            templateUrl: 'app/lineup/lineup.html',
            permission: 'Can View Lineup'
          })
          .when('/admin/user', {
            templateUrl: 'app/admin/users/adminUser.html',
            permission: 'Can View Users'
          })
          .when('/admin/list', {
            templateUrl: 'app/admin/lists/adminList.html',
            permission: 'Access Administration'
          })
          .when('/admin/role', {
            templateUrl: 'app/admin/roles/adminRole.html',
            permission: 'Can View Access'
          })       
          .when('/admin/target', {
            templateUrl: 'app/admin/targets/adminTarget.html',
            permission: 'Access Administration'
          })    
          .when('/admin/training', {
            templateUrl: 'app/admin/training/adminTraining.html',
            permission: 'Can View Training Records'
          })                      
          .when('/admin/equipment', {
            templateUrl: 'app/admin/equipment/equipment.html',
            permission: 'Can Manage Equipment Preops'
          })
          .when('/admin/form-builder', {
            templateUrl: 'app/admin/formBuilder/formBuilder.html',
            permission: 'Can View Custom Forms'
          })
          .when('/admin/i18n', {
            templateUrl: 'app/admin/internationalization/i18n.html',
            permission: 'Access Administration'
          })
          .when('/admin/trifr', {
            templateUrl: 'app/admin/trifr/adminTrifr.html',
            permission: 'Access Administration'
          })
          .when('/a/loto', {
            templateUrl: 'app/loto/lockout-tagout.html',
            permission: 'Can View LOTO'
          })
          // Risk Management
          .when('/ra/jra', {
            templateUrl: 'app/risk-management/jra/jra.html',
            permission: 'Can View JRA'
          })
          .when('/ra/pra', {
            templateUrl: 'app/risk-management/pra/pra.html',
            permission: 'Can View PRA'
          })
          .when('/ra/ora', {
            templateUrl: 'app/risk-management/ora/ora.html',
            permission: 'Can View ORA'
          })
          .when('/ra/bowtie', {
            templateUrl: 'app/risk-management/bowtie/bowtie.html',
            permission: 'Can View Bowtie'
          })
          .when('/ra/bowtieprint', {
            templateUrl: 'app/risk-management/bowtie/bowtiePrint.html'
          })
          // Analytics
          .when('/analytics/adoption', {
            templateUrl: 'app/analytics/adoptionTracking/adoption.html'
          })
          .when('/analytics/hr', {
            templateUrl: 'app/analytics/humanResource/hr.html',
            permission: 'Can View Analytics Human Resources'
          })
          .when('/analytics/incidents', {
            templateUrl: 'app/analytics/incidents/incidents.html',
            permission: 'Can View Analytics Incidents'
          })
          .when('/html-reports', {
            templateUrl: 'app/html-reports/print.html'
          })
          .when('/silent-check-sso', {
            templateUrl: '/silent-check-sso.html'
          })
          .otherwise({
            template: '<div></div>',
            controller: function () {
              window.location.assign('/a/home');
            }
            //template: '<div>Not ready yet.</div>'
            });

        //No round trips when links clicked.
        $locationProvider.html5Mode(true);
    }]);