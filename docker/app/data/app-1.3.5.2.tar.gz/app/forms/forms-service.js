﻿angular
    .module('safeToDo')
    .service('formsService', ['$http',
      function ($http) {
        let formSubmissions = [];
        let disciplines = [];
        var forms = {
            O: {},
            OR: {}, //reverse name:ID lookup
            A: []
        };
        let submissionIds = {}
          
        function formatForms(data)  {
          let output = []
          let old = ''
          let a = 0
            data.forEach((record, index)=>{
              if(record.SectionName !== old) {
                output.push({
                  "SectionName" : record.SectionName,
                  "SectionOrder" : a,
                  "Fields" : [{
                      "ID": record.ID,
                      "Order": record.FieldOrder,
                      "Name": record.fieldKey,
                      "Display":record.fieldName ,
                      "Visible" : true,
                      "FieldType": record.fieldType,
                      "Width": null
                  }]
                })
                if(old !== '')
                  a++;
                }
              else {
                output[a].Fields.push( 
                  {
                    "ID": record.ID,
                    "Order": record.FieldOrder,
                    "Name": record.fieldKey,
                    "Display":record.fieldName ,
                    "Visible" : true,
                    "FieldType": record.fieldType,
                    "Width": null
                })
              }
              old = record.SectionName
              })
              return(output)
        }

        var formsPromise = $http.get(`${__env.apiUrl}/api/form/get-all-top-forms/active/`)          
            .then((response) => {
                for (var i = 0; i < response.data.length; i++) {
                  if(response.data[i].FormType == 'Predefined'){
                    forms.O[response.data[i].FormID] = response.data[i]
                    forms.OR[response.data[i].FormName] = response.data[i].FormID
                    forms.A.push(response.data[i])
                  }
                }
              }, (args) => {
                console.log('Failed to load top form definitions.')
                console.log(args)
            });
        return {
          
        getFormSubmissions: (payload) => {
              return $http.post(`${__env.apiUrl}/api/form/get-submissions-by-userid-frmdescid/`,payload)
                .then((response) => {
                    //Check for error
                    if (response.data.accessMsg){
                      toastr.error(response.data.accessMsg)
                      return []
                    }
                          let firstRow = response.data[0]
                          if (firstRow && firstRow['error']) {
                              toastr.error(firstRow['error'])
                              return []
                        }
                        formSubmissions = response.data
                        return response.data
                      }, (errorParams) => {
                          console.log('Failed to load Form Submissions', errorParams)
                })
        },
        getSubmissionsPreop: (payload) => {
          return $http.post(`${__env.apiUrl}/api/form/get-submissions-by-userid-frmdescid-preop/`, payload)
            .then((response) => {
              return response.data
            }, (errorParams) => {
              console.log('Failed to load Form Preop Submissions', errorParams)
            })
        },

        getIncidentCountByHeaderId: (payload) => {
          return $http.post(`${__env.apiUrl}/api/incident-management/get-incidents-count-by-headerid/`, payload)
            .then((response) => {
              submissionIds = response.data
            }, (errorParams) => {
              console.log('Failed to get the getIncidentCountByHeaderId', errorParams)
            })
        },

        getSubmissionsCustomForms: (payload) => {
          return $http.post(`${__env.apiUrl}/api/form-builder/get-form-builder-submission-by-date/`, payload)
            .then((response) => {
              return response.data
            }, (errorParams) => {
              console.log('Failed to load custom form Submissions', errorParams)
              return []
            })
        },

        createFormSubmission: (payload) => {
          return $http.post(`${__env.apiUrl}/api/wafs/form-submission-engine/`, payload).then((response) => {
              return response.data
          }, (errorParams) => {
              console.log('Failed to create preliminary incident', errorParams)
          })
        },

        updateFormSubmission: (payload) => {
            return $http.post(`${__env.apiUrl}/api/wafs/update-form-submission-engine/`, payload).then((response) => {
                return response.data
            }, (errorParams) => {
                console.log('Failed to update preliminary incident', errorParams)
            })
        },

        addFormSubmissionAttachments: (payload) => {
            return $http.post(`${__env.apiUrl}/api/wafs/add-form-submission-attachments/`, payload,{
                // this cancels AngularJS normal serialization of request
                transformRequest: angular.identity,
                // this lets browser set `Content-Type: multipart/form-data` 
                // header and proper data boundary
                headers: {'Content-Type': undefined}}).then((response) =>{
                return response.data
            }, (errorParams) => {
                console.log('Failed to add preliminary incident attachments', errorParams)
            })
        },

        removeFormSubmissionAttachments: (payload) => {
            return $http.post(`${__env.apiUrl}/api/wafs/remove-form-submission-attachment/`, payload).then((response) => {
                return response.data
            }, (errorParams) => {
                console.log('Failed to remove attachments', errorParams)
            })
        },
        
        // If an incident is created from Incident page, the newly created submission should be assigned to the incident
        assignSubmissionToIncidentDuringFormCreation: (payload) => {
            return $http.post(`${__env.apiUrl}/api/wafs/assign-submission-to-incident-during-form-creation/`, payload).then((response) => {
                return response
            }, (errorParams) => {
                console.log('Failed to assign submission to incident during form creation', errorParams)
            })
        },

        readFormSubmissions: () => {
          return formSubmissions
        },

        getFormFieldDescriptions: (formDescriptionId) => {
          return $http.post(`${__env.apiUrl}/api/form/get-form-fields-by-id/`, {"id" : formDescriptionId})
            .then((response) => {
              formatForms(response.data) 
              return formatForms(response.data) 
              }, (errorParams) => {
                  console.log('Failed to load Form Field Descriptions',errorParams)
              });
        },

        getFormDescription: (formDescriptionId) => {
          return $http.post(`${__env.apiUrl}/api/form/get-form-description-by-id/`, { "id" : formDescriptionId }) 
              .then((response) => {
            return response.data
              }, (errorParams) => {
                console.log('Failed to load Form Description')
                console.log(errorParams)
            })
        },

        getCustomFormData: (fob_id) => {
          return $http.post(`${__env.apiUrl}/api/form/get-custom-form-name/`, { "fob_id" : fob_id }) 
              .then((response) => {
            return response.data
              }, (errorParams) => {
                console.log('Failed to load custom Form data')
                console.log(errorParams)
            })
        },
          
        getHapsFromFormID: (payload) => {
          return $http.post(`${__env.apiUrl}/api/form/get-haps-by-frmdescid-preop/`,payload) 
              .then((response) => {
            return response.data
              }, (errorParams) => {
                console.log('Failed to data')
                console.log(errorParams)
            })
        },

        getFormDataBySHID: (sh_id) => {
          return $http.get(`${__env.apiUrl}/api/wafs/get-form-data/${sh_id}/`) 
              .then((response) => {
            return response.data
              }, (errorParams) => {
                console.log(errorParams)
            })
        },

        getFormFieldFilter: (payload) => {
          return $http.post(`${__env.apiUrl}/api/form-management/get-form-field-filter/`, payload).then((response) => {
            return response.data
          }, (errorParams) => {
            console.log(errorParams)
          })
        },
          
        getTopFormDescriptionsP: () => {
          return formsPromise
        },

        getTopFormDescriptions: () => {
            return forms
        },

        getIncidentValidateByIds: () => {
          return submissionIds
        },
        archiveFormSubmissionsP: (submissionIdList) => {
          var patchList = []
          for (var i = 0; i < submissionIdList.length; i++) {
            patchList.push({ ID: submissionIdList[i], IsArchived: true })
          }
          return $http.post(`${__env.apiUrl}/api/submission/update-submission-archive/`, patchList).then(() => {
            return true
          }, (errorParams) => {
            console.log('Failed to delete attachment', errorParams)
            if(errorParams.status === 403 && errorParams.data.detail)
                    toastr.error(errorParams.data.detail)
            return false
          })
        },

        removeHiddenFormFields: (form, formFieldVisibilityList) => {

          let formHTML = document.getElementById(form)
          
          for (let f = 0; f < formFieldVisibilityList.length; f++) {
            let field = document.getElementById(formFieldVisibilityList[f].fieldKey)

            if(field) {
              let parent = field.parentElement.parentElement

              if(field.getAttribute("type") == "radio")
                parent = parent.parentElement

              if(!formFieldVisibilityList[f].ffv_is_visible){
                parent.remove()
              }
            }
          }

          let sectionTitles = []
          if(formHTML) {
            sectionTitles = formHTML.getElementsByClassName("section-title")
          }


          for (let s = 0; s < sectionTitles.length; s++) {

            // Get next previous sibling element that is not hidden
            let nextElementSibling = sectionTitles[s].nextElementSibling
            while(nextElementSibling && (nextElementSibling.classList.contains("ng-hide") || nextElementSibling.classList.contains("row"))) {
              nextElementSibling = nextElementSibling.nextElementSibling
            }

            if(!nextElementSibling || nextElementSibling.classList.contains("section-title")) {
              sectionTitles[s].remove()
            }
          }
        },

        removePayloadHiddenFormFields: (payload, formFieldVisibilityList) => {
       
          for (let f = 0; f < formFieldVisibilityList.length; f++) {
            if(!formFieldVisibilityList[f].ffv_is_visible) {
              delete payload[formFieldVisibilityList[f].fieldKey]
            }
          }

          return payload
        },
        // SOF-13562 - Updating Incidents table when an incident is modified by adding or editing a form
        updateIncidentAssociated: (incident_id) => {
          let payload = {incident_id: incident_id}
          return $http.put(`${__env.apiUrl}/api/incident-management/update-incident/`, payload) 
              .then((response) => {
            return response.data
              }, (errorParams) => {
                console.log(errorParams)
            })
        }

      };
      
      }
    ]);