﻿angular
    .module('safeToDo')
    .controller('FormsCtrl', ['$controller', '$compile','$sce', '$scope', '$rootScope', '$routeParams', '$window', '$timeout', '$q', 'formsService', 'signoffService', 'gridService', 'select2Service', 'modalService', 'employeesService', 'profileService', 'menuService', 'equipmentService','exportCSV','lockoutTagoutService',
    function ($controller, $compile, $sce, $scope, $rootScope, $routeParams, $window, $timeout, $q, formsService, signoffService, gridService, select2Service, modalService, employeesService, profileService, menuService, equipmentService, exportCSV, lockoutTagoutService) {
        var vm = this
        

        $controller('distributionGroupCtrl', {$scope: $scope})
        vm.selectedSubmissionID = []
        vm.canArchiveSubmissions = false
        vm.topSearch = ""
        vm.reportURL = null
        vm.appEditable = null
        vm.appAvailable = null
        vm.mobileDisabled = true
        vm.employees = []
        vm.loadMessage = translateTag(8616)  //"Loading form data. Please wait."
        if (!!$routeParams.submissionId) {
            vm.topSearch = '?submissionId=' + $routeParams.submissionId
        }


        $rootScope.$on("MOBILE-LOADED", (event,result) => {
            vm.mobileDisabled = false
            $scope.$digest()
        })

        let formDescriptionId = $routeParams.formDescriptionId
        vm.reportInputs = ""
        vm.canExportCSV = true
        vm.canExportXLS = true
        vm.sfilter = []
        vm.hazardSubmissions = []
        let submissionId = $routeParams.submissionId;

        if (formDescriptionId === '1137') {
            vm.canExportCSV = false
            vm.canExportXLS = false
        }

        vm.gridSections = []
        vm.attachmentModalFiles = []

        vm.options = gridService.getCommonOptions()
        vm.options.groupSuppressBlankHeader = true
        vm.options.groupSuppressAutoColumn = true
        vm.isLinkedFormsAvailable = false
        vm.submissionIdsForArchive = []

        //
        // vm.Report_Distribution1 = []
        vm.groupsSelected = []
        vm.openForm = () =>{
            if(vm.activeFormID=="372328"){     //employee departure form open app modal
                vm.openModal()
            }
            else{
                let message={activeFormID:null,incidentId:null,moduleId:null}                    
                message.activeFormID=vm.activeFormID
                $rootScope.$broadcast("OPENMOBILEFRAME", message)
            }
        }

        vm.options.isExternalFilterPresent = () => {
            vm.sfilter = vm.topSearch.split(' ')
            return vm.sfilter !== ""
        }


        $scope.$on('DATERANGE', (range) => {
               vm.mainDateFilter = {
                   start_date: moment(range.targetScope.vm.range.start,'YYYY-MM-DD').format('YYYY-MM-DD 00:00:00.000'),
                   end_date: moment(range.targetScope.vm.range.end,'YYYY-MM-DD').format('YYYY-MM-DD 23:59:59.999')
               }
               refreshForms()
        })

        // profileService.getFullEmployeeProfile().then((response) => {
        //     vm.employees = profileService.readFullEmployeeProfile()
        // })
        function getEmployeeName(value) {
            let name = value 
            vm.employees.forEach((emp)=>{
                if(emp.per_id == name) {
                    name = emp.per_full_name
                }
            })
            return name
        }

        vm.options.doesExternalFilterPass = (gridRow) => {
            let pass = false
            if (vm.topSearch.indexOf('?') === 0) {
                var submissionId = vm.topSearch.replace('?submissionId=', '')
            if (gridRow.data['ID'] == submissionId) {
                    return true
            }
                return false
            } else {
                if (vm.sfilter[0] === '')
                    pass = true
            
                let searchArray = []
                for (var property in gridRow.data) {
                    if (gridRow.data.hasOwnProperty(property)) {
                            //any property in the row matches search box
                        vm.sfilter.forEach((data) => {
                            if ((gridRow.data[property] + "").toLowerCase().indexOf(data.toLowerCase()) > -1) {
                                searchArray[data] = 1
                            }
                        })
                    }
                }
                let a = 0
                for (data in searchArray) 
                    a++

                if (a === vm.sfilter.length)
                    pass = true
            
                return pass
            }
        }

        vm.options.dateComponent = JUIDateComponent

        vm.exportDisabled = true
        //Function to disable action button
        vm.options.onSelectionChanged = (params) => {
            var selectedRows = vm.options.api.getSelectedRows()

            vm.exportDisabled = selectedRows.length === 0
            
            var urlParams = ""
            for (var i = 0; i < selectedRows.length; i++) {
                urlParams += "&ids=" + selectedRows[i].ID
                vm.parentHeaderId = selectedRows[i].ID
            }
            vm.reportInputs = urlParams
            $scope.$apply()
        }

        //Function to update grid when search is changed
        vm.topSearchChanged = () =>{
            vm.options.api.onFilterChanged();
        }

        function getFormModalId(activeFormID){
            let formModalId = null
            switch(activeFormID) {
                case 372298: formModalId = 'generalActionModal'
                    break
                case 131042: formModalId = 'hazardActionModal'
                    break
                case 166071: formModalId = 'positiveRecognitionModal'
                    break
                default: formModalId = `form-${vm.activeFormID}`
                    break
            }
            return formModalId
        }

        //Function to open modals
        vm.openModal = () => {
            if ($scope.$$phase !== '$apply' && $scope.$$phase !== '$digest')
                $scope.$apply();
            formModalId = getFormModalId(vm.activeFormID)
            $('.modal .scroll').scrollTop(0);
            modalService.Open(formModalId);
            vm.initializeSelect2(formModalId)
        }
        
        //Function to close modals
        vm.closeModal = (id) => {
            modalService.Close(id)
        }

        vm.options.defaultColDef = {
            filter: 'agSetColumnFilter',
            menuTabs: ['filterMenuTab'],
            headerCheckboxSelection: (params) => {
                var displayedColumns = params.columnApi.getAllDisplayedColumns()
                var thisIsFirstColumn = displayedColumns[0] === params.column
                return thisIsFirstColumn
            },
            checkboxSelection: (params) => {
                var displayedColumns = params.columnApi.getAllDisplayedColumns()
                var thisIsFirstColumn = displayedColumns[0] === params.column
                return thisIsFirstColumn
            }
        }

        // Edit Form 
        vm.editForm = (sh_id) => {
            if(vm.canManageAllIncidentSubmissions){
                vm.sh_id = sh_id
                formModalId = getFormModalId(vm.activeFormID)
                $scope.$broadcast(`EDITFORMBYSHID-${formModalId}`, vm.sh_id)
            }    
        }

        $scope.$on("FORMSINITIALIZESELECT2", (event,formModalId) => {
            vm.initializeSelect2(formModalId)
        })

        //Get permissions for the user
        menuService.getPagePermissions().then((data) => {
            vm.permissions = data
            vm.canArchiveSubmissions = vm.permissions.includes('Archive Submissions') ? true : false
            vm.canManageAllIncidentSubmissions = vm.permissions.includes('Can Manage All Incident Submissions') ? true : false                
        })

        vm.checkPermissionsForCreateFormSubmission = () => {
            let manageIncidentSubmissionForms = [1338,1329]
            vm.canCreateFormSubmission = false          

            // SOF-12360 - App - Iframe - Show create button when user has permission to create form on mobile
            if(vm.activeFormID!="777777"){    //custom form hide create button
                menuService.getCreateMobileFormsPermission().then((permissions) => {
                    if(permissions.data.find((list) => list.FormID==vm.activeFormID)){
                        vm.canCreateFormSubmission = true  
                    }
                })
            }

            // Check for Employee Departure and Employee Performance for form creation
            if(vm.appAvailable && (vm.activeFormID == "372328" || vm.activeFormID == "372318")){
                vm.canCreateFormSubmission = true
            }
        }      
       

        //Set Ag-Grid column settings for hazards
        let formColumns = [
            {
                headerName: '',
                field: 'dummyCheckbox',
                maxWidth: 50,
                minWidth: 50,
                checkboxSelection: true,
                suppressMenu: true,
                suppressSorting: true,
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
            },
            {
                field: "review",
                headerName: " ",
                minWidth: 125,
                maxWidth: 125,
                suppressSizeToFit: true,
                cellRenderer: function (params) {
                    return `<span class="fa-1x fa-stack mr-3 pr-2" style="width: 1.25em;" ng-if="forms.appEditable" ng-class="{ transparent: ${!vm.canManageAllIncidentSubmissions}, pointer: ${vm.canManageAllIncidentSubmissions}, invisible: ${params.data.IncidentSignedOffStatus===1}}" ng-click="forms.editForm(${params.data.ID})"><i class="fas fa-pen fa-stack-1x text-primary" note="Edit" title="{{menu.translateLabels(1194)}}"></i></span>`                        
                    + `<span ng-click="forms.signoff(data)" class="{{ data.MySignoffID > 0 ? 'text-success ' : 'pointer'}}" title="{{menu.translateLabels(3431)}}" note="Review Submission"><i class="far fa-file-alt fa-lg"></i></span>`
                    + '<span note="Submission Review History" title="{{menu.translateLabels(3430)}}" class="source signoff-count" ng-class="{ transparent: !data.signoffCount, pointer: !!data.signoffCount }" ng-click="forms.viewSignoffHistory(data);">{{ data.signoffCount }}</span>'
                    + `<span class="pointer text-left" ng-click="forms.viewReports($event,${params.data.ID})"><i class="fa fa-external-link-alt" note="Launch Report" title="{{menu.translateLabels(3429)}}"></i></span>`;
                }, filter: 'agSetColumnFilter', menuTabs: ['filterMenuTab'],
                valueGetter: function (params) {
                    return params.data.signoffCount
                },
            },
            {
                field: "ID",
                headerName: " ",
                minWidth: 40,
                maxWidth: 40,
                hide: true,
                sort: 'desc'
            },
            {
                field: "category_name",
                headerName: " ",
                hide: true,
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "custom_form_name",
                headerName: " ",
                hide: true,
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },

            {
                field: "FormSubmissionDate",
                headerName: " ",
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "SubmittedBy",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "HeaderDate",
                headerName: " ",
                minWidth: 120,
                maxWidth: 120,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field:"Agenda",
                headerName:" ",
                minWidth: 120,
                maxWidth: 120,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',

            },
            {
                field: "Departure Date",
                headerName: " ",
                hide: true,
                minWidth: 120,
                maxWidth: 120,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "equipment_identifier",
                headerName: " ",
                hide: true,
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },           
            {
                field: "signature_supervisor",
                headerName: " ",
                hide: true,
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                valueGetter: function(params) {
                    if(params.data.signature_supervisor === null || params.data.signature_supervisor === ""){
                        return translateTag(1380) //No
                    } else {
                        return translateTag(1379) //Yes
                    }
                },
            },
            {
                headerName: "Hazard Action",
                field : " ",
                hide: true,
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: function(params){ 
                    if(getHazard(params.data.ID)>0) {
                        return translateTag(1379) //Yes
                    } else {
                        return translateTag(1380) //No
                    }
                },
                filterValueGetter: function (params) {
                    if(getHazard(params.data.ID)>0){
                        return translateTag(1379) //Yes
                    } else {
                        return translateTag(1380) //No
                    }
                }     
            },
            {
              
                headerName:" ",
                field: "Employee Name",
                minWidth: 150,
                maxWidth: 250,
                cellRenderer: 'tippyCellRenderer',
                
            },
            {
              
                headerName:" ",
                field: "Employee",
                minWidth: 150,
                maxWidth: 250,
                cellRenderer: 'tippyCellRenderer',
                
            },
            {
                field: "Event Type",
                headerName: "Discipline Type",
                minWidth: 150,
                maxWidth: 200,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Site",
                headerName: " ",
                minWidth: 200,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "JobNumber",
                headerName: " ",
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "SiteLevel",
                headerName: " ",
                minWidth: 150,
                maxWidth: 150,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Workplace",
                headerName: " ",
                minWidth: 150,                
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Inspection Type",
                headerName: " ",
                minWidth: 150,                
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "HeaderSupervisor",
                headerName: " ",
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },  
            {
                field: "equipment_name",
                headerName: " ",
                hide: true,
                minWidth: 150,                
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "equipment_comments",
                headerName: " ",
                hide:true,
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "Reason For Departure",
                headerName: " ",
                hide:true,
                minWidth: 150,
                maxWidth: 250,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {
                field: "end_of_shift_review_time_stamp",
                headerName: " ",
                hide:true,
                minWidth: 200,
                maxWidth: 300,
                filter: 'agSetColumnFilter',
                menuTabs: ['filterMenuTab'],
                cellRenderer: 'tippyCellRenderer',
            },
            {field: "IncidentSignedOffStatus",hide:true},
        ]

        vm.options.columnDefs = formColumns
  
        //Function to prep export
        vm.prepExport = () => {
            var exportFields = []
            for (var i = 0; i < vm.sections.length; i++) {
                for (let b = 0; b < vm.sections[i].Fields.length; b++) {
                    exportFields.push(vm.sections[i].Fields[b].Name)
                }
            }
            return {
                onlySelected: true,
                columnKeys: exportFields,
                processCellCallback: (params) => {
                    if (!!params.column.colDef.isAttachment) {
                    // return params.value.length;
                    }
                    return params.value
                }
            }
        }

        //Function to export csv
        vm.exportCSV = () => {
            let rows = JSON.parse(JSON.stringify(vm.options.api.getSelectedRows()))
            exportCSV.export_csv(rows, vm.activeFormName)
        }

        //Function to export xls
        vm.exportXLS = () => {
            var exportOptions = vm.prepExport()
            vm.options.api.exportDataAsExcel(exportOptions)
        }

        //Function to open archive submission modal
        vm.archiveSubmissions = () => {
            var rs = vm.options.api.getSelectedRows()
            if (rs.length > 0) {
                if(formDescriptionId == 1331 || formDescriptionId == 1338 || formDescriptionId == 1329){
                    var rs = vm.options.api.getSelectedRows()
                    var ids = []
                    for (var i = 0; i < rs.length; i++) {
                        ids.push(rs[i].ID)
                    }
                    $q.all([formsService.getIncidentCountByHeaderId(ids)]).then(() => {
                        subIncidentIds = formsService.getIncidentValidateByIds()
                        if(subIncidentIds.not_archive_ids.length > 0)
                            vm.isLinkedFormsAvailable = true
                        else
                            vm.isLinkedFormsAvailable = false
                        
                        if(subIncidentIds.archive_ids)
                            vm.submissionIdsForArchive = subIncidentIds.archive_ids

                        // if there is linked to the incident and there is only one
                        if(vm.isLinkedFormsAvailable){
                            vm.modalIncidentLinkedWarning = {
                                title: translateTag(2182), // "Warning"
                                message: `<div><p>${translateTag(9403)}</p></div>`, //One or more of the forms you are trying to archive are mapped to an incident. The incident must contain at least one submission and therefore the form or forms cannot be archived.
                                buttons: 
                                    `<button class="btn btn-primary btn-rounded m-0 mr-3" ng-click="vm.return('button1')" note="Ok" >{{vm.componentTranslateLabels(1405)}}</button>`
                            }
                            document.getElementById('confirmcallingform').innerHTML = 'INCIDENTWARNINGMODAL' 
                            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalIncidentLinkedWarning)
                        }
                        else{
                            vm.subArchiveCount = rs.length
                            vm.modalElementsArchive = {
                                title: translateTag(8285), //"Archive Submissions?"
                                message: `<div><p>${translateTag(3580)} ${vm.subArchiveCount} ${translateTag(8286)}</p></div>`, //"You are about to archive X submissions. These submissions may have associated actions and positive recognition entries. Undoing this will require IT support. Are you sure?"
                                buttons: 
                                    `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Archive Submissions">{{vm.componentTranslateLabels(8378)}}</button>` 
                            }
                            document.getElementById('confirmcallingform').innerHTML = 'FORMARCHIVECALLCONFIRMMODAL' 
                            $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsArchive)
                        }                        
                    })

                } else if (formDescriptionId == 1416){
                    //archiving a LOTO.
                    vm.subArchiveCount = rs.length
                    vm.modalElementsArchive = {
                        title: translateTag(8285), //"Archive Submissions?"
                        message: `<div><p>${translateTag(3580)} ${vm.subArchiveCount} ${translateTag(8286)}</p></div>`, //"You are about to archive X submissions. These submissions may have associated actions and positive recognition entries. Undoing this will require IT support. Are you sure?"
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button3')" note="Archive Submissions">{{vm.componentTranslateLabels(8378)}}</button>` 
                    }
                    document.getElementById('confirmcallingform').innerHTML = 'FORMARCHIVECALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsArchive)

                } else {
                    vm.subArchiveCount = rs.length
                    vm.modalElementsArchive = {
                        title: translateTag(8285), //"Archive Submissions?"
                        message: `<div><p>${translateTag(3580)} ${vm.subArchiveCount} ${translateTag(8286)}</p></div>`, //"You are about to archive X submissions. These submissions may have associated actions and positive recognition entries. Undoing this will require IT support. Are you sure?"
                        buttons: 
                            `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="Archive Submissions">{{vm.componentTranslateLabels(8378)}}</button>` 
                    }
                    document.getElementById('confirmcallingform').innerHTML = 'FORMARCHIVECALLCONFIRMMODAL' 
                    $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsArchive)

                }
            }
        }

        $scope.$on("FORMARCHIVECALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.confirmArchiveSubmissions()
            } else if(result == 'button3'){
                vm.confirmArchiveSubmissions()
                vm.archiveLOTOSubmissions()
            }
        })

        $scope.$on("INCIDENTWARNINGMODAL", (event,result) => {
            if (result==='button1') {
                vm.archiveIncidentSubmissions()
            }
        })

        vm.archiveLOTOSubmissions = () => {

            lockoutTagoutService.archiveSubmittedLOTOProcedure(vm.selectedSubmissionID)//.then(result => {

            
        }


        //Function to archive a submission
        vm.confirmArchiveSubmissions = () => {
            var rs = vm.options.api.getSelectedRows()
            var ids = []
            for (var i = 0; i < rs.length; i++) {
                ids.push(rs[i].ID)
            }
            vm.selectedSubmissionID = ids
            formsService.archiveFormSubmissionsP(ids).then((r) => {
                if (r === true) {
                    modalService.Close('confirmModal')
                    var trans = {
                        remove: rs
                    }
                    vm.options.api.updateRowData(trans)
                }
            })           
        }

        /** 
         * Method name : archiveIncidentSubmissions
         * Parameter   : 
         * Description : Function to archive the submission ids from incidents
         * Ticket No.  : SOF-12477
        */
        vm.archiveIncidentSubmissions = () => {
            if(vm.submissionIdsForArchive.length > 0){
                formsService.archiveFormSubmissionsP(vm.submissionIdsForArchive).then((r) => {
                    if (r === true) {
                        modalService.Close('confirmModal')
                        refreshForms()
                    }
                })
            }
            else
                modalService.Close('confirmModal')
        }
          
        

        // http://devcore-reports.sofvie.com:8000/positive_recognition/73893?lang=1
        //Function to launch report
        vm.viewReports = (e,id=null) =>{            
            if(!e.ctrlKey){
                lang_number = localStorage.getItem('lang_id')
                if(id == null)
                {
                    let rows = vm.options.api.getSelectedRows() 
                    rows.forEach(emp => {            
                    vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.singleServeReportUrl}/${emp.ID}?lang=${lang_number}`)
                    $window.open(vm.reportURL, "_blank")
                    })
                }
                else{
                    vm.reportURL =  $sce.trustAsResourceUrl(`${__env.pentahoUrl}/${vm.singleServeReportUrl}/${id}?lang=${lang_number}`)
                    $window.open(vm.reportURL, "_blank")
                }

            }
        } 

        vm.headerDataContext = null

        //Function to open review confirmation modal
        vm.signoff = (headerData) => {
            vm.headerDataContext = headerData
            if (headerData.MySignoffID > 0) {
                toastr.success(translateTag(2834)) //("You have already Acknowledged this submission")
            } 
            else {
                vm.modalElementsSignoff = {
                    title: translateTag(2171), //"Submission Review?"
                    message: `<div><p>${translateTag(2172)}</p></div>`, //"You are now confirming that you have reviewed this submission. This action cannot be undone. Continue?"
                    buttons: 
                        `<button class="btn btn-primary btn-rounded m-0" ng-click="vm.return('button1')" note="OK">{{vm.componentTranslateLabels(1405)}}</button>
                        <button class="btn btn-outline-primary btn-rounded m-0 mr-3" ng-click="vm.closeModal()" note="Cancel">{{vm.componentTranslateLabels(1257)}}</button>` 
                }
                document.getElementById('confirmcallingform').innerHTML = 'FORMSIGNOFFCALLCONFIRMMODAL' 
                $rootScope.$broadcast("CALLCONFIRMMODAL",vm.modalElementsSignoff)
            }
        }

        $scope.$on("FORMSIGNOFFCALLCONFIRMMODAL", (event,result) => {
            if (result=='button1') {
                vm.confirmSignoff(vm.headerDataContext)
            }
        })

        //Function to add review
        vm.confirmSignoff = (headerData) => {
            signoffService.addSignoff(headerData.ID)
            .then((newSignoffId) => {
                if (newSignoffId.Payload != null) {
                    headerData.MySignoffID = newSignoffId.Payload
                    headerData.signoffCount = headerData.signoffCount + 1
                }
                modalService.Close('confirmModal')
            })
                 
        }

        //Function to open view review history modal
        vm.viewSignoffHistory = (rowData) => {
            if (!rowData.signoffCount) {
                return
            }
            vm.currentSignoffHistory = []
            signoffService.getSignoffsByHeader(rowData.ID).then((data) => {
                data.map((rec)=>{
                    rec.name = rec.SigningName
                    rec.reviewed_date=rec.SigningTimestamp
                    rec.pos=rec.sus_position
                    delete rec.SigningName
                    delete rec.SigningTimestamp
                    delete rec.sus_position
                  })
                vm.currentSignoffHistory = data
                $rootScope.$broadcast("CALLHISTORYMODAL",vm.currentSignoffHistory,translateLabels(3733))  //"Submission Reviews"
            })
        }

        vm.back = ()=>{
            vm.reportURL = null
            refreshForms()
        }

        $(window).click((e) => {
            $('#myDropdown').removeClass('show')
        })

        $('.pointer').click(function (e){  
            if (e.ctrlKey) {
                return false;
            }
        });
        
        vm.exportPressed = () => {
            $('#myDropdown').addClass('show')
        }

        //Function to get form name & report url
        if (!formDescriptionId.includes("custom-")){
            formsService.getFormDescription(formDescriptionId).then((formDescription) => {
                vm.activeFormName = formDescription[0].Form_Name.replace('Parent', "")
                vm.activeFormID = formDescription[0].FormID
                vm.appEditable  = formDescription[0].rpt_app_editable
                vm.appAvailable = formDescription[0].rpt_app_available
                formTag = `<form-${formDescription[0].FormID}></form-${formDescription[0].FormID}>`
                switch(formDescription[0].FormID) {
                    case 372298:  formTag = `<general-action-form></general-action-form>`
                        break
                    case 131042: formTag = `<hazard-action-form></hazard-action-form>`
                        break
                    case 166071: formTag = '<positive-recognition-form></positive-recognition-form>'
                        break                    
                    default: formTag = `<form-${formDescription[0].FormID} shId='forms.sh_id'></form-${formDescription[0].FormID}>`
                        break
                }
                vm.checkPermissionsForCreateFormSubmission()
                $("#form-placeholder").html($compile(formTag)($scope))                
                vm.singleServeReportUrl = formDescription[0].ReportURL
                vm.singleServeReportOutput = formDescription[0].rpt_output_type
                vm.reportId = formDescription.SingleReportID
            })
        }
        else{
            let fob_id = formDescriptionId.split('-')[1]
            formsService.getCustomFormData(fob_id).then((data) => {
                vm.activeFormName = data[0].active_form
            }) 
            vm.singleServeReportUrl = 'custom_form'
        }
        vm.currentUserName = null

        //Function to refresh data
        function refreshForms() {
            $scope.$emit('STARTSPINNER', vm.loadMessage)
            let nav_filters = localStorage.getItem("navToFormSubFilterHazards") ? JSON.parse(localStorage.getItem("navToFormSubFilterHazards")): null
            if(nav_filters){
                vm.mainDateFilter.start_date = nav_filters.start_date
                vm.mainDateFilter.end_date  = nav_filters.end_date
            }
            localStorage.removeItem("navToFormSubFilterHazards")
            if(formDescriptionId == 1389){
                payload = {
                    "form_id" : 372278,
                    "start_date" : vm.mainDateFilter.start_date,
                    "end_date" : vm.mainDateFilter.end_date
                }
                formsService.getHapsFromFormID(payload).then(response => {
                    vm.hazardSubmissions = response
                   
                });
                 
            }

            // considering if it is a custom form then pass 1403 as form description id
            formDescID = 0
            if(formDescriptionId.includes('custom-')){
                formDescID = 1403
            }
            else{
                formDescID = formDescriptionId
            }

            formsService.getFormFieldDescriptions(formDescID).then((sections) => {
                let model = {}
                vm.sections = sections
                payload = {
                    "frmdescid" : formDescriptionId,
                    "start_date" : vm.mainDateFilter.start_date,
                    "end_date" : vm.mainDateFilter.end_date
                }
                profileService.getFullEmployeeProfile().then((response) => {
                    vm.employees = profileService.readFullEmployeeProfile()
                
                    formsService.getFormSubmissions(payload).then((submissions) => {  
                        if(formDescriptionId == 1389) {  // preop
                            try{
                                formsService.getSubmissionsPreop(vm.mainDateFilter).then((preopSubmissions) => {
                                    preopData =  insertPreOPData(submissions, preopSubmissions)
                                    try{
                                        vm.options.columnApi.setColumnsVisible(['equipment_identifier', 'equipment_name', 'equipment_comments', 'hazard_action','signature_supervisor'], true)
                                        translateAgGridHeader(vm.options)
                                        model = vm.options.api.getFilterModel()
                                        vm.options.api.setRowData(fixTippy(preopData))
                                        vm.options.api.sizeColumnsToFit()
                                        vm.options.api.setFilterModel(model)
                                        $scope.$emit('STOPSPINNER')
                                    }
                                    catch(e) {$scope.$emit('STOPSPINNER')}
                                })
                            }
                            catch(e) {}
                            } 
                        else if (formDescriptionId == 1403){  // Custom Forms
                            try{
                                formsService.getSubmissionsCustomForms(vm.mainDateFilter).then((customFormSubmissions) => {
                                    customFormData =  insertCustomFormData(submissions,customFormSubmissions)
                                    try{
                                        vm.options.columnApi.setColumnsVisible(['category_name', 'custom_form_name'], true)
                                        translateAgGridHeader(vm.options)
                                        model = vm.options.api.getFilterModel()
                                        vm.options.api.setRowData(fixTippy(customFormData))
                                        vm.options.api.sizeColumnsToFit()
                                        vm.options.api.setFilterModel(model)
                                        $scope.$emit('STOPSPINNER')
                                    }
                                    catch(e) {$scope.$emit('STOPSPINNER')}
                                })
                            }
                            catch(e){}
                        }

                        else if (formDescriptionId == 1402){ // Employee Departure
                            try{
                                vm.options.columnApi.setColumnsVisible(['Departure Date'], true)
                                translateAgGridHeader(vm.options)
                                model = vm.options.api.getFilterModel()

                                vm.options.api.setRowData(fixTippy(submissions))
                                vm.options.api.sizeColumnsToFit()
                                vm.options.api.setFilterModel(model)
                                $scope.$emit('STOPSPINNER')
                            }
                            catch(e){}
                        }
                        else if (formDescriptionId == 1414){ // TFSR
                            if (!submissions) {
                                return
                            }
                            try {
                                translateAgGridHeader(vm.options)
                                $q.all([equipmentService.getPreopEquipmentList()
                                ]).then(() => { 
                                    equipmentSummaryList = equipmentService.readListPreopEquipments() 
                                    getMachineData(submissions,equipmentSummaryList)            
                                    model = vm.options.api.getFilterModel()
                                    vm.options.api.setRowData(fixTippy(submissions))
                                    vm.options.api.sizeColumnsToFit()
                                    vm.options.api.setFilterModel(model)
                                    $scope.$emit('STOPSPINNER')
                                })
                            }
                            catch(e){}
                        }
                        else {
                            $scope.$emit('STOPSPINNER')
                            if (!submissions) {
                                return
                            }
                            try{
                                translateAgGridHeader(vm.options)
                                model = vm.options.api.getFilterModel()
                                if(formDescriptionId == 1412){  //work card
                                    vm.options.api.setRowData(fixTippy(submissions,1412))
                                }
                                else if(formDescriptionId == 1411){  // A&M Shift report
                                    vm.options.api.setRowData(fixTippy(submissions,1411))
                                }
                                else{
                                    vm.options.api.setRowData(fixTippy(submissions))
                                }
                                vm.options.api.sizeColumnsToFit()
                                vm.options.api.setFilterModel(model)
                            }
                            catch (e) {}
                        }
                    })
                })
            })

        }

         // function to insert machine data into the submissions
         function getMachineData(sub, preopEquipmentList){
            sub.forEach((rec)=>{
                let modelList = []
                if(rec["Unit Make/Model"]) {
                    modelList = rec["Unit Make/Model"].split(";").map(item => item.trim())
                    rec["Unit Make/Model"] = ""
                    if(modelList && modelList.length > 0){
                        modelList.forEach((item)=>{
                            if(item === 'Other')
                                rec["Unit Make/Model"] += item + ";"
                            else{
                                let equipObj = preopEquipmentList.find(obj => obj.PreOpEquipmentID == item)
                                if(equipObj)
                                    rec["Unit Make/Model"] += equipObj.EquipDesc ? (equipObj.EquipDesc + ";") : ""
                                else
                                    rec["Unit Make/Model"] += ''
                            }
                        })
                    }
                }
            })
            return sub
        }

        function removeFields(data,fields) {
            data.forEach((rec)=>{
                fields.forEach((fld)=>{
                    delete rec[fld]
                })
            })
          return data
        }

        function getHazard(id){
            let rtrn = 0
            vm.hazardSubmissions.forEach(item => {
                if(item.sub_head_id==id ){
                    rtrn = item.sub_head_id
                    return     
                }
            })
            if(rtrn)
                return rtrn
        }

        // function for find the shift length calcucation
        function findShiftLength(submissionRecord){
            try{
                timeIn=submissionRecord["Time In"].split('; ');
                timeOut=submissionRecord["Time Out"].split('; ');
                shiftLength=[]
                let timeCount=timeIn.length
                for(let i=0;i<timeCount;i++){
                    shiftLength.push(calculateTime(timeIn[i], timeOut[i]))
                }
                submissionRecord["Shift Length"]=shiftLength.join("; ")
            }
            catch(err) {
            }           
        }

        // function for get the shift length
        function calculateTime(starttime, endtime){
            let startTime=moment(starttime, "HH:mm:ss a");
            let endTime=moment(endtime, "HH:mm:ss a");
            let hours = 0
            let minutes = 0
            if(startTime<=endTime){
                /* starttime is less than end time */
                let duration = moment.duration(endTime.diff(startTime));
                hours = parseInt(duration.asHours());
                minutes = parseInt(duration.asMinutes())-hours*60;  
            }
            else{
                let currentDayHours=0, currentDayMinutes=0
                /* starttime is today and endtime is next day  */
                let currentDayTime = moment("24:00:00", "HH:mm:ss a");      
                let currentDayduration = moment.duration(currentDayTime.diff(startTime));
                let startDayTime = moment("00:00:00", "HH:mm:ss a")
                let duration = moment.duration(endTime.diff(startDayTime));

                currentDayHours = parseInt(currentDayduration.asHours());
                currentDayMinutes = parseInt(currentDayduration.asMinutes())-currentDayHours*60;  
                
                hours = parseInt(duration.asHours());
                minutes = parseInt(duration.asMinutes())-hours*60;  
                hours=hours+currentDayHours
                minutes=minutes+currentDayMinutes
            }   
            
            return hours+'h '+minutes+'m'
        }    

        function fixTippy(data,formName){
            // If any data needs to be fixed in the tippy add conditions to 
            // fix itppy.
            data.forEach((item) =>  {
                item.exceptionFields = ["IncidentSignedOffStatus","Ventilation","Supervisor","end_of_shift_review_time_stamp", "Time",""]
                item.FormSubmissionDate = moment(item.FormSubmissionDate).format('YYYY-MM-DD')
                if(item.employee_name)
                    item.employee_name =  getEmployeeName(item.employee_name)
                if(item['Employee Name'])
                    item['Employee Name'] =  getEmployeeName(item['Employee Name'])
                if(item.Employee)
                    item.Employee =  getEmployeeName(item.Employee)
                if(item.HeaderSupervisor)
                    item.HeaderSupervisor =  getEmployeeName(item.HeaderSupervisor)

                item.end_of_shift_review_time_stamp = item['End of Shift Review'] ? item['Time'] : ''

                item['Report Distribution'] = item['Report Distribution'] != undefined ? item['Report Distribution'] : ''
                if(formName==1412){
                    for (const key in item) {
                        if(item[key]=="8502" || item[key]=="8503" || item[key]=="8504" || item[key]=="3914"){
                            item[key]=i18next.t(item[key])
                        }             
                    }
                }
                else if(formName==1411){
                    findShiftLength(item)
                }
              })
            return data
        }
        
        // function to insert preop data into the submissions
        function insertPreOPData(sub, preopSub){
            sub.forEach((rec)=>{
                let  obj= preopSub.find(obj => obj.psh_submissionheader_id == rec.ID)
                rec.FormSubmissionDate = moment(rec.FormSubmissionDate).format('YYYY-MM-DD')
                if(obj){
                    rec.equipment_identifier = obj.psh_pet_id__pet_equipment_identifier ? obj.psh_pet_id__pet_equipment_identifier : ""
                    rec.equipment_name = obj.EquipDesc ? obj.EquipDesc: ""
                    rec.equipment_comments = obj.comments ? obj.comments : ""
                }
                else {
                    rec.equipment_identifier =  ""
                    rec.equipment_name =  ""
                    rec.equipment_comments = "" 
                }
            })
            return sub
        }

         // function to insert custom form data into the submissions
         function insertCustomFormData(sub, customFormSub){
            sub.forEach((rec)=>{
                let  obj = customFormSub.find(obj => obj.cfm_submission_header == rec.ID)
                rec.FormSubmissionDate = moment(rec.FormSubmissionDate).format('YYYY-MM-DD')
                if (obj) {
                    rec.category_name = obj.category_name ? obj.category_name : ""
                    rec.custom_form_name = obj.cfm_fob ? obj.cfm_fob: ""
                }
                else {
                    rec.category_name = ""
                    rec.custom_form_name = ""
                }
            })
            return sub
        }
        
        //Refresh grid when any form is submitted
        $scope.$on('REFRESH_FORMSUBMISSIONS', (event) => {
            refreshForms()
        })

        //Function to initialize select2
        vm.initializeSelect2 = (parent)=> {  
        setTimeout(()=>{
        $('.select-single, .select-multiple')
            .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", width: '100%', dropdownParent: $(`#${parent} .modal-body`), escapeMarkup: function (text) { return text } })
            .on('select2:select', (event) => {
                if (event.target.parentNode.querySelector('.distribution-list'))
                    $rootScope.$broadcast('distribution-list-added', event)
                $(this).parent().find('label').addClass('filled')   
            })
            .on('select2:unselect', (event) => {
                if (event.target.parentNode.querySelector('.distribution-list'))
                    $rootScope.$broadcast('distribution-list-removed', event)
                $(this).parent().find('label').addClass('filled')
            })

            $('.select2-selection__arrow b').addClass("fa fa-caret-down") // Add caret on selects
            select2Service.select2Tags()
        }, 100)
        if($.fn.pickadate)$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
        $('.datepicker').pickadate({
            format: 'yyyy-mm-dd',
            onClose : function(){
                this.$holder.blur()
            },
        }).removeAttr('readonly')
        .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
            evt.preventDefault()
        })
        
        preventFutureDatePickerInit()
            
        let pickadateTranslations = sofvie_pickatime_languages[`${selectedLanguage}`]
        $('.timepicker').pickatime({
            donetext: pickadateTranslations.done,
            cleartext: pickadateTranslations.clear,
            twelvehour: true, 
            'default': '24:00'
        }).on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
            evt.preventDefault()
        })       
        }

        //Update Ag-Grid size when window is resized
        $(window).on('resize', () => {
            $timeout(function () {
            if (vm.options.api) {
            vm.options.api.sizeColumnsToFit()
            }
            })
        })  
        vm.options.onGridReady= () =>{
            let fdi =  $routeParams.formDescriptionId
            if(fdi == 1402 || fdi == 1401){
                 vm.options.columnApi.setColumnVisible('Employee Name', true)
                 vm.options.columnApi.setColumnVisible('Employee', false)
             }else if(fdi == 1381 || fdi == 1386 || fdi == 1385) {
                vm.options.columnApi.setColumnVisible('Employee Name', false)
                vm.options.columnApi.setColumnVisible('Employee', true)
             }else {
                vm.options.columnApi.setColumnVisible ('Employee Name', false) 
                vm.options.columnApi.setColumnVisible('Employee', false)
            }
            if(fdi==1402){
                vm.options.columnApi.setColumnVisible('Reason For Departure',true)
                vm.options.columnApi.setColumnVisible('SiteLevel',false)
                vm.options.columnApi.setColumnVisible('Workplace',false  )
                vm.options.columnApi.setColumnVisible('Supervisor',false)
                vm.options.columnApi.setColumnVisible('HeaderDate', false)
                vm.options.columnApi.setColumnVisible('Departure Date', true)
            }
            if(fdi ==1386){
                vm.options.columnApi.setColumnVisible('Event Type',true)
            } else {
                vm.options.columnApi.setColumnVisible('Event Type',false)
            }
            if(fdi == 1409){
                vm.options.columnApi.setColumnVisible('Agenda',true)
            } else {
                vm.options.columnApi.setColumnVisible('Agenda', false)
            }
            if(fdi == 1389 || fdi == 1392 || fdi == 1410){ // Added condition for End of shift time stamp for Preop and Pretask and pretask_vale_FLHA
                vm.options.columnApi.setColumnVisible('end_of_shift_review_time_stamp',true)
            }else{
                vm.options.columnApi.setColumnVisible('end_of_shift_review_time_stamp',false)
            }
            if(fdi==1289){
                vm.options.columnApi.setColumnVisible('Inspection Type',true)
            }else{
                vm.options.columnApi.setColumnVisible('Inspection Type',false)
            }
        }

    //END
    }
])