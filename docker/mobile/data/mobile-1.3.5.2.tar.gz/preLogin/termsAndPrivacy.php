<?php	
	$boolLoginRequired = false;
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
	$strPageTitle = 'Terms and Privacy';
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
    include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");

?>
<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-3">
			<div class="card">
				<div class="card-body">
					<h4><span class='translate' data-i18n="1779" note="Terms and conditions of use"></span></h4>
					<p><span class='translate' data-i18n="1780" note="Please read these terms and conditions"></span><br>
            
					<h4><span class='translate' data-i18n="1782" note="Privacy Policy"></span></h4>
					<p><span class='translate' data-i18n="[html]1783" note="Privacy Policy"></span></p>
					
            
					<h4><span class='translate' data-i18n="1784" note="Copyright"></span></h4>
					<p><span class='translate' data-i18n="1785" note="Content published on this platform"></span></p>

					<h4><span class='translate' data-i18n="1786" note="Communications"></span></h4>
					<p><span class='translate' data-i18n="1787" note="The entire communication with"></span></p>
            
					<h4><span class='translate' data-i18n="1788" note="Cookies"></span></h4>
					<p><span class='translate' data-i18n="1789" note="We employ the use of cookies."></span></p>
            
					<h4><span class='translate' data-i18n="1790" note="License"></span></h4>
					<p><span class='translate' data-i18n="1791" note="Unless otherwise stated"></span><br>
					<span class='translate' data-i18n="1792" note="You must not:"></span>
						<ol>
							<li><span class='translate' data-i18n="1793" note="Republish material"></span></li>
							<li><span class='translate' data-i18n="1794" note="Sell, rent or sub-license material"></span></li>
							<li><span class='translate' data-i18n="1795" note="Reproduce, duplicate or copy material"></span></li>
							<li><span class='translate' data-i18n="1796" note="Redistribute content from Sofvie (unless content is specifically made for redistribution)."></span></li>
						</ol>
					</p>

					<h4><span class='translate' data-i18n="1797" note="User Content"></span></h4>
					<p>
						<ol>
							<li><span class='translate' data-i18n="1798" note="This Agreement shall begin on the date"></span></li>
							<li><span class='translate' data-i18n="1799" note="Certain parts of this software offer"></span></li>
							<li><span class='translate' data-i18n="1800" note="Sofvie reserves the right to monitor"></span></li>
							<li><span class='translate' data-i18n="1801" note="You warrant and represent that:"></span>
								<ol>
									<li><span class='translate' data-i18n="1802" note="You are entitled to submit content"></span></li>
									<li><span class='translate' data-i18n="1803" note="The content does not infringe"></span></li>
									<li><span class='translate' data-i18n="1804" note="The content does not contain"></span></li>
									<li><span class='translate' data-i18n="1805" note="The content will not be used to solicit"></span></li>
									</ol>
								</li>
							<li>
								<span class='translate' data-i18n="[html]1806" note="You hereby grant to"></span>
							
						</li>
						</ol>
					<span class='translate' data-i18n="1807" note="We do not own any data"></span>
					</p>

					<h4><span class='translate' data-i18n="1808" note="Intellectual property rights"></span></h4>
					<p><span class='translate' data-i18n="1809" note="This Agreement does not transfer"></span></p>

					<h4><span class='translate' data-i18n="1810" note="Hyperlinking to our Content"></span></h4>
					<p>
						<ol>
							<li><span class='translate' data-i18n="1811" note="The following organizations may link"></span>
								<ol>
								<li><span class='translate' data-i18n="1812" note="Government agencies;"></span></li>
								<li><span class='translate' data-i18n="1813" note="Search engines;"></span></li>
								<li><span class='translate' data-i18n="1814" note="News organizations;"></span></li>
								<li><span class='translate' data-i18n="1815" note="Online directory distributors"></span></li>
								<li><span class='translate' data-i18n="1816" note="Systemwide Accredited Businesses"></span></li>
								</ol>
							</li>
						</ol>
						<ol start="2">
							<li><span class='translate' data-i18n="1817" note="These organizations may"></span>
							</li>
							<li><span class='translate' data-i18n="1818" note="We may consider and approve"></span>
								<ol>
									<li><span class='translate' data-i18n="1819" note="commonly-known consumer"></span></li>
									<li><span class='translate' data-i18n="1820" note="dot.com community sites;"></span></li>
									<li><span class='translate' data-i18n="1821" note="associations or other groups"></span></li>
									<li><span class='translate' data-i18n="1822" note="online directory distributors;"></span></li>
									<li><span class='translate' data-i18n="1823" note="internet portals;"></span></li>
									<li><span class='translate' data-i18n="1824" note="accounting, law and consulting"></span></li>
									<li><span class='translate' data-i18n="1825" note="educational institutions"></span></li>
								</ol>
							</li>
						</ol>
					<span class='translate' data-i18n="[html]1826" note="The entire communication with"></span>
					

					<br><span class='translate' data-i18n="1827" note="Approved organizations may hyperlink"></span>
						<ol>
							<li><span class='translate' data-i18n="1828" note="By use of our corporate name; or"></span></li>
							<li><span class='translate' data-i18n="1829" note="By use of the uniform resource"></span></li>
							<li><span class='translate' data-i18n="1830" note="By use of any other description"></span></li>
						</ol>
					<span class='translate' data-i18n="1831" note="No use of softname’s logo"></span></p>

					<h4><span class='translate' data-i18n="1832" note="Iframes"></span></h4>
					<p><span class='translate' data-i18n="1833" note="Without prior approval and"></span></p>

					<h4><span class='translate' data-i18n="1834" note="Reservation of Rights"></span></h4>
					<p><span class='translate' data-i18n="1835" note="We reserve the right at any time"></span></p>

					<h4><span class='translate' data-i18n="1836" note="Removal of links from our website"></span></h4>
					<p><span class='translate' data-i18n="1837" note="If you find any link"></span></p>

					<h4><span class='translate' data-i18n="1838" note="Content Liability"></span></h4>
					<p><span class='translate' data-i18n="1839" note="We shall have no responsibility or liability"></span></p>

					<h4><span class='translate' data-i18n="1840" note="Disclaimer"></span></h4>
					<p><span class='translate' data-i18n="1841" note="To the maximum extent permitted"></span></p>
					<ol>
					<li><span class='translate' data-i18n="1842" note="liability for death or personal"></span></li>
					<li><span class='translate' data-i18n="1843" note="liability for fraud"></span>;</li>
					<li><span class='translate' data-i18n="1844" note="liabilities in any way"></span></li>
					<li><span class='translate' data-i18n="1845" note="exclude any of our or your"></span></li>
					</ol>
					<p><span class='translate' data-i18n="1846" note="The limitations and exclusions of liability"></span></p>
            
					<h4><span class='translate' data-i18n="1847" note="Backups and Downtime"></span></h4>
					<p><span class='translate' data-i18n="1848" note="We perform regular backups "></span></p>

					<h4><span class='translate' data-i18n="1849" note="Indemnification"></span></h4>
					<p><span class='translate' data-i18n="1850" note="You agree to indemnify"></span></p>

					<h4><span class='translate' data-i18n="1851" note="Severability"></span></h4>
					<p><span class='translate' data-i18n="1852" note="All rights and restrictions"></span></p>

					<h4><span class='translate' data-i18n="1853" note="Dispute resolution"></span></h4>
					<p><span class='translate' data-i18n="1854" note="The formation, interpretation"></span></p>

					<h4><span class='translate' data-i18n="1855" note="Changes and amendments"></span></h4>
					<p><span class='translate' data-i18n="1856" note="We reserve the right to modify"></span></p>

					<h4><span class='translate' data-i18n="1857" note="Acceptance of these terms"></span></h4>
					<p><span class='translate' data-i18n="1858" note="You acknowledge that"></span></p>

					<!-- Privacy Policy starts here -->
					<h4 id="privacy_policy"><span class='translate' data-i18n="1782" note="Privacy Policy"></span></h4>
					<p><span class='translate' data-i18n="1859" note="Your privacy is critically important to us."></span></p>
            
					<p>
						<span class='translate' data-i18n="[html]1860" note="It is Sofvie’s policy to respect"></span></p>					

					<h4><span class='translate' data-i18n="1861" note="Visitors and Users"></span></h4>
					<p><span class='translate' data-i18n="1862" note="Like most software operators"></span></p>
            
					<h4><span class='translate' data-i18n="1863" note="Gathering of Personally"></span></h4>
					<p><span class='translate' data-i18n="1864" note="Certain visitors to Sofvie’s"></span></p>
            
					<h4><span class='translate' data-i18n="1865" note="Security"></span></h4>
					<p><span class='translate' data-i18n="1866" note="The security of your Personal"></span></p>
            
					<h4><span class='translate' data-i18n="1867" note="Advertisements"></span></h4>
					<p><span class='translate' data-i18n="1868" note="Ads appearing on our platforms"></span></p>

					<h4><span class='translate' data-i18n="1869" note="Links To External Sites"></span></h4>
					<p><span class='translate' data-i18n="1870" note="Our services may contain"></span></p>
            
					<h4><span class='translate' data-i18n="1871" note="Sofvie.com uses Google"></span></h4>
					<p><span class='translate' data-i18n="1872" note="Sofvie.com uses the remarketing"></span></p>
            
					<h4><span class='translate' data-i18n="1873" note="Protection of Certain"></span></h4>
					<p><span class='translate' data-i18n="1874" note="Sofvie discloses potentially "></span></p>
            
					<h4><span class='translate' data-i18n="1875" note="Aggregated Statistics"></span></h4>
					<p><span class='translate' data-i18n="1876" note="Sofvie may collect statistics"></span></p>
            
					<h4><span class='translate' data-i18n="1877" note="Affiliate Disclosure"></span></h4>
					<p><span class='translate' data-i18n="1878" note="This site uses affiliate"></span></p>
            
					<h4><span class='translate' data-i18n="1788" note="Cookies"></h4>
					<p><span class='translate' data-i18n="1879" note="To enrich and perfect your"></span></p>
            
					<h4><span class='translate' data-i18n="1880" note="Business Transfers"></span></h4>
					<p><span class='translate' data-i18n="1881" note="substantially all of its assets"></span></p>
            
					<h4><span class='translate' data-i18n="1882" note="Privacy Policy Changes"></span></h4>
					<p><span class='translate' data-i18n="1883" note="Although most changes"></span></p>
            
					<h4><span class='translate' data-i18n="1884" note="Applicable Law"></span> </h4>
					<p><span class='translate' data-i18n="1885" note="By visiting this website"></span></p>
            
					<h4><span class='translate' data-i18n="1886" note="Comments, Reviews, and Emails"></span></h4>
					<p><span class='translate' data-i18n="1887" note="Visitors may post content"></span></p>
            
					<h4><span class='translate' data-i18n="1888" note="License and Access"><span></h4>
					<p><span class='translate' data-i18n="1889" note="We grant you a limited license"></span></p>
            
					<strong><span class='translate' data-i18n="1890" note="Last updated"></span>: 15 <span class='translate' data-i18n="2135" note="January"></span> 2019</strong>
				</div>
			</div>
		</div>
	</div>
</main>
<script>
	openCacheData().then(() => {
		$("#footerSpinner").addClass('d-none')
	})
</script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
