
sofvie_pickatime_languages = {
    en: {
        done: "Done",
        clear: "Clear",
    },
    fr: {
        done: "Fini",
        clear: "Effacer",
    },
    es: {
        done: 'Terminado',
        clear: 'Borrar',
    }
}