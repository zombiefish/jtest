function sofvie_select2_languages_en () {
    // English
    return {
      errorLoading: function () {
        return 'The results could not be loaded.';
      },
      inputTooLong: function (args) {
        var overChars = args.input.length - args.maximum;
  
        var message = 'Please delete ' + overChars + ' character';
  
        if (overChars != 1) {
          message += 's';
        }
  
        return message;
      },
      inputTooShort: function (args) {
        var remainingChars = args.minimum - args.input.length;
  
        var message = 'Please enter ' + remainingChars + ' or more characters';
  
        return message;
      },
      loadingMore: function () {
        return 'Loading more results…';
      },
      maximumSelected: function (args) {
        var message = 'You can only select ' + args.maximum + ' item';
  
        if (args.maximum != 1) {
          message += 's';
        }
  
        return message;
      },
      noResults: function () {
        return 'No results found';
      },
      searching: function () {
        return 'Searching…';
      },
      removeAllItems: function () {
        return 'Remove all items';
      },
      removeItem: function () {
        return 'Remove item';
      },
      search: function() {
        return 'Search';
      }
    };
};

function sofvie_select2_languages_fr () {
    // French
    return {
      errorLoading: function () {
        return 'Les résultats ne peuvent pas être chargés.';
      },
      inputTooLong: function (args) {
        var overChars = args.input.length - args.maximum;
  
        return 'Supprimez ' + overChars + ' caractère' +
          ((overChars > 1) ? 's' : '');
      },
      inputTooShort: function (args) {
        var remainingChars = args.minimum - args.input.length;
  
        return 'Saisissez au moins ' + remainingChars + ' caractère' +
          ((remainingChars > 1) ? 's' : '');
      },
      loadingMore: function () {
        return 'Chargement de résultats supplémentaires…';
      },
      maximumSelected: function (args) {
        return 'Vous pouvez seulement sélectionner ' + args.maximum +
          ' élément' + ((args.maximum > 1) ? 's' : '');
      },
      noResults: function () {
        return 'Aucun résultat trouvé';
      },
      searching: function () {
        return 'Recherche en cours…';
      },
      removeAllItems: function () {
        return 'Supprimer tous les éléments';
      },
      removeItem: function () {
        return 'Supprimer l\'élément';
      }
    };
};

function sofvie_select2_languages_es () {
    // Spanish
    return {
      errorLoading: function () {
        return 'No se pudieron cargar los resultados';
      },
      inputTooLong: function (args) {
        var remainingChars = args.input.length - args.maximum;
  
        var message = 'Por favor, elimine ' + remainingChars + ' car';
  
        if (remainingChars == 1) {
          message += 'ácter';
        } else {
          message += 'acteres';
        }
  
        return message;
      },
      inputTooShort: function (args) {
        var remainingChars = args.minimum - args.input.length;
  
        var message = 'Por favor, introduzca ' + remainingChars + ' car';
  
        if (remainingChars == 1) {
          message += 'ácter';
        } else {
          message += 'acteres';
        }
  
        return message;
      },
      loadingMore: function () {
        return 'Cargando más resultados…';
      },
      maximumSelected: function (args) {
        var message = 'Sólo puede seleccionar ' + args.maximum + ' elemento';
  
        if (args.maximum != 1) {
          message += 's';
        }
  
        return message;
      },
      noResults: function () {
        return 'No se encontraron resultados';
      },
      searching: function () {
        return 'Buscando…';
      },
      removeAllItems: function () {
        return 'Eliminar todos los elementos';
      }
    };
};