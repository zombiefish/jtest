let form = document.forms[0];
let cancelTimer = null
let sofvieBrowserVersion = "Chrome"
let primaryKeyField = form.keyField.value
let draft = document.getElementById(form.draftField.value);// Name of our Draft selector
debug = _DEBUG;	// Set our debug flag


(() => {

    document.addEventListener( "DOMContentLoaded", () =>{
        sofvieBrowserVersion = detectBrowserVersion()
        try	{
            formHeader.formInitialize(document.forms[0])
        } catch(err)	{
            console.warn('formHeader.formInitialize does not exist. \n' + err)
        }

        try	{
            formBody.formInitialize(document.forms[0])
        } catch(err)	{
            console.warn('formBody.formInitialize does not exist. \n' + err)
        }

        try	{
            formFooter.formInitialize(document.forms[0])
        } catch(err)	{
            console.warn('formFooter.formInitialize does not exist. \n' + err)
        }
        
        var DBconfigDraftRmm = {
            draftDbName: 'mobileRmmDraft',
            draftRemoteSync: false,
            commitDBName: _SYNCCOUCHDB,
            commitRemoteSync:  _SYNCDOMAIN + ':' + _SYNCPORT + '/' + _SYNCCOUCHDB
        }

		var DBconfigRMM = {
            DbName: 'sofvieRmm',
            RemoteSync: false,
            commitDBName: _SYNCCOUCHDB,
            commitRemoteSync:  _SYNCDOMAIN + ':' + _SYNCPORT + '/' + _SYNCCOUCHDB
        }

		// Create a ref to the local Draft DB
        rmmDbDraft = new PouchDB(DBconfigDraftRmm.draftDbName, {auto_compaction: true})
        dbSofvieRMM = new PouchDB(DBconfigRMM.DbName, {auto_compaction: true})
		getRADraftList(draft)


        // // Save a draft (local only) copy of this form.
        setTimeout(() =>{

			// For Saving Draft
            document.getElementById("saveDraft").addEventListener( "click", ( e )=> {
                stopAutoSave()
                document.getElementById("saveDraft").disabled = true
                e.preventDefault()
                if(formHandle(form, 'draft')){
					let json = toJSONString( form )
                    if(primaryKeyField)	{
                        key = draftName(primaryKeyField)
                           if (form.checkValidity() === false) {
                            e.preventDefault()
                            e.stopImmediatePropagation()
                        } 
                        form.classList.add('was-validated')

                		// Then save the JSON to our localDB
                        addFormDraft(json, key, form.submissionId.value, form.formname.value)
                        return
                    } else	{
                        alert('No primary keyfield defined for this form, please contact admin')
                    }
                }
            }, false)
        },1)

        // Save a local, and remote, copy of the form.
		setTimeout(function(){ 
            form.addEventListener( "submit", function( e ) {				
				e.preventDefault()	
				window.sessionStorage.setItem('modalsubmit','SUBMITSTOP')	
				autoValidateSave()
				stopAutoSave()
			
				// Handle any post processing to the form component
				if(formHandle(form, 'full')){
					if(primaryKeyField)	{
						let key = draftName(primaryKeyField)

					/// Start of Modal for Saving the Submission			
					formModal = new SofvieModal()
					formModal.handleModal(`warning`)
					$(`.modal-footer .confirm`).click(() => {
					formModal.hideModal()
					// Submit to Pouch 
					let formStatus = addForm(jraObject, key, form.submissionId.value, form.formname.value, form._rev.value, form.formid.value);


					if (formStatus) {
					} else {
						$('#theModal').one('hidden.bs.modal', (e) => {
							formModal.setModalElements(`danger`, `modalText`, `The form submission failed.`)
							formModal.setModalElements(`danger`, `modalTitle`, `Form Submission Failure`)
							formModal.setModalElements(`danger`, `modalButtons`, `<a role="button" class="btn btn-outline-danger waves-effect" data-dismiss="modal">OK</a>`)
							formModal.handleModal(`danger`)
							startAutoSave()
						})
					}
					})
					
					$(`#cancelSubmit`).click(() => {  
						window.sessionStorage.removeItem('modalsubmit','1')
						startAutoSave()
					})
			
					// End of Modal Submit
					// Then save the JSON to our localDB
					} else	{
						alert('No primary keyfield defined for this form, please contact admin')
					}
				}	// End Form Valid
            }, false)		
        }, 1000)

    })

})()

    function autoValidateSave() {
        let formValidationStatus = $('form')[0].classList.contains('was-validated')  // Added a condition so if the form was validated before the autosave it will respect it
        let status = formHeader.formValidate($('form')[0],'autosave')
        if(status){
            window.sessionStorage.setItem('modalsave','1')
            document.getElementById('saveDraft').click() 
            if(!formValidationStatus){
                $('form')[0].classList.remove('was-validated')
            }
        }
    }

	// Code to autosave the form every 20 seconds if the header 
	// information is properly filled out
	let autoSaveInterval = ''
	function startAutoSave() {
		autoSaveInterval = setInterval(()=>{
			autoValidateSave()
		}, 20000)
	}

    // function to stop the Autosave interval on Submission
	function stopAutoSave() {
        clearInterval(autoSaveInterval);
    }

    function detectBrowserVersion() {
		let navUserAgent = navigator.userAgent;
		let browserName  = navigator.appName;
		let browserVersion  = ''+parseFloat(navigator.appVersion); 
		let majorVersion = parseInt(navigator.appVersion,10);
		let tempNameOffset,tempVersionOffset,tempVersion;
		
		if ((tempVersionOffset=navUserAgent.indexOf("Opera"))!=-1) {
			browserName = "Opera"
			browserVersion = navUserAgent.substring(tempVersionOffset+6)
		if ((tempVersionOffset=navUserAgent.indexOf("Version"))!=-1) 
			browserVersion = navUserAgent.substring(tempVersionOffset+8)
		} else if ((tempVersionOffset=navUserAgent.indexOf("MSIE"))!=-1) {
			browserName = "Microsoft Internet Explorer"
			browserVersion = navUserAgent.substring(tempVersionOffset+5)
		} else if ((tempVersionOffset=navUserAgent.indexOf("Chrome"))!=-1) {
			browserName = "Chrome"
			browserVersion = navUserAgent.substring(tempVersionOffset+7)
		} else if ((tempVersionOffset=navUserAgent.indexOf("Safari"))!=-1) {
			browserName = "Safari"
			browserVersion = navUserAgent.substring(tempVersionOffset+7)
		if ((tempVersionOffset=navUserAgent.indexOf("Version"))!=-1) 
			browserVersion = navUserAgent.substring(tempVersionOffset+8)
		} else if ((tempVersionOffset=navUserAgent.indexOf("Firefox"))!=-1) {
			browserName = "Firefox"
			browserVersion = navUserAgent.substring(tempVersionOffset+8)
		} else if ((tempNameOffset=navUserAgent.lastIndexOf(' ')+1) < (tempVersionOffset=navUserAgent.lastIndexOf('/')) ) {
			browserName = navUserAgent.substring(tempNameOffset,tempVersionOffset)
			browserVersion = navUserAgent.substring(tempVersionOffset+1)
			if (browserName.toLowerCase()==browserName.toUpperCase()) {
				browserName = navigator.appName
			}
		}
		
		// trim version
		if ((tempVersion=browserVersion.indexOf(";"))!=-1)
			browserVersion=browserVersion.substring(0,tempVersion)
		if ((tempVersion=browserVersion.indexOf(" "))!=-1)
			browserVersion=browserVersion.substring(0,tempVersion)
		return browserVersion
	}

    function formHandle(form, submissionType){	
		// Handle the form.  First perform any post processing before validation.
		try	{
			formHeader.formTerminate(form)
		} catch(err)	{
			console.warn('formHeader.formTerminate does not exist. \n' + err)
		}
		try	{
			formBody.formTerminate(form)
		} catch(err)	{
			console.warn('formBody.formTerminate does not exist. \n' + err)
		}
		try	{
			formFooter.formTerminate(form)
		} catch(err)	{
			console.warn('formFooter.formTerminate does not exist. \n' + err)
		}
		// Handle validation of the form component, we always validate the form header because the data is used in defining the draft.
		try	{		
			headForm = formHeader.formValidate(form)
			if(headForm === false)	{
				return false
			}				
		} catch(err)	{
			console.error('formHeader.formValidate: ' + err)
			return false
		}

		if(submissionType !== 'full')	{																	    // Handle the special case of child forms (HAP/PID) using their respective form ids
			if(form.formid.value == 131042 || form.formid.value == 166071 || form.formid.value == 131200)	{	// We must always validate child forms whether submit or draft
				try	{																							// Call any form validation code in the header
						return formFooter.formValidate(form)
				} catch(err)	{
					console.error('formFooter.formValidate: ' + err)
					return false
				}
			}
			
		}	 else	{
			try	{
				formBody.formValidate(form)	
			} catch(err)	{
				console.error('formBody.formValidate : ' + err)
				return false
			}
			try	{				
				return formFooter.formValidate(form)
			} catch(err)	{
				console.error('formFooter.formValidate:' + err)
				return false
			}
		}
			document.getElementById("saveDraft").disabled = true
		return true
	}

    function toJSONString( form ) {
		// Extract all form elements, iterate over, extracte values, save as JSON Key:Value pairs
		// INPUTS:
		//	form - form object from the event listener
		let obj = {}
		let elements = form.querySelectorAll( "input, select, textarea" )
		for(let i = 0; i < elements.length; ++i ) {
			let element = elements[i]	
			// Extract the element type
			let name = element.name.substring(element.name.indexOf('~') + 1, 120)
			let value = element.value

			if( name ) {
				if(!obj[name]) {
					if(element.matches('[type="radio"]')) {		
						if(element.checked)	{	
							// Is it checked
							obj[name] = element.value
						} 

					} else if (element.tagName == 'SELECT') {
							obj[name] = getSelectValues(element)
					} else {
						obj[name] = element.value
					}
				}
			} 
		 }
		return JSON.stringify( obj )
	}

    function getSelectValues(select) {
		let result = []
		let options = select && select.options
		let opt

		for (let i=0, iLen=options.length; i<iLen; i++) {
			opt = options[i]

			if (opt.selected) {	
				result.push(opt.value || opt.text);	
			}
		}
		return result.join('|')	
	}

    function draftName(primaryKeyField)	{
		// Build a unique form identifier for saved draft of 'this' form, based on the contents of the hidden keyField
		// All draft field names contain the timestamp and site.
		// INPUTS:
		//	primaryKeyField - the primaryKeyField values, can be a pipe '|' seperated array for compound id's.
		
		// Create a base name for this form (name + formatted timestamp)
		// if the form has PARENT in IT just cut it off - RR
		let fname = form.formname.value
		if(fname.indexOf(' PARENT') >= 0){
			fname = form.formname.value.slice(0, -7)
		}
		let draftTitle = ''
		let formattedDate = moment(form.startFormTimeStamp.value).format('YYYY-MM-DD hh:mm:ss a')
		
		let arrKeys = primaryKeyField.split('|')	

		arrKeys.forEach((element) => {
			if(form[element].options && form[element].options[form[element].selectedIndex]){
				draftTitle = draftTitle + ' ' + form[element].options[form[element].selectedIndex].innerHTML
			}
			else{
				draftTitle = draftTitle + ' ' + form[element].value	
			}	
		})

		if(debug) console.log(draftTitle)	

		return {
			"title": draftTitle.trim(),			
			"formid": `${draftTitle.trim()} - ${formattedDate}`
		}
	}

	// Write the JSON data to the local DB
    function addFormDraft(text, pouchid, submissionID, formname, mode='yes', type='parent') {
		parentDraft = $("#currentDraft").val()
		if(type !== 'parent') {
            $("#currentDraft").val("")
			formdata=text
        }
		else{
			formdata=jraObject
			jraObject.jra_data.rmm_jra_created_by_per_id = document.getElementById('submittedby').value
		}
        rmmDbDraft.get(pouchid.formid).then(function(doc) {
            return rmmDbDraft.put({
				// Update it
                _id: pouchid.formid,
                _rev: doc._rev,
				// Make submissionID available
                submissionID: submissionID,
                formname: formname,
				// Must pass the existing revision
                formid: pouchid.title,
				// and the data
                formdata: formdata
            })
        }).then(function(response) {
            if(mode === 'yes'){
                updateDraftListSelect(pouchid.formid || pouchid.title)
                showAlert()
            }	                                          
        }).catch(function (err) {
            if(debug) console.log('Creating New Rec: ' + err);	
            rmmDbDraft.put({
                _id: pouchid.formid,
                _rev: text._rev,
                submissionID: submissionID,	
                formname: formname,
                formid: pouchid.title,
                formdata:formdata
            }).then( ()=> {
                if ($("#currentDraft").val() !== "" && type === 'parent') {
                    rmmDbDraft.get($("#currentDraft").val()).then(function(doc) {
                        return rmmDbDraft.remove(doc);
                    }).then(()=>{
                    updateDraftListSelect(pouchid.formid,type)
                    if(mode === 'yes') {
                        showAlert()   
                        }
                    }); // Update draft list.
                }
                else {
                    updateDraftListSelect(pouchid.formid,type,parentDraft)
                    if(mode === 'yes'){
                        showAlert()   
                    }
                }
            });
        });		
    }

	function changePropertyNames(arrParent){
		arrParent.jra_data['rmm_jra_site_id'] = arrParent.jra_data['rmm_jra_site']
		arrParent.jra_data['rmm_jra_job_id'] = arrParent.jra_data['rmm_jra_job']
		arrParent.jra_data['rmm_jra_pra_id'] = arrParent.jra_data['rmm_jra_pra']
		delete arrParent.jra_data.rmm_jra_site
		delete arrParent.jra_data.rmm_jra_job
		delete arrParent.jra_data.rmm_jra_pra
		delete arrParent.jra_data.rmm_jra_is_submitted
		delete arrParent.jra_data.rmm_jra_revision_no
		delete arrParent.jra_data.approversList

		arrParent.jra_data.step_categories.forEach((cat)=>{
			cat.threats.forEach((threat)=>{
				threat.rmm_jth_likelyhood_preliminary_id = threat.rmm_jth_likelyhood_preliminary ? threat.rmm_jth_likelyhood_preliminary: null
				threat.rmm_jth_likelyhood_residual_id = threat.rmm_jth_likelyhood_residual ? threat.rmm_jth_likelyhood_residual : null
				threat.rmm_jth_severity_preliminary_id = threat.rmm_jth_severity_preliminary ? threat.rmm_jth_severity_preliminary :null
				threat.rmm_jth_severity_residual_id = threat.rmm_jth_severity_residual ? threat.rmm_jth_severity_residual : null
				delete threat.rmm_jth_likelyhood_preliminary
				delete threat.rmm_jth_likelyhood_residual
				delete threat.rmm_jth_severity_preliminary
				delete threat.rmm_jth_severity_residual
				delete threat.preliminary_likelyhood_score
				delete threat.preliminary_severity_score
				delete threat.residual_likelyhood_score
				delete threat.residual_severity_score
				delete threat.rmm_jth_preliminary_risk_text
				delete threat.rmm_jth_residual_risk_text
				delete threat.applicable_line_items
				delete threat.rmm_jth_risk
			})
		})

		arrParent.jra_general_actions.forEach((val)=>{
			val['sga_id']=null
			val['HeaderDate']=val.date
			val['Site']=parseInt(val.rmm_jra_site)
			val['JobNumber']=parseInt(val.rmm_jra_job)
			val['SiteLevel']=parseInt(val.rmm_jra_level)
			val['Workplace']=val.rmm_jra_workplace
			val['Supervisor']=parseInt(val.rmm_jra_supervisor)
			val['sga_action_is_complete']=0
			val['distribution'] =  val.modal_report_distribution? val.modal_report_distribution.split('|'):[]
			val['sga_completed_action_type_rld_id']=null
			val['sga_completed_action_taken']=null
			val['sga_action_type_rld_id']=parseInt(val.action_type)
			val['sga_action_by_who_per_id']=val.action_by_who ? val.action_by_who.split("|").map(Number): []
            val['sga_action_by_when']=val.general_action_by_when
            val['sga_created_date']= val.general_action_by_when_submit
            val['sga_created_by_per_id']=parseInt(val.submittedby)
            val['sga_completed_action_date']=null
            val['sga_recommended_action']=val.recommended_action
			val['completed_action_score']=null
			
			delete val.date
			delete val.rmm_jra_site
			delete val.rmm_jra_job
			delete val.rmm_jra_level
			delete val.rmm_jra_workplace
			delete val.rmm_jra_supervisor
			delete val.action_type
			delete val.action_by_who
			delete val.general_action_by_when
			delete val.endFormTimeStamp
			delete val.submittedby
			delete val.general_action_by_when_submit
			delete val.submissionId
			delete val.displayReferenceValue
			delete val.child_draft
			delete val.recommended_action
			delete val.modal_report_distribution
			delete val.formname
			delete val.formtype
			delete val.formid
			delete val.version
			delete val.date_submit
			delete val._rev
			delete val._id
			delete val.keyField
			delete val.draftField
			delete val.startFormTimeStamp
			delete val.myFile
		})
		
		arrParent.jra_hazard_actions.forEach((val)=>{
			val['HeaderDate']=val.date
			val['Site']=parseInt(val.rmm_jra_site)
			val['JobNumber']=parseInt(val.rmm_jra_job)
			val['SiteLevel']=parseInt(val.rmm_jra_level)
			val['Workplace']=val.rmm_jra_workplace
			val['Supervisor']=parseInt(val.rmm_jra_supervisor)
			val['distribution'] =  val.modal_report_distribution? val.modal_report_distribution.split('|'):[]
			val['action_by_who']=val.action_by_who ? val.action_by_who.split("|").map(Number): []
			val['hazard_type']=parseInt(val.hazard_type)
			val['action_complete_by_who']=val.action_completed_by_who
			val['action_completed_date']=val.action_completed_date ? val.action_completed_date :null
			val['immediate_action_required_and_performed'] = val.immediate_action_required_and_performed ? val['immediate_action_required_and_performed']=parseInt(val.immediate_action_required_and_performed): 0
			val['further_action_required'] = val.further_action_required ? val['further_action_required']=parseInt(val.further_action_required) : 0
			val['action_type_score'] = val.action_type ? val['action_type_score']=parseInt(val.action_type.split('|')[1]) : 0
			val['action_type'] = val.action_type ? val['action_type']=parseInt(val.action_type.split('|')[0]) : 0
			val['hazard_identification']=val.hazard_identification?parseInt(val.hazard_identification.split('|')[0]):0
			val['hazard_identification_score']=parseInt(val.hazard_identification_score)
			val['immediate_action_type'] = val.immediate_action_type ? val['immediate_action_type']=parseInt(val.immediate_action_type.split('|')[0]) : 0
			val['immediate_action_score'] = val.immediate_action_score ? val['immediate_action_score']=parseInt(val.immediate_action_score) : 0
			val['potential_risk']=val.potential_risk? parseInt(val.potential_risk.split('|')[0]):0
			val['potential_risk_score']=parseInt(val.potential_risk_score)
			val['submittedby']=parseInt(val.submittedby)
			val['completed_action_score']=null
			val['completed_action_type']=null
			val['action_by_when']=val.action_by_when ? val.action_by_when :null
			delete val.date
			delete val.rmm_jra_site
			delete val.rmm_jra_job
			delete val.rmm_jra_level
			delete val.rmm_jra_workplace
			delete val.rmm_jra_supervisor
			delete val.child_draft
			delete val.formname
			delete val.formtype
			delete val.formid
			delete val.action_type_score
			delete val.date_submit
			delete val.version
			delete val.submittedby
			delete val.action_completed_by_who
			delete val._rev
			delete val._id
			delete val.keyField
			delete val.action_by_when_submit
			delete val.draftField
			delete val.startFormTimeStamp
			delete val.modal_report_distribution
			delete val.action_completed_date_submit
			delete val.myFile
			delete val.selected_draft
			delete val.displayReferenceValue
			delete val.submissionId
			delete val.endFormTimeStamp
		})
		return arrParent
	}

	// check if the user can add another JRA
    function checkJRAformAccess(){
		const formAccessData = remoteData[_FORMACCESS].FormAccess
		let obj = formAccessData.find(o => o.FormID == 372448);
		if(obj === undefined) {
		  return false
		} 
		return true
	  }
	async function addForm(jraObject, pouchid, submissionID, formname, _rev, formid) {
		// add the Modal for adding the form
		let arrParent = {};			
		arrParent =	jraObject;	
		arrParent.jra_hazard_actions=[]
		arrParent.jra_general_actions=[]
		let arrIDs=[];
		arrIDs.push({'_id' : pouchid.formid, '_rev' : _rev});
		if(debug) console.dir(arrParent);
		   
		if(submissionID){
			await rmmDbDraft.createIndex({
				index: {fields: ['submissionID', 'formname']}
			}).then(function(response)	{
				if(debug) console.log('ReIndexed db');
			}).then(function(doc){

				rmmDbDraft.find({selector: {
					'submissionID':submissionID ,
					'formname':  {"$ne": formname} 
				},
				fields: ['formdata', '_id', '_rev','formname']
				
				}).then(function(doc)	{
					arrID=[]
					for(s of doc.docs)	{
						arrIDs.push({'_id' : s._id, '_rev' : s._rev})
						if(s.formname=='General Action'){
							arrParent.jra_general_actions.push(JSON.parse(s.formdata))
						}
						else if(s.formname=='Hazard Report'){
							arrParent.jra_hazard_actions.push(JSON.parse(s.formdata))
						}
					}
					arrParent=changePropertyNames(arrParent)
					if(debug) console.log('arrIDs');	
					if(debug) console.dir(arrIDs);	
				}).then(function(doc){
					dbSofvieRMM.get(pouchid.formid).then(function(doc) {
						if(form.formid.value == 131042 || form.formid.value == 349935)	{
							if(debug) console.log('skipping Pouch exists check because of Hazard Action')
							throw true
						}
						console.error('addForm: Commit Found ID: ' + pouchid.formid)
						alert('You cannot save this form. This id already exists\r\nID = ' + pouchid.formid )
						//Reset disabled stated on Commit/Save button
						$('#saveEnable').prop('checked', false)
						$('#submit').prop("disabled","disabled")
						
						return false;
					}).catch((err) => {
						dbSofvieRMM.put({
							_id: pouchid.formid,
							submissionID: submissionID,
							formname: formname,
							formdata: arrParent,
							timestamp: +new Date
						})
						.then(function(response) {
						// Check to see if this was from a draft, if so, delete the draft copy.
						for(s of arrIDs){
							if(debug)	console.log('s._id: ' + s._id)
							rmmDbDraft.get(s._id).then(function(doc) {
								if(debug) console.log('addForm: Draft Found ID (to delete): ' + s._id)
								return rmmDbDraft.remove(
									doc._id, 
									doc._rev
								).then((data)=>{
									window.sessionStorage.removeItem('modalsubmit')
									if(debug){
									}
								})
							}).catch(function (err) {
								console.warn('ERROR or nothing to delete from drafts: ' + err)
							})
							setTimeout(()=>{
								submitSuccessModal()
							}, 500)
						}
			
					// Remove validation to eliminate issue with selects showing invalid styling after form submission				
					function submitSuccessModal() {
						$(`form.validated`).removeClass('was-validated')
						// Display the success modal (addForm is async, so we put this modal inline)
						formModal.setModalElements(`success`, `modalText`, i18next.t("1425"))
						formModal.setModalElements(`success`, `modalTitle`, i18next.t("1424"))
						let buttons = ``
						if(checkJRAformAccess()){
							buttons += `<a role="button" class="px-1 flex-fill btn btn-outline-success waves-effect repeatform translate" data-i18n="1426" notes="Create Another"></a>`
						}
						buttons +=`<a role="button" class="px-1 flex-fill btn btn-success waves-effect tohomepage translate" data-i18n="1405" notes="OK"></a>`
						formModal.setModalElements(`success`, `modalButtons`, buttons)

						formModal.handleModal(`success`)
						$(`.modal-footer .repeatform`).click(() => {
							formModal.hideModal()
							location.reload()
						})
						$(`.modal-footer .tohomepage`).click(() => {
							formModal.hideModal()
							window.open($('#parentpage').attr('url'), '_self')
						})
						return true
					}

				}).then(()=>{
					checkOnline().then((status)=>{
						syncForm("RMM","From the Form Handler")
					}).catch((err)=>{})
				}).catch(function (err) {
					// This rec does not exist in the specified db, save it.
					console.error('AddForm: Error Committing Data: ' + err)
					return false;
				})
				})
			})
			}).catch(function (err)	{
				console.error('Error finding child form')
				console.error(err)
				return false
			})
		// End submissionid check
		}
		return false
	}

    function updateDraftListSelect(pouchid, type, parentDraft)  {
		let select2LanguageFunction = window[`sofvie_select2_languages_${selectedLanguage}`];
		if (!(typeof select2LanguageFunction === "function")){
			select2LanguageFunction = {}
			console.error("Failed to get Select2 Translations")
		}

		if($('#currentDraft').val() !== pouchid){
		    $("#draft").select2('destroy'); 
		    getRADraftList('#draft')
		    $('#draft').select2({theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder:""})
		    .on('select2:select', function(){
                reInitializeSelect2Language()
                $(this).parent().find('label').addClass('filled')
            })
		    .on('select2:unselect', function(){
		        if($(".select2-selection__choice")[0]){
		            $(this).parent().find('label').addClass('filled')
		        }else {
		            $(this).parent().find('label').removeClass('filled')
		        }
		    })
		    setTimeout(()=>{
                if(type ==='parent'){
                    $('#currentDraft').val(pouchid)
					$('#draft').val(pouchid).trigger('change')
					$("#draft").parent().find('label').addClass('filled')
                }
				else {
					$('#currentDraft').val(parentDraft)
					$('#draft').val(parentDraft).trigger('change')
					$("#draft").parent().find('label').addClass('filled')
				}
		    },500)
	    }
	}

	function getRADraftList(selectID, url = '') {
		//Check if the url is for an old draft
		if(url.split(' - '))
		{
			let formid = url.split(' - ')[0]
			if(!isNaN(formid))
				formname = null
			else
				formname = url
		}
		else
		{
			formname = url
		}
		if(selectID){	
			rmmDbDraft.allDocs({
				include_docs: true,
				attachments: false
			}).then(function (result) {	
				let count = result.rows.length
				// if there are no drafts do not show the pulldown
				count === 0 ? $('#draft').parent().hide():$('#draft').parent().show()
				$(selectID).empty();
				$(selectID).append($('<option>').text("Select Draft").attr('value', ''));
				$.each(result.rows, function(i, obj){
					if(obj.id.indexOf("_design") == -1 && parseInt(obj.doc.formdata.jra_data.rmm_jra_created_by_per_id) == parseInt(remoteData[2].Employee[0].per_id)){
						$(selectID).append($('<option>').text(obj.key).attr('value', obj.id))
					}
				});
				if(url)	{
					$(selectID).val(url).parent().find('label').addClass('filled')
				}
			}).catch(function (err) {
				console.error(err);
			});
		}	
	}

    function showAlert() {
		if(window.sessionStorage.getItem('modalsubmit') !== 'SUBMITSTOP'){
			startAutoSave()
		}
		document.getElementById("saveDraft").disabled = false;
        if(window.sessionStorage.getItem('modalsave')) {
            window.sessionStorage.removeItem('modalsave')
            } else{
				window.location.href = `/pages/RiskAssessment.php`
        }	
	} 

	function getRADraftData(theForm, theURL = '') {
		// Retrieve selected draft form and populate form	
		countSubFormAttachments(true)
		let selectedDraft = ''
		if(theForm[theForm.selectedIndex]) {
			// Retrieve whatever was selected, and if it has a value, action it
			selectedDraft = theForm[theForm.selectedIndex].value.trim()
		}

		if(theURL) {
			selectedDraft = theURL.trim()
		}

		if(selectedDraft !==  $('#currentDraft').val()) {
			$("#deleteDraft").css('display','block')
			$('#currentDraft').val(selectedDraft)
			$('#draft').val(selectedDraft)
			
			// Get selected item from the db
			rmmDbDraft.get(`${selectedDraft}`).then((result) => {
				// Parse out the form data	
				draftObject = result
				recallJRADraft(draftObject)	
				
			}).catch((err) => {
			  console.error(err)
			})
		} 
 	}

	function putJSONForm(theForm, parsedJSON) {
		let allGalleries = document.getElementsByClassName('photoGallery')
		for (gal in allGalleries) {
			allGalleries[gal].innerHTML = ""
		}

        // remove all images
		$('.singleImage').remove()
		// clear all of the radio buttons
		$(".form-check-input").parent().removeClass('focus active')
		$(".form-check-input").attr('checked', false)

		// Put JSON array data into form values
		//	INPUTS:	theForm = pointer to form
		//					parsedJSON = JSON formatted for data

		let s=1;
		let xcount = 0;
		$.each(parsedJSON, (name, val) => {	

			let fileDateStamp = ''
			let $el = $('[name="' + name + '"]')
			// If we don't have an element, it must be a photo, we'll need to create a hidden field, and a gallery display
			if($el.length === 0)	{	
				let input = document.createElement('input')
				input.type = 'hidden';
				input.classList.add('singleImage')
				input.name = name

				input.id = input.name
				form.appendChild(input)
				$el = $('[name="' + name + '"]')

				let photoComponents = name.split('.');
				fileDateStamp = photoComponents[0].substring(0,19)
				if(photoComponents.length > 1) {
					if(name.substr(-8)!="_comment"){
						document.getElementById(photoComponents[1]).innerHTML += `<div class="col-md-3 col-sm-4 col-6 mb-3 d-flex">
						<div name="${name}GALLERY" id="${name}GALLERY" class="sf-gallery__bg-image" src="${val}" style="background-image: url(${val})">
						<span onclick="removeImg(this);" class="deleteGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-trash-alt"></i></span>
						<span onclick="addComment(this);" class="commentGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-comment"></i></span>
						<span onclick="expandImage(this);" class="displayGalleryImage btn-floating btn-sm btn-secondary"><i class="fas fa-search-plus"></i></span>
						<span class="imageDateStamp text-center font-weight-bold">${moment(fileDateStamp).format('YYYY-MM-DD hh:mm:ss a')}</span>
						</div></div>`
					}
				}
				if(name.substr(-8)=="_comment"){
					if(val){						
						imgs=$el.parent().find("div")
						imgs.each(function( index ){
							if(name.slice(0, -8)==imgs[index].id.slice(0, -7)){
								$(imgs[index]).parent().find(".fa-comment").removeClass('far')  //remove empty comment icon
								$(imgs[index]).parent().find(".fa-comment").addClass("fas")   //add filled comment icon
							}
						});
					}					
				}
				$el.val(val);	
			} else	{
				type = $el.attr('type');
				if(type == undefined)	{
					type = $el[0].tagName;
				}
				switch(type){
					case 'checkbox':
					if(val === "1"){
						$el.val(val)
						$el.attr('checked', 'checked');
						if (typeof initiateCheckBoxOnRecall == 'function') { 
							initiateCheckBoxOnRecall($el);
						}	
					}
						break;
					case 'radio':						
						$el.filter('[value="'+val+'"]').attr('checked', 'checked');
						$el.filter('[value="'+val+'"]').parent().addClass('active')
						if($el.filter('[value="'+val+'"]').val() === 'Action Required'){
							$el.filter('[value="'+val+'"]').parent().parent().nextAll(`.cond-form-check-area:first`).show()
						}
						if($el.filter('[value="'+val+'"]').val() === '1'){
							if ($el.filter('[value="'+val+'"]')[0].classList.contains('radio-check')){
								$el.filter('[value="'+val+'"]').parent().parent().nextAll(`.cond-form-check-area:first`).show()
								if (typeof requiredRadio == 'function') { 
									requiredRadio(1);
								}
							}
						}
						if($el.filter('[value="'+val+'"]').val() === '0'){
							if ($el.filter('[value="'+val+'"]')[0].classList.contains('radio-check')){ 
								if (typeof requiredRadio == 'function') { 
									requiredRadio(0);
								}
							}
						}
						if (typeof initRadioOnCriticalActivityRequirements == 'function') { 
							initRadioOnCriticalActivityRequirements();
						}
						if (typeof initializeRadioButtonOnRecall == 'function') { 
							initializeRadioButtonOnRecall();
						}
						break;
					case 'SELECT':
						SetSelectValue($el[0], val);
						break;
					case 'file':
						break;
					default:
						
						if($el[0].name != 'formname'){
							$el.val(val)
						}

             if (val  && ($el[0].type === 'text' || $el[0].localName === 'textarea' || $el[0].type === 'number') && !$el.parent().find("label").hasClass('active')) {
				$el.parent().find("label").addClass('active');
				}
				if($el.hasClass('modalSignature')){
					let image = $el.val()
					if($el.val()) {
						let s = $el.prev().prev().children()
						s[0].innerHTML = '<i class="fa fa-pen"></i> ' + i18next.t('2243')  //display "RE-SIGN" button
						s[1].classList.remove('d-none')  //display "Comment button"	
						if(s[2]){
							s[2].classList.remove('d-none')   //display "clear buttion"	
						}
						let recall = $el.prev().attr('src', image)
						
						img_notes = $el.attr('id') + '_img_time'
						$(`[notes=${img_notes}]`)[0].parentElement.classList.remove("d-none")
					}

				}	

				if($el.attr('class')=="sig_comment"){   //if there's signature comment
					if($el.val())
					{
						$el.parent().find(".btn-group").children()[1].firstChild.classList.remove("far") //remove empty comment icon
						$el.parent().find(".btn-group").children()[1].firstChild.classList.add("fas")   //add filled comment icon
					}
				}
			}

			if(type != 'hidden')	{
				if(name == 'rmm_jra_job' && checkSiteJob('rmm_jra_site', val))	{
					formHeader.populateJobSelect(document.getElementById('rmm_jra_site'))
					SetSelectValue(document.getElementById('rmm_jra_job'), val);
				}
				if(name == 'level' && checkSiteJob('rmm_jra_job', val))	{
					formHeader.populateLevelSelect(document.getElementById('rmm_jra_site'));
					SetSelectValue(document.getElementById('level'), val); 
				}
			}

			// check if there are scores in the triangle
			if(document.forms[0].workplace_score) {
				workplaceScore = document.forms[0].workplace_score.value
				jobDefScore = document.forms[0].job_definition_score.value
				experienceScore = document.forms[0].experience_score.value
				if(workplaceScore && jobDefScore && experienceScore) {
				drawSafetyTriangle(workplaceScore, jobDefScore, experienceScore)  
				}	
			}
		}
		 // check to see if there is a Dynamic form Function

		});
		try {
			populateDynamicForm()
		}
		catch(err) {
			//console.log("this is the Error Message: ", err.message)
		}

		try {

		populateEquipmentDynamicForm()
		}
		catch(err) {
			//console.log("this is the Error Message: ", err.message)
		}
	}

	function SetSelectValue($el, value) {
		// Set the value in the options list of the select box to selected, can be a | delimited array.
		arrLen = $el.options.length;
		let arrKeys = value.split('|');
		$('#' + $el.name).val(arrKeys);
		if($el.classList.contains('score')){
			$('#' + $el.name).val(fixMultiSelects(arrKeys))
		}
		trigger = true	
		if($el.name==='rmm_jra_site' || $el.name==='rmm_jra_job'){
			trigger = checkSiteJob($el.name, value) 
		}
		if(trigger){
			$('#' + $el.name).trigger('change');
			$('.select2-search__field').attr('placeholder', i18next.t("2346"))
			if (arrKeys != '') {
				addClassFilled($el.name)
			}
		}    
		return;
	}

	function checkSiteJob(name, value){
		trigger = true	
		if(name==='rmm_jra_site'){
			sites_list = $.parseJSON(localStorage.getItem('siteselectLists'))
			site_names_list = []
			sites_list.forEach((site)=>{
				site_names_list.push(site.rld_id)
			})
			if(site_names_list.includes(parseInt(value)) === false){
				trigger = false
			}			
		}
		if(name==='rmm_jra_job'){
			jobs_list = $.parseJSON(localStorage.getItem('jobselectLists'))
			job_numbers_list = []
			jobs_list.forEach((job)=>{
				job_numbers_list.push(job.rld_id)
			})
			if(job_numbers_list.includes(parseInt(value)) === false){
				trigger = false
			}
		}
		return trigger
	}

	function addClassFilled(name){
		if(name=='level'){
			// checking if site value is available after checkSiteJob function. If not donot fill level and do not add class filled to level. 
			if($( "#site" ).next().next().hasClass( "filled" )){
				$('#' + name).next().next().addClass('filled')
			}
		}
		else{
			$('#' + name).next().next().addClass('filled')
		}
	}


	// Set canvas size dynamically to match camera orientation
	// Set the canvas size on page load
	window.onload = pageOrientation
	// Set the canvas size when page orientation changes
	window.addEventListener("orientationchange", pageOrientation)

	function pageOrientation() {
		let canvasElement = document.querySelectorAll("canvas[id^=canvas]"); 
		setTimeout(() => {
			canvasElement.forEach((canvas) => {
			canvas.setAttribute("width", "480")
			canvas.setAttribute("height", "640")

			if (window.innerWidth > window.innerHeight) {
				canvas.setAttribute("width", "640")
				canvas.setAttribute("height", "480")
			}
			})
		}, 1000)
	}

	function photoChangeEvent(camera, mode='parent', canvas = 'canvas') {

		camera.addEventListener('change',(e)=>{
			$("#filespinner").removeClass('d-none')

			let allfiles = e.target.files
			let allowedFileTypes = ['image/png','image/jpeg','image/bmp','image/gif','image/webp']
			let invalidFile = false
			let imagePromises = []
			
			for(let i = 0; i < allfiles.length; i++) {
				if(allowedFileTypes.includes(allfiles[i].type)) {
					// Add reduceBase64 promise to array
					imagePromises.push(
						reduceBase64(allfiles[i],e, mode, canvas).then((result) => {
							if(!result)
								invalidFile = true
						})
					)
				}
				else {
					invalidFile = true
				}
			}

			// Wait for all images to be processed
			Promise.all(imagePromises).then(() => {
				$("#filespinner").addClass('d-none')

				if(invalidFile)
					showPictureWarning(mode)
			})

			if(imagePromises == [] && invalidFile)
			{
				$("#filespinner").addClass('d-none')					
				showPictureWarning(mode)				
			}
				
		})
	}

	function showPictureWarning(mode) {
		if(mode != 'parent') {
			formModal = new SofvieModal('pictureWarningModal')
			formModal.handleModal('pictureWarning')
		} else {
			formModal = new SofvieModal()
			formModal.handleModal('pictureWarning')
		}
		$('.confirmValidation').click(()=>{
			closeModal(formModal)
		})
	}

	function removeModalImg(imgWrapper) {
        const theElements = {
          modalTheme: `modal-danger`,
          modalAlert: `fa-times-circle`,
          modalTitle: i18next.t("1411"), // Delete Image
          modalText: i18next.t("1412"), // This action is permanent. Are you sure you want to delete this Image?
          modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-danger waves-effect"><span class='translate' data-i18n="1257" note="Cancel"></span></a>
          <a role="button" id='deleteModalImageConfirm' class="px-1 flex-fill btn btn-danger waves-effect confirm"><span class='translate' data-i18n="1379" note="Yes"></span></a>`
        };
        showAlertModal($("#child-form")[0], "posModal", "warning", theElements);
    
        $("#deleteModalImageConfirm").click(() => {
          if(imgWrapper.parentNode.parentNode.parentNode.children.length === 1){
            imgWrapper.parentNode.parentNode.parentNode.parentNode.parentNode.classList.add('invalid')
           }
           imgWrapper.parentElement.parentElement.remove()
           picInput = imgWrapper.parentElement.getAttribute("name");
           picInput = picInput.replace(/GALLERY+$/, '')
           element = document.getElementById(picInput)
		   element.nextElementSibling.remove();
		   element.parentNode.removeChild(element)
          $('#alertModalShow').hide()
        })
	 }
	 
	async function reduceBase64(file, element, mode='parent', canvas_id = 'canvas') {
		return new Promise((resolve, reject) => {

			let fileDateStamp =  moment(file.lastModified)
			
			let removeFunction = `removeImg`
			if(mode !== 'parent') {
				removeFunction = `removeModalImg`
			}

			if(file) {
				let canvas = document.getElementById(canvas_id);
				let img = document.createElement("img");
				let reader = new FileReader();
				reader.readAsDataURL(file);
				reader.onload = function(e) {
					img.src = e.target.result

					img.onerror = function(e) {
						element.target.value = null
						resolve(false)
						return
					}

					img.onload = function(e) {
						let ctx = canvas.getContext("2d");
						ctx.drawImage(img, 0, 0);
						
						let MAX_WIDTH = 1200;
						let MAX_HEIGHT = 1200;

						let width = img.width;
						let height = img.height;
						if (width > height) {
							if (width > MAX_WIDTH) {
								height *= MAX_WIDTH / width;
								width = MAX_WIDTH;
							}
						} else {
							if (height > MAX_HEIGHT) {
								width *= MAX_HEIGHT / height;
								height = MAX_HEIGHT;
							}
						}
						canvas.width = width;
						canvas.height = height;
						ctx = canvas.getContext("2d");
						ctx.drawImage(img, 0, 0, width, height);

						// Check if the image is corrupt
						try {
							if(ctx.getImageData(0, 0, width, height).data.every(item => item === 0)) {
								element.target.value = null
								resolve(false)
								return
							}
						} 
						catch (e){
							element.target.value = null
							resolve(false)
							return
						}
						
						
						let dataurl = canvas.toDataURL("image/jpeg");
						if(sofvieBrowserVersion === "Safari" || dataurl.length < 20){
							dataurl = img.src
						}

						// now Process
						let elemname = element.target.parentNode.parentNode.parentNode;
						let galleryname = elemname.querySelector('.photoGallery')
						let myphotoName = getUniqueModalPhotoName(galleryname.id, elemname.id, fileDateStamp.format('YYYY-MM-DD HH:mm:ss'))
						// now get the file name
						galleryname.innerHTML += `<div class="col-md-3 col-sm-4 col-6 mb-3 d-flex">
						<div name="${myphotoName}GALLERY" id="${myphotoName}GALLERY" class="sf-gallery__bg-image" src="${dataurl}" style="background-image: url(${dataurl})">
						<span onclick="${removeFunction}(this);" class="deleteGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-trash-alt"></i></span>
						<span onclick="addComment(this);"class="commentGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-comment"></i></span>
						<span onclick="expandImage(this);" class="displayGalleryImage btn-floating btn-sm btn-secondary"><i class="fas fa-search-plus"></i></span>
						<span class="imageDateStamp text-center font-weight-bold">${fileDateStamp.format('YYYY-MM-DD hh:mm:ss a')}</span>			
						</div></div>`

						let input = document.createElement("input");
						input.setAttribute("type", "hidden");
						input.setAttribute("name", myphotoName);
						input.setAttribute("id", myphotoName);
						input.setAttribute("value", dataurl);
						galleryname.appendChild(input);

						let commentInput = document.createElement("input");
						commentInput.setAttribute("type", "hidden");
						commentInput.setAttribute("name", myphotoName+'_comment');
						commentInput.setAttribute("id", myphotoName+'_comment');
						galleryname.appendChild(commentInput);

						element.target.value = null
						if (typeof drawSafetyTriangle !== 'undefined' && typeof drawSafetyTriangle === 'function') {
							window.dispatchEvent(new Event('resize'))
						}
						
						resolve(true)
					}
				}
			} else {
				resolve(false)
			}
			
		})
	}

	function expandImage(imageInput) {
		let selectedImage = imageInput.parentElement.getAttribute("src")
		let imageTag = imageInput.parentElement.getAttribute("name").replace('GALLERY',"")
		const showPictureModal = 
		`<div class="modal fade" id="openPictureModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
		  	<div class="modal-dialog modal-notify modal-info m-0" role="document" style="max-width:100vw;" >
		    	<div class="modal-content bg-dark" style="height:100vh; overflow:hidden;">
			    	<div class="modal-body p-0">
						<form method="post" action="" class="camModal">
							<span id="theCanvasSpan" class="displayMainImage d-flex" style:"width:100%;"><canvas src="${selectedImage}" style="max-width:100vw; max-height:100vh" id="theCanvas" class="align-self-center"><canvas></span>
              				<div class="text-center buttonArea d-flex justify-content-center position-fixed w-100" style="bottom:20px; z-index:1;">
				    			<div class='btn-floating btn-white' id="closeCapture"><i class="fas fa-times"></i></div>
								<div class='btn-floating btn-white' id="saveCapture"><i class="fas fa-save"></i></div>
								<div class='btn-floating btn-white' id="clearCapture"><i class="fas fa-eraser"></i></div>
              				</div>

						</form>
         			 </div>
		    	</div>
		  	</div>
		</div>`

		$("#openPicture")
		.empty()
		.append(showPictureModal);
		$('#closeCapture').click(()=>{
			$('#openPictureModal').remove()
			$('.modal-backdrop').first().remove()
			$('body').removeClass('modal-open')
		})
		$("#openPictureModal").modal("show");

		// Markup Images //
		let canvas = document.getElementById("theCanvas");
		let ctx = canvas.getContext("2d");
		let image = new Image();
		image.src = selectedImage
		let MAX_WIDTH = 1200;
		let MAX_HEIGHT = 1200;
		let width = image.width;
		let height = image.height;
		if (width > height) {
		if (width > MAX_WIDTH) {
			height *= MAX_WIDTH / width;
			width = MAX_WIDTH;
		}
		} else {
		if (height > MAX_HEIGHT) {
			width *= MAX_HEIGHT / height;
			height = MAX_HEIGHT;
		}
		}
		canvas.width = width;
		canvas.height = height;
		ctx.drawImage(image, 0, 0);

		let pos = { x: 0, y: 0 };
		document.addEventListener('mousemove', draw);
		document.addEventListener('mousedown', setPosition);
		document.addEventListener('mouseenter', setPosition);
		document.addEventListener('touchmove', draw);
		document.addEventListener('touchstart', setPosition);
		document.addEventListener('touchend', setPosition);

		let factorX = canvas.width / document.documentElement.clientWidth
		let factorXPoint = canvas.width / document.documentElement.clientWidth
		factorX = factorX > 1 ? factorX : 1
		factorXPoint = factorXPoint > 1 ? factorXPoint : 1
		let canvasHeight = canvas.height / factorX
		let factorY =  canvasHeight / document.documentElement.clientHeight 
		factorY = factorY > 1 ? factorY : 1
 		if(factorY > factorX && factorX == 1) {
			factorX = factorY * factorX
		}

		// new position from mouse event
		function setPosition(e) {
			if(e) {
				if(e.type != "touchstart" && e.type != 'touchend' && e.type != 'touchmove')
				{
					pos.x = e.clientX * factorX
					pos.y = e.clientY * factorX
				}
				else {
					pos.x = e.changedTouches[0].clientX  * factorXPoint * factorY
					pos.y = e.changedTouches[0].clientY  * factorXPoint * factorY
				}
			}

		}

		function draw(e) {
			// mouse left button must be pressed
			if(e.type != "touchstart" && e.type != 'touchend' && e.type != 'touchmove')
			{
				if (e.buttons !== 1) return;
			}
			ctx.beginPath(); // begin
			ctx.lineWidth = 5;
			ctx.lineCap = 'round';
			//ctx.globalAlpha = 0.04;
			ctx.strokeStyle = 'red';
			ctx.moveTo(pos.x, pos.y); // from
			setPosition(e);
			ctx.lineTo(pos.x, pos.y); // to
			ctx.stroke(); // draw it!
			}

		$('#saveCapture').click(()=>{
			finalImage = canvas.toDataURL("image/jpeg")
			imageInput.parentElement.setAttribute("src", finalImage)
			imageInput.parentElement.setAttribute("style",`background-image: url(${finalImage})`)
			document.getElementsByName(imageTag)[0].value = finalImage
			$('#openPictureModal').remove()
			$('.modal-backdrop').first().remove()
			$('body').removeClass('modal-open')
		})

		$('#clearCapture').click(()=>{
			ctx.drawImage(image, 0, 0)
		})


		// resize canvas
		$(window).resize(function(){
			factorX = canvas.width / document.documentElement.clientWidth
			factorX = factorX > 1 ? factorX : 1
			factorY =  canvasHeight / document.documentElement.clientHeight 
			factorY = factorY > 1 ? factorY : 1
			if(factorY > factorX && factorX == 1) {
				factorX = factorY * factorX
			}
		})

		// End of Mark up Imaging //
	}

	function getUniqueModalPhotoName(galleryName, photoElemName, fileDateStamp)	{
		let i = 1
		let photoName = `${fileDateStamp}${form.formtype.value}.${galleryName}.|${photoElemName}|${i}|`
		if (document.getElementById(photoName)) {
			i++
			photoName = `${fileDateStamp}${form.formtype.value}.${galleryName}.|${photoElemName}|${i}|`
			while(document.getElementById(photoName)){
					photoName = `${fileDateStamp}${form.formtype.value}.${galleryName}.|${photoElemName}|${i}|`
					i++
				}
		}
		else {
			return photoName
		}
		return photoName
	}

	function addComment(comment) {
		commentId= comment.parentElement.getAttribute("name").slice(0, -7) + '_comment'
		filledComment=document.getElementById(commentId).value

		let deleteButton = ''

		if(filledComment.length > 0 ){
			deleteButton = `<a role="button" class="btn btn-primary text-nowrap waves-effect waves-light" id="deleteImageComment" data-dismiss="modal"><span class='translate' data-i18n="3088" notes="Delete"></span></a>`
		}

		const addCommentModal = 
		`
		<div class="modal" id="imageCaptionModal" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
          <div class="modal-dialog modal-notify modal-info" style="background-color: #0072ce;" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <p class="heading lead"><span class='translate' data-i18n="8917" notes="Image Caption"></span></p>
              </div>
			  
				<div class="modal-body">
					<div class="md-form">
						<textarea name="mycomments" id="mycomments" class="form-control md-textarea" length="1000" maxlength="4000" required></textarea>
						<label for="mycomments"><span class='translate' data-i18n="81" notes="Comments"></span></label>
					</div>	
				</div>
			
			  <div class="modal-footer justify-content-center">
			  	${deleteButton}
			    <a role="button" class="btn btn-primary text-nowrap waves-effect waves-light" id="cancelImageComment" data-dismiss="modal"><span class='translate' data-i18n="1257" notes="Cancel"></span></a>
                <a role="button" class="btn btn-primary text-nowrap waves-effect waves-light" id="saveImageCaptionModal" data-dismiss="modal"><span class='translate' data-i18n="1258" notes="Save"></span></a>
              </div>
			</div>
		  </div>
		</div>
		<div class="modal fade" id="imageCaptionVerificationModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
			<div class="modal-dialog modal-notify modal-danger" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<p class="heading lead"></p>
					</div>
					<div class="modal-body">
						<div class="text-center">
							<i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
							<p class='modal-body-text'></p>
						</div>
					</div>
					<div class="modal-footer justify-content-center">
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade" id="deleteCommentConfirmModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
		<div class="modal-dialog modal-notify modal-danger" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<p class="heading lead"></p>
				</div>
				<div class="modal-body">
					<div class="text-center">
						<i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
						<p class='modal-body-text'></p>
					</div>
				</div>
				<div class="modal-footer justify-content-center">
				</div>
			</div>
		</div>
	</div>
		`
		$("#imageCaption")
		.empty()
		.append(addCommentModal);

		$('.translate').localize()
		$('#mycomments').val(filledComment).trigger('change').parent().find('label').addClass('filled')
		$("#imageCaptionModal").modal("show");
		$("#deleteImageComment").click((event) => {		
			comment_value=document.getElementById(commentId).value= document.getElementById("mycomments").value
			if(filledComment){
				comment_value=filledComment
			}
			if(comment_value){
				const theElements = {
					modalTheme: `modal-danger`,
					modalAlert: `fa-times-circle`,
					modalTitle: i18next.t("9009"), // Delete Comments
					modalText:  i18next.t("3455"), //You are about to delete this comment. Are you sure?
					modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-danger waves-effect"><span class='translate' data-i18n="1257" notes="Cancel"></a>
					<a role="button" id='deleteCommentConfirm' class="px-1 flex-fill btn btn-danger waves-effect confirm"><span class='translate' data-i18n="3088" notes="Delete"></a>`
				}
				let pop = new SofvieModal("deleteCommentConfirmModal");   
				pop.modalSettings.danger = theElements 
				pop.handleModal('danger')
				if(filledComment){
					document.getElementById(commentId).value= document.getElementById("mycomments").value=filledComment
				}
				
				$('.translate').localize()
				$("#alertModalCancel").click(() => {
					closeModal(pop)
					$("#imageCaptionModal").modal("show");
				})
				$("#deleteCommentConfirm").click((event) => {
					event.preventDefault();
					event.stopImmediatePropagation();
					comment_value=document.getElementById(commentId).value= document.getElementById("mycomments").value=''
					comment.firstChild.classList.remove("fas","far")
					comment.firstChild.classList.add("far")
					closeModal(pop)
				})
			}
			else{
				$("#imageCaptionModal").modal("hide");
			}	
		})
		
		$("#cancelImageComment").click((event) => {	
			if(filledComment){
				comment_value=filledComment
				document.getElementById(commentId).value=filledComment
			}
			else{
				comment_value=document.getElementById(commentId).value= document.getElementById("mycomments").value=''
			}
		  })  

		$("#mycomments").click(() => { 
			document.getElementById('mycomments').classList.remove('invalid')
		})

		$("#saveImageCaptionModal").click((event) => { 
			document.getElementById(commentId).value= document.getElementById("mycomments").value
			document.getElementById('mycomments').classList.remove('invalid')
			event.preventDefault(); 
			if(document.getElementById('mycomments').value == ''){
				event.preventDefault();
				event.stopImmediatePropagation();
				let formModal = new SofvieModal("imageCaptionVerificationModal");     
				formModal.handleModal(`validate`)  
				document.getElementById('mycomments').classList.add('invalid')
				$('.translate').localize()
				$('.confirmValidation').click(()=>{
					closeModal(formModal)
				})
			}
			else{
				comment.firstChild.classList.remove("fas","far")
				comment.firstChild.classList.add("far")
				if(document.getElementById(commentId).value){
					comment.firstChild.classList.remove("far")
					comment.firstChild.classList.add("fas")
				}	
			}		
		})

		$(document).on('hidden.bs.modal', function () {
			if($('.modal.show').length){
				$('body').addClass('modal-open');
			}
		});
	}

	function formatDate(date) {
		// Return a human readable, short, date string
		// INPUTS:
		//	a date object (timestamp)
		return date.toLocaleString('en-CA', { timeZone: 'America/Toronto' });
	}

startAutoSave()
