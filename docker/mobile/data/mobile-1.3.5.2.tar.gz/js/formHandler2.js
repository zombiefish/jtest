// Create a ref to our form
let form = document.forms[0]
let cancelTimer = null
let parsedJSON = null
let sofvieBrowserVersion = "Chrome"
// What form field is unique to use as an id.
let primaryKeyField = form.keyField.value
// Name of our Draft selector
let draft = document.getElementById(form.draftField.value)
// Set our debug flag
debug = _DEBUG;

let newDraft = false;

(() => {
	document.addEventListener( "DOMContentLoaded", () =>{// On document loaded
  		sofvieBrowserVersion = detectBrowserVersion()
		try	{// Trigger form handling for Header
			formHeader.formInitialize(document.forms[0])
		} catch(err)	{
			console.warn('formHeader.formInitialize does not exist. \n' + err)
		}

		try	{// Trigger form handling for Body
			formBody.formInitialize(document.forms[0])
		} catch(err)	{
			console.warn('formBody.formInitialize does not exist. \n' + err)
		}

		try	{// Trigger form handling for Footer
			formFooter.formInitialize(document.forms[0])
		} catch(err)	{
			console.warn('formFooter.formInitialize does not exist. \n' + err)
		}

		var DBconfigLoto = {
            DbName: 'sofvieLoto',
            RemoteSync: false,
            commitDBName: _SYNCCOUCHDB,
            commitRemoteSync:  _SYNCDOMAIN + ':' + _SYNCPORT + '/' + _SYNCCOUCHDB
        }

		// Open connection to both DB's and leave them open (commitDB needs to be opoen to sync)
		dbDraft = new PouchDB(DBconfig.draftDbName, {auto_compaction: true})// Create a ref to the local Draft DB
        dbSofvieForm = new PouchDB(DBconfigLoto.DbName, {auto_compaction: true})
		openCacheData().then((rdata) => {
			getFormDraftList(draft)// Handle the draft list select box
		})

		// Save a draft (local only) copy of this form.
		setTimeout(() =>{ 	
			document.getElementById("saveDraft").addEventListener( "click", function( e ) {	// And a hook to form submission.
				stopAutoSave()
				document.getElementById("saveDraft").disabled = true
				e.preventDefault();
				if(formHandle(form, 'draft')){
					formId = form.querySelectorAll( "#formid" )[0].value
					submittedby = form.querySelectorAll( "#submittedby" )[0].value
					let json = toJSONString( form )
					if(formId=="372458"){     //daily drilling report
						json = json.replace(/"draft".*"submissionId"/ ,'"submissionId"')
					}
					if(debug) console.log(json)// Log it to the console
					if(primaryKeyField)	{// Is our unique key field identified
						key = draftName(primaryKeyField)
						if (form.checkValidity() === false) {// Was the form valid?
							e.preventDefault()// No, prevent firing
							e.stopImmediatePropagation()// and propogation
						} 
						form.classList.add('was-validated')// Otherwise, mark it as valid
						// Then save the JSON to our localDB

						addFormDraft(json, key, form.submissionId.value, form.formname.value, 'yes', 'parent', submittedby )
						return
					} else	{
						alert('No primary keyfield defined for this form, please contact admin')
					}
				}
			}, false)// End event handler for draft
		},1)
		// Save a local, and remote, copy of the form.

		setTimeout(function(){ 
			form.addEventListener( "submit", function( e ) {// And a hook to form submission.
				e.preventDefault()	
				window.sessionStorage.setItem('modalsubmit','SUBMITSTOP')	
				autoValidateSave()// Stop normal processing of this form, we'll handle it
				stopAutoSave()

				// Handle any post processing to the form component
				if(formHandle(form, 'full')){// Terminate and validate form
					let json = toJSONString( form )// Convert the form submission to usable JSON 
					if(primaryKeyField)	{
						let key = draftName(primaryKeyField)// Build a key for this submission
						/// Start of Modal for Saving the Submission

						formModal = new SofvieModal()// initialize the Modal 
						formModal.handleModal(`warning`) // Display the Warning Modal
						$(`.modal-footer .confirm`).click(() => {// create event listener for OK button
							formModal.hideModal()
							// Submit to Pouch //
							let formStatus = addForm( json, key, form.submissionId.value, form.formname.value, form._rev.value, form.formid.value);
							if (formStatus) {} 
							else {
								$('#theModal').one('hidden.bs.modal', (e) => {
									formModal.setModalElements(`danger`, `modalText`, `The form submission failed.`)
									formModal.setModalElements(`danger`, `modalTitle`, `Form Submission Failure`)
									formModal.setModalElements(`danger`, `modalButtons`, `<a role="button" class="btn btn-outline-danger waves-effect" data-dismiss="modal">OK</a>`)
									formModal.handleModal(`danger`)
									startAutoSave()
								})
							}
						})
						
						$(`#cancelSubmit`).click(() => {  
							window.sessionStorage.removeItem('modalsubmit','1')
							startAutoSave()
						})

						// End of Modal Submit
						// Then save the JSON to our localDB
					} else	{
						alert('No primary keyfield defined for this form, please contact admin')
					}
				}	// End Form Valid
			}, false)
		}, 1000)// End Event Handler for submit
	})
})()

function draftName(primaryKeyField)	{
	// Build a unique form identifier for saved draft of 'this' form, based on the contents of the hidden keyField
	// All draft field names contain the timestamp and site.
	// INPUTS:
	//	primaryKeyField - the primaryKeyField values, can be a pipe '|' seperated array for compound id's.
	
	// Create a base name for this form (name + formatted timestamp)
	// if the form has PARENT in IT just cut it off - RR
	let fname = form.formname.value
	if(fname.indexOf(' PARENT') >= 0){
		fname = form.formname.value.slice(0, -7)
	}
	let draftTitle = ''
	let formattedDate = moment(form.startFormTimeStamp.value).format('YYYY-MM-DD hh:mm:ss a')
	
	let arrKeys = primaryKeyField.split('|')	

	arrKeys.forEach((element) => {	
		if(form[element].options && form[element].options[form[element].selectedIndex]){
			draftTitle = draftTitle + ' ' + form[element].options[form[element].selectedIndex].innerHTML
		}
		else{
			draftTitle = draftTitle + ' ' + form[element].value	
		}	
	})

	if(debug) console.log(draftTitle)	

	return {
		"title": draftTitle.trim(),
		"formid": `${form.formid.value} - ${formattedDate}`
	}

}
	
function getMobileOperatingSystem() {
	let userAgent = navigator.userAgent || navigator.vendor || window.opera;

	// Windows Phone must come first because its UA also contains "Android"
	if (/windows phone/i.test(userAgent)) {
		return "Windows Phone"
	}

	if (/android/i.test(userAgent)) {
		return "Android"
	}

	// iOS detection from: http://stackoverflow.com/a/9039885/177710
	if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
		return "iOS"
	}

	return "unknown"
}

function disableDraftKeys(primaryKeyField)	{
	// Disable our unique form identifiers after recalling a draft so that they cannot change (if they change, you cannot update/save)
	// All draft field names contain the timestamp and site.
	// INPUTS:
	//	primaryKeyField - the primaryKeyField values, can be a pipe '|' seperated array for compound id's.
	
	let arrKeys = primaryKeyField.split('|')// Retrieve and split our key elements from the form
		arrKeys.forEach((element) => {// Iterate over them
			if(document.getElementById(element).tagName == 'SELECT')	{// Are we a select box?
				document.getElementById(element).parentNode.children[1].disabled = true // Point to the customized select box
			}	else{
				form[element].disabled = true// Disable each element so that they cannot be changed.
			}
	})
}

function formatDate(date) {
	// Return a human readable, short, date string
	// INPUTS:
	//	a date object (timestamp)
	// RMR: 20190809 - Enforce locale definitions (these should come from env). To solve issue with different date formats being submitted.
	return date.toLocaleString('en-CA', { timeZone: 'America/Toronto' })// Just return the date as defined by machine settings
}

function formHandle(form, submissionType){	
	// Handle the form.  First perform any post processing before validation.
	try	{// Call any form termination code in the header
		formHeader.formTerminate(form)
	} catch(err)	{
		console.warn('formHeader.formTerminate does not exist. \n' + err)
	}
	try	{// Call any form termination code in the body
		formBody.formTerminate(form)
	} catch(err)	{
		console.warn('formBody.formTerminate does not exist. \n' + err)
	}
	try	{
		formFooter.formTerminate(form)// Call any form termination code in the footer
	} catch(err)	{
		console.warn('formFooter.formTerminate does not exist. \n' + err)
	}

	// Handle validation of the form component, we always validate the form header because the data is used in defining the draft.
	try	{
		headForm = formHeader.formValidate(form)// Call any form validation code in the header
		if(headForm === false)	{// If the header failed, abort
			return false// Return failure to abort the event
		}
	} catch(err)	{
		console.error('formHeader.formValidate: ' + err)
		return false
	}

	if(submissionType !== 'full')	{// Handle the special case of child forms (HAP/PID) using their respective form ids
		if(form.formid.value == 131042 || form.formid.value == 166071 || form.formid.value == 131200)	{					                     // We must always validate child forms whether submit or draft
			try	{// Call any form validation code in the header
				return formFooter.formValidate(form)
			} catch(err)	{
				console.error('formFooter.formValidate: ' + err)
				return false
			}
		}
		
	}	 else	{													// We can skip the body and footer validation for draft saves unless its a subform then we must force  validation
		try	{															// Call any form validation code in the body
			formBody.formValidate(form)	
		} catch(err)	{
			console.error('formBody.formValidate : ' + err)
			return false
		}
		try	{				
			return formFooter.formValidate(form)	                                  	                           // Call any form validation code in the footer
		} catch(err)	{
			console.error('formFooter.formValidate:' + err)
			return false
		}
	}
		document.getElementById("saveDraft").disabled = true
	return true
}

function toJSONString( form ) {																						// Convert form submission to JSON string
	// Extract all form elements, iterate over, extracte values, save as JSON Key:Value pairs
	// INPUTS:
	//	form - form object from the event listener
	let obj = {}																															// Create storage object
	let elements = form.querySelectorAll( "input, select, textarea" )   // Create a reference to all form element types
	for(let i = 0; i < elements.length; ++i ) {
		let element = elements[i]	
		// Extract the element type
		let name = element.name.substring(element.name.indexOf('~') + 1, 120)                                    // Extract the name, stripping off everything to the left of the tilde. This is a kludge to work around dupe form element names in modals.
		let value = element.value																					// The value

		if( name ) {																															// If it has a name attribute
			if(!obj[name]) {																												// Has this element already been added?
				if(element.matches('[type="radio"]')) {		
					if(element.checked)	{	
						// Is it checked
						obj[name] = element.value;																	// Assign the associated value to the element
					} 

				} else if (element.tagName == 'SELECT') {															// Is a select box 
						obj[name] = getSelectValues(element)														// Handle if it contains 1 or more selections.
				} else {
					obj[name] = element.value																		// Its another kind of input element
				}
			}
		} 
	// 	if(debug)console.log(name + '=' + obj[name]);																		
																													// Store the values in the storage object
		}
	return JSON.stringify( obj )																					// When were done iterating, convert the object to a JSON string and return it
}
	
function getSelectValues(select) {																					// Parse a select box for one or more selected items
	let result = []																														// Initialize and array to hold our results
	let options = select && select.options																		// Our option values
	let opt																																		// Temp storage

	for (let i=0, iLen=options.length; i<iLen; i++) {														// Iterate over all options
		opt = options[i]																													// Copy the option

		if (opt.selected) {																												// Is it selected?
			result.push(opt.value || opt.text);																			// Push the value onto the array (value maybe the option value, or the option text)
		}
	}
	return result.join('|')																										// Join all the data separated by a comma (comma delimited list)
}	

// Generate unique hidden field name for photo's
function getUniquePhotoName(galleryName, photoElemName)	{
	// Generate a sequential element name as a suffix to photoElemName
	// INPUT :		galleryName - Name of display gallery	
	//						photoElemName = base elem name
	// OUTPUT: 	return unique file base on photoElemName
	let i = 1// Set the starting index
	// Iterate over possible names
	for(i=1; ; i++)	{
		// Create the name
		photoName = form.formtype.value + '.' + galleryName + '.' + photoElemName + i
		// If that name exist?
		if(!document.getElementById(photoName))	{
			break
		}
	}
	// Return the resolved 'next' name
	return photoName
}

// Set canvas size dynamically to match camera orientation
// Set the canvas size on page load
window.onload = pageOrientation
// Set the canvas size when page orientation changes
window.addEventListener("orientationchange", pageOrientation)

function pageOrientation() {
	let canvasElement = document.querySelectorAll("canvas[id^=canvas]")
	// Use timeout to delay the orientation check trigger
	setTimeout(() => {
		canvasElement.forEach((canvas) => {
		canvas.setAttribute("width", "480")
		canvas.setAttribute("height", "640")

		// Check if page orientation is landscape
		if (window.innerWidth > window.innerHeight) {
			canvas.setAttribute("width", "640")
			canvas.setAttribute("height", "480")
		}
		})
	}, 1000)
}

function removeModalImg(imgWrapper) {
	const theElements = {
		modalTheme: `modal-danger`,
		modalAlert: `fa-times-circle`,
		modalTitle: i18next.t("1411"), // Delete Image
		modalText: i18next.t("1412"), // This action is permanent. Are you sure you want to delete this Image?
		modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-danger waves-effect"><span class='translate' data-i18n="1257" note="Cancel"></span></a>
		<a role="button" id='deleteModalImageConfirm' class="px-1 flex-fill btn btn-danger waves-effect confirm"><span class='translate' data-i18n="1379" note="Yes"></span></a>`
	};
	showAlertModal($("#child-form")[0], "posModal", "warning", theElements);

	$("#deleteModalImageConfirm").click(() => {
		if(imgWrapper.parentNode.parentNode.parentNode.children.length === 1){
		imgWrapper.parentNode.parentNode.parentNode.parentNode.parentNode.classList.add('invalid')
		}
		imgWrapper.parentElement.parentElement.remove()
		picInput = imgWrapper.parentElement.getAttribute("name");												// Extract the name of the display image
		picInput = picInput.replace(/GALLERY+$/, '')												          // Strip off the trailing 'GALLERY' indentifier
		element = document.getElementById(picInput)												          // Get the element
		element.nextElementSibling.remove();  													//remove img comment
		element.parentNode.removeChild(element)                                                   //remove img
		$('#alertModalShow').hide()
	})
	}

//Trigger photo delete
function removeImg(imgWrapper) {
	delImg = new SofvieModal()
	delImg.setModalElements('danger', 'modalTitle', i18next.t("1411"))
	delImg.setModalElements('danger', 'modalText', i18next.t("1412"))
	delImg.handleModal('danger')
	$(`.modal-footer .confirm`).click((e) => {
		let closestGallery = imgWrapper.closest(".photoGallery")

		imgWrapper.parentElement.parentElement.remove();
		picInput = imgWrapper.parentElement.getAttribute("name");												// Extract the name of the display image
		picInput = picInput.replace(/GALLERY+$/, '')												          // Strip off the trailing 'GALLERY' indentifier
		element = document.getElementById(picInput);							          // Get the element
		element.nextElementSibling.remove();											//remove img comment
		element.parentNode.removeChild(element);		                               //remove img
		if (closestGallery.innerHTML === "" && closestGallery.closest(".photoImage").hasAttribute("required")) {
			closestGallery.closest(".photoImage").classList.add('invalid')
		}
		$(`#theModal`).modal('hide')
	})

}

function closeModal(modal) {
	let backDrops = $(".modal-backdrop");
	if(backDrops[backDrops.length - 1]) {
		backDrops[backDrops.length - 1].remove();
	}
	modal.hideModal()
}

function addComment(comment) {
	let showSaveButton = ''
	let deleteButton = ''
	commentId= comment.parentElement.getAttribute("name").slice(0, -7) + '_comment'
	filledComment=document.getElementById(commentId).value

	if(filledComment.length > 0 ){
		deleteButton = `<a role="button" class="btn btn-primary text-nowrap waves-effect waves-light" id="deleteImageComment" data-dismiss="modal"><span class='translate' data-i18n="3088" notes="Delete"></span></a>`
	}
	if(comment.parentElement.parentElement.parentElement.parentElement.classList.contains("read-only")){
		showSaveButton = 'd-none'
		deleteButton = ''
	}

	const addCommentModal = 
	`
	<div class="modal" id="imageCaptionModal" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
		<div class="modal-dialog modal-notify modal-info" style="background-color: #0072ce;" role="document">
			<div class="modal-content">
				<div class="modal-header">
				<p class="heading lead"><span class='translate' data-i18n="8917" notes="Image Caption"></span></p>
				</div>
				
				<div class="modal-body">
					<div class="md-form">
						<textarea name="mycomments" id="mycomments" class="form-control md-textarea" length="1000" maxlength="4000" required></textarea>
						<label for="mycomments"><span class='translate' data-i18n="81" notes="Comments"></span></label>
					</div>	
				</div>
			
				<div class="modal-footer justify-content-center">
					${deleteButton}
					<a role="button" class="btn btn-primary text-nowrap waves-effect waves-light" id="cancelImageComment" data-dismiss="modal"><span class='translate' data-i18n="1257" notes="Cancel"></span></a>
					<a role="button" class="btn btn-primary text-nowrap waves-effect waves-light ${showSaveButton}" id="saveImageCaptionModal" data-dismiss="modal"><span class='translate' data-i18n="1258" notes="Save"></span></a>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="imageCaptionVerificationModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
		<div class="modal-dialog modal-notify modal-danger" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<p class="heading lead"></p>
				</div>
				<div class="modal-body">
					<div class="text-center">
						<i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
						<p class='modal-body-text'></p>
					</div>
				</div>
				<div class="modal-footer justify-content-center">
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="deleteCommentConfirmModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
	<div class="modal-dialog modal-notify modal-danger" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<p class="heading lead"></p>
			</div>
			<div class="modal-body">
				<div class="text-center">
					<i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
					<p class='modal-body-text'></p>
				</div>
			</div>
			<div class="modal-footer justify-content-center">
			</div>
		</div>
	</div>
</div>
	`
	$("#imageCaption")
	.empty()
	.append(addCommentModal);

	if(showSaveButton == 'd-none'){
		$("#mycomments").attr('disabled',true)
	}

	$('.translate').localize()
	$('#mycomments').val(filledComment).trigger('change').parent().find('label').addClass('filled')
	$("#imageCaptionModal").modal("show");
	$("#deleteImageComment").click((event) => {		
		comment_value=document.getElementById(commentId).value= document.getElementById("mycomments").value
		if(filledComment){
			comment_value=filledComment
		}
		if(comment_value){
			const theElements = {
				modalTheme: `modal-danger`,
				modalAlert: `fa-times-circle`,
				modalTitle: i18next.t("9009"), // Delete Comments
				modalText:  i18next.t("3455"), //You are about to delete this comment. Are you sure?
				modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-danger waves-effect"><span class='translate' data-i18n="1257" notes="Cancel"></a>
				<a role="button" id='deleteCommentConfirm' class="px-1 flex-fill btn btn-danger waves-effect confirm"><span class='translate' data-i18n="3088" notes="Delete"></a>`
			}
			let pop = new SofvieModal("deleteCommentConfirmModal");   
			pop.modalSettings.danger = theElements 
			pop.handleModal('danger')
			if(filledComment){
				document.getElementById(commentId).value= document.getElementById("mycomments").value=filledComment
			}
			
			$('.translate').localize()
			$("#alertModalCancel").click(() => {
				closeModal(pop)
				$("#imageCaptionModal").modal("show");
			})
			$("#deleteCommentConfirm").click((event) => {
				event.preventDefault();
				event.stopImmediatePropagation();
				comment_value=document.getElementById(commentId).value= document.getElementById("mycomments").value=''
				comment.firstChild.classList.remove("fas","far")
				comment.firstChild.classList.add("far")
				closeModal(pop)
			})
		}
		else{
			$("#imageCaptionModal").modal("hide");
		}	
	})
	
	$("#cancelImageComment").click((event) => {	
		if(filledComment){
			comment_value=filledComment
			document.getElementById(commentId).value=filledComment
		}
		else{
			comment_value=document.getElementById(commentId).value= document.getElementById("mycomments").value=''
		}
		})  

	$("#mycomments").click(() => { 
		document.getElementById('mycomments').classList.remove('invalid')
	})

	$("#saveImageCaptionModal").click((event) => { 
		document.getElementById(commentId).value= document.getElementById("mycomments").value
		document.getElementById('mycomments').classList.remove('invalid')
		event.preventDefault(); 
		if(document.getElementById('mycomments').value == ''){
			event.preventDefault();
			event.stopImmediatePropagation();
			let formModal = new SofvieModal("imageCaptionVerificationModal");     
			formModal.handleModal(`validate`)  
			document.getElementById('mycomments').classList.add('invalid')
			$('.translate').localize()
			$('.confirmValidation').click(()=>{
				closeModal(formModal)
			})
		}
		else{
			comment.firstChild.classList.remove("fas","far")
			comment.firstChild.classList.add("far")
			if(document.getElementById(commentId).value){
				comment.firstChild.classList.remove("far")
				comment.firstChild.classList.add("fas")
			}	
		}		
	})

	$(document).on('hidden.bs.modal', function () {
		if($('.modal.show').length){
			$('body').addClass('modal-open');
		}
	});
}

function getFormDraftList(selectID, url = '') {
	if(url.split(' - '))						//Check if the url is for an old draft
	{
		let formid = url.split(' - ')[0]
		if(!isNaN(formid))
			formname = null
		else
			formname = url
	}
	else
	{
		formname = url
	}
	// Is draft enabled?
		if(selectID)	{
		// Get all matching drafts for this form name 
		dbDraft.allDocs({
			include_docs: true,
			attachments: false,
			startkey: formname || form.formid.value,
			endkey: (formname || form.formid.value) + '\ufff0',
			submittedId: form.querySelectorAll( "#submittedby" )[0].value
		}).then(function (result) {	
			let count = 0	
			$.each(result.rows, function(i, obj){
				// Iterate over the results 
				fid = JSON.parse(obj.doc.formdata).formid
				if( fid !== '131042' && fid !== '166071') {
					if(form.formid.value == 777777) { // Custom Form check 
						let customForm = JSON.parse(obj.doc.formdata).customForm
						if(window.localStorage.getItem('customForm') == customForm)
						count++
					}
					else
						count++
				}
			})
			// if there are no drafts do not show the pulldown
			count === 0 ? $('#draft').parent().hide():$('#draft').parent().show()
			// handle result
			// Whack the existing data in the select should be none
			$(selectID).empty()
			// Add a prompt for the first entry
			$(selectID).append($('<option>').text("Select Draft").attr('value', ''))
			
			// Iterate over the results
			$.each(result.rows, function(i, obj){
				let option = obj.doc.formid ? `${lookupFormNameByFormId(obj.key.split(" ")[0])}${obj.key.substr(6)}` : obj.key
				// Iterate over the results 
				fid = JSON.parse(obj.doc.formdata).formid
				if( fid !== '131042' && fid !== '166071' && parseInt(obj.doc.submittedId) == parseInt(form.querySelectorAll( "#submittedby" )[0].value))
				{
					if(form.formid.value == 777777) { // Custom Form check 
						let customForm = JSON.parse(obj.doc.formdata).customForm
						let customFormName = JSON.parse(obj.doc.formdata).customForm_name
						if(window.localStorage.getItem('customForm') == customForm) // Only add to the list if the draft is for this Custom Form
							$(selectID).append($('<option>').text(customFormName + " - " + option).attr('value', obj.id))
					}							
					else
						$(selectID).append($('<option>').text(option).attr('value', obj.id))
				}
			})
			
			if(url)
			{
				$(selectID).val(url).parent().find('label').addClass('filled')
			}
			if (typeof postOpAction !== 'undefined' && typeof postOpAction === 'function') {
				postOpAction()
			}
			
		}).catch(function (err) {
			console.error(err);
		});
	}	
}

function getAllDrafts()	{
	// Retrieve JSON list of saved form drafts
	// Get all matching drafts for this form name 
		dbDraft.allDocs({
		include_docs: true,
		attachments: false,
		startkey: '',
		endkey: '\ufff0'
		// If we got results
	}).then((result) => {
		// handle result
		// Output to console
		if(debug) console.log(result)
		return result.rows
	}).catch((err) => {
		console.error(err)
	})
}

function AddOrRemoveIndividualFromListLoadDraft(){
	// Step1: compare all selected emails in the select list with the 
	// distribution groups.

	// Get a list of selected emils from the select list.
	let selectedEmails = []
	distElementId = '#Report_Distribution1'
	selectedEmails = $(distElementId).select2('data');
	
	// step2: if the emails in the list are all contained in a distribution group then
	// remove the group from the select list.

	// Clean selected emails.
	for (let i in selectedEmails) {
		selectedEmails[i] = selectedEmails[i]["id"]
	}
	// loop through the groups list.
	for(let l=0;l<distributionGroupList.length;l++){
		let group = distributionGroupList[l].email.split(",")
		group.pop()
		let groupName = distributionGroupList[l].name

		// loop through the selected emails list in the group loop and 
		// find the emails.
		let found = true
		for(let i in group){
			if (!selectedEmails.includes(group[i])){
				found = false
				break
			}
		}
		// let found = group.every((val) => {
		// 	selectedEmails.includes(val)
		// });
		if(found){
			// remove the group from the list.
			$(distElementId + " option[value='" + group.join(",") + ",']").remove();
		} else {

			// add the group back.
			let opt = new Option(groupName,distributionGroupList[l].email)
				
			// only add the group name back if it is not already added.
			let found2 = false
			let opts = $(distElementId).find("option")
			for(let c=0;c<opts.length;c++){
				if(opts[c].text == distributionGroupList[l].name){
					found2 = true
				}
			}
			if(!found2){
				$(distElementId).append(opt).change();
			}
		}
	
	}
}

function getFormData(theForm, theURL = '') {
	if(newDraft) // We dont want to load the draft if this is the first draft save
		return

	// Retrieve selected draft form and populate form	
	let selectedDraft = ''
	if(theURL)
		selectedDraft = theURL.trim()
	if(theForm[theForm.selectedIndex]) {
		// Retrieve whatever was selected, and if it has a value, action it
		selectedDraft = theForm[theForm.selectedIndex].value.trim()
	}
	if(selectedDraft) {
		$("#deleteDraft").css('display','block')
		$('#currentDraft').val(selectedDraft)
		// Get selected item from the db
		dbDraft.get(`${selectedDraft}`).then((result) => {
			// Parse out the form data
			parsedJSON = JSON.parse(result.formdata)
			if(parsedJSON.formLanguage!=selectedLanguage){
				document.getElementById("select2-draft-container").innerHTML= ''
				$('label[for="draft"]').removeClass("filled")
				popDraftLoadAlert(parsedJSON.formLanguage)
				return
			}
			reCallRepeatSections(parsedJSON)
			if(debug)
				console.dir(parsedJSON)
			clearAllQuestions()
			clearAllSignatures()

			if (typeof draftPreProcess == 'function') {
				draftPreProcess(parsedJSON)
			}
			openSelectCacheData().then(()=>{
					putJSONForm(theForm, parsedJSON)
					// Plug in the pouchdb value for revision
					document.forms[0]._rev.value = result._rev
					document.forms[0]._id.value = result._id	
					if (typeof draftPostProcess === 'function') {
						draftPostProcess(parsedJSON);
					}
					// Plug in the pouchdb value for the unique key
					if (typeof postOpAction !== 'undefined' && typeof postOpAction === 'function') {
					postOpAction()
					}

					AddOrRemoveIndividualFromListLoadDraft()
					countSubFormAttachments(true)
				})
			}).catch((err) => {
			console.error(err)
			})
	} else	{
		// A blank option was selected.
	}
}

	function reCallRepeatSections(parsedJSON) {
	if(document.getElementById('numCrews')){
		// check to see if there is a Dynamic form Function
		let repeatSections=[
			{totalNum:'totalCrews',num:'numCrews',functionName:'populateDynamicForm'},
			{totalNum:'totalEquipments',num:'numEquipments',functionName: 'populateEquipmentDynamicForm'},
			{totalNum:'totalLocations',num:'numLocation',functionName:'populateLocationDynamicForm'},
			{totalNum:'totalAirTest',num:'numAirTest',functionName:'populateGasTestDynamicForm'},
			{totalNum:'totalUsed',num:'numUsed',functionName:'populateMaterialUsed'},
		]

		for(repeatSection of repeatSections){
			try {
				let totalNum = parseInt(parsedJSON[repeatSection.totalNum])
				let num = parseInt(parsedJSON[repeatSection.num])
				let functionName = eval("(" + repeatSection.functionName + ")")
				functionName(num,totalNum)
			}
			catch(err) {
			}
		}
		if(parsedJSON.formname === i18next.t('2246')) {  			//'CONFINED SPACE ACTIVITY LOG'
			var numTime=0
			$.each(parsedJSON, (name, val) => {	
				if(name == 'employeeTimeinTimeout')	{
					numTime=val
				}
			});
			numTimeArray=numTime.split(',')
			for (employee=1;employee<=numTimeArray.length;employee++){
				for (times = 1; times <= numTimeArray[employee-1] - 1; times++){
					document.getElementsByClassName('addTimeCycle')[employee-1].click()			
				}				
			}
		}

		initializeSelect2Dynamic()
		formHeader.populateEmployeeSelect()	
		switch(parsedJSON.formid){
			case '333840':   //ShiftReportConstruction
				formHeader.populateHoursSummarySelect()
				formHeader.populateAllEquipmentSelect()
				break
			case '333857':  //ShiftReportCraigLogistics
				formHeader.populateHoursSummarySelect()
				formHeader.populateAllEquipmentSelect()
				break	
			case '333851': //ShiftReportDevlopment 
				formHeader.populateHoursSummarySelect()
				formHeader.populateAllEquipmentSelect()
				formHeader.populateEmployeePositionSelect()
				break
			case '372438': //TFSR 
				formHeader.populateServiceTypeSelect()
				formHeader.populateEquipmentStatusSelect()
				break
			case '372348': //TimeSheet
				formHeader.populateEmployeeOccupationSelect()
				break
			case '372418': //WorkCard  
				formHeader.populateWorkAccomplishedSelect()
				break
			case '372408': //A&M Shift Report
				formHeader.populateAMTaskContractSelect()
				formHeader.populateAMTaskTypeSelect()
				formHeader.populateAMSuppliesTypeSelect()
				break
			case '372458': //Daily Drilling Report
				formHeader.populateDrillingTimeDelaysCodeSelect()
				formHeader.populateDrillingBitSizeSelect()
				formHeader.populateDrillingCodeSelect()
				formHeader.populateStatusCodeSelect()
				formHeader.populateDrillingLogCodeSelect()
				formHeader.populateDrillingMaterialUsedSelect()
				break
		}

		initialize()

		function initialize () {
			initializePickadate()
			$('.sign').off('click')
			$(`.sign_comment`).off('click')
			initializeSignatures()
			initializeImagePickers()
			$('.translate').localize()
		}
	}
}

function putJSONForm(theForm, parsedJSON) {
	main_current_draft_object = parsedJSON
	if(parsedJSON.formname === 'PRE-OP') {
		populateQuestions(parsedJSON.machine_number,parsedJSON.machineType)
	}

	if(parsedJSON.formname === 'CUSTOMFORMS') {
		let selected_customForm = parsedJSON.checklist
		if(selected_customForm) {
			document.getElementById('customForm').value = selected_customForm
				customForms.forEach((id)=>{
					if(id.fob_id == selected_customForm) {
						document.getElementById('customFormTitle').innerHTML = `Custom Form - ${id.fob_name}`
						document.getElementById('customForm_name').value = id.fob_name
					}
					})
					populateCustomFormItems(selected_customForm)
		}
	}

	let allGalleries = document.getElementsByClassName('photoGallery')
	for (gal in allGalleries) {
		allGalleries[gal].innerHTML = ""
	}

	// remove all images
	$('.singleImage').remove()
	// clear all of the radio buttons
	$(".form-check-input").parent().removeClass('focus active')
	$(".form-check-input").attr('checked', false)

	let s=1;
	let xcount = 0;	
	$.each(parsedJSON, (name, val) => {	
		let fileDateStamp = ''
		let $el = $('[name="' + name + '"]')
		// If we don't have an element, it must be a photo, we'll need to create a hidden field, and a gallery display
		if($el.length === 0)	{
			// Create an input element to form
			let input = document.createElement('input')
			input.type = 'hidden'
			// Make it hidden
			input.classList.add('singleImage')
			input.name = name;
			// Copy the name into the ID
			input.id = input.name
			// Append the form element to the form.
			form.appendChild(input)
			// Copy a pointer to the newly created object
			$el = $('[name="' + name + '"]')
			let photoComponents = name.split('.');
			fileDateStamp = photoComponents[0].substring(0,19)
			// Parse out photo components from name (formname_gallername_photoname)
			if(photoComponents.length > 1) {
				if(name.substr(-8)!="_comment"){
					document.getElementById(photoComponents[1]).innerHTML += `<div class="col-md-3 col-sm-4 col-6 mb-3 d-flex">
					<div name="${name}GALLERY" id="${name}GALLERY" class="sf-gallery__bg-image" src="${val}" style="background-image: url(${val})">
					<span onclick="removeImg(this);" class="deleteGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-trash-alt"></i></span>
					<span onclick="addComment(this);" class="commentGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-comment"></i></span>
					<span onclick="expandImage(this);" class="displayGalleryImage btn-floating btn-sm btn-secondary"><i class="fas fa-search-plus"></i></span>
					<span class="imageDateStamp text-center font-weight-bold">${moment(fileDateStamp).format('YYYY-MM-DD hh:mm:ss a')}</span>
					</div></div>`
				}
			}
			if(name.substr(-8)=="_comment"){
				if(val){						
					imgs=$el.parent().find("div")
					imgs.each(function( index ){
						if(name.slice(0, -8)==imgs[index].id.slice(0, -7)){
							$(imgs[index]).parent().find(".fa-comment").removeClass('far')  //remove empty comment icon
							$(imgs[index]).parent().find(".fa-comment").addClass("fas")   //add filled comment icon
						}
					});
				}
			}
			$el.val(val)
			// This is a regular form element
		} else	{
			// Get its type
			type = $el.attr('type')
			// Properly handle input types
			if(type == undefined)	{
				// Otherwise, use the tagName for selects
				type = $el[0].tagName
			}
			// Handle special cases
			switch(type){
				// If it's a checkbox
				case 'checkbox':
					if(val === "1"){
						// Set the check attribute
						$el.val(val)
						$el.attr('checked', 'checked')
						if (typeof initiateCheckBoxOnRecall == 'function') { 
							initiateCheckBoxOnRecall($el);
						}	
					}
					break;
				case 'radio':
					// If it's a radio
					// If their elements value matches the form, set the checked attribute
					$el.filter('[value="'+val+'"]').attr('checked', 'checked')
					$el.filter('[value="'+val+'"]').parent().addClass('active')
					$el.filter('[value="'+val+'"]').trigger("onchange")
					if($el.filter('[value="'+val+'"]').val() === 'Action Required'){
						// For the forms where the value of the respective radio button is 'Action Required'
						$el.filter('[value="'+val+'"]').parent().parent().nextAll(`.cond-form-check-area:first`).show()
					}
					if($el.filter('[value="'+val+'"]').val() === '1'){
						// For the forms where the value of the respective radio button is '1'
						if ($el.filter('[value="'+val+'"]')[0].classList.contains('radio-check')){
							// Condition for the radio button (cond-form-check-area) expansion with the respect to the field 'Were any areas of improvement identified?'
							$el.filter('[value="'+val+'"]').parent().parent().nextAll(`.cond-form-check-area:first`).show()
							if (typeof requiredRadio == 'function') { 
								requiredRadio(1);
							}
						}
					}

					if($el.filter('[value="'+val+'"]').val() === '0'){
						// For the forms where the value of the respective radio button is '0'
						if ($el.filter('[value="'+val+'"]').parent()[0].classList.contains('no-radio')){
							// Condition for the radio button (cond-form-check-area) expansion with the respect to the field 'Were any areas of improvement identified?'
							$el.filter('[value="'+val+'"]').parent().parent().nextAll(`.cond-form-check-area:first`).show()
						}
					}
					
					// For the forms where the value of the respective radio button is '1'
					// Condition for the radio button (cond-form-check-area) expansion with the respect to the field 'Were any areas of improvement identified?'
					if($el.filter('[value="'+val+'"]').val() === '0'){
						if ($el.filter('[value="'+val+'"]')[0].classList.contains('radio-check')){
							if (typeof requiredRadio == 'function') { 
								requiredRadio(0);
							}
						}
					}
					if (typeof initRadioOnCriticalActivityRequirements == 'function') { 
						initRadioOnCriticalActivityRequirements();
					}
					if (typeof initializeRadioButtonOnRecall == 'function') { 
						initializeRadioButtonOnRecall();
					}
					break
				// If it's a Select box
				case 'SELECT':
					SetSelectValue($el[0], val);
					break
				// If it's a Select box
				case 'file':
				//	SetSelectValue($el[0], val);
					break;
				default:
					if($el[0].name != 'formname'){
						// Otherwise
						// Set the elements value
						$el.val(val)
					}
				if (val  && ($el[0].type === 'text' || $el[0].localName === 'textarea' || $el[0].type === 'number') && !$el.parent().find("label").hasClass('active')) {
				$el.parent().find("label").addClass('active');
				}
				// Image and data recall for Modal Signature
				if($el.hasClass('modalSignature')){
					let image = $el.val()
					if($el.val()) {
						let s = $el.prev().prev().children()
						s[0].innerHTML = '<i class="fa fa-pen"></i> ' + i18next.t('2243')  //display "RE-SIGN" button
						s[1].classList.remove('d-none')  //display "Comment button"	
						if(s[2]){
							s[2].classList.remove('d-none')   //display "clear buttion"	
						}
						let recall = $el.prev().attr('src', image)
						
						img_notes = $el.attr('id') + '_img_time'
						$(`[notes=${img_notes}]`)[0].parentElement.classList.remove("d-none")
					}

				}	
				//if there's signature comment
				if($el.attr('class')=="sig_comment"){
					if($el.val())
					{
						$el.parent().find(".btn-group").children()[1].firstChild.classList.remove("far") //remove empty comment icon
						$el.parent().find(".btn-group").children()[1].firstChild.classList.add("fas")   //add filled comment icon
					}
				}
			}

			if(type != 'hidden')	{
				// If these are dropdowns, populate and update
				if(name == 'job_number' && checkSiteJob('site', val))	{// Trigger to populate job_number drop down
					formHeader.populateJobSelect(document.getElementById('site'))
					SetSelectValue(document.getElementById('job_number'), val);
				}
				if(name == 'level' && checkSiteJob('job_number', val))	{																									// Trigger to populate level drop down
					formHeader.populateLevelSelect(document.getElementById('site'));
					SetSelectValue(document.getElementById('level'), val); 
				}
			}

			// check if there are scores in the triangle
			if(document.forms[0].workplace_score) {
				workplaceScore = document.forms[0].workplace_score.value
				jobDefScore = document.forms[0].job_definition_score.value
				experienceScore = document.forms[0].experience_score.value
				if(workplaceScore && jobDefScore && experienceScore) {
				drawSafetyTriangle(workplaceScore, jobDefScore, experienceScore)  
				}	
			}
		}
	})
	refreshDataAfterLoadDraft(parsedJSON)	
}

function SetSelectValue($el, value) {

	// Set the value in the options list of the select box to selected, can be a | delimited array.
	// How many option elements do we have
	// Try splitting
	let arrKeys = value.split('|')
	// Modification to suit Select2 select box plug in for jquery

	if($el.classList.contains('score')){
		$('#' + $el.name).val(fixMultiSelects(arrKeys))
	}

	if($el.name==='site' || $el.name==='job_number'){
		trigger = checkSiteJob($el.name, value) 
		// added new function checkSiteJob - to check if the site selected is draft is still available is user data visibility.
		// if not available send site value nothing. 
		// set the trigger to false site doesn't exist in user data visbility. Thus not calling onchange function for site and job_number
	}
	if($el.name !== 'equipmentSelect') {
		changeValue()
		if($el.name === 'supervisor') {
			setTimeout(() => {
				changeValue() 
			}, 100);
		}
	} else {
		a= $("#equipmentSelect").find(`option[value='${value}']`)[0]
		setTimeout(()=>{
			a.selected = 'selected'
			$("#equipmentSelect").val(value)
			$("#equipmentSelect").trigger("change").parent().find('label').addClass('filled')
		},200)
	}

	function changeValue() {
		let mainArray = []
		arrKeys.forEach((element)=>{
			if(element) {
				mainArray.push(element)
			}
		})
		$('#' + $el.name).val(mainArray)
		$('#' + $el.name).trigger('change');
		$('.select2-search__field').attr('placeholder', i18next.t("2346"))
		if (arrKeys != '') {
			addClassFilled($el.name)
		}
	}

	return
}

function checkSiteJob(name, value){
	trigger = true	
	if(name==='site'){
		sites_list = userSiteData
		site_names_list = []
		sites_list.forEach((site)=>{
			site_names_list.push(site.rld_id)
		})
		if(site_names_list.includes(parseInt(value)) === false){
			trigger = false
		}			
	}
	if(name==='job_number'){
		jobs_list = userJobData
		job_numbers_list = []
		jobs_list.forEach((job)=>{
			job_numbers_list.push(job.rld_id)
		})
		if(job_numbers_list.includes(parseInt(value)) === false){
			trigger = false
		}
	}
	return trigger
}

function addClassFilled(name){
	if(name=='level'){
		// checking if site value is available after checkSiteJob function. If not donot fill level and do not add class filled to level. 
		if($( "#site" ).next().next().hasClass( "filled" )){
			$('#' + name).next().next().addClass('filled')
		}
	}
	else{
		$('#' + name).next().next().addClass('filled')
	}
}

function fixMultiSelects(values) {
	let arr = []
	let score = ""
	let pick = ""
	values.forEach((data, index) => {
		!isOdd(index) ? (pick = data) : (score = data)
		if (pick != "" && score != "") {
			arr.push(`${pick}|${score}`)
			pick = ""
			score = ""
		}
	})
	return arr
}

function isOdd(num) {
	return num % 2
}

// Write the JSON data to the local DB	
function addFormDraft(text, pouchid, submissionID, formname, mode='yes', type='parent', submittedId) {
	let selectedForm =  JSON.parse(text).formid
	let parentDraft = $("#currentDraft").val()
	if(type !== 'parent') {
		$("#currentDraft").val("")
	}
	dbDraft.get(pouchid.formid).then(function(doc) {
		return dbDraft.put({
			_id: pouchid.formid,
			_rev: doc._rev,	
			submissionID: submissionID,
			formname: formname,	
			formid: pouchid.title,
			formdata: text,
			submittedId:submittedId
		})
	}).then(function() {
		if(mode === 'yes'){
			updateDraftListSelect(pouchid.formid || pouchid.title)
			showAlert(selectedForm)
		}
	}).catch(function (err) {
		if(debug) console.log('Creating New Rec: ' + err);	
		dbDraft.put({
			_id: pouchid.formid,
			_rev: text._rev,
			submissionID: submissionID,
			formname: formname,
			formid: pouchid.title,	
			formdata: text,
			submittedId:submittedId
		}).then( ()=> {
			countSubFormAttachments()
			if ($("#currentDraft").val() !== "" && type === 'parent') {
				dbDraft.get($("#currentDraft").val()).then(function(doc) {
					return dbDraft.remove(doc);
				}).then(()=>{
					updateDraftListSelect(pouchid.formid,type)
					if(mode === 'yes') {
						showAlert(selectedForm)
					}
				}); // Update draft list.
			}
			else {
				updateDraftListSelect(pouchid.formid, type, parentDraft)
				if(mode === 'yes'){
					showAlert(selectedForm)
				}
			}
		});
	});		
}

function updateDraftListSelect(pouchid, type, parentDraft) {
	let select2LanguageFunction = window[`sofvie_select2_languages_${selectedLanguage}`];
	if (!(typeof select2LanguageFunction === "function")){
		select2LanguageFunction = {}
		console.error("Failed to get Select2 Translations")
	}

	if($('#currentDraft').val() !== pouchid) {
		$("#draft").select2('destroy');
		getFormDraftList('#draft')
		$('#draft').select2({theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder:""})
		.on('select2:select', function(){
			reInitializeSelect2Language()
			$(this).parent().find('label').addClass('filled')
		})
		.on('select2:unselect', function(){
			if($(".select2-selection__choice")[0]){
				$(this).parent().find('label').addClass('filled')
			}else {
				$(this).parent().find('label').removeClass('filled')
			}
		})
		setTimeout(()=>{
			newDraft = true;
			if(type === 'parent'){
				$('#currentDraft').val(pouchid)
				$('#draft').val(pouchid).trigger('change')
				$("#draft").parent().find('label').addClass('filled')
			}
			else {
				$('#currentDraft').val(parentDraft)
				$('#draft').val(parentDraft).trigger('change')
				$("#draft").parent().find('label').addClass('filled')
			}	
			$("#deleteDraft").css('display','block')
			newDraft = false;
		},500)
	}
}

async function addForm(text, pouchid, submissionID, formname, _rev, formid) {	// Write the JSON data to the local DB
	// add the Modal for adding the form
		
	let arrParent = {};																						// Create storage for all forms
	arrParent =	JSON.parse(text);																			// Convert our parent to an object to allow us to add children to it.
	
	let arrChildren = [];
	let arrIDs=[];																															// Storage for ID's to allow easier deletion later
	arrIDs.push({'_id' : pouchid.formid, '_rev' : _rev}); 															// Store the parent ident
	if(debug) console.dir(arrParent);

	if(submissionID)	{																													// Is draft enabled?

		await dbDraft.createIndex({																			// Update our index (required by pouch)
			index: {fields: ['submissionID', 'formname']}													// Were querying by subid and formname
		}).then(function(response)	{
			if(debug) console.log('ReIndexed db');
		}).then(function(doc)	{

			dbDraft.find({selector: {																		// Query where subid matches and is not the parent form
				'submissionID':submissionID ,					
				'formname':  {"$ne": formname} 
			},
			fields: ['formdata', '_id', '_rev']																// We only care about the formdata
			
			}).then(function(doc)	{
				if(debug) console.log('result of child find');
				if(debug) console.dir(doc);
				for(s of doc.docs)	{																										// Iterate over the results
					arrIDs.push({'_id' : s._id, '_rev' : s._rev});												// Store the ID's so we can delete from drafts
					arrChildren.push({'formdata' :	JSON.parse(s.formdata)});							// and push on to the array
				}
				if(debug) console.log('arrIDs');	
				if(debug) console.dir(arrIDs);	

				if(debug) console.log('arrChildren');	
				if(debug) console.dir(arrChildren);	

				arrParent['Children'] = arrChildren;

				if(debug) console.log('arrParent');	
				if(debug) console.dir(arrParent);

			}).then(function()	{
				_db = form.formid.value == 372468 ? dbSofvieForm : db
				if(form.formid.value == 372468){
					if (typeof convertToObj !== 'undefined' && typeof convertToObj === 'function') {
						convertToObj(arrParent)
						arrParent=lotoObj
					}
				}
				// Check to see if this id already has been committed
				_db.get(pouchid.formid).then(function() {
					// If this is an actionable form (Hazard, General), throw an error to skip into the catch block
					if(form.formid.value == 131042 || form.formid.value == 349935)	{
						if(debug) console.log('skipping Pouch exists check because of Hazard Actio or Hazard Action')
						throw true
					}

					console.error('addForm: Commit Found ID: ' + pouchid.formid)
					alert('You cannot save this form. This id already exists\r\nID = ' + pouchid.formid )
				//Reset disabled stated on Commit/Save button
					$('#saveEnable').prop('checked', false)
					$('#submit').prop("disabled","disabled")
					
					return false;
				}).catch((err) => {
					_db.put({
						_id: pouchid.formid,
						submissionID: submissionID,
						formname: formname,
						formdata: arrParent,
						timestamp: +new Date,
						submittedId: remoteData[2].Employee[0].per_id
					}).then(function(response) {
						if(debug)	console.log('addForm: Commit Update ID: ' + pouchid.formid)
						checkOnline().then((status)=>{
							if(!localStorage.getItem('submittedForms')){
								localStorage.setItem('submittedForms',JSON.stringify([]))
								}
								let submittedForms = JSON.parse(localStorage.getItem('submittedForms'))
								let found = false
								submittedForms.forEach((data)=>{
									if(data.formid === formid){
										data.count ++
										found = true
									}
								})
								if(!found){
									submittedForms.push(subForm = {formid: formid,count: 1})
								}
								localStorage.setItem('submittedForms', JSON.stringify(submittedForms))																				// sync to it.
							}).catch((err)=>{})

						// RMR:20190425 - Update Target Notifications directly
						targets = remoteData[0].targets																	// Extract the notifications
						let formTarget = arrayItem = 0
						for(let arrayItem in targets)	{																		// Iterate over our target array
							if(targets[arrayItem].FDFormID == formid)	{											// Does it equal our formid? (arrParent.formid)
								formTarget = targets[arrayItem].Target											// Get the Target value
								if(debug) console.log(formTarget)		
								formTarget = (formTarget) ? formTarget -1 :	0									// Decrement if were greater than zero
								targets[arrayItem].Target = formTarget											// Stuff it back in the array
							}
								
						}
						if(debug) console.log(targets)
						remoteData[0].targets = targets																	// Store the results back on our object
					}).then(function(response) {
					// Check to see if this was from a draft, if so, delete the draft copy.
					for(s of arrIDs)	{																									// Iterate over the results					
						if(debug)	console.log('s._id: ' + s._id)
						dbDraft.get(s._id).then(function(doc) {														// Try to retrieve existing unique id
							if(debug) console.log('addForm: Draft Found ID (to delete): ' + s._id)
							return dbDraft.remove(																					// If we got a result
								doc._id, 
								doc._rev																											// Overwrite it
							).then((data)=>{
								window.sessionStorage.removeItem('modalsubmit')
								if(debug){
								}
							})
						}).catch(function (err) {
							console.warn('ERROR or nothing to delete from drafts: ' + err);	// Error
						})
						setTimeout(()=>{
							submitSuccessModal()
						}, 500)
					}
		
		// Remove validation to eliminate issue with selects showing invalid styling after form submission
				
				function submitSuccessModal() {
					$(`form.validated`).removeClass('was-validated')
					// Display the success modal (addForm is async, so we put this modal inline)
					formModal.setModalElements(`success`, `modalText`, i18next.t("1425"))   // The form has been submitted successfully.`)
					formModal.setModalElements(`success`, `modalTitle`, i18next.t("1424"))  // Form Submitted
					formModal.setModalElements(`success`, `modalButtons`, `<a role="button" class="px-1 flex-fill btn btn-outline-success waves-effect repeatform translate" data-i18n="1426" notes="Create Another"></a>
					<a role="button" class="px-1 flex-fill btn btn-success waves-effect tohomepage translate" data-i18n="1405" notes="OK"></a>`)
					formModal.handleModal(`success`)
					$(`.modal-footer .repeatform`).click(() => {
						formModal.hideModal()
						sessionStorage.setItem("lastformdata", JSON.stringify(arrParent))
						location.reload()
					})
					$(`.modal-footer .tohomepage`).click(() => {
						if(mobileFrame) {
							let message = {
								name: "mobile-frame-submit",
								data: ""
							}
							window.parent.postMessage(JSON.stringify(message), '*')
							window.sessionStorage.setItem('incidentId', null)
							window.sessionStorage.setItem('moduleId', null)
							location.reload()
						} else {
							formModal.hideModal()
							window.open($('#parentpage').attr('url'), '_self')
						}
					})
					return true
				}
			}).then(()=>{
				checkOnline().then((status)=>{
					syncForm("From the Form Handler")
				}).catch((err)=>{})
				}).catch(function (err) {
					// This rec does not exist in the specified db, save it.
					console.error('AddForm: Error Committing Data: ' + err)
					return false;
				})
			})
		})
		}).catch(function (err)	{
			console.error('Error finding child form')
			console.error(err)
			return false
		})
	// End submissionid check
	}
	return false
}

function modalDeleteDraft() {
	formModal = new SofvieModal();                                          // initialize the Modal 
	formModal.setModalElements(`danger`, `modalTitle`, i18next.t('1408'))
	formModal.handleModal(`danger`)                                        // Display the Warning Modal
	$(`.modal-footer .confirm`).click(() => {                               // create event listener for OK button
	formModal.hideModal()       
	//	const formStatus = deleteDraft();                                // Send request to submit form
	let url = new URL(window.location.href);
	let urldraftid = url.searchParams.get("draftid");
	draftID = $('#draft').val()
	if(urldraftid)
	draftID = urldraftid
		dbDraft.get(draftID).then(function(doc) {
			dbDraft.remove(doc);

			if(mobileFrame) {
				let message = {
					name: "mobile-frame-close",
					data: ""
				}
				window.parent.postMessage(JSON.stringify(message), '*')
				window.sessionStorage.setItem('incidentId', null)
				window.sessionStorage.setItem('moduleId', null)
				location.reload()
			} else {
				setTimeout(function(){ window.history.back() }, 1000)
			}
				
		});
	})
}

// This is an orphan
function deleteDraft()	{																											// The user clicked the Reset/Delete Draft button	
	if(form._id.value)	{																												// If this form has been saved previously (form has db id)
		if(form._rev.value)	{																											// And if it has a revision (redundant)
			dbDraft.get(form._id.value).then(function(doc) {															// Retrieve the form data
				return dbDraft.remove(doc)																								// delete the doc
			}).then(function (result) {	       																			// and the housekeeping
				form._rev.value= ''																									// Reset the form rev
				form._id.value= ''																										// Reset the form id
				getFormDraftList(draft);																							// Update the draft list
				})
				//.then(function (result) {																						// and then
		//	clearForm();																													// Clear the form
		//	})
				.catch(function (err) {
					console.error('ERROR deleting draft: ' + err)
				})
			.catch(function (err) {
				console.error('ERROR getting draft: ' + err)
			})				
		}
	}
}

function clearDBForm() {
	if(form._id.value)	{																												// If this form has been saved previously (form has db id)
		if(form._rev.value)	{																											// And if it has a revision (redundant)
			dbDraft.get(form._id.value).then(function(doc) {
				return dbDraft.put({
					_id: doc._id,																														// Update it
					_rev: doc._rev,	
					submissionID: doc.submissionID,		                                                                          // SJB: 20190329 - Make submissionID available
					formname: doc.formname,	
					formid: doc.formid,																											// Must pass the existing revision
					formdata: ''																												// and the data
				})
			})
		}
	}
}

function showAlert(formname) {
	let incidentForms = [221746, 220234, 224335, 349935];
	if(window.sessionStorage.getItem('modalsubmit') !== 'SUBMITSTOP')
	{
		startAutoSave()
	}
	document.getElementById("saveDraft").disabled = false;
	if(window.sessionStorage.getItem('modalsave')) {
		window.sessionStorage.removeItem('modalsave')
	} else{
		if(mobileFrame) {
			let message = {
				name: "mobile-frame-close",
				data: ""
			}
			window.parent.postMessage(JSON.stringify(message), '*')
			location.reload()
		} else {
			if(incidentForms.indexOf(parseInt(formname)) == -1) {
				window.location.href = `/pages/Toolbox.php`
			}
			else {
				window.location.href = `/pages/HazardAndIncidentManagement.php`				
			}
		}
	}
}

function clearForm()	{
	// Iterate over form elements and set values to null
	let elements = form.querySelectorAll( "input, select, textarea" );					// Create a reference to all form element types
	let obj = {};																																// Create storage object

	for( let i = 0; i < elements.length; ++i ) {																// Iterate over it
		let element = elements[i];																								// Extract the element type
		let name = element.name;																									// The element name
		element.value = null;																											// Reset the value

		if( name ) {																															// If it has a name attribute
			if(!obj[name]) {																												// Has this element already been added?
				if(element.matches('[type="radio"]')) {																// Is a radio button
					if(element.checked)	{																								// Is it checked
						obj[name] = element.value;																				// Assign the associated value to the element
					} 

				} else if (element.tagName == 'SELECT') {															// Is a select box 
						obj[name] = getSelectValues(element);															// Handle if it contains 1 or more selections.
						element.selectedIndex = -1;

				} else {
					obj[name] = element.value;																					// Its another kind of input element
				}
			}
		}
	}

	// Delete all images in gallery
	while ($(".deleteGalleryImage")[0])	{
				$(".deleteGalleryImage")[0].parentElement.remove();										// Delete the node
	}
	//Reset disabled stated on Commit/Save button
		$('#saveEnable').prop('checked', false);																	// UnCheck the save enable button
		$('#submit').prop("disabled","disabled");																	// Disable the commit/save button.
}

function getDraftSubmissions() {
	return new Promise((resolve, reject) => {
		dbDraft.allDocs({								// Get all matching drafts for this form name 
			include_docs: true,
			attachments: false,
			}).then(function (result) {					// If we got results
				resolve(result)
			}).catch(function (err) {
				reject(err)
			});
		});
}

function checkForChildForms() {
	document.getElementById('hapChildExists').value = false
	document.getElementById('pidChildExists').value = false
	document.getElementById('gapChildExists').value = false

	let subid  = document.getElementById('submissionId')
	let currentForm = document.getElementById('formname').value
		currentForm=currentForm.toUpperCase()
		if(subid && (currentForm === 'HAZARD REPORT PARENT' || currentForm === 'HAZARD ACTION' || currentForm === 'POSITIVE IDENTIFICATION PARENT' || currentForm === 'POSITIVE RECOGNITIONS' || currentForm === 'GENERAL ACTION' || currentForm === 'GENERAL REPORT PARENT')){
		let draftData = getDraftSubmissions()
		
		draftData.then((data) => {
			for(let records in data.rows) {
				let formname = data.rows[records].doc.formname
				if(formname){
					formname=formname.toUpperCase()
					if(subid.value === data.rows[records].doc.submissionID) {
						if(formname === 'HAZARD REPORT') {
							document.getElementById('hapChildExists').value = true
							document.getElementById('hazards_identified').value = '1'
						}
						if(formname === 'POSITIVE IDENTIFICATION') {
							document.getElementById('pidChildExists').value = true
							document.getElementById('positive_identification_opportunities_identified').value = '1'
						}
						if(formname === 'GENERAL ACTION') {
							document.getElementById('gapChildExists').value = true
							document.getElementById('general_actions_identified').value = '1'
						}						
					}
				}
			}
		})
	}
}

function clearAllQuestions(){
	if(document.getElementById('preopQuestions')) 
		document.getElementById('preopQuestions').innerHTML = ''
}

function clearAllSignatures() {
	$('.signatureImage').attr('src','')
	$('.modalSignature').val('')

	$('.sign').each(function( index ) {
	if ($('.sign')[index].getAttribute('signaturename') == 'rescue_sketch_draw'){
		let drawText = "<span class='translate' data-i18n='2376' notes='Draw'></span>"
		$('.sign')[index].innerHTML=`<i class="fa fa-pen"></i> ${drawText}`
	}
	else if($('.sign')[index].getAttribute('signaturename') == 'signature_end_of_shift_review'){
		let reviewText = "<span class='translate' data-i18n='1188' notes='Review'></span>"
		$('.sign')[index].innerHTML=`<i class="fa fa-pen"></i> ${reviewText}`
	}
	else{
		let signText = "<span class='translate' data-i18n='1396' notes='Sign'></span>"
		$('.sign')[index].innerHTML=`<i class="fa fa-pen"></i> ${signText}`
	}
	})
	$('.clear_sign').addClass('d-none')
	$('.sign_comment').addClass('d-none')
	$('.sign_comment').find(".fa-comment").removeClass('fas')  //remove empty comment icon
	$('.sign_comment').find(".fa-comment").addClass("far")   //add filled comment icon

	try{$('.translate').localize()} catch{}
}

function getUniqueModalPhotoName(galleryName, photoElemName, fileDateStamp)	{
	// Generate unique hidden field name for photo's
	// Generate a sequential element name as a suffix to photoElemName
	// INPUT :	galleryName - Name of display gallery
	//			photoElemName = base elem name
	// OUTPUT: 	return unique file base on photoElemName
	let i = 1
	let photoName = `${fileDateStamp}${form.formtype.value}.${galleryName}.|${photoElemName}|${i}|`
	if (document.getElementById(photoName)) {
		i++
		photoName = `${fileDateStamp}${form.formtype.value}.${galleryName}.|${photoElemName}|${i}|`
		while(document.getElementById(photoName)){
			photoName = `${fileDateStamp}${form.formtype.value}.${galleryName}.|${photoElemName}|${i}|`
			i++
		}
	}
	else {
		return photoName
	}
	return photoName
}

// Code to autosave the form every 20 seconds if the header 
// information is properly filled out
let autoSaveInterval = ''
function startAutoSave() {
	autoSaveInterval = setInterval(()=>{
		autoValidateSave()
	}, 20000)
}

// function to stop the Autosave interval on Submission
function stopAutoSave() {
		clearInterval(autoSaveInterval);
}

function autoValidateSave() {
	let formValidationStatus = $('form')[0].classList.contains('was-validated')  // Added a condition so if the form was validated before the autosave it will respect it
	let status = formHeader.formValidate($('form')[0],'autosave')
	if(status){
		window.sessionStorage.setItem('modalsave','1')
		document.getElementById('saveDraft').click() 
	if(!formValidationStatus){
		$('form')[0].classList.remove('was-validated')                       // check if the form was validated before the autosave.
		}
	}
}

startAutoSave()

// this is used to disable the Select List when OTHER is used
let olist = document.querySelectorAll('.otherclass')
olist.forEach((data)=>{
	data.addEventListener('keyup', (e)=>{
		if(e.target.value === ''){
			e.target.parentNode.previousElementSibling.querySelector('select').required = true
		}
		else {
			e.target.parentNode.previousElementSibling.querySelector('select').required = false
		}
	})
})
// 2019-10-02 - RMR
// These functions are used to handle a Dynamic form that has an add/remove section in it
// Mostly with Shift Reports
// Initialize the Form for a new one
let totalCrews = 0
let crews = 1
if(document.getElementById('numCrews')){
	totalCrews = parseInt(document.getElementById('totalCrews').value)
	document.getElementById('removeCrew').classList.add('d-none')

	// add a crew
	document.getElementById('addCrew').addEventListener('click',(e)=>{
		crews = document.getElementById('numCrews').value
		if(crews < totalCrews) {
			crews++
			addCrew(crews)
			document.getElementById('numCrews').value = crews
			if(crews == totalCrews){
				document.getElementById('addCrew').classList.add('d-none')
			}			
		} 
		if(crews > 1 && crews <= totalCrews){
			document.getElementById('removeCrew').classList.remove('d-none')
		}
	})

	// remove a crew 
	document.getElementById('removeCrew').addEventListener('click',(e)=>{
		crews = document.getElementById('numCrews').value
		let theCrew = $(`.crewsection[value="${crews}"]`)
		theCrew.remove()
		//remove hided draft load photos
		let repeatPicForms=['333840','333857','333851','372438']
		formid = document.getElementById('formid').value
		if(repeatPicForms.indexOf(formid) > -1){
			loadedPhotos = $('.singleImage')
			for(loadedPhoto of loadedPhotos){
				if(formid=='333840' && loadedPhoto.id.includes('workplace_picture_' + crews)){
					loadedPhoto.remove()
				}
				if((formid=='333857' || formid=='333851') && loadedPhoto.id.includes('workplace_pictures_' + crews)){
					loadedPhoto.remove()
				}
				if(formid=='372438' && loadedPhoto.id.includes('images_' + crews)){
					loadedPhoto.remove()
				}
			}
		}
		crews--
		document.getElementById('numCrews').value = crews
		if(crews > 1 && crews <= totalCrews)
		document.getElementById('removeCrew').classList.remove('d-none')
		if(crews >= totalCrews){
			document.getElementById('addCrew').classList.add('d-none')
		}
		else{
			document.getElementById('addCrew').classList.remove('d-none')
		}
		if(crews === 1) 
		document.getElementById('removeCrew').classList.add('d-none')
	})

	// Populate the Form from a Draft by showing the sections activated in FormHandler    * 
	function populateDynamicForm(crews,totalCrews) {
		$(`.crewsection`).remove()		
		if(crews > 1 && crews <= totalCrews)
		document.getElementById('removeCrew').classList.remove('d-none')

		if(crews >= totalCrews)
		document.getElementById('addCrew').classList.add('d-none')
		for (a = 1; a <= totalCrews; a++) {
			if(a <= crews){
				addCrew(a,"loadDraft")	
			} 
		}
	}
}

async function reduceBase64(file, element, mode='parent', canvas_id ='canvas') {
	return new Promise((resolve, reject) => {
		let fileDateStamp =  moment(file.lastModified)
		let removeFunction = `removeImg`
		if(mode !== 'parent') {
			removeFunction = `removeModalImg`
		}
		if(file) {
				let canvas = document.getElementById(canvas_id);
				if(!canvas) {
					let g = document.createElement('canvas');
					g.setAttribute("id", canvas_id);
					canvas = g;
				}
				let img = document.createElement("img");
				let reader = new FileReader();
				reader.readAsDataURL(file);
				reader.onload = function(e) {
					img.src = e.target.result

				img.onload = function(e) {
					let ctx = canvas.getContext("2d");
					ctx.drawImage(img, 0, 0);
					
					let MAX_WIDTH = 1200;
					let MAX_HEIGHT = 1200;

					let width = img.width;
					let height = img.height;
					if (width > height) {
						if (width > MAX_WIDTH) {
							height *= MAX_WIDTH / width;
							width = MAX_WIDTH;
						}
					} else {
						if (height > MAX_HEIGHT) {
							width *= MAX_HEIGHT / height;
							height = MAX_HEIGHT;
						}
					}
					canvas.width = width;
					canvas.height = height;
					ctx = canvas.getContext("2d");
					ctx.drawImage(img, 0, 0, width, height);

					// Check if the image is corrupt
					try {
						if(ctx.getImageData(0, 0, width, height).data.every(item => item === 0)) {
							console.log("Image is corrupt!", file.name)
							element.target.value = null
							resolve(false)
							return
						}
					} 
					catch (e){
						console.log("Image is corrupt!", file.name)
						element.target.value = null
						resolve(false)
						return
					}
					
					
					let dataurl = canvas.toDataURL("image/jpeg");

					// now Process
					let elemname = element.target.parentNode.parentNode.parentNode;
					let galleryname = elemname.querySelector('.photoGallery')
					let childImageExpand = ''
					if(mode === "child") {
						childImageExpand = ",true"
					}
					let myphotoName = getUniqueModalPhotoName(galleryname.id, elemname.id, fileDateStamp.format('YYYY-MM-DD HH:mm:ss'))
					// now get the file name
					galleryname.innerHTML += `<div class="col-md-3 col-sm-4 col-6 mb-3 d-flex">
					<div name="${myphotoName}GALLERY" id="${myphotoName}GALLERY" class="sf-gallery__bg-image" src="${dataurl}" style="background-image: url(${dataurl})">
					<span onclick="${removeFunction}(this);" class="deleteGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-trash-alt"></i></span>
					<span onclick="addComment(this);"class="commentGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-comment"></i></span>
					<span onclick="expandImage(this${childImageExpand});" class="displayGalleryImage btn-floating btn-sm btn-secondary"><i class="fas fa-search-plus"></i></span>
					<span class="imageDateStamp text-center font-weight-bold">${fileDateStamp.format('YYYY-MM-DD hh:mm:ss a')}</span>			
					</div></div>`

					let input = document.createElement("input");
					input.setAttribute("type", "hidden");
					input.setAttribute("name", myphotoName);
					input.setAttribute("id", myphotoName);
					input.setAttribute("value", dataurl);
					galleryname.appendChild(input);

					let commentInput = document.createElement("input");
					commentInput.setAttribute("type", "hidden");
					commentInput.setAttribute("name", myphotoName+'_comment');
					commentInput.setAttribute("id", myphotoName+'_comment');
					galleryname.appendChild(commentInput);

					element.target.value = null
					if (typeof drawSafetyTriangle !== 'undefined' && typeof drawSafetyTriangle === 'function') {
						window.dispatchEvent(new Event('resize'))
					}
					
					resolve(true)
				}
			}
		} else {
			resolve(false)
		}
		
	})
}

function initializeImagePickers () {
	if(!localStorage.getItem(`noinitialize`)) {
		let allPhotoFiles = document.getElementsByClassName('pics')
		for (let i = 0; i < allPhotoFiles.length; i++) {
			photoChangeEvent(allPhotoFiles[i])
		}
	}
}

function addImagePicker (imageId) {
	let photoFile = document.getElementById(imageId).getElementsByClassName('pics')[0]
	photoChangeEvent(photoFile)
}

function expandImage(imageInput, modal=false) {
	let selectedImage = imageInput.parentElement.getAttribute("src")
	let imageTag = imageInput.parentElement.getAttribute("name").replace('GALLERY',"")
	const showPictureModal = 
	`<div class="modal fade" id="openPictureModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
		  <div class="modal-dialog modal-notify modal-info m-0" role="document" style="max-width:100vw;" >
			<div class="modal-content bg-dark" style="height:100vh; overflow:hidden;">
				<div class="modal-body p-0">
					<form method="post" action="" class="camModal">
						<span id="theCanvasSpan" class="displayMainImage d-flex" style:"width:100%;"><canvas src="${selectedImage}" style="max-width:100vw; max-height:100vh" id="theCanvas" class="align-self-center"><canvas></span>
						  <div class="text-center buttonArea d-flex justify-content-center position-fixed w-100" style="bottom:20px; z-index:1;">
							<div class='btn-floating btn-white' id="closeCapture"><i class="fas fa-times"></i></div>
							<div class='btn-floating btn-white' id="saveCapture"><i class="fas fa-save"></i></div>
							<div class='btn-floating btn-white' id="clearCapture"><i class="fas fa-eraser"></i></div>
						  </div>

					</form>
				  </div>
			</div>
		  </div>
	</div>`

	$("#openPicture")
	.empty()
	.append(showPictureModal);
	$('#closeCapture').click(()=>{
		$('#openPictureModal').remove()
		$('.modal-backdrop').first().remove()
		if(!modal) {
			$('body').removeClass('modal-open')
		}
	})
	$("#openPictureModal").modal("show");

	// Markup Images //
	let canvas = document.getElementById("theCanvas");
	let ctx = canvas.getContext("2d");
	let image = new Image();
	image.src = selectedImage
	let MAX_WIDTH = 1200;
	let MAX_HEIGHT = 1200;
	let width = image.width;
	let height = image.height;
	if (width > height) {
	if (width > MAX_WIDTH) {
		height *= MAX_WIDTH / width;
		width = MAX_WIDTH;
	}
	} else {
	if (height > MAX_HEIGHT) {
		width *= MAX_HEIGHT / height;
		height = MAX_HEIGHT;
	}
	}
	canvas.width = width;
	canvas.height = height;
	ctx.drawImage(image, 0, 0);

	let pos = { x: 0, y: 0 };
	document.addEventListener('mousemove', draw);
	document.addEventListener('mousedown', setPosition);
	document.addEventListener('mouseenter', setPosition);
	document.addEventListener('touchmove', draw);
	document.addEventListener('touchstart', setPosition);
	document.addEventListener('touchend', setPosition);

	let factorX = canvas.width / document.documentElement.clientWidth
	let factorXPoint = canvas.width / document.documentElement.clientWidth
	factorX = factorX > 1 ? factorX : 1
	factorXPoint = factorXPoint > 1 ? factorXPoint : 1
	let canvasHeight = canvas.height / factorX
	let factorY =  canvasHeight / document.documentElement.clientHeight 
	factorY = factorY > 1 ? factorY : 1
	 if(factorY > factorX && factorX == 1) {
		factorX = factorY * factorX
	}

	// new position from mouse event
	function setPosition(e) {
		if(e) {
			if(e.type != "touchstart" && e.type != 'touchend' && e.type != 'touchmove')
			{
				pos.x = e.clientX * factorX
				pos.y = e.clientY * factorX
			}
			else {
				pos.x = e.changedTouches[0].clientX  * factorXPoint * factorY
				pos.y = e.changedTouches[0].clientY  * factorXPoint * factorY
			}
		}

	}

	function draw(e) {
		// mouse left button must be pressed
		if(e.type != "touchstart" && e.type != 'touchend' && e.type != 'touchmove')
		{
			if (e.buttons !== 1) return;
		}
		ctx.beginPath(); // begin
		ctx.lineWidth = 5;
		ctx.lineCap = 'round';
		//ctx.globalAlpha = 0.04;
		ctx.strokeStyle = 'red';
		ctx.moveTo(pos.x, pos.y); // from
		setPosition(e);
		ctx.lineTo(pos.x, pos.y); // to
		ctx.stroke(); // draw it!
		}

	$('#saveCapture').click(()=>{
		finalImage = canvas.toDataURL("image/jpeg")
		imageInput.parentElement.setAttribute("src", finalImage)
		imageInput.parentElement.setAttribute("style",`background-image: url(${finalImage})`)
		document.getElementsByName(imageTag)[0].value = finalImage
		$('#openPictureModal').remove()
		$('.modal-backdrop').first().remove()
		if(!modal) {
			$('body').removeClass('modal-open')
		}
	})

	$('#clearCapture').click(()=>{
		ctx.drawImage(image, 0, 0)
	})


	// resize canvas
	$(window).resize(function(){
		factorX = canvas.width / document.documentElement.clientWidth
		factorX = factorX > 1 ? factorX : 1
		factorY =  canvasHeight / document.documentElement.clientHeight 
		factorY = factorY > 1 ? factorY : 1
		if(factorY > factorX && factorX == 1) {
			factorX = factorY * factorX
		}
	})

	// End of Mark up Imaging //
}

function photoChangeEvent(camera, mode='parent') {
	camera.addEventListener('change',(e)=>{
		$("#filespinner").removeClass('d-none')
		let allfiles = e.target.files
		let allowedFileTypes = ['image/png','image/jpeg','image/bmp','image/gif','image/webp']
		let invalidFile = false
		let imagePromises = []
		for(let i = 0; i < allfiles.length; i++) {
			if(allowedFileTypes.includes(allfiles[i].type)) {
				// Add reduceBase64 promise to array
				imagePromises.push(
					reduceBase64(allfiles[i],e, mode).then((result) => {
						if(!result)
							invalidFile = true
					})
				)
			}
			else {
				invalidFile = true
			}
		}

		// Wait for all images to be processed
		Promise.all(imagePromises).then(() => {
			$("#filespinner").addClass('d-none')

			if(invalidFile)
				showPictureWarning(mode)
		})

		if(imagePromises == [] && invalidFile)
		{
			$("#filespinner").addClass('d-none')					
			showPictureWarning(mode)				
		}
			
	})
}

function showPictureWarning(mode) {

	if(mode != 'parent') {
		formModal = new SofvieModal('pictureWarningModal')
		formModal.handleModal('pictureWarning')
	} else {
		formModal = new SofvieModal()
		formModal.handleModal('pictureWarning')
	}

	$('.confirmValidation').click(()=>{
		closeModal(formModal)
	})
}

function detectBrowserVersion() {
	let navUserAgent = navigator.userAgent;
	let browserName  = navigator.appName;
	let browserVersion  = ''+parseFloat(navigator.appVersion); 
	let majorVersion = parseInt(navigator.appVersion,10);
	let tempNameOffset,tempVersionOffset,tempVersion;
	
	if ((tempVersionOffset=navUserAgent.indexOf("Opera"))!=-1) {
		browserName = "Opera"
		browserVersion = navUserAgent.substring(tempVersionOffset+6)
	if ((tempVersionOffset=navUserAgent.indexOf("Version"))!=-1) 
		browserVersion = navUserAgent.substring(tempVersionOffset+8)
	} else if ((tempVersionOffset=navUserAgent.indexOf("MSIE"))!=-1) {
		browserName = "Microsoft Internet Explorer"
		browserVersion = navUserAgent.substring(tempVersionOffset+5)
	} else if ((tempVersionOffset=navUserAgent.indexOf("Chrome"))!=-1) {
		browserName = "Chrome"
		browserVersion = navUserAgent.substring(tempVersionOffset+7)
	} else if ((tempVersionOffset=navUserAgent.indexOf("Safari"))!=-1) {
		browserName = "Safari"
		browserVersion = navUserAgent.substring(tempVersionOffset+7)
	if ((tempVersionOffset=navUserAgent.indexOf("Version"))!=-1) 
		browserVersion = navUserAgent.substring(tempVersionOffset+8)
	} else if ((tempVersionOffset=navUserAgent.indexOf("Firefox"))!=-1) {
		browserName = "Firefox"
		browserVersion = navUserAgent.substring(tempVersionOffset+8)
	} else if ((tempNameOffset=navUserAgent.lastIndexOf(' ')+1) < (tempVersionOffset=navUserAgent.lastIndexOf('/')) ) {
		browserName = navUserAgent.substring(tempNameOffset,tempVersionOffset)
		browserVersion = navUserAgent.substring(tempVersionOffset+1)
		if (browserName.toLowerCase()==browserName.toUpperCase()) {
			browserName = navigator.appName
		}
	}
	
	// trim version
	if ((tempVersion=browserVersion.indexOf(";"))!=-1)
		browserVersion=browserVersion.substring(0,tempVersion)
	if ((tempVersion=browserVersion.indexOf(" "))!=-1)
		browserVersion=browserVersion.substring(0,tempVersion)
	return browserName
}

function requiredRadio(mode=1) {
	el_1 = document.getElementById("follow_up_with_the_employee_yes")
	el_2 = document.getElementById("follow_up_with_the_employee_no")
	el_3 = document.getElementById("follow_up_with_the_task_yes")
	el_4 = document.getElementById("follow_up_with_the_task_no")
	el_5 = document.getElementById("follow_up_with_the_task_na")
	if (mode==0){
		el_1.checked = false
		el_2.checked = false
		el_3.checked = false
		el_4.checked = false
		el_5 ? el_5.checked = false : null
		el_1.required = false
		el_2.required = false
		el_3.required = false
		el_4.required = false
		el_5 ? el_5.required = false : null
	}else{
		el_1.required = true
		el_2.required = true
		el_3.required = true
		el_4.required = true
		el_5 ? el_5.required = true : null
	}
}

// check 'other' on multi select dropdown
function checkOther(element, array, value='Other') {
	let myarray = []
	output = false
	let check = document.getElementById(element).options
	for(let element of check) {
		try {
			if(element.value.toUpperCase() === value.toUpperCase()){
				myarray.push(element.value)
			}
		}
		catch(err){
		console.warn(err)
	}
	}
	array.forEach((arr)=>{
	if(myarray.indexOf(arr) >= 0)
		output = true 
	})

	return output
}

// single select dropdown other selected validation
function checkSingleSelectOtherExists(element, selectedvalue, value='other') {	
	if(selectedvalue !=null && selectedvalue.toUpperCase()  === value.toUpperCase() ){
		return true
	}
	else{
		return false
	}            
}

function lookupFormNameByFormId(formId) {
	if(formId == 350049) // POSITIVE IDENTIFICATION PARENT
		formId = 166071
	if(formId == 131200) // General Report Parent
		formId = 372298
	if(formId == 349935) // Hazard Report Parent
		formId = 131042
	
	let formName = ""
	try {
		formName = JSON.parse(JSON.stringify(remoteData[1].forms))[formId].MobileFormName
	}
	catch {
		console.warn("This formId does not exist: ", formId)
	}

	return formName
}

function refreshDataAfterLoadDraft(parsedJSON){
	setTimeout(() => {    //post process,waiting some header fields value active populate select options
		$.each(parsedJSON, (name, val) => {	
			let $el = $('[name="' + name + '"]')
			switch(parsedJSON.formid){
				case '333840':    //formShifReportConstruction
					if(name.startsWith("equipment_location_group_") ||name.startsWith("name_of_tester_")){
						SetSelectValue($el[0], val)
					}						
					break
				case '372368':     //formHotWorkPermit
					if(name.startsWith("employee_") ||name.startsWith("name_of_tester_")){
						SetSelectValue($el[0], val)
					}						
					break
				case '333851':      //formShiftReportDevelopment
					if(name.endsWith("_location")){
						SetSelectValue($el[0], val)
					}						
					break
				case '372388':     //form Meeting Minutes
					if(name.startsWith("person_responsible_")){
						SetSelectValue($el[0], val)
					}						
					break
			}				
		})	
	}, 2000) 
}
// END of Section RMR