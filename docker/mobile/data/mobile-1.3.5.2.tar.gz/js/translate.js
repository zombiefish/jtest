function getCookie(name) {
	const value = `; ${document.cookie}`;
	const parts = value.split(`; ${name}=`);
	if (parts.length === 2) return parts.pop().split(';').shift();
  }
  
selectedLanguage = navigator.language.substring(0,2)
langCookie = getCookie("lang")
selectedLanguage = langCookie ? langCookie : selectedLanguage
if(window.localStorage.getItem('language'))
  selectedLanguage= window.localStorage.getItem('language')
// Start i18Next for Translations
if (!localStorage.getItem('noinitialize')) {
	initializeI18N()
}

function initializeI18N() {
	return new Promise((resolve, reject) => {
		if(!localStorage.getItem(`noinitialize`)) {
			i18next
			.use(i18nextXHRBackend)
			.init({
				fallbackLng: ["en", "fr", "de"],
				lng: `${selectedLanguage}`,
				debug: false,
				backend: {
					loadPath: `/locales/translation/translation_${selectedLanguage}.json`
				}
				}, (err, t) => {
				jqueryI18next.init(i18next, $)
				// Handle Label Translations
				$('.translate').localize()

				// Initialize charts in Safety Trends
				if (typeof drawCharts == 'function') { 
					drawCharts()
				}

				// Handle the Page Title
				try{
					document.getElementById('page_name').innerHTML = i18next.t(document.getElementById('formname').getAttribute('tag'))
				} catch (error) {}
					
				// Handle the Tooltips 
				let tooltips = document.getElementsByClassName('trans_tooltip')
				for(tooltip in tooltips){
					try {
					tooltips[tooltip].setAttribute('data-original-title', i18next.t(tooltips[tooltip].getAttribute('tag')))
					} catch (error) {}
				}	

				
				// Handle the Input values
				let inputs = document.getElementsByClassName('trans_input')
				for(input in inputs){
					try {
						inputs[input].setAttribute('value', i18next.t(inputs[input].getAttribute('value')))
					} catch (error) {}
				}

				// Handle multiple Input values
				inputs = document.getElementsByClassName('trans_input_multi')
				for(input in inputs){
					try {
						let translation = ""
						let lines = inputs[input].getAttribute('value').split(",")
						for(line in lines){
							let lineValue = lines[line]
							translation += (i18next.t(lineValue) + "\n")
						}			
						inputs[input].setAttribute('value', translation)
					} catch (error) {}
				}
				// Handle the TEST badge
				if (__env.test_environment) {
					document.getElementById('test-pill-id').classList.remove('d-none')
					document.getElementById('test-pill-id').classList.add('d-block')
				} else {
					document.getElementById('test-pill-id').classList.remove('d-block')
					document.getElementById('test-pill-id').classList.add('d-none')
				}

				// Handle the search in Select 2
				reInitializeSelect2Language()

				// Populate settings page with i18n
				if(window.location.pathname === '/pages/Settings.php')
					formHeader.formInitialize()
				
				resolve(true)
			})
		}
	})
}

function reInitializeSelect2Language() {
	let select2Search = document.getElementsByClassName('select2-search__field')
		for(search in select2Search){
			try {
			select2Search[search].setAttribute('placeholder', i18next.t("2346"))
			} catch (error) {}
		}	
}

function reinitializeTranslateTooltips() {
					// Handle the Tooltips 
	let tooltips = document.getElementsByClassName('trans_tooltip')
	for(tooltip in tooltips){
		try {
		tooltips[tooltip].setAttribute('data-original-title', i18next.t(tooltips[tooltip].getAttribute('tag')))
		} catch (error) {}
	}
}


