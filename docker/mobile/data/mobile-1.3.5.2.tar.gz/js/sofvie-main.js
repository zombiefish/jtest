class SofvieModal {
    constructor(name = 'theModal') {
        this.name = name;

        let invalidContentList = []
        try {
            invalidContentList = invalidList
        } catch (e) {}

        this.modalSettings = {
            warning: {
                modalTheme: `modal-warning`,
                modalAlert: `fa-exclamation-triangle`,
                modalTitle: i18next.t('1415'),
                modalText: i18next.t('1409'),
                modalButtons: `<a role="button" class="px-1 flex-fill btn btn-outline-warning waves-effect" id="cancelSubmit" data-dismiss="modal"><span class='translate' data-i18n="1257" notes="Cancel"></span></a>
                <a role="button" class="px-1 flex-fill btn btn-warning waves-effect confirm"><span class='translate' data-i18n="1379" notes="Yes"></span></a>`
            },
            info: {
                modalTheme: `modal-info`,
                modalAlert: `fa-info-circle`,
                modalTitle: i18next.t('2006') , //`Information`
                modalText: ``,
            },
            danger: {
                modalTheme: `modal-danger`,
                modalAlert: `fa-times-circle`,
                modalTitle: i18next.t(`9080`), //'Delete Form'
                modalText: i18next.t('1409'), //This action is permanent. Are you sure you want to proceed?
                modalButtons: `<a role="button" class="px-1 flex-fill btn btn-outline-danger waves-effect"  data-dismiss="modal"><span class='translate' data-i18n="1257" notes="Cancel"></span></a>
                <a role="button" class="px-1 flex-fill btn btn-danger waves-effect confirm"><span class='translate' data-i18n="1379" notes="Yes"></span></a>`
            },
            validate: {
                modalTheme: `modal-danger`,
                modalAlert: `fa-times-circle`,
                modalTitle: i18next.t(`1406`), // Form not saved
                modalText: i18next.t(`1407`),  // Form not saved. Please revisit the fields marked in red.)
                modalButtons: `<a role="button" class="btn btn-danger waves-effect confirmValidation"><span class='translate' data-i18n="1405" notes="OK"></span></a>`            
            },
            invalidContent: {
                modalTheme: `modal-danger`,
                modalAlert: `fa-times-circle`,
                modalTitle: i18next.t(`1406`), // Form not saved
                modalText: i18next.t(`9082`) + " " + invalidContentList.join(" "),  // Form not saved. Please revisit the fields marked in red. These fields must not contain the following invalid content: {{ }} ${
                modalButtons: `<a role="button" class="btn btn-danger waves-effect confirmValidation"><span class='translate' data-i18n="1405" notes="OK"></span></a>`            
            },
            success: {
                modalTheme: `modal-success`,
                modalAlert: `fa-check-circle`,
                modalTitle: ``,
                modalText: ``,
                modalButtons: `<a role="button" class="btn btn-success waves-effect" data-dismiss="modal"><span class='translate' data-i18n="1405" notes="Ok"></span></a>`
            },
            pictureWarning: {
                modalTheme: `modal-warning`,
                modalAlert: `fa-exclamation-triangle`,
                modalTitle: i18next.t("2182"),
                modalText: i18next.t("3456") + "<br>"  + i18next.t("3586"), // Invalid file type Only Pictures can be attached
                modalButtons: `<a role="button" class="flex-fill btn btn-outline-warning waves-effect confirmValidation"><span class='translate' data-i18n="1405" notes="Ok"></span></a>`
            }
        }
    }
    // This ojbect sets the default values for the model buttons and elements
    themeClasses = '';
    alertClasses = '';

    // Default Modal Setting and Main Settings Object
    modalSettings = {}

    // method for combining the available class for theme and alert to remove before adding the indicated one.
    getClasses() {
        const modelData = Object.entries(this.modalSettings)
        for (let item of modelData) {
            this.themeClasses += `${item[1].modalTheme} `
            this.alertClasses += `${item[1].modalAlert} `
        }
    }

    // method for setting modal elements on the fly
    setModalElements(mode, element, newvalue) {
        this.modalSettings[mode][element] = newvalue
    }

    // Method for modifying the Modal then displaying it on the screen when completed
    handleModal(mode, secondModal=false) {
        this.getClasses();

        // Common Element changes
        $(`#${this.name} p.heading`).html(this.modalSettings[mode].modalTitle)
        $(`#${this.name} .modal-notify`).removeClass(this.themeClasses).addClass(this.modalSettings[mode].modalTheme)
        $(`#${this.name} div.text-center  i.fas`).removeClass(this.alertClasses).addClass(this.modalSettings[mode].modalAlert)
        $(`#${this.name} .modal-body-text`).html(this.modalSettings[mode].modalText)
        $(`#${this.name} .modal-footer`).html(this.modalSettings[mode].modalButtons)
        
        // Open the Modal
        $(`#${this.name}`).modal('show')
        $(`#${this.name}`).show()

        if(secondModal) {
            $(`#${this.name}`).css("z-index", "1060")
            $(`.modal-backdrop`).eq(1).css("z-index", "1050") // Second backdrop
        }

        // Hack/fix to prevent second modal from removing the scrollbar for the first modal
        $(document).on('hidden.bs.modal', function () {
			if($('.modal.show').length){
				$('body').addClass('modal-open');
			}
		})

        try {$('.translate').localize()} catch {}
    }

    hideModal() {
        $(document).on('hidden.bs.modal', function () {
			if($('.modal.show').length){
				$('body').addClass('modal-open');
			}
		});

       $(`#${this.name}`).modal('hide');
       $(`#${this.name}`).hide();
    }

}

class SofvieValidation {
    myElems = ''
    myButtons = ''
    returnValue = true
    materialRadioButtonValidationShowError() {
        // check radio buttons to see if there is one not checked
        let returnValue = true
        this.myElems = document.getElementsByClassName(`btn-group btn-group-sm d-flex`)
        if(document.getElementById('child-form')){
         this.myElems = document.getElementById('child-form').getElementsByClassName(`btn-group btn-group-sm d-flex`)
        }
        for (let count = 0; count < this.myElems.length; count++ ) {
            if (this.myElems[count].getElementsByClassName(`btn btn-outline-primary form-check-label active`).length === 0) {
                document.getElementsByClassName(`invalid-feedback`)[count].style.display = 'block'
                returnValue = false
            } else {
                document.getElementsByClassName(`invalid-feedback`)[count].style.display = 'none'
                returnValue = true
            }
            // make all of the events for the buttons
            this.myButtons = this.myElems[count].getElementsByClassName(`btn btn-outline-primary`)
            for (var i = 0; i < this.myButtons.length; i++) {
                this.myButtons[i].addEventListener(`click`, () => {
                    document.getElementsByClassName(`invalid-feedback`)[count].style.display = 'none'
                })
            }
        }
        return returnValue
    }
}

class DateUtils {
    months = [`Jan`, `Feb`, `Mar`, `Apr`, `May`, `Jun`, `Jul`, `Aug`, `Sep`, `Oct`, `Nov`, `Dec`]
    fullMonths = [`January`, `February`, `March`, `April`, `May`, `June`, `July`, `August`, `September`, `October`, `November`, `December`]
    formatCurrentDate(type) {
        const myDate = new Date
        return `${myDate.getDate()} ${this.months[myDate.getMonth()]}, ${myDate.getFullYear()}`
    }


}

/**
 * Form Rules:
 * Class that emplements rules based on actions from radio buttons, check etc to open or close thier Sibling area
 * 
 *  */
class FormRules {
    activateRules() {
        // Form Rules for Radio Buttons
        const checkButtons = document.getElementsByClassName(`custom-radio`)
        for (let a = 0; a < checkButtons.length; a++) {
            checkButtons[a].addEventListener(`change`, (event) => {
                const radioNoRadio = event.target.parentNode.classList.contains("no-radio")
                const radioNoSub = event.target.parentNode.classList.contains("no-sub")
                const inputs = $(event.target).parent().parent().nextAll(`.cond-form-check-area:first`);
              if(!radioNoSub) {
                switch (event.target.value.toUpperCase()) {
                    case i18next.t("2045"):  //'COMPLETE':
                        radioButtonsShow(inputs)
                        break
                    case  i18next.t("1644").toUpperCase(): //  'ACTION REQUIRED':
                        $(event.target).parent().parent().nextAll(`.cond-form-check-area:first`).show()
                        break
                    case i18next.t("1380").toUpperCase(): //'NO': 
                    if(radioNoRadio)
                    {
                        radioButtonsShow(inputs)
                    }else {
                        radioButtonHide(inputs)   
                    }
                            break         
                    case '0': 
                    if(radioNoRadio)
                    {
                         radioButtonsShow(inputs)
                    }else {
                         radioButtonHide(inputs)   
                    }
                                    break                                                    
                    case i18next.t("1379").toUpperCase(): // 'YES':
                    if(!radioNoRadio)
                    {
                        radioButtonsShow(inputs)
                    }else{
                        radioButtonHide(inputs)
                    }
                        break
                    case '1':
                        if(!radioNoRadio)
                        {
                            radioButtonsShow(inputs)
                        }else{
                            radioButtonHide(inputs)
                        }
                            break

                    default:
                        radioButtonHide(inputs)
                        break
                }
            }
            }, false);
        }

        function radioButtonHide(inputs) {
            inputs.find('input,select,textarea').each((index, data)=>{
                if(data.required) {
                    data.classList.add('should_be_validated')
                    data.required = false
                }
                data.value=""
           });
            $(event.target).parent().parent().nextAll(`.cond-form-check-area:first`).hide()
        }

        function radioButtonsShow(inputs){
            inputs.find('.should_be_validated').each((index, data)=>{
                data.classList.remove('should_be_validated')
                data.required = true
           });
            $(event.target).parent().parent().nextAll(`.cond-form-check-area:first`).show()   
        }

        // Form Rules for Check Boxes
        const chkboxButtons = document.getElementsByClassName(`cond-form-check`)
        for (let a = 0; a < chkboxButtons.length; a++) {
            chkboxButtons[a].addEventListener(`click`, (event) => {
                switch (event.srcElement.checked) {
                    case true :
                      event.srcElement.value = '1'
                      $('.invalid-feedback').css('display','none')
                      const inputs = $(event.target).parent().nextAll(`.cond-form-check-area:first`).find('.should_be_validated');
                      if(event.target.classList.contains('complete-off')) {
                          $('#completed-button').hide()
                      }

                      if(inputs.length > 0) {
                      let b=0;
                       do {
                        inputs[b].required = true
                        inputs[b].classList.remove('should_be_validated')
                        b++;
                      }
                      while (b < inputs.length && inputs[b].type !== 'radio');
                    }
                        $(event.target).parent().nextAll(`.cond-form-check-area:first`).show()
                        break

                    default:
                    event.srcElement.value = ''
                    let def = $(event.target).parent().nextAll(`.cond-form-check-area:first`).find('input,select,textarea')
                    if(event.target.classList.contains('complete-off')) {
                        $('#completed-button').show()
                    }
                    if(def.length > 0) {
                        let b=0;
                         do {
                            def[b].required = false
                            def[b].classList.add('should_be_validated')
                          b++;
                        }
                        while (b < def.length && def[b].type !== 'radio');
                      }
                        $(event.target).parent().nextAll(`.cond-form-check-area:first`).hide()
                        break
                }

            }, false);
        }     
    }

    hideRuleFields() {
        $(`.cond-form-check-area`).find('select, input, textarea').each((index,data) => {
            if(data.required) {
                data.required = false 
                data.classList.add("should_be_validated") 
               }

        });
        $(`.cond-form-check-area`).hide()    
    }


    hideRuleFieldsSubModal() {
        $(`.submodal-cond-form-check-area`).find('select, input, textarea').each((index,data) => {
            if(data.required) {
                data.required = false 
                data.classList.add("should_be_validated") 
               }
        
        });
        $(`.submodal-cond-form-check-area`).hide()
    }

    activateRulesSubModal() {
        // Form Rules for Radio Buttons
        const checkButtons = document.getElementsByClassName(`custom-radio`)
        for (let a = 0; a < checkButtons.length; a++) {
            checkButtons[a].addEventListener(`change`, (event) => {
                const radioNoRadio = event.srcElement.parentNode.classList.contains("no-radio")
                const radioNoSub = event.srcElement.parentNode.classList.contains("no-sub")
                const inputs = $(event.target).parent().parent().nextAll(`.submodal-cond-form-check-area:first`);
              if(!radioNoSub) {
                switch (event.srcElement.value.toUpperCase()) {
                    case i18next.t("2045"):  //'COMPLETE':
                        radioButtonsShowSubModal(inputs)
                        break
                    case  i18next.t("1644").toUpperCase(): //  'ACTION REQUIRED':
                        $(event.target).parent().parent().nextAll(`.submodal-cond-form-check-area:first`).show()
                        break
                    case i18next.t("1380").toUpperCase(): //'NO': 
                    if(radioNoRadio)
                    {
                        radioButtonsShowSubModal(inputs)
                    }else {
                        radioButtonHideSubModal(inputs)   
                    }
                            break         
                    case '0': 
                    if(radioNoRadio)
                    {
                        radioButtonsShowSubModal(inputs)
                    }else {
                        radioButtonHideSubModal(inputs)   
                    }
                                    break                                                    
                    case i18next.t("1379").toUpperCase(): // 'YES':
                    if(!radioNoRadio)
                    {
                        radioButtonsShowSubModal(inputs)
                    //    event.srcElement.id === `improvement_action_subform_yes` ? window.open(`http://sofviemobile/forms/formPositiveActionSub.php?submissionId=${$('#submissionId').val()}`, '_blank') : ''
                    }else{
                        radioButtonHideSubModal(inputs)
                    }
                        break
                    case '1':
                        if(!radioNoRadio)
                        {
                            radioButtonsShowSubModal(inputs)
                        }else{
                            radioButtonHideSubModal(inputs)
                        }
                            break

                    default:
                        radioButtonHideSubModal(inputs)
                        break
                }
            }
            }, false);
        }

        function radioButtonHideSubModal(inputs) {
            let test =   $(event.target).parent().parent().nextAll(`.submodal-cond-form-check-area:first`).find('input,select,textarea')
            inputs.find('input,select,textarea').each((index, data)=>{
                if(data.required) {
                    data.classList.add('should_be_validated')
                    data.required = false
                }
           });
            $(event.target).parent().parent().nextAll(`.submodal-cond-form-check-area:first`).hide()
        }

        function radioButtonsShowSubModal(inputs){
            inputs.find('.should_be_validated').each((index, data)=>{
                data.classList.remove('should_be_validated')
                data.required = true
           });
            $(event.target).parent().parent().nextAll(`.submodal-cond-form-check-area:first`).show()   
        }

        // Form Rules for Check Boxes
        const chkboxButtons = document.getElementsByClassName(`cond-form-check`)
        for (let a = 0; a < chkboxButtons.length; a++) {
            chkboxButtons[a].addEventListener(`click`, (event) => {
                switch (event.srcElement.checked) {
                    case true :
                      event.srcElement.value = '1'
                      $('.invalid-feedback').css('display','none')
                      const inputs = $(event.target).parent().nextAll(`.submodal-cond-form-check-area:first`).find('.should_be_validated');
                      if(event.target.classList.contains('complete-off')) {
                          $('#completed-button').hide()
                      }

                      if(inputs.length > 0) {
                      let b=0;
                       do {
                        inputs[b].required = true
                        inputs[b].classList.remove('should_be_validated')
                        b++;
                      }
                      while (b < inputs.length && inputs[b].type !== 'radio');
                    }
                        $(event.target).parent().nextAll(`.submodal-cond-form-check-area:first`).show()
                        break

                    default:
                    event.srcElement.value = ''
                    let def = $(event.target).parent().nextAll(`.submodal-cond-form-check-area:first`).find('input,select,textarea')
                    if(event.target.classList.contains('complete-off')) {
                        $('#completed-button').show()
                    }
                    if(def.length > 0) {
                        let b=0;
                         do {
                            def[b].required = false
                            def[b].classList.add('should_be_validated')
                          b++;
                        }
                        while (b < def.length && def[b].type !== 'radio');
                      }
                        $(event.target).parent().nextAll(`.submodal-cond-form-check-area:first`).hide()
                        break
                }

            }, false);
        }     
    }

}
