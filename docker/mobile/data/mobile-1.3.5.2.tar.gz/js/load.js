function setLinks(link, rel, type) {
    let itm = document.createElement("link")
    itm.rel = rel
    itm.type = type
    itm.href = `${__env.resourceUrl}${link}`
    document.getElementById("indexhead").appendChild(itm);
        }

function setScripts(link) {
    let itm = document.createElement("script")
    itm.type = "text/javascript"
    itm.src = `${__env.resourceUrl}${link}`
    if(link === '/js/jquery.min.3.6.0.js'){
        itm.onload = () =>{
            setScripts('/js/popper.min.js')
            setScripts('/js/mdb.min.js')
            setScripts('/js/bootstrap.min.js')
         }
    }
    document.getElementById("indexhead").appendChild(itm);
        }

// Dynamically Set the Links and Scripts
setLinks('/img/favicon.png','icon','image/png')
setLinks('/img/sofvie-icon-4x.png','apple-touch-icon','image/png')
setLinks('/css/all.min.css','stylesheet','text/css')
setLinks('/css/bootstrap.min.css','stylesheet','text/css')
setLinks('/css/mdb-mobile.min.css','stylesheet','text/css')
setLinks('/css/select2.min.css','stylesheet','text/css')
setScripts('/js/jquery.min.3.6.0.js')

