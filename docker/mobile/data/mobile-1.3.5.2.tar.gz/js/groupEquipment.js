let eGroups = []

let all_equipment_site_job_data = []
openCacheData().then((rdata) => {
		all_equipment_site_job_data = remoteData[40].preopEquipmentSiteJob
	})

function initializeEquipmentSelect2(id) {
	if(!localStorage.getItem(`noinitialize`)) {
	  // Alow validation on select inputs except the ones with the class .custom-select (in DataTable)
	  $(`#${id}`).val("").removeAttr('readonly')
	  $(`#${id}`).select2({theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder:""})
	  .on('select2:select', function(event){
		$(this).parent().find('label').addClass('filled')
	  })
	  .on('select2:unselect', function(event){
		if($(".select2-selection__choice")[0]){
		$(this).parent().find('label').addClass('filled')
		}else {
		$(this).parent().find('label').removeClass('filled')
		}
	  })
	  .on('select2:open', function () {
		$('.select2-search__field').attr('placeholder', i18next.t("2346"))
		$('.select2-results').css({'max-height':'260px'})
	  })
	  .on('select2:close', function () {
		$('.select2-search__field').attr('placeholder', i18next.t("2346"))
	  })
	  .on('select2:clear', function(event) {
		if(event.currentTarget.id === 'lineup_workplace') {
			event.currentTarget.required = true
		}
	  })
	}
  }

function preop_site_job_equipment_select() {
	eGroups = []
	let preop_site = document.getElementById('site').value ?  document.getElementById('site').value : ""
	let preop_job = document.getElementById('job_number').value ? document.getElementById('job_number').value : ""

	let all_rest = []
	if(preop_job) {
		all_equipment_site_job_data.forEach((equip) =>{
			if(equip.psj_rld_site_id == preop_site && !equip.psj_rld_job_id ) {
				all_rest.push({id: `${equip.pet_equipment_identifier} - ${equip.pet_equipment_name}`, text: `${equip.pet_equipment_identifier} - ${equip.pet_equipment_name}`})

			}

			if(equip.psj_rld_site_id == preop_site && equip.psj_rld_job_id == preop_job) {
				all_rest.push({id: `${equip.pet_equipment_identifier} - ${equip.pet_equipment_name}`, text: `${equip.pet_equipment_identifier} - ${equip.pet_equipment_name}`})

			}

			if(!equip.psj_rld_job_id && !equip.psj_rld_site_id) {
				all_rest.push({id: `${equip.pet_equipment_identifier} - ${equip.pet_equipment_name}`, text: `${equip.pet_equipment_identifier} - ${equip.pet_equipment_name}`})
			}
		})
	
		setTimeout(()=> {
			let optionData = ``
			// TimeSheet
			if($(`#equipment_used`).length > 0) {
				optionData = `<select name="equipment_used" id="equipment_used" class="select-multiple mobile-equipment-select" multiple>`
				all_rest.forEach((data)=>{
					optionData += `<option value="${data.id}">${data.text}</option>`
				})
				optionData += `</select>`
				$(`#equipment_used`).html(optionData)
				initializeEquipmentSelect2(`equipment_used`)

				if(main_current_draft_object) {
					if(main_current_draft_object.equipment_used) {
						$(`#equipment_used`).val(main_current_draft_object.equipment_used.split('|')).trigger('change').parent().find('label').addClass('filled')
					}
				}
				setTimeout(()=>{
					$(`#equipment_used`).parent().find('label')[0].innerHTML = i18next.t('453')
				},100)
			}
			// Daily Drilling
			if($(`#equipment_id`).length > 0) {
				optionData = `<select name="equipment_id" id="equipment_id" class="select-multiple" multiple>`
				all_rest.forEach((data)=>{
					optionData += `<option value="${data.id}">${data.text}</option>`
				})
				optionData += `</select>`
				$(`#equipment_id`).html(optionData)

				initializeEquipmentSelect2(`equipment_id`)
				if(main_current_draft_object) {
					if(main_current_draft_object.equipment_id) {
						$(`#equipment_id`).val(main_current_draft_object.equipment_id).trigger('change').parent().find('label').addClass('filled')
					}
				}
				setTimeout(()=>{
					$(`#equipment_id`).parent().find('label')[0].innerHTML = `${i18next.t('428')} #`
				}, 100)

			}
			// Rescue Plan
			if($(`#equipment_involved`).length > 0) {
				optionData = `<select name="equipment_involved" id="equipment_involved" class="select-multiple" multiple>`
				all_rest.forEach((data)=>{
					optionData += `<option value="${data.id}">${data.text}</option>`
				})
				optionData += `</select>`
				$(`#equipment_involved`).html(optionData)
				initializeEquipmentSelect2(`equipment_involved`)

				if(main_current_draft_object) {
					$(`#equipment_involved`).val(main_current_draft_object.equipment_involved.split('|')).trigger('change').parent().find('label').addClass('filled')
				}
				setTimeout(()=>{
					if(window.location.pathname === '/forms/formPreliminaryIncident.php') {
						$(`#equipment_involved`).parent().find('label')[0].innerHTML = i18next.t('428')
					}
					else {
						$(`#equipment_involved`).parent().find('label')[0].innerHTML = i18next.t('450')
					}

				},100)
			}
			// Shift Report Construction
			if($(`.shift-report`).length > 0) {
				for(a=0 ; a < $(`.shift-report`).length ; a++) {
					currentVal = null
					equipId = $(`.shift-report`)[a].id
					currentVal = $(`#${equipId}`).val()
					optionData = `<select name="${equipId}" id="${equipId}" class="select-multiple" multiple>`
					all_rest.forEach((data)=>{
						optionData += `<option value="${data.id}">${data.text}</option>`
					})
					optionData += `</select>`
					$(`#${equipId}`).html(optionData)
					setTimeout(()=>{
						$(`#${equipId}`).parent().find('label')[0].innerHTML = i18next.t('428')
					}, 100)
					initializeEquipmentSelect2(equipId)
					if(currentVal.length) {
						$(`#${equipId}`).val(currentVal).trigger('change').parent().find('label').addClass('filled')
					}
					if(main_current_draft_object) {
						if(main_current_draft_object[equipId]) {
							$(`#${equipId}`).val(main_current_draft_object[equipId].split('|')).trigger('change').parent().find('label').addClass('filled')
						}
					}
				}
			}
		}, 200)
	}
}


