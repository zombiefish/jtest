class makeDonut {
  element = ``
  mode = "type"
  newChartData = "donutChart"
  totalItems = 0
  totalLegendLines = 0
  chartData = {
    chart: {
      renderTo: this.element,
      plotBackgroundColor: null,
      plotBorderWidth: null,
      plotShadow: false,
      marginTop: 60,
      height: "500",
      events: {
        redraw: (element) => {
          titlePos()
          let currentDisplay = element.target.container.querySelector(".highcharts-legend-item")
          let series = element.target.series
          let grand = 0;
          $.each(series, (i, myseries) => {
            for (let data in myseries.data) {
              if (myseries.data[data]["y"] != undefined) {
                if (myseries.data[data]["visible"]) {
                  grand += myseries.data[data]["y"]
                }
              }
            }
          })
          this.totalItems = grand
          this.chartData.title.text = grand
          element.target.setTitle({text: `${grand}
           <button class="btn btn-outline-primary btn-rounded btn-sm d-block waves-effect py-2 translate" data-i18n="1755" notes="Toggle Legend"
           id="${element.target.series[0].chart.renderTo.id}-toggle"  style="margin:0 auto; value="${element.target.series[0].chart.renderTo.id}"></button>
           <span class="d-block pt-2 translate" data-i18n="1068" notes="Company wide for the past 90 days" style="font-size: .8rem; max-width: 35vw; white-space:normal;"  ></small>
           `})
           if(currentDisplay && currentDisplay.style.display === 'none') {
             element.target.container.style.height = "650px"
           }
        function titlePos(){
          let currentX = element.target.container.querySelector("text").textLength.baseVal.value
          let currentContainer = element.target.container.clientWidth
          element.target.container.querySelector("text").setAttribute("x",(currentContainer/2) - (currentX/2))
        }

        $(`#${element.target.series[0].chart.renderTo.id}-toggle`).click(event => {
          let x = $(`#${event.currentTarget.id}`).parent().parent().find('.highcharts-legend-item')
          if (x.css("display") === "none") {
            x.css("display", `block`)
            $(`#${event.currentTarget.id}`).parent().parent().css(
              "height",
              (this.chartData.chart.height = 600 + this.totalLegendLines * 44)
            )
          } else {
            x.css("display", `none`)
            $(`#${event.currentTarget.id}`).parent().parent().css(
              "height",
              "600px"
            )
          }
        })
          $('.translate').localize()
          $('.highcharts-title').css({"left": "50%", "transform":"translateX(-50%)"})
          $('.highcharts-legend-item').css('text-transform','none')
        },
        click: () => {},
        render: () => {}
      },
      style: { fontFamily: "inherit", fontWeight: "bold" }
    },

    title: {
      text: "",
      useHTML: true,
      align: "left",
      y: 295,
      x: 0,
      style: {
        fontSize: "4rem",
        textAlign:"center"
      }
    },
    credits: {
      enabled: false
    },
    tooltip: {
      pointFormat: "{series.name}: <b>{point.percentage:.1f}%</b>"
    },
    plotOptions: {
      series: {
        showCheckbox: true
      },
      pie: {
        allowPointSelect: true,
        cursor: "pointer",
        dataLabels: {
          enabled: false
        },
        showInLegend: true
      }
    },
    colors: [
      "#0E6AC1",
      "#C0D7C5",
      "#64996B",
      "#097392",
      "#7FB5DB",
      "#FE9B56",
      "#B6D2EA",
      "#D55535",
      "#E59998",
      "#234234",
      "#FFF07C",
      "#D782B8",
      "#EF798A",
      "#20639B"
    ],
    series: [
      {
        type: "pie",
        name: this.chartLableType,
        innerSize: "75%",
       // size:"500",
        data: this.newChartData
      }
    ],
    legend: {
      symbolWidth: 0,
      symbolHeight: 20,
      symbolPadding: 24,
      itemMarginTop: 10,
      itemMarginBottom: 10,
      layout: "vertical",
      useHTML: true,
      itemStyle: {
        lineHeight: "20px",
        fontWeight: "400",
        fontSize: "20px"
      },
      labelFormatter: function() {
        let legWidth = 450
          legWidth = window.innerWidth - 175
        return (
          `<div style='width:${legWidth}px;' class='d-flex justify-content-between'><span style='overflow: hidden; text-overflow: ellipsis;'> 
          ${this.name}</span><span>${this.y}</span></div>`
        );
      }
    }
  }
  legendColors = Array([
    "#0E6AC1",
    "#C0D7C5",
    "#097392",
    "#7FB5DB",
    "#FE9B56",
    "#B6D2EA",
    "#D55535",
    "#E59998",
    "#234234",
    "#FFF07C",
    "#D782B8",
    "#EF798A",
    "#20639B"
  ])

  constructor(element, chartData, title) {
    this.mode = "type"
    this.chartData.series[0].data = chartData
    this.chartData.series[0].name = title
    this.element = element
    this.setCountFont()
    this.setTotalLegendLines(chartData.length)
    this.setItemTotals(chartData)
    this.setCenterTitle()
    $('.highcharts-title').css({"left": "50%", "transform":"translateX(-50%)"})
  }
  
  setCountFont() {
    if(window.innerWidth < 500){
      this.chartData.title.style.fontSize = '2rem'
      this.chartData.legend.itemStyle.fontSize = 12
    }

  }

  setCenterTitle(title) {
    this.chartData.title.text = `${this.totalItems}
      <button class="btn btn-outline-primary btn-rounded btn-sm d-block waves-effect py-2 translate" data-i18n="1755" notes="Toggle Legend"
      id="${ this.element}-toggle" value="${this.element}" style="margin:0 auto;"></button>
      <small class="d-block pt-2 translate" data-i18n="1068" notes="Company wide for the past 90 days" style="font-size: .8rem; max-width: 35vw; white-space:normal;"></small>`
     $('.highcharts-title').css({"left": "50%", "transform":"translateX(-50%)"})
     $('.translate').localize()

  }

  setItemTotals(data) {
    this.totalItems = 0
    for (let items in data) {
      this.totalItems += data[items][1]
    }
  }

  getChartData() {
    return this.chartData
  }

  getElement() {
    return this.element
  }

  setTotalLegendLines(total) {
    this.totalLegendLines = total
    this.chartData.chart.height = 600 + this.totalLegendLines * 44
  }

  setChartData(chartData) {
    this.chartData.series[0].data = chartData
    this.setTotalLegendLines(chartData.length)
    this.setItemTotals(chartData)
    this.setCenterTitle()
  }

  chartMainTitle(chart, title) {
    let myTitle = chart.renderer.text(`${title}`, 200, 40).attr({rotation: 0, "class": "mainTitle","position":"absolute"}).css({"fontSize": "1.5rem","margin-top": "80px","text-align":"center"}).add()
    let textBBox = myTitle.getBBox();
    let x = chart.plotLeft + chart.plotWidth * 0.5 - textBBox.width * 0.5
    myTitle.attr({ x: x })
  }

  chartToggleButtons(pickedChart, chartData, title) {
    $(`#${this.element}`).before(`
    <div class="btn-group btn-group-sm d-flex mb-3" data-toggle="buttons" id="${
      this.element
    }-radio" style="margin: 0 auto auto auto; ">
      <label class="btn btn-outline-primary form-check-label active translate" data-i18n="1054" mode="type" notes="Type">
        <input class="form-check-input" type="radio" name="chart-radio" id="type" value='type' checked> <span class='translate' data-i18n="1054" notes="Type"></span>
      </label>
      <label class="btn btn-outline-primary form-check-label translate" data-i18n="828" mode="site" notes="Site">
        <input class="form-check-input" type="radio" name="chart-radio" id="site" value='site'>
      </label>
    </div>
    `)
    $(`#${this.element}-radio`).click(e => {  
      $(`#${this.element}-radio .form-check-label`).removeClass('active')
      let displayStatus = e.target.parentNode.nextElementSibling.querySelector(".highcharts-legend-item")
        e.preventDefault();
        this.mode = e.target.getAttribute("mode");
        if(displayStatus){
        pickedChart.setChartData(chartData[this.mode], displayStatus.style);
        } 
        const myChart = Highcharts.chart(
          `${pickedChart.getElement()}`,
          pickedChart.getChartData(),
          chart => {
            pickedChart.chartMainTitle(chart, `${title}`);
          },
        )
      myChart.redraw()

    })
    
    $(`#${this.element}-toggle`).click(event => {
      var x = $(`#${event.target.value} .highcharts-legend-item`);
      if (x.css("display") === "none") {
        x.css("display", `block`);
        $(`#${event.target.value} .highcharts-container`).css(
          "height",
          (this.chartData.chart.height = 600 + this.totalLegendLines * 44)
        )
      } else {
        x.css("display", `none`);
        $(`#${event.target.value} .highcharts-container`).css(
          "height",
          "650px"
        )
      }
    })
  }
}
