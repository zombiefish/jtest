document.getElementById('test').innerHTML = `<svg
xmlns:dc="http://purl.org/dc/elements/1.1/"
xmlns:cc="http://creativecommons.org/ns#"
xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
xmlns:svg="http://www.w3.org/2000/svg"
xmlns="http://www.w3.org/2000/svg"
xmlns:xlink="http://www.w3.org/1999/xlink"
xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
width="210mm"
height="297mm"
viewBox="0 0 210 297"
version="1.1"
id="svg8"
inkscape:version="1.0.2-2 (e86c870879, 2021-01-15)"
sodipodi:docname="test.svg">
<defs
  id="defs2">
 <linearGradient
    inkscape:collect="always"
    id="linearGradient28">
   <stop
      style="stop-color:#000000;stop-opacity:1;"
      offset="0"
      id="stop24" />
   <stop
      style="stop-color:#000000;stop-opacity:0;"
      offset="1"
      id="stop26" />
 </linearGradient>
 <rect
    x="20.410714"
    y="41.577381"
    width="130.02381"
    height="26.458333"
    id="rect18" />
 <rect
    x="21.166667"
    y="49.136905"
    width="165.55357"
    height="42.333333"
    id="rect12" />
 <linearGradient
    inkscape:collect="always"
    xlink:href="#linearGradient28"
    id="linearGradient30"
    x1="29.104166"
    y1="122.46429"
    x2="83.910713"
    y2="101.29762"
    gradientUnits="userSpaceOnUse"
    gradientTransform="translate(2.2678571,19.276786)" />
</defs>
<sodipodi:namedview
  id="base"
  pagecolor="#ffffff"
  bordercolor="#666666"
  borderopacity="1.0"
  inkscape:pageopacity="0.0"
  inkscape:pageshadow="2"
  inkscape:zoom="0.7"
  inkscape:cx="500.39641"
  inkscape:cy="781.19841"
  inkscape:document-units="mm"
  inkscape:current-layer="layer1"
  inkscape:document-rotation="0"
  showgrid="false"
  inkscape:window-width="2880"
  inkscape:window-height="1526"
  inkscape:window-x="-11"
  inkscape:window-y="-11"
  inkscape:window-maximized="1" />
<metadata
  id="metadata5">
 <rdf:RDF>
   <cc:Work
      rdf:about="">
     <dc:format>image/svg+xml</dc:format>
     <dc:type
        rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
     <dc:title></dc:title>
   </cc:Work>
 </rdf:RDF>
</metadata>
<g
  inkscape:label="Layer 1"
  inkscape:groupmode="layer"
  id="layer1">
 <text
    xml:space="preserve"
    id="text10"
    style="fill:black;fill-opacity:1;line-height:1.25;stroke:none;font-family:sans-serif;font-style:normal;font-weight:normal;font-size:10.58333333px;white-space:pre;shape-inside:url(#rect12);" />
 <text
    xml:space="preserve"
    id="text16"
    style="font-style:normal;font-weight:normal;font-size:12.7px;line-height:1.35;font-family:sans-serif;white-space:pre;shape-inside:url(#rect18);fill:#000000;fill-opacity:1;stroke:none;"
    transform="translate(14.741071,78.619048)"><tspan
      x="20.410156"
      y="53.449648"><tspan
        style="font-size:12.7px" class='translate' data-i18n="4107" notes="Testing Translation"></tspan></tspan></text>
 <rect
    id="rect22"
    width="98.651787"
    height="64.255951"
    x="21.166666"
    y="94.494049"
    style="fill:url(#linearGradient30);fill-opacity:1;stroke-width:0.264583" />
</g>
</svg>`