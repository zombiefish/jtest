document.getElementById('hierarchy_of_controls').innerHTML = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 765.36 175.09">
    <defs>
        <style>
            .cls-1{fill:#66aae2;}
            .cls-2{fill:#338ed8;}
            .cls-3{fill:#0072ce;}
            .cls-4{fill:#005ba5;}
            .cls-5{fill:#00447c;}
            .cls-12,.cls-6{font-size:16px;font-family:Roboto-Bold, Roboto;font-weight:700;}
            .cls-6{fill:#fff;}
            .cls-7{letter-spacing:0.01em;}
            .cls-8{letter-spacing:-0.06em;}
            .cls-9{letter-spacing:-0.01em;}
            .cls-10{fill:none;stroke:#f6be00;stroke-miterlimit:10;stroke-width:24px;}
            .cls-11{fill:#f6be00;}
            .cls-12{letter-spacing:0.05em;}
            .cls-13{letter-spacing:0.04em;}
            .cls-14{letter-spacing:0.03em;}
        </style>
    </defs>
    <g id="Layer_2" data-name="Layer 2">
        <g id="Layer_1-2" data-name="Layer 1">
            <polygon class="cls-1" points="1.36 175.09 140.63 175.09 140.63 117.82 1.36 131.8 1.36 175.09"/>
            <polygon class="cls-2" points="157.54 175.09 296.81 175.09 296.81 102.14 157.54 116.12 157.54 175.09"/>
            <polygon class="cls-3" points="313.72 175.09 452.99 175.09 452.99 86.45 313.72 100.44 313.72 175.09"/>
            <polygon class="cls-4" points="469.9 175.09 609.17 175.09 609.17 70.77 469.9 84.76 469.9 175.09"/>
            <polygon class="cls-5" points="626.09 175.09 765.36 175.09 765.36 55.09 626.09 69.08 626.09 175.09"/>
            <text class="cls-6 translate" data-i18n="1090" note="ELIMINATION" transform="translate(648.22 128.82)"></text>
            <text class="cls-6 translate" data-i18n="2866" note="SUBSTITUTION" transform="translate(485.22 137.82)"></text>
            <text class="cls-6 translate" data-i18n="2960" note="ENGINEERING" transform="translate(332.22 143.82)"></text>
            <text class="cls-6 translate" data-i18n="5027" note="ADMINISTRATIVE" transform="translate(162.22 151.82)"></text>
            <text class="cls-6 translate" data-i18n="1087" note="PPE" transform="translate(53.22 158.82)"></text>
            <line class="cls-10" x1="1.36" y1="106.09" x2="731.13" y2="22.99"/><polygon class="cls-11" points="726.88 47.56 765.36 19.09 721.47 0 726.88 47.56"/>
            <text class="cls-12" transform="translate(9.2 111.14) rotate(-6.5)">
                <tspan class='translate' data-i18n="2448" note="Effective"></tspan>
                <tspan class="cls-14 translate" x="580" y="0" data-i18n="5026" note="MOST EFFECTIVE"></tspan>
            </text>
        </g>
    </g>
</svg>`