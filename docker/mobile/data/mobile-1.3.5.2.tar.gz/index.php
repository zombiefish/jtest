<?php	
  $strPageTitle = '';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<style>
  #linkMySDS img{height:100px; margin:auto;}
  .dark-theme #linkMySDS img {filter:invert(100%) brightness(200%);}
</style>
<main class="col containter-fluid mobile-content home">
  <div class="row">
		<div class="col-6 mb-2 d-flex align-items-stretch flex-column">
			<button id='testToolbox' type="button" onclick="window.location.href = '<?php echo _TOOLBOX ?>';" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block py-3 px-1 flex-1 align-items-stretch flex-column z-depth-1-half">
        <i class="fa fa-toolbox fa-4x d-block pb-2"></i>
        <strong><span class='translate' data-i18n="977" notes="Toolbox"></span></strong>
      </button>
      <a href="<?php echo _TOOLBOX?>" id="ToolBoxBadge"></a>
		</div>
    <div class="col-6 mb-2 d-flex align-items-stretch flex-column">
			<button id='testActionItems' type="button" onclick="window.location.href = '<?php echo _ACTIONITEMS ?>';" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block py-3 px-1 flex-1 align-items-stretch flex-column z-depth-1-half">
        <i class="far fa-calendar-alt fa-4x d-block pb-2"></i>
        <strong><span class='translate' data-i18n="1037" notes="Action Items"></span></strong>
      </button>
      <a href="<?php echo _ACTIONITEMS ?>" id="ActionItemsBadge"></a>
		</div>
  </div>
  <div class="row">
		<div class="col-6 mb-2 d-flex align-items-stretch flex-column">
			<button id='testIncidentManagement' type="button" onclick="window.location.href = '<?php echo _HAZARDINCIDENTMANAGEMENT ?>';" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block py-3 px-1 flex-1 align-items-stretch flex-column z-depth-1-half">
        <i class="fa fa-fire-extinguisher fa-4x d-block pb-2"></i>
        <strong><span class='translate' data-i18n="2328" notes="Hazard and Incident management"></span></strong>
      </button>
      <a id="HazIncBadge"></a>
		</div>
    <div class="col-6 mb-2 d-flex align-items-stretch flex-column"> 
			<button id='testRiskManagement' type="button" onclick="window.location.href = '<?php echo _RISKASSESSMENT ?>';" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block py-3 px-1 flex-1 align-items-stretch flex-column z-depth-1-half" >
        <i class="fa fa-exclamation-triangle fa-4x d-block pb-2"></i>
        <strong><span class='translate' data-i18n="1358" notes="Risk Assessment"></span></strong>
      </button>
		</div>
  </div>
  <div class="row">
		<div class="col-6 mb-2 d-flex align-items-stretch flex-column">
			<button id='testSafetyTrends' type="button" onclick="window.location.href = '<?php echo _SAFETYTRENDS ?>';" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block py-3 px-1 flex-1 align-items-stretch flex-column z-depth-1-half">
        <i class="fa fa-chart-pie fa-4x d-block pb-2"></i>
        <strong><span class='translate' data-i18n="1359" notes="Safety Trends"></span></strong>
      </button>
		</div>
    <div class="col-6 mb-2 d-flex align-items-stretch flex-column">
			<button id='testProfile' type="button" onclick="window.location.href = '<?php echo _PROFILE ?>';" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block py-3 px-1 flex-1 align-items-stretch flex-column z-depth-1-half">
        <i class="fa fa-address-card fa-4x d-block pb-2"></i>
        <strong><span class='translate' data-i18n="990" notes="My Profile"></span></strong>
      </button>
      <a  href="<?php echo _PROFILE ?>"  id="ProfileBadge"></a>
    </div>
  </div>
  <div class="row">
    <div class="col-12 mb-2 d-flex align-items-stretch flex-column" id="documentBadge">
			<button id='testDocuments' type="button" onclick="window.location.href = '<?php echo _DOCUMENTS ?>';" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block py-3 px-1 flex-1 align-items-stretch flex-column z-depth-1-half">
        <i class="fa fa-folder-open fa-4x d-block pb-2"></i>
        <strong><span class='translate' data-i18n="1344" notes="Documents"></span></strong>
      </button>

      <a href="<?php echo _DOCUMENTS?>"id="DocumentsBadge"></a>
		</div>   
    <div class="col-6 mb-2 align-items-stretch flex-column d-none" id="mysds">
			<button id='linkMySDS' type="button" onclick="openMySDS()" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block py-3 px-1 flex-1 align-items-stretch flex-column z-depth-1-half">
        <img src="images/MySDS_logo.svg" class="d-block pb-2" alt="MySDS-logo">
      </button>
		</div>
  
  </div>

</main>

<div class="spinnerContainer SWspinnerContainer" id="indexSpinner">
  <div class="preloader-wrapper big active">
    <div class="spinner-layer spinner-blue-only">
      <div class="circle-clipper left">
        <div class="circle"></div>
      </div>
      <div class="gap-patch">
        <div class="circle"></div>
      </div>
      <div class="circle-clipper right">
        <div class="circle"></div>
      </div>
    </div>
  </div>
</div>

<script src="<?php echo _RESOURCEDOMAIN; ?>/js/pouchdb.min.js"></script>
<script src="<?php echo _RESOURCEDOMAIN; ?>/js/pouchdb.find.js"></script>
<script type="text/javascript">

debug=_DEBUG
let finalTargets = []
// ***************  Check if On line and run as expected ****************
localStorage.removeItem("noinitialize")

  // Load the Service worker
LoadServiceworker()
  
// Sync old pouchDB to new. Can remove after 1.3.1 release
pouchDatadatabaseExists('safetodotemp').then((exists) => {
  if(exists) {
    let dbDraft = new PouchDB('sofvie_drafts', {auto_compaction: true})
    let dbDraftOld = new PouchDB('safetodotemp', {skip_setup: true})

    dbDraftOld.sync(dbDraft).on('complete', function () {
      dbDraftOld.destroy()
    })
  }
})

function openMySDS() {
  access = JSON.parse(localStorage.getItem('token')).access
  request_url = `<?php echo _API_URL ?>/api/utils/mysds-token/`
  $.ajax({
			url: request_url,
			type: 'get',
			dataType: 'json',
			contentType: 'application/json',
			beforeSend: function(request) {
				request.setRequestHeader("Authorization", `Bearer ${access}`)              
			},
			success: function (data) {
        window.open(`https://clients.mysds.ca/api.php?token=${data.token}`)
			},
			error: function (data) {
				console.log('error ', data)
			}

		})
}

function pouchDatadatabaseExists(dbname) {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(`_pouch_${dbname}`)
    req.onsuccess = function () {
      resolve(true)
    }
    req.onupgradeneeded = function (e) {
      e.target.transaction.abort()
      resolve(false)
    }
  })
}

function updateOfflineDocs(){
  let blobConfig = {
      draftDbName: 'offlineDocuments', 
      draftRemoteSync: false,		
  }
  docDb = new PouchDB(blobConfig.draftDbName, { auto_compaction: true })
  return new Promise((resolve, reject) =>	{
  docDb.allDocs().then(function (doc) {
          let cookieData = []
          doc.rows.forEach((docs)=>{
              cookieData.push(docs.id)
          })
          localStorage.setItem('offline_docs', JSON.stringify(cookieData))
          resolve("ok")
        }).catch(function (err) {
          console.log("Problem Getting all Docs",err)
          })

  }).catch(err => {
    reject(err)
  }) // End Promise
}

function getBlobData(data, currentOfflineDocs,currentDocs) {
  if(data) {
    let blobArray = []
      data.forEach((data)=>{
        blobArray.push({
        _id: `${data.doa_drm_id}`,
        blob: data.doa_offline_attachment,
        timestamp: + new Date
      })
    })

    docDb.bulkDocs(blobArray).then((response) => {
        updateOfflineDocs()
      })
      .catch(function (err) {
          console.log("Error Saving Document", err)
        })
    }
}

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
}

  function getOfflineData() {
    let token = ""
    $.ajaxSetup({ cache: false })
    let allCurrentRecords = []
    updateOfflineDocs().then((data)=>{
      setTimeout(()=>{
      token = JSON.parse(window.localStorage.getItem('token'))
      let languageCookie = getCookie("lang")
      var urlString = `/ajax/getRemoteData.php?lang=${languageCookie}&auth=${token.access}`
      $.get(urlString,(data) => {
        getRmmJraRemoteData()
        allCurrentRecords = data[27].DocumentReview
        // Check to see if the Language Changed
        if(data[32].UserSettingsProfile[0].upr_language !== languageCookie){
          userLang = data[32].UserSettingsProfile[0].upr_language
          document.cookie = `lang=${userLang}; expires= ${now.toUTCString()}`
          window.location.href = `/index.php`
        }
      }).done(() => {
          localStorage.setItem('loadedflag','true')
          var urlString_selectLists = `/includes/generateLists.php?lang=${languageCookie}`
          $.get(urlString_selectLists,(data) => {
            localStorage.setItem('selectcacheloaded','true')
            //  localStorage.removeItem('selectLists')     
            //  localStorage.setItem('selectLists', JSON.stringify(data))
          }).done(() => {	
              openCacheData().then(()=>{
                if(remoteData){
                  window.localStorage.setItem("remotedatastate", true)
                } else {
                  window.localStorage.setItem("remotedatastate", false)
                }
                // Load the Notification Badges
                loadToolboxToDo()
                loadAssignedActionItems()
                loadProfileTrainingRecords()
                loadDocuments()     
                loadAddonModulePermission()
                let mobileTheme = ''
                if(remoteData[_MOBILESETTINGS].UserSettingsProfile) {
                  mobileTheme = `${remoteData[_MOBILESETTINGS].UserSettingsProfile[0].upr_theme_mobile}-theme`
                }
                // set the theme from the Settings
                localStorage.setItem('mobileTheme',mobileTheme)
                // if it is set to default them take the setting from the browser
                if(mobileTheme === "default"){
                  localStorage.setItem('mobileTheme','light-theme')
                  if(window.matchMedia('(prefers-color-scheme: dark)').matches){
                    localStorage.setItem('mobileTheme','dark-theme')
                  }
                }

                if(localStorage.getItem('mobileTheme'))
                {
                  document.body.classList.remove('dark-theme')
                  document.body.classList.remove('light-theme')
                  document.body.classList.add(mobileTheme)
                }

                // Get the Offline Documents
                getOfflineDocuments(allCurrentRecords)
               window.localStorage.setItem('offlinedocstate',true)
                // Get the User sites
                getUserSites(remoteData)
                // Get the Users Jobs
                getUserJobs(remoteData)
                // Get the User Lineups
                getUserLineup()
                // Get the user Employee Remote Data
                getUserEmployeeRemoteData()
                // get the  all jra data
                getRmmJraRemoteData()
                // get the action attachments 
                getGeneralActionAttachmentData()
                // get the hazard attachments 
                getHazardActionAttachmentData()
                
                if(checkLotoPermission()){
                  // get the loto equipments
                  getLOTOEquipmentData()
                  // get the loto procedures
                  getLOTOAttachmentData()
                }

                // get the assgin multi user action
                if(getAssignMultipleAction()){
                  localStorage.setItem('assignmultiuser','true')
                }
                else{
                  localStorage.setItem('assignmultiuser','false')
                }
              })
          })
        })
      },1000)

    })
  }

  function getOfflineDataAPP() {
    let token = ""
    $.ajaxSetup({ cache: false })
    let allCurrentRecords = []
  //  updateOfflineDocs().then((data)=>{
   //   setTimeout(()=>{
      token = JSON.parse(window.localStorage.getItem('token'))
      let languageCookie = getCookie("lang")
      var urlString = `/ajax/getRemoteData.php?lang=${languageCookie}&auth=${token.access}&app=yes`     
      $.get(urlString,(data) => {
        //getRmmJraRemoteData()
        allCurrentRecords = data[27].DocumentReview
        // Check to see if the Language Changed
        if(data[32].UserSettingsProfile[0].upr_language !== languageCookie){
          userLang = data[32].UserSettingsProfile[0].upr_language
          document.cookie = `lang=${userLang}; expires= ${now.toUTCString()}`
          window.location.href = `/index.php`
        }
      }).done(() => {
          localStorage.setItem('loadedflag','true')
          var urlString_selectLists = `/includes/generateLists.php?lang=${languageCookie}`
          $.get(urlString_selectLists,(data) => {
            localStorage.setItem('selectcacheloaded','true')
            //  localStorage.removeItem('selectLists')     
            //  localStorage.setItem('selectLists', JSON.stringify(data))
          }).done(() => {	
              openCacheData().then(()=>{
                if(remoteData){
                  window.localStorage.setItem("remotedatastate", true)
                } else {
                  window.localStorage.setItem("remotedatastate", false)
                }
                // Load the Notification Badges
              //  loadToolboxToDo()
               // loadAssignedActionItems()
              //  loadProfileTrainingRecords()
               // loadDocuments()
               // loadAddonModulePermission()
                let mobileTheme = ''
                if(remoteData[_MOBILESETTINGS].UserSettingsProfile) {
                  mobileTheme = `${remoteData[_MOBILESETTINGS].UserSettingsProfile[0].upr_theme_mobile}-theme`
                }
                // set the theme from the Settings
                localStorage.setItem('mobileTheme',mobileTheme)
                // if it is set to default them take the setting from the browser
                if(mobileTheme === "default"){
                  localStorage.setItem('mobileTheme','light-theme')
                  if(window.matchMedia('(prefers-color-scheme: dark)').matches){
                    localStorage.setItem('mobileTheme','dark-theme')
                  }
                }

                if(localStorage.getItem('mobileTheme'))
                {
                  document.body.classList.remove('dark-theme')
                  document.body.classList.remove('light-theme')
                  document.body.classList.add(mobileTheme)
                }

                // Get the Offline Documents
               // getOfflineDocuments(allCurrentRecords)
                window.localStorage.setItem('offlinedocstate',true)
                setTimeout(() => {
                  let message = {
                    name: "index-loaded",
                    data: ""
                  }
							  window.parent.postMessage(JSON.stringify(message), '*')
						    }, 1000)
                // Get the User sites
                getUserSites(remoteData)
                // Get the Users Jobs
                getUserJobs(remoteData)
                // Get the User Lineups
                getUserLineup()
                // Get the user Employee Remote Data
                getUserEmployeeRemoteData()
                // get the  all jra data
              // getRmmJraRemoteData()
                localStorage.setItem(`supervisorSelectListloaded`,'true')
                localStorage.setItem(`employeeIncludingDisabledSelectListloaded`,'true')
                localStorage.setItem(`employeeSelectListloaded`,'true')
                localStorage.setItem(`distributionSelectListloaded`,'true')
                localStorage.setItem(`rmmApproversSelectListloaded`,'true')
                // get the action attachments 
               // getGeneralActionAttachmentData()
                localStorage.setItem(`generalActionAttachment`,'true')
                // get the hazard attachments 
              //  getHazardActionAttachmentData()
                localStorage.setItem(`hazardActionAttachment`,'true')
                
                if(checkLotoPermission()){
                  // get the loto equipments
                  getLOTOEquipmentData()
                  // get the loto procedures
                  getLOTOAttachmentData()
                }
                // get the assgin multi user action
                if(getAssignMultipleAction()){
                  localStorage.setItem('assignmultiuser','true')
                }
                else{
                  localStorage.setItem('assignmultiuser','false')
                }
              })
          })
        })
    //  },1000)

 //   })
  }

  function checkIncidentFormAccess(remoteData) {
    const formAccessData = remoteData[_FORMACCESS].FormAccess
    if(formAccessData) {
      if(!formAccessData.find(o => o.FormID == 224335) && !formAccessData.find(o => o.FormID == 220234) &&
        !formAccessData.find(o => o.FormID == 221746) && !formAccessData.find(o => o.FormID == 248310) &&
        !formAccessData.find(o => o.FormID == 131042)) {
          document.getElementById('testIncidentManagement').disabled = true
      }
    } else {
      document.getElementById('testIncidentManagement').disabled = true
    }

  }

  function LoadServiceworker() {
    if ('serviceWorker' in navigator) {																						// Does this browser support service workers.
      window.addEventListener('load', () => {																// Listen for a load event
        navigator.serviceWorker.register('/sw.js').then((registration) => {// Register the service workers

          if(registration.active.state === "activated") {
            localStorage.setItem('serviceworkerstate','true')	
          }
          // Registration was successful
          if(debug) console.log('ServiceWorker registration successful with scope: ', registration.scope)
          // record messages
        }, (err) => {
          // registration failed 
          console.error('ServiceWorker registration failed: ' + err)							// Log the error
        })

        navigator.serviceWorker.addEventListener('controllerchange', (event) => {
              // Listen for changes in the state of our ServiceWorker
              // This only occurs when a new SW is installed. Otherwise, we just check to see if a SW is currently controlling the page below
          navigator.serviceWorker.controller.addEventListener('statechange', (data) => { // List for a state change event
            if(debug) console.log('[controllerchange][statechange] ' + 'A "statechange" has occured: ', data.target.state)

            // If the ServiceWorker becomes "activated", let the user know they can go offline!
            if (data.target.state === 'activated') {
                localStorage.setItem('serviceworkerstate','true')	
                localStorage.setItem('cacheloaded','true')
                // Show the "You may now use offline" notification
                if(debug) console.log('Received notification cache has finished loading')

                } 
              }
          )
        })
        
        if (navigator.serviceWorker.controller) {		
          localStorage.setItem('serviceworkerstate','true')
          localStorage.setItem('cacheloaded','true')
          // Are we currently controlled by a SW?
          if(debug) console.log('This page is currently controlled by:', navigator.serviceWorker.controller)
        }
      })
    }
  }

  function loadToolboxToDo(){
    let number = getTargetToDo()
    if(number > 0){
      let ele = document.getElementById("ToolBoxBadge")
      ele.innerText = number
      ele.classList.add('badge')
      ele.classList.add('badge-secondary')
      ele.classList.add('position-absolute')
    }
    
    return number
  }

  function loadAssignedActionItems(){
    let numbers = getAssignedActionItems()
    let ele = document.getElementById("ActionItemsBadge") 

    if(numbers.overDue > 0){
      // use the red badge
      ele.classList.add("badge")
      ele.classList.add("badge-danger")
      ele.classList.add("position-absolute")
      ele.innerText = numbers.open
    } else if(numbers.open > 0) {
      // use the yellow badge
      ele.classList.add('badge')
      ele.classList.add('badge-secondary')
      ele.classList.add('position-absolute')
      ele.innerText = numbers.open
    } else {
      ele.innerText = ""
      ele.classList.remove('badge')
      ele.classList.remove('badge-secondary')
      ele.classList.remove('badge-danger')
      ele.classList.remove("position-absolute")
    }
  }

  function loadProfileTrainingRecords(){
    let numbers = getTrainingRecords()
    let ele = document.getElementById("ProfileBadge")
    if(numbers.expired > 0){
      // use the red badge
      ele.classList.add("badge")
      ele.classList.add("badge-danger")
      ele.classList.add("position-absolute")
      ele.innerText = numbers.expired
      
    } else if (numbers.aboutToExpire > 0) {
      // use the yellow badge
      ele.classList.add('badge')
      ele.classList.add('badge-secondary')
      ele.classList.add('position-absolute')
      ele.innerText = numbers.aboutToExpire
    } else {
        ele.innerText = ""
        ele.classList.remove('badge')
        ele.classList.remove('badge-secondary')
        ele.classList.remove('badge-danger')
        ele.classList.remove("position-absolute")
    }
    // return number
  }

  function loadDocuments(){
    let numbers = getDocumentsToReview()
    let ele = document.getElementById("DocumentsBadge")
    
    ele.innerText = numbers.total>0?numbers.total:''
    if(numbers.overdue){
      // use the red badge.
      ele.classList.add("badge")
      ele.classList.add("badge-danger")
      ele.classList.add("position-absolute")
    } else if(numbers.total > 0){
      //use the yellow badge.
      ele.classList.add('badge')
      ele.classList.add('badge-secondary')
      ele.classList.add('position-absolute')
    }

  }

  function getTargetToDo(){
    let monthlyTargetCounts = remoteData[20]['EmployeeTargetCounts']['30']
    let annuallyTargetCounts = remoteData[20]['EmployeeTargetCounts']['365']
    let quarterlyTargetCounts = remoteData[20]['EmployeeTargetCounts']['90']
    let biannaualTargetCounts = remoteData[20]['EmployeeTargetCounts']['182']

    let periods = [
      monthlyTargetCounts,
      annuallyTargetCounts,
      quarterlyTargetCounts,
      biannaualTargetCounts
    ]

    let targets = remoteData[0]['targets']
    let toDo = 0
    for(period of periods){
      if(period){        
        for(count of period){
          toDo += count.todo          
        }
      }
    }    
    return toDo
  }

  function getAssignedActionItems(){
    let ha = remoteData[4]['HazardActions']
    let ga = remoteData[28]['GeneralActions'] 
    let ia = remoteData[5]['IncidentActions']
    let items = [ha, ga, ia]
    let itemOverDue = 0 
    let open = 0
    for(item of items){
      if(item){
        open += item.length
        for(act of item){
          if(new Date(act.sga_action_by_when) < Date.now()){
            itemOverDue ++
          }
        }
      }
    }

    let rtrn = {
      open: open,
      overDue: itemOverDue
    }
  return rtrn
  }

  function getProfileRecords(profileRecords){
    let aboutToExpire = 0
    let expired = 0
    let daysCloseToExipiry = 10  
    if(profileRecords){
      for(train of profileRecords){
        if(train.etr_expiry_date!=null){
          if(train.etr_no_expiry_date=="0"){
            let expiredDate = new Date(train.etr_expiry_date)
            let closeToexpiredDate = new Date()
            closeToexpiredDate = addDays(expiredDate, -daysCloseToExipiry)
            if(Date.now() > closeToexpiredDate && Date.now() < expiredDate){
              aboutToExpire ++
            } else if(expiredDate < Date.now()){
              expired ++
            }
          }
        }
      }
    }
    let rtrn = {
      expired: expired,
      aboutToExpire: aboutToExpire
    }
    return rtrn
  }

  function addDays(date, days) {
      return new Date(
          date.getFullYear(),
          date.getMonth(),
          date.getDate() + days,
          date.getHours(),
          date.getMinutes(),
          date.getSeconds(),
          date.getMilliseconds()
      );
  }

  function getTrainingRecords(profileRecords){
    let trainingRecs = remoteData[3]['Training']
    let certificationRecs = remoteData[11]['Certifications']
    
    let train = getProfileRecords(trainingRecs)
    let cert = getProfileRecords(certificationRecs)
    let rtrn = {
      expired: train.expired + cert.expired,
      aboutToExpire: train.aboutToExpire + cert.aboutToExpire
    }
    return rtrn
  }

  // this function returns true or false based on the user role add-on module permission
  function loadAddonModulePermission(){
    let showMySDS = false
    let addonRecords = remoteData[33]['UserAddonModulePermission']  
    if(addonRecords){
      for(rec of addonRecords){
        if(rec.ape_name==="MySDS"){
          showMySDS = true
        }    
      }
    }
    else{
      showMySDS = false
    }

    if(!showMySDS){
      document.getElementById("mysds").classList.remove("d-flex")    
      document.getElementById("mysds").classList.add("d-none")   
    }
    else{
      document.getElementById("mysds").classList.add("d-flex")
      document.getElementById("mysds").classList.remove("d-none")
      document.getElementById("documentBadge").classList.remove("col-12")
      document.getElementById("documentBadge").classList.add("col-6")  
    }
    
  }

  function getDocumentsToReview(){
    let docsToReview = remoteData[27]['DocumentReview']
    let rtrn = {
      overdue : false,
      total : 0
    }
    let reviewed = 0
    if(docsToReview){
      // Determine of there are any overdue documents.
      for(doc of docsToReview){
        let d = new Date( doc.drm_review_by_date)
        if (doc.drr_is_reviewed ==0){
          if(d < Date.now()){
            rtrn.overdue = true
          } 
        } else {
            reviewed ++
        }
      }
      rtrn.total = docsToReview.length - reviewed 
    }
    return rtrn
  }

</script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>