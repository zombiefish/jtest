var CACHE_NAME = 'SofvieCache'; 						// Declare service worker cache name

function createURLCache(ENVURL) {
  var urlsToCache = [
    // Create a manifest of resources to preload
    "/",
    "/index.php",
    "/login.html",
    "/ajax/getRemoteData.php",
    "/forms/formCustomForm.php",
    "/forms/formDailyLog.php",
    "/forms/formDailyDrillingReport.php",
    "/forms/formCapAndPowderMagAudit.php",
    "/forms/formEmployeeDiscipline.php",
    "/forms/formEmployeeReviewAnnual.php",
    "/forms/formEmployeeReview60Day.php",
    "/forms/formGeneralAction.php",
    "/forms/formGeneralStatement.php",
    "/forms/formHap.php",
    "/forms/formHotColdEvaluation.php",
    "/forms/formHotWorkPermit.php",
    "/forms/formIncidentStatement.php",
    "/forms/formJobDemonstration.php",
    "/forms/formJobObservation.php",
    "/forms/formLifeSavingRules.php",
    "/forms/formMeetingMinutes.php",
    "/forms/formMonthlySafetyMeeting.php",
    "/forms/formPersonalContact.php",
    "/forms/formPHRAudit.php",
    "/forms/formPositiveAction.php",
    "/forms/formPPEAudit.php",
    "/forms/formPreliminaryIncident.php",
    "/forms/formPreliminaryInvestigation.php",
    "/forms/formJobRiskAssessment.php",
    "/forms/formPreOpAudit.php",
    "/forms/formPreOp.php",
    "/forms/formPreTask.php",
    "/forms/formPreTask_Vale.php",
    "/forms/formSafetyCardAudit.php",
    "/forms/formSafetyJHSBoardAudit.php",
    "/forms/formShiftReportConstruction.php",
    "/forms/formShiftReportCraigLogistics.php",
    "/forms/formShiftReportDevelopment.php",
    "/forms/formA&MShiftReport.php",
    "/forms/formWorkCard.php",
    "/forms/formSupervisorLineUpAudit.php",
    "/forms/formSupervisorTrainingAudit.php",
    "/forms/formTagBoardAudit.php",
    "/forms/formTaskVsMTCUTraining.php",
    "/forms/formTrainingAssessment.php",
    "/forms/formTimeSheet.php",
    "/forms/formVFLAudit.php",
    "/forms/formViewpointAudit.php",
    "/forms/formWorkplaceInspection.php",
    "/forms/formRescuePlan.php",
    "/forms/formConfinedSpaceWorkingAtHeightsPermit.php",
    "/forms/formConfinedSpaceActivityLog.php",
    "/forms/formTFSR.php",
    '/forms/includes/CommonFormFooter.php',
    '/forms/includes/CommonFormFooterRMM.php',
    '/forms/includes/CommonFormHeader.php',
    '/forms/includes/CommonFormHeaderRMM.php',
    '/forms/formLOTO.php',
    "/js/chart.js",
    "/js/formHandler2.js",
    "/js/RAformHandler.js",
    "/js/selectwithsearch.js",
    "/js/signaturePad.js",
    "/js/sofvie-main.js",
    "/js/moment.min.js",
    "/modals/alerts.js",
    "/modals/alertsRmm.js",
    "/modals/hapModal.js",
    "/modals/hapModalRmm.js",
    "/modals/posModal.js",
    "/modals/genModal.js",
    "/modals/genModalRmm.js",
    "/modals/preOpModal.js",
    "/modals/reSubmitAlert.js",
    "/modals/draftLanguageAlert.js",
    "/modals/commentModal.js",
    "/modals/likeHistoryModal.js",
    "/modals/viewCommentsModal.js",
    "/modals/generic.html",
    "/js/load.js",
    "/js/jquery.min.3.6.0.js",
    "/js/translate.js",
    "/env/mobileenv.js",
    "/pages/ActionItems.php",
    "/pages/HazardAndIncidentManagement.php",
    "/pages/MyProfile.php",
    "/pages/RiskAssessment.php",
    "/pages/SafetyTrends.php",
    "/pages/Toolbox.php",
    "/pages/Settings.php",
    "/supportRequest.php",
    "/preLogin/termsAndPrivacy.php",
    "/pages/Documents.php",
    "/locales/datatables/i18n/fr.json",
    "/locales/datatables/i18n/en.json",
    "/locales/datatables/i18n/es.json",
    "/locales/translation/translation_fr.json",
    "/locales/translation/translation_en.json",
    "/locales/translation/translation_es.json",
    "/images/SafetyTriangle_i18n.png",
    "/images/hierarchy_of_controls.js",
    "/images/MySDS_logo.svg",
    "/locales/pickadate/languages.js",
    "/locales/pickatime/languages.js",
    "/locales/select2/languages.js",
    "/js/i18next.js",
    "/js/jquery-i18next.js",
    "/js/i18nextXHRBackend.js",
    "/manifest.json",
    ENVURL + "/css/bootstrap.min.css",
    ENVURL + "/css/mdb-mobile.min.css",
    ENVURL + "/css/select2.min.css",
    ENVURL + "/css/all.min.css",
    ENVURL + "/highcharts/highcharts.js",
    ENVURL + "/font/roboto/Roboto-Light.eot",
    ENVURL + "/font/roboto/Roboto-Light.ttf",
    ENVURL + "/font/roboto/Roboto-Light.woff",
    ENVURL + "/font/roboto/Roboto-Light.woff2",
    ENVURL + "/font/roboto/Roboto-Bold.woff2",
    ENVURL + "/font/roboto/Roboto-Bold.woff",
    ENVURL + "/font/roboto/Roboto-Bold.ttf",
    ENVURL + "/webfonts/fa-regular-400.eot",
    ENVURL + "/webfonts/fa-regular-400.ttf",
    ENVURL + "/webfonts/fa-regular-400.woff",
    ENVURL + "/webfonts/fa-regular-400.woff2",
    ENVURL + "/webfonts/fa-regular-400.svg",
    ENVURL + "/webfonts/fa-solid-900.eot",
    ENVURL + "/webfonts/fa-solid-900.ttf",
    ENVURL + "/webfonts/fa-solid-900.woff",
    ENVURL + "/webfonts/fa-solid-900.woff2",
    ENVURL + "/webfonts/fa-solid-900.svg",
    ENVURL + "/font/roboto/Roboto-Medium.eot",
    ENVURL + "/font/roboto/Roboto-Medium.ttf",
    ENVURL + "/font/roboto/Roboto-Medium.woff",
    ENVURL + "/font/roboto/Roboto-Medium.woff2",
    ENVURL + "/font/roboto/Roboto-Regular.eot",
    ENVURL + "/font/roboto/Roboto-Regular.ttf",
    ENVURL + "/font/roboto/Roboto-Regular.woff",
    ENVURL + "/font/roboto/Roboto-Regular.woff2",
    ENVURL + "/img/favicon.png",
    ENVURL + "/img/login-bg.jpg",
    ENVURL + "/img/menu_img.png",
    ENVURL + "/img/temperature_reference_chart.jpg",
    ENVURL + "/img/SafetyTriangle_i18n.png",
    ENVURL + "/img/lightbox/default-skin.png",
    ENVURL + "/img/lightbox/default-skin.svg",
    ENVURL + "/img/lightbox/preloader.gif",
    ENVURL + "/img/overlays/01.png",
    ENVURL + "/img/overlays/02.png",
    ENVURL + "/img/overlays/03.png",
    ENVURL + "/img/overlays/04.png",
    ENVURL + "/img/overlays/05.png",
    ENVURL + "/img/overlays/06.png",
    ENVURL + "/img/overlays/07.png",
    ENVURL + "/img/overlays/08.png",
    ENVURL + "/img/overlays/09.png",
    ENVURL + "/img/svg/arrow_left.svg",
    ENVURL + "/img/svg/arrow_right.svg",
    ENVURL + "/img/svg/favicon.svg",
    ENVURL + "/img/svg/sofvie-s-white.svg",
    ENVURL + "/img/svg/sofvieBlue.svg",
    ENVURL + "/img/svg/sofvieWhite.svg",
    ENVURL + "/img/sofvie-icon-4x.png",
    ENVURL + "/js/bootstrap.js",
    ENVURL + "/js/bootstrap.min.js",
    ENVURL + "/js/jquery.signaturepad.min.js",
    ENVURL + "/js/json2.min.js",
    ENVURL + "/js/mdb.js",
    ENVURL + "/js/mdb.lite.js",
    ENVURL + "/js/mdb.lite.min.js",
    ENVURL + "/js/moment-with-locales.min.js",
    ENVURL + "/js/mdb.min.js",
    ENVURL + "/js/popper.min.js",
    ENVURL + "/js/select2.min.js",
    ENVURL + "/js/pouchdb.find.js",
    ENVURL + "/js/pouchdb.min.js",
    ENVURL + "/js/addons/datatables-select.js",
    ENVURL + "/js/addons/datatables-select.min.js",
    ENVURL + "/js/addons/datatables.js",
    ENVURL + "/js/addons/datatables.min.js",
    ENVURL + "/js/addons-pro/stepper.js",
    ENVURL + "/js/addons-pro/stepper.min.js",
    ENVURL + "/js/addons-pro/steppers.js",
    ENVURL + "/js/addons-pro/steppers.min.js",
    ENVURL + "/js/addons-pro/timeline.js",
    ENVURL + "/js/modules/buttons.js",
    ENVURL + "/js/modules/cards.js",
    ENVURL + "/js/modules/character-counter.js",
    ENVURL + "/js/modules/chips.js",
    ENVURL + "/js/modules/collapsible.js",
    ENVURL + "/js/modules/default-file-input.js",
    ENVURL + "/js/modules/dropdown.js",
    ENVURL + "/js/modules/file-input.js",
    ENVURL + "/js/modules/forms-free.js",
    ENVURL + "/js/modules/material-select.js",
    ENVURL + "/js/modules/mdb-autocomplete.js",
    ENVURL + "/js/modules/preloading.js",
    ENVURL + "/js/modules/range-input.js",
    ENVURL + "/js/modules/scrolling-navbar.js",
    ENVURL + "/js/modules/sidenav.js",
    ENVURL + "/js/modules/smooth-scroll.js",
    ENVURL + "/js/modules/sticky.js",
    ENVURL + "/mdb-addons/mdb-lightbox-ui.html",
    ENVURL + "/mdb-addons/preloader.html",
  ]

  return urlsToCache
}

debug = true;

self.addEventListener("install", function (event) {
  // Install the service worker
  // Is this a first time install?
  // Perform install steps
  event.waitUntil(
    // Block the SW until we've finished preloading the cache
    // Cache the following and don't do anything else until completed
    caches
      // With the cache
      .open(CACHE_NAME)
      // Open the cache
      .then(function (cache) {
        if (debug) console.log("Adding cache files")

        let files = createURLCache(getResourcePath(event.target.location.host.split('.')[0]))

        // Comment out for production
        //cache = cacheDebugger(cache, files, event.target.location.origin)

        cache.addAll(files)

        return cache
        // Load all files in the preload manifest (note, this is NOT manifest.json)
      })
      .then(function (response) {
        if (debug) console.log('Cache finished loading');
        return self.skipWaiting()
        // Trigger notification that we've completed loading the cache
      })
  );
});

function getResourcePath(srv) {
  let envurl = ''
  switch (srv) {
    case 'sofmobile':
      envurl = `https://sofvieresources.sofvie.com`
      break
    case 'mobile':
      envurl = `https://devcore-resources.sofvie.com`
      break
    case 'localhost:85':
      envurl = `https://devcore-resources.sofvie.com`
      break
    case 'james':
      envurl = `https://res.sofvie.com`
      break
    default:
      envurl = `https://${srv.split('-')[0]}-resources.sofvie.com`
      break
  }
  return envurl
}

function convertURL(data, e) {
  url = `${getResourcePath(e.target.location.host.split('.')[0])}`
  for (a = 3; a < data.length; a++) {
    url = url + `/${data[a]}`
  }
  return url
}

self.addEventListener('fetch', (e) => {
  e.respondWith((async () => {
    const response = await fetch(e.request).catch((err) => {
    })
    let url = e.request.url.replace(/\/$/, '').split("/")
    let endPointExceptions = ['refresh', 'get-offline-documents', 'token', 'refresh']
    let endPoint = endPointExceptions.find(element => element === url[url.length - 1])
    if (response) {
      if (!endPoint) {
        const cache = await caches.open(CACHE_NAME);
        await putcache(e, cache, response)
        const thecache = await getcache(e, cache)
        return thecache
      }
    }
    if (!endPoint) {
      const r = await caches.match(e.request, { ignoreVary: true });
      if (r) { return r; }
      else {
        var req = new Request(convertURL(e.request.url.split("/"), e))
        const p = await caches.match(req, { ignoreVary: true })
        if (p) { return p; }
      }
    }
    else {
      return response
    }
  })());
})

async function putcache(e, cache, response) {
  await cache.put(e.request.url.split("?")[0], response.clone()).catch((err) => { })
}

async function getcache(e, cache) {
  return cache.match(e.request.url.split("?")[0], { ignoreVary: true })
}

self.addEventListener('activate', function (event) {															// Light us up on completion so that we don't have to do a page reload on install to be active
  if (debug) console.log('[activate] Activating ServiceWorker');
  if (debug) console.log('[activate] Claiming this ServiceWorker!');
  event.waitUntil(self.clients.claim())
});

cacheDebugger = (cache, files, hostURL) => {
  for (let i = 0; i < files.length; i++) {

    let url = ''
    if (files[i].includes('sofvie.com'))
      url = files[i]
    else
      url = hostURL + files[i]

    fetch(url).then(response => response).then((data) => {
      if (data.status != 200)
        console.log(data)
    })

    cache.add(files[i])
  }

  return cache
}
