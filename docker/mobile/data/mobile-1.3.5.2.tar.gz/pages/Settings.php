<?php	
  $strPageTitle = 'Settings';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>
<script type="text/javascript" src="/js/jquery.min.3.6.0.js"></script>
<script type="text/javascript" src="<?php echo _RESOURCEDOMAIN; ?>/js/popper.min.js"></script>

<main class="col containter-fluid mobile-content documents">
  <div class="row">
		<div class="col-12">
			<div class="card mb-4">
				<div class="card-body">
          			<a class="float-right">
            			<i class="fa fa-info-circle text-primary fa-lg trans_tooltip"  data-toggle="tooltip" tag="8669" notes="Here you can change Sofvie to either dark or light mode"></i>
         			</a>
					<h6 class="card-title"><strong><span class='translate' data-i18n="5057" notes="Application Settings"></span></strong></h6>
					<div class="classic-tabs custom-tabs">
						<div class="px-0">
							<div class="tab-pane fade active show" id="applicationSettings" role="tabpanel">
                                <form name="applicationSettingsForm" id="applicationSettingsForm" class="needs-validation" method="POST" action="#" novalidate >
                                    <div class="pt-1 position-relative my-4">
                                        <select name="mobile_theme" id="mobile_theme" class="select-single select-default" required>
                                        </select>
                                        <label for="mobile_theme"><span class='translate' data-i18n="5060" notes="Theme"></span></label>
                                    </div>
                                </form>						
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="card mb-4">
				<div class="card-body">
          			<a class="float-right">
            			<i class="fa fa-info-circle text-primary fa-lg trans_tooltip"  data-toggle="tooltip" tag="8670" notes="Here you can preset responses to auto-fill in all forms"></i>
         			 </a>
					<h6 class="card-title"><strong><span class='translate' data-i18n="5061" notes="User Settings"></span></strong></h6>
					<div class="classic-tabs custom-tabs">
						<div class="px-0">
							<div class="tab-pane fade active show" id="userSettings" role="tabpanel">			
                                <form name="userSettingsForm" id="userSettingsForm" class="needs-validation" method="POST" action="#" novalidate >
                                    <div class="pt-1 position-relative my-4">
                                        <select name="mobile_language" id="mobile_language" class="select-single select-default" required>
                                        </select>
                                        <label for="mobile_language"><span class='translate' data-i18n="5059" notes="Language"></span></label>
                                    </div>

                                    <div class="pt-1 position-relative my-4">
                                        <select name="site_settings" id="site_settings" class="select-single select-default" onChange="formHeader.populateJobSelect(this)" required>
                                        </select>
                                        <label for="site_settings"><span class='translate' data-i18n="828" notes="Site"></span></label>
                                    </div>

                                    <div class="pt-1 position-relative my-4">
                                        <select name="job_number_settings" id="job_number_settings" class="select-single select-default" onChange="formHeader.populateSupervisorSelect(this)" required>
                                        </select>
                                        <label for="job_number_settings"><span class='translate' data-i18n="617" notes="Department/Job"></span></label>
                                    </div>

                                    <div class="pt-1 position-relative my-4">
                                        <select name="level_settings" id="level_settings" class="select-single select-default" required>
                                        </select>
                                        <label for="level_settings"><span class='translate' data-i18n="621" notes="Level"></span></label>
                                    </div>

                                    <div class="pt-1 position-relative my-4">
                                        <select name="supervisor" id="supervisor_settings" class="select-single select-default form-control mobile-supervisor_id-select" required>
                                        </select>
                                        <label for="supervisor_settings"><span class='translate' data-i18n="844" notes="Supervisor"></span></label>
                                    </div>

                                    <div class="pt-1 position-relative my-4">
                                        <select name="Report_Distribution1" id="Report_Distribution1" class="select-multiple select-default mobile-distribution-select" multiple>
                                        </select>
                                        <label for="Report_Distribution1"><span class='translate' data-i18n="166" notes="Distribution"></span></label>
                                    </div>

                                    <input type="hidden" id="myUserID" value="<?php echo $userID ?>" />

                                    <div id='alertDraftLanguageModalComponent'></div>
                                </form>			
							</div>
						</div>
					</div>
				</div>
            </div>
            
            <div class="btn-group d-flex mt-4 mb-2" aria-label="Form Actions">                
                <button type="submit" name="applySettings" id="applySettings" class="btn btn-primary text-nowrap px-1"> <span class='translate' data-i18n="5058" notes="Apply Settings"></span> </button>
            </div>
		</div>
	</div>

</main>

<script type="text/javascript">
    const _USERSETTINGSPROFILE = 32
    $.ajaxSetup({ cache: false })
    let loadedLanguage = ''

    //Dissable apply button if offline
    function getRemoteData(mode = null) {
        return new Promise(resolve => {
            let languageCookie = getCookie("lang")
            let token = JSON.parse(window.localStorage.getItem('token'))
            var urlString = `/ajax/getRemoteData.php?lang=${languageCookie}&auth=${token.access}`
            var urlString_selectLists = `/includes/generateLists.php?lang=${languageCookie}`
            $.get(urlString,(data) => {
            }).done((data)=>{
                $.get(urlString_selectLists,(listdata) => {
                }).done(()=>{
                    getUserSites(data).then((sitedata)=>{
                        getUserJobs(data).then((jobdata)=>{
                            resolve(data)
                        })
                    })
                })
            }).catch((err)=>{
                console.log("Error getting the remote data")
            })
        })
    }

    checkOnline().then((status)=>{
        if(!status){
            document.getElementById('applySettings').disabled = true
        }
    }).catch((err)=>{})

    localStorage.removeItem('userjobstate', false)
    localStorage.removeItem('usersitestate', false)
    localStorage.removeItem('offlinedocstate', false)
    localStorage.removeItem('remotedatastate', false)
    localStorage.removeItem('userlineupState', false)
    localStorage.removeItem('serviceworkerstate', "in progress")

    var formBody = {
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.')
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.')
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.')
		}	
    }    
	
	var formHeader = {
        listsData : '',

        formInitialize: (theForm) => {
            if(sessionStorage.getItem('remoteLoad') === 'True') {
                openCacheData().then(()=>{
                    openSelectCacheData().then(()=>{
                        if(!sessionStorage.getItem('startingcache')){
                            sessionStorage.removeItem('remoteLoad')
                            formHeader.populateThemeSelect(document.getElementById('mobile_theme')) 
                            formHeader.populateLanguageSelect(document.getElementById('mobile_language'))
                            formHeader.populateSiteSelect(document.getElementById('site_settings'))	
                            formHeader.populateSettings()
                        }                            
                    })
                })
            }
            else {
                openCacheData().then(()=>{
                localStorage.setItem('cacheloaded','true')
                    openSelectCacheData().then(()=>{
                        sessionStorage.removeItem('remoteLoad')
                        formHeader.populateThemeSelect(document.getElementById('mobile_theme')) 
                        formHeader.populateLanguageSelect(document.getElementById('mobile_language'))
                        formHeader.populateSiteSelect(document.getElementById('site_settings'))	
                        formHeader.populateSettings()
                    })
                })
            }
        },

        populateThemeSelect : (theSelect) => {
            var opts = [
                {
                    id:'light',
                    name:`${i18next.t(3511)}`
                },
                {
                    id:'dark',
                    name:`${i18next.t(8467)}`
                }
                ,
                {
                    id:'default',
                    name:`${i18next.t(8668)}`
                }
            ]

            $('#mobile_theme').empty()
            $.each(opts, function(id, d){
                            $('#mobile_theme').append(`<option value= "${d.id}" theme="${d.id}">${d.name}</option>`);
                        });
        }, 

        populateLanguageSelect : (theSelect) => {
            var opts = selectListData.languages
            $('#mobile_language').empty()
            $.each(opts, function(id, d){
                            $('#mobile_language').append(`<option value= "${d.lng_name}">${d.lng_description}</option>`);
                        });
        },       

        populateSiteSelect: (theSelect)	=> {
            $('#site_settings').empty().append('<option></option>')
            userSiteData.forEach((d) => {
                $('#site_settings').append(`<option value="${d.rld_id}" site="${d.rld_id}">${d.rld_name}</option>`)
            })
        },

        populateJobSelect: (selectedSite) => {
            if(selectedSite.options[selectedSite.selectedIndex])
                selectSiteHolder = selectedSite.options[selectedSite.selectedIndex].getAttribute('site') 
            $('#job_number_settings').empty().append('<option></option>')
            var opts = userJobData
            $.each(opts, function(i, d) {
                if(d.rld_parent_detail_rld_id === parseInt(selectSiteHolder) && d.rld_is_active == 1){                    
                    $('#job_number_settings').append(`<option value="${d.rld_id}" site="${selectSiteHolder}" >${d.rld_code} - ${d.rld_name}</option>`)
                }
            })

            $('#level_settings').empty().append('<option></option>')
            var opts = selectListData.ref_level;
            $.each(opts, function(i, d) {
                if(d.rld_parent_detail_rld_id == selectSiteHolder) {
                    $('#level_settings').append(`<option value="${d.rld_id}">${d.rld_name}</option>`);
                }
            })

            if(selectSiteHolder === null || selectSiteHolder === undefined){                
                $('#site_settings').val("").parent().find('label').removeClass('filled active')
                $("#job_number_settings").val("").trigger('change').parent().find('label').removeClass('filled active')
                $("#level_settings").val("").trigger('change').parent().find('label').removeClass('filled active')
                $('#supervisor_settings').val("").parent().find('label').removeClass('filled active')
            }
		},

        populateSupervisorSelect: (theSelect) =>  {
            var user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'
            var supervisor_list = userSupervisorSelectData
            var jobIDSelected = document.getElementById('job_number_settings').value	

            if(jobIDSelected === null || jobIDSelected === undefined){                                
                $( "#job_number_settings" ).val("").parent().find('label').removeClass('filled active')                
                $('#supervisor_settings').val("").parent().find('label').removeClass('filled active')
                $('#Report_Distribution1').val("").parent().find('label').removeClass('filled active')			    
            }else{
                formHeader.populateDistributionSelect()
            }
			superSelects = document.getElementsByClassName('mobile-supervisor_id-select')
			for(let a=0; a <superSelects.length; a++) {
				let optionData = `<option></option>`
				if(user_visibility == 'all'){
					supervisor_list.forEach((data)=>{
					optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
					})
					$(superSelects[a]).empty().append(optionData)
				}
				else{
					supervisor_list.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs!== undefined && data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
							}  
						}
					})
					$(superSelects[a]).empty().append(optionData)
				}
			}
		},

        populateDistributionSelect: () =>  {
            let external_group_distribution_list = selectListData.distributionList
			let distribution_list = userDistributionSelectData
			let user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'
			let jobIDSelected = document.getElementById('job_number_settings').value
			distribution_list = distribution_list.concat(external_group_distribution_list)

			distributionGroupList=[]
			distributionSelects = document.getElementsByClassName('mobile-distribution-select')

			if($('#job_number_settings').val() == "") {
				for(let a=0; a <distributionSelects.length; a++) {
					$(distributionSelects[a]).empty()
				}
				return
			}

			let collator = new Intl.Collator('en-ca');

			distribution_list.sort(function (a, b){
				return collator.compare(a.per_full_name, b.per_full_name)
			})
            
            for(let a=0; a <distributionSelects.length; a++) {
                let optionData = ``
                if(user_visibility === "all"){
                    distribution_list.forEach((data)=>{
                        if(data.email.includes(',')){
                            distributionGroupList.push(data)
                        }
                        optionData += `<option value="${data.email}">${data.per_full_name}</option>`
                    })
                    $(distributionSelects[a]).empty().append(optionData)
                }
                else{
                    distribution_list.forEach((data)=>{	
                        if(data.email.includes(',')){
                            distributionGroupList.push(data)
                        }
                        if(data.emp_data_visibility === 'all'){
                            optionData += `<option value="${data.email}">${data.per_full_name}</option>`
                        }
                        else{
                            if(data.employee_jobs!== undefined &&  data.employee_jobs.split(',').includes(jobIDSelected.toString())){
                                optionData += `<option value="${data.email}">${data.per_full_name}</option>`
                            }
                        }
                    })
                    $(distributionSelects[a]).empty().append(optionData)
                }
            }
        },

        populateSettings: () =>  {
            populatePage()
        }
    }


    // setting all values of the form to null or empty before populating the page.
    // Upon applying new settings, refreshing the service worker will trigger the page to reload and populate the page with the new settings.
    // if there is no data it is populating legacy values. 
    // Insetead of else case in populatePage function, setting the values to null or empty and the populating data from remotedata.
    function fill_empty(){
        $('#mobile_theme').val('').trigger('change').parent().find('label').addClass('filled')
        $('#mobile_language').val('').trigger('change').parent().find('label').addClass('filled')
        $('#site_settings').val('').trigger('change').parent().find('label').addClass('filled')
        $('#job_number_settings').val('').trigger('change').parent().find('label').addClass('filled')
        $('#level_settings').val('').trigger('change').parent().find('label').addClass('filled')        
        $('#supervisor_settings').val('').trigger('change').parent().find('label').addClass('filled')
        $('#Report_Distribution1').val('').trigger('change').parent().find('label').addClass('filled')
    }

    function populatePage() {
        let data = ''
        if(remoteData[_USERSETTINGSPROFILE].UserSettingsProfile){
            data = remoteData[_USERSETTINGSPROFILE].UserSettingsProfile[0]
        }        
        fill_empty()
        if(data){
            if(data.upr_theme_mobile){
                $('#mobile_theme').val(data.upr_theme_mobile).trigger('change').parent().find('label').addClass('filled')
            }
            if(data.upr_language){
                $('#mobile_language').val(data.upr_language).trigger('change').parent().find('label').addClass('filled')
                loadedLanguage = data.upr_language
            }
            if(data.upr_site_id){
                $('#site_settings').val(data.upr_site_id).trigger('change').parent().find('label').addClass('filled')
            }
            if(data.upr_job_id){                
                $('#job_number_settings').val(data.upr_job_id).trigger('change').parent().find('label').addClass('filled')
            }
            if(data.upr_level_id){
                $('#level_settings').val(data.upr_level_id).trigger('change').parent().find('label').addClass('filled')
            }
            if(data.supervisor_name){
                $('#supervisor_settings').val(data.supervisor_name).trigger('change').parent().find('label').addClass('filled')
            }
            if(data.email_list){
                let distribution_value = data.email_list.split(',')                      
                $('#Report_Distribution1').val(distribution_value).trigger('change').parent().find('label').addClass('filled')
            }
        }
        $("#footerSpinner").addClass('d-none')
    }

    function set_values(data){        
        if(data.upr_language){
            $('#mobile_language').val(data.upr_language).trigger('change').parent().find('label').addClass('filled')
        }
        if(data.upr_theme_mobile){
            $('#mobile_theme').val(data.upr_theme_mobile).trigger('change').parent().find('label').addClass('filled')
        }
        if(data.upr_site_id){
            $('#site_settings').val(data.upr_site).trigger('change').parent().find('label').addClass('filled')
        }
        if(data.upr_job_id){
            $('#job_number_settings').val(data.upr_job).trigger('change').parent().find('label').addClass('filled')
        }
        if(data.upr_level_id){
            $('#level_settings').val(data.upr_level).trigger('change').parent().find('label').addClass('filled')
        }
        if(data.upr_supervisor_per_id){
            $('#supervisor_settings').val(data.upr_supervisor_per).trigger('change').parent().find('label').addClass('filled')
        }
        let distribution_value = []
        if (data.distribution_list){
            data.distribution_list.forEach((d) => {
                distribution_value.push(d.email)
            })
            if(distribution_value){
                $('#Report_Distribution1').val(distribution_value).trigger('change').parent().find('label').addClass('filled')
            }
        }
        
    }

    function changeTheme(theme) {
        let mobileTheme = theme
        if (mobileTheme === 'light') {
            mobileTheme = 'light-theme'
            document.body.classList.remove('dark-theme')
            document.body.classList.add(mobileTheme)
        }
        else if (mobileTheme === 'dark'){
            mobileTheme = 'dark-theme'
            document.body.classList.remove('light-theme')
            document.body.classList.add(mobileTheme) 
        }
        else {
            mobileTheme = 'light-theme'
            if(window.matchMedia('(prefers-color-scheme: dark)').matches){
            mobileTheme = 'dark-theme'
            }
            document.body.classList.remove('light-theme')
            document.body.classList.remove('dark-theme')
            document.body.classList.add(mobileTheme) 
        }
        window.localStorage.setItem('mobileTheme',mobileTheme)
    }
    
    document.getElementById('applySettings').addEventListener("click", function (e) {
        let dbDraft = new PouchDB('sofvie_drafts', {auto_compaction: true})
        let count = 0
        // Get all matching drafts for this form name
        dbDraft.allDocs({
            include_docs: true,
            attachments: false,
            startkey: '',
            endkey: '\ufff0'
        }).then((result) => {
            // Iterate over the results 
            $.each(result.rows, (i, obj) => {
                if(obj.doc._id.indexOf('_design') == -1) {
                    formID = JSON.parse(obj.doc.formdata).formid
                    if(remoteData[1].forms[formID] && formID !== '131042'  && formID !== '166071' && formID !== '349935' && formID !== '221746' && formID !== '220234' && formID !== '224335')
                        count++
                }
            })

            if(count > 0 && $('#mobile_language').val() != loadedLanguage)
            {
                const theElements = {
                    modalTheme: `modal-warning`,
                    modalAlert: `fa-times-circle`,
                    // Warning
                    modalTitle: i18next.t("2182"),
                    // You have un-submitted form drafts. Changing your language may effect the saved data in these drafts. 
                    // It is recommended that you submit all forms before changing your language. Do you still want to apply settings?
                    modalText: i18next.t("8859"),
                    modalButtons: `<a role="button" id='alertDraftLanguageModalCancel' class="btn btn-outline-warning waves-effect px-1 flex-fill"><span class='translate' data-i18n="1257" note="Cancel"></span></a>
                    <a role="button" id='alertDraftLanguageModalConfirm' class="btn btn-warning waves-effect confirm px-1 flex-fill"><span class='translate' data-i18n="1379" note="Yes"></span></a>`
                }
                showDraftLanguageAlertModal("warning", theElements)
            }
            else {
                applySettings()
            }
        }).catch((err) => {
            console.error(err)
        })
    }, false)

    function applySettings() {
        $.ajaxSetup({ cache: false })
        $("#footerSpinner").removeClass('d-none')
        currentUser = document.getElementById('userSettingsForm').elements['myUserID'].value
        let theme_val = 'light'
        if($('#mobile_theme').val()){
            theme_val = $('#mobile_theme').val()
        }
        let language_val = 'en'
        if($('#mobile_language').val()){
            language_val = $('#mobile_language').val()
        }
        updatePayload = {
            "upr_language": language_val,
            "upr_theme_mobile": theme_val,
            "upr_site_id": $('#site_settings').val() !== '' ? $('#site_settings').val() : null,
            "upr_job_id": $('#job_number_settings').val() !== '' ? $('#job_number_settings').val() : null,
            "upr_supervisor_per_id": $('#supervisor_settings').val() !== '' ? $('#supervisor_settings').val() : null,
            "upr_level_id" : $('#level_settings').val() !== '' ? $('#level_settings').val() : null,
            "distribution_list" : $('#Report_Distribution1').val() !== '' ? $('#Report_Distribution1').val() : null
        }
        offlineUrl = "<?php echo _API_URL ?>" + "/api/settings/update-user-profile/"
        access = JSON.parse(window.localStorage.getItem('token')).access
        $.ajax({
            url: offlineUrl,
            type: 'post',
            dataType: 'json',
            contentType: 'application/json',
            beforeSend: function(request) {
            request.setRequestHeader("Authorization", `Bearer ${access}`)
            },
            data: JSON.stringify(updatePayload),
            success: function (data) {
                set_values(updatePayload)
                let now = new Date()
                now.setFullYear( now.getFullYear() + 2 )
                document.cookie = `lang=${updatePayload.upr_language}; expires= ${now.toUTCString()}; path=/`
                changeTheme(updatePayload.upr_theme_mobile)
                getRemoteData().then(()=>{
                    location.reload()
                })

            },
            error: function (data) {       
            }
        })
    }

</script>

<?php include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
<script src="<?php echo _DOMAIN ?>/modals/draftLanguageAlert.js"></script>