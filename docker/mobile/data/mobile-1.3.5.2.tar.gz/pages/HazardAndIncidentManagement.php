<?php	
  $strPageTitle = 'Hazard and Incident Management';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

  <main class="col containter-fluid mobile-content hazard-incident-management">

  <div class="row">
    <div id="hazard_action" class="col-12 mb-2 align-items-stretch flex-column">
      <div class="col-12 mb-2 d-flex align-items-stretch flex-column">
        <button type="button" onclick="window.location.href = '<?php echo _FORMHAZARDACTION ?>';" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block p-3 d-flex flex-1 z-depth-1-half text-left">
          <i class="fa fa-file-alt fa-2x mr-3 align-self-center"></i>
          <span class="d-inline-block">
            <strong><span class='translate' data-i18n="1695" notes="Submit New Hazard"></span></strong><br>
            <span class='translate' data-i18n="996" notes="Hazard Report"></span>
          </span>
        </button>
      </div>
    </div>
    <div class="col-12 mb-2 align-items-stretch flex-column" id="preliminary_incident">
      <div class="col-12 mb-2 d-flex align-items-stretch flex-column">
        <button type="button"  onclick="window.location.href = '<?php echo _FORMPRELIMINARYINCIDENT ?>';" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block p-3 d-flex flex-1 z-depth-1-half text-left">
          <i class="fa fa-file-alt fa-2x mr-3 align-self-center"></i>
          <span class="d-inline-block">
            <strong><span class='translate' data-i18n="1696" notes="Create New Incident"></span></strong><br>
            <span class='translate' data-i18n="1003" notes="Preliminary Incident"></span>
          </span>
        </button>
      </div>
    </div>
    <div id="preliminary_investigation" class="col-12 mb-2 align-items-stretch flex-column" >
      <div class="col-12 mb-2 d-flex align-items-stretch flex-column">
        <button type="button" onclick="window.location.href = '<?php echo _FORMPRELIMINARYINVESTIGATION ?>';" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block p-3 d-flex flex-1 z-depth-1-half text-left">
          <i class="fa fa-file-alt fa-2x mr-3 align-self-center"></i>
          <span class="d-inline-block">
            <strong><span class='translate' data-i18n="1697" notes="Preliminary Incident"></span></strong><br>
            <span class='translate' data-i18n="1698" notes="Preliminary Incident Investigation"></span>
          </span>
        </button>
      </div>
    </div>
    <div id="incident_statement" class="col-12 mb-2 align-items-stretch flex-column">
      <div class="col-12 mb-2 d-flex align-items-stretch flex-column">
        <button type="button" onclick="window.location.href = '<?php echo _FORMINCIDENTSTATEMENT?>';" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block p-3 d-flex flex-1 z-depth-1-half text-left">
          <i class="fa fa-file-alt fa-2x mr-3 align-self-center"></i>
          <span class="d-inline-block">
            <strong><span class='translate' data-i18n="1699" notes="Collect Statements"></span></strong><br>
            <span class='translate' data-i18n="1004" notes="Incident Statement"></span>
          </span>
        </button>
      </div>
    </div>
    <div class="col-12">
      <div class="card mb-4">
				<div class="card-body">
          <a class="float-right">
            <i class="fa fa-info-circle text-primary fa-lg trans_tooltip" data-toggle="tooltip" tag="1702"></i>
          </a>
          <h6 class="card-title"><strong><span class='translate' data-i18n="1701" notes="Draft forms"></span></strong></h6>
          <table class="table table-sm mt-4" id="draftForms">
            <tbody>
            </tbody>
          </table>
			  </div>
		  </div>
    </div>
	</div>
</main>


<script>
var debug = _DEBUG																																// Set our debug flag
const _FORMS = 1
let config = {// Define some config itmes
  // db name for draft storage
  draftDbName: 'sofvie_drafts',
  // Sync path for draft, false for none
  draftRemoteSync: false,
  // Committed db name
  commitDBName: 'safetodo',
  // Sync path for committed, false for none
  commitRemoteSync: `${_SYNCDOMAIN}:${_SYNCPORT}/${_SYNCCOUCHDB}`
}

// On document loaded
document.addEventListener( "DOMContentLoaded", function() {
  // Create a ref to the local Draft DB
  var dbDraft = new PouchDB(config.draftDbName, {auto_compaction: true})
    openCacheData().then((rdata)=>{
      checkIncidentFormAccess(JSON.parse(JSON.stringify(rdata)))
      populatePage(rdata, dbDraft)

      $("#footerSpinner").addClass('d-none')
    })
}, false);

function checkIncidentFormAccess(remoteDataPage) {
  const formAccessData = remoteDataPage[_FORMACCESS].FormAccess
  let obj = formAccessData.find(o => o.FormID == 224335);
   if(!obj) {
     document.getElementById('preliminary_incident').style.display = "none"
   }
  obj2 = formAccessData.find(o => o.FormID == 220234);
   if(!obj2) {
     document.getElementById('preliminary_investigation').style.display = "none"
   }   
  obj3 = formAccessData.find(o => o.FormID == 221746);
   if(!obj3) {
     document.getElementById('incident_statement').style.display = "none"
   }    
   obj4 = formAccessData.find(o => o.FormID == 248310 || formAccessData.find(o => o.FormID == 131042))
   if(!obj4) {
     document.getElementById('hazard_action').style.display = "none"
   }  
}


function calculateTotals(submissionid, records)	{
	let count = -1;
	for(let rec of records) {
		if(rec.submissionID === submissionid){
			count++;
		}
	}
	return count
}


function calculateDraftTotals(submissionid, dbDraft)	{
	return new Promise(resolve =>{
	   dbDraft.allDocs({																													// Get all matching drafts for this form name 
		   include_docs: true,
		   attachments: false,
		   startkey: '',
		   endkey: '\ufff0'
	   }).then((result) => {	
		   let count= 0 
		   for(row of result.rows){
			   if(row.doc.submissionID == submissionid){
				    count  ++
			   }
		   }
		   resolve(count-1) // always should not include the current form, therefore subtracting one from the count.
	   }).catch((err) => {
		   console.error(err)
	   })		
	})
}

async function iterateRows (data, db) {
		let draftArray = []
  		for (const record of data) {
			if(record.id.indexOf("_design") == -1 ){
				draftArray.push(await getSingleDraftRecord(record, db))
			}
  		}
		return(draftArray)
	}

function getSingleDraftRecord(record, db) {
	return new Promise(function (resolve, reject ) {
		db.get(record.id).then(function (doc) {
			formData = doc.formdata
      if(typeof(doc.formdata) === 'string') {
				formData = JSON.parse(doc.formdata)
			}
			resolve({
				"formName" : formData.formname,
				"formID" :formData.formid,
				"customForm_name":formData.customForm_name,
				"_id" : formData._id ? formData._id :record.id,
				"formLanguage" : formData.formLanguage,
				"submissionID": formData.submissionId,
				"customForm" : formData.customForm,
				"submittedby": formData.submittedby,
				"children" : formData.Children ? formData.Children.length :"",
				"timestamp" : doc.timestamp
			})
		}).catch(function (err) {
			reject(err)
			console.log(err)
		})
	})
}

function populatePage(remoteData, dbDraft)	{
    // Handle Pending Drafts
    strDraftForms = '';
    dbDraft.allDocs({																													// Get all matching drafts for this form name 
      include_docs: false,
      attachments: false,
      startkey: '',
      endkey: '\ufff0'
    }).then(function (result) {																								// If we got results
      iterateRows(result.rows, dbDraft).then((records)=>{
        for(let rec of records) {
          r =  calculateTotals(rec.submissionID, records)
          formID = rec.formID;
            if(formID === '349935') {
              selectedFormUrl = '/forms/formHap.php'
            }
            else {
              selectedFormUrl = remoteData[_FORMS].forms[formID].FormURL
            }
            let displayLabel = rec.formID ? `${rec.formName}${rec._id.substr(6)}` : rec._id
            if((remoteData[_FORMS].forms[formID] || formID === '349935') && (formID === '221746' || formID === '220234' || formID === '224335' || formID === '349935') && parseInt(rec.submittedby) == parseInt(remoteData[2].Employee[0].per_id)){
              strDraftForms = `<tr><td scope="row"><a url="${selectedFormUrl}" class="draftlisting d-block" value="${rec._id}">${displayLabel}</a></td><td class="text-right"><span class="badge badge-primary ml-1">${r}</span></td></tr>`
              $('#draftForms').find('tbody').append( strDraftForms )
              draftEventHandler(rec._id)
            }
        }
      })
    }).catch(function (err) {
      console.error(err);
    });
}

function draftEventHandler(item) {
  document.querySelectorAll('.draftlisting').forEach((data)=>{

    if(data.getAttribute("value") == item){
      data.addEventListener('click',(data)=>{
        sessionStorage.setItem('draftpick', data.target.getAttribute('value'))
        window.open(data.target.getAttribute('url'), "_self");
      })
    }
  })
}

function lookupFormNameByFormId(formId) {
	//console.log("formId", formId)
	if(formId == 350049) // POSITIVE IDENTIFICATION PARENT
		formId = 166071
	if(formId == 131200) // General Report Parent
		formId = 372298
	if(formId == 349935) // Hazard Report Parent
		formId = 131042

  let formName = ""
	try {
		formName = JSON.parse(JSON.stringify(remoteData[_FORMS].forms))[formId].MobileFormName
	}
	catch {
		console.warn("This formId does not exist: ", formId)
	}

	return formName
}

</script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
