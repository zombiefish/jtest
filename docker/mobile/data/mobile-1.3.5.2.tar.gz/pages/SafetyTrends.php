<?php	
  $strPageTitle = 'Safety Trends';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

    <script type="text/javascript" src="<?php echo _RESOURCEDOMAIN; ?>/highcharts/highcharts.js"></script>
    <!-- <script type="text/javascript" src="<?php echo _RESOURCEDOMAIN; ?>/highcharts/modules/exporting.js"></script>
    <script type="text/javascript" src="<?php echo _RESOURCEDOMAIN; ?>/highcharts/modules/export-data.js"></script> -->
    <script type="text/javascript" src="/js/chart.js"></script>
  <main class="col containter-fluid mobile-content">
  <div class="row">
		<div class="col-12">
			<div class="card mb-4">
				<div class="card-body text-center">
          <div id='hazards-chart'  charttype = 'type'></div>
				</div>
			</div>
      <div class="card mb-4">
				<div class="card-body text-center">
          <div id='incidents-chart'  charttype = 'type'></div>
				</div>
			</div>
      <div class="card mb-4">
				<div class="card-body text-center">
          <div id='positive-chart'  charttype = 'type'></div>
				</div>
			</div>
		</div>
	</div>
</main>



<script>
	debug=_DEBUG;
	function drawCharts() {	  
		const _HAZARDTRENDTYPE = 6;
		const _HAZARDTRENDSITE = 14;
		const _INCIDENTTRENDTYPE = 8;
		const _INCIDENTTRENDSITE = 15;
		const _POSITIVERECOGNITIONTRENDTYPE = 16;
		const _POSITIVERECOGNITIONTRENDSITE = 17;
		
		var obj = {
			'chart1' : {
				'type' :	[],
				'site' : []
			},
			'chart2' : {
				'type' :	[],
				'site' : []
			},
			'chart3' : {
				'type' :	[],
				'site' : []
			}
		}
		
	
		openCacheData().then((rdata)=>{
			// Iterate over Hazard Trend types and format for chart.
			for(var record in remoteData[_HAZARDTRENDTYPE].HazardTrendType)	{
				obj.chart1.type.push([remoteData[_HAZARDTRENDTYPE].HazardTrendType[record].FormName, parseFloat(remoteData[_HAZARDTRENDTYPE].HazardTrendType[record].FormsTotal)])   ;
			}

			// Iterate over Hazard Trend sites and format for chart.
			for(var record in remoteData[_HAZARDTRENDSITE].HazardTrendSite)	{
				obj.chart1.site.push([remoteData[_HAZARDTRENDSITE].HazardTrendSite[record].FormName, parseFloat(remoteData[_HAZARDTRENDSITE].HazardTrendSite[record].FormsTotal)])   ;
			}

			// Iterate over Incident Trend types and format for chart.
			for(var record in remoteData[_INCIDENTTRENDTYPE].IncidentTrendType)	{
				obj.chart2.type.push([remoteData[_INCIDENTTRENDTYPE].IncidentTrendType[record].Value, parseFloat(remoteData[_INCIDENTTRENDTYPE].IncidentTrendType[record].SubTotal)])   ;
			}

			// Iterate over Incident Trend sites and format for chart.
			for(var record in remoteData[_INCIDENTTRENDSITE].IncidentTrendSite)	{
				obj.chart2.site.push([remoteData[_INCIDENTTRENDSITE].IncidentTrendSite[record].Site, parseFloat(remoteData[_INCIDENTTRENDSITE].IncidentTrendSite[record].SubTotal)])   ;
			}

			// Iterate over Positive Trend types and format for chart.
			for(var record in remoteData[_POSITIVERECOGNITIONTRENDTYPE].PositiveRecognitionTrendType)	{
				obj.chart3.type.push([remoteData[_POSITIVERECOGNITIONTRENDTYPE].PositiveRecognitionTrendType[record].RecognitionType, parseFloat(remoteData[_POSITIVERECOGNITIONTRENDTYPE].PositiveRecognitionTrendType[record].SubTotal)])   ;
			}

			// Iterate over Positive Trend sites and format for chart.
			for(var record in remoteData[_POSITIVERECOGNITIONTRENDSITE].PositiveRecognitionTrendSite)	{
				obj.chart3.site.push([remoteData[_POSITIVERECOGNITIONTRENDSITE].PositiveRecognitionTrendSite[record].Site, parseFloat(remoteData[_POSITIVERECOGNITIONTRENDSITE].PositiveRecognitionTrendSite[record].SubTotal)])   ;
			}


			// Create the Chart for Hazards
				chart1 = new makeDonut('hazards-chart', obj.chart1.type, i18next.t("978")) // Hazards
				Highcharts.chart('hazards-chart',chart1.getChartData(), (chart) => {chart1.chartMainTitle(chart,i18next.t("978"))}) // Hazards
				chart1.chartToggleButtons(chart1,obj.chart1, i18next.t("978")) //Hazards

			// Create the Chart for Incidents
				chart2 = new makeDonut('incidents-chart', obj.chart2.type, i18next.t("979")) // Incidents
				Highcharts.chart('incidents-chart',chart2.getChartData(), (chart) => {chart2.chartMainTitle(chart, i18next.t("979"))}) // Incidents
				chart2.chartToggleButtons(chart2,obj.chart2, i18next.t("979")) // Incidents

			// Create the Chart for Potentials
				chart3 = new makeDonut('positive-chart', obj.chart3.type, i18next.t("751")) // Positive Recognitions
				Highcharts.chart('positive-chart',chart3.getChartData(), (chart) => {chart3.chartMainTitle(chart, i18next.t("751"))}) // Positive Recognitions
				chart3.chartToggleButtons(chart3,obj.chart3, i18next.t("751")) // Positive Recognitions
           	
			
				 $('.translate').localize()
				 $('.highcharts-title').css({"left": "50%", "transform":"translateX(-50%)"})

			

			$('.highcharts-legend-item').css('display','none')
			$('.highcharts-legend-item').css('text-transform','none')
			$('.highcharts-container').css('height','650px')

			$("#footerSpinner").addClass('d-none')
		})
	}

</script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>