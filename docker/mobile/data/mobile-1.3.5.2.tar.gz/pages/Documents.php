<?php	
  $strPageTitle = 'Documents';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>
<main class="col containter-fluid mobile-content documents">
  <div class="row">
		<div class="col-12">
			<div class="card mb-4">
				<div class="card-body">
          			<a class="float-right">
            			<i class="fa fa-info-circle text-primary fa-lg trans_tooltip" data-toggle="tooltip" tag="3296" notes="Documents you need to review."></i>
         			 </a>
					<h6 class="card-title"><strong><span class='translate' data-i18n="1344" notes="Documents"></span></strong></h6>
					<div class="classic-tabs custom-tabs">
						<div class="tab-content px-0">
							<div class="tab-pane fade active show" id="mainDocuments" role="tabpanel">
								<table class="w-100 data-table doc-data-table widget-table table" id='doc-data-table'>
									<thead><tr><th></th></tr></thead>
										<tbody id="Documents">
										</tbody>
										<tfoot></tfoot>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="card mb-4">
				<div class="card-body">
          			<a class="float-right">
            			<i class="fa fa-info-circle text-primary fa-lg trans_tooltip" data-toggle="tooltip" notes="Useful Links" tag="1773"></i>
         			 </a>
					<h6 class="card-title"><strong><span class='translate' data-i18n="1773" notes="Useful Links"></span></strong></h6>
					<div class="classic-tabs custom-tabs">
						<div class="tab-content px-0">
							<div class="tab-pane fade active show" id="mainDocuments" role="tabpanel">
								<table class="w-100 data-table widget-table table" id='useful-links-data-table'>
									<thead><tr><th></th></tr></thead>
										<tbody id="useful_links">
										</tbody>
										<tfoot></tfoot>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>			
		</div>
	</div>
	<input type="hidden" name="formname" id="formname" tag = "1344" value="Documents"/>
</main>

<?php include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
<script src="<?php echo _DOMAIN ?>/js/i18next.js"></script>
<script>
	const _DOCUMENTS = 27
	const _USEFULLINKS = 30
	const _DOCURLS = 31
	docDb = new PouchDB('offlineDocuments', { auto_compaction: true })
	let dateToday = moment(new Date(), 'YYYY-MM-DD')
	let currentDate = dateToday.format('YYYY-MM-DD')
	localStorage.setItem(`noinitialize`,'true')
	let config = {
		draftDbName: 'sofvie_drafts',
		draftRemoteSync: false,
		commitDBName: _SYNCCOUCHDB,
		commitRemoteSync: `${_SYNCDOMAIN}:${_SYNCPORT}/${_SYNCCOUCHDB}`
	}

	db = new PouchDB(config.commitDBName, { auto_compaction: true })

	document.addEventListener( "DOMContentLoaded", () => {
		// On page load, populate our dynamic data stored in cachestorage
		openCacheData().then((rdata)=>{
			populatePage(remoteData)
			localStorage.removeItem(`noinitialize`)
			initializeDataTables()
			initializeSelect2()
			initializeI18N()
			ackCompleteModal = new SofvieModal()
			checkOnline().then((status)=>{
				if(status){
					$(".documents .downloadlink").removeClass("d-none");
				}
				else {
					$("#footerSpinner").addClass('d-none')
				}
			}).catch((err)=>{})
			$("#footerSpinner").addClass('d-none')
    	})
	}, false)

	function populatePage(remoteData) {
		// Handle Documents	
		let strDoc = ''
		if(remoteData[_DOCUMENTS].DocumentReview)	{	
			let docObj = ''
			remoteData[_DOCUMENTS].DocumentReview.forEach((data, index)=>{
				let reviewDate = data.drm_review_by_date.substring(0,10)
				let docUrl = `${_DOCUMENT_URL}${data.drm_filename}`
				if(data.drm_attachment_type === 'link')
					docUrl = data.drm_url
					if(data.drm_available_offline == 0)
					{
					docObj = `
					<h6><strong>${data.drm_document_type}</strong></h6>
										<div>
					<a href="${data.drr_is_reviewed == 1 ? docUrl:'javascript:;'}" target="_self"  class="${data.drr_is_reviewed == 1 ? '':'idlink'} rounded-circle badge ${data.drr_is_reviewed == 1? 'green darken-2':'bg-secondary'} ml-3 downloadlink d-none">
								<i 
								        mode="online"
										modalSubmissionID="${data.drr_id}" 
										modalSubmissionIndex="${index}"
										class="fa ${data.drr_is_reviewed == 1 ? 'fa-download':'fa-file-alt'} fa-fw py-1"></i>
								</a></div>`

					} else {
						docObj = `
						<h6><strong>${data.drm_document_type}</strong></h6>
						<div>
						<div class='btn btn-primary btn-rounded btn-sm'><span class='translate' data-i18n="3473" notes="Available Offline"></span></div>
						<a class="${data.drr_is_reviewed == 1 ? 'offline':'idlink'} rounded-circle badge ${data.drr_is_reviewed == 1? 'green darken-2':'bg-secondary'} ml-3">
								<i 
										mode="offline"
										modalSubmissionID="${data.drr_id}" 
										drm_id = "${data.drm_id}"
										modalSubmissionIndex="${index}"
										class="fa ${data.drr_is_reviewed == 1? 'fa-download':'fa-file-alt'} fa-fw py-1"></i>
								</a></div>`

					}
				strDoc += `	<tr>
								<td class="action-wrapper ${reviewDate < currentDate && data.drr_is_reviewed != 1 ? 'overdue':''} my-3">
									<span id="doc${index}">
										<div class="d-flex justify-content-between">
											${docObj}	
										</div>
										<p class="description">${data.drm_description}</p>
										<span class="d-flex justify-content-between" ><small><span class='translate' data-i18n="1298" notes="Created By"></span>: ${data.drm_created_name}</small><small class="flex-shrink-0 pl-2"><span class='translate' data-i18n="1047" notes="Due"></span>: ${data.drm_review_by_date.substring(0,10)}</small></span>
									</span>
								</td>
							</tr>`
			})
		}

		// Refresh offline check when table page changes
		$('#doc-data-table').on('draw.dt', () => {
			checkOnline().then((status)=>{
				if(status)
				{
					$(".documents .downloadlink").removeClass("d-none");
				}
			}).catch((err)=>{})
		})

		$('#Documents').html( strDoc )
        let allLinks = ''
		if(remoteData[_USEFULLINKS].UsefulLinks) {
			remoteData[_USEFULLINKS].UsefulLinks.forEach((link)=>{
				allLinks += `<tr>
								<td class="action-wrapper my-3">
								<span>
									<div class="d-flex justify-content-between">
										<h6><strong>${link.ulm_description}</strong></h6>
										<div>
											<a href="${link.ulm_link}"  target="_self" class="downloadlink d-none rounded-circle badge bg-secondary">
												<i class="fas fa-download fa-link py-1"></i>
											</a>			
										</div>
									</div>
								</span>
								</td>
							</tr>`
			})				
			$('#useful_links').html(allLinks)
		}

		// Refresh link offline check when table page changes
		$('#useful-links-data-table').on('draw.dt', () => {
			checkOnline().then((status)=>{
				if(status){
					$(".documents .downloadlink").removeClass("d-none");
				}
			}).catch((err)=>{})
		})

		// Events for Hamburgers
		Array.from(document.getElementsByClassName('idlink')).forEach((data) => {
			data.addEventListener('click',(event) => {	
				acknowledgeDocument(event.target.getAttribute('modalsubmissionid'),event.target.getAttribute('modalsubmissionIndex'),event.target.getAttribute('mode'),event.target.getAttribute('drm_id'), event)
			}, false)
		})

		// Event for Offline document
		Array.from(document.getElementsByClassName('offline')).forEach((data) => {
			data.addEventListener('click',(event) => {	
				getOfflineDocument(event.target.getAttribute('drm_id'))
			}, false)
		})		
	}

	function getOfflineDocument(id) {
		docDb.get(id).then(function (doc) {
			ranaBlob(doc.blob)
        }).catch(function (err) {
             console.log("Problem Getting Doc",err)
        })
	}

	function ranaBlob(my_string) {
		// spliting the extension
		let split_data_and_ext = my_string.split(',')
		let type = split_data_and_ext[0].split(";")[0].split(":")[1]
		if(type === "application/jpg" ||type === "application/png" ) {
			var d = window.open().document
             d.write(''); d.close()
              d.body.appendChild(document.createElement('img')).src = my_string

			ackCompleteModal.hideModal() 
			$('.modal-backdrop').first().remove()
		} else {
			let byteString = atob(split_data_and_ext[1])
			// create file from the bytes object
			let ab = new ArrayBuffer(byteString.length)
			let ia = new Uint8Array(ab)
			// loop through the array and insert into the i variable
			for (let i = 0; i < byteString.length; i++) {
				ia[i] = byteString.charCodeAt(i)
			}
			let b = new Blob([ab], {"type": type})
			let myURL =  window.URL.createObjectURL(b)
			window.open(myURL,  '_blank')
			ackCompleteModal.hideModal() 
			$('.modal-backdrop').first().remove()
		}
	}

	function clearModal() {
		window.open(`${window.location.origin}${window.location.pathname}`, "_self")
	}	

	function acknowledgeDocument(doc, index, mode, drm_id, obj) {
		let mystamp = new Date
		let dateString = new Date(mystamp.getTime() - (mystamp.getTimezoneOffset() * 60000 )).toISOString().split("T")
		
		ackCompleteModal.setModalElements('warning', `modalButtons`, `<a role="button" class="btn btn-outline-warning waves-effect cancel px-1 flex-fill" note="Cancel">${i18next.t(1257)}</a>
			<a role="button" class="btn btn-warning waves-effect confirm  px-1 flex-fill" note="MARK AS REVIEWED">${i18next.t(1188)}</a>`)
			ackCompleteModal.setModalElements('warning', `modalTitle`, i18next.t("2095")) // Document Review
			ackCompleteModal.setModalElements('warning', `modalText`, i18next.t("8672"))	//By performing this action, you are digitally signing and acknowledging you have received the document. You are taking full responsibility of reviewing the document in a timely manner.
			ackCompleteModal.handleModal('warning')

		$(`.modal-footer .cancel`).click(() => {  
			ackCompleteModal.hideModal() 
			$('.modal-backdrop').first().remove()
		})

		$(`.modal-footer .confirm`).click(() => {  
			db.put({
			_id: `DMM:${doc}:${mystamp}`
			,type: 'DMMACK'
			,formdata: {
				formname: 'DRMACK'
			}
			,ack_timestamp: `${dateString[0]} ${dateString[1].slice(0,-1)}`
			,ack_id: doc
		}).then(function (response) {
            sync(db, config.commitRemoteSync)
			}).then(()=>{
				remoteData[_DOCUMENTS].DocumentReview[index].drr_is_reviewed = "1"
				storeDocumentCacheData().then(()=>{
					$('#doc-data-table').dataTable().fnClearTable();
					$('#doc-data-table').dataTable().fnDestroy();
					populatePage(remoteData)
					initializeDataTables('doc-data-table')
					$('.translate').localize()
					if(mode === 'online'){
						docUrl = `${_DOCUMENT_URL}${remoteData[_DOCUMENTS].DocumentReview[index].drm_filename}`
						if(remoteData[_DOCUMENTS].DocumentReview[index].drm_attachment_type === 'link')
							docUrl = remoteData[_DOCUMENTS].DocumentReview[index].drm_url

						window.open( `${docUrl}`,'_blank')
						ackCompleteModal.hideModal() 
						$('.modal-backdrop').first().remove()
					}
					else {
						getOfflineDocument(drm_id)
					}

					checkOnline().then((status)=>{
						if(status) {
							$(".documents .downloadlink").removeClass("d-none")
						}
					}).catch((err)=>{})
				})
			}).catch(function (err) {
					console.log('AddForm: Error Acknowledging Data: ' + err)
			})
		})
	}

	function sync(db, syncTo) {
		checkOnline().then((status)=>{
			if (syncTo && status) {
				let opts = { live: true, retry: true }
				db.replicate.to(syncTo, opts)
					.then(function (response) {
					}).catch(function (err) {
						console.error('Error replicating to : ' + syncTo + ' : ' + err)
					})
			} 
			else {
				if (debug) console.log('Nothing to sync to')
			}
		}).catch((err)=>{
			console.warn('Browser offline, not replicating')
		})
	}

	function documentCachePromise() {
		return new Promise((resolve) => {
			caches.open('SofvieCache').then((res)=>{
				var init = { "status" : 200 , "statusText" : "SuperSmashingGreat!" };
				var myResponse = new Response(JSON.stringify(remoteData));
				res.put('<?php echo _DOMAIN ?>/ajax/getRemoteData.php', myResponse).then(()=>{
					resolve(true)
				})
			})
		})
	}

	async function storeDocumentCacheData() {
		await documentCachePromise()
	}

</script>