<?php	
  $strPageTitle = 'Toolbox';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content toolbox">
<!-- field to identify this page for the translation function do not remove -->
  <input type = "hidden" id="toolboxpage"/>

	<div class="row" id="toolbox_content">			
			<div class="col-12">
				<div class="card mb-4">
					<div class="card-body">
			<a class="float-right">
				<i class="fa fa-info-circle text-primary fa-lg trans_tooltip" data-toggle="tooltip" tag="1364" notes="List of forms that you have not met your target for, at the current point in time. The yellow badge shows the number of forms that need to be submitted to meet the target."></i>
			</a>
			<h6 class="card-title"><strong><span class='translate' data-i18n="1363" notes="Outstanding forms with targets"></span></strong></h6>
			<table class="table table-sm mt-4" id="OutstandingTargets">
				<tbody>
				</tbody>
			</table>
					</div>
				</div>
			<div class="card mb-4">
					<div class="card-body">
			<a class="float-right">
				<i class="fa fa-info-circle text-primary fa-lg trans_tooltip" data-toggle="tooltip" tag="1368" notes="Forms you have started working on and saved as drafts or have already submitted."></i>
			</a>
			<h6 class="card-title"><strong><span class='translate' data-i18n="1365" notes="Form Activity"></span></strong></h6>

						<div class="classic-tabs custom-tabs">
							<ul class="nav nav-justified grey lighten-4" role="tablist">
								<li class="nav-item">
									<a class="nav-link  waves-effect active show" data-toggle="tab" href="#form-drafts" role="tab"><span class='translate' data-i18n="1366" notes="Drafts"></span></a>
								</li>
								<li class="nav-item">
									<a class="nav-link waves-effect" data-toggle="tab" href="#forms-submitted" role="tab"><span class='translate' data-i18n="1367" notes="Submitted"></span><span id="submitted-badge" class="badge badge-danger mx-2"></span></a>
								</li>
							</ul>
							<div class="tab-content pt-4">
								<div class="tab-pane fade active show" id="form-drafts" role="tabpanel">
									<table class="table table-sm widget-table" id="draftForms">
										<tbody>
										</tbody>
									</table>
								</div>
								<div class="tab-pane fade" id="forms-submitted" role="tabpanel">
									<table class="table table-sm data-table-submitted widget-table">
										<thead><tr><th></th></tr></thead>
										<tbody id="submittedForms">
										</tbody>
										<tfoot></tfoot>
									</table>
								</div>
							</div>
						</div>

					</div>
				</div>
				<div class="card mb-4">
					<div class="card-body">
						<a class="float-right">
							<i class="fa fa-info-circle text-primary fa-lg trans_tooltip" data-toggle="tooltip" tag="1374" notes="List of all forms available to you, grouped in categories."></i>
						</a>
						<h6 class="card-title"><strong><span class='translate' data-i18n="1373" notes="All Forms"></span></strong></h6>
						<div class="md-form">
							<input type="text" id="myInput" class="form-control md-textarea" onkeyup="searchFunction()" style="width: 100%;">
							<label  for="myInput" style="width: 100%;"><span class="translate" data-i18n="1136" notes="Search"></span></label>
						</div>
						<div class="accordion md-accordion" id="formList" role="tablist"></div>
					</div>
				</div>
			</div>
	</div>

	<div id='alertReSubmitComponent'></div>
</main>
<script>localStorage.setItem(`noinitialize`,'true')</script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>

<script type="text/javascript">

const _TARGETS = 0
const _TARGETSCOMPLETED = 20
const _FORMS = 1
const _CUSTOMFORMS = 36
let finalFormData = []

let finaltargets = {}	// Set our debug flag
let config = {		// Define some config itmes
	draftDbName: 'sofvie_drafts', 	// db name for draft storage
	draftRemoteSync: false,		// Sync path for draft, false for none
	commitDBName: _SYNCCOUCHDB, 	// Committed db name
	commitRemoteSync: `${_SYNCDOMAIN}:${_SYNCPORT}/${_SYNCCOUCHDB}`// Sync path for committed, false for none

}

let DBconfigLoto = {
		DbName: 'sofvieLoto',
		RemoteSync: false,
		commitDBName: _SYNCCOUCHDB,
		commitRemoteSync:  _SYNCDOMAIN + ':' + _SYNCPORT + '/' + _SYNCCOUCHDB
	}

let dbDraft = new PouchDB(config.draftDbName, {auto_compaction: true})
let dbSofvieForm = new PouchDB(DBconfigLoto.DbName, {auto_compaction: true})
let formData = []


function loadToolboxPage() {
	const db = new PouchDB(config.commitDBName, { auto_compaction: true })
	let selectedLanguage = 'en'
	let langCookie = getCookie("lang")
	selectedLanguage = langCookie ? langCookie : selectedLanguage	
	// Start i18Next for Translations
	openCacheData().then((rdata)=>{
		localStorage.removeItem(`noinitialize`)
		formData = JSON.parse(JSON.stringify(rdata[_FORMACCESS].FormAccess))
		finalFormData = specialFormPermission(formData)
		finalFormData=finalFormData.sort((a,b) => a.category > b.category ? 1 : b.category>a.category ? -1 : 0)  //Sort by Category
		populatePage(rdata, dbDraft, db)
		initializeI18N()
		$("#footerSpinner").addClass('d-none')
	})
}

function calculateTotals(submissionid, records)	{
	let count = -1;
	for(let rec of records) {
		if(rec.submissionID === submissionid){
			count++;
		}
	}
	return count
}

async function iterateRows (data, db) {
	let draftArray = []
	let rec = null
	for (const record of data) {
		if(record.id.indexOf("_design") == -1 ){
			rec = await getSingleDraftRecord(record, db)
			if(rec){
				draftArray.push(rec)
			}
		}
	}
	return(draftArray)
}

function getSingleDraftRecord(record, db) {
	return new Promise(function (resolve, reject ) {
		db.get(record.id).then(function (doc) {
			formData = doc.formdata
			if(typeof(doc.formdata) === 'string') {
				formData = JSON.parse(doc.formdata)
			}
			resolve({
				"formName" : formData.formname,
				"formID" :formData.formid,
				"customForm_name":formData.customForm_name,
				"_id" : formData._id ? formData._id :record.id,
				"formLanguage" : formData.formLanguage,
				"submissionID": formData.submissionId,
				"customForm" : formData.customForm,
				"submittedby": formData.submittedby,
				"children" : formData.Children ? formData.Children.length :"",
				"timestamp" : doc.timestamp
			})
		}).catch((err) => {
			resolve(false)
		})
	}).catch((err)=>{
		console.log(err)
	})
}

function populatePage(remoteData, dbDraft, db) {
    // Handle Targets
    let target = ''
    let objNotifications = null
    objNotifications = JSON.parse(localStorage.getItem('Notifications'))
    let myTargets = targetSummary(remoteData)
    showPendingTargets(db, myTargets)
    // Handle Pending Drafts
    strDraftForms = ''
	// Get all matching drafts for this form name 
    dbDraft.allDocs({
        include_docs: false,
        attachments: false,
        startkey: '',
        endkey: '\ufff0'
    }).then((result) => {
		// Iterate over the results 
		iterateRows(result.rows, dbDraft).then((records)=>{
			for (let draft of records) {
				let displayLabel = ""
				r = calculateTotals(draft.submissionID, records)
				if(r==0) r=''
				// Custom Form
				if(draft.formID == 777777){
					displayLabel = draft.formID ? `${draft.customForm_name}${draft._id.substr(6)}` : draft._id
				} 
				else {
					displayLabel = draft.formID ? `${lookupFormNameByFormId(draft.formID)}${draft._id.substr(6)}` : draft._id
				}
																				//hap              //pid              //hazard parent        //incident statement     //Preliminary Investigation //Preliminary Incident
				if (remoteData[_FORMS].forms[draft.formID] && draft.formID !== '131042' && draft.formID !== '166071' && draft.formID !== '349935' && draft.formID !== '221746' && draft.formID !== '220234' && draft.formID !== '224335' && draft.submittedby == parseInt(remoteData[2].Employee[0].per_id)) {
					if(draft.formID == 777777) { // Custom Form
						strDraftForms = `<tr><td scope="row"><a url="${remoteData[_FORMS].forms[draft.formID].FormURL}" class="draftlisting d-block" customFormID="${draft.customForm}" key="${draft._id}">${displayLabel}</a></td><td class="text-right"><span class="badge badge-primary ml-1">${r}</span></td></tr>`
					}
					else{
						if(draft.formLanguage != selectedLanguage){
							strDraftForms = `<tr><td scope="row"><a url="" lang=${draft.formLanguage} class="difflang draftlisting d-block" key="${draft._id}">${displayLabel}</a></td><td class="text-right"><span class="badge badge-primary ml-1">${r}</span></td></tr>`
						}
						else{
							strDraftForms = `<tr><td scope="row"><a url="${remoteData[_FORMS].forms[draft.formID].FormURL}" class="draftlisting d-block" key="${draft._id}">${displayLabel}</a></td><td class="text-right"><span class="badge badge-primary ml-1">${r}</span></td></tr>`
						}
					}
					
						$('#draftForms').find('tbody').append(strDraftForms)
						draftEventHandler(draft._id, draft.formID)
					}
					if (draft.formID === '350049' && draft.submittedby == parseInt(remoteData[2].Employee[0].per_id)) {
						strDraftForms = `<tr><td scope="row"><a url="/forms/formPositiveAction.php" class="draftlisting d-block" key="${draft._id}">${displayLabel}</a></td><td class="text-right"><span class="badge badge-primary ml-1">${r}</span></td></tr>`
						$('#draftForms').find('tbody').append(strDraftForms)
						draftEventHandler(draft._id, draft.formID)
					}
			}
		})

    }).catch((err) => {
        console.error(err)
    })

	function draftEventHandler(item, formID) {
			document.querySelectorAll('.draftlisting').forEach((data)=>{
			if(data.getAttribute("key") == item){
				data.addEventListener('click',(data)=>{
					sessionStorage.setItem('draftpick', data.target.getAttribute('key'))
					
					if(formID == 777777) // Custom Form
						window.localStorage.setItem('customForm', data.target.getAttribute('customFormID'))
					
					window.open(data.target.getAttribute('url'), "_self");
				})
			}
		})
	}

    // Display accessible forms by Category
    var accessibleForms = ''
    var categoryForm = null
    const categoryFormName = 0
    const categoryFormURL = 1
    const categoryFormID = 2
    const categoryFormCategory = 3
    var strAccessibleForm = ''
    let finaltargets = []
  
	//Group by Category
	let groupBy = (xs, key) => {
		return xs.reduce(function(rv, x) {
			(rv[x[key]] = rv[x[key]] || []).push(x) 
			return rv 
		}, {}) 
	};

    finalFormDataByCategories = groupBy( finalFormData, 'category' );

	//Sort Mobile form name by language setting in each Category group
	newSort=[]
	for ( let key in finalFormDataByCategories ){
		formDataByCategories=finalFormDataByCategories[key].sort( (a, b) => a.MobileFormName.toString().localeCompare(b.MobileFormName.toString(), selectedLanguage, {ignorePunctuation: true}));
		for(let i in formDataByCategories){
			newSort.push(formDataByCategories[i])
		}		
	}
	//replace original FormData by new sort method
	finalFormData=newSort
	for (let record in finalFormData) {
        if (categoryForm !== finalFormData[record]['category']) {
            if (categoryForm !== null) {
                strAccessibleForm += '</tbody> \
										</table> \
										</div> \
										</div> \
										</div> '

            }
            //Reset for category
            categoryForm = finalFormData[record]['category'];
            // Output the new header

            strAccessibleForm += '<div class="card"> \
              <div class="card-header px-1 py-2" role="tab"> \
                <a cat-id="' + finalFormData[record]['MobileFormCategoryIdentifier'] + '" class="collapsed" data-toggle="collapse" data-parent="#formList" href="#form-' + finalFormData[record]['FormID'] + '"> \
                  <h5 class="mb-0 font-weight-bold" id="formCategory">' + categoryForm + '<i class="fas fa-angle-down rotate-icon"></i></h5> \
                </a> \
              </div> \
	                        \
		          <div id="form-' + finalFormData[record]['FormID'] + '" class="collapse" role="tabpanel" data-parent="#formList"> \
                <div class="card-body px-1 py-0"> \
                  <table class="table table-sm" id="menuTarget"> \
                    <tbody> \
										';

        }
        if (finalFormData[record]['FormID'] !== '777777') {
            strAccessibleForm += `<tr>	\
				<td>`
				if(finalFormData[record]['type'] === 'custom-category' || finalFormData[record]['type'] === 'custom-form-pre-defined-category' ){
					strAccessibleForm += `<a item-id="${finalFormData[record]['MobileFormIdentifier']}" class="categoryLink d-block" chkId="${finalFormData[record]['FormID']}">${finalFormData[record]['MobileFormName']}</a>`
				}
				else{
					strAccessibleForm += `<a item-id="${finalFormData[record]['MobileFormIdentifier']}" href="${finalFormData[record]['FormUrl']}" class="d-block"> ${finalFormData[record]['MobileFormName']} </a>`
				}
				strAccessibleForm += `</td>	\
				</tr>`;
        }
    }

    strAccessibleForm += '</tbody> \
                  </table> \
                </div> \
              </div> \
            </div>';

    document.getElementById('formList').innerHTML += strAccessibleForm;
    getSubmissionData(db)
	
	allowedForms = remoteData[9]['FormAccess']

	let allChecks = document.getElementsByClassName('categoryLink')
    for(let customForm in allChecks) {
		try {
			allChecks[customForm].addEventListener('click',(e)=>{
				window.localStorage.setItem('customForm',e.target.attributes.chkId.value)
				window.location.href = `/forms/formCustomForm.php`
			})
		}
		catch (err){
		}
	}	
}

function customFormMenu() {
    // deal with the customForm categories
	let customFormToolboxMenu = ""
	let customForm_list =  []
	let customFormCategories = remoteData[35].FormBuilderCategories
	let customForms = remoteData[36].CustomForms
	customFormToolboxMenu += `
		<div class="accordion md-accordion" id="MainMenu">
			<div class="list-group panel">`
	customFormCategories.forEach((cat)=>{
		// Get list of customForms in the Category
		customForm_list =  []
		customForms.forEach((list)=>{
			if(cat.fbc_id === list.fob_fbc_id) {
			customForm_list.push(list)
			}
			customForm_list=customForm_list.sort( (a, b) => a.fob_name.toString().localeCompare(b.fob_name.toString(), selectedLanguage, {ignorePunctuation: true}))
		})
        if(customForm_list.length > 0){
			customFormToolboxMenu += `<a href="#cat${cat.fbc_id}" class="p-2 border-bottom text-default" data-toggle="collapse" data-parent="#MainMenu">${cat.fbc_name}</a>
					<div class="collapse" id="cat${cat.fbc_id}">`
			customForm_list.forEach((chk)=>{
				customFormToolboxMenu +=`<a class="categoryLink p-2 pl-4 border-bottom d-block" chkId="${chk.fob_id}">${chk.fob_name}</a>`
			})
			customFormToolboxMenu += `</div>`
		}
	})
	customFormToolboxMenu += `</div>`
    let allChecks = document.getElementsByClassName('categoryLink')
    for(let customForm in allChecks) {
		try {
			allChecks[customForm].addEventListener('click',(e)=>{
				window.localStorage.setItem('customForm',e.target.attributes.chkId.value)
				window.location.href = `/forms/formCustomForm.php`
			})
		}
		catch (err){
		}
	}
}

// Function to Convert Uppercase Forms to Titlecase
function titleCase(item) {
	let finalData = ''
	switch(item) {
		case 'SAFETY-JHS BOARD AUDIT': finalData = 'Safety-JHS Board Audit'
			break
		case 'VFL AUDIT': finalData = 'VFL Audit'
			break	
		case 'PPE AUDIT': finalData = 'PPE Audit'
			break	
		case 'HOT/COLD EVALUATION': finalData = 'Hot/Cold Evaluation'
			break	
		case 'Vale N.A.P.G. FLHA': finalData = 'Vale N.A.P.G. FLHA'
			break		
		case 'A&M SHIFT REPORT': finalData = 'A&M Shift Report'
			break	
		case 'IT': finalData = 'IT'
			break						
		default:				
			let data = item.toLowerCase().split(' ')
			data.forEach((rec)=>{
				finalData += `${rec.substring(0, 1).toUpperCase()}${rec.substring(1)} `
			})
			break
	}
	if(selectedLanguage!="en"){
			finalData=item.toLowerCase().charAt(0).toUpperCase() + item.toLowerCase().slice(1)
	}
	return finalData
}

function targetSummary(remoteData) {
	let myTargets = []
	if (remoteData[_TARGETS].targets){
		let targetData = remoteData[_TARGETS].targets.forEach((data)=>{
		freq =  getTargetFrequency(data.FrequencyID)
		let form_access = true
		if(remoteData[_FORMS].forms) {
			if(data.FDFormID !== '350049' && data.FDFormID !== '349935' && data.FDFormID !== '131200'){
				totalTargetCounts = data.Target
				let formName = ''
				let formURL = ''
				let formID = null
				let formType = ''
				let form_access = false
				if(data.FDFormID !== null && data.sta_fob_id === null){
					formName = remoteData[_FORMS].forms[data.FDFormID].MobileFormName
					formURL = remoteData[_FORMS].forms[data.FDFormID].FormURL
					formID = data.FDFormID
					formType = "Predefined"
					form_access = true
				}
				else if (data.FDFormID === null && data.sta_fob_id !== null){
					formID = data.sta_fob_id
					formURL = remoteData[_FORMS].forms[777777].FormURL
					formType = "Custom"
					remoteData[_CUSTOMFORMS].CustomForms.forEach(custom_form => {
						if(custom_form.fob_id === data.sta_fob_id){
							formName = custom_form.fob_name
							form_access = true
						}
					});
				}
				if(form_access == true){
					myTargets.push({
						form: formName,
						formID : formID,
						formURL: formURL,
						allTargets: totalTargetCounts,
						basicTarget: parseInt(data.Target),
						monthlyTargets : totalTargetCounts,
						frequency: freq,
						formType: formType,
					})
				}
			}
		}
	})
	}


 return(myTargets)
}

function getTargetFrequency(target) {
	switch(target) {
		  case '1': return 'Daily'
		  case '7': return '111'
		  case '30': return '222'
		  case '90': return '555'
		  case '182': return '444'
		  case '365': return '333'
        default: return 'Daily'
	}
}

function showPendingTargets(db,targets) {
	
	// Handle Pending Submissions
	finaltargets = JSON.parse(JSON.stringify(targets))
	let outstanding_targets = completedTargets(finaltargets)
	outstanding_targets = completedOfflineTargets(outstanding_targets)
	for(var record in outstanding_targets)	{
		outstanding_targets[record].form = titleCase(outstanding_targets[record].form)
		 // Create a structure of Targets to store target submissions.
		 // If a entry already exists for this formid, use it, otherwise, set to 0
         // Remove calculation and display of 'completed', implemented decrement of 'owing' targets in formHandler.js
         //	completed = (objNotifications[remoteData[_TARGETS].targets[record].FDFormID]) ? objNotifications[remoteData[_TARGETS].targets[record].FDFormID] : 0;
		if(outstanding_targets[record].allTargets > 0) {
			target = `<tr><th scope="row"><a url="${outstanding_targets[record].formURL}" form_id="${outstanding_targets[record].formID}" form_type="${outstanding_targets[record].formType}" class="targetLink d-block">${outstanding_targets[record].form}</a></th><td class="text-right"><span class="badge badge-pill bg-secondary">${outstanding_targets[record].allTargets}</span></td></tr>`
			$('#OutstandingTargets').find('tbody').append(target);
		}
	}

	let allTargetLinks = document.getElementsByClassName('targetLink')
    for(let target in allTargetLinks) {
		try {
			allTargetLinks[target].addEventListener('click',(e)=>{
				let form_type = e.target.attributes.form_type.value
				if(form_type == "Custom"){
					window.localStorage.setItem('customForm',e.target.attributes.form_id.value)
				}				
				window.location.href = e.target.attributes.url.value
			})
		}
		catch (err){
		}
	}
}

function updateTargets(targets, pendingForm) {
	temp = JSON.parse(JSON.stringify(targets))
     for (let record in temp) {
          if(temp[record].form === pendingForm) {
			  if(temp[record].allTargets > 0) {
				temp[record].allTargets--
			  }
		  }
	 }
     return temp
}

function targetFormsArray(targets) {
	targetArray = []
	targets.forEach((data) => {
		targetArray.push(data.form)
	})
 	return targetArray
}

function getCompletedTargets(data, todo_targets) {
	for(let record in data) {		
		for(targ in finaltargets) {
			if(finaltargets[targ].formID ===  data[record].form_id && finaltargets[targ].formType === data[record].form_type){
				finaltargets[targ].allTargets = data[record].todo
				todo_targets.push(finaltargets[targ])					
			}
		}
	}
	return todo_targets
}

function completedTargets(finaltargets) {
	// formURL, formID, formType, form, allTargets
	let todo_targets = []

	//  Do the Monthly Targets
	let monthly = remoteData[_TARGETSCOMPLETED].EmployeeTargetCounts['30'];
	todo_targets = getCompletedTargets(monthly, todo_targets)

	//  Do the Annual Targets
	let annual = remoteData[_TARGETSCOMPLETED].EmployeeTargetCounts['365'];
	todo_targets = getCompletedTargets(annual, todo_targets)

	//  Do the Quarterly Targets
	let quarterly = remoteData[_TARGETSCOMPLETED].EmployeeTargetCounts['90'];
	todo_targets = getCompletedTargets(quarterly, todo_targets)

	//  Do the Bi-Annual Targets
	let biannually = remoteData[_TARGETSCOMPLETED].EmployeeTargetCounts['182'];
	todo_targets = getCompletedTargets(biannually, todo_targets)

    
	return todo_targets
}

function completedOfflineTargets(outstanding_targets) {
	if(localStorage.getItem('submittedForms')){
		let offForms = JSON.parse(localStorage.getItem('submittedForms'))
		outstanding_targets.forEach((rec)=>{
			for(off in offForms)	{
				if(rec.formID === offForms[off].formid) {
					rec.allTargets = rec.allTargets - offForms[off].count
					rec.allTargets = rec.allTargets > 0 ? rec.allTargets : 0
				}
			}
	    })
	}
    return outstanding_targets
}

// This portion will take care of special form permission.  Ie remove forms from the toolbox page or eneable and disable button etc.
function specialFormPermission(formData) {	
	let arr = []
	if(formData) {
		let preTask_preOp_row = $('#toolbox_content')		
		let pretask = false
		let preop = false
		formData.forEach((fdata)=>{
			fID = parseInt(fdata.FormID)
			switch(fID) {
				case 236193:  // Pre-Task
					let pre_task_url = '<?php echo _FORMSAFETYCARDAUDIT ?>'					
					preTaskButton = ` <div id='pre_task' class="mb-2 d-flex align-items-stretch flex-column">
											<button id="pretaskButton" type="button" onclick="window.location.href = '${pre_task_url}'" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block py-3 px-1 flex-1 z-depth-1-half">
        										<strong><span class="translate" data-i18n="994" notes="Pre-Task"></span></strong>
      										</button>
										</div>`					
					
					preTask_preOp_row.prepend(preTaskButton)
					pretask = true
				break
				case 372278: // Pre-Op
					let pre_op_url = '<?php echo _FORMPREOPAUDIT ?>'
					preOpButton = `<div id='pre_op' class="mb-2 d-flex align-items-stretch flex-column">
										<button id="preopButton" type="button" onclick="window.location.href = '${pre_op_url}'" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block py-3 px-1 flex-1 z-depth-1-half">
											<strong><span class="translate" data-i18n="1362" notes="Pre-op Check"></span></strong>
										</button>
									</div>`								
					preTask_preOp_row.prepend(preOpButton)
					preop = true
				break
				case 131042: break                                                           // remove HAP
				case 221746: break                                                           // remove Incident Statement
				case 224335: break                                                           // remove prelimitary incident
				case 220234: break                                                           // remove preliminary Investigation
				case 349935: break                                                           // remove HAP
				default: arr.push(fdata)                                                     // push valid forms to new array
			}
		})

		if (pretask && preop) {
			$('#pre_task').addClass('col-6')
			$('#pre_op').addClass('col-6')			
		}
		else if (pretask) {
			$('#pre_task').addClass('col-12')			
		}
		else if (preop) {
			$('#pre_op').addClass('col-12')		
		}
	}
	return arr
}

function getSubmissionData(dbDraft)	{
	// Retrieve contents of PouchDB and return as array.
	// Get all matching drafts for this form name 	
	let submissionsList = ''
	dbDraft.allDocs({
		include_docs: false
	}).then((result) => {
		if(result.rows.length) {
			iterateRows(result.rows, dbDraft).then((records) => {
				let pouchData = sortSubmissionData(records)
				//Only allow ReSubmit if online
				checkOnline().then((status)=>{
					if(status) {
					let sendData = []
						for(let sub of pouchData) {
							sendData.push({"submissionID": sub.submissionID,"submittedId":sub.submittedId})
						}

						token = JSON.parse(window.localStorage.getItem('token')).access
						$.ajax({
							url: `<?php echo _API_URL ?>/api/submission/check-submissions-synced/`,
							type: "POST",
							dataType: "json",
							contentType: 'application/json',
							data: JSON.stringify(sendData),
							headers: {
								'Authorization': `Bearer ${token}`
							},
							success: (result) => {
								let failedSubmissions = []
								for(s = 0; s < result.length; s++){
									findSubmittedId = sendData.find(o => o.submissionID === result[s].submissionID) ? parseInt(sendData.find(o => o.submissionID === result[s].submissionID).submittedId):0
									if( findSubmittedId  == parseInt(remoteData[2].Employee[0].per_id)){
										failedSubmissions.push(result[s].submissionID)
									}

								}

								pouchData.forEach((record)=>{
									let children=""
									if(record.children>0)
										children=record.children
									if(parseInt(record.submittedId) == parseInt(remoteData[2].Employee[0].per_id))
									{
										if(failedSubmissions.includes(record.submissionID))
											submissionsList += `<tr><td class="action-wrapper my-3">${record.name}<span class="badge badge-primary ml-1">${children}</span><a href="javascript:ReSubmitSubmission('${record.submissionID}', '${record.formName}', '${record.dateTime}', '${record.pouchKey}')" class="fa fa-share p-1 float-right" title="${i18next.t("8963")}"></a></td></tr>`
										else
											submissionsList += `<tr><td class="action-wrapper my-3">${record.name}<span class="badge badge-primary ml-1">${children}</span></td></tr>`
									}
								})
								
								//Send Support Email IF a day has passed since the last check
								let lastSubmissionSyncCheck = localStorage.getItem('lastSubmissionSyncCheck')
								if(failedSubmissions.length > 0 && (lastSubmissionSyncCheck == null || lastSubmissionSyncCheck < Date.now() - 86400000)) { //86400000 milliseconds in a day

									localStorage.setItem('lastSubmissionSyncCheck', Date.now())
									let mailSubmissions = []

									pouchData.forEach((record) => {
										if(failedSubmissions.includes(record.submissionID))
										{
											mailSubmissions.push({
												submissionID: record.submissionID,
												formName: record.formName,
												submissionDateTime: record.dateTime
											})
										}
									})
									
									$.ajax({
										url: `<?php echo _API_URL ?>/api/submission/missing-submissions-email/`,
										type: "POST",
										dataType:"json",
										data : JSON.stringify(mailSubmissions),
										contentType: 'application/json',
										headers: {
											'Authorization': `Bearer ${JSON.parse(window.localStorage.getItem('token')).access}`
										},
										success: (result) => {

										},
										error: (error) => {
											console.log("There was an Email Error", error)
										}
									})
								}

								$('#submitted-badge').html(failedSubmissions.length > 0 ? failedSubmissions.length : "")
								$('#submittedForms').html( submissionsList )
							},
							error: (error) => {
								console.log("There was an error checking submissions synced", error)

								pouchData.forEach((record)=>{
									let children=""
									if(record.children>0)
										children=record.children
									
									submissionsList += `<tr><td class="action-wrapper my-3">${record.name}<span class="badge badge-primary ml-1">${children}</span></td></tr>`
								})
								$('#submittedForms').html( submissionsList )
							}
						})
					}
					else {
						pouchData.forEach((record)=>{
							let children=""
							if(record.children>0)
								children=record.children
							if(parseInt(record.submittedId) == parseInt(remoteData[2].Employee[0].per_id)){
								submissionsList += `<tr><td class="action-wrapper my-3">${record.name}<span class="badge badge-primary ml-1">${children}</span></td></tr>`
							}
							
						})
						setTimeout(()=>{
							$('#submittedForms').html( submissionsList )
						},1000)
					}
				})
			})
		}
	}).then(()=>{
		var changes = dbSofvieForm.changes({
		    filter: function(doc) {
		      return doc;
		    }
		})

		changes.then((data)=> {
			data.results.forEach((record)=> {
				let lotoFormId=record.id.split(" ")
				formName=lookupFormNameByFormId(lotoFormId.shift())
				formName=formName.concat(lotoFormId)
				submissionsList += `<tr><td class="action-wrapper my-3">${formName}<span class="badge badge-primary ml-1"></span></td></tr>`
				$('#submittedForms').html( submissionsList )
			})
		})
	}).then(()=>{
		let select2LanguageFunction = window[`sofvie_select2_languages_${selectedLanguage}`]
		if (!(typeof select2LanguageFunction === "function"))
		{
			select2LanguageFunction = {}
			console.error("Failed to get Select2 Translations")
		}

		$(".data-table-submitted").DataTable({
			"bSort": false, 
			"lengthMenu": [ 5, 10, 15, 25, 50 ],  
			"pagingType": "numbers",
			"language": {
				"url": `/locales/datatables/i18n/${selectedLanguage}.json`
			},
			"initComplete": function(settings, json) {
				$('.dataTables_length').addClass('bs-select')
				$(".dataTables_wrapper .dataTables_filter").addClass("md-form m-0")
				$(".dataTables_wrapper div:last-of-type div").removeClass("col-md-5 col-md-7")
				$('select:not([class^=picker_])').select2({theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder:""})
				$('.dataTables_wrapper select').select2({theme: "material", language: select2LanguageFunction(), allowClear: false, minimumResultsForSearch: Infinity})
			}
		})
	}).catch((err) => {
		console.error(err)
	})
}


function ReSubmitSubmission (submissionID, formName, submissionDateTime, pouchKey) {	

	const theElements = {
		modalTheme: `modal-warning`,
		modalAlert: `fa-exclamation-triangle`,
		modalTitle: i18next.t("8963"), // Resubmit Form
		// This action will attempt to resubmit the [form name] form. 
		// Please make sure you have a good internet connection to minimize the risk of synchronization failure.
		modalText: i18next.t("8964") + ` ${formName} ` + i18next.t("8965"),
		modalButtons: `<a role="button" id='alertReSubmitModalCancel' class="btn btn-outline-warning waves-effect px-1 flex-fill"><span class='translate' data-i18n="1257" note="Cancel"></span></a>
		<a role="button" id='alertReSubmitModalConfirm' class="btn btn-warning waves-effect confirm px-1 flex-fill"><span class='translate' data-i18n="8962" note="Resubmit"></span></a>`
	}
	showReSubmitAlertModal("warning", theElements)

	$("#alertReSubmitModalConfirm").click(() => {
		$("#footerSpinner").removeClass('d-none')
		//Resubmit Form
		db.get(pouchKey).then(function(doc) {
			return db.put({
				_id: pouchKey,
				_rev: doc._rev,
				formdata: doc.formdata,
				formname: doc.formname,
				timestamp: doc.timestamp,
				submissionID: doc.submissionID
			});
		}).then(function(response) {
			//Send Support Email
			mailSubmission = {
				submissionID: submissionID,
				formName: formName,
				submissionDateTime: submissionDateTime
			}
			
			$.ajax({
				url: `<?php echo _API_URL ?>/api/submission/resubmit-submission-email/`,
				type: "POST",
				dataType:"json",
				data : JSON.stringify(mailSubmission),
				contentType: 'application/json',
				headers: {
					'Authorization': `Bearer ${JSON.parse(window.localStorage.getItem('token')).access}`
				},
				success: (result) => {
					// Wait for form to land in the DB
					setTimeout(()=>{
						location.reload()
         			}, 5000)
				},
				error: (error) => {
					console.log("There was an Email Error", error)
				}
			})
		}).catch(function (err) {
			console.log(err);
		})
	})	
}

function searchFunction() {
	// Declare variables
	var input, filter, table, tr, td, i, txtValue
	input = document.getElementById("myInput");
	filter = input.value.toUpperCase()
	cards=document.getElementById("formList").getElementsByClassName("card")

	if(filter){
		for (i = 0; i < cards.length; i++) {
			cards[i].style.display = "none"
			if(cards[i].getElementsByTagName("table").length>0){
				tr = cards[i].getElementsByTagName("table")[0].getElementsByTagName("tr")
				for (j = 0; j < tr.length; j++) {
					td = tr[j].getElementsByTagName("td")[0];
					if (td) {
						txtValue = td.textContent || td.innerText;
						if (txtValue.toUpperCase().indexOf(filter) > -1) {
							cards[i].style.display = ""
							tr[j].style.display = ""
							if (cards[i].getElementsByTagName('a')[0].classList.contains("collapsed")) {			
								cards[i].getElementsByTagName('a')[0].click()
								cards[i].getElementsByClassName("card-header")[0].style.display = "none"
								cards[i].getElementsByClassName("card-header")[0].nextElementSibling.classList.add("show")
							}					
						} else {
							tr[j].style.display = "none";
						}
					}
				}
			}
			else{     //Search in Custom Forms
				let customForms=cards[i].getElementsByClassName("categoryLink")
				let findSearch=[]
				for(form of customForms){
					txtValue = form.textContent || form.innerText
					if (txtValue.toUpperCase().indexOf(filter) > -1) {
						cards[i].style.display = ""
						findSearch.push(form)
					}
				}
				if(findSearch.length>0){
					cards[i].getElementsByTagName('a')[0].click()	
					cards[i].getElementsByTagName("h5")[0].classList.add("d-none")
					eles=cards[i].getElementsByClassName("accordion")[0].getElementsByTagName("a")					
					for( ele of eles){     //hide all items first
						ele.classList.remove("d-block")
						ele.classList.add("d-none")
					}
					for(find of findSearch){
						if(!find.parentElement.previousElementSibling.nextElementSibling.classList.contains("show")){		
							find.parentElement.previousElementSibling.click()
						}
						find.classList.remove("d-none")   //show found items only
						find.classList.add("d-block")
					}				
				}
			}
		}
	}
	else{    //return to original status before search
		for (i = 0; i < cards.length; i++) {
			if(cards[i].getElementsByTagName("table").length>0){
				tr = cards[i].getElementsByTagName("table")[0].getElementsByTagName("tr")
				for (j = 0; j < tr.length; j++) {
					tr[j].style.display = ""
				}
			}	
			else{
				cards[i].getElementsByTagName('h5')[0].classList.remove("d-none")	
			}
			cards[i].style.display = ""
			cards[i].getElementsByClassName("card-header")[0].style.display = ""
			cards[i].getElementsByTagName('a')[0].classList.add("collapsed")
			cards[i].getElementsByClassName("card-header")[0].nextElementSibling.classList.remove("show")
		}
	}
}

setTimeout(() => {
	const diffs=document.getElementsByClassName('difflang')
	let numb = diffs.length
	for(let i = 0; i<numb; i++){
		diffs[i].addEventListener('click', (e)=>{
			popDraftLoadAlert(diffs[i].lang)
		})
	}
}, 1000);

</script>

<script src="/modals/reSubmitAlert.js"></script>
