<?php	
  $strPageTitle = 'Risk Assessment';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content toolbox">

<div id="incident_statement" class="col-12 mb-2 align-items-stretch flex-column">
      <div class="col-12 mb-2 d-flex align-items-stretch flex-column">
        <button id='jra_button' type="button" onclick="window.location.href = '<?php echo _FORMJOBRISKASSESSMENT?>';" class="btn btn-outline-default rounded rounded-lg waves-effect white btn-lg btn-block p-3 d-flex flex-1 z-depth-1-half text-left">
          <i class="fa fa-file-alt fa-2x mr-3 align-self-center"></i>
          <span class="d-inline-block">
            <strong><span class='translate' data-i18n="9111" notes="Create New"></span></strong><br>
            <span class='translate' data-i18n="2253" notes="Job Risk Assessment"></span>
          </span>
        </button>
      </div>
    </div>
    
  <div class="row">
		<div class="col-12">
			<div class="card mb-4">
				<div class="card-body">
                <a class="float-right">
                <i class="fa fa-info-circle text-primary fa-lg trans_tooltip" data-toggle="tooltip" notes= "All open hazard actions assigned to or created by you." tag="1692"></i>
                </a>
                <h6 class="card-title mb-3"><strong><span class='translate' data-i18n="1365" notes="Form activity"></span></strong></h6>
                <div class="classic-tabs custom-tabs">
					<ul class="nav nav-justified grey lighten-4" role="tablist">
						<li class="nav-item">
							<a class="nav-link  waves-effect active show" data-toggle="tab" href="#ra-drafts" role="tab"><span class='translate' data-i18n="1366" notes="Drafts"></span></a>
						</li>
						<li class="nav-item">
							<a class="nav-link waves-effect" data-toggle="tab" href="#ra-submitted" role="tab"><span class='translate' data-i18n="1367" notes="Submitted"></span></a>
						</li>
					</ul>
					<div class="tab-content px-0">
						<div class="tab-pane fade active show" id="ra-drafts" role="tabpanel">
              <table class="table table-sm widget-table" id="draftRA">
                  <tbody>
                  </tbody>
							</table>
					</div>
					<div class="tab-pane fade" id="ra-submitted" role="tabpanel">
              <table class="table table-sm widget-table" id="submittedRA">
                  <tbody>
                  </tbody>
							</table>
					</div>
				</div>
			</div>
		</div>
	</div>

</main>

<script>
    localStorage.setItem(`noinitialize`, 'true')
</script>

 <?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footerRMM.php");?> 

<script>   

    var DBconfigDraftRmm = {
      draftDbName: 'mobileRmmDraft',
      draftRemoteSync: false,
      commitDBName: _SYNCCOUCHDB,
      commitRemoteSync:  _SYNCDOMAIN + ':' + _SYNCPORT + '/' + _SYNCCOUCHDB
    };

    var DBconfigForm = {
        DbName: 'sofvieRmm',
        RemoteSync: false,
        commitDBName: _SYNCCOUCHDB,
        commitRemoteSync:  _SYNCDOMAIN + ':' + _SYNCPORT + '/' + _SYNCCOUCHDB
    }

    let dbSofvieForm = new PouchDB(DBconfigForm.DbName, {auto_compaction: true})
    let rmmDbDraft = new PouchDB(DBconfigDraftRmm.draftDbName, {auto_compaction: true})

    const RA_FORM_URL = "/forms/formJobRiskAssessment.php"

    function loadJRAPage() {
      openCacheData().then((rdata)=>{
        let selectedLanguage = 'en'
        let langCookie = getCookie("lang")
        selectedLanguage = langCookie ? langCookie : selectedLanguage	
        populatePage(JSON.parse(JSON.stringify(rdata)), rmmDbDraft, dbSofvieForm)
        localStorage.removeItem(`noinitialize`)
        initializeI18N().then(() => {
          $("#footerSpinner").addClass('d-none')
        })
      })
    }

    async function checkJRAformAccess(){
      await openCacheData().then(()=>{
        const formAccessData = remoteData[_FORMACCESS].FormAccess
        let obj = formAccessData.find(o => o.FormID == 372448);
        if(obj === undefined) {
          document.getElementById('jra_button').style.visibility = "hidden"
        } 
      })
    }

    function calculateTotals(submissionid)	{
      return new Promise(resolve =>{
        // Get all matching drafts for this form name 
        rmmDbDraft.allDocs({
          include_docs: true,
          attachments: false,
          startkey: '',
          endkey: '\ufff0'
        }).then((result) => {
          let count= 0 
          for(row of result.rows){
            if(row.doc.submissionID == submissionid){
                count  ++
            }
          }
          resolve(count-1) 
          // always should not include the current form, therefore subtracting one from the count.
        }).catch((err) => {
          console.error(err)
        })		
      })
    }

    function populatePage(remoteDataAll, rmmDbDraft, dbSofvieForm) {
      checkJRAformAccess(JSON.parse(JSON.stringify(remoteDataAll)))
      strDraftForms = ''
      rmmDbDraft.allDocs({ // Get all matching drafts for this form name 
          include_docs: true,
          attachments: false,
          startkey: '',
          endkey: '\ufff0'
      }).then((result) => {
          $.each(result.rows, (i, obj) => { // Iterate over the results 
            calculateTotals(obj.doc.submissionID).then((r) =>{
              if (obj.doc._id.indexOf('_design') == -1) {
                if(parseInt(obj.doc.formdata.jra_data.rmm_jra_created_by_per_id) == parseInt(remoteData[2].Employee[0].per_id))
                {
                  if(r==0) r=''
                  strDraftForms = `<tr><td scope="row"><a url="${RA_FORM_URL}" class="draftlisting d-block" key='${htmlEscape(obj.doc._id)}'>${obj.id}</a></td><td class="text-right"><span class="badge badge-primary ml-1">${r}</span></td></tr>`
                  $('#draftRA').find('tbody').append(strDraftForms)
                  draftEventHandler(obj.doc._id)
                }
              }
            })
          
          })
      }).catch((err) => {
          console.error(err)
      })

      

      var changes = dbSofvieForm.changes({
        filter: function(doc) {
          return doc;
        }
      })

      changes.then((data)=> {
        data.results.forEach((record)=> {
          strDraftForms = `<tr><td scope="row"><a url="${RA_FORM_URL}" class="d-block" key="${record._id}">${record.id}</a></td><td class="text-right"></td></tr>`
             $('#submittedRA').find('tbody').append(strDraftForms)
        })
      })

      function draftEventHandler(item) {
          document.querySelectorAll('.draftlisting').forEach((data)=>{
              if(data.getAttribute("key") == item){
                data.addEventListener('click',(data)=>{
                  sessionStorage.setItem('draftpick', data.target.getAttribute('key'))
                  window.open(data.target.getAttribute('url'), "_self");
                })
              }
          })
      }
    }
</script>
