<?php	
  $strPageTitle = 'My Profile';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");

?>

<main class="col containter-fluid mobile-content my-profile">

<div class="modal fade" id="trainingModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
  <div class="modal-dialog modal-notify modal-info" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <p class="heading lead"></p>
      </div>
      <div class="modal-body">
        <div class="text-center">
          <i class="fas fa-info-circle fa-4x mb-3"></i>
          <p class='modal-body-text'>
          </p>
        </div>
      </div>
      <div class="modal-footer justify-content-center">
        <button type="button" class="btn btn-block btn-info" id="closeTrainingModal"><span class='translate' data-i18n="1405" notes="Ok"></span></button>
      </div>
    </div>
  </div>
</div>

  <div class="row">
		<div class="col-12">
      <div class="card mb-4">
				<div class="card-body">
          <h3 class="card-title text-center m-0"><strong><span id="EmployeeName"></span></strong></h3>
				</div>
			</div>
			<div class="card mb-4">
				<div class="card-body">
          <a class="float-right">
            <i class="fa fa-info-circle text-primary fa-lg trans_tooltip" data-toggle="tooltip" tag="3294" notes="Personal information on file."></i>
          </a>
          <h6 class="card-title"><strong><span class='translate' data-i18n="1756" notes="Employee Info"></span></strong></h6>
          <ul class="list-group list-group-flush">
            <li class="list-group-item px-0">
              <h6><strong><span class='translate' data-i18n="1271" notes="Address"></span></strong></h6>
              <span id="EmployeeAddress"></span>
            </li>
            <li class="list-group-item px-0">
              <h6><strong><span class='translate' data-i18n="1270" notes="Email"></span></strong></h6>
              <span id="EmployeeEmail"></span>
            </li>
            <li class="list-group-item px-0">
              <h6><strong><span class='translate' data-i18n="1757" notes="Phone"></span></strong></h6>
              <span id="EmployeePhone"></span>
            </li>

            <li class="list-group-item px-0">
              <h6><strong><span class='translate' data-i18n="1265" notes="Employee ID"></span></strong></h6>
              <span id="EmployeeID"></span> 
            </li>
            <li class="list-group-item px-0">
              <h6><strong><span class='translate' data-i18n="1758" notes="Roles"></span></strong></h6>
              <span id="EmployeeRole"></span>
            </li>
            <li class="list-group-item px-0">
              <h6><strong><span class='translate' data-i18n="1759" notes="Sites"></span></strong></h6>
              <div class="d-flex justify-content-between">
                <span id="EmployeeLastSite"></span>
              </div>
            </li>
            <li class="list-group-item px-0">
              <h6><strong><span class='translate' data-i18n="617" notes="Department/Job"></span></strong></h6>
              <div class="d-flex justify-content-between">
                <span id="EmployeeJobs"></span>
              </div>
            </li>
          </ul>
				</div>
				<div class="card-body">
          <h6 class="card-title"><strong><span class='translate' data-i18n="3289" notes="Emergency Contact Info"></span></strong></h6>
          <ul class="list-group list-group-flush">
            <li class="list-group-item px-0">
              <h6><strong><span class='translate' data-i18n="649" notes="Name"></span></strong></h6>
              <span id="EmergencyContactName"></span>
            </li>
            <li class="list-group-item px-0">
              <h6><strong><span class='translate' data-i18n="2845" notes="Relationship"></span></strong></h6>
              <span id="EmergencyContactRelationship"></span>
            </li>
            <li class="list-group-item px-0">
              <h6><strong><span class='translate' data-i18n="3290" notes="Mobile Phone"></span></strong></h6>
              <span id="EmergencyContactMobile"></span>
            </li>

            <li class="list-group-item px-0">
              <h6><strong><span class='translate' data-i18n="3291" notes="Work Phone"></span></strong></h6>
              <span id="EmergencyContactWorkPhone"></span> 
            </li>
            <li class="list-group-item px-0">
              <h6><strong><span class='translate' data-i18n="3292" notes="Home Phone"></span></strong></h6>
              <span id="EmergencyContactHomePhone"></span>
            </li>
            <li class="list-group-item px-0">
              <h6><strong><span class='translate' data-i18n="1270" notes="Email"></span></strong></h6>
              <div class="d-flex justify-content-between">
                <span id="EmergencyContactEmail"></span>
              </div>
            </li>
          </ul>
				</div>
			</div>

      <div class="card mb-4">
				<div class="card-body">
          <a class="float-right">
            <i class="fa fa-info-circle text-primary fa-lg trans_tooltip" data-toggle="tooltip" notes="All training records completed since the begining of time." tag="1763"></i>
          </a>
          <h6 class="card-title"><strong><span class='translate' data-i18n="1761" notes="Records"></span></strong></h6>

          <div class="classic-tabs custom-tabs">
						<ul class="nav nav-justified grey lighten-4" role="tablist">
							<li class="nav-item">
								<a class="nav-link  waves-effect active show" data-toggle="tab" href="#records-training" role="tab"><span class='translate' data-i18n="1553" notes="Training"></span></a>
							</li>
							<li class="nav-item">
								<a class="nav-link waves-effect" data-toggle="tab" href="#records-certification" role="tab"><span class='translate' data-i18n="1762" notes="Certification"></span></a>
							</li>
						</ul>
						<div class="tab-content pt-4">
							<div class="tab-pane fade active show" id="records-training" role="tabpanel">
                <table class="w-100 data-table widget-table table">
                  <thead><tr><th></th></tr></thead>
                  <tbody id="Training">
                  </tbody>
                  <tfoot></tfoot>
                </table>
							</div>
							<div class="tab-pane fade" id="records-certification" role="tabpanel">
                <table class="w-100 data-table widget-table table">
                  <thead><tr><th></th></tr></thead>
                  <tbody id="Certification">
                  </tbody>
                  <tfoot></tfoot>
                </table>
							</div>
						</div>
					</div>
          
        </div>
			</div>

      <div class="card mb-4">
				<div class="card-body">
          <a class="float-right">
            <i class="fa fa-info-circle text-primary fa-lg trans_tooltip" data-toggle="tooltip" tag="3295" notes="All performance reviews received since the begining of time."></i>
          </a>
          <h6 class="card-title"><strong><span class='translate' data-i18n="2329" notes="Assesment"></span></strong></h6>

          <div class="classic-tabs custom-tabs">
						<ul class="nav nav-justified grey lighten-4" role="tablist">
							<li class="nav-item">
								<a class="nav-link  waves-effect active show" data-toggle="tab" href="#recognition" role="tab"><span class='translate' data-i18n="1766" notes="Recognition"></span></a>
							</li>
							<li class="nav-item">
								<a class="nav-link waves-effect" data-toggle="tab" href="#review" role="tab"><span class='translate' data-i18n="1188" notes="Review"></span></a>
							</li>
              <li class="nav-item">
								<a class="nav-link waves-effect" data-toggle="tab" href="#discipline" role="tab"><span id="discipline_type" class='translate' data-i18n="1475" notes="Discipline"></span></a>
							</li>
						</ul>
						<div class="tab-content pt-4">
							<div class="tab-pane fade active show" id="recognition" role="tabpanel">
                <table class="w-100 data-table widget-table table" id="recognition-table">
                  <thead><tr><th></th></tr></thead>
                  <tbody id="Recognition">
                  </tbody>
                  <tfoot></tfoot>
                </table>
							</div>
							<div class="tab-pane fade" id="review" role="tabpanel">
                <table class="w-100 data-table widget-table table">
                  <thead><tr><th></th></tr></thead>
                  <tbody id="Review">
                  </tbody>
                  <tfoot></tfoot>
                </table>
							</div>
              <div class="tab-pane fade" id="discipline" role="tabpanel">
                <table class="w-100 data-table widget-table table">
                  <thead><tr><th></th></tr></thead>
                  <tbody id="Disciplines">
                  </tbody>
                  <tfoot></tfoot>
                </table>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>

<div id='likeHistoryComponent'></div>
<div id='commentComponent'></div>
<div id='viewCommentComponent'></div>

<input type="hidden" name="formname" id="formname" tag = "990" value="My Profile"/>
</main>

<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
<script type="text/javascript">

// *** Already been declared in another file  This is for Reference ****
// const _EMPLOYEE = 2;
// const _TRAINING = 3;
// const _EMPLOYEEVIEWPOINT = 10;
// const _CERTIFICATION = 11;
// const _DISCIPLINES = 12;
// const _RECOGNITION = 13;
// const _REVIEW = 0;
// *** ----------------------------------------------------------------***
localStorage.setItem(`noinitialize`, 'true')

openCacheData().then((rdata)=>{
	populatePage(remoteData)
})

function populatePage(remoteData)	{
    if(remoteData[_EMPLOYEE].Employee[0].per_full_name)
	    document.getElementById('EmployeeName').innerHTML += remoteData[_EMPLOYEE].Employee[0].per_full_name;
    if(remoteData[_EMPLOYEE].Employee[0].email)
	    document.getElementById('EmployeeEmail').innerHTML += remoteData[_EMPLOYEE].Employee[0].email;
    if(remoteData[_EMPLOYEE].Employee[0].emp_employee_number)
	    document.getElementById('EmployeeID').innerHTML += remoteData[_EMPLOYEE].Employee[0].emp_employee_number;
    if(remoteData[_EMPLOYEE].Employee[0].roles)
      document.getElementById('EmployeeRole').innerHTML += remoteData[_EMPLOYEE].Employee[0].roles;
    if(remoteData[_EMPLOYEE].Employee[0].sites)
      document.getElementById('EmployeeLastSite').innerHTML += remoteData[_EMPLOYEE].Employee[0].sites;
    if(remoteData[_EMPLOYEE].Employee[0].full_address)
	    document.getElementById('EmployeeAddress').innerHTML += remoteData[_EMPLOYEE].Employee[0].full_address;
    if(remoteData[_EMPLOYEE].Employee[0].jobs)
	    document.getElementById('EmployeeJobs').innerHTML += remoteData[_EMPLOYEE].Employee[0].jobs;
    if(remoteData[_EMPLOYEE].Employee[0].pho_number)
      document.getElementById('EmployeePhone').innerHTML += remoteData[_EMPLOYEE].Employee[0].pho_number;
    if(remoteData[_EMPLOYEE].Employee[0].pec_full_name)
      document.getElementById('EmergencyContactName').innerHTML += remoteData[_EMPLOYEE].Employee[0].pec_full_name;
    if(remoteData[_EMPLOYEE].Employee[0].pec_relationship)
      document.getElementById('EmergencyContactRelationship').innerHTML += remoteData[_EMPLOYEE].Employee[0].pec_relationship;
    if(remoteData[_EMPLOYEE].Employee[0].pec_mobile_phone)
      document.getElementById('EmergencyContactMobile').innerHTML += remoteData[_EMPLOYEE].Employee[0].pec_mobile_phone;
    if(remoteData[_EMPLOYEE].Employee[0].pec_work_phone)
      document.getElementById('EmergencyContactWorkPhone').innerHTML += remoteData[_EMPLOYEE].Employee[0].pec_work_phone;
    if(remoteData[_EMPLOYEE].Employee[0].pec_home_phone)  
      document.getElementById('EmergencyContactHomePhone').innerHTML += remoteData[_EMPLOYEE].Employee[0].pec_home_phone;
    if(remoteData[_EMPLOYEE].Employee[0].pec_email)
      document.getElementById('EmergencyContactEmail').innerHTML += remoteData[_EMPLOYEE].Employee[0].pec_email;

 /// Training Records Grid
 function prepareTraining(data) {
   let train = JSON.parse(JSON.stringify(data))
   
   if(train){
    data.forEach((training, index) => {
     train[index].RecordStatus = getTrainingRecordStatus(train[index])
    });
   let final =  sortTrainingRecords(train)
   return(sortTrainingRecords(final))
   }
   return []
 }

 function sortTrainingRecords(data) {
   let sorted = [];
   let x=0;
   data.forEach((training,index) => {
     if (training.RecordStatus === 'overdue' ){
       sorted[x] = training
       x++
     }
  })
  data.forEach((training,index) => {
     if (training.RecordStatus === 'due' ){
       sorted[x] = training
       x++
     }
  })
  data.forEach((training,index) => {
     if (training.RecordStatus === 'notdue' ){
       sorted[x] = training
       x++
     }
  })
   return sorted
}

function getTrainingRecordStatus(data) {
  let late = dateToday
  if(data.etr_no_expiry_date === "1"){
    data.etr_expiry_date = 'N/A'
    return "notdue"
  } else if(data.etr_expiry_date < todaysDate) {
      return "overdue"
  } else if(data.etr_expiry_date < late.add(1, 'months').format('YYYY-MM-DD')) {
      return "due"
  } else {
      return "notdue"
  }
}

let dateToday = moment(new Date(), 'YYYY-MM-DD')
let todaysDate = dateToday.format('YYYY-MM-DD')
const TrainingData = prepareTraining(remoteData[_TRAINING].Training)
let training = ''
TrainingData.forEach((data, index)=>{
  if(data.rld_option != 3 && data.rld_option != 4 && data.rld_option != 5 ) {
    let dueStyle = 'color: #ffc107'
    if(data.RecordStatus!=='due'){
      dueStyle = ''
    }
    if(!data.training_description)
      data.training_description = ""
    training += `<tr><td class="action-wrapper my-3 
    ${data.RecordStatus}"><div class="d-flex justify-content-between">
    <h6><strong>${data.training_code} - ${data.training_name}</strong></h6>`
      if(data.RecordStatus !== 'overdue') {
        training += `<div><a id="attachmentDownload" trainingId = "${data.etr_id}" class="downloadlink rounded-circle badge bg-secondary ml-3 training-docs">
          <i class="fa fa-download fa-1x fa-fw py-1"></i>
        </a></div>`
      }
    training += `</div><p class="description">${data.training_description}</p>
    <span class="d-flex justify-content-between"><small>
    ${data.etr_completion_date ? data.etr_completion_date.substring(0,10):"N/A"}</small><small style="${dueStyle}"><span class='translate' data-i18n="1262" notes="Expiry Date"></span>: 
    ${data.etr_expiry_date ? data.etr_expiry_date.substring(0,10):"N/A" }</small></span></td></tr>`
  }
  else {
    if(!data.training_description)
      data.training_description = ""
      training += `<tr><td class="action-wrapper my-3 
      "notdue"}"><div class="d-flex justify-content-between">
      <h6><strong>${data.training_code} - ${data.training_name}</strong></h6>`
      training += `</div><p class="description">${data.training_description}</p>
      <span class="d-flex justify-content-between"><small>
      ${data.etr_training_status_lable}</small><small style="notdue"></td></tr>`
  }

})

  document.getElementById('Training').innerHTML += training;

  document.getElementById('closeTrainingModal').addEventListener("click", () =>{
    $("#trainingModal").modal("hide")
  })

  function trainingModal(trainingDocumentArray) {
    trainingRec = ""
    $(`#trainingModal p.heading`).html(`<span notes="Proof of Completion">${i18next.t('8947')}</span>`)
    if(!window.navigator.onLine)	{
      $(`#trainingModal .modal-body-text`).html(`${i18next.t('9083')}`)
    }
    else if(trainingDocumentArray.attachments.length > 0) {
      trainingDocumentArray.attachments.forEach((rec)=>{
      theUrl = `<?php echo _IMAGE_URL ?>/training_attachments/employee_id_${remoteData[_EMPLOYEE].Employee[0].emp_id}/training_id_${rec.eta_etr_id}`
      trainingRec += `<tr><td class="justify-content-start action-wrapper py-2">
        <div class="d-flex justify-content-start text-decoration-none">
          <a class="text-decoration-none text-info" href="${theUrl}/${rec.eta_attachment_name}" target="_blank" class="description">${rec.eta_attachment_comment}</a>
        </div>
        <small><span class="d-flex justify-content-start">${moment(rec.eta_created_date).format('YYYY-MM-DD HH:mm:ss')}<span></small>
        </td></tr>`
      })
      $(`#trainingModal .modal-body-text`).html(trainingRec)
    }
    else {
      $(`#trainingModal .modal-body-text`).html(`${i18next.t('9068')}`)
    }
      $("#trainingModal").modal("show");
  }

  // Certifications Grid
  let certificationData = prepareTraining(remoteData[_CERTIFICATION].Certifications)
  let certification = ''
  certificationData.forEach((data, index)=>{
    if(data.rld_option != 3 && data.rld_option != 4 && data.rld_option != 5 ) {
      if(!data.training_description)
        data.training_description = ""
      let dueStyle = 'color: #ffc107'
      if(data.RecordStatus!=='due'){
        dueStyle = ''
      }
      certification += `<tr><td class="action-wrapper my-3 
      ${data.RecordStatus}"><div class="d-flex justify-content-between">
      <h6><strong>${data.training_code} - ${data.training_name}</strong></h6>`
      if(data.RecordStatus !== 'overdue') {
        certification += `<div><span id="attachmentDownload" trainingId = "${data.etr_id}" class="downloadlink rounded-circle badge bg-secondary ml-3 training-docs">
          <i class="fas fa-download py-1"></i>
        </span></div>`
      }
      certification += `</div><p class="description">${data.training_description}</p><span class="d-flex justify-content-between"><small>
      ${data.etr_completion_date ? data.etr_completion_date.substring(0,10):"N/A"}</small><small style="${dueStyle}"><span class='translate' data-i18n="8673" notes="Expires"></span>: 
      ${data.etr_expiry_date ? data.etr_expiry_date.substring(0,10):"N/A"}</small></span></td></tr>`
    }
    else {
      if(!data.training_description)
        data.training_description = ""
        certification += `<tr><td class="action-wrapper my-3 
        "notdue"}"><div class="d-flex justify-content-between">
        <h6><strong>${data.training_code} - ${data.training_name}</strong></h6>`
        certification += `</div><p class="description">${data.training_description}</p>
        <span class="d-flex justify-content-between"><small>
        ${data.etr_training_status_lable}</small><small style="notdue"></td></tr>`
    }
  })
  
	document.getElementById('Certification').innerHTML += certification;
 
// create the events for the download links
  Array.from(document.getElementsByClassName('training-docs')).forEach((data) => {
		data.addEventListener('click',(event) => {
      access = JSON.parse(window.localStorage.getItem('token')).access
      trainingUrl = `<?php echo _API_URL ?>/api/training/list-training-record-attachments/`

      checkOnline().then((res)=>{
        if(res) {
          $.ajax({
              url: trainingUrl,
              type: 'post',
              dataType: 'json',
              contentType: 'application/json',
              beforeSend: function(request) {
                request.setRequestHeader("Authorization", `Bearer ${access}`)
              },
              data: JSON.stringify({"etr_id" : data.getAttribute('trainingid')}),
              success: function (data) {
                trainingModal(data)
              },
              error: function (data) {
                console.log(" This is the Data")
              }
            })
        }
        else
        {
          trainingModal([{attachments:[]}])
        }
      }).catch((err)=>{

      })
		  }, false)
	})

  // Recognition Data
  let recognition = '';  

  if(remoteData[_RECOGNITION].PositiveRecognition) {
    remoteData[_RECOGNITION].PositiveRecognition.forEach((data)=>{

    recognition += `<tr>
                      <td class="action-wrapper my-3">
                        <div class="d-flex justify-content-between">
                          <h6>
                            <strong>${data.RecognitionType}</strong>
                          </h6>
                          <span id="likeCommentSection-${data.ID}" class="text-primary d-none">
                            <div class="btn-group show">
                                <div data-toggle="dropdown" class="pointer">
                                    <i id="recognitionLikeIcon-${data.ID}" class="fa fa-thumbs-up"></i> <span id="recognitionLikeCount-${data.ID}"></span>
                                </div>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <button id="recognitionLikeButton-${data.ID}" class="dropdown-item pointer" type="button" notes="Like Positive Recognition"></button>
                                    <button id="recognitionViewLikeButton-${data.ID}" class="dropdown-item pointer translate" type="button" data-i18n="8674" notes="View Likes"></button>
                                </div>
                            </div>
                                
                            <div class="btn-group show">
                                <div data-toggle="dropdown" class="pointer">
                                    <i id="recognitionCommentIcon-${data.ID}" class="far fa-comment ml-3"></i> <span id="recognitionCommentCount-${data.ID}"></span>
                                </div>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <button id="recognitionCommentButton-${data.ID}" class="dropdown-item pointer translate" type="button" data-i18n="8921" notes="Add Comment"></button>
                                    <button id="recognitionViewCommentsButton-${data.ID}" class="dropdown-item pointer translate" type="button" data-i18n="8922" notes="View Comments"></button>
                              </div>
                            </div>
                          </span>
                        </div>
                        <p class="description">${data.EventDescription}</p>
                        <span class="d-flex justify-content-between">
                          <small><span class='translate' data-i18n="1298" notes="Created By"></span>: ${data.Supervisor}</small>
                          <small><span class='translate' data-i18n="124" notes="Date"></span>: ${data.FormSubmissionDate.substring(0,10)}</small>
                        </span>
                      </td>
                    </tr>`;
  });
	document.getElementById('Recognition').innerHTML += recognition;
  }

  // Disciplines Grid Data
  let disciplines = '';
  let discipline_type = 248310
  if(remoteData[_DISCIPLINES].Disciplines && remoteData[_DISCIPLINES].Disciplines.length){
    discipline_type=remoteData[_DISCIPLINES].Disciplines[0].FormID
  }
  if(discipline_type==372428){
    document.getElementById("discipline_type").setAttribute("data-i18n","1445")
  }
  if(remoteData[_DISCIPLINES].Disciplines) {
   remoteData[_DISCIPLINES].Disciplines.forEach((data)=>{
      disciplines += `<tr>
            <td class="item-wrapper py-3 px-0">
              <h6><strong>Type: ${data.event_type} </strong></h6>
              <p class="description">${data.discipline_violation} </p>
              <span class="d-flex justify-content-between">
                <small><span class='translate' data-i18n="1298" notes="Created By"></span>: ${data.submitted_by}</small>
                <small><span class='translate' data-i18n="124" notes="Date"></span>: ${data.FormSubmissionDate}</small>
              </span>
            </td>
          </tr>`;
  });
  document.getElementById('Disciplines').innerHTML += disciplines;
  }

  reviewData = remoteData[18].Reviews
  var review = ''
  if(reviewData) {
    reviewData.forEach((data)=>{
      review += ` <tr>
            <td class="item-wrapper py-3 px-0">
            <p class="description">${data.goals_1}. ${data.goals_2}. ${data.goals_3}.</p> 
            <div class="d-flex justify-content-between">
              <small><span class='translate' data-i18n="1298" notes="Created By"></span>: ${data.submitted_by}</small>
              <small><span class='translate' data-i18n="124" notes="Date"></span>: ${data.FormSubmissionDate}</small>
            </div>
          </td> 
        </tr>`
    })
  document.getElementById('Review').innerHTML += review
  }

   /// Pad with Zeros Function
  function pad(num, size) {
    var s = "000000000" + num;
    return s.substr(s.length - size);
    }
  }
  ////////////////////////////////////
  // Positive Recognition like/comments

  let recognitionData = []

  checkOnline().then((online) => {
    if(online){
      setTimeout(() => {
        updateRecognitionLikeComment()
      }, 2000)

     }
  }).catch((err)=>{})

  updateRecognitionLikeComment = () => {
    token = JSON.parse(window.localStorage.getItem('token')).access
    $.ajax({
      url: `<?php echo _API_URL ?>/api/userprofile/get-employee-positive-recognition-mobile/`,
      type: "GET",
      dataType: "json",
      contentType: 'application/json',
      headers: {
        'Authorization': `Bearer ${token}`
      },
      success: (result) => {
        recognitionData = result
        if(localStorage.getItem(`noinitialize`)) {
          localStorage.removeItem(`noinitialize`)
          initializeDataTables()
          initializeSelect2()
          $("#footerSpinner").addClass('d-none')
        }
        refreshRecognitionLikeComment()
      },
      error: (error) => {
        console.log("There was an error getting positive recognitions", error)
      }
    })
  }

  // Refresh when table page changes
  $('#recognition-table').on('draw.dt', () => {
    refreshRecognitionLikeComment()
  })

  refreshRecognitionLikeComment = () => {
    recognitionData.forEach((recognition) => {

      let sectionElement = document.getElementById("likeCommentSection-" + recognition.parent_submission_id)
      if(sectionElement)
        sectionElement.classList.remove('d-none')

      // Update icons and counts
      let likeCountElement = document.getElementById("recognitionLikeCount-" + recognition.parent_submission_id)
      if(likeCountElement)
        likeCountElement.innerHTML = recognition.likeCount == 0 ? "" : recognition.likeCount

      let likeIconElement = document.getElementById("recognitionLikeIcon-" + recognition.parent_submission_id)
      if(likeIconElement) {
        if(recognition.liked_by_per)
          likeIconElement.classList.add('text-secondary')
        else
          likeIconElement.classList.remove('text-secondary')
      }

      let commentCountElement = document.getElementById("recognitionCommentCount-" + recognition.parent_submission_id)
      if(commentCountElement)
        commentCountElement.innerHTML = recognition.commentCount == 0 ? "" : recognition.commentCount

      let commentIconElement = document.getElementById("recognitionCommentIcon-" + recognition.parent_submission_id)
      if(commentIconElement) {
        if(recognition.commentCount > 0) {
          commentIconElement.classList.remove('far')
          commentIconElement.classList.add('fa')
        } else {
          commentIconElement.classList.add('far')
          commentIconElement.classList.remove('fa')
        }

        if(recognition.comment_by_per)
          commentIconElement.classList.add('text-secondary')
        else
          commentIconElement.classList.remove('text-secondary')
      }

      /////////////////////
      // Like Buttons

      let likeButtonElement = document.getElementById("recognitionLikeButton-" + recognition.parent_submission_id)
      if(likeButtonElement) {
        // Remove all event listeners
        likeButtonElement = clearEventListeners(likeButtonElement, "recognitionLikeButton-" + recognition.parent_submission_id)

        likeButtonElement.addEventListener("click", () => {
          if(!recognition.liked_by_per) {
            likeRecognition(recognition.pid_id)
          } else {
            formModal = new SofvieModal();
            formModal.setModalElements(`warning`, `modalText`, i18next.t("3827"))
            formModal.setModalElements(`warning`, `modalTitle`, i18next.t("3828"))
            formModal.handleModal(`warning`)
            $(`.modal-footer .confirm`).click(() => { 
              likeRecognitionRemove(recognition.mylikeid)
              formModal.hideModal()
            })
          }
        })

        if(recognition.liked_by_per)
          likeButtonElement.innerHTML = i18next.t("9115") // Unlike Positive Recognition
        else
          likeButtonElement.innerHTML = i18next.t("8931") // Like Positive Recognition
      }

      let veiwLikeButtonElement = document.getElementById("recognitionViewLikeButton-" + recognition.parent_submission_id)
      if(veiwLikeButtonElement && recognition.likeCount > 0) {
        // Remove all event listeners
        veiwLikeButtonElement = clearEventListeners(veiwLikeButtonElement, "recognitionViewLikeButton-" + recognition.parent_submission_id)

        veiwLikeButtonElement.addEventListener("click", () => {
          showLikeHistoryModal()

          let likeHistoryContent = document.getElementById("likeHistoryContent")
          likeHistoryContent.innerHTML = ""
          recognition.likes.forEach((like) => {
            likeHistoryContent.innerHTML += 
            (`<li>
                <span class="signoff-history-name">${like.SigningName}</span>
                <span>${like.prl_position == null ? "" : like.prl_position}</span>
                <span class="signoff-history-date">${like.SigningTimestamp.substring(0,10)}</span>
              </li>`)
          })
        })            

        veiwLikeButtonElement.style.display = "block"
      } else if (veiwLikeButtonElement) {
        veiwLikeButtonElement.style.display = "none"
      }

      /////////////////////
      // Comment Buttons

      let commentButtonElement = document.getElementById("recognitionCommentButton-" + recognition.parent_submission_id)
      if(commentButtonElement) {
        // Remove all event listeners
        commentButtonElement = clearEventListeners(commentButtonElement, "recognitionCommentButton-" + recognition.parent_submission_id)

        commentButtonElement.addEventListener("click", () => {
          showCommentModal(recognition.pid_id)
        })
      }

      let viewCommentsButtonElement = document.getElementById("recognitionViewCommentsButton-" + recognition.parent_submission_id)
      if(viewCommentsButtonElement && recognition.commentCount > 0) {
        // Remove all event listeners
        viewCommentsButtonElement = clearEventListeners(viewCommentsButtonElement, "recognitionViewCommentsButton-" + recognition.parent_submission_id)

        viewCommentsButtonElement.addEventListener("click", () => {
          showViewCommentsModal(9008)
          updateCommentsList(recognition.comments, recognition.pid_id)
        })

        viewCommentsButtonElement.style.display = "block"
      } else if (viewCommentsButtonElement) {
        viewCommentsButtonElement.style.display = "none"
      }

    })
  }

  updateCommentsList = (commentData, RecognitionID) => {
    if(commentData) { // Use data from recognition object
      refreshCommentsList(commentData, RecognitionID)
    } else { // Need to get new data

      payload = {"submission_pid": RecognitionID}

      token = JSON.parse(window.localStorage.getItem('token')).access
      $.ajax({
        url: `<?php echo _API_URL ?>/api/recognition/get-comment-list/`,
        type: "POST",
        dataType: "json",
        contentType: 'application/json',
        data: JSON.stringify(payload),
        headers: {
          'Authorization': `Bearer ${token}`
        },
        success: (result) => {
          refreshCommentsList(result.list_comments, RecognitionID)            
        },
        error: (error) => {
          console.log("There was an error getting positive recognitions", error)
        }
      })
    }
  }

  refreshCommentsList = (commentData, RecognitionID) => {

    refreshRecognitionCommentsData(commentData, RecognitionID)

    let viewCommentsContent = document.getElementById("viewCommentsContent")
    viewCommentsContent.innerHTML = ""

    commentData.forEach((comment) => {
      updateViewCommentsContentTable(comment)
    }) 

    commentData.forEach((comment) => {

      let likeCountElement = document.getElementById("commentLikeCount-" + comment.com_id)
      if(likeCountElement)
        likeCountElement.innerHTML = comment.likes_count == 0 ? "" : comment.likes_count

      let likeIconElement = document.getElementById("commentLikeIcon-" + comment.com_id)
      if(likeIconElement) {
        if(comment.liked_by_per)
          likeIconElement.classList.add('text-secondary')
        else
          likeIconElement.classList.remove('text-secondary')
      }

      /////////////////////
      // Like Buttons

      let likeButtonElement = document.getElementById("commentLikeButton-" + comment.com_id)
      if(likeButtonElement) {
        // Remove all event listeners
        likeButtonElement = clearEventListeners(likeButtonElement, "commentLikeButton-" + comment.com_id)

        likeButtonElement.addEventListener("click", () => {
          if(!comment.liked_by_per) {
            likeComment(comment.com_id, RecognitionID)
          } else {
            formModal = new SofvieModal();
            formModal.setModalElements(`warning`, `modalText`, i18next.t("9112")) // Your record of liking this comment will be erased. Continue?
            formModal.setModalElements(`warning`, `modalTitle`, i18next.t("3828"))
            formModal.handleModal(`warning`, true)
            $(`.modal-footer .confirm`).click(() => { 
              likeCommentRemove(comment.com_id, RecognitionID)
              formModal.hideModal()
            })
          }
        })

        if(comment.liked_by_per)
          likeButtonElement.innerHTML = i18next.t("9113") // Unlike Comment
        else
          likeButtonElement.innerHTML = i18next.t("9114") // Like Comment
      }

      let veiwLikeButtonElement = document.getElementById("commentViewLikeButton-" + comment.com_id)
      if(veiwLikeButtonElement && comment.likes_count > 0) {
        // Remove all event listeners
        veiwLikeButtonElement = clearEventListeners(veiwLikeButtonElement, "commentViewLikeButton-" + comment.com_id)

        veiwLikeButtonElement.addEventListener("click", () => {
          showLikeHistoryModal(true)

          let likeHistoryContent = document.getElementById("likeHistoryContent")
          likeHistoryContent.innerHTML = ""
          comment.likes.forEach((like) => {
            likeHistoryContent.innerHTML += 
            (`<li>
                <span class="signoff-history-name">${like.liked_by}</span>
                <span>${like.position == null ? "" : like.position}</span>
                <span class="signoff-history-date">${like.created_date.substring(0,10)}</span>
              </li>`)
          })
        })

        veiwLikeButtonElement.style.display = "block"
      } else if(veiwLikeButtonElement) {
        veiwLikeButtonElement.style.display = "none"
      }

      /////////////////////////
      // Comment Edit Button

      let editButtonElement = document.getElementById("commentEditIcon-" + comment.com_id)
      let currentPersonID = remoteData[2].Employee[0].per_id

      if(editButtonElement && comment.com_created_by_per_id == currentPersonID) {
        // Remove all event listeners
        editButtonElement = clearEventListeners(editButtonElement, "commentEditIcon-" + comment.com_id)
        editButtonElement.addEventListener("click", () => {
          showCommentModal(RecognitionID, comment.com_id, comment.com_comment, true)
        })

        editButtonElement.style.display = "inline"
      } else if(editButtonElement) {
        editButtonElement.style.display = "none"
      }

      /////////////////////////
      // Comment Delete Button
      let deleteButtonElement = document.getElementById("commentDeleteIcon-" + comment.com_id)

      if(deleteButtonElement && comment.com_created_by_per_id == currentPersonID) {
        // Remove all event listeners
        deleteButtonElement = clearEventListeners(deleteButtonElement, "commentDeleteIcon-" + comment.com_id)
        deleteButtonElement.addEventListener("click", () => {
          formModal = new SofvieModal();
          formModal.setModalElements(`warning`, `modalText`, i18next.t("3455"))
          formModal.setModalElements(`warning`, `modalTitle`, i18next.t("2182"))
          formModal.handleModal(`warning`, true)
          $(`.modal-footer .confirm`).click(() => { 
            commentRecognitionDelete(comment.com_id, RecognitionID)
            formModal.hideModal()
          })
        })

        deleteButtonElement.style.display = "inline"
      } else if(deleteButtonElement) {
        deleteButtonElement.style.display = "none"
      }


    })

  }

  refreshRecognitionCommentsData = (commentData, recognitionID) => {
    recognitionData.forEach((recognition) => {
      if(recognition.pid_id == recognitionID)
        recognition.comments = commentData
    })

  }

  likeRecognition = (ID) => {
    payload = {"submission_pid": ID}

    token = JSON.parse(window.localStorage.getItem('token')).access
    $.ajax({
      url: `<?php echo _API_URL ?>/api/recognition/add-likes/`,
      type: "POST",
      dataType: "json",
      contentType: 'application/json',
      data: JSON.stringify(payload),
      headers: {
        'Authorization': `Bearer ${token}`
      },
      success: (result) => {
        updateRecognitionLikeComment()
      },
      error: (error) => {
        console.log("There was an error liking the positive recognition", error)
      }
    })
  }

  likeRecognitionRemove = (ID) => {
    payload = {"like_id": ID}

    token = JSON.parse(window.localStorage.getItem('token')).access
    $.ajax({
      url: `<?php echo _API_URL ?>/api/recognition/delete-likes-by-like-id/`,
      type: "POST",
      dataType: "json",
      contentType: 'application/json',
      data: JSON.stringify(payload),
      headers: {
        'Authorization': `Bearer ${token}`
      },
      success: (result) => {
        updateRecognitionLikeComment()
      },
      error: (error) => {
        console.log("There was an error removeing the positive recognition like", error)
      }
    })
  }

  commentRecognition = (ID, comment) => {
    payload = {
      "com_cmt_id": 11,
      "com_reference_id": ID,
      "com_comment": comment
    }

    token = JSON.parse(window.localStorage.getItem('token')).access
    $.ajax({
      url: `<?php echo _API_URL ?>/api/comments/add-multiple-comment/`,
      type: "POST",
      dataType: "json",
      contentType: 'application/json',
      data: JSON.stringify(payload),
      headers: {
        'Authorization': `Bearer ${token}`
      },
      success: (result) => {
        updateRecognitionLikeComment()
      },
      error: (error) => {
        console.log("There was an error adding the recognition comment", error)
      }
    })
  }

  commentRecognitionUpdate = (ID, comment, RecognitionID) => {
    payload = {
      "com_id": ID,
      "com_comment": comment
    }

    token = JSON.parse(window.localStorage.getItem('token')).access
    $.ajax({
      url: `<?php echo _API_URL ?>/api/comments/update-comment/`,
      type: "POST",
      dataType: "json",
      contentType: 'application/json',
      data: JSON.stringify(payload),
      headers: {
        'Authorization': `Bearer ${token}`
      },
      success: (result) => {
        updateCommentsList(null, RecognitionID)
      },
      error: (error) => {
        console.log("There was an error adding the recognition comment", error)
      }
    })
  }

  commentRecognitionDelete = (ID, RecognitionID) => {

    payload = {
      "com_id": ID
    }

    token = JSON.parse(window.localStorage.getItem('token')).access
    $.ajax({
      url: `<?php echo _API_URL ?>/api/comments/delete-comment/`,
      type: "POST",
      dataType: "json",
      contentType: 'application/json',
      data: JSON.stringify(payload),
      headers: {
        'Authorization': `Bearer ${token}`
      },
      success: (result) => {
        updateRecognitionLikeComment()
        updateCommentsList(null, RecognitionID)
      },
      error: (error) => {
        console.log("There was an error adding the recognition comment", error)
      }
    })
  }

  likeComment = (ID, RecognitionID) => {
    payload = {"com_id": ID}

    token = JSON.parse(window.localStorage.getItem('token')).access
    $.ajax({
      url: `<?php echo _API_URL ?>/api/recognition/add-comment-like/`,
      type: "POST",
      dataType: "json",
      contentType: 'application/json',
      data: JSON.stringify(payload),
      headers: {
        'Authorization': `Bearer ${token}`
      },
      success: (result) => {
        updateCommentsList(null, RecognitionID)
      },
      error: (error) => {
        console.log("There was an error liking the comment", error)
      }
    })
  }

  likeCommentRemove = (ID, RecognitionID) => {
    payload = {"clk_com_id": ID}

    token = JSON.parse(window.localStorage.getItem('token')).access
    $.ajax({
      url: `<?php echo _API_URL ?>/api/recognition/delete-comment-like/`,
      type: "POST",
      dataType: "json",
      contentType: 'application/json',
      data: JSON.stringify(payload),
      headers: {
        'Authorization': `Bearer ${token}`
      },
      success: (result) => {
        updateCommentsList(null, RecognitionID)
      },
      error: (error) => {
        console.log("There was an error liking the comment", error)
      }
    })
  }

  clearEventListeners = (element, elementID) => {
    let clone = element.cloneNode(true)
    element.parentNode.replaceChild(clone, element)
    return document.getElementById(elementID)
  }


</script>

<script src="/modals/likeHistoryModal.js"></script>
<script src="/modals/commentModal.js"></script>
<script src="/modals/viewCommentsModal.js"></script>
