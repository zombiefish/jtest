<?php	
  $strPageTitle = 'Action Items';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

  <main class="col containter-fluid mobile-content action-items">

  <div class="row">
		<div class="col-12">
			<div class="card mb-4">
				<div class="card-body">
                <a class="float-right">
                <i class="fa fa-info-circle text-primary fa-lg trans_tooltip" data-toggle="tooltip" notes= "All open hazard actions assigned to or created by you." tag="1692"></i>
                </a>
                <h6 class="card-title mb-3"><strong><span class='translate' data-i18n="1218" notes="Hazard Actions"></span></strong></h6>
                <div class="classic-tabs custom-tabs">
					<ul class="nav nav-justified grey lighten-4" role="tablist">
						<li class="nav-item">
							<a class="nav-link  waves-effect active show" data-toggle="tab" href="#toMeTab" role="tab"><span class='translate' data-i18n="1062" notes="Assigned to me"></span></a>
						</li>
						<li class="nav-item">
							<a class="nav-link waves-effect" data-toggle="tab" href="#byMeTab" role="tab"><span class='translate' data-i18n="1063" notes="Created by me"></span></a>
						</li>
					</ul>
					<div class="tab-content px-0">
						<div class="tab-pane fade active show" id="toMeTab" role="tabpanel">
							<table class="w-100 data-table widget-table table">
								<thead><tr><th></th></tr></thead>
									<tbody id="HazardActions">
									</tbody>
									<tfoot></tfoot>
							</table>
					</div>
					<div class="tab-pane fade" id="byMeTab" role="tabpanel">
						<table class="w-100 data-table widget-table table">
							<thead><tr><th></th></tr></thead>
								<tbody id="HazardActionsByMe">
								</tbody>
								<tfoot></tfoot>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="card mb-4">
		<div class="card-body">
          <a class="float-right">
            <i class="fa fa-info-circle text-primary fa-lg trans_tooltip" data-toggle="tooltip" notes="All open incident actions assigned to you." tag="1693"></i>
          </a>
          <h6 class="card-title mb-5"><strong><span class='translate' data-i18n="1219" notes="Incident Actions"></span></strong></h6>
          <table class="w-100 data-table widget-table table">
            <thead><tr><th></th></tr></thead>
				<tbody id="IncidentActions">
				</tbody>
            <tfoot></tfoot>
          </table>
				</div>
			</div>
		</div>
	</div>

 <!-- General Actions TABS -->
	<div class="row">
		<div class="col-12">
			<div class="card mb-4">
				<div class="card-body">
                <a class="float-right">
                <i class="fa fa-info-circle text-primary fa-lg trans_tooltip" data-toggle="tooltip" notes="All open general actions assigned to or created by you." tag="3096"></i>
                </a>
                <h6 class="card-title mb-3"><strong><span class='translate' data-i18n="1324" notes="General Actions"></span></strong></h6>
                <div class="classic-tabs custom-tabs">
					<ul class="nav nav-justified grey lighten-4" role="tablist">
						<li class="nav-item">
							<a class="nav-link  waves-effect active show" data-toggle="tab" href="#generalToMeTab" role="tab"><span class='translate' data-i18n="1062" notes="Assigned to me"></span></a>
						</li>
						<li class="nav-item">
							<a class="nav-link waves-effect" data-toggle="tab" href="#generalByMeTab" role="tab"><span class='translate' data-i18n="1063" notes="Created by me"></span></a>
						</li>
					</ul>
					<div class="tab-content px-0">
						<div class="tab-pane fade active show" id="generalToMeTab" role="tabpanel">
							<table class="w-100 data-table widget-table table">
								<thead><tr><th></th></tr></thead>
									<tbody id="GeneralActions">
									</tbody>
									<tfoot></tfoot>
							</table>
					</div>
					<div class="tab-pane fade" id="generalByMeTab" role="tabpanel">
						<table class="w-100 data-table widget-table table">
							<thead><tr><th></th></tr></thead>
								<tbody id="GeneralActionsByMe">
								</tbody>
								<tfoot></tfoot>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>	
</main>

<!--spinner for File upload-->

<div class="spinnerContainer SWspinnerContainer d-none" id='filespinner'>
  <div class="preloader-wrapper big active">
    <div class="spinner-layer spinner-blue-only">
      <div class="circle-clipper left">
        <div class="circle"></div>
      </div>
      <div class="gap-patch">
        <div class="circle"></div>
      </div>
      <div class="circle-clipper right">
        <div class="circle"></div>
      </div>
    </div>
  </div>
</div>

<!-- Modal for Hazard and Incident Actions -->
 <div class="modal fade" data-backdrop="static" id="ActionCompletionModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
				<p class="heading lead"><span class='translate' data-i18n="3089" notes="Hazard Action Completion"></span></p>
      </div>
      <div class="modal-body">
        <form name='action-completion' id='action-completion' class='needs-validation'action="#" novalidate>
          <div class="pt-1 position-relative mb-4">
						<select name="action_complete_by_who" id="action_complete_by_who" class="action-employee-select" multiple required>
						</select>
						<label for="action_complete_by_who"><span class='translate' data-i18n="2028" notes="Completed By"></span></label>
					</div>
          <div class="md-form">
						<input type="text" name="action_completed_date" id="action_completed_date" class="form-control datepicker" required>
						<label for="action_completed_date"><span class='translate' data-i18n="2001" notes="Completed Date"></span></label>
					</div>
          <div class="md-form">
						<textarea name="completed_action_taken" id="completed_action_taken" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
						<label for="completed_action_taken"><span class='translate' data-i18n="15" notes="Action Taken"></span></label>
					</div>
          <div class="pt-1 position-relative my-4">
						<select name="completed_action_type" id="completed_action_type" class="select-single action-actiontype-select" required>
						</select>
						<label for="completed_action_type"><span class='translate' data-i18n="17" notes="Action Type"></span></label>
					</div>

					<canvas id="canvas" style='display:none;'></canvas>
					<div class="form-group photoImage my-4" id="actionphoto"> 
						<label class="d-block"><span class='translate' data-i18n="1413" notes="Include photos"></span></label>
						<canvas id="actioncanvas" style='display:none;'></canvas>
						<div class="btn-group d-flex" role="group">
						<div class="btn btn-block btn-outline-secondary file-field px-1">
							<i class="fa fa-upload"></i><span class='translate' data-i18n="2340" notes="Add Images"></span>
							<input type="file" id="actionpics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
						</div>
						</div>
						<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
						<div class="row photoGallery" id="actiongalleryid"></div>
					</div>


						<input type="hidden" name="submissionId" id="submissionId" value="" />
						<input type="hidden" name="rowid" id="rowid" value="" />
						<input type="hidden" name="id" id="id" value="" />
						<input type="hidden" name="site" id="site" value="" />
						<input type="hidden" name="sitelevel" id="sitelevel" value="" />
						<input type="hidden" name="workplace" id="workplace" value="" />
						<input type="hidden" name="action" id="action" value="" />
						<input type="hidden" name="action_contextual_date" id="action_contextual_date" value="" />
						<input type="hidden" name="reporturl" id="reporturl" value="" />
						<input type="hidden" name="Report_Distribution1" id="Report_Distribution1" value="" />
						<input type="hidden" name="datatype" id="datatype" value="" />
						<input type="hidden" name="formname" id="formname" value="ACTIONCOMPLETE" />
						<input type="hidden" name="formtype" id="formtype" value="AC" />
						<input type="hidden" name="formid" id="formid" value="999999"/>
						<input type="hidden" name="version" id="version" value="01" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="hapSubmmitedBy" id="hapSubmmitedBy" value="" />	
						<input type="hidden" name="keyField" id="keyField" value="workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
        </form>
      </div>
      <div class="modal-footer text-right">
        <div id='cancel_completed' class="px-1 flex-fill btn btn-outline-primary waves-effect" ><span class='translate' data-i18n="1257" notes="Cancel"></span></div>
        <button id="completed"  class="px-1 flex-fill btn btn-primary waves-effect" ><span class='translate' data-i18n="3091" notes="Mark as Complete"></span></button>
      </div>

    </div>
  </div>
</div> 

<!--  General Action Completion -->
 <div class="modal fade" data-backdrop="static" id="GeneralActionCompletionModal" tabindex="-1" role="dialog">
  	<div class="modal-dialog" role="document">
    	<div class="modal-content">
      		<div class="modal-header">
				<p class="heading lead"><span class='translate' data-i18n="3092" notes="General Action Completion"></span></p>
      		</div>
      		<div class="modal-body">
				<form name='general-action-completion' id='general-action-completion' class='needs-validation' action="#" novalidate>
					<div class="pt-1 position-relative mb-4">
						<select name="general_action_complete_by_who" id="general_action_complete_by_who" class="action-employee-select" multiple required>
						</select>
						<label for="general_action_complete_by_who"><span class='translate' data-i18n="2028" notes="Completed By"></span></label>
					</div>

					<div class="md-form">
						<input type="text" name="general_action_completed_date" id="general_action_completed_date" class="form-control datepicker" required>
						<label for="general_action_completed_date"><span class='translate' data-i18n="2001" notes="Completed Date"></span></label>
					</div>
					<div class="md-form">
						<textarea name="general_completed_action_taken" id="general_completed_action_taken" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
						<label for="general_completed_action_taken"><span class='translate' data-i18n="15" notes="Action Taken"></span></label>
					</div>
					<div class="pt-1 position-relative my-4">
						<select name="general_completed_action_type" id="general_completed_action_type" class="select-single general-actiontype-select" required>
						</select>
						<label for="general_completed_action_type"><span class='translate' data-i18n="17" notes="Action Type"></span></label>
					</div>
					<canvas id="canvas" style='display:none;'></canvas>
					<div class="form-group photoImage my-4" id="completed_general_action_images"> 
						<label class="d-block"><span class='translate' data-i18n="1413" notes="Include photos"></span></label>
						<canvas id="actioncanvas" style='display:none;'></canvas>
						<div class="btn-group d-flex" role="group">
							<div class="btn btn-block btn-outline-secondary file-field px-1">
								<i class="fa fa-upload"></i><span class='translate' data-i18n="2340" notes="Add Images">&nbsp;</span>
								<input type="file" id="generalactionpics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
							</div>
						</div>
						<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
						<div class="row photoGallery" id="generalactiongalleryid"></div>
					</div>
					<input type="hidden" name="submissionId" id="general_submissionId" value="" />
					<input type="hidden" name="general_rowid" id="general_rowid" value="" />
					<input type="hidden" name="general_id" id="general_id" value="" />
					<input type="hidden" name="general_site" id="general_site" value="" />
					<input type="hidden" name="general_sitelevel" id="general_sitelevel" value="" />
					<input type="hidden" name="general_workplace" id="general_workplace" value="" />
					<input type="hidden" name="general_action" id="general_action" value="" />
					<input type="hidden" name="general_action_contextual_date" id="general_action_contextual_date" value="" />
					<input type="hidden" name="general_reporturl" id="general_reporturl" value="" />
					<input type="hidden" name="general_Report_Distribution1" id="general_Report_Distribution1" value="" />
					<input type="hidden" name="general_datatype" id="general_datatype" value="" />
					<input type="hidden" name="formname" id="general_action_formname" value="GENERALACTIONCOMPLETE" />
					<input type="hidden" name="formtype" id="general_action_formtype" value="AC" />
					<input type="hidden" name="formid" id="general_action_formid" value="999999"/>
					<input type="hidden" name="version" id="general_action_version" value="01" />
					<input type="hidden" name="_rev" id="_general_action_rev" value="" />
					<input type="hidden" name="_id" id="_general_action_id" value="" />
					<input type="hidden" name="keyField" id="general_action_keyField" value="workplace" />
					<input type="hidden" name="gapSubmmitedBy" id="gapSubmmitedBy" value="" />					
					<input type="hidden" name="draftField" id="general_action_draftField" value="draft" />
				</form>
      		</div>
      		<div class="modal-footer text-right">
    			<div id='general_cancel_completed' class="px-1 flex-fill btn btn-outline-primary waves-effect" ><span class='translate' data-i18n="1257" notes="Cancel"></span></div>
        		<button id="general_action_completed"  class="px-1 flex-fill btn btn-primary waves-effect"><span class='translate' data-i18n="3091" notes="Mark as Complete"></span></button>
      		</div>
    	</div>
  	</div>
</div> 
<div id='viewCommentComponent'></div>
<script type="text/javascript">
const _HAZARDS = 4
const _HAZARDSBYME = 26
const _GENERALACTIONS = 28
const _GENERALACTIONSBYME = 29
const _INCIDENT = 5
const _FORMS = 1
const _HAZARDATTACHMENTSFORME = 38
const _HAZARDATTACHMENTSBYME = 39
const _GENERALATTACHMENTSFORME = 40
const _GENERALATTACHMENTSBYME = 41

let dateToday = moment(new Date(), 'YYYY-MM-DD')
let currentDate = dateToday.format('YYYY-MM-DD')
localStorage.setItem(`noinitialize`,'true')
debug = _DEBUG

form = null

let config = {
		// db name for draft storage
		draftDbName: 'sofvie_drafts',
		// Sync path for draft, false for none
		draftRemoteSync: false,
		// Committed db name
		commitDBName: _SYNCCOUCHDB,
		// Sync path for committed, false for none
		commitRemoteSync:  `${_SYNCDOMAIN}:${_SYNCPORT}/${_SYNCCOUCHDB}`
	}

window.onload = pageOrientation
window.addEventListener("orientationchange", pageOrientation)
sofvieBrowserVersion = detectBrowserVersion()

photoChangeEvent(document.getElementById('actionpics'))
photoChangeEvent(document.getElementById('generalactionpics'))

function populateActionEmployeeModalSelect(){
	let employeelist = userEmployeeSelectData
	employeeSelects = document.getElementsByClassName('action-employee-select')
		for(let a=0; a <employeeSelects.length; a++) {
			let optionData = ''
			employeelist.forEach((data)=>{
				optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
				})
				$(employeeSelects[a]).empty().append(optionData)
		}
}

// Populate the Select List for Action Type for Hazards
function populateActionActionTypeSelect() {
	let actTypelist = selectListData.ref_action_type
	actTypeSelects = document.getElementsByClassName('action-actiontype-select')
	for(let a=0; a <actTypeSelects.length; a++) {
		let optionData = ''
		actTypelist.forEach((data)=>{
			optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
			})
			$(actTypeSelects[a]).empty().append(optionData)
	}
}

function populateGeneralActionTypeSelect() {
	let genActTypelist = selectListData.ref_general_action
	genActTypeSelects = document.getElementsByClassName('general-actiontype-select')
	for(let a=0; a <genActTypeSelects.length; a++) {
		let optionData = ''
		genActTypelist.forEach((data)=>{
			optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
			})
			$(genActTypeSelects[a]).empty().append(optionData)
	}
}

async function reduceBase64(file, element, mode='parent', canvas_id = 'canvas') {
	return new Promise((resolve, reject) => {
		let fileDateStamp =  moment(file.lastModified)
		
		let removeFunction = `removeImg`
		if(mode !== 'parent') {
			removeFunction = `removeModalImg`
		}

		if(file) {
			let canvas = document.getElementById(canvas_id);
			let img = document.createElement("img");
			let reader = new FileReader();
			reader.readAsDataURL(file);
			reader.onload = function(e) {
				img.src = e.target.result

				img.onerror = function(e) {
					console.log("Image is corrupt!", file.name)
					element.target.value = null
					resolve(false)
					return
				}
				
				img.onload = function(e) {

					let ctx = canvas.getContext("2d");
					ctx.drawImage(img, 0, 0);
					let MAX_WIDTH = 1200;
					let MAX_HEIGHT = 1200;
					let width = img.width;
					let height = img.height;
					if (width > height) {
						if (width > MAX_WIDTH) {
							height *= MAX_WIDTH / width;
							width = MAX_WIDTH;
						}
					} else {
						if (height > MAX_HEIGHT) {
							width *= MAX_HEIGHT / height;
							height = MAX_HEIGHT;
						}
					}
					canvas.width = width;
					canvas.height = height;
					ctx = canvas.getContext("2d");
					ctx.drawImage(img, 0, 0, width, height);					

					// Check if the image is corrupt
					try {		
						if(ctx.getImageData(0, 0, width, height).data.every(item => item === 0)) {
							console.log("Image is corrupt!")
							element.target.value = null
							resolve(false)
							return
						}
					} 
					catch {
						console.log("Image is corrupt!")
						element.target.value = null
						resolve(false)
						return
					}
					
					
					let dataurl = canvas.toDataURL("image/jpeg");
					if(sofvieBrowserVersion === "Safari" || dataurl.length < 20){
						console.log("Failed to compress image: ",  dataurl)
						dataurl = img.src
					}

					// now Process
					let elemname = element.target.parentNode.parentNode.parentNode;
					let galleryname = elemname.querySelector('.photoGallery')
					let myphotoName = getUniqueModalPhotoName(galleryname.id, elemname.id, fileDateStamp.format('YYYY-MM-DD HH:mm:ss'))
					// now get the file name
					galleryname.innerHTML += `<div class="col-md-3 col-sm-4 col-6 mb-3 d-flex">
					<div name="${myphotoName}GALLERY" id="${myphotoName}GALLERY" class="sf-gallery__bg-image" src="${dataurl}" style="background-image: url(${dataurl})">
					<span onclick="${removeFunction}(this);" class="deleteGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-trash-alt"></i></span>
					<span onclick="addComment(this);"class="commentGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-comment"></i></span>
					<span onclick="expandImage(this);" class="displayGalleryImage btn-floating btn-sm btn-secondary"><i class="fas fa-search-plus"></i></span>
					<span class="imageDateStamp text-center font-weight-bold">${fileDateStamp.format('YYYY-MM-DD hh:mm:ss a')}</span>			
					</div></div>`

					let input = document.createElement("input");
					input.setAttribute("type", "hidden");
					input.setAttribute("name", myphotoName);
					input.setAttribute("id", myphotoName);
					input.setAttribute("value", dataurl);
					galleryname.appendChild(input);

					let commentInput = document.createElement("input");
					commentInput.setAttribute("type", "hidden");
					commentInput.setAttribute("name", myphotoName+'_comment');
					commentInput.setAttribute("id", myphotoName+'_comment');
					galleryname.appendChild(commentInput);

					element.target.value = null
					if (typeof drawSafetyTriangle !== 'undefined' && typeof drawSafetyTriangle === 'function') {
						window.dispatchEvent(new Event('resize'))
					}
					
					resolve(true)
				}
			}
		} else {
			resolve(false)
		}
	})
}

function photoChangeEvent(camera, mode='parent', canvas = 'canvas') {
	camera.addEventListener('change',(e)=>{
		$("#filespinner").removeClass('d-none')

		let allfiles = e.target.files
		let allowedFileTypes = ['image/png','image/jpeg','image/bmp','image/gif','image/webp']
		let invalidFile = false
		let imagePromises = []
		
		for(let i = 0; i < allfiles.length; i++) {
			if(allowedFileTypes.includes(allfiles[i].type)) {
				// Add reduceBase64 promise to array
				imagePromises.push(
					reduceBase64(allfiles[i],e, mode, canvas).then((result) => {
						if(!result)
							invalidFile = true
					})
				)
			}
			else {
				invalidFile = true
			}
		}

		// Wait for all images to be processed
		Promise.all(imagePromises).then(() => {
			$("#filespinner").addClass('d-none')

			if(invalidFile)
				showPictureWarning(mode)
		})

		if(imagePromises == [] && invalidFile)
		{
			$("#filespinner").addClass('d-none')					
			showPictureWarning(mode)				
		}
			
	})
}

function showPictureWarning(mode) {

	if(mode != 'parent') {
		formModal = new SofvieModal('pictureWarningModal')
		formModal.handleModal('pictureWarning')
	} else {
		formModal = new SofvieModal()
		formModal.handleModal('pictureWarning')
	}

	$('.confirmValidation').click(()=>{
		closeModal(formModal)
	})
}

function saveComment(obj, id) {
	document.getElementById(id).value = document.getElementById('image-comments').value
}

function closeModal(modal) {
	let backDrops = $(".modal-backdrop");
	if(backDrops[backDrops.length - 1]) {
		backDrops[backDrops.length - 1].remove();
	}
	modal.hideModal()
}

function addComment(comment) {
	commentId= comment.parentElement.getAttribute("name").slice(0, -7) + '_comment'
	filledComment=document.getElementById(commentId).value
	let deleteButton = ''

	if (filledComment.length > 0 ){
		deleteButton = `<a role="button" class="btn btn-primary text-nowrap waves-effect waves-light" id="deleteActionImageComment" data-dismiss="modal"><span class='translate' data-i18n="3088" notes="Delete"></span></a>`
	}
	const addCommentModal = 
	`
	<div class="modal" id="imageCaptionModal" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
		<div class="modal-dialog modal-notify modal-info" style="background-color: #0072ce;" role="document">
		<div class="modal-content">
			<div class="modal-header">
			<p class="heading lead"><span class='translate' data-i18n="8917" notes="Image Caption"></span></p>
			</div>
			
			<div class="modal-body">
				<div class="md-form">
					<textarea name="mycomments" id="mycomments" class="form-control md-textarea" length="1000" maxlength="4000" required></textarea>
					<label for="mycomments"><span class='translate' data-i18n="81" notes="Comments"></span></label>
				</div>
			</div>
		
			<div class="modal-footer justify-content-center">
			${deleteButton}
			<a role="button" class="btn btn-primary text-nowrap waves-effect waves-light" id="cancelActionImageComment" data-dismiss="modal"><span class='translate' data-i18n="1257" notes="Cancel"></span></a>
			<a role="button" class="btn btn-primary text-nowrap waves-effect waves-light" id="saveActionImageCaptionModal" data-dismiss="modal"><span class='translate' data-i18n="1258" notes="Save"></span></a>
			</div>
		</div>
		</div>
	</div>
	<div class="modal fade" id="actionImageCaptionVerificationModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
		<div class="modal-dialog modal-notify modal-danger" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<p class="heading lead"></p>
				</div>
				<div class="modal-body">
					<div class="text-center">
						<i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
						<p class='modal-body-text'></p>
					</div>
				</div>
				<div class="modal-footer justify-content-center">
				</div>
			</div>
		</div>
	</div>
	`
	$("#imageCaption")
	.empty()
	.append(addCommentModal);

	$('.translate').localize()
	$('#mycomments').val(filledComment).trigger('change').parent().find('label').addClass('filled')
	$("#imageCaptionModal").modal("show");
	$("#deleteActionImageComment").click((event) => {		
		comment_value=document.getElementById(commentId).value= document.getElementById("mycomments").value
		if(filledComment){
			comment_value=filledComment
		}
		if(comment_value){
			const theElements = {
				modalTheme: `modal-danger`,
				modalAlert: `fa-times-circle`,
				// Delete Comments
				modalTitle: i18next.t("9009"),
				//You are about to delete this comment. Are you sure?
				modalText:  i18next.t("3455"),
				modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-danger waves-effect"><span class='translate' data-i18n="1257" notes="Cancel"></a>
				<a role="button" id='deleteCommentConfirm' class="px-1 flex-fill btn btn-danger waves-effect confirm"><span class='translate' data-i18n="3088" notes="Delete"></a>`
			}
			let pop = new SofvieModal()
			pop.modalSettings.danger = theElements
			pop.handleModal('danger')
			if(filledComment){
				document.getElementById(commentId).value= document.getElementById("mycomments").value=filledComment
			}
			
			$('.translate').localize()
			$("#alertModalCancel").click(() => {
				closeModal(pop)
				$("#imageCaptionModal").modal("show");
			})
			$("#deleteCommentConfirm").click((event) => {
				comment_value=document.getElementById(commentId).value= document.getElementById("mycomments").value=''
				comment.firstChild.classList.remove("fas","far")
				comment.firstChild.classList.add("far")
				closeModal(pop)
			})
		}
		else{
			$("#imageCaptionModal").modal("hide");
		}	
	})		
			
	$("#cancelActionImageComment").click((event) => {	
		if(filledComment){
			comment_value=filledComment
			document.getElementById(commentId).value=filledComment
		}
		else{
			comment_value=document.getElementById(commentId).value= document.getElementById("mycomments").value=''
		}
		})  

	$("#mycomments").click(() => { 
		document.getElementById('mycomments').classList.remove('invalid')
	})

	$("#saveActionImageCaptionModal").click((event) => { 
		document.getElementById(commentId).value= document.getElementById("mycomments").value
		document.getElementById('mycomments').classList.remove('invalid')
		event.preventDefault(); 
		if(document.getElementById('mycomments').value == ''){
			event.preventDefault()
			event.stopImmediatePropagation();
			let formModal = new SofvieModal("actionImageCaptionVerificationModal");     
			formModal.handleModal(`validate`)  
			document.getElementById('mycomments').classList.add('invalid')
			$('.translate').localize()
			$('.confirmValidation').click(()=>{
				closeModal(formModal)
			})
		}
		else{
			comment.firstChild.classList.remove("fas","far")
			comment.firstChild.classList.add("far")
			if(document.getElementById(commentId).value){
				comment.firstChild.classList.remove("far")
				comment.firstChild.classList.add("fas")
			}	
		}			
	})

	$(document).on('hidden.bs.modal', function () {
		if($('.modal.show').length){
			$('body').addClass('modal-open');
		}
	});
}

function pageOrientation() {
	let canvas = document.getElementById("actioncanvas")
  	setTimeout(function () {
	  canvas.setAttribute("width", "480")
	  canvas.setAttribute("height", "640")
	  // Check if page orientation is landscape
	  if (window.innerWidth > window.innerHeight) {
		  canvas.setAttribute("width", "640")
		  canvas.setAttribute("height", "480")
	  }
		
	}, 1000)
}

//Trigger photo delete
function removeImg(imgWrapper) {
	delImg = new SofvieModal()
	delImg.setModalElements('danger', 'modalTitle', i18next.t("1411")) // Delete Image
	delImg.setModalElements('danger', 'modalText', i18next.t("1412")) // This action is permanent. Are you sure you want to delete this Image?
	delImg.handleModal('danger')
	$('.translate').localize()
	$(`.modal-footer .confirm`).click((e) => {
		let closestGallery = imgWrapper.closest(".photoGallery")
		imgWrapper.parentElement.parentElement.remove();
		picInput = imgWrapper.parentElement.getAttribute("name");												// Extract the name of the display image
		picInput = picInput.replace(/GALLERY+$/, '')												          // Strip off the trailing 'GALLERY' indentifier
		element = document.getElementById(picInput);												          // Get the element
		element.parentNode.removeChild(element);
		if (closestGallery.innerHTML === "" && closestGallery.closest(".photoImage").hasAttribute("required")) {
			closestGallery.closest(".photoImage").classList.add('invalid')
		}
		$(`#theModal`).modal('hide')
	})
}

function expandImage(imageInput) {
	let selectedImage = imageInput.parentElement.getAttribute("src")
	let imageTag = imageInput.parentElement.getAttribute("name").replace('GALLERY',"")
	const showPictureModal = 
	`<div class="modal fade" id="openPictureModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
		<div class="modal-dialog modal-notify modal-info m-0" role="document" style="max-width:100vw;" >
			<div class="modal-content bg-dark" style="height:100vh; overflow:hidden;">
				<div class="modal-body p-0">
					<form method="post" action="" class="camModal">
						<span id="theCanvasSpan" class="displayMainImage d-flex" style:"width:100%;"><canvas src="${selectedImage}" style="max-width:100vw; max-height:100vh" id="theCanvas" class="align-self-center"><canvas></span>
						<div class="text-center buttonArea d-flex justify-content-center position-fixed w-100" style="bottom:20px; z-index:1;">
							<div class='btn-floating btn-white' id="closeCapture"><i class="fas fa-times"></i></div>
							<div class='btn-floating btn-white' id="saveCapture"><i class="fas fa-save"></i></div>
							<div class='btn-floating btn-white' id="clearCapture"><i class="fas fa-eraser"></i></div>
						</div>

					</form>
					</div>
			</div>
		</div>
	</div>`

	$("#openPicture")
	.empty()
	.append(showPictureModal);
	$('#closeCapture').click(()=>{
		$('#openPictureModal').remove()
		$('.modal-backdrop').first().remove()
	})
	$("#openPictureModal").modal("show");

	// Markup Images //
	var canvas = document.getElementById("theCanvas");
	var ctx = canvas.getContext("2d");
	var image = new Image();
	image.src = selectedImage
	var MAX_WIDTH = 1200;
	var MAX_HEIGHT = 1200;
	var width = image.width;
	var height = image.height;
	if (width > height) {
		if (width > MAX_WIDTH) {
			height *= MAX_WIDTH / width;
			width = MAX_WIDTH;
		}
	} else {
		if (height > MAX_HEIGHT) {
			width *= MAX_HEIGHT / height;
			height = MAX_HEIGHT;
	}
	}
	canvas.width = width;
	canvas.height = height;
	var offset = $("#theCanvas").offset()
	ctx.drawImage(image, 0, 0);

	let pos = { x: 0, y: 0 };
	document.addEventListener('mousemove', draw);
	document.addEventListener('mousedown', setPosition);
	document.addEventListener('mouseenter', setPosition);

	document.addEventListener('touchmove', draw);
	document.addEventListener('touchstart', setPosition);
	document.addEventListener('touchend', setPosition);

	var factorX = canvas.width / document.documentElement.clientWidth
	factorX = factorX > 1 ? factorX : 1
	var canvasHeight = canvas.height / factorX
	var factorY =  canvasHeight / document.documentElement.clientHeight 
	// new position from mouse event
	function setPosition(e) {
			if(e.type != "touchstart" && e.type != 'touchend' && e.type != 'touchmove')
			{
				pos.x = e.clientX * factorX
				pos.y = e.clientY * factorX
			}
			else {
				pos.x = e.changedTouches[0].clientX * factorX
				pos.y = e.changedTouches[0].clientY * factorX
			}
		}

	function draw(e) {
		// mouse left button must be pressed
		if(e.type != "touchstart" && e.type != 'touchend' && e.type != 'touchmove')
			{
				if (e.buttons !== 1) return;
			}
		ctx.beginPath(); // begin
		ctx.lineWidth = 5;
		ctx.lineCap = 'round';
		//ctx.globalAlpha = 0.04;
		ctx.strokeStyle = 'red';
		ctx.moveTo(pos.x, pos.y); // from
		setPosition(e);
		ctx.lineTo(pos.x, pos.y); // to
		ctx.stroke(); // draw it!
		}

	$('#saveCapture').click(()=>{
		finalImage = canvas.toDataURL("image/jpeg")
		imageInput.parentElement.setAttribute("src", finalImage)
		imageInput.parentElement.setAttribute("style",`background-image: url(${finalImage})`)
		document.getElementsByName(imageTag)[0].value = finalImage
		$('#openPictureModal').remove()
		$('.modal-backdrop').first().remove()
		$('body').removeClass('modal-open')
	})
		
	$('#clearCapture').click(()=>{
		ctx.drawImage(image, 0, 0);
	})
	// resize canvas
	$(window).resize(function(){
		factorX = canvas.width / document.documentElement.clientWidth
		factorX = factorX > 1 ? factorX : 1
	});

	// End of Mark up Imaging //
}
	
function showImage(dataURI) {
	const showPictureModal = 
	`<div class="modal fade" id="openPictureModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
		<div class="modal-dialog modal-notify modal-info m-0" role="document" style="max-width:100vw;" >
			<div class="modal-content bg-dark" style="height:100vh; overflow:hidden;">
				<div class="modal-body p-0">
					<form method="post" action="" class="camModal">
						<span id="theCanvasSpan" class="displayMainImage d-flex" style:"width:100%;"><canvas src="${dataURI}" style="max-width:100vw; max-height:100vh" id="theCanvas" class="align-self-center"><canvas></span>
						<div class="text-center buttonArea d-flex justify-content-center position-fixed w-100" style="bottom:20px; z-index:1;">
							<div class='btn-floating btn-white' id="closeCapture"><i class="fas fa-times"></i></div>
						</div>

					</form>
					</div>
			</div>
		</div>
	</div>`

	$("#openPicture")
	.empty()
	.append(showPictureModal);
	$('#closeCapture').click(()=>{
		$('#openPictureModal').remove()
		$('.modal-backdrop').first().remove()
		$('body').removeClass('modal-open')
	})
	$("#openPictureModal").modal("show");

	// Markup Images //
	let canvas = document.getElementById("theCanvas");
	let ctx = canvas.getContext("2d");
	let image = new Image();
	image.src = dataURI
	let MAX_WIDTH = 1200;
	let MAX_HEIGHT = 1200;
	let width = image.width;
	let height = image.height;
	if (width > height) {
		if (width > MAX_WIDTH) {
			height *= MAX_WIDTH / width;
			width = MAX_WIDTH;
		}
	} else {
		if (height >= MAX_HEIGHT) {
			width *= MAX_HEIGHT / height;
			height = MAX_HEIGHT;
		}
	}
	canvas.width = width;
	canvas.height = height;
	ctx.drawImage(image, 0, 0);

	let pos = { x: 0, y: 0 };
	let factorX = canvas.width / document.documentElement.clientWidth
	let factorXPoint = canvas.width / document.documentElement.clientWidth
	factorX = factorX > 1 ? factorX : 1
	factorXPoint = factorXPoint > 1 ? factorXPoint : 1
	let canvasHeight = canvas.height / factorX
	let factorY =  canvasHeight / document.documentElement.clientHeight 
	factorY = factorY > 1 ? factorY : 1
	if(factorY > factorX && factorX == 1) {
		factorX = factorY * factorX
	}

	// resize canvas
	$(window).resize(function(){
		factorX = canvas.width / document.documentElement.clientWidth
		factorX = factorX > 1 ? factorX : 1
		factorY =  canvasHeight / document.documentElement.clientHeight 
		factorY = factorY > 1 ? factorY : 1
		if(factorY > factorX && factorX == 1) {
			factorX = factorY * factorX
		}
	})

	// End of Mark up Imaging //
}


// Main Function that populates all data onto the Actions Page.
function populatePage(remoteData)	{
	// Handle Hazards	
	let strHazard = ''
	if(remoteData[_HAZARDS].HazardActions)	{
		remoteData[_HAZARDS].HazardActions.forEach((data, index)=>{
			let byWhenDate = '9999-99-99'
			if(data.action_contextual_date){
				byWhenDate = data.action_contextual_date.substring(0,10)
			}
			let strImage=''
			let attachmentsSection = ''
			let att_data = hazardActionAttachment['for_me'] 
			strImage += `</strong></p><div class="container"><div class="row">`
			// find image.
			
			let columnCounter = 0
			att_data.forEach((att, index)=>{
				 if(att.ID == data.ID ){
					attachmentsSection = `<p><strong><span class="translate" data-i18n="1228" notes="Attachments"></span>:`
					columnCounter ++;
					
				strImage += `<div class="col">
					<span class="d-flex justify-content-center align-items-center mb-2" style="background-repeat:no-repeat;background-position:center;background-size:contain; height:160px; background-image: url(${att.data})"/>
						<div>`
				if(att.comment){
					strImage += `<i class="far fa-comment text-white" title="View Comment" onclick="showComment('${att.comment ? att.comment : ''}')"></i>`
				}
				strImage += `<i class="ml-1 fas fa-search-plus text-white" title="View Comment" onclick="showImage('${att.data}')"></i>
						</div>
					</span>
				</div>`
				}
				if(columnCounter % 3 == 0){
					strImage +=`</div><div class="row">`
				}
			})

			strImage +=`</div></div>`
			strImage = attachmentsSection + strImage
			strHazard += `<tr>
							<td class="action-wrapper ${byWhenDate < currentDate ? 'overdue':''} my-3">
								<span id="hazard${index}">
									<div onClick="rotateMe(this)">
										<a class="float-right rounded-circle badge bg-secondary" data-toggle="collapse" data-target="#ActionHaz${index}">
											<i class="fas fa-caret-down fa-fw py-1"></i>
										</a>
									</div>
									<div><strong><span class='translate' data-i18n="828" notes="Site"></span>: </strong>${data.Site}</div>
									<div><strong><span class='translate' data-i18n="621" notes="Level"></span>: </strong>${data.SiteLevel}</div>
									<div><strong><span class='translate' data-i18n="959" notes="Workplace"></span>: </strong>${data.Workplace}</div>
									<p></p>
									<div id="ActionHaz${index}" class="collapse">
										
										<p><strong><span class='translate' data-i18n="514" notes="Hazard Type"></span>: </strong>${data.hazard_type}</p>
										<p><strong><span class='translate' data-i18n="509" notes="Hazard Description"></span>: </strong>${data.hazard_description}</p>
										<p><strong><span class='translate' data-i18n="17" notes="Action Type"></span>: </strong>${data.action_type}</p>
										<p><strong><span class='translate' data-i18n="773" notes="Recommended Action"></span>: </strong>${data.action}</p>
										${strImage}
										<div class="d-flex">
											<a role="button" href="#" class="btn btn-outline-secondary btn-block idlink translate" data-i18n="3090" notes="Complete Action"
														modalSubmissionID="${data.SubmissionID}" 
														modalrowid="${data.ID}" 
														modalid="${index}" 
														modalsite="${data.Site}" 
														modalsitelevel="${data.SiteLevel}" 
														modalworkplace="${data.Workplace}" 
														modalaction="${data.action}" 
														modalaction_contextual_date="${data.action_contextual_date}" 
														modalreporturl="${data.ReportURL}" 
														modalReport_Distribution1="${data.EmailAddress}" 
														modaldatatype="hazard" 
													></a>
										</div>
										 
										<p></p>
										<span class="d-flex justify-content-between"><small><span class='translate' data-i18n="1298" notes="Created By"></span>: ${data.per_full_name}</small><small class="flex-shrink-0 pl-2"><span class='translate' data-i18n="1047" notes="Due"></span>: ${data.action_contextual_date}</small></span>
										
									</div>
								</span>
							</td>
						</tr>`
		});
	}
	$('#HazardActions').html( strHazard )

    //  HazardActionsByMe
	let strHazardByMe
	if(remoteData[_HAZARDSBYME].HazardActionsByMe)	{	
		remoteData[_HAZARDSBYME].HazardActionsByMe.forEach((data, index)=>{
		let byWhenDate = '9999-99-99'
		if(data.action_contextual_date){
			byWhenDate = data.action_contextual_date.substring(0,10)
		}
		let attachmentsSection = ''
		att_data = hazardActionAttachment['by_me'] 
		let strImage=''
		strImage +='<div class="container"><div class="row">'
		let columnCounter = 0
		att_data.forEach((att, index)=>{
			if(att.ID == data.ID ){
				attachmentsSection = `<p><strong><span id="attachmentsSection" class="translate" data-i18n="1228" notes="Attachments"></span>:`
				columnCounter ++;
				strImage += `<div class="col">
                <span class="d-flex justify-content-center align-items-center mb-2" style="background-repeat:no-repeat;background-position:center;background-size:contain; height:160px; background-image: url(${att.data})"/>
                <div>`
				if(att.comment){
					strImage += `<i class="far fa-comment text-white" title="View Comment" onclick="showComment('${att.comment ? att.comment : ''}')"></i>`
				}
				strImage += `<i class="ml-1 fas fa-search-plus text-white" title="View Comment" onclick="showImage('${att.data}')"></i>
						</div>
					</span>
				</div>`

			}
			if(columnCounter % 3 == 0){
					strImage +=`</div><div class="row">`
			}
				
		})
		strImage +=`</div></div>`
		strImage = attachmentsSection + strImage
		strHazardByMe += `<tr>
							<td class="action-wrapper ${byWhenDate < currentDate ? 'overdue':''} my-3">
								<span id="hazard${index}">
									<div onClick="rotateMe(this)">
										<a class="float-right rounded-circle badge bg-secondary" data-toggle="collapse" data-target="#ActionHazMe${index} " >
											<i class="fas fa-caret-down fa-fw py-1"></i>
										</a>
									</div>
									<div><strong><span class='translate' data-i18n="828" notes="Site"></span>: </strong>${data.Site}</div>
									<div><strong><span class='translate' data-i18n="621" notes="Level"></span>: </strong>${data.SiteLevel}</div>
									<div><strong><span class='translate' data-i18n="959" notes="Workplace"></span>: </strong>${data.Workplace}</div>
									<p></p>
									<div id="ActionHazMe${index}" class="collapse">
										<p><strong><span class='translate' data-i18n="514" notes="Hazard Type"></span>: </strong>${data.hazard_type}</p>
										<p><strong><span class='translate' data-i18n="509" notes="Hazard Description"></span>: </strong>${data.hazard_description}</p>
										<p><strong><span class='translate' data-i18n="17" notes="Action Type"></span>: </strong>${data.action_type}</p>
										<p><strong><span class='translate' data-i18n="773" notes="Recommended Action"></span>: </strong>${data.action}</p>
										${strImage}	
										<div class="d-flex">
											<a role="button" href="#" class="btn btn-outline-secondary btn-block idlink translate" data-i18n="3090" notes="Complete Action"
													modalSubmissionID="${data.SubmissionID}" 
													modalrowid="${data.ID}" 
													modalid="${index}" 
													modalsite="${data.Site}" 
													modalsitelevel="${data.SiteLevel}" 
													modalworkplace="${data.Workplace}" 
													modalaction="${data.action}" 
													modalaction_contextual_date="${data.action_contextual_date}" 
													modalreporturl="${data.ReportURL}" 
													modalReport_Distribution1="${data.EmailAddress}" 
													modaldatatype="hazardsbyme" 
													>
										</a>

									</div>
									<p></p>
									
									<span class="d-flex justify-content-between"><small><span class='translate' data-i18n="1298" notes="Created By"></span>: ${data.per_full_name}</small><small class="flex-shrink-0 pl-2"><span class='translate' data-i18n="1047" notes="Due"></span>: ${data.action_contextual_date}</small></span>
									
								</div>
							</span>
						</td>
					</tr>`
		})
	}
	$('#HazardActionsByMe').html( strHazardByMe );																			// Inject the buffer into the page

	//	General Actions Assigned to me Widget
	let strGeneralActions = '';	
	if(remoteData[_GENERALACTIONS].GeneralActions)	{// If its not null		
		remoteData[_GENERALACTIONS].GeneralActions.forEach((data, index)=>{	
			
			let byWhenDate = '9999-99-99'
			if(data.sga_action_by_when){
				byWhenDate = data.sga_action_by_when.substring(0,10)
			}
			let attachmentsSection = ''
			att_data = generalActionAttachment['for_me'] 
			let strImage=''
			strImage ='<div class="container"><div class="row">'
			
			let columnCounter = 0
			att_data.forEach((att, index)=>{

				if(att.ID == data.sga_id ){
					attachmentsSection = `<p><strong><span id="attachmentsSection" class="translate" data-i18n="1228" notes="Attachments"></span>:`
					columnCounter ++;
					strImage += `<div class="col">
					<span class="d-flex justify-content-center align-items-center mb-2" style="background-repeat:no-repeat;background-position:center;background-size:contain; height:160px; background-image: url(${att.data})"/>
						<div>`
                    if(att.comment){
                        strImage += `<i class="far fa-comment text-white" title="View Comment" onclick="showComment('${att.comment}')"></i>`
                    }
                    strImage += `<i class="ml-1 fas fa-search-plus text-white" title="View Comment" onclick="showImage('${att.data}')"></i>
                            </div>
                        </span>
                    </div>`
				}
				if(columnCounter % 3 == 0){
					strImage +=`</div><div class="row">`
				}
			})
			strImage +=`</div></div>`
			strImage = attachmentsSection + strImage
			strGeneralActions += 
							`<tr>
								<td class="action-wrapper  ${byWhenDate < currentDate ? 'overdue':''} my-3">
								<span id="General${index}">
									<div onClick="rotateMe(this)">
										<a class="float-right rounded-circle badge bg-secondary" data-toggle="collapse" data-target="#ActionGen${index}">
											<i class="fas fa-caret-down fa-fw py-1"></i>
										</a>
									</div>
									<div><strong><span class='translate' data-i18n="828" notes="Site"></span>: </strong>${data.Site}</div>
									<div><strong><span class='translate' data-i18n="621" notes="Level"></span>: </strong>${data.SiteLevel}</div>
									<div><strong><span class='translate' data-i18n="959" notes="Workplace"></span>: </strong>${data.Workplace}</div>
									<p></p>

									<div id="ActionGen${index}" class="collapse">
										<p><strong><span class='translate' data-i18n="17" notes="Action Type"></span>: </strong>${data.sga_action_type_name}</p>
										<p><strong><span class='translate' data-i18n="773" notes="Recommended Action"></span>: </strong>${data.sga_recommended_action}</p>
										${strImage}
										<div class="d-flex">
										<a role="button" href="#" class="btn btn-outline-secondary btn-block genidlink translate" data-i18n="3090" notes="Complete Action"
													modalSubmissionID="${data.SubmissionID}" 
													modalrowid="${data.sga_id}" 
													modalid="${index}" 
													modalsite="${data.Site}" 
													modalsitelevel="${data.SiteLevel}" 
													modalworkplace="${data.Workplace}" 
													modalaction="${data.sga_action_type_name}" 
													modalaction_by_when_date="${data.sga_action_by_when}" 
													modaldatatype="general_actions" 
												>
											
											</a>
										</div>
										<p></p>
										<span class="d-flex justify-content-between"><small><span class='translate' data-i18n="1298" notes="Created By"></span>: ${data.SubmittedBy}</small><small class="flex-shrink-0 pl-2"><span class='translate' data-i18n="1047" notes="Due"></span>: ${data.sga_action_by_when}</small></span>
										
									<div>
								</span>
							</td>
						</tr>`
		})
	}
	$('#GeneralActions').html( strGeneralActions );

	//	General Actions Created By Me Widget
    let strGeneralActionsByMe = '';			
	if(remoteData[_GENERALACTIONSBYME].GeneralActionsByMe)	{   // If its not null
		remoteData[_GENERALACTIONSBYME].GeneralActionsByMe.forEach((data, index)=>{	
			let byWhenDate = '9999-99-99'
			if(data.sga_action_by_when){
				byWhenDate = data.sga_action_by_when.substring(0,10)
			}
			let attachmentsSection = ''
			att_data =generalActionAttachment['by_me']
			let strImage=''

			strImage +='<div class="container"><div class="row">'
			let columnCounter = 0
			att_data.forEach((att, index)=>{

				if(att.ID == data.sga_id ){
					attachmentsSection = `<p><strong><span class="translate" data-i18n="1228" notes="Attachments"></span>:`
					columnCounter ++;
				strImage += `<div class="col">
					<span class="d-flex justify-content-center align-items-center mb-2" style="background-repeat:no-repeat;background-position:center;background-size:contain; height:160px; background-image: url(${att.data})"/>
						<div>`
				if(att.comment){
					strImage += `<i class="far fa-comment text-white" title="View Comment" onclick="showComment('${att.comment ? att.comment : ''}')"></i>`
				}
				strImage += `<i class="ml-1 fas fa-search-plus text-white" title="View Comment" onclick="showImage('${att.data}')"></i>
						</div>
					</span>
				</div>`
				}
				if(columnCounter % 3 == 0){
					strImage +=`</div><div class="row">`
				}
			})

			strImage +=`</div></div>`
			strImage = attachmentsSection + strImage
			strGeneralActionsByMe += `
								<tr>
									<td class="action-wrapper  ${byWhenDate < currentDate ? 'overdue':''} my-3">
									<span id="GeneralByMe${index}">
										<div onClick="rotateMe(this)">	
											<a class="float-right rounded-circle badge bg-secondary" data-toggle="collapse" data-target="#ActionGenMe${index}">
												<i class="fas fa-caret-down fa-fw py-1"></i>
											</a>
										</div>
										<div><strong><span class='translate' data-i18n="828" notes="Site"></span>: </strong>${data.Site}</div>
										<div><strong><span class='translate' data-i18n="621" notes="Level"></span>: </strong>${data.SiteLevel}</div>
										<div><strong><span class='translate' data-i18n="959" notes="Workplace"></span>: </strong>${data.Workplace}</div>
										<div id="ActionGenMe${index}" class="collapse">
											<p><strong><span class='translate' data-i18n="17" notes="Action Type"></span>: </strong>${data.sga_action_type_name}</p>
											<p><strong><span class='translate' data-i18n="773" notes="Recommended Action"></span>: </strong>${data.sga_recommended_action}</p>
											<p>${strImage}
										
											<div class="d-flex">
											<a role="button" href="#" class="btn btn-outline-secondary btn-block genidlink translate" data-i18n="3090" notes="Complete Action"
													modalSubmissionID="${data.SubmissionID}" 
													modalrowid="${data.sga_id}" 
													modalid="${index}" 
													modalsite="${data.Site}" 
													modalsitelevel="${data.SiteLevel}" 
													modalworkplace="${data.Workplace}" 
													modalaction="${data.sga_action_type_name}" 
													modalaction_by_when_date="${data.sga_action_by_when}" 
													modaldatatype="general_actions" 


												>
											
											</a>
										</div>
										<p></p>
										<span class="d-flex justify-content-between"><small><span class='translate' data-i18n="1298" notes="Created By"></span>: ${data.SubmittedBy}</small><small class="flex-shrink-0 pl-2"><span class='translate' data-i18n="1047" notes="Due"></span>: ${data.sga_action_by_when}</small></span>
									
									</div>
								</span>
							</td>
						</tr>`
		})
	}
	$('#GeneralActionsByMe').html( strGeneralActionsByMe )

	// Handle Incidents
	let strIncident = '';	
	let index = 0
	let incidentLink = 'idlink'
	let currentActionType = ''
	if(remoteData[_INCIDENT].IncidentActions!=null){																										// Initialize our buffer for Add			
		for(let data of remoteData[_INCIDENT].IncidentActions)	{									// If it's not null, iterate over and  append HTML/Data to our buffer
			if(data !== null)	{
				incidentLink = 'idlink'
                let currentActionType = data.action_type
				if(data.action_type === "General"){
					incidentLink = 'genidlink'
				}
				let byWhenDate = '9999-99-99'
				if(data.action_contextual_date){
					byWhenDate = data.action_contextual_date.substring(0,10)
				}
				strIncident += `
									<tr>
										<td class="action-wrapper ${byWhenDate < currentDate ? 'overdue':''} my-3">
										<span id="incident${index}">
											<div onClick="rotateMe(this)">
												<a class="float-right rounded-circle badge bg-secondary" data-toggle="collapse" data-target="#ActionInc${index}">
													<i class="fas fa-caret-down fa-fw py-1"></i>
												</a>
											</div>
											<div><strong><span class='translate' data-i18n="828" notes="Site"></span>: </strong>${data.Site}</div>
											<div><strong><span class='translate' data-i18n="621" notes="Level"></span>: </strong>${data.SiteLevel}</div>
											<div><strong><span class='translate' data-i18n="959" notes="Workplace"></span>: </strong>${data.Workplace}</div>
											<p></p>

											<div id="ActionInc${index}" class="collapse">
												<p><strong><span class='translate' data-i18n="514" notes="Hazard Type"></span>: </strong>${data.hazard_type}</p>
												<p><strong><span class='translate' data-i18n="509" notes="Hazard Description"></span>: </strong>${data.hazard_description}</p>
												<p><strong><span class='translate' data-i18n="17" notes="Action Type"></span>: </strong>${data.action_type}</p>
												<p><strong><span class='translate' data-i18n="773" notes="Recommended Action"></span>: </strong>${data.action}</p>
												<div class="d-flex">	
												<a role="button" href="#" class="btn btn-outline-secondary btn-block ${incidentLink} translate" data-i18n="3090" notes="Complete Action" 
														modalSubmissionID="${data.SubmissionID}" 
														modalrowid="${data.ID}" 
														modalid="${index}" 
														modalsite="${data.Site}" 
														modalsitelevel="${data.SiteLevel}" 
														modalworkplace="${data.Workplace}" 
														modalaction="${data.action}" 
														modalaction_contextual_date="${data.action_contextual_date}" 
														modalreporturl="${data.ReportURL}" 
														modalReport_Distribution1="${data.EmailAddress}" 
														modaldatatype="incident" 
														>
													</a>
												</div>
												<p></p>
												<span class="d-flex justify-content-between"><small><span class='translate' data-i18n="1298" notes="Created By"></span>: ${data.created_by}</small><small class="flex-shrink-0 pl-2"><span class='translate' data-i18n="1047" notes="Due"></span>: ${data.action_contextual_date}</small></span>
											</div>
										</span>
									</td>
								</tr>`
			} 
			index++
		}
	}
	$('#IncidentActions').html( strIncident )

    // Event for Opening the Modal for Closing Hazard and Incident Actions	
	Array.from(document.getElementsByClassName('idlink')).forEach((data) =>{		// Iterate over our data  (this is bad, if 'idlink' is used in another spot on the page, for instance, another modal, this code will introduce errors
		data.addEventListener('click',(event) => {	
            // Add a click handler to our data
			form = document.forms['action-completion']
			let populateActionModal = new Promise ((resolve, reject)=>{
				document.getElementById('rowid').value = event.target.getAttribute('modalrowid')
				document.getElementById('submissionId').value = event.target.getAttribute('modalSubmissionID')
				document.getElementById('id').value = event.target.getAttribute('modalid')
				document.getElementById('site').value = event.target.getAttribute('modalsite')
				document.getElementById('sitelevel').value = event.target.getAttribute('modalsitelevel')
				document.getElementById('workplace').value = event.target.getAttribute('modalworkplace')
				document.getElementById('action').value = event.target.getAttribute('modalaction')
				document.getElementById('action_contextual_date').value = event.target.getAttribute('modalaction_contextual_date')
				document.getElementById('reporturl').value = event.target.getAttribute('modalreporturl')
				document.getElementById('Report_Distribution1').value = event.target.getAttribute('modalReport_Distribution1')
				document.getElementById('datatype').value = event.target.getAttribute('modaldatatype')
				if(document.getElementById('datatype').value) {
					resolve("done")
				}
			})
			populateActionModal.then((data) => {
				$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])

				//This is to hack/fix a glitch with pickadate not displaying the month/year fields correctly
				$('.picker__header').find('[dir="ltr"]').remove()
				$('.picker__header').find('.select2-hidden-accessible').removeClass('select2-hidden-accessible')

				$('#action_completed_date').val("").removeAttr('readonly')	// Alow validation
				if(localStorage.getItem('assignmultiuser')!='true') {
					$('#action_complete_by_who').removeAttr('multiple')	
					$("#action_complete_by_who").addClass("select-single")
				}
				$('#ActionCompletionModal').modal('show')															// Show the modal
				$('#ActionCompletionModal').show()
		   })
		})
	})

	// Event for Opening the Modal for Closing General Actions
	Array.from(document.getElementsByClassName('genidlink')).forEach((data) =>{		
		data.addEventListener('click',(event) => {	
			form = document.forms['general-action-completion']
			let populateActionModal = new Promise ((resolve, reject)=>{
				document.getElementById('general_rowid').value = event.target.getAttribute('modalrowid')
				document.getElementById('general_submissionId').value = event.target.getAttribute('modalSubmissionID')
				document.getElementById('general_id').value = event.target.getAttribute('modalid')
				document.getElementById('general_site').value = event.target.getAttribute('modalsite')
				document.getElementById('general_sitelevel').value = event.target.getAttribute('modalsitelevel')
				document.getElementById('general_workplace').value = event.target.getAttribute('modalworkplace')
				document.getElementById('general_action').value = event.target.getAttribute('modalaction')
				document.getElementById('general_action_contextual_date').value = event.target.getAttribute('modalaction_contextual_date')
				document.getElementById('general_reporturl').value = event.target.getAttribute('modalreporturl')
				document.getElementById('general_Report_Distribution1').value = event.target.getAttribute('modalReport_Distribution1')
				document.getElementById('general_datatype').value = event.target.getAttribute('modaldatatype')
				if(document.getElementById('general_datatype').value) {
					resolve("done")
				}
			})
			populateActionModal.then((data) => {
				$.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
				
				//This is to hack/fix a glitch with pickadate not displaying the month/year fields correctly
				$('.picker__header').find('[dir="ltr"]').remove()
				$('.picker__header').find('.select2-hidden-accessible').removeClass('select2-hidden-accessible')		

				$('#general_action_completed_date').val("").removeAttr('readonly')	// Alow validation
				if(localStorage.getItem('assignmultiuser')!='true') {
					$('#general_action_complete_by_who').removeAttr('multiple')	
					$("#general_action_complete_by_who").addClass("select-single")
				}					
				$('#GeneralActionCompletionModal').modal('show')	// Show the modal

		   	})
		})
	})
}
function showComment(comment){

	showViewCommentsModal(3915)
	let viewCommentsContent = document.getElementById("viewCommentsContent")
    viewCommentsContent.innerHTML = comment

}
function rotateMe(e){
	let ele = e.children[0].children[0]
	if(ele.classList.contains("fa-caret-down")){
		ele.classList.remove("fa-caret-down") 
		ele.classList.add("fa-caret-up")
	} else {
		ele.classList.remove("fa-caret-up") 
		ele.classList.add("fa-caret-down")
	}
}

// Function to Open the Modal for Completing Hazards
document.getElementById('completed').addEventListener("click", (e) => {
	form = document.forms['action-completion']
	// And a hook to form submission.
	e.preventDefault()
	let Validity = invalidContentValidation(form)
	if (Validity === false) {
		event.preventDefault();
		event.stopImmediatePropagation()
		//initialize the Modal 
		let formModal = new SofvieModal()
		if(form.classList.contains('invalid-content'))
			formModal.handleModal(`invalidContent`)
		else 
			formModal.handleModal(`validate`)  

		$('.translate').localize()
		$('.confirmValidation').click(()=>{
			closeModal(formModal)
		})
  	}
  	else {
		// Handle any post processing to the form component
		// Convert the form submission to JSON
		let json = toJSONString(form)
		// Create a ref to the local DB
		db = new PouchDB(config.commitDBName, {  })
		// sync to it.
		sync(db, config.commitRemoteSync)
		// Then save the JSON to our localDB 
		addForm(db, json, form.submissionId.value + '-' + Math.floor(Date.now() / 1000), form)
  	}
  	form.classList.add("was-validated")
}, false)

// Function to Open the Modal for Completing General Actions
document.getElementById('general_action_completed').addEventListener("click", (e) => {
	form = document.forms['general-action-completion']
	e.preventDefault(); 
	let Validity = invalidContentValidation(form)
	if (Validity === false) {
		event.preventDefault()
		event.stopImmediatePropagation()
		let formModal = new SofvieModal()
		if(form.classList.contains('invalid-content'))
			formModal.handleModal(`invalidContent`)
		else 
			formModal.handleModal(`validate`)
		$('.translate').localize()
		$('.confirmValidation').click(()=>{
			closeModal(formModal)
		})
  	}
  	else {
		// Handle any post processing to the form component
		// Convert the form submission to JSON
		let json = toJSONString(form)
		// Create a ref to the local DB
		db = new PouchDB(config.commitDBName, {  })
		// sync to it.
		sync(db, config.commitRemoteSync)
		// Then save the JSON to our localDB
		addGeneralActionForm(db, json, form.general_submissionId.value + '-' + Math.floor(Date.now() / 1000), form)
  	}
  	form.classList.add("was-validated")
}, false)

// Function to close the HazardCompletion Modal on Cancel of Confirmation Modal
document.getElementById('cancel_completed').addEventListener('click',()=>{
	const theElements = {
		modalTheme: `modal-danger`,
		modalAlert: `fa-times-circle`,
		// Cancel Draft
		modalTitle: i18next.t("1410"),
		//This action is permanent. Are you sure you want to proceed?
		modalText: i18next.t("1409"),
		modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-danger waves-effect"><span class='translate' data-i18n="1257" notes="Cancel"></a>
		<a role="button" id='cancelDraftConfirm' class="px-1 flex-fill btn btn-danger waves-effect confirm"><span class='translate' data-i18n="1379" notes="Yes"></a>`
	}
	let pop = new SofvieModal()
	pop.modalSettings.danger = theElements
	pop.handleModal('danger')
	$('.translate').localize()
	document.getElementById('cancelDraftConfirm').addEventListener('click',()=>{
		clearModal() 
	})
	$("#alertModalCancel").click(() => {
		pop.hideModal()
	})
})

// Function to close the General Action Completion Modal on Cancel of Confirmation Modal
document.getElementById('general_cancel_completed').addEventListener('click',()=>{
	const theElements = {
		modalTheme: `modal-danger`,
		modalAlert: `fa-times-circle`,
		modalTitle: i18next.t("1410"),  // Cancel Draft
		modalText: i18next.t("1409"),   // This action is permanent. Are you sure you want to proceed? 
		modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-danger waves-effect"><span class='translate' data-i18n="1257" notes="Cancel"></a>
		<a role="button" id='cancelDraftConfirm' class="px-1 flex-fill btn btn-danger waves-effect confirm"><span class='translate' data-i18n="1379" notes="Yes"></a>`
	  // Cancel (1257) and OK (1379) Buttons
	}
	let pop = new SofvieModal()
	pop.modalSettings.danger = theElements
	pop.handleModal('danger')
	$('.translate').localize()
	document.getElementById('cancelDraftConfirm').addEventListener('click',()=>{
		clearModal() 
	})
	$("#alertModalCancel").click(() => {
		pop.hideModal();
	})
})

//Takes the form elements for Hazards and turns them into key value pairs
function toJSONString(form) {			                                                  
	let obj = {}	
	let elements = form.querySelectorAll("input, select, textarea")	
	for (let i = 0; i < elements.length; ++i) {	
		let element = elements[i]
		let name = element.name
		let value = element.value
		if (name) {
			if (!obj[name]) {
				if (element.matches('[type="radio"]')) {
					if (element.checked) {
						obj[name] = element.value
					}
				} else if (element.tagName == 'SELECT') {
					obj[name] = getSelectValues(element)
				} else {
					obj[name] = element.value
				}
			}
		}
	}
	return JSON.stringify(obj)
}

// Function to parse the Select Values from Pull Downs
function getSelectValues(select) {
	let result = []
	let options = select && select.options
	let opt
	for (let i = 0, iLen = options.length; i < iLen; i++) {
		opt = options[i]
		if (opt.selected) {
			result.push(opt.value || opt.text)
		}
	}
	return result.join('|')
}

// Main function for Submitting the Action Items
function addForm(db, text, pouchid, form) {
	formObjectJSON = JSON.parse(text)
	db.get(pouchid).then(function (doc) {
		console.error('addForm: Commit Found ID: ' + pouchid)
		alert('You cannot save this form. This id already exists\r\nID = ' + pouchid)
		return
	}).catch(function (err) {
		// Everything is fine, proceed.
	})

	if(debug) console.log('formObjectJSON:')
	if(debug) console.dir(formObjectJSON)
	actionCompleteModal = new SofvieModal()
	actionCompleteModal.setModalElements('warning', `modalButtons`, `<a role="button" class="btn btn-outline-warning waves-effect cancel px-1 flex-fill"><span class='translate' data-i18n="1257" notes="Cancel"></a>
                                     <a role="button" class="btn btn-warning waves-effect confirm px-1 flex-fill"><span class='translate' data-i18n="1379" notes="Yes"></a>`)
	actionCompleteModal.handleModal('warning')
	$('.translate').localize()

	$(`.modal-footer .cancel`).click(() => {  
		actionCompleteModal.hideModal() 
		$('.modal-backdrop').first().remove()
	})

	$(`.modal-footer .confirm`).click(() => {  
		let actionType = form.datatype.value 
		if(actionType){
			db.put({
				_id: pouchid// Update it
				// and the data
				,formdata: formObjectJSON
				//Timestamp this record to allow for easy deletion.
				,timestamp: +new Date
				}).then(function (response) {
					let datapointer = { 
						"hazard": remoteData[_HAZARDS].HazardActions, 
						"hazardsbyme": remoteData[_HAZARDSBYME].HazardActionsByMe, 
						"incident": remoteData[_INCIDENT].IncidentActions 
					};
					if(actionType === 'hazard' || actionType === 'hazardsbyme'){
						try {
							remoteData[_HAZARDS].HazardActions.splice(formObjectJSON.id, 1)
						}
						catch(err){
						}

						try {
							remoteData[_HAZARDSBYME].HazardActionsByMe.splice(formObjectJSON.id, 1)
						}
						catch(err){
						}

					} 
					else {
						try {
							ptr = datapointer[actionType]
							ptr.splice(formObjectJSON.id, 1)
							
						} catch(err) {
						console.log(err)
						}
					}
					storeActionCacheData().then(()=>{ 
						let el = document.getElementById(form.datatype.value + formObjectJSON.id)
						$('#ActionCompletionModal').modal('hide')
						actionCompleteModal.hideModal()
						clearModal()
					})
				}).catch(function (err) {
					console.warning('AddForm: Error Committing Data: ' + err)
				})
		}
		else {
			console.error("The Data did not LOAD from the ELEMENTS")
		}
	})
}

function addGeneralActionForm(db, text, pouchid, form) {
	formObjectJSON = JSON.parse(text)
	db.get(pouchid).then(function (doc) {
		console.error('addForm: Commit Found ID: ' + pouchid)
		alert('You cannot save this form. This id already exists\r\nID = ' + pouchid)
		return
	}).catch(function (err) {
		// Everything is fine, proceed.
		if(debug) console.log('formObjectJSON:')
		if(debug) console.dir(formObjectJSON)
		actionCompleteModal = new SofvieModal()
		actionCompleteModal.setModalElements('warning', `modalButtons`, `<a role="button" class="btn btn-outline-warning waves-effect cancel px-1 flex-fill"><span class='translate' data-i18n="1257" notes="Cancel"></a>
			<a role="button" class="btn btn-warning waves-effect confirm px-1 flex-fill"><span class='translate' data-i18n="1379" notes="Yes"></a>`)
		actionCompleteModal.handleModal('warning')
		$('.translate').localize()

		$(`.modal-footer .cancel`).click(() => {
			actionCompleteModal.hideModal() 
			$('.modal-backdrop').first().remove()
		})

		$(`.modal-footer .confirm`).click(() => {  
			let actionType = form.general_datatype.value 
			if(actionType){
				db.put({
					_id: pouchid																															// Update it
					,formdata: formObjectJSON																									// and the data
					,timestamp: +new Date																											// SJB: 20190826 - Timestamp this record to allow for easy deletion.
					}).then(function (response) {
						let datapointer = { 
							"general_action": remoteData[_GENERALACTIONS].GeneralActions, 
							"general_action_by_me": remoteData[_GENERALACTIONSBYME].GeneralActionsByMe, 
							"incident": remoteData[_INCIDENT].IncidentActions 
						}
						if(actionType === 'general_actions' || actionType === 'general_actions_by_me'){
							try {
								remoteData[_GENERALACTIONS].GeneralActions.splice(formObjectJSON.general_id, 1)
							}
							catch(err){
							}

							try {
								remoteData[_GENERALACTIONSBYME].GeneralActionsByMe.splice(formObjectJSON.general_id, 1)
							}
							catch(err){
							}

						} 
						else {
							try {
								ptr = datapointer[actionType]
								ptr.splice(formObjectJSON.general_id, 1)
								
							} catch(err) {
							console.log(err)
							}
						}
						storeActionCacheData().then(()=>{
							$('#ActionCompletionModal').modal('hide')
							actionCompleteModal.hideModal()
							clearModal()
						})
					}).catch(function (err) {
						console.log('AddForm: Error Committing Data: ' + err)
					})
			}
			else {
				console.error("The Data did not LOAD from the ELEMENTS")
			}
		})
	})
}

// Sync Function for Replicating to Couch
function sync(db, syncTo) {
	checkOnline().then((status)=>{
	  if (syncTo && status) {
			let opts = { live: true, retry: true }	
			db.replicate.to(syncTo, opts)
				.then(function (response) {
					console.log('Replicating To: ' + syncTo)
				}).catch(function (err) {
					console.error('Error replicating to : ' + syncTo + ' : ' + err)
				})
		} 
		else {
			if (debug) console.log('Nothing to sync to');
		}	  
	}).catch((err)=>{
		console.warn('Browser offline, not replicating');
	  })
}

// Clear the Modal
function clearModal() {
	 window.open(`${window.location.origin}${window.location.pathname}`, "_self");
}

function spinnerEvent(spinner) {
	spinner.addEventListener('click',(e)=>{
		$("#filespinner").removeClass('d-none')
		cancelFileTimer()
	})
}

function cancelFileTimer() {
	cancelTimer = setInterval(()=>{
		if(document.activeElement.name  === 'myFile')
		{
			if(document.hasFocus() == true ) {
				setTimeout(()=>{
					document.getElementById('filespinner').classList.add('d-none')
					clearInterval(cancelTimer)
				  },500)
			}
		}
	},1000)
}

// create a unique photoname 
function getUniqueModalPhotoName(galleryName, photoElemName,fileDateStamp)	{
	let i = 1
	let photoName = `${fileDateStamp}${form.formtype.value}.${galleryName}.|${photoElemName}|${i}|`
	if (document.getElementById(photoName)) {
		i++
		photoName = `${fileDateStamp}.${galleryName}.|${photoElemName}|${i}|`
		while(document.getElementById(photoName))
		{
			photoName = `${fileDateStamp}.${galleryName}.|${photoElemName}|${i}|`
			i++
		}
	}
	else {
		return photoName
	}
	return photoName	
}

// Sleep Function
function sleep(milliseconds) {
	const date = Date.now()
	let currentDate = null
	do {
	  currentDate = Date.now()
	} while (currentDate - date < milliseconds)
}

document.addEventListener("DOMContentLoaded", function(){
	openCacheData().then((rdata)=>{
		openSelectCacheData().then(()=>{
			populatePage(remoteData)
			populateActionEmployeeModalSelect()
			populateActionActionTypeSelect()
			populateGeneralActionTypeSelect()

			localStorage.removeItem(`noinitialize`)

			initializeDataTables()
			initializePickadate()
			initializeSelect2()

			initializeI18N()
			document.getElementById('hapSubmmitedBy').value = remoteData[2].Employee[0].per_id
			document.getElementById('gapSubmmitedBy').value = remoteData[2].Employee[0].per_id
			$("#footerSpinner").addClass('d-none')
		})
	})
})

function getMobileOperatingSystem() {
    var userAgent = navigator.userAgent || navigator.vendor || window.opera;

    // Windows Phone must come first because its UA also contains "Android"
    if (/windows phone/i.test(userAgent)) {
        return "Windows Phone";
    }

    if (/android/i.test(userAgent)) {
        return "Android";
    }

    // iOS detection from: http://stackoverflow.com/a/9039885/177710
    if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
        return "iOS";
    }

    return "unknown";
}

function detectBrowserVersion() {
	var navUserAgent = navigator.userAgent
	var browserName  = navigator.appName
	var browserVersion  = ''+parseFloat(navigator.appVersion)
	var majorVersion = parseInt(navigator.appVersion,10)
	var tempNameOffset,tempVersionOffset,tempVersion
	
	if ((tempVersionOffset=navUserAgent.indexOf("Opera"))!=-1) {
		browserName = "Opera"
		browserVersion = navUserAgent.substring(tempVersionOffset+6)
	if ((tempVersionOffset=navUserAgent.indexOf("Version"))!=-1) 
		browserVersion = navUserAgent.substring(tempVersionOffset+8)
	} else if ((tempVersionOffset=navUserAgent.indexOf("MSIE"))!=-1) {
		browserName = "Microsoft Internet Explorer"
		browserVersion = navUserAgent.substring(tempVersionOffset+5)
	} else if ((tempVersionOffset=navUserAgent.indexOf("Chrome"))!=-1) {
		browserName = "Chrome"
		browserVersion = navUserAgent.substring(tempVersionOffset+7)
	} else if ((tempVersionOffset=navUserAgent.indexOf("Safari"))!=-1) {
		browserName = "Safari"
		browserVersion = navUserAgent.substring(tempVersionOffset+7)
	if ((tempVersionOffset=navUserAgent.indexOf("Version"))!=-1) 
		browserVersion = navUserAgent.substring(tempVersionOffset+8)
	} else if ((tempVersionOffset=navUserAgent.indexOf("Firefox"))!=-1) {
		browserName = "Firefox"
		browserVersion = navUserAgent.substring(tempVersionOffset+8)
	} else if ((tempNameOffset=navUserAgent.lastIndexOf(' ')+1) < (tempVersionOffset=navUserAgent.lastIndexOf('/')) ) {
		browserName = navUserAgent.substring(tempNameOffset,tempVersionOffset)
		browserVersion = navUserAgent.substring(tempVersionOffset+1)
		if (browserName.toLowerCase()==browserName.toUpperCase()) {
			browserName = navigator.appName
		}
	}
	
	// trim version
	if ((tempVersion=browserVersion.indexOf(";"))!=-1)
		browserVersion=browserVersion.substring(0,tempVersion)
	if ((tempVersion=browserVersion.indexOf(" "))!=-1)
		browserVersion=browserVersion.substring(0,tempVersion)
	return browserName
}

function actionCachePromise() {
  return new Promise((resolve) => {
	caches.open('SofvieCache').then((res)=>{
		var init = { "status" : 200 , "statusText" : "SuperSmashingGreat!" };
		var myResponse = new Response(JSON.stringify(remoteData));
		res.put('<?php echo _DOMAIN ?>/ajax/getRemoteData.php', myResponse).then(()=>{
			resolve(true)
		})
	})
  })


}

async function storeActionCacheData() {
	await actionCachePromise()
}

</script>


<?php include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>

<script src="/modals/viewCommentsModal.js"></script>