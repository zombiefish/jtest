<?php
header('Content-Type: application/json');
header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$selectedLanguage = 'en';
if (isset($_GET['lang'])) {
	$selectedLanguage = $_GET['lang'];
} else if (isset($_COOKIE['lang'])) {
	$selectedLanguage = $_COOKIE['lang'];
}

$auth = "";
$fromApp = 0;
if (isset($_GET['auth'])) {
	$auth = $_GET['auth'];
} else if (isset($_COOKIE['access'])) {
	$auth = $_COOKIE['access'];
}

if (isset($_GET['app'])) {
	$fromApp = 1;
}

// RMR: 2020-03-20 - REMOTE Data pull for offline aspects
	require_once __DIR__.'../../vendor/autoload.php';// Pull in our packages
	$strRuntimeEnvironmentFileName = 'mobile.env';	// Look up env filename for this runtime mode
	if(!$strRuntimeEnvironmentFileName)	{
		echo 'Error resolving environment file from ' . $sofvieRunTimeEnvironment . ' environment variable.';
		die(-1);
	}
 // Open or environment file (outside of root for security)
	$dotenv = Dotenv\Dotenv::create(__DIR__ . '/../../', $strRuntimeEnvironmentFileName);	// Retrieve the .env for this runtime
	$dotenv->load();  // Apply data to our env vars.

	 include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/sofvie_config.php");
	 include_once(_DOCUMENT_ROOT . _APP_DIR . "/classes/database.php");

$formDefinitions =[];
$targetsSupervisor = [];
$targetsItem = [];
$targets = [];
$targetsJSON = [];
$Employee = [];
$EmployeeList = [];
$ViewPointEmployee = [];
$DocumentPDF = [];
$Training = [];
$Reviews = [];
$row = [];
$HazardActions = [];
$HazardActionsByMe = [];
$HazardTrend = [];
$PositiveID = [];
$IncidentTrend = [];
$IncidentTrendType = [];
$Certifications = [];
$Disciplines = [];
$PositiveRecognition = [];
$HazardTrendSite = [];
$IncidentTrendSite = [];
$PositiveRecognitionTrendType = [];
$PreOpEquipQuestionLookup = [];
$PreOpEquipment  = [];
$PreOpQuestions = [];
$PreOpEquipmentList = [];
$PositiveRecognitionTrendSite =  [];
$formAccess = [];
$IncidentActions = [];
$DocumentReview = [];
$GeneralActions  = [];
$GeneralActionsByMe = [];
$UsefulLinks = [];
$UserSettingsProfile = [];
$UserAddonModulePermission = [];
$UserMultiActionPermission = [];
$EquipmentMeasureData = [];
$FormBuilderCategories = [];
$CustomForms = [];
$PreOpEquipSiteJob = [];
$DrillingCalculation = []; 
$CustomFormItems = [];
$ErrorsInRemoteData = [];
$FormFieldVisibility = null;
$completedTargets = [];

// Function to get the DB error messages in Remote data if debug flag is ON
function errorMessage($e){
	if(_DEBUG or $DEBUG){
		array_push($GLOBALS["ErrorsInRemoteData"],$e);
	}
}

// Create DB Connection
$Database = new DBManager();
$Database->dbConnect(_DB_READ_MODE);

// Get the Employee Profile
try{
	$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_person_profile_mobile(:userId, :language)");
    $stmt->bindValue(':userId', $_COOKIE['userid']);
	$stmt->bindValue(':language', $selectedLanguage);
	$stmt->execute();
	$row = $stmt->fetch(PDO::FETCH_ASSOC);
	$Employee[] = $row;

}
catch (PDOException $e) {
	errorMessage($e);
}

// Get the Supervisor Targets
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_supervisor_targets_by_per_id(:per_id)");
		$stmt->bindValue(':per_id', $Employee[0]['per_id']);
		$stmt->execute();
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$targetsSupervisor[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}


// Form Definitions
try{
	$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_mobile_forms(:language)");
	$stmt->bindValue(':language', $selectedLanguage);
	$stmt->execute();		
	while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
		$formDefinitions[$row['FormID']] = $row;
	}
}
catch (PDOException $e) {
	errorMessage($e);
}

// Get useful links.
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_useful_links()");
		$stmt->execute();
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$UsefulLinks[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}



// TRAINING
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_employee_training_records(:userid, :language)");					
		$stmt->bindValue(':userid', $Employee[0]['per_id']);
		$stmt->bindValue(':language', $selectedLanguage);
		$stmt->execute();
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$Training[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

// Certifications
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_employee_certification_records(:userid, :language)");					
		$stmt->bindValue(':userid', $Employee[0]['per_id']);
		$stmt->bindValue(':language', $selectedLanguage);
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$Certifications[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

// Reviews
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_review_list_by_employee_id(:userid)");
		$stmt->bindValue(':userid', $Employee[0]['per_id']);		//$userID->userid
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$Reviews[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}


// HAZARD ACTIONS
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_hazard_actions_by_employee_id(:bywho, :language)" );					
		$stmt->bindValue(':bywho', $Employee[0]['per_id']);
		$stmt->bindValue(':language', $selectedLanguage);
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$HazardActions[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

// HAZARD ACTIONS BY ME
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_hazard_actions_by_me_employee_id(:bywho, :language)" );					
		$stmt->bindValue(':bywho', $Employee[0]['per_id']);
		$stmt->bindValue(':language', $selectedLanguage);
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$HazardActionsByMe[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

//GENERAL ACTIONS
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_general_actions_by_who_by_id(:bywho, :language)" );					
		$stmt->bindValue(':bywho', $Employee[0]['per_id']);
		$stmt->bindValue(':language', $selectedLanguage);
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$GeneralActions[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

// GENERAL ACTIONS BY ME
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_general_actions_by_created_by_id(:bywho, :language)" );					
		$stmt->bindValue(':bywho', $Employee[0]['per_id']);
		$stmt->bindValue(':language', $selectedLanguage);
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$GeneralActionsByMe[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

// DISCIPLINES
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_disciplines_by_employee_id(:userid)" );					
		$stmt->bindValue(':userid', $Employee[0]['per_id']);
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$Disciplines[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

// INCIDENT ACTIONS
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_incident_actions_by_employee_id(:bywho, :language)" );
		$stmt->bindValue(':bywho', $Employee[0]['per_id']);
		$stmt->bindValue(':language', $selectedLanguage);
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$IncidentActions[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

// Hazards TREND TYPE
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_hazard_type_totals(:language)");	
		$stmt->bindValue(':language', $selectedLanguage);					
		$stmt->execute();	
		$HazardTrendType =[];																									
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$HazardTrendType[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

// HAZARD TREND SITE
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_hazards_by_site(:language)");
		$stmt->bindValue(':language', $selectedLanguage);					
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$HazardTrendSite[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

// Incident TREND Type
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_incidents_by_incident_type(:language)");	
		$stmt->bindValue(':language', $selectedLanguage);				
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$IncidentTrendType[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

if(!$fromApp) {
// Incident TREND Site
	try{
		$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_incidents_by_site(:language)");	
		$stmt->bindValue(':language', $selectedLanguage);					
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$IncidentTrendSite[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}
	
// Positive Recognition TREND Type
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_positive_recognition_by_recognition_type(:language)");					
		$stmt->bindValue(':language', $selectedLanguage);
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$PositiveRecognitionTrendType[] = $row;
		}
	}
		catch (PDOException $e) {
		errorMessage($e);
	}
}

// Positive Recognition TREND Site
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_positive_recognition_by_site(:language)");					
		$stmt->bindValue(':language', $selectedLanguage);	
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$PositiveRecognitionTrendSite[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}
	

// FORM ACCESSS
try{
	$url = _API_URL . "/api/formnavigation/get-list-mobile-form-category/";
	$curl = curl_init();
	
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_HTTPGET, TRUE);
	curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json', "Authorization: Bearer " . $auth));
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true );
	
	$formAccess = json_decode(curl_exec($curl));
	
	curl_close($curl);
}
catch (PDOException $e) {
    errorMessage($e);
}

// POSITIVE RECOGNITION
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_positive_recognition_by_employee_id(:personid, :language)" );					
		$stmt->bindValue(':personid', $Employee[0]['per_id']);
		$stmt->bindValue(':language', $selectedLanguage);
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$PositiveRecognition[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

//Pre-op Equipment with Site and job
try{
	$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_all_site_job_equipment_list(:language)");
	$stmt->bindValue(':language', $selectedLanguage);
	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
		$PreOpEquipSiteJob[] = $row;
	}
}
catch (PDOException $e) {
	errorMessage($e);
}

//Pre-op Equipment Question Lookup
try{
	$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_preop_equip_question_lookup(:language)");
	$stmt->bindValue(':language', $selectedLanguage);
	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
		$PreOpEquipQuestionLookup[] = $row;
	}
}
catch (PDOException $e) {
	errorMessage($e);
}

// Pre-op Equipment 
try{
	$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_preop_equipment_list(:language, :active)");
	$stmt->bindValue(':language', $selectedLanguage);
	$stmt->bindValue(':active', 'active');
	$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$PreOpEquipment[] = $row;
		}
	}
catch (PDOException $e) {
	errorMessage($e);
}

// // Pre-op Questions
try{
	$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_preop_questions(:language)");
	$stmt->bindValue(':language', $selectedLanguage);
	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
		$PreOpQuestions[] = $row;
	}
}
catch (PDOException $e) {
	errorMessage($e);
}

// Pre-op Equipment List
try{
	$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_preop_equip_question_lookup_distinct()");					
	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
		$PreOpEquipmentList[] = $row;
	}
}	
catch (PDOException $e) {
	errorMessage($e);
}

// DOCUMENT REVIEW
if(!$fromApp) {
	try{
		$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_user_documents_by_per_id(:personid, :language)" );					
		$stmt->bindValue(':personid', $Employee[0]['per_id']);
		$stmt->bindValue(':language', $selectedLanguage);
		$stmt->execute();																												
		while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
			$DocumentReview[] = $row;
		}
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

//USER SETTINGS PROFILE
try{
	$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_user_profile_mobile(:personid, :language)");
	$stmt->bindValue(':personid', $Employee[0]['per_id']);
	$stmt->bindValue(':language', $selectedLanguage);
	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
		$UserSettingsProfile[] = $row;
	}
}
catch (PDOException $e) {
	errorMessage($e);
}

//USER ADD-ON MODULE PERMISSIONS
try{
	$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_addon_modules_permissions(:personid)");
	$stmt->bindValue(':personid', $Employee[0]['per_id']);
	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
		$UserAddonModulePermission[] = $row;
	}
}
catch (PDOException $e) {
	errorMessage($e);
}

//EQUIPMENT MEASURE DATA.
try{
	$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_equipment_measure_data(:language)");
	$stmt->bindValue(':language', $selectedLanguage);
	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
		$EquipmentMeasureData[] = $row;
	}
}
catch (PDOException $e) {
	errorMessage($e);
}

// Get the List of form builder Categories
try{
	$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_form_builder_categories(:language)");
	$stmt->bindValue(':language', $selectedLanguage);
	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		$FormBuilderCategories[] = $row;
	}
}  
catch (PDOException $e) {
    errorMessage($e);
}

// Get the List of custom forms
try{
	$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_all_custom_forms(:language, :personid)");
	$stmt->bindValue(':language', $selectedLanguage);
	$stmt->bindValue(':personid', $Employee[0]['per_id']);

	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		$CustomForms[] = $row;
	}
}  
catch (PDOException $e) {
    errorMessage($e);
}

// Get the List of form Builder Items
try{
	$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_custom_form_items(:language)");
	$stmt->bindValue(':language', $selectedLanguage);
	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		$CustomFormItems[] = $row;
	}
}  
catch (PDOException $e) {
    errorMessage($e);
}

// get drilling calculation reflist
try{
	$stmt = $Database->connection->prepare("CALL " . _DB_READ_NAME . "." . "get_all_reflist_drilling_calculation_values()" );		
	$stmt->execute();																												
	while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
		$DrillingCalculation[] = $row;
	}
}
catch (PDOException $e) {
	errorMessage($e);
}

//USER Assign Actions to Multi Persons PERMISSIONS
try{
	$stmt = $Database->connection->prepare("call " . _DB_READ_NAME . "." . "get_multi_action_permissions(:personid)");
	$stmt->bindValue(':personid', $Employee[0]['per_id']);
	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC))	{
		$UserMultiActionPermission[] = $row;
	}
}
catch (PDOException $e) {
	errorMessage($e);
}

// Get Form Field Visibility List
try{
	$url = _API_URL . "/api/form-management/get-form-field-filter/";
	$curl = curl_init();
	
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_POST, TRUE);
	curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json', "Authorization: Bearer " . $auth));
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true );
	
	$FormFieldVisibility = json_decode(curl_exec($curl));
	
	curl_close($curl);
}
catch (PDOException $e) {
    errorMessage($e);
}

// Get Form completedTargets
if(!$fromApp) {
	try{
		$url = _API_URL . "/api/target/get-employee-targets/mobile/";
		$curl = curl_init();	
		
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_HTTPGET, TRUE);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json', "Authorization: Bearer " . $auth));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true );
		
		$completedTargets = json_decode(curl_exec($curl));
		
		curl_close($curl);	
	}
	catch (PDOException $e) {
		errorMessage($e);
	}
}

$dumpJSON[] = array("targets"=>$targetsSupervisor);											// window.json[0]["targets"][0].FDFormID
$dumpJSON[] = array("forms"=>$formDefinitions);													// json[1].forms[131091].FormName
$dumpJSON[] = array("Employee"=>$Employee);															// window.json[2].Employee[0].ADLogin
$dumpJSON[] = array("Training"=>$Training);															// window.json[3].Training[0].Description
$dumpJSON[] = array("HazardActions"=>$HazardActions);										// window.json[4].HazardActions[3].hazard_description
$dumpJSON[] = array("IncidentActions"=>$IncidentActions);								// window.json[5].IncidentActions[3].Description
$dumpJSON[] = array("HazardTrendType"=>$HazardTrendType);								// window.json[6].HazardTrendType[4].FormName
$dumpJSON[] = array("PositiveRecognition"=>$PositiveID);								// window.json[7].PositiveRecognition[0]
$dumpJSON[] = array("IncidentTrendType"=>$IncidentTrendType);						// window.json[8].IncidentTrendType[1].Value
$dumpJSON[] = array("FormAccess"=>$formAccess);													// window.json[9].FormAccess[2][1]
$dumpJSON[] = array("ViewPointEmployee"=>$ViewPointEmployee);						// window.json[10].ViewPointEmployee[0].ADLogin
$dumpJSON[] = array("Certifications"=>$Certifications);									// window.json[11].Certifications[0].ADLogin
$dumpJSON[] = array("Disciplines"=>$Disciplines);												// window.json[12].Disciplines[0].ADLogin
$dumpJSON[] = array("PositiveRecognition"=>$PositiveRecognition);				// window.json[13].PositiveRecognition[0].ADLogin
$dumpJSON[] = array("HazardTrendSite"=>$HazardTrendSite);								// window.json[14].HazardTrendSite[4].FormName
$dumpJSON[] = array("IncidentTrendSite"=>$IncidentTrendSite);						// window.json[15].IncidentTrendSite[4].FormName
$dumpJSON[] = array("PositiveRecognitionTrendType"=>$PositiveRecognitionTrendType);	// window.json[16].PositiveRecognitionTrendType[4].FormName
$dumpJSON[] = array("PositiveRecognitionTrendSite"=>$PositiveRecognitionTrendSite);	// window.json[17].PositiveRecognitionTrendSite[4].FormName
$dumpJSON[] = array("Reviews"=>$Reviews);													      // window.json[18].Reviews[2][1]

//Kill the cache, force reload
$dumpJSON[] = array("EmployeeList"=>$EmployeeList);                                                  //window.json[18]
$dumpJSON[] = array("EmployeeTargetCounts"=>$completedTargets);
$dumpJSON[] = array("FormFieldVisibility"=> $FormFieldVisibility);
$dumpJSON[] = array("PreOpEquipQuestionLookup"=>$PreOpEquipQuestionLookup);                         /// Question Lookup for Preop
$dumpJSON[] = array("PreOpEquipment"=>$PreOpEquipment);
$dumpJSON[] = array("PreOpQuestions"=>$PreOpQuestions);
$dumpJSON[] = array("PreOpEquipmentList"=>$PreOpEquipmentList);
$dumpJSON[] = array("HazardActionsByMe"=>$HazardActionsByMe);										// window.json[26].HazardActionsByMe[3].hazard_description
$dumpJSON[] = array("DocumentReview"=>$DocumentReview);	
$dumpJSON[] = array("GeneralActions"=> $GeneralActions);
$dumpJSON[] = array("GeneralActionsByMe"=> $GeneralActionsByMe);
$dumpJSON[] = array("UsefulLinks"=> $UsefulLinks);
$dumpJSON[] = array("DocumentPDF"=> $DocumentPDF);
$dumpJSON[] = array("UserSettingsProfile"=> $UserSettingsProfile);
$dumpJSON[] = array("UserAddonModulePermission" => $UserAddonModulePermission);
$dumpJSON[] = array("EquipmentMeasureData" => $EquipmentMeasureData);
$dumpJSON[] = array("FormBuilderCategories" => $FormBuilderCategories);
$dumpJSON[] = array("CustomForms" => $CustomForms);
$dumpJSON[] = array("CustomFormItems" => $CustomFormItems);
$dumpJSON[] = array("DrillingCalculation" => $DrillingCalculation);
$dumpJSON[] = array("UserMultiActionPermission" => $UserMultiActionPermission);
$dumpJSON[] = array("preopEquipmentSiteJob" => $PreOpEquipSiteJob);
$dumpJSON[] = array("ErrorsInRemoteData" => $ErrorsInRemoteData);
echo json_encode($dumpJSON);
?>