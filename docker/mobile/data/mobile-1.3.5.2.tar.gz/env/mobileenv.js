(function (window) {
    window.__env = window.__env || {};
    window.__env.mainApi = "http://localhost:8000"
    window.__env.resourceUrl = "https://devcore-resources.sofvie.com"
    window.__env.apiUrl = "http://localhost:8000";
    window.__env.test_environment = false
    window.__env.baseUrl = '/';
    window.__env.pouchCacheName = 'SofvieCache';
    window.__env.pouchDBDeleteThreshholdDays
    window.__env.enableDebug = false;
  }(this));