<?php

	require_once __DIR__.'../../vendor/autoload.php';															// Pull in our packages
	$strRuntimeEnvironmentFileName = "mobile.env";						
	if(!$strRuntimeEnvironmentFileName)	{
		echo 'Error resolving environment file from ' . $sofvieRunTimeEnvironment . ' environment variable.';
		die(-1);
	}
	
	$dotenv = Dotenv\Dotenv::create(__DIR__ . '/../../', $strRuntimeEnvironmentFileName);	// Retrieve the .env for this runtime											// Open or environment file (outside of root for security)
	$dotenv->load();																															// Apply data to our env vars.

	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/sofvie_config.php");
	include_once(_DOCUMENT_ROOT . _APP_DIR . "/includes/Navigation.php");
	include_once(_DOCUMENT_ROOT . _APP_DIR . "/classes/database.php");

	if(!isset($boolLoginRequired)) $boolLoginRequired = true;											// Catch if boolLoginRequired isn't set, if not, set login IS required.
	
	if(array_key_exists('userid', $_COOKIE))	{
		$userID = json_decode($_COOKIE['userid']);
	//	echo "This is the USER ID ". $userID;
  }
	
?> 
