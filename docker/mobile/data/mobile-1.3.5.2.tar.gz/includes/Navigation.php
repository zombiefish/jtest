<?php
// Define navigational constants

define("_DEFAULT", "/index.php");
define("_LOGIN", "/login.php");
define("_SIGNOUT", "/SignOut.php");
define("_HELP","/supportRequest.php");
define("_PRIVACY","/preLogin/termsAndPrivacy.php");
define("_PASSRESETEMAIL", "setResetPassEmail.php");
define("_ABOUT","_about.php");
define("_CONTACT","_contact.php");
define("_TERMS","/preLogin/termsAndPrivacy.php");
define("_PROFILE","/pages/MyProfile.php");
define("_TOOLBOX","/pages/Toolbox.php");
define("_ACTIONITEMS","/pages/ActionItems.php");
define("_HAZARDINCIDENTMANAGEMENT","/pages/HazardAndIncidentManagement.php");
define("_RISKASSESSMENT","/pages/RiskAssessment.php");
define("_SAFETYTRENDS","/pages/SafetyTrends.php");
define("_DOCUMENTS","/pages/Documents.php");
define("_SETTINGS", "/pages/Settings.php");

// Forms
define("_DAILYLOG","/forms/formDailyLog.php");
define("_HAZARDACTIONSUB","/forms/formHAPSub.php");
define("_FORMHAZARDACTION","/forms/formHap.php");
define("_FORMPOSITIVEACTION","/forms/formPositiveAction.php");
define("_FORMCRAIGSHIFTREPORT","/forms/formCraigShiftReport.php");
define("_POSITIVEACTIONSUB","/forms/formPositiveActionSub.php");
define("_FORMHOTCOLDEVAL","/forms/formHotColdEvaluation.php");
define("_FORMINCIDENTSTATEMENT","/forms/formIncidentStatement.php");
define("_FORMPRELIMINARYINCIDENT","/forms/formPreliminaryIncident.php");
define("_FORMSAFETYCARDAUDIT","/forms/formPreTask.php");
define("_FORMEMPLOYEEDISCIPLINE","/forms/formEmployeeDiscipline.php");
define("_FORMJOBDEMONSTRATION","/forms/formJobDemonstration.php");
define("_FORMJOBOBSERVATION","/forms/formJobObservation.php");
define("_FORMPPEAUDIT","/forms/formPPEAudit.php");
define("_FORMPERSONALCONTACT","/forms/formPersonalContact.php");
define("_FORMPREOPAUDIT","/forms/formPreOp.php");
define("_FORMPHRAUDIT","/forms/formPHRAudit.php");
define("_FORMSAFETYJHSBOARDAUDIT","/forms/formSafetyJHSBoardAudit.php");
define("_FORMSUPERVISORLINUPAUDIT","/forms/formSupervisorLineUpAudit.php");
define("_FORMTAGBOARDAUDIT","/forms/formTagBoardAudit.php");
define("_FORMMONTHLYSAFETYMEETING","/forms/formMonthlySafetyMeeting.php");
define("_FORMSUPERVISORTAININGAUDIT","/forms/formSupervisorTrainingAudit.php");
define("_FORMMTCUVSTRAINING","/forms/formTaskVsMTCUTraining.php");
define("_FORMTIMESHEET","/forms/formTimeSheet.php");
define("_FORMRESCUEPLAN","/forms/formRescuePlan.php");
define("_FORMCONFINEDSPACEWORKINGATHEIGHTSPERMIT","/forms/formConfinedSpaceWorkingAtHeightsPermit.php");
define("_FORMTRAININGASSESSMENT","/forms/formTrainingAssessment.php");
define("_FORMACTIVITYLOG","/forms/formConfinedSpaceActivityLog.php");
define("_FORMA&MSHIFTREPORT","/forms/formA&MShiftReport.php");
define("_FORMWORKCARD","/forms/formWorkCard.php");
define("_FORMVIEWPOINTAUDIT","/forms/formViewpointAudit.php");
define("_FORMWORKPLACEINSPECTION","/forms/formWorkplaceInspection.php");
define("_FORMVFLAUDIT","/forms/formVFLAudit.php");
define("_FORMPRELIMINARYINVESTIGATION","/forms/formPreliminaryInvestigation.php");
define("_FORMJOBRISKASSESSMENT","/forms/formJobRiskAssessment.php");
define("_HOTWORKPERMIT","/forms/formHotWorkPermit.php");
define("_FORMMEETINGMINUTES","/forms/formMeetingMinutes.php");
define("_FORMTFSR","/forms/formTFSR.php");


define("131042","/forms/formHap.php");
define("131092","/forms/formWorkplaceInspection.php");
define("000000","/forms/formCraigShiftReport.php");
define("131093","/forms/formPersonalContact.php");
define("131097","/forms/formJobObservation.php");
define("131100","/forms/formJobDemonstration.php");
define("131106","/forms/formPPEAudit.php");
define("138900","/forms/formVFLAudit.php");
define("166071","/forms/formPositiveAction.php");
define("220234","/forms/formPreliminaryInvestigation.php");
define("221746","/forms/formIncidentStatement.php");
define("224335","/forms/formPreliminaryIncident.php");
define("226270","/forms/formSupervisorTrainingAudit.php");
define("235063","/forms/formHotColdEvaluation.php");
define("236336","/forms/formMonthlySafetyMeeting.php");
define("236704","/forms/formPreOpAudit.php");
define("236709","/forms/formViewpointAudit.php");
define("236710","/forms/formTrainingAssessment.php");
define("372348","/forms/formTimeSheet.php");
define("372338","/forms/formRescuePlan.php");
define("372358","/forms/formConfinedSpaceWorkingAtHeightsPermit.php");
define("372368","/forms/formHotWorkPermit.php");
define("236756","/forms/formSafetyCardAudit.php");
define("236757","/forms/formTagBoardAudit.php");
define("236760","/forms/formSupervisorLineUpAudit.php");
define("236762","/forms/formSafetyJHSBoardAudit.php");
define("236765","/forms/formPHRAudit.php");
define("236768","/forms/formTaskVsMTCUTraining.php");
define("372378","/forms/formConfinedSpaceActivityLog.php");
define("372408","/forms/formA&MShiftReport.php");
define("372418","/forms/formWorkCard.php");
define("372438","/forms/formTFSR.php");
define("372448","/forms/formJobRiskAssessment.php");

?>