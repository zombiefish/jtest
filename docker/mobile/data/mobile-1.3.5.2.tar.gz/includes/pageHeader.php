<header class="topnav blue text-white container-fluid">
    <div class="d-flex flex-nowrap">
        <div class="button-collapse mr-3 my-2" data-activates="slide-out"><i class="fa fa-bars fa-fw"></i></div>
        <span class="my-2 flex-grow-1 text-center">
            <div id="test-pill-id" class="material-tooltip-main trans_tooltip d-none" data-toggle="tooltip" tag="9055" notes="This is the test environment of Sofvie. Changes made here will not reflect on the production version of the application."><span class='translate badge badge-pill badge-danger text-uppercase' data-i18n='9078' notes='TEST ENVIRONMENT'></div>
        </span>
        <div class="online_status ml-3 my-2">
          <i class="fa fa-ban fa-fw" data-toggle="tooltip" title="The device is not connected to any networks."></i>
          <span id="syncPass" class="chip position-absolute mr-5 text-white green d-none" style="right: 0;"><span class='translate' data-i18n='3932' notes='Ready for offline use'></span><i class="text-white close fas fa-times"></i></span>
          <span id="syncFail" class="chip position-absolute mr-5 text-white red d-none" style="right: 0;"><span class='translate' data-i18n='3933' notes='Sync failed, try again'></span><i class="text-white close fas fa-times"></i></span>
          <span id="syncProgress" class="chip position-absolute mr-5 d-none grey darken-2 text-white" style="right: 0;"><span class='translate' data-i18n='3934' notes='Sync In Progress'></span></span>
          <i class="fas fa-sync-alt d-none fa-fw trans_tooltip" id="syncButton" data-toggle="tooltip" notes="The device is connected to a network." tag="1360"></i>
        </div>
    </div>
    <div>
        <div class="row">
            <div class = 'col-6 offset-3 mt-2 mb-5'>
                <a href="../index.php" class="flex-center logo"><img src="<?php echo _RESOURCEDOMAIN; ?>/img/svg/sofvieWhite.svg" class="img-fluid"></a>
            </div>
        </div>


    <div>

</header>

<script type="text/javascript">

function popDraftLoadAlert(lang){
    sessionStorage.setItem('draftpick','')
    switch(lang){
        case 'en':   
            lang = i18next.t('3617')
            break
        case 'fr':   
            lang = i18next.t('3618')
            break
        case 'es':   
            lang = i18next.t('3619')
            break
        default:
            lang = i18next.t('3617')
        }
	formModal = new SofvieModal();                                          // initialize the Modal 
	formModal.setModalElements(`warning`, `modalTitle`, i18next.t('9472'))  //unable to load draft
    formModal.setModalElements(`warning`, `modalText`,  i18next.t("9462")+" "+lang+","+ "<br>"  +i18next.t("9463")+" "+lang+" "+i18next.t("9464")+".")
    formModal.setModalElements(`warning`, `modalButtons`, `<a role="button" class="flex-fill btn btn-outline-warning waves-effect confirm" data-dismiss="modal"><span class='translate' data-i18n="1405" notes="Ok"></span></a>`)
	formModal.handleModal(`warning`) 
    $(`.modal-footer .confirm`).click(() => {
	    formModal.hideModal()
    })
}
</script>