<div class="modal fade" id="theModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
  <div class="modal-dialog modal-notify modal-success" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <p class="heading lead"></p>
      </div>
      <div class="modal-body">
        <div class="text-center">
          <i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
          <p class='modal-body-text'></p>
        </div>
      </div>
      <div class="modal-footer justify-content-center flex-wrap">
      </div>
    </div>
  </div>
</div>
<div id='child-modal'></div>
<div id='signature-modal'></div>
<div id='insertPhotoModal'></div>
<div id='openPicture'></div>
<div id='imageCaption'></div>
<div id='signatureNote'></div>
<div class="spinnerContainer SWspinnerContainer" id="footerSpinner">
  <div class="preloader-wrapper big active">
    <div class="spinner-layer spinner-blue-only">
      <div class="circle-clipper left">
        <div class="circle"></div>
      </div>
      <div class="gap-patch">
        <div class="circle"></div>
      </div>
      <div class="circle-clipper right">
        <div class="circle"></div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript" src="/js/jquery.min.3.6.0.js"></script>
<script type="text/javascript" src="/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo _RESOURCEDOMAIN; ?>/js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo _RESOURCEDOMAIN; ?>/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo _RESOURCEDOMAIN; ?>/js/mdb.min.js"></script>
<script type="text/javascript" src="<?php echo _RESOURCEDOMAIN; ?>/js/jquery.signaturepad.min.js"></script>
<script type="text/javascript" src="<?php echo _RESOURCEDOMAIN; ?>/js/json2.min.js"></script>
<script src="<?php echo _DOMAIN ?>/js/sofvie-main.js"></script>
<script src="<?php echo _DOMAIN ?>/modals/hapModalRmm.js"></script>
<script src="<?php echo _DOMAIN ?>/modals/genModalRmm.js"></script>
<script src="<?php echo _DOMAIN ?>/modals/preOpModal.js"></script>
<script src="<?php echo _DOMAIN ?>/modals/alertsRmm.js"></script>
<script src="<?php echo _DOMAIN ?>/js/i18next.js"></script>
<script src="<?php echo _DOMAIN ?>/js/jquery-i18next.js"></script>
<script src="<?php echo _DOMAIN ?>/js/i18nextXHRBackend.js"></script>
<script type="text/javascript" src="<?php echo _RESOURCEDOMAIN; ?>/js/addons/datatables.min.js"></script>
<script type="text/javascript" src="<?php echo _RESOURCEDOMAIN; ?>/js/select2.min.js"></script>
<script src="/js/jquery.ui.touch-punch.min.js"></script>
<script src="/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
//Add custom scrollbar to side navigation if it exists
if ($(".scrollbar")[0]){
  var sideNavScrollbar = document.querySelector('.scrollbar')
  Ps.initialize(sideNavScrollbar)
}

  // Define some config itmes
var DBconfig = {
  // db name for draft storage
  draftDbName: 'sofvie_drafts',
  // Sync path for draft, false for none
  draftRemoteSync: false,
  // Committed db name
  commitDBName: _SYNCCOUCHDB,
  commitRemoteSync:  _SYNCDOMAIN + ':' + _SYNCPORT + '/' + _SYNCCOUCHDB
} 
var db = null
let selectedLanguage = getDataFromCookie('lang')
let select2LanguageFunction = window[`sofvie_select2_languages_${selectedLanguage}`]
if (!(typeof select2LanguageFunction === "function"))
{
  select2LanguageFunction = {}
  console.error("Failed to get Select2 Translations")
}

function addDistributionGroup(args) {
      let items = args.params.data.id.split(",")
      let findMe = args.params.data.id.replace("string:","")
      let idx = 0
      let distribution= document.getElementById("Report_Distribution1").value.split(',')
      // Find the email list including teh comma in the distribution list.
      for(let i=0;i<distribution.length; i++){
          if(distribution[i] == findMe){
              idx = i
          }
      }
      
      // Remove the email string from the distribution list.
      distElementId = '#Report_Distribution1'
      if(items.length > 1){
          distribution.splice(idx,1)

          // Add them back in as individual emails if they dont already exist.
          for(let i = 0 ; i < items.length; i++){
            
              if(!distribution.includes(items[i])){
                  distribution.push(items[i])
              }
          }      

          disitems = items.concat($(distElementId).val())
          newdisitems = []

          
          for (let i in disitems){
              if (disitems[i].includes(',')) {
                  currentGroup = distributionGroupList.filter(function (group) {
                      return group.email == disitems[i]
                  });

                  // remove the currentGroup name from select list.
                  $(args.params.data.element).detach();
                  $(distElementId).trigger("change");

              } else {
                  newdisitems.push(disitems[i])
              }
          }
          if (newdisitems) {
              $(distElementId).val(newdisitems).trigger('change').parent().find('label').addClass('filled');
          }
      } else {
          AddOrRemoveIndividualFromList()
      }
}

function removeDistributionGroup(event) {
    AddOrRemoveIndividualFromList()
}

function AddOrRemoveIndividualFromList(){
    // Step1: compare all selected emails in the select list with the 
    // distribution groups.

    // Get a list of selected emils from the select list.
    let selectedEmails = []
    distElementId = '#Report_Distribution1'
    selectedEmails = $(distElementId).select2('data')
    
    // step2: if the emails in the list are all contained in a distribution group then
    // remove the group from the select list.

    // Clean selected emails.
    for (let i in selectedEmails) {
        selectedEmails[i] = selectedEmails[i]["id"]
        
    }   
    // loop through the groups list.
    for(let l=0;l<distributionGroupList.length;l++){
        let group = distributionGroupList[l].email.split(",")
        group.pop()
        let groupName = distributionGroupList[l].per_full_name

        // loop through the selected emails list in the group loop and 
        // find the emails.
        
        let found = group.every(val => selectedEmails.includes(val));
        if(found){
            // remove the group from the list.
            $(distElementId + " option[value='" + group.join(",") + ",']").remove();
        } else {

            // add the group back.
            let opt = new Option(groupName,distributionGroupList[l].email)
                
            // only add the group name back if it is not already added.
            let found2 = false
            let opts = $(distElementId).find("option")
            for(let c=0;c<opts.length;c++){
                if(opts[c].text == distributionGroupList[l].per_full_name){
                    found2 = true
                }
            }
            if(!found2){
                $(distElementId).append(opt).change();
            }
        }
    }
}

// Function to initialize datatables throughout the mobile app
function initializeDataTables(datatable = 'data-table') {
  if(!localStorage.getItem(`noinitialize`)) {
    let select2LanguageFunction = window[`sofvie_select2_languages_${selectedLanguage}`]
    if (!(typeof select2LanguageFunction === "function"))
    {
      select2LanguageFunction = {}
      console.error("Failed to get Select2 Translations")
    }
    myDataTable = $(`.${datatable}`).DataTable({
      "bSort": false, 
      // Set rows per page option
      "lengthMenu": [ 5, 10, 15, 25, 50 ],
      "pagingType": "numbers",
      "language": {
        "url": `/locales/datatables/i18n/${selectedLanguage}.json`
      },
      "initComplete": function(settings, json) {
        $('.dataTables_length').addClass('bs-select')
        // Removed the -md- classes to center pagination and info text  
        $(".dataTables_wrapper div:last-of-type div").removeClass("col-md-5 col-md-7")
        $('.dataTables_wrapper select').select2({theme: "material", language: select2LanguageFunction(), allowClear: false, minimumResultsForSearch: Infinity})
        $('.dataTables_wrapper b').addClass('fa fa-caret-down')
      }
    })

    myDataTable.on( 'page.dt', () => {
      setTimeout(() => {
        $('.translate').localize()
      },200)
    })

    myDataTable.on( 'draw.dt', () => {
      setTimeout(() => {
        $('.translate').localize() 
      },1000)
    })
  }
}

// Select2
function initializeSelect2() {
  if(!localStorage.getItem(`noinitialize`)) {
    // Alow validation on select inputs except the ones with the class .custom-select (in DataTable)
    $('select:not(.custom-select, .select-default, .select-admin, [class^=picker_])').val("").removeAttr('readonly')
    
    $('select:not([class^=picker_])').select2({theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder:""})
    .on('select2:select', function(event){$(this).parent().find('label').addClass('filled')
      if (event.target.parentNode.querySelector('.mobile-distribution-select')){
        addDistributionGroup(event)
      }
    })
    .on('select2:unselect', function(event){
      if($(".select2-selection__choice")[0]){
      $(this).parent().find('label').addClass('filled')
    }else {
    $(this).parent().find('label').removeClass('filled')
    }
    if (event.target.parentNode.querySelector('.mobile-distribution-select')){
        removeDistributionGroup()
      }
    })
    .on('select2:open', function () {
      $('.select2-search__field').attr('placeholder', i18next.t("2346"))
      $('.select2-results').css({'max-height':'260px'})
    })
    .on('select2:close', function () {
      $('.select2-search__field').attr('placeholder', i18next.t("2346"))
    });
    $("#ActionCompletionModal select").select2({theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder:"", dropdownParent: $('#ActionCompletionModal')})
    $("#GeneralActionCompletionModal select").select2({theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder:"", dropdownParent: $('#GeneralActionCompletionModal')})
    $(".select-multiple").select2({closeOnSelect: false, theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: ""})
    // Select2 styles for DataTable
    $('.dataTables_wrapper select').select2({theme: "material", language: select2LanguageFunction(), allowClear: false, minimumResultsForSearch: Infinity})
    // Add caret on selects
    $('.select2-selection__arrow b').addClass("fa fa-caret-down")
    $('.select-multiple').on('change', function (e) {
        var selected = $(e.target).val().length
        var total = $(e.target).find("option").length      
        if(selected > 4){
          $(e.target).parent().find(".select2 .select2-selection ul").append(selected + " " + i18next.t(1131) + " " + total)
          $(e.target).parent().find(".select2-selection__rendered").addClass("mt-1")
          $(e.target).parent().find('.select2-selection__choice').each(function() {$( this ).addClass( "d-none" )})
        }
      });
  }
}

// Select2JRA
function initializeSelect2Jra() {
  if(!localStorage.getItem(`noinitialize`)) {
    // Alow validation on select inputs except the ones with the class .custom-select (in DataTable)
    $('select:not(.custom-select, .select-default, .select-admin,.select-multiple-jra, [class^=picker_])').val("").removeAttr('readonly')
    
    $('.select-single-jra').select2({theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder:""})
      .on('select2:select', function(event){
        nameObj = event.currentTarget.name.split('-')
        if(nameObj.length == 1){
          jraObject.jra_data[`${nameObj[0]}`] = parseInt(event.currentTarget.value)

        }
        else {
          jraObject.jra_data.step_categories[nameObj[2]-1].threats[nameObj[1]][`${nameObj[0]}`] = parseInt(event.currentTarget.value)
        }
        $(this).parent().find('label').addClass('filled')
        if (event.target.parentNode.querySelector('.mobile-distribution-select')){
          addDistributionGroup(event)
        }
      })
      .on('select2:unselect', function(event){
        if($(".select2-selection__choice")[0]){
        $(this).parent().find('label').addClass('filled')
        }
        else {
          $(this).parent().find('label').removeClass('filled')
        }
        if (event.target.parentNode.querySelector('.mobile-distribution-select')){
          removeDistributionGroup()
        }
      })
      .on('select2:open', function () {
        $('.select2-search__field').attr('placeholder', i18next.t("2346"))
        $('.select2-results').css({'max-height':'260px'})
      })
      .on('select2:close', function () {
        $('.select2-search__field').attr('placeholder', i18next.t("2346"))
       })


    $("#ActionCompletionModal select").select2({theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder:"", dropdownParent: $('#ActionCompletionModal')})
    
    $("#GeneralActionCompletionModal select").select2({theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder:"", dropdownParent: $('#GeneralActionCompletionModal')})
    
    $(".select-multiple-jra").select2({closeOnSelect: false, theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: ""})
        .on('select2:open', ()=> {
        $('.select2-search__field').attr('placeholder', i18next.t("2346"))
        $('.select2-results').css({'max-height':'260px'})
        })
        .on('select2:select', (event) =>{
          event.currentTarget.parentNode.querySelector('label').classList.add(['filled'])
          alloptions = event.currentTarget.options
          selectedOptions = []
          for(x = 0; x < alloptions.length; x++) {
            if(alloptions[x].selected)
              selectedOptions.push(parseInt(alloptions[x].value))
          }
          jraObject.jra_data[event.currentTarget.name] = selectedOptions
          $(this).parent().find('label').addClass('filled')
        })
        .on('select2:unselect', function(event){
          alloptions = event.currentTarget.options
          selectedOptions = []
          for(x = 0; x < alloptions.length; x++) {
            if(alloptions[x].selected)
              selectedOptions.push(alloptions[x].value)
          }
          jraObject.jra_data[event.currentTarget.name] = selectedOptions
          
          if($(".select2-selection__choice")[0]){
            $(this).parent().find('label').addClass('filled')
          }
          else {
            $(this).parent().find('label').removeClass('filled')
          }
        })
        .on('change', function (e) {
          var selected = $(e.target).val().length;
          var total = $(e.target).find("option").length;   
          if(selected > 4){ 
            $(e.target).parent().find(".select2 .select2-selection ul").append(selected + " " + i18next.t('1131') + " " + total)
            $(e.target).parent().find(".select2-selection__rendered").addClass("mt-1"); 
            $(e.target).parent().find('.select2-selection__choice').each(function() {$( this ).addClass( "d-none" )});
          }
        });

    // Select2 styles for DataTable
    $('.dataTables_wrapper select').select2({theme: "material", language: select2LanguageFunction(), allowClear: false, minimumResultsForSearch: Infinity})
    // Add caret on selects
    $('.select2-selection__arrow b').addClass("fa fa-caret-down")
  }
}
// Initialize the pickadate.
function initializePickadate() {
  if(!localStorage.getItem(`noinitialize`)) {
    // apply the language to the Pickadate 
    $.extend($.fn.pickadate.defaults, sofvie_pickadate_languages[`${selectedLanguage}`])
    
    $('.datepicker').pickadate({
      format : 'yyyy-mm-dd',
    }).removeAttr('readonly')
    .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
      evt.preventDefault()
    })

    if(window.location.pathname === '/forms/formJobRiskAssessment.php') {
      $('.datepickerjra , .datepickerjraexpirydate ').pickadate({
        format : 'yyyy-mm-dd',
      }).removeAttr('readonly')
      .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
        evt.preventDefault()
      })

      $('.datepickerjradate').pickadate().pickadate('picker').on('close',
        () => {
          jraObject.jra_data.rmm_jra_date  = $('.datepickerjradate').pickadate().pickadate('picker').$node[0].value
        })

      $('.datepickerjraexpirydate').pickadate().pickadate('picker').on('close',
        () => {
          jraObject.jra_data.rmm_jra_expiry_date = $('.datepickerjraexpirydate').pickadate().pickadate('picker').$node[0].value
        })
    }

    let pickadateTranslations = sofvie_pickatime_languages[`${selectedLanguage}`]
    $('.timepicker').pickatime({
      donetext: pickadateTranslations.done,
      cleartext: pickadateTranslations.clear,
      twelvehour: true,
      'default': '24:00'
    })
  }
}

// Check if there is an draftpick in the Session storage
function draftCheck() {
  let draftid = sessionStorage.getItem('draftpick')
  sessionStorage.removeItem('draftpick')
  if(draftid) {
    if (typeof getFormData === 'function') {
      getFormData($('#draft'), theURL = draftid)
    }
    if (typeof getFormDraftList === 'function') {
      getFormDraftList($('#draft'), draftid)
    }

    if (typeof getRADraftData == 'function' && draftid ) {
      getRADraftData($('#draft'), draftid)
      $('#draft').parent().find('label').addClass(['filled','active'])

    }
  }
}


$(document).ready(function() {
  if(!checkIfLoggedIn()) {
    if(document.querySelector('.button-collapse .fa')) {
      document.querySelector('.button-collapse .fa').classList.remove('fa-bars')
      document.querySelector('.button-collapse .fa').classList.add('fa-home')
      delete document.querySelector('.button-collapse').dataset.activates
      $('.button-collapse .fa').on('click',()=> {
      })
    }
  } else {
    $("#theModal").before(`
      <footer class="mb-2">
        <small class="d-block text-center">Sofvie 
          <span>v <?php echo _SOFVIEVERSION ?></span>
        </small>
      </footer>
    `)
  }

  // Create a ref to the local DB
  window.db = new PouchDB(DBconfig.commitDBName, { auto_compaction: true })
  checkOnline().then((status)=>{
    // sync to it.
    if(status){
      sync(db, DBconfig.commitRemoteSync)
      syncForm("RMM","From Footer")
    }
  }).catch((err)=>{})
  
  // initialize Cancel Button on Forms
  $('#cancelForm').click(()=>{
      // initialize the Modal
      formModal = new SofvieModal() 
      formModal.setModalElements(`danger`, `modalText`, i18next.t("1402"))
      formModal.setModalElements(`danger`, `modalTitle`, i18next.t("1401"))
      // Display the Warning Modal
      formModal.handleModal(`danger`)
      $('.translate').localize()
      $(`.modal-footer .confirm`).click(() => { 
        window.history.back()
      })
  })

  $('#deleteDraft').click(()=>{ 
    modalDeleteDraft()
  })

  // initialize Cancel SUB Button on Forms
  $('#cancelSubForm').click(()=>{
        formModal = new SofvieModal()// initialize the Modal 
        formModal.setModalElements(`warning`, `modalText`, i18next.t("1402"))
        formModal.handleModal(`warning`)// Display the Warning Modal
        $(`.modal-footer .confirm`).click(() => { 
        window.close()
        })
  })

  $('#SignOut').click(()=>{
    checkOnline().then((status)=>{
      // initialize the Modal
      formModal = new SofvieModal()
      // Log Out.
      formModal.setModalElements(`warning`, `modalTitle`, i18next.t("1896"))
      // You can only sign in when online. Are you sure you want to proceed?
      formModal.setModalElements(`warning`, `modalText`,  i18next.t("1897"))
      // Display the Warning Modal
      formModal.handleModal(`warning`)
      $(`.modal-footer .confirm`).click(() => { 
        window.localStorage.removeItem('token')
        window.open(`/login.html`, '_self');
      })        
    }).catch((err)=>{})
  })

  
  initializeDataTables() 
  
  // Add functionality for Form Rules
  // initialize Class FormRules from sofvie-main.js
  formRules = new FormRules()
  // Hide all of the Fields needed upon form load
  formRules.hideRuleFields()
  // Add Events for Radio Buttons to Show and Hide Thier Sibling
  formRules.activateRules()
  // Trigger for side menu toggle
  $('.button-collapse').sideNav()
  // Initialize tooltips
  $('[data-toggle="tooltip"]').tooltip()
    
  if(document.getElementById("showsuccessmodal")){
    modal = new SofvieModal()
    // set Text to the success modal
    modal.setModalElements('success','modalText','The message was sent successfully')
    // set the title of the success modal
    modal.setModalElements('success','modalTitle','Message Sent')
    modal.handleModal("success")
    $('#showsuccessmodal').remove()
  }

  // Populate form with previous form values if same form want to be filled out
  function populateSelectValueDefaults(id){
      $(`#${id}`).prev().children()[0].each((index,value)=>{
        if(value.innerText === sessionStorage.getItem(`${id}`)){
        $(`#${id}`).prev().children()[index].className = `selected filled`
        }
      })
      $(`#${id}`).prev().prev(`.select-dropdown`).val(sessionStorage.getItem(`${id}`))
  }

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  // This section will fill out the reportname tag so that we can pick this off when emailing with the SQL listener //
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  if(document.getElementById('email_form_report')){
    let reportFormId = document.getElementById('formid').value
    if(reportFormId == 349935){
      document.getElementById('email_form_report').value = 'hazard_report'
    }
    else if(reportFormId == 350049) {
      document.getElementById('email_form_report').value = 'positive_recognition'
    }
    else if(reportFormId == 999999) {
      document.getElementById('email_form_report').value = 'job_risk_assessment'
    }
    else {
      openCacheData().then(()=>{
        let allReports = remoteData[1].forms
        document.getElementById('email_form_report').value = allReports[reportFormId].ReportURL
      })
    }
  }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
})

function closeModal(modal) {
  let backDrops = $(".modal-backdrop")
  if(backDrops[backDrops.length - 1]) {
    backDrops[backDrops.length - 1].remove()
  }
  modal.hideModal()
}

//Bootstrap form validation

(() => {
  'use strict'
  let debug = _DEBUG;
  window.addEventListener('load', () => {
  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  let forms = document.getElementsByClassName('needs-validation')
  // Loop through them and prevent default submission
  let validation = Array.prototype.filter.call(forms, (form) => {
      // Event Listener for the FORM submit
      form.addEventListener('submit', (event) => {
      //  remove the readonly attribute before validation
        $('.datepicker').removeAttr('readonly')
        var eventList = $._data(form, "events")
        let returnValue = true
        let val = new SofvieValidation()
      returnValue = val.materialRadioButtonValidationShowError() 

      // debug code to check each field for a validated Value
      if(debug) {
        for(let a=0; a < event.target.length; a++){
          if(!event.target[a].validity.valid) {
            console.log(`${event.target[a].name}  is  ${event.target[a].validity.valid}`)
          }
        }
      }
      let valImages = ValidateImageFields(event)
      let modalSignatures = ValidateModalSignatureFields(event)

      // Are the images validating and the fields
      let chipsValidated = false
      if(validateChips())
        chipsValidated = true

      if (!invalidContentValidation(form) || !valImages || !modalSignatures || !chipsValidated) {
        event.preventDefault();
        event.stopImmediatePropagation()
        let formModal = new SofvieModal() 
        if(form.classList.contains('invalid-content'))
          formModal.handleModal(`invalidContent`)
        else 
          formModal.handleModal(`validate`)
      
        $('.confirmValidation').click(()=>{
          closeModal(formModal)
        })   
      }
      else{
        form.classList.add('validated')
        if(document.getElementById('hapChildExists') && document.getElementById('pidChildExists')) {
        let hap = document.getElementById('hapChildExists').value
        let pid = document.getElementById('pidChildExists').value 
        let gap = document.getElementById('gapChildExists').value 
        if(form.formid.value === '349935' && hap === 'false'){
          childAlert()
          event.preventDefault();
          event.stopImmediatePropagation()
          form.classList.remove('validated')
        }

        if(form.formid.value === '372298' && gap === 'false'){
          childAlert()
          event.preventDefault();
          event.stopImmediatePropagation()
          form.classList.remove('validated')
        }
        
        if(form.formid.value === '350049'  && pid === 'false'){
          childAlert()
          event.preventDefault();
          event.stopImmediatePropagation()
          form.classList.remove('validated')
        }  
        }
      }
      form.classList.add('was-validated')
      }, false)
    // End of Event

    // Event Listener for the SAVE Draft
    const getSaveDraft = document.querySelector(".saveDraft")
    if(getSaveDraft) {
      document.querySelector(".saveDraft").addEventListener('click',(event) => {
        let returnValue = true
        let val = new SofvieValidation()
      returnValue = val.materialRadioButtonValidationShowError() 
      if (form.checkValidity() === false) {
        event.preventDefault()
        event.stopImmediatePropagation()
      }
      else{
        form.classList.add('validated')
      }
      form.classList.add('was-validated')
      }, false)   

    }
    
    // End of Event
    })
    })
    
    // check if there is a draft selected if not then disable the delete draft button
    if(document.getElementById('draftDropdown')) {
          document.getElementById('draftDropdown').addEventListener('click', () => {
          var url = new URL(window.location.href)
        let draftid = url.searchParams.get("draftid")
        if(!document.getElementById("draft").value && !draftid){
          document.getElementById("deleteDraft").disabled = true
        } else{
          document.getElementById("deleteDraft").disabled = false
        }
      })
    }

  // --------------------------------------------------------------------- //
  // Window Resizing needed for Canvas and imaging and maybe other things  //
  // --------------------------------------------------------------------- //


  // --------------------------------------------------------------------- //
  // end of Window Resizing stuff                                          //
  // --------------------------------------------------------------------- //

})()

//Invalid character validation
function invalidContentValidation (form){
  form.classList.remove('invalid-content')
  for (let a = 0; a < form.length; a++) {
    if (form[a].tagName === "INPUT" || form[a].tagName === "TEXTAREA"){
      if(!validateText(form[a].value) && form[a].offsetParent != null){ // Check for invalid content && Check if feild is hidden
        form[a].classList.add('invalid')
        form[a].setCustomValidity("Invalid Content")
        form.classList.add('invalid-content')
      }else{
        form[a].classList.remove('invalid')
        form[a].setCustomValidity("")
      }
    }
  }

  return form.checkValidity()
}

// This list needs finalized before release!
let invalidList = ['{{', '}}', '${', '$(', '==', '===', '&&', '--', '++', '||', '//', '/*', '*/'] 
function validateText (data) {
  // To check if its not empty
  if(data){
    for (let i = 0; i < invalidList.length; i++) {
      if(data.includes(invalidList[i])){
        return false
      }
    } 
  }
  return true
}

function childAlert() {
  let childAlert = new SofvieModal()
        childAlert.setModalElements('danger', 'modalTitle', i18next.t('1704'))
        //Form not submitted. Please revisit the required sub-form.  
        childAlert.setModalElements('danger', 'modalText', i18next.t('1705'))
        childAlert.setModalElements('danger', 'modalButtons', '<a role="button" class="btn btn-danger waves-effect" data-dismiss="modal"><span class="translate" data-i18n="1405" note="OK"></span></a>')  
        childAlert.handleModal('danger')
        $('.translate').localize()
}

// Check if device is connected to a network
let intVal

intVal = setInterval(()=> {
      syncInterval()            
}, 10000)

let badgeInterval

function badgeIntPass(){
  let ele = document.getElementById('syncProgress')
  ele.classList.add('d-none')
  badgeInterval = setInterval(()=>{
    let ele = document.getElementById("syncPass")
    ele.classList.add('d-none')
    clearInterval(badgeInterval)
  },20000)
}

function badgeIntFail(){
  let ele = document.getElementById('syncProgress')
  ele.classList.add('d-none')
  badgeInterval = setInterval(()=>{
    let ele = document.getElementById("syncFail")
    ele.classList.add('d-none')
    clearInterval(badgeInterval)
  },20000)
}

function syncInterval(){
  localStorage.setItem('Refreshing', true)
  if(localStorage.getItem('userlineupState')=='true'){
    if(localStorage.getItem('userjobstate')=='true'){
      if(localStorage.getItem('usersitestate')=='true'){
        if(localStorage.getItem('offlinedocstate')=='true'){
          if(localStorage.getItem('remotedatastate')=='true'){
            if(window.location.pathname === '/pages/Settings.php'){
              // Dissable spinner for settings page
              $("#footerSpinner").addClass('d-none')
              formHeader.formInitialize()
            }
            if(document.cookie){
              if(localStorage.getItem('serviceworkerstate')=='true'){
                localStorage.setItem('Refreshing', false)
                let ele = document.getElementById("syncProgress")
                ele.classList.add('d-none')
                //success.
                //stop the interval.
                //erase all items from the local storage.
                localStorage.removeItem('userjobstate')
                localStorage.removeItem('usersitestate')
                localStorage.removeItem('offlinedocstate')
                localStorage.removeItem('userlineupState')
                localStorage.removeItem('remotedatastate')
                localStorage.removeItem('serviceworkerstate')
                //show the synchronized badge.
                // alert("SYNCHRONIZAQTION COMPLETED")
                ele = document.getElementById("syncPass")
                window.localStorage.removeItem('refresh')
                ele.classList.remove('d-none')
                clearInterval(intVal)
                badgeIntPass()
                if(window.location.pathname === '/pages/Toolbox.php'){
                  location.reload()
                }                
              }
            } else {

              let ele = document.getElementById("syncFail")
              ele.classList.remove('d-none')
              clearInterval(intVal)
              badgeIntFail()
            }
            
          } else if ( localStorage.getItem('remotedatastate')=='failed') {

            let ele = document.getElementById("syncFail")
            ele.classList.remove('d-none')
            clearInterval(intVal)
            badgeIntFail()
          }
        } else if ( localStorage.getItem('offlinedocstate')=='failed') {

          let ele = document.getElementById("syncFail")
          ele.classList.remove('d-none')
          clearInterval(intVal)
          badgeIntFail()
        }
      } else if (localStorage.getItem('usersitestate')=='failed') { //usersitestate

        let ele = document.getElementById("syncFail")
        ele.classList.remove('d-none')
        clearInterval(intVal)
        badgeIntFail()
      }
      
    } else if (localStorage.getItem('userjobstate')=='failed'){ //userjobstate

      let ele = document.getElementById("syncFail")
      ele.classList.remove('d-none')
      clearInterval(intVal)
      badgeIntFail()
      
    }
  } else if (localStorage.getItem('userjobstate')=='failed'){ //userjobstate
  let ele = document.getElementById("syncFail")
  ele.classList.remove('d-none')
  clearInterval(intVal)
  badgeIntFail()

  }

  if(window.location.pathname === '/pages/Settings.php' && localStorage.getItem('remotedatastate')=='true')
    $("#footerSpinner").addClass('d-none')													// Disable the spinner for settings page
}
// On document loaded
document.addEventListener( "DOMContentLoaded", () => {
  checkOnline().then((status)=>{
    if(status) {
      localStorage.removeItem('submittedForms')
      // Online
      $('#SignOut').attr('disabled',false)
      $('#submit').attr('disabled',false)
      $('.online_status .fa-ban').addClass('d-none')
      $('.online_status .fa-sync-alt').removeClass('d-none')
    
      document.getElementById('syncButton').addEventListener('click', (e) => {
        $("#footerSpinner").removeClass('d-none')

        localStorage.setItem('Refreshing', true)
          //reset items in the remote data.
          localStorage.setItem('userjobstate', false)
          localStorage.setItem('usersitestate', false)
          localStorage.setItem('offlinedocstate', false)
          localStorage.setItem('remotedatastate', false)
          localStorage.setItem('userlineupState', false)
          localStorage.setItem('serviceworkerstate', "in progress")
          
          intVal = setInterval(()=> {
            syncInterval()
          }, 10000)
          refreshServiceWorkerSofvie()
          checkSubmissionDataSync()
      })

      if(window.localStorage.getItem('refresh')) {
        let ele = document.getElementById("syncProgress")
        ele.classList.remove('d-none')
        $("#footerSpinner").removeClass('d-none')
        getOfflineDataSofvie()
      }
    }
    else{
      $('.online_status .fa-ban').removeClass('d-none')
      $('.online_status .fa-sync-alt').addClass('d-none')
      $("#footerSpinner").addClass('d-none')
    }
  }).catch((err)=>{})
}, false)

function checkSubmissionDataSync() {
  // Retrieve contents of PouchDB and return as array.
  const db = new PouchDB(DBconfig.commitDBName, { auto_compaction: true })
  db.allDocs({
    include_docs: true,
    attachments: false,
  }).then((result) => {
    if(result.rows.length) {
      let pouchData = sortSubmissionData(result.rows)

      //Only check if online
      checkOnline().then((status)=> {
        let sendData = []
        for(let s = 0; s < pouchData.length; s++)
          sendData.push({"submissionID": pouchData[s].submissionID})

        token = JSON.parse(window.localStorage.getItem('token')).access
        $.ajax({
          url: `<?php echo _API_URL ?>/api/submission/check-submissions-synced/`,
          type: "POST",
          dataType: "json",
          contentType: 'application/json',
          data: JSON.stringify(sendData),
          headers: {
            'Authorization': `Bearer ${token}`
          },
          success: (result) => {
            let failedSubmissions = []
            for(let s = 0; s < result.length; s++)
              failedSubmissions.push(result[s].submissionID)

            sendMissingSubmissionEmail(pouchData, failedSubmissions)
          },
          error: (error) => {
            console.log("There was an error checking submissions synced", error)
          }
        })
      }).catch((err)=>{
        
      })
    }
  })
}
//Send Support Email IF a day has passed since the last check
function sendMissingSubmissionEmail(pouchData, failedSubmissions) {
  let lastSubmissionSyncCheck = localStorage.getItem('lastSubmissionSyncCheck')
  //86400000 milliseconds in a day
  if(failedSubmissions.length > 0 && (lastSubmissionSyncCheck == null || lastSubmissionSyncCheck < Date.now() - 86400000)) {
    localStorage.setItem('lastSubmissionSyncCheck', Date.now())
    let mailSubmissions = []
    pouchData.forEach((record) => {
      if(failedSubmissions.includes(record.submissionID))
      {
        mailSubmissions.push({
          submissionID: record.submissionID,
          formName: record.formName,
          submissionDateTime: record.dateTime
        })
      }
    })
    $.ajax({
      url: `<?php echo _API_URL ?>/api/submission/missing-submissions-email/`,
      type: "POST",
      dataType:"json",
      data : JSON.stringify(mailSubmissions),
      contentType: 'application/json',
      headers: {
        'Authorization': `Bearer ${JSON.parse(window.localStorage.getItem('token')).access}`
      },
      success: (result) => {
      },
      error: (error) => {
        console.log("There was an Email Error", error)
      }
    })
  }
}

  function sortSubmissionData(data) {
    var today = moment(new Date(),'YYYY-MM-DD')
    var todayDate = today.subtract(_POUCHDB_DELETE_THRESHOLD_DAYS, 'days').format('YYYY-MM-DD')
    let sortedData = []
    let exceptions = ['ACTIONCOMPLETE', 'DRMACK','GENERALACTIONCOMPLETE']

    data.forEach((record)=>{
      date = moment(new Date(record.doc.timestamp),'YYYY-MM-DD')
      if(record.doc.hasOwnProperty('timestamp'))	{
        if(date.format('YYYY-MM-DD') < todayDate) {
          db.get(record.id).then((d) => {
            d._deleted = true;
            return db.put(d);
          })
        } else {
          if(exceptions.indexOf(record.doc.formdata.formname) == -1) {
            let formNameFull = record.id
            if(record.id.split(' - ')) {
              let formId = record.id.split(' - ')[0]
              if(!isNaN(formId))
              {
                if(formId == 777777) // Custom Form
                  formNameFull = `${record.doc.formdata.customForm_name} - ${lookupFormNameByFormId(formId)} - ${record.id.split(' - ')[1]}`
                else
                  formNameFull = `${lookupFormNameByFormId(formId)} - ${record.id.split(' - ')[1]}`
                formName = lookupFormNameByFormId(formId)
                dateTime = record.id.split(' - ')[1]
              }
                
            }
              
            sortedData.push({
              pouchKey: record.key,
              submissionID: record.doc.submissionID,
              name: formNameFull,
              formName: formName,
              dateTime: dateTime,
              timestamp: record.doc.timestamp,
              children: record.doc.formdata.Children.length
            })
          }          
        }
      }
    })

    let myarray = sortedData.sort((a,b) => {
      return b.timestamp - a.timestamp
    })

    return myarray
  }

function lookupFormNameByFormId(formId) {
  if(formId == 350049) // POSITIVE IDENTIFICATION PARENT
    formId = 166071
  if(formId == 131200) // General Report Parent
    formId = 372298
  if(formId == 349935) // Hazard Report Parent
    formId = 131042

  let formName = ""
  try {
    formName = remoteData[1].forms[formId].MobileFormName
  }
  catch {
    console.warn("This formId does not exist: ", formId)
  }

  return formName
}

function checkCookie(){
  //put a cookie check in.
  let expires = new Date()
  expires.setFullYear( expires.getFullYear() + 2)

  let AccessToken = JSON.parse(window.localStorage.getItem('token')).access
  
  $.ajax({
    url: `<?php echo _API_URL; ?>/api/userprofile/get-person-profile/${selectedLanguage?selectedLanguage:'en'}/`,
    type: 'get',
    dataType: 'json',
    contentType: 'application/json',
    beforeSend: function(request) {
      request.setRequestHeader("Authorization", `Bearer ${AccessToken}`)
    },
    success: function (data) {
      $.ajax({
        url: `<?php echo _API_URL; ?>/api/settings/get-user-profile/${data[0].per_id}/`,
        type: 'get',
        dataType: 'json',
        contentType: 'application/json',
        beforeSend: function(request) {
          request.setRequestHeader("Authorization", `Bearer ${AccessToken}`)
        },
        success: function (settingsData) {
          userLang = settingsData.upr_language ? settingsData.upr_language :'en'
          setCookieLanguage(userLang, expires)
          location.reload()
        },
        error: function (data) {
          location.reload()
        }
      })
  },
  error: function (data) {
    location.reload()
  }
  })
}

function setCookieLanguage(lang, expires){
  document.cookie = "lang=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;" 
  document.cookie = `lang=${lang}; expires= ${expires.toUTCString()}; path=/`
}

function refreshServiceWorkerSofvie() {

  let ele = document.getElementById('syncProgress')
  ele.classList.remove('d-none')
  window.localStorage.setItem('refresh','true')
  checkCookie()
}

function LoadServiceworkerSofvie() {
  // Does this browser support service workers.
  if ('serviceWorker' in navigator) {
    // Register the service workers
      navigator.serviceWorker.register('/sw.js').then((registration) => {
        // Registration was successful
        if(debug) console.log('ServiceWorker registration successful with scope: ', registration.scope)
        //record messages
      }, (err) => {
        // Log the error
        console.error('ServiceWorker registration failed: ' + err)
      })

      navigator.serviceWorker.addEventListener('controllerchange', (event) => {
        // Listen for changes in the state of our ServiceWorker
        // This only occurs when a new SW is installed. Otherwise, 
        // we just check to see if a SW is currently controlling the page below
        // List for a state change event
        navigator.serviceWorker.controller.addEventListener('statechange', (data) => {
          if(debug) console.log('[controllerchange][statechange] ' + 'A "statechange" has occured: ', this.state);
          // If the ServiceWorker becomes "activated", let the user know they can go offline!

          if (data.target.state === 'activated') {
            localStorage.setItem('serviceworkerstate','true')
            // Show the "You may now use offline" notification
            if(debug) console.log('Received notification cache has finished loading')

            } else {
              
            }
          }
        )
      })
      // Are we currently controlled by a SW?
      if (navigator.serviceWorker.controller) {
        if(debug) console.log('This page is currently controlled by:', navigator.serviceWorker.controller)
        localStorage.setItem('serviceworkerstate','true')
        // hide the spinner.
        $("#footerSpinner").addClass('d-none')
      }
  }
}

function getOfflineDataSofvie() {
    let token = JSON.parse(window.localStorage.getItem('token'))
    $.ajaxSetup({ cache: false })
    let allCurrentRecords = []
    updateOfflineDocsSofvie().then((data)=>{
      let languageCookie = getCookie("lang")
      var urlString = `/ajax/getRemoteData.php?lang=${languageCookie}&auth=${token.access}`

      $.get(urlString,(data) => {
        getRmmJraRemoteData()
        allCurrentRecords = data[27].DocumentReview
        // Check to see if the Language Changed
        if(data[32].UserSettingsProfile[0].upr_language !== languageCookie){
          userLang = data[32].UserSettingsProfile[0].upr_language
          document.cookie = `lang=${userLang}; expires= ${now.toUTCString()}`
          window.location.href = `/index.php`
        }
      }).done(() => {
          var urlString_selectLists = `/includes/generateLists.php?lang=${languageCookie}`
          $.get(urlString_selectLists,(data) => {
            localStorage.setItem('selectcacheloaded','true')
          }).done(() => {	
              openCacheData().then(()=>{
                if(remoteData){
                  window.localStorage.setItem("remotedatastate", true)
                } else {
                  window.localStorage.setItem("remotedatastate", false)
                }
                // Load the Notification Badges
                if(window.location.pathname === '/index.php') {
                  loadToolboxToDo()
                  loadAssignedActionItems()
                  loadProfileTrainingRecords()
                  loadDocuments()     
                  loadAddonModulePermission()

                }

                if(typeof(formFooter) !== 'undefined') {
                  formFooter.formInitialize(document.forms[0])
                }

                let mobileTheme = ''
                if(remoteData[_MOBILESETTINGS].UserSettingsProfile) {
                  mobileTheme = `${remoteData[_MOBILESETTINGS].UserSettingsProfile[0].upr_theme_mobile}-theme`
                }
                // set the theme from the Settings
                localStorage.setItem('mobileTheme',mobileTheme)
                // if it is set to default them take the setting from the browser
                if(mobileTheme === "default"){
                  localStorage.setItem('mobileTheme','light-theme')
                  if(window.matchMedia('(prefers-color-scheme: dark)').matches){
                    localStorage.setItem('mobileTheme','dark-theme')
                  }
                }

                if(localStorage.getItem('mobileTheme'))
                {
                  document.body.classList.remove('dark-theme')
                  document.body.classList.remove('light-theme')
                  document.body.classList.add(mobileTheme)
                }

                // Get the Offline Documents
                getOfflineDocuments(allCurrentRecords)
                // Get the User sites
                getUserSites(remoteData)
                // Get the Users Jobs
                getUserJobs(remoteData)
                // Get the User Lineups
                getUserLineup()
                // Get the user Employee Remote Data
                getUserEmployeeRemoteData()
                // get the  all jra data
                getRmmJraRemoteData()
                // get the action attachments 
                getGeneralActionAttachmentData()
                // get the hazard attachments 
                getHazardActionAttachmentData()
              })
          })
        })
    })
  }

function updateOfflineDocsSofvie() {
  let blobConfig = {
      draftDbName: 'offlineDocuments', 
      draftRemoteSync: false,		
  }
  docDb = new PouchDB(blobConfig.draftDbName, { auto_compaction: true })
  return new Promise((resolve, reject) =>	{
  docDb.allDocs().then(function (doc) {
          let cookieData = []
          doc.rows.forEach((docs)=>{
            cookieData.push(docs.id)
          })
          localStorage.setItem('offline_docs', JSON.stringify(cookieData))
          resolve("ok")
        }).catch(function (err) {
            console.log("Problem Getting all Docs",err)
        })

  }).catch(err => {
    reject(err)
  }) // End Promise
}

function getBlobDataSofvie(data, currentOfflineDocs,currentDocs,refresh=false) {
  if(data) {
    let blobArray = []
      data.forEach((data)=>{
        blobArray.push({
        _id: `${data.drm_id}`,
        blob: data.drm_offline_attachment,
        timestamp: + new Date
      })
    })
    docDb.bulkDocs(blobArray).then((response) => {
        updateOfflineDocsSofvie()
        if(refresh)
          location.reload() 
        // Successfully got the bulk docs refresh !!
    })
    .catch(function (err) {
      console.log("Error Saving Document", err)
    })
  }
}

  // initialize signature fields for use
function ValidateImageFields(event) {
  imageFields = document.querySelectorAll('.photoImage')
  let status = true
  imageFields.forEach((data)=>{
    if(data.hasAttribute('required')) {
        if(data.getElementsByClassName('photoGallery')[0].innerHTML.trim()){
          form.classList.add('validated')
          data.classList.remove('invalid')
          }
          else {
              form.classList.remove('validated');
              data.classList.add('invalid')
              event.preventDefault();
              event.stopImmediatePropagation()
              status = false
          }
        }
    })
    return status
}

function ValidateModalSignatureFields(event) {
  imageFields = document.querySelectorAll('.modalSignature')
  let status = true
  imageFields.forEach((data)=>{
    if(data.hasAttribute('required')) {
        if(data.value  && data.hasAttribute('required')){
          form.classList.add('validated');
          data.previousElementSibling.previousElementSibling.childNodes[1].classList.remove('invalid')
          status = true
        }
        else {
            form.classList.remove('validated')
            data.previousElementSibling.previousElementSibling.childNodes[1].classList.add('invalid')
            event.preventDefault()
            event.stopImmediatePropagation()
            status = false
          }
        }
  })
  return status
}

function anotherForm() {
  // check if we need to populate data from the previous submission
  if(sessionStorage.getItem("lastformdata") !== null) {
    const theData = JSON.parse(sessionStorage.getItem("lastformdata"));
    sessionStorage.removeItem("lastformdata")	
    returnSelectValue('site', theData.site)
    returnSelectValue('job_number', theData.job_number)
    returnSelectValue('level', theData.level)
    returnSelectValue('supervisor', theData.supervisor)
    $('#workplace').val(theData.workplace)
    $(`#workplace`).next().addClass('active')
  }
}

function correctLabels() {
  let selects = document.querySelectorAll('select')
    for(let a=0; a < selects.length; a++) {
      let myLables = selects[a].parentNode.getElementsByTagName('label')
    }
}

function returnSelectValue(name, value)	 {
  // Try splitting
  var arrKeys = value.split('|')
  $(`#${name}`).val(arrKeys).trigger("change")
  $(`#${name}`).next().next().addClass('filled')
  return
}

function IsJsonString(str) {
  try {
      JSON.parse(str)
  } catch (e) {
      return false
  }
  return true
}
 
function checkIfLoggedIn() {
  // Checking if Logged in
  if(window.localStorage.getItem('token')){
      return true
    }
    else {
      return false
    }
}

function sync(db, syncTo) {
  if (syncTo) {
    var opts = { live: true, retry: true }
    // Configure synching
    // Handle and report sync (replication)
    db.replicate.to(syncTo, opts)
    // One way replicate (to only)
    .on('change', (change) => {
      // something changed
      if(debug) console.log('replicated form submitted to: ' + syncTo)
      if(debug) console.dir(change)
      var sessionSync = localStorage.getItem('sessionSync')
      // Retrieve the number of docs reported in the replication status from local storage
      sessionSync += change.docs_written
      // Increment our total
      localStorage.setItem('sessionSync', sessionSync)
      // Resave the count
    }).on('active', (info) => {
      // replication was resumed
      if(debug) console.log('replication was resumed to: ' + syncTo)
    }).on('paused', (info) => {
      // replication was paused, usually because of a lost connection or just inactive
      if(debug) console.log('replication paused: ' + syncTo)
    }).on('denied', (err) => {
        // replication was denied, usually because of a lost connection
      if(debug) console.log('Document failed to replicate (e.g. due to permissions): ' + err)
    }).on('completed', (info) => {
      // Replication was shut down, or, error
      if(debug) console.log('Replication has completed, connection closed: ' + syncTo)
    }).on('error', (err) => {
      // totally unhandled error (shouldn't happen)
      if(debug) console.log('Replication Error: ' + err)
    })
  }
  else {
      // We got passed a bad remote connection string
      if (debug) console.log('Nothing to sync to, please check configuration')
  }
}

Date.prototype.getWeek = function (dowOffset) {
    //default dowOffset to zero
    dowOffset = typeof(dowOffset) == 'int' ? dowOffset : 0
    var newYear = new Date(this.getFullYear(),0,1)
    //the day of week the year begins on
    var day = newYear.getDay() - dowOffset
    day = (day >= 0 ? day : day + 7)
    var daynum = Math.floor((this.getTime() - newYear.getTime() - 
    (this.getTimezoneOffset()-newYear.getTimezoneOffset())*60000)/86400000) + 1
    var weeknum
    //if the year starts before the middle of a week
    if(day < 4) {
        weeknum = Math.floor((daynum+day-1)/7) + 1
        if(weeknum > 52) {
            nYear = new Date(this.getFullYear() + 1,0,1)
            nday = nYear.getDay() - dowOffset
            nday = nday >= 0 ? nday : nday + 7
            /*if the next year starts before the middle of
              the week, it is week #1 of that year*/
            weeknum = nday < 4 ? 1 : 53
        }
    }
    else {
        weeknum = Math.floor((daynum+day-1)/7)
    }
    return weeknum
}

let clear = $('.clearButton').on('click', (e)=>{
  if (e.target.parentNode.parentNode.hasAttribute("required")){
    e.target.parentNode.parentNode.classList.add('invalid')
  }
})

const signatureModal = `<div class="modal fade" id="sigModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
  <div class="modal-dialog modal-notify modal-primary" role="document" >
    <div class="modal-content">
      <div class="modal-header">
        <p class="heading lead">Signature</p>
      </div>
      <div class="modal-body">
      <form method="post" action="" class="sigPadModal">
        <canvas id ='SignatureCanvas' class="border border-light rounded pad2"></canvas>
        <input type="hidden" name="output" class="output">
        <div class="text-center buttonArea"></div>
      </form>
    </div>
  </div>`

const modalStart = `<div class="modal fade" id="sigModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
  <div class="modal-dialog modal-notify modal-primary" role="document" >
    <div class="modal-content">
			<div class="modal-header">
  <p class="heading lead">`

const modalEnd = `</p>
        </div>
        <div class="modal-body">
        <form method="post" action="" class="sigPadModal">
          <canvas id ='SignatureCanvas' class="border border-light rounded pad2"></canvas>
          <input type="hidden" name="output" class="output">
          <div class="text-center buttonArea"></div>
        </form>
      </div>
    </div>`

function initializeSignatures () {
  if(!localStorage.getItem(`noinitialize`)) {
    $('.sign').on('click',(e) =>{
      e.stopPropagation();
      let mainButton = e.target
      // If clicked on span added with i18n
      if(mainButton.tagName.toLowerCase() == 'span') 
        mainButton = e.target.parentNode
      // If clicked on <i>
      if(mainButton.tagName.toLowerCase() == 'i') 
        mainButton = e.target.parentNode

      let target =  e.currentTarget.getAttribute('signaturename')    
      
      if (target == "rescue_sketch_draw"){
        signatureType = "<span class='translate' data-i18n='2376' notes='Draw'></span>"
        actionType = "<span class='translate' data-i18n='3297' notes='RE-DRAW'></span>"
      }
      else{
        signatureType = "<span class='translate' data-i18n='823' notes='Signature'></span>"
        actionType = "<span class='translate' data-i18n='2243' notes='RE-SIGN'></span>"
      }    

      $('#signature-modal').html(modalStart + signatureType + modalEnd)

      $(`#${target}`).val('')
      $(`#${target}_img`).val('')
      $('#sigModal').modal('show')
      
      activateSignature(target,mainButton)
      
      // Remove padding-right: 17px that is added to body for some unknown reason
      $('body').css({"padding-right": ""}); 

      // Set the canvas size on page load
      window.onload = pageOrientation;
      window.addEventListener("orientationchange", SignaturePageOrientation)

        function SignaturePageOrientation() {
          var canvasElement = document.querySelector("#SignatureCanvas")
          // Use timeout to delay the orientation check trigger
          setTimeout(() => {
            activateSignature(target,mainButton)
          }, 100)
        }
      })

    function activateSignature(target,mainButton){
          $('#sigModalOK').remove()
          $('.buttonArea').html(`<div class="btn btn-outline-primary py-2" id="reSignButton"><i class="fa fa-pen"></i> ` + actionType  + `</div> <div class='btn btn-primary  py-2' id='sigModalOK'> <span class='translate' data-i18n="2244" notes="DONE"></span> </div>`)
          setTimeout(()=>{
            $('canvas.pad2').attr({"width": $('.pad2').parent().width(),"height":$('.pad2').parent().width()/3});
                let sig = $('.sigPadModal').signaturePad(	{
              lineColour: "#ced4da",
              drawOnly: true,
              lineWidth: 0,
              lineBottom: 10,
              bgColour: 'rgb(255,255,255)'
            });
            sig.clearCanvas()

            document.getElementById(`sigModalOK`).addEventListener('click',(e) =>{ 
              e.stopPropagation();
              let vecValue = document.querySelector('.sigPadModal .output').value
              if(vecValue){
                  $(`#${target}`).val($(`.sigPadModal .pad2`)[0].toDataURL('image/jpeg'))
                  $(`#${target}`).next().val(vecValue)
                  $(`#${target}_img`).attr('src',$(`.sigPadModal .pad2`)[0].toDataURL('image/jpeg'))

                  img_notes = target + '_img_time'
                  time = moment(new Date()).format('YYYY-MM-DD hh:mm:ss a')
                  $(`[notes=${img_notes}]`)[0].value = time
                  $(`[notes=${img_notes}]`)[0].parentElement.classList.remove("d-none")

              } else {
                  $(`#${target}`).val('')
                  $(`#${target}`).next().val('')
                  $(`#${target}_img`).attr('src','')

                  img_notes = target + '_img_time'
                  $(`[notes=${img_notes}]`)[0].value = ""
                  $(`[notes=${img_notes}]`)[0].parentElement.classList.add("d-none")

              }

              $(`#sigModal .output`).val('')
              $('.modal-backdrop').remove()
              $('#sigModal').remove()
              $("body").removeClass("modal-open")
              const data = mainButton.innerHTML.split('(')[0].trim()
              if(vecValue) {
                mainButton.innerHTML = `<i class="fa fa-pen"></i> `  + actionType
                $(`#${target}`).prev().prev().children()[1].classList.remove('d-none') //  comment button
                $(`#${target}`).prev().prev().children()[0].classList.remove('invalid') //  sign button 
                if($(`#${target}`).prev().prev().children().length>2){
                  $(`#${target}`).prev().prev().children()[2].classList.remove('d-none') //clear button
                }
              } 
              else {  //no signature value
                $(`#${target}_photo`).val('')
                $(`#${target}_img`).attr('src','')
                $(`#${target}`).prev().prev().children()[1].classList.add('d-none')
                //if has comment button
                if($(`#${target}`).prev().prev().children().length>2){
                  $(`#${target}`).prev().prev().children()[2].classList.add('d-none') //hide "clear" button
                  $(`#${target}_comments`).val('') //remove comments
                  $(`#${target}`).prev().prev().children()[1].firstChild.classList.remove("fas") //remove filled comment icon
                  $(`#${target}`).prev().prev().children()[1].firstChild.classList.add("far") //add empty comment icon
                }
                if (target == "rescue_sketch_draw"){
                  signatureType = "<span class='translate' data-i18n='2376' notes='Draw'></span>"
                  actionType = "<span class='translate' data-i18n='2376' notes='Draw'></span>"
                }
                else{
                  signatureType = "<span class='translate' data-i18n='823' notes='Signature'></span>"
                  actionType = "<span class='translate' data-i18n='1396' notes='SIGN'></span>"
                } 
                mainButton.innerHTML = `<i class="fa fa-pen"></i> `  + actionType
              }            
              $('.translate').localize()
            })
            document.getElementById(`reSignButton`).addEventListener('click',(e) =>{
              let reSignTarget = e.target
              // If clicked on span added with i18n
              if(reSignTarget.tagName.toLowerCase() == 'span') 
                reSignTarget = e.target.parentNode
              // If clicked on <i>
              if(reSignTarget.tagName.toLowerCase() == 'i') 
                reSignTarget = e.target.parentNode

              canvas = reSignTarget.parentNode.previousElementSibling.previousElementSibling.previousElementSibling
              let sig = $('.sigPadModal').signaturePad(	{
                  lineColour: "#ced4da",
                  drawOnly: true,
                  lineWidth: 0,
                  lineBottom: 10,
                  bgColour: 'rgb(255,255,255)'
              });
              sig.clearCanvas()
            })
          },200)
          $('.translate').localize()
    }

    $(`.sign_comment`).click((e) =>{ 
      addSignatureComment(e) 
    })

    //click on clear_sign to open the confirmation modal
    $(`.clear_sign`).click((e) =>{ 
      if(e.currentTarget.parentNode.parentNode.querySelector('.sig_comment').value){
        delSig = new SofvieModal()
        delSig.setModalElements('danger', 'modalTitle', i18next.t("2748"))   //"Clear Signatures"
        delSig.setModalElements('danger', 'modalText', i18next.t("2781"))  //"Are you sure you want to remove the signature and associated comment from the form?"
        delSig.handleModal('danger')
        $(`.modal-footer .confirm`).click((event) => {
            clear_signature(e)
            $(`#theModal`).modal('hide')
        })
      }
      else {
        clear_signature(e)
      }
    })
  }
}

initializeSignatures()

function clear_signature(e){
  let target =  e.currentTarget.getAttribute('sketchname')
  if(e.target.tagName.toLowerCase() == 'span') // If clicked on span added with i18n
    e.target = e.target.parentNode
  if(e.target.tagName.toLowerCase() == 'i') // If clicked on <i>
    e.target = e.target.parentNode
  if (target == "rescue_sketch_draw"){
    signatureType = "<span class='translate' data-i18n='2376' notes='Draw'></span>"
    actionType = "<span class='translate' data-i18n='2376' notes='Draw'></span>"
    $(`[notes=${e.target.parentNode.nextElementSibling.id + '_time'}]`)[0].value = ""
    $(`[notes=${e.target.parentNode.nextElementSibling.id + '_time'}]`)[0].parentElement.classList.add("d-none")
  }
  else{
    signatureType = "<span class='translate' data-i18n='823' notes='Signature'></span>"
    actionType = "<span class='translate' data-i18n='1396' notes='SIGN'></span>"
    $(`[notes=${e.target.parentNode.nextElementSibling.id + '_time'}]`)[0].value = ""
    $(`[notes=${e.target.parentNode.nextElementSibling.id + '_time'}]`)[0].parentElement.classList.add("d-none")
  }
    e.target.previousElementSibling.previousElementSibling.innerHTML = '<i class="fa fa-pen"></i> ' + actionType 
    e.target.parentNode.nextElementSibling.setAttribute('src','')
    e.target.parentNode.nextElementSibling.nextElementSibling.value = ''
    e.target.parentNode.nextElementSibling.nextElementSibling.nextElementSibling.value = ''
    e.target.previousElementSibling.firstChild.classList.remove("fas")
    e.target.previousElementSibling.firstChild.classList.add("far")
    e.target.parentNode.nextElementSibling.nextElementSibling.nextElementSibling.nextElementSibling.value = ''
    e.target.classList.add('d-none')
    e.target.previousElementSibling.classList.add('d-none')
    if(e.target.parentNode.nextElementSibling.nextElementSibling.hasAttribute('required')){
      e.target.previousElementSibling.classList.add('invalid')
      e.target.previousElementSibling.previousElementSibling.classList.add('invalid')
    }
$('.translate').localize()
}

if(window.localStorage.getItem('refresh')) {
  LoadServiceworkerSofvie()
}

function addSignatureComment(e) {
  let target =  e.currentTarget.parentNode
  sigCommentElement=$(target).parent().find('.sig_comment')
  filledComment=sigCommentElement.val()
  let showDeleteButton = 'd-none'

  if (filledComment.length > 0){
    showDeleteButton = ''
  }
  
		const addSignatureCommentModal = 
		`
		<div class="modal" id="signatureNoteModal" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
          <div class="modal-dialog modal-notify modal-info" style="background-color: #0072ce;" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <p class="heading lead"><span class='translate' data-i18n="8915" notes="Signature Note"></p>
              </div>
              <div class="modal-body">
                <div class="md-form">
                  <textarea name="signatureComments" id="signatureComments" class="form-control md-textarea" length="1000" maxlength="4000" required></textarea>
                  <label for="signatureComments"><span class='translate' data-i18n="81" notes="Comments"></span></label>
                </div>
              </div>
			  <div class="modal-footer justify-content-center">
        <a role="button" class="btn btn-primary text-nowrap waves-effect waves-light ${showDeleteButton}" id="deleteSignatureComment" data-dismiss="modal"><span class='translate' data-i18n="3088" notes="Delete"></span></a>
          <a role="button" class="btn btn-primary text-nowrap waves-effect waves-light" id="cancelSignatureComment" data-dismiss="modal"><span class='translate' data-i18n="1257" notes="Cancel"></span></a>
          <a role="button" class="btn btn-primary text-nowrap waves-effect waves-light" id="savesignatureNoteModal" data-dismiss="modal"><span class='translate' data-i18n="1258" notes="Save"></span></a>
        </div>
			</div>
		  </div>
		</div>
    <div class="modal fade" id="signatureNotesVerificationModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
			<div class="modal-dialog modal-notify modal-danger" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<p class="heading lead"></p>
					</div>
					<div class="modal-body">
						<div class="text-center">
							<i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
							<p class='modal-body-text'></p>
						</div>
					</div>
					<div class="modal-footer justify-content-center">
					</div>
				</div>
			</div>
		</div>
		`

	$("#signatureNote")
	.empty()
	.append(addSignatureCommentModal);

	$('.translate').localize()
	$('#signatureComments').val(filledComment).trigger('change').parent().find('label').addClass('filled')
	$("#signatureNoteModal").modal("show")
  $("#deleteSignatureComment").click((event) => {
			comment_value= document.getElementById("signatureComments").value
			if(filledComment){
				comment_value=filledComment
        sigCommentElement.val(filledComment)
			}
			if(comment_value){
				const theElements = {
					modalTheme: `modal-danger`,
					modalAlert: `fa-times-circle`,
          // Delete Comments
					modalTitle: i18next.t("9009"),
          //You are about to delete this comment. Are you sure?
					modalText:  i18next.t("3455"),
					modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-danger waves-effect"><span class='translate' data-i18n="1257" notes="Cancel"></a>
					<a role="button" id='deleteCommentConfirm' class="px-1 flex-fill btn btn-danger waves-effect confirm"><span class='translate' data-i18n="3088" notes="Delete"></a>`
				}
				let pop = new SofvieModal()
				pop.modalSettings.danger = theElements 
				pop.handleModal('danger')
				if(filledComment){
					sigCommentElement.value= document.getElementById("signatureComments").value=filledComment
				}
				
				$('.translate').localize()
				$("#alertModalCancel").click(() => {
					closeModal(pop)
					$("#signatureNoteModal").modal("show");
				})
				$("#deleteCommentConfirm").click((event) => {
					event.preventDefault();
					event.stopImmediatePropagation();
					comment_value=sigCommentElement.value= document.getElementById("signatureComments").value=''
          sigCommentElement.val(null)
					e.currentTarget.firstChild.classList.remove("fas","far")
					e.currentTarget.firstChild.classList.add("far")
					closeModal(pop)
				})
			}
			else{
				$("#signatureNoteModal").modal("hide");
			}	
		})

  $("#cancelSignatureComment").click((event) => {	
    if(filledComment){
      comment_value=filledComment
      sigCommentElement.val(filledComment)
    }
    else{
      comment_value=document.getElementById("signatureComments").value=''
    }
  })    
  		
  $("#signatureComments").click(() => { 
			document.getElementById('signatureComments').classList.remove('invalid')
	})

	$("#savesignatureNoteModal").click((event) => {  
		sigCommentElement.val(document.getElementById("signatureComments").value)
    document.getElementById('signatureComments').classList.remove('invalid')
    event.preventDefault(); 
    if(document.getElementById('signatureComments').value == ''){
      event.preventDefault();
      event.stopImmediatePropagation();
      let formModal = new SofvieModal("signatureNotesVerificationModal");     
      formModal.handleModal(`validate`)   
			document.getElementById('signatureComments').classList.add('invalid')
      $('.translate').localize()
      $('.confirmValidation').click(()=>{
        closeModal(formModal)
      })
    }
    else{
      e.currentTarget.firstElementChild.classList.remove("fas")
      e.currentTarget.firstElementChild.classList.add("far")
      if(sigCommentElement.val()){
        e.currentTarget.firstElementChild.classList.remove("far")
        e.currentTarget.firstElementChild.classList.add("fas")
      }
    }
	})
}

function htmlEscape(htmlStr) {
  return htmlStr.replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;")
}

</script>
<script src="/js/translate.js"></script>

</body>
</html>
