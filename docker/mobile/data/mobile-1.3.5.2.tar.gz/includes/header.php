<?php 
	//SJB: 20190726111900 - Added local cache name and Debug to come from config 
	//SJB: 20190809142000 - PouchDB record deletion threshold.

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, maximum-scale=1, user-scalable=0">
	<title>Sofvie - Mobile</title>

  <link href="<?php echo _RESOURCEDOMAIN; ?>/img/favicon.png" rel="icon" type="image/png">
  <link href="<?php echo _RESOURCEDOMAIN; ?>/css/all.min.css " rel="stylesheet"> <!-- Font Awesome -->
  <link href="<?php echo _RESOURCEDOMAIN; ?>/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo _RESOURCEDOMAIN; ?>/css/mdb-mobile.min.css" rel="stylesheet">
  <link href="<?php echo _RESOURCEDOMAIN; ?>/css/select2.min.css" rel="stylesheet">
  <link rel="apple-touch-icon" href="<?php echo _RESOURCEDOMAIN; ?>/img/sofvie-icon-4x.png" type="image/png">
  <script type="text/javascript" src="/js/moment.min.js"></script>
  <script type="text/javascript" src="/env/mobileenv.js"></script>
  <script type="text/javascript" src="/js/keycloak.min.js"></script>
  <script type="text/javascript" src="/locales/pickadate/languages.js"></script>
  <script type="text/javascript" src="/locales/pickatime/languages.js"></script>
  <script type="text/javascript" src="/locales/select2/languages.js"></script>
	  <link rel="manifest" href="/manifest.json">
</head>
<body class="bg-light">
<script type="text/javascript">
var _DOMAIN = '<?php echo _DOMAIN ;?>';
var _SYNCDOMAIN = '<?php echo _SYNCDOMAIN;?>';
var _SYNCPORT = '<?php echo _SYNCPORT; ?>';
var _SYNCCOUCHDB = '<?php echo _SYNCCOUCHDB; ?>';
var _DOCUMENT_URL = '<?php echo _DOCUMENT_URL; ?>';
var _DEBUG = <?php echo _DEBUG ?>;
var debug = _DEBUG
var _POUCHDB_DELETE_THRESHOLD_DAYS = <?php echo _POUCHDB_DELETE_THRESHOLD_DAYS?>;
</script>
<div id='parentpage' url='<?php echo _TOOLBOX; ?>'></div> <!-- SOF-12722 Mobile - Submissions - Change to landing page -->