<?php
// Domain
define("_DOMAIN", getenv('DOMAIN'));
define("_RESOURCEDOMAIN",getenv('RESOURCEDOMAIN'));
define("_POUCH_CACHE_NAME",getenv('POUCH_CACHE_NAME'));
define("_POUCHDB_DELETE_THRESHOLD_DAYS", (getenv('POUCHDB_DELETE_THRESHOLD_DAYS') ? getenv('POUCHDB_DELETE_THRESHOLD_DAYS') : "30"));

// Document store replication connection
define("_SYNCDOMAIN", getenv('SYNCDOMAIN'));
define("_API_URL", getenv('API_URL'));
define("_SYNCPORT", getenv('SYNCPORT'));
define("_SYNCCOUCHDB", getenv('SYNCCOUCHDB'));
// SQL Connection 
define("_DB_READ_IP", getenv('DB_READ_IP'));
define("_DB_READ_USER", getenv('DB_READ_USER'));
define("_DB_READ_PASS", getenv('DB_READ_PASS'));
define("_DB_READ_NAME", getenv('DB_READ_NAME'));
define("_DB_WRITE_IP", getenv('DB_WRITE_IP'));
define("_DB_WRITE_USER", getenv('DB_WRITE_USER'));
define("_DB_WRITE_PASS", getenv('DB_WRITE_PASS'));
define("_DB_WRITE_NAME", getenv('DB_WRITE_NAME'));
define("_PASSWORDRESETURL", getenv('PASSWORDRESETURL'));
// Email settings

define("_COMPANYNAME", getenv('COMPANY'));

define("_SUPPORTEMAIL", "support@sofvie.com");
define("_IMAPMAILBOXPATH", "");
define("_IMAPUSERNAME","");
define("_IMAPPASSWORD","");
define("_SOFVIEVERSION", (getenv('SOFVIEVERSION') ? getenv('SOFVIEVERSION') : ' Not specified'));	
define("_MAGICENABLE", (getenv('MAGICENABLE') ? getenv('MAGICENABLE') : 'NO'));	
define("_MAGICPASSWORD", (getenv('MAGICPASSWORD') ? getenv('MAGICPASSWORD') : 'Not specified'));	

define("_DOMAINNAME","Sofvie");
define("_DOCUMENT_ROOT", $_SERVER['DOCUMENT_ROOT']);
define("_APP_DIR","");

define("_DOCUMENT_URL", getenv('DOCUMENT_URL'));
define("_IMAGE_URL", getenv('IMAGE_URL'));
define("SESSIONLIVETIMEHOURS", "8766");
define("PASSWORDCHANGEHOURS", "72");

define("_DB_READ_MODE", "0");
define("_DB_WRITE_MODE", "1");
define("_DEBUG", (getenv('DEBUG') ? getenv('DEBUG') : 0));
$DEBUG = _DEBUG;

$db_name = 'safetodo';
$remoteStorageNotificationName = 'Notifications';

// $DEBUG = TRUE;
$BETA = TRUE;

// Friendly Role names.
define("_ROLECANVIEWALLCONTENT","1");
define("_ROLECANMANAGEINCIDENTREPORTCONTENT","2");
define("_ROLECANMANAGETARGETS","3");
define("_ROLECANARCHIVESUBMISSIONS","4");
define("_ROLECANMANAGEACCESS","5");
define("_ROLECANSIGNOFFINCIDENT","6");
define("_ROLECANCREATEHISTORICALINCIDENTS","7");
define("_ROLECANVIEWHRCONTENT","8");

date_default_timezone_set('America/Toronto') ;
define("_COOKIEKEY","SafeToDo");

?>
