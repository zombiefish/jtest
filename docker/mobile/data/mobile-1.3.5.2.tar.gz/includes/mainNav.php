<aside id="slide-out" class="d-flex flex-column blue side-nav mobile">
  <div class="user-info blue collapsed waves-effect waves-light pl-3 pr-4 py-3 z-depth-1-half flex-shrink-0" data-toggle="collapse" href="#user_menu">
    <i class="fa fa-angle-up mr-3 rounded-circle mr-3 px-2 py-1 primary-color-dark"></i>
    <h5 class="text-truncate d-block font-weight-bold" id='navEmployeeName'></h5>
    <span class="text-truncate d-block " id='navEmployeeEmail'></span>
  </div>
  <nav class="flex-grow-1 scrollbar">
    <ul class="nav flex-column collapsible collapsible-accordion pb-4">
      <div id="user_menu" class="collapse blue darken-2">
        <li>
          <a class="collapsible-header waves-effect waves-light disable-offline" href="<?php echo _SETTINGS ?>">
            <i class="fa fa-user-cog fa-fw"></i> 
            <span class='translate' data-i18n="3098" note="Settings"></span>            
          </a>
        </li>
        <li>
          <a class="collapsible-header waves-effect waves-light disable-offline" href="https://learn.sofvie.com" target="_blank">
            <i class="fa fa-question-circle fa-fw"></i> <span class='translate' data-i18n="1292" note="Knowledge Base"></span>
          </a>
        </li>
        <li>
          <a class="collapsible-header waves-effect waves-light disable-offline" href="<?php echo _HELP ?>">
            <i class="fa fa-envelope-open-text fa-fw"></i> 
            <span class='translate' data-i18n="3099" note="Provide Feedback"></span>            
          </a>
        </li>
        <li>
          <a class="collapsible-header waves-effect waves-light disable-offline" onclick ="mobileChangePassword()">
            <i class="fa fa-lock fa-fw"></i> <span class='translate' data-i18n="8700" note="Reset Password"></span>
          </a>
        </li>
        <li>
          <a class="collapsible-header waves-effect waves-light" href="<?php echo _TERMS ?>">
            <i class="fa fa-book fa-fw"></i> <span class='translate' data-i18n="1302" note="Terms and Conditions"></span>
          </a>
        </li>
        <li>
          <a class="collapsible-header waves-effect waves-light primary-color-dark" id="SignOut"  disabled>
            <i class="fa fa-sign-out-alt"></i> <span class='translate' data-i18n="1293" note="Sign out"></span>
          </a>
        </li>
      </div>
      <li>
		    <a class="collapsible-header waves-effect waves-light mt-2" href="<?php echo _DEFAULT ?>">
			    <i class="fa fa-home fa-fw"></i> 
          <span class='translate' data-i18n="3100" note="Home"></span>
		    </a>
      </li>
      <li>
        <a class="collapsible-header waves-effect waves-light" href="<?php echo _ACTIONITEMS ?>">
          <i class="fa fa-calendar-alt fa-fw"></i> <span class='translate' data-i18n="1037" note="Action Items"></span>
        </a>
      </li>
      <li>
        <a class="collapsible-header waves-effect waves-light" href="<?php echo _DOCUMENTS ?>">
          <i class="fa fa-folder-open fa-fw"></i> <span class='translate' data-i18n="1344" note="Documents"></span> 
        </a>
      </li>
      <li>
        <a class="collapsible-header waves-effect waves-light" href="<?php echo _HAZARDINCIDENTMANAGEMENT ?>">
          <i class="fa fa-fire-extinguisher fa-fw"></i> <span class='translate' data-i18n="1357" note="Hazard & Incident Management"></span> 
        </a>
      </li>
      <li>
        <a class="collapsible-header waves-effect waves-light" href="<?php echo _PROFILE ?>">
          <i class="fa fa-address-card fa-fw"></i> <span class='translate' data-i18n="990" note="My Profile"></span>
        </a>
      </li>
      <li>
        <a class="collapsible-header waves-effect waves-light" href="<?php echo _RISKASSESSMENT ?>">
          <i class="fa fa-exclamation-triangle fa-fw"></i> <span class='translate' data-i18n="1358" note="Risk Assessment"></span> 
        </a>
      </li>
      <li>
        <a class="collapsible-header waves-effect waves-light" href="<?php echo _SAFETYTRENDS ?>">
          <i class="fa fa-chart-pie fa-fw"></i> <span class='translate' data-i18n="1359" note="Safety Trends"></span>
        </a>
      </li>
      <li>
        <a class="collapsible-header waves-effect waves-light" href="<?php echo _TOOLBOX ?>">
          <i class="fa fa-toolbox fa-fw"></i> <span class='translate' data-i18n="977" note="Toolbox"></span>
        </a>
      </li>
  </ul>
  </nav>

</aside> 
<input type="hidden" id="selected-language"/>

<script type="text/javascript" src="/js/jquery.min.3.6.0.js"></script>
<script type="text/javascript" src="<?php echo _RESOURCEDOMAIN; ?>/js/popper.min.js"></script>
<?php
include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/offlineDataLoad.php");
?>

<script src="<?php echo _RESOURCEDOMAIN; ?>/js/pouchdb.min.js"></script>
<script src="<?php echo _RESOURCEDOMAIN; ?>/js/pouchdb.find.js"></script>

<script>
const _EMPLOYEE = 2
const _TRAINING = 3
const _EMPLOYEEVIEWPOINT = 10
const _CERTIFICATION = 11
const _DISCIPLINES = 12
const _RECOGNITION = 13
const _REVIEW = 0
const _FORMACCESS = 9
const _MOBILESETTINGS = 32
let preop_current_draft_object = null
let main_current_draft_object = null
const _PREVENTFUTUREDATES = ['/forms/formPreliminaryIncident.php', '/forms/formPreliminaryInvestigation.php', '/pages/ActionItems.php']

let mobileFrame = window.sessionStorage.getItem('mobileFrame') ? window.sessionStorage.getItem('mobileFrame') === 'true' : false
let fromApp = mobileFrame

if(fromApp) {
  mobileFrame = true
  window.sessionStorage.setItem('mobileFrame', true)
}

window.addEventListener('message', function (e) {
  if(e.data && e.data !== 'supported' && e.data != 'changed' && e.data != 'unchanged' && e.data.substring(0,4) !== 'http') {
    let message = JSON.parse(e.data)
    if(message.name == "mobile-form-id") {
      let formId = message.data.mobileFormId
      let formData = JSON.parse(JSON.stringify(remoteData[9].FormAccess))

      for (let i = 0; i < formData.length; i++) {
        if(formData[i].FormID == formId) {
          window.location.href = formData[i].FormUrl
          if(message.data.incidentId){
            let incidentId = message.data.incidentId
            window.sessionStorage.setItem('incidentId', incidentId)
          }
          if(message.data.moduleId){
            let moduleId = message.data.moduleId
            window.sessionStorage.setItem('moduleId', moduleId)
          }
          break
        }
      }
    }
  }
})

function putNavName() {
  document.getElementById('navEmployeeName').innerHTML = remoteData[_EMPLOYEE].Employee[0].per_full_name
  document.getElementById('navEmployeeEmail').innerHTML = remoteData[_EMPLOYEE].Employee[0].email
}

let mobileTheme = ''
if(window.localStorage.getItem('mobileTheme')){
  	document.body.classList.remove('dark-theme')
    mobileTheme = window.localStorage.getItem('mobileTheme')
}
else {
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      mobileTheme = 'dark-theme'
  }
  else {
      mobileTheme = 'light-theme'
  }
	mobileTheme = window.localStorage.setItem('mobileTheme', mobileTheme)  
}

if(mobileTheme)
document.body.classList.add(mobileTheme)

function changeTheme(element) {
    if (mobileTheme === 'dark-theme') {
      mobileTheme = 'light-theme'
      document.body.classList.remove('dark-theme')
      document.body.classList.add(mobileTheme)
      element.innerHTML = `<i class="fa fa-moon fa-fw"></i> Change to Dark Theme`
    }
    else {
      mobileTheme = 'dark-theme'
      document.body.classList.remove('light-theme')
      document.body.classList.add(mobileTheme) 
      element.innerHTML = `<i class="fa fa-sun fa-fw"></i> Change to Light Theme`
    }
    window.localStorage.setItem('mobileTheme',mobileTheme)
}

function checkIfMobileOnline () {
  $.ajaxSetup({ cache: false })
  return new Promise((resolve, reject) => {
    if(window.localStorage.getItem('token')){
      accesstoken = JSON.parse(window.localStorage.getItem('token')).access
    }
    else {
      accesstoken = "1234567890"
    }
    $.ajax({
      // Check mobile checks to see if you have access to use Mobile APP
      url: `<?php echo _API_URL ?>/api/user/check-mobile/`,
      type: 'get',
      contentType: 'application/json',
      beforeSend: function(request) {
        request.setRequestHeader("Authorization", `Bearer ${accesstoken}`)
      },
      success: (data) => {
        resolve(true)
      },
      error: (data) => {
        if(data.statusText === 'Unauthorized') {
          window.location = "/login.html"
        }
        else {
          resolve(false)
        }
      }
    })
  })
}

async function checkOnline() {
  return await checkIfMobileOnline ()
}

function loadToolboxPageOffline() {
  config = {		// Define some config itmes
  draftDbName: 'sofvie_drafts', 	// db name for draft storage
  draftRemoteSync: false,		// Sync path for draft, false for none
  commitDBName: _SYNCCOUCHDB, 	// Committed db name
  commitRemoteSync: `${_SYNCDOMAIN}:${_SYNCPORT}/${_SYNCCOUCHDB}`// Sync path for committed, false for none
  }
  const db = new PouchDB(config.commitDBName, { auto_compaction: true })
  // Start i18Next for Translations
  openCacheData().then((rdata)=>{
    localStorage.removeItem(`noinitialize`)
    formData = JSON.parse(JSON.stringify(rdata[_FORMACCESS].FormAccess))
    finalFormData = specialFormPermission(formData)
    finalFormData=finalFormData.sort((a,b) => a.category > b.category ? 1 : b.category>a.category ? -1 : 0)  //Sort by Category
    populatePage(rdata, dbDraft, db)
    initializeI18N()
    $("#footerSpinner").addClass('d-none')
  })
}

function loadJRAPageOffline() {
  openCacheData().then((rdata)=>{
    populatePage(JSON.parse(JSON.stringify(rdata)), rmmDbDraft, dbSofvieForm)
    localStorage.removeItem(`noinitialize`)
    initializeI18N().then(() => {
      $("#footerSpinner").addClass('d-none')
    })
  })
}

//Disable buttons for pages that wont function offline
checkOnline().then((online)=>{
  if(!online) {
    let elements = document.getElementsByClassName("disable-offline")
  for (let i = 0; i < elements.length; i++) {
    elements[i].href = "#";
    elements[i].target = ""
    elements[i].style.backgroundColor  = "transparent"
    elements[i].style.opacity = "0.2"
  }
  document.getElementById("SignOut").style.opacity = "0.2"
  }
}).catch((err)=>{
  console.log("Online Error", err)
})

var now = new Date()
now.setFullYear( now.getFullYear() + 2 )

function checkLotoPermission(){
		let len = remoteData[9].FormAccess.length
		for(let a = 0;a < len; a++ ){
			let obj = remoteData[9].FormAccess[a]
			if (obj.FormID == 372468){    //'Lockout / Tagout'
				return true
			}
		}
  return false
}

// authentication 
let keycloak = Keycloak('/js/keycloak.json')
checkOnline().then((online)=>{
  if(online) {
   keycloak.init({  onLoad: 'check-sso',
                    silentCheckSsoRedirectUri: window.location.origin + '/silent-sso.html',
                }).then((authenticated) => {
      if(authenticated){
        keycloak.loadUserInfo().then((user)=> {
          keycloak.updateToken(18000).then((token)=>{
            sessionId = keycloak.sessionId
            window.localStorage.setItem('sso_session_id', sessionId)
            session_token = {
              "access": keycloak.token,
              "refresh" : keycloak.refreshToken,
              "user_full_name" : user.name,
              "email":user.email
            }
            window.localStorage.setItem('token', JSON.stringify(session_token))
            // Clearing legacy sessions after login and on every page naviagtion to fix the 502 Bad gateway issue
            if(!window.sessionStorage.getItem('mobileFrame')){
              let payload = {
						    "session_id": sessionId
					    }
              $.ajax({
                url: `${__env.apiUrl}/api/user/clear-legacy-session-sso/`,
                type: 'delete',
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify(payload),
                beforeSend: function(request) {
                  request.setRequestHeader("Authorization", `Bearer ${keycloak.token}`)
                },
                success: (res) => {
                },
							  error: (data) => {
								  console.log("Error on clearing legacy sessions")
							  }
					    })
            }
            document.cookie = `userid=${user.email}; expires= ${now.toUTCString()}`

            if(!cookieExist('lang')){
              setLanguageCookieFromUserProfile(keycloak.token)
            }

            window.localStorage.setItem('token', JSON.stringify(session_token))
            if(window.location.pathname === '/index.php' && !window.localStorage.getItem('loadedflag')) {
              if(window.sessionStorage.getItem('mobileFrame')) {
                  getOfflineDataAPP()
                }else {
                  getOfflineData()
                }
            }
            else {
              if(window.location.pathname === '/index.php') {
                if(window.sessionStorage.getItem('mobileFrame')) {
                  getOfflineData()
                }
                else {
                  let token = ""
                  let languageCookie = getCookie("lang")
                  $.ajaxSetup({ cache: false })
                  let allCurrentRecords = []
                  openCacheData().then(()=>{
                    allCurrentRecords = remoteData[27].DocumentReview
                    // Check to see if the Language Changed
                    if(remoteData[32].UserSettingsProfile[0].upr_language !== languageCookie){
                      userLang = remoteData[32].UserSettingsProfile[0].upr_language
                      document.cookie = `lang=${userLang}; expires= ${now.toUTCString()}`
                      window.location.href = `/index.php`
                    }
                    // Load the Notification Badges
                    loadToolboxToDo()
                    loadAssignedActionItems()
                    loadProfileTrainingRecords()
                    loadDocuments()     
                    loadAddonModulePermission()
                    let mobileTheme = ''
                    if(remoteData[_MOBILESETTINGS].UserSettingsProfile) {
                      mobileTheme = `${remoteData[_MOBILESETTINGS].UserSettingsProfile[0].upr_theme_mobile}-theme`
                    }
                    // set the theme from the Settings
                    localStorage.setItem('mobileTheme',mobileTheme)
                    // if it is set to default them take the setting from the browser
                    if(mobileTheme === "default"){
                      localStorage.setItem('mobileTheme','light-theme')
                      if(window.matchMedia('(prefers-color-scheme: dark)').matches){
                        localStorage.setItem('mobileTheme','dark-theme')
                      }
                    }

                    if(localStorage.getItem('mobileTheme'))
                    {
                      document.body.classList.remove('dark-theme')
                      document.body.classList.remove('light-theme')
                      document.body.classList.add(mobileTheme)
                    }

                      
                    if(checkLotoPermission()){
                      // get the loto equipments
                      getLOTOEquipmentData()
                      // get the loto procedures
                      getLOTOAttachmentData()
                    }
                    $("#indexSpinner").addClass('d-none')
                  })
                }
              }
            }

            if(window.location.pathname === '/pages/Toolbox.php') {
              loadToolboxPage()
              $("#indexSpinner").addClass('d-none')
            }

            if(window.location.pathname === '/pages/RiskAssessment.php') {
              loadJRAPage()
              $("#indexSpinner").addClass('d-none')
            }

          })
        })
      }
      else{
        window.localStorage.removeItem('token')
        window.location.pathname === '/login.html'
      }
    }).catch((err) => {
      console.log('failed to initialize', err)
    })
   }
  else{
    if(window.location.pathname === '/index.php')
    {
      openCacheData().then((rdata)=>{
      loadToolboxToDo()
      loadAssignedActionItems()
      loadProfileTrainingRecords()
      loadDocuments()
      $("#indexSpinner").addClass('d-none')
      $('.online_status .fa-ban').removeClass('d-none')
      $('.online_status .fa-sync-alt').addClass('d-none')
    })
    }

    if(window.location.pathname === '/pages/Toolbox.php') {
        loadToolboxPageOffline()
    }

    if(window.location.pathname === '/pages/RiskAssessment.php') {
        loadJRAPageOffline()
    }
  }
})





function mobileChangePassword()
  {
    $.ajaxSetup({ cache: true})
    $.ajax({
      // Check mobile checks to see if you have access to use Mobile APP
      url: `${__env.apiUrl}/api/user/change-password/`,
      type: 'get',
      contentType: 'application/json',
      beforeSend: function(request) {
        request.setRequestHeader("Authorization", `Bearer ${keycloak.token}`)
      },
      success: (data) => {
        pwReset = new SofvieModal()
        pwReset.setModalElements('success', 'modalTitle', i18next.t("1290")) //change password
        pwReset.setModalElements('success', 'modalText', `${i18next.t("3895")} ${remoteData[_EMPLOYEE].Employee[0].email}`) // We have emailed your password reset link to
        pwReset.handleModal('success')
      },
      error: (data) => {
        console.log("An error has occured", err)
      }
    })
}

function cookieExist(name) {
  const value = `; ${document.cookie}`
  const parts = value.split(`; ${name}=`)
  if (parts.length === 2) return parts.pop().split(';').shift()
}

function setLanguageCookieFromUserProfile(AccessToken) {
  $.ajax({
    url: `${__env.apiUrl}/api/userprofile/get-person-profile/${selectedLanguage?selectedLanguage:'en'}/`,
    type: 'get',
    dataType: 'json',
    contentType: 'application/json',
    beforeSend: (request) => {
    request.setRequestHeader("Authorization", `Bearer ${AccessToken}`)
    },
    success: (data) => {
      $.ajax({
        url: `${__env.apiUrl}/api/settings/get-user-profile/${data[0].per_id}/`,
        type: 'get',
        dataType: 'json',
        contentType: 'application/json',
        beforeSend: (request) => {
        request.setRequestHeader("Authorization", `Bearer ${AccessToken}`)
        },
        success: (settingsData) => {
          userLang = settingsData.upr_language ? settingsData.upr_language :'en'
          document.cookie = `lang=${userLang}; expires= ${now.toUTCString()}`
          window.location.href = `/index.php`
        },
        error: (data) => {
          // DISABLE THE SPINNER FAIL
          document.cookie = `lang=en; expires= ${now.toUTCString()}`
          window.location.href = `/index.php`          
          $("#loginSpinner").addClass('d-none')
        }
      })
  },
  error:(data) => {
    // DISABLE THE SPINNER FAIL
    $("#loginSpinner").addClass('d-none')
  }
  })
}

let groupBy = (xs, key) => {
  return xs.reduce(function(rv, x) {
    (rv[x[key]] = rv[x[key]] || []).push(x) 
    return rv 
  }, {}) 
};
</script>

