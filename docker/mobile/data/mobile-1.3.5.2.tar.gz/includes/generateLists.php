<?php
header('Content-Type: application/json');
header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
$Database = new DBManager();
$myconn = $Database->dbConnect(_DB_READ_MODE);
$pdoConn = $Database->connection;
$listarray = array();
$selectedLanguage = $_COOKIE["lang"];
$ErrorsInGenerateLists = [];

function errorMessage($e){
	if(_DEBUG) {
		array_push($GLOBALS['ErrorsInGenerateLists'],$e);
	}
}

// Get all ref list details
try{
	$statement = $pdoConn->prepare("CALL " . _DB_READ_NAME . "." . "get_ref_list_by_name('', :language)");
	$statement->bindValue(':language', $selectedLanguage);
	$statement->execute();
	$data = $statement->fetchAll(PDO::FETCH_ASSOC);
	foreach($data as $i => $i_value) {
		$i_value['rlh_name'] = trim($i_value['rlh_name']);

		if(array_key_exists($i_value['rlh_name'], $listarray)) {
			array_push($listarray[$i_value['rlh_name']], $i_value);
		} else {
			$listarray[$i_value['rlh_name']] = [$i_value];
		}			
	}	
}  
catch (PDOException $e) {
	errorMessage($e);
}

// Get Distribution List
try{
	$statement = $pdoConn->prepare("CALL " . _DB_READ_NAME . "." . "get_distribution_list()");
	$statement->execute();
	$data = $statement->fetchAll(PDO::FETCH_ASSOC);
	$listarray['distributionList'] = $data;
}  
catch (PDOException $e) {
    errorMessage($e);
}

// Get the List of Languages
try{
	$statement = $pdoConn->prepare("CALL " . _DB_READ_NAME . "." . "get_language_list()");
	$statement->execute();
	$data = $statement->fetchAll(PDO::FETCH_ASSOC);
	$listarray['languages'] = $data;
}  
catch (PDOException $e) {
    errorMessage($e);
}

// Get the custom lists
try{
	$statement = $pdoConn->prepare("CALL " . _DB_READ_NAME . "." . "get_custom_list_details(:language)");
	$statement->bindValue(':language', $selectedLanguage);
	$statement->execute();
	$data = $statement->fetchAll(PDO::FETCH_ASSOC);
	$listarray['customLists'] = $data;
}  
catch (PDOException $e) {
    errorMessage($e);
}




$listarray['ErrorsInGenerateLists'] = $ErrorsInGenerateLists;


echo json_encode($listarray);

$Database->dbClose();
?>
