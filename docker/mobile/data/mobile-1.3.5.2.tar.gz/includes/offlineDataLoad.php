<script>

	let remoteData = null
	let selectListData = null
	let userSiteData = null
	let userJobData = null
	let jraProjectData = null
	let jraApplicableLineItemsData = null
	let userLineupData = []
	let userSupervisorSelectData = null
	let userEmployeeSelectData = null
	let userEmployeeIncludingDisabledSelectData = null
	let userDistributionSelectData = null
	let jraBluelinesData = []
	let distributionGroupList = []
	// Disable caching on Ajax requests
    $.ajaxSetup({ cache: false })

	// Delete old cache. Can remove after 1.3.1 release
	caches.delete('SafeToDoCache-v1')
	// Delete old local storage. Can remove after 1.3.1 release
	window.localStorage.removeItem('remoteData')
	window.localStorage.removeItem('selectLists')
	window.localStorage.removeItem('jobselectLists')
	window.localStorage.removeItem('employeeSelectList')
	window.localStorage.removeItem('supervisorSelectList')
	window.localStorage.removeItem('distributionSelectList')
	window.localStorage.removeItem('rmmApproversSelectList')
	window.localStorage.removeItem('siteselectLists')

	let access = ""
	if(window.localStorage.getItem('token'))
		access = JSON.parse(localStorage.getItem('token')).access
	
	function remoteCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('cacheloaded')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _DOMAIN ?>/ajax/getRemoteData.php').then(res => res.json()).then((r) => {
							remoteData = r
							resolve(r)
							clearInterval(cacheInterval)
							putNavName()
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function selectCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('selectcacheloaded')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _DOMAIN ?>/includes/generateLists.php').then(sel => sel.json()).then((s) => {
							selectListData = s
							resolve(s)
							clearInterval(cacheInterval)
					}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function userSiteDataCachePromise (per_id) {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('usersitesloaded')) {
					caches.open('SofvieCache').then((res)=>{
						res.match(`<?php echo _API_URL ?>/api/master-ref-list/get-user-site/${per_id}/`).then(sel => sel.json()).then((s) => {
							userSiteData = s.Sites
							resolve(s)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function userJobDataCachePromise (per_id) {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('userjobsloaded')) {
					caches.open('SofvieCache').then((res)=>{
						res.match(`<?php echo _API_URL ?>/api/master-ref-list/get-user-job/${per_id}/`).then(sel => sel.json()).then((j) => {
							userJobData = j.Jobs
							resolve(userJobData)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function userSupervisorSelectCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('supervisorSelectListloaded')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _API_URL ?>/api/employee/get-employee-list-uv/supervisor/').then(sel => sel.json()).then((s) => {
							userSupervisorSelectData = s.Employee_list
							resolve(userSupervisorSelectData)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function userEmployeeIncludingDisabledSelectCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('employeeIncludingDisabledSelectListloaded')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _API_URL ?>/api/employee/get-employee-list-uv/include-disable/').then(sel => sel.json()).then((s) => {
							userEmployeeIncludingDisabledSelectData = s.Employee_list
							resolve(userEmployeeIncludingDisabledSelectData)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function userEmployeeSelectCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('employeeSelectListloaded')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _API_URL ?>/api/employee/get-employee-list-uv/all/').then(sel => sel.json()).then((s) => {
							userEmployeeSelectData = s.Employee_list
							resolve(userEmployeeSelectData)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function userDistributionSelectCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('distributionSelectListloaded')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _API_URL ?>/api/employee/get-employee-list-uv/distribution/').then(sel => sel.json()).then((s) => {
							userDistributionSelectData = s.Employee_list
							resolve(userDistributionSelectData)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function userRmmApproversSelectCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {				
				if(localStorage.getItem('rmmApproversSelectListloaded')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _API_URL ?>/api/employee/get-employee-list-uv/rmm-jra/').then(sel => sel.json()).then((s) => {
							userRmmApproversSelectData = s.Employee_list
							resolve(userRmmApproversSelectData)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function userLineupCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('distributionSelectListloaded')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _API_URL ?>/api/lineup/get-lineup-user-data/').then(sel => sel.json()).then((lineups) => {
							userLineupData = lineups
							resolve(userLineupData)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function jraProjectCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('JraBluelinesloaded')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _API_URL ?>/api/rmm/jra-pra-title-list/').then(sel => sel.json()).then((jra) => {
							jraProjectData = jra.data
							resolve(jraProjectData)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function jraBluelineCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('JraBluelinesloaded')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _API_URL ?>/api/rmm/jra-bluelines/').then(sel => sel.json()).then((jraBlueline) => {
							OraBluelineData = jraBlueline.rmm_ora_bluelines
							PraBluelineData = jraBlueline.rmm_pra_bluelines
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function jraApplicableLineItemsCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('JraPraThreatListloaded')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _API_URL ?>/api/rmm/jra-pra-threat-list/').then(sel => sel.json()).then((jra) => {
							jraApplicableLineItemsData = jra.data
							resolve(jraApplicableLineItemsData)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function generalActionAttachmentsCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('generalActionAttachment')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _API_URL ?>/api/ga/get-general-action-attachment/').then(sel => sel.json()).then((att) => {
							generalActionAttachment = att
							resolve(generalActionAttachment)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function hazardActionAttachmentsCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('hazardActionAttachment')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _API_URL ?>/api/ha/get-hazard-action-attachment/').then(sel => sel.json()).then((att) => {
							hazardActionAttachment = att
							resolve(hazardActionAttachment)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function lotoAttachmentsCachePromise () {
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('lotoProceduresAttachment')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _API_URL ?>/api/loto/get-all-loto-procedure/').then(sel => sel.json()).then((att) => {
							lotoProceduresAttachment = att
							resolve(lotoProceduresAttachment)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function lotoEquipmentPicsCachePromise() {

		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(localStorage.getItem('lotoEquipmentPics')) {
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _API_URL ?>/api/loto/get-equipment-picture/').then(sel => sel.json()).then((att) => {
							lotoEquipmentPics = att
							resolve(lotoEquipmentPics)
							clearInterval(cacheInterval)
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}	

	function refreshCachePromise () {
		sessionStorage.setItem('startingcache', 'True')
		return new Promise(function (resolve) {
			let cacheInterval =  setInterval(() => {
				if(sessionStorage.getItem('refreshloaded')) {
					sessionStorage.removeItem('refreshloaded')
					caches.open('SofvieCache').then((res)=>{
						res.match('<?php echo _DOMAIN ?>/ajax/getRemoteData.php').then(res => res.json()).then((r) => {
							res.match('<?php echo _DOMAIN ?>/includes/generateLists.php').then(sel => sel.json()).then((s) => {
							selectListData = s
							remoteData = r
							sessionStorage.removeItem('startingcache')
							resolve(r)
							clearInterval(cacheInterval)
							putNavName()
							}).catch((err)=>{console.log(err)})
						}).catch((err)=>{console.log(err)})
					}).catch((err)=>{console.log(err)})
				}
			}, 100)
		})
	}

	function getUserSites(remoteData) {
		$.ajaxSetup({ cache: false })
		getUserSiteUrl = "<?php echo _API_URL ?>" + "/api/master-ref-list/get-user-site/" + remoteData[_EMPLOYEE].Employee[0].per_id+"/"
		return new Promise(resolve =>{
			$.ajax({
				url: getUserSiteUrl,
				type: 'get',
				dataType: 'json',
				contentType: 'application/json',
				beforeSend: function(request) {
					request.setRequestHeader("Authorization", `Bearer ${access}`)
				},
				data: {},
				success: function (data) {
					localStorage.setItem('usersitestate','true')
					localStorage.setItem('usersitesloaded', 'true')
					resolve(data)
				},
				error: function (data) {
					// DISABLE THE SPINNER FAIL
				}
			})
		})
	}

	function getUserJobs(remoteData) {
		$.ajaxSetup({ cache: false })
		getUserJobUrl = "<?php echo _API_URL ?>" + "/api/master-ref-list/get-user-job/" + remoteData[_EMPLOYEE].Employee[0].per_id+"/"
		return new Promise(resolve => { 
			$.ajax({
				url: getUserJobUrl,
				type: 'get',
				dataType: 'json',
				contentType: 'application/json',
				beforeSend: function(request) {
					request.setRequestHeader("Authorization", `Bearer ${access}`)
				},
				data: {},
				success: function (data) {
					localStorage.setItem('userjobstate','true')
					localStorage.setItem('userjobsloaded','true')
					resolve(data)
				},
				error: function (data) {
					// DISABLE THE SPINNER FAIL
				}
			})
		})
	}

	function getUserLineup() {
		getUserLineupUrl = "<?php echo _API_URL ?>" + "/api/lineup/get-lineup-user-data/"
		return new Promise(resolve => { 
			$.ajax({
				url: getUserLineupUrl,
				type: 'get',
				dataType: 'json',
				contentType: 'application/json',
				beforeSend: (request) => {
					window.localStorage.setItem('userlineupState',"pending")
					request.setRequestHeader("Authorization", `Bearer ${access}`)
				},
				data: {},
				success: (data) => {
					window.localStorage.setItem('userlineupState',true)
					window.localStorage.setItem('userLineupCacheLoaded',"true")
					resolve(data)
				},
				error: (data) => {
					// DISABLE THE SPINNER FAIL
					window.localStorage.setItem('userlineupState',"failed")     
				}
			})
		})
	}

	function ajaxGetEmployees(request_url, selectListName) {
		$.ajax({
			url: request_url,
			type: 'get',
			dataType: 'json',
			contentType: 'application/json',
			beforeSend: function(request) {
				request.setRequestHeader("Authorization", `Bearer ${access}`)
			},
			data: {},
			success: (data) => {
				localStorage.setItem(`${selectListName}loaded`,'true')
				localStorage.setItem('employeeVisibility', data.data_visbility)
			},
			error: (data) => {
			}
		})
	}

	function getOfflineDocuments(allCurrentRecords) {
		let docsList = JSON.parse(localStorage.getItem('offline_docs'))
		let offlineDocsPayload = {
			current_docs: docsList
		}
		access = JSON.parse(localStorage.getItem('token')).access
		offlineUrl = "<?php echo _API_URL ?>" + "/api/drm/get-offline-documents/"
		$.ajax({
			url: offlineUrl,
			type: 'post',
			dataType: 'json',
			contentType: 'application/json',
			beforeSend: function(request) {
				window.localStorage.setItem('offlinedocstate',"retrieving offline docs")
				request.setRequestHeader("Authorization", `Bearer ${access}`)
			},
			data: JSON.stringify(offlineDocsPayload),
			success: function (data) {
				window.localStorage.setItem('offlinedocstate',true)
				if(debug) console.info('Completed loading remoteData')
				getBlobDataSofvie(data.data, offlineDocsPayload, allCurrentRecords)
				// Dont disable spinner if settings are loading (Wait for data to be retrived for selects)
				if(window.location.pathname != '/pages/Settings.php' && localStorage.getItem('remotedatastate')){
					if(mobileFrame) {
						setTimeout(() => {
							let message = {
								name: "index-loaded",
								data: ""
							}
							window.parent.postMessage(JSON.stringify(message), '*')
						}, 1000)
					} else {
					}
				}
			},
			error: function (data) {
				window.localStorage.setItem('offlinedocstate',"failed")
			}
		})
	}

	ajaxCallStoreInCache = (request_url, selectListName, requestType, passData) => {
		access = JSON.parse(localStorage.getItem('token')).access
		$.ajax({
			url: request_url,
			type: requestType,
			dataType: 'json',
			contentType: 'application/json',
			beforeSend: function(request) {
				request.setRequestHeader("Authorization", `Bearer ${access}`)              
			},
			data: passData,
			success: function (data) {
				// localStorage.setItem(selectListName, JSON.stringify(data))          
				localStorage.setItem(`${selectListName}loaded`,'true')
			},
			error: function (data) {
				console.log('error ', data)
			}

		})
	}

	function getRmmJraRemoteData() {
		// JRA mobile implements
		let getJraPraTitleListURL = "<?php echo _API_URL ?>" + "/api/rmm/jra-pra-title-list/"
		let getJraPraThreatListURL = "<?php echo _API_URL ?>" + "/api/rmm/jra-pra-threat-list/"
		let getJraBluelinesURL = "<?php echo _API_URL ?>" + "/api/rmm/jra-bluelines/"
		ajaxCallStoreInCache(getJraPraThreatListURL, 'JraPraThreatList', 'post', '{"rmm_pra_id":null}')
		ajaxCallStoreInCache(getJraPraTitleListURL, 'JraPraTitleList', 'get', '')  
		ajaxCallStoreInCache(getJraBluelinesURL, 'JraBluelines', 'post','{"rmm_pra_id": null,"rmm_pec_id": []}')
	}

	function getGeneralActionAttachmentData(){
		getAttachmentURL = "<?php echo _API_URL ?>" + "/api/ga/get-general-action-attachment/"
		$.ajax({
			url: getAttachmentURL,
			type: 'get',
			dataType: 'json',
			contentType: 'application/json',
			beforeSend: function(request) {
				request.setRequestHeader("Authorization", `Bearer ${access}`)
			},
			data: {},
			success: (data) => {
				localStorage.setItem(`generalActionAttachment`,'true')
			},
			error: (data) => {
			}
		})
	}



	function getLOTOAttachmentData(){
		getAttachmentURL = "<?php echo _API_URL ?>" + "/api/loto/get-all-loto-procedure/"
		if(checkLotoPermission()){
			$.ajax({
				url: getAttachmentURL,
				type: 'get',
				dataType: 'json',
				contentType: 'application/json',
				beforeSend: function(request) {
					request.setRequestHeader("Authorization", `Bearer ${access}`)
				},
				data: {},
				success: (data) => {
					localStorage.setItem(`lotoProceduresAttachment`,'true')
				},
				error: (data) => {
				}
			})
		}
	}

	function getLOTOEquipmentData(){
		getAttachmentURL = "<?php echo _API_URL ?>" + "/api/loto/get-equipment-picture/"
		if(checkLotoPermission()){
			$.ajax({
				url: getAttachmentURL,
				type: 'get',
				dataType: 'json',
				contentType: 'application/json',
				beforeSend: function(request) {
					request.setRequestHeader("Authorization", `Bearer ${access}`)
				},
				data: {},
				success: (data) => {
					localStorage.setItem(`lotoEquipmentPics`,'true')
				},
					error: (data) => {
						console.log("Error", data)
				}
			})
		}
	}

	function getHazardActionAttachmentData(){
		getAttachmentURL = "<?php echo _API_URL ?>" + "/api/ha/get-hazard-action-attachment/"
		$.ajax({
			url: getAttachmentURL,
			type: 'get',
			dataType: 'json',
			contentType: 'application/json',
			beforeSend: function(request) {
				request.setRequestHeader("Authorization", `Bearer ${access}`)
			},
			data: {},
			success: (data) => {
				localStorage.setItem(`hazardActionAttachment`,'true')
			},
			error: (data) => {
			}
		})
	}

	async function openUserData() {
		await userSiteDataCachePromise()
		await userJobDataCachePromise()
	}

	async function openRefreshCacheData() {
		return await refreshCachePromise()
	}

	async function openJraProjectCacheData() {
		return await jraProjectCachePromise()
	}

	async function openJraBluelineCacheData() {
		return await jraBluelineCachePromise()
	}

	async function openJraApplicableLineItemsCacheData() {
		return await jraApplicableLineItemsCachePromise()
	}

	async function openCacheData() {
		return await remoteCachePromise()
	}

	async function openSelectCacheData() {
		await selectCachePromise()
		let id = remoteData[2].Employee[0].per_id
		await userSiteDataCachePromise(id)
		await userJobDataCachePromise(id)
		await userSupervisorSelectCachePromise()
		await userEmployeeSelectCachePromise()
		await userEmployeeIncludingDisabledSelectCachePromise()
		await userDistributionSelectCachePromise()
		await userRmmApproversSelectCachePromise()
		await userLineupCachePromise ()
		if(!fromApp) {
			await generalActionAttachmentsCachePromise()
			await hazardActionAttachmentsCachePromise()
		}
		if(checkLotoPermission()){
			await lotoAttachmentsCachePromise()
			await lotoEquipmentPicsCachePromise()
		}
	}

	async function getUserEmployeeRemoteData () {
		let getAllEmployeesURL = "<?php echo _API_URL ?>" + "/api/employee/get-employee-list-uv/all/"
		let getAllEmployeesIncludingDisabledURL = "<?php echo _API_URL ?>" + "/api/employee/get-employee-list-uv/include-disable/"
		let getSupervisorEmployeesURL = "<?php echo _API_URL ?>" + "/api/employee/get-employee-list-uv/supervisor/"
		let getDistributionEmployeesURL = "<?php echo _API_URL ?>" + "/api/employee/get-employee-list-uv/distribution/"
		let getRmmApproversURL = "<?php echo _API_URL ?>" + "/api/employee/get-employee-list-uv/rmm-jra/"

		ajaxGetEmployees(getSupervisorEmployeesURL, 'supervisorSelectList')
		ajaxGetEmployees(getAllEmployeesIncludingDisabledURL, 'employeeIncludingDisabledSelectList')
		ajaxGetEmployees(getAllEmployeesURL, 'employeeSelectList')
		ajaxGetEmployees(getDistributionEmployeesURL, 'distributionSelectList')
		ajaxGetEmployees(getRmmApproversURL, 'rmmApproversSelectList')
	}

	function getDataFromCookie(cookieItem) {
		let per_id = null
		let myCookie = document.cookie.split(";")
		myCookie.forEach((item) => {
			if(item.trim().split("=")[0] === cookieItem){
				per_id = item.split("=")[1]
			}
		})
		return per_id
	}	
	
	let formSubmission=null

	function syncForm(mode) {
		let DBconfig = {
			DbName: "sofvieRmm",
			RemoteSync: false,
			commitDBName: _SYNCCOUCHDB,
			commitRemoteSync:  _SYNCDOMAIN + ':' + _SYNCPORT + '/' + _SYNCCOUCHDB
		}
		dbSofvieRMM = new PouchDB(DBconfig.DbName, {auto_compaction: true})
		dbSofvieRMM.allDocs({ // Get all matching drafts for this form name 
			include_docs: true,
			attachments: false,
			startkey: '',
			endkey: '\ufff0'
		}).then((result) => {
			if(result.rows.length > 0) {
				formSubmission="RMM"
				insertForm(result.rows[0],dbSofvieRMM)
			}
		}).then(()=> {
			let DBconfig = {
				DbName: "sofvieLoto",
				RemoteSync: false,
				commitDBName: _SYNCCOUCHDB,
				commitRemoteSync:  _SYNCDOMAIN + ':' + _SYNCPORT + '/' + _SYNCCOUCHDB
			}
			dbSofvieLOTO = new PouchDB(DBconfig.DbName, {auto_compaction: true})
			dbSofvieLOTO.allDocs({ // Get all matching drafts for this form name 
				include_docs: true,
				attachments: false,
				startkey: '',
				endkey: '\ufff0'
			}).then((result) => {
				if(result.rows.length > 0) {
					formSubmission="LOTO"
					insertForm(result.rows[0],dbSofvieLOTO)
				}
			})
		}).catch((err) => {
			console.error(err)
		})		
	}

	let formSyncing=null
	
	function insertFormAPI(payload) {
		return new Promise(resolve => { 
			access = JSON.parse(localStorage.getItem('token')).access
			let url=null; formSyncing=null
			if(formSubmission=="RMM"){
				url=`${__env.apiUrl}/api/rmm/jra-insert-mobile/`
				formSyncing='RMMSYNCING'
			}
			else if(formSubmission=="LOTO"){
				url=`${__env.apiUrl}/api/loto/submit-loto-form/`
				formSyncing='LOTOSYNCING'
			}

			$.ajax({
				url: url,
				type: 'post',
				dataType: 'json',
				contentType: 'application/json',
				beforeSend: function(request) {
					request.setRequestHeader("Authorization", `Bearer ${access}`)
				},
				data: JSON.stringify(payload.doc.formdata),
				success: function (data) {
					resolve(payload.doc._id)
				},
				error: function (data) {
					window.localStorage.setItem('syncForm',"failed")
					localStorage.removeItem(formSyncing)
					// DISABLE THE SPINNER FAIL
					$("#footerSpinner").addClass('d-none')
				}
			})
		})
	}

    function getDeletedForm(id,dbSofvieForm) {
		return new Promise(resolve => { 
			dbSofvieForm.get(id, {conflicts: true}).then(function(doc) {
				resolve(doc)
			})
		})

	}

	function deleteDeletedForm(doc,dbSofvieForm) {
		return new Promise(resolve => { 
			dbSofvieForm.remove(doc._id, doc._rev ).then(()=>{
				localStorage.removeItem(formSyncing)
				resolve(true)
			})
		})
	}

	async function insertForm(payload,dbSofvieForm) {
		id = await insertFormAPI(payload)
		doc = await getDeletedForm(id,dbSofvieForm)
		await deleteDeletedForm(doc,dbSofvieForm)
		syncForm(formSubmission)
	}

	function getAssignMultipleAction(){
	  let assignMultiUser = false
      let assignMultiUserRecords = remoteData[39]['UserMultiActionPermission']  
      if(assignMultiUserRecords){
        for(rec of assignMultiUserRecords){
          if(rec.ape_name==="Can Assign Action to Multiple Users"){
            assignMultiUser = true
          }    
        }
      }
	  return assignMultiUser
	}
</script>
