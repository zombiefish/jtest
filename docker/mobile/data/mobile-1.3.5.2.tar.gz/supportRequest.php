<?php	
  	$strPageTitle = 'Provide Feedback';
  	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col container-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-3">
			<div class="card">
				<div class="card-body">
					<form id='feedback' class="needs-validation" novalidate method="POST">
						<div class="w-75 m-auto">
						</div>	
						<div class="pt-1 position-relative my-4">
							<select class="select-single" name="subject" id="subject" required>
								<option value="choose" disabled selected class='translate' data-i18n='3917' notes='Choose subject'></option>
								<option value="8867" class='translate trans_input' data-i18n='3918' notes='Feedback'></option>
								<option value="8868" class='translate trans_input' data-i18n='3919' notes='Bug report'></option>
								<option value="8869" class='translate trans_input' data-i18n='3920' notes='Feature Request'></option>
							</select>
							<label for="subject"><span class='translate' data-i18n='3923' notes='Feedback Type'></span></label>
							<div class="invalid-feedback">
							<span class='translate' data-i18n='3922' notes='Please select a feedback type.'></span>
							</div>
						</div>
						<div class="md-form">
							<textarea type="text" name="message" id="message" class="form-control md-textarea" rows="3" required></textarea>
							<label for="message"><span class='translate' data-i18n='1893' notes='Message'></span></label>
						</div>
						<div class="form-check pl-0">
							<input type="checkbox" class="form-check-input ml-0" name="check" id="check">
							<label class="form-check-label" id="email" for="check"><span class='translate' data-i18n='3924' notes='Send a copy of this message to'></span></label> <span id="emailaddress"></span> 
						</div>
						<button class="btn btn-primary btn-block my-4 waves-effect waves-light" id="submitRequest"><span class='translate' data-i18n='1895' notes='Send Message'></span></button>
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<?php include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
<script>
	openCacheData().then(()=>{
		mailObj = {
		name: remoteData[_EMPLOYEE].Employee[0].per_full_name,
		email: remoteData[_EMPLOYEE].Employee[0].email,
		subject: $('#subject').val(),
		message: $('#message').val(),
		sendEmail: $('#check').val()
		}
		$('#emailaddress').html(`${mailObj.email}`)
		$("#footerSpinner").addClass('d-none')
	})


// Check to see if we are on line

	checkOnline().then((status)=>{
		if(!status) {
			document.getElementById('submitRequest').disabled = true
		}
	}).catch((err)=>{
		document.getElementById('submitRequest').disabled = true
	})

$('#submitRequest').click((e)=>{
	if(validateForm()) {
		msgToken = JSON.parse(window.localStorage.getItem('token')).access
		mailObj.subject= $('#subject').val()
		mailObj.message= $('#message').val()
		mailObj.sendEmail = $('#check')[0].checked
		mailObj.message += `\r\n\r\n${i18next.t('3927')} ${mailObj.name} ${i18next.t('3928')} <?php echo _COMPANYNAME ?> - ${i18next.t('3929')}\r\n\r\n`
		$.ajax({
			url: `<?php echo _API_URL ?>/api/utils/send-support-email/`,
			type: "POST",
			dataType:"json",
			data : JSON.stringify(mailObj),
			contentType: 'application/json',
			headers: {
				'Authorization': `Bearer ${msgToken}`
			},
			success: (result) => {
				mailObj.subject= $('#subject').val('').trigger('change') 
				mailObj.message= $('#message').val('')
				$('#check')[0].checked = false
				document.forms['feedback'].classList.remove('was-validated')
				modal = new SofvieModal();
				modal.setModalElements('success','modalText',i18next.t('3925'));        // set Text to the success modal
				modal.setModalElements('success','modalTitle',i18next.t('3926'));                            // set the title of the success modal
				modal.handleModal("success");  
			},
			error: (error) => {
				console.log("There was an Email Error", error)
			}
		})

	}

})

function validateForm() {
	let formVal = document.forms['feedback']
	formVal.classList.add('was-validated')
	let validated = true
	for (let a = 0; a < formVal.length; a++) {
		if (!formVal[a].validity.valid) {
			validated = false
		}
	}
	return validated
}

</script>