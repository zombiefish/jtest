<?php
	class DBManager{
		var $connection   = '';
		var $queryCounter = 0;
		var $totalTime    = 0;
		var $errorCode    = 0;
		var $errorMsg     = '';
		var $resultSet    = '';
 		
		function dbConnect()	{
				
			if(func_num_args())	{				// We need a variable list of args until I can get all of the calling routines converted
				$db_mode = func_get_arg(0);		// If we got it, use it.
			}	else	{
				$db_mode = _DB_READ_MODE;		// Otherwise, were safe using the read connection parameters until we have more than one db server.
			}
			
			// Default to read connection
			$db_ip = _DB_READ_IP;
			$db_user = _DB_READ_USER;
			$db_pass = _DB_READ_PASS;
			$db_name = _DB_READ_NAME;
			
			if($db_mode)	{
				$db_ip = _DB_WRITE_IP;
				$db_user = _DB_WRITE_USER;
				$db_pass = _DB_WRITE_PASS;
				$db_name = _DB_WRITE_NAME;
			}

			$options = [	// Set our default PDO options
				PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
			];

			try {
				// Try to connect
				$this->connection = new PDO("mysql:host=$db_ip;Database=$db_name",$db_user, $db_pass, $options);
			} catch (\PDOException $e) {	// Handle on error
				print "Error!: " . $e->getMessage() . "<br/>";
				return false;
				throw new \PDOException($e->getMessage(), (int)$e->getCode());
				die();
			}

			return true;
		}   

		function dbClose()	{
			// Close the currently open db connection
			$this->connection = null;
		}
	}
?>
