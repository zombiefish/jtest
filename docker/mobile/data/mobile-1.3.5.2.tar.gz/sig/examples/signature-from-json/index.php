<html>
    <h1> Signature Output </h1>
    <?php

require_once '../../signature-to-image.php';

$img = sigJsonToImage(file_get_contents('sig-output.json'));

// Save to file
imagepng($img, 'signature.jpg');

// Output to browser
//header('Content-Type: image/png');
//imagepng($img);

// Destroy the image in memory when complete
//imagedestroy($img);

?>
</html>