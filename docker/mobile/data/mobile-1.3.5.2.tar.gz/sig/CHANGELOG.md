# Changelog

**1.1.0 (Jun. 12, 2012)**

- Added the ability to have a transparent background for the image.
- Moved the draw multiplier into a public property.

**1.0.1 (Apr. 9, 2011)**

- Added `stripslashes()` to the string JSON for many servers that have magic quotes on.

**1.0.0 (Aug. 29, 2010)**

- Initial Release
