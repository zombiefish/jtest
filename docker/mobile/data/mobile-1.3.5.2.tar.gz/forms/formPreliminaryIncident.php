<?php	
  $strPageTitle = 'Preliminary Incident';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
					<h6 class="text-secondary"><span class='translate' data-i18n='1003' notes='Preliminary Incident'></span></h6>
					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
						</select>
						<label for="draft"><span class='translate' data-i18n='1474' notes='Form Drafts'></span></label>
					</div>

					<form name="preliminaryIncident" id="preliminaryIncident" class="needs-validation" method="POST" action="#" novalidate>
								
						<div class="md-form">
							<textarea name="incident_short_description" id="incident_short_description" class="form-control md-textarea character_counter" wrap="VIRTUAL" required tag="1706"></textarea>
							<label for="incident_short_description"><span class='translate' data-i18n='1706' notes='Incident Title'></span></label>
						</div>

						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1707' notes='Incident Information'></span></h6>
						<div class="pt-1 position-relative my-4">
							<select name="incident_type" id="incident_type" class="select-single mobile-preliminaryincidentype-select" onChange="formHeader.populatePreliminaryIncidentTypeCategory(this)" required>
							</select>
							<label for="incident_type"><span class='translate' data-i18n='566' notes='Incident Type'></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="Incident_Type_Category" id="Incident_Type_Category" class="select-multiple mobile-preliminaryincidentypecategory-select" onChange="formHeader.populatePreliminaryIncidentTypeDetail(this)" multiple required>
							</select>
							<label for="Incident_Type_Category"><span class='translate' data-i18n='1708' notes='Incident category'></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="Incident_Type_Detail" id="Incident_Type_Detail" class="select-multiple mobile-preliminaryincidentypedetail-select" multiple required>
							</select>
							<label for="Incident_Type_Detail"><span class='translate' data-i18n='568' notes='Incident Type Detail'></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="incident_time" id="incident_time" class="form-control timepicker" required>
							<label for="incident_time"><span class='translate' data-i18n='565' notes='Incident Time'></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="incident_shift" id="incident_shift" class="select-single mobile-shift-select" required>
							</select>
							<label for="incident_shift"><span class='translate' data-i18n='563' notes='Incident Shift'></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="shift_schedule" id="shift_schedule" class="select-single mobile-eventshiftschedule-select" required>
							</select>			
							<label for="shift_schedule"><span class='translate' data-i18n='821' notes='Shift Schedule'></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="other_shift_schedule_text" id="other_shift_schedule_text" class="form-control" length="200" maxlength="200">
							<label for="other_shift_schedule_text"><span class='translate' data-i18n='707' notes='Other Shift Schedule'></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="day_of_rotation" id="day_of_rotation" class="select-single mobile-daysofrotation-select">
							</select>
							<label for="day_of_rotation"><span class='translate' data-i18n='126' notes='Day of Rotation'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1709' notes='Personnel Involved'></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="name_of_person_reporting_incident" id="name_of_person_reporting_incident" class="select-single mobile-employee-select-single">
							</select>
							<label for="name_of_person_reporting_incident" ><span class='translate' data-i18n='1710' notes='Name of person reporting the incident'></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="other_reporting_incident" id="other_reporting_incident" class="form-control" length="200" maxlength="200">
							<label for="other_reporting_incident"><span class='translate' data-i18n='1711' notes='Other reporting incident'></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="company_name" id="company_name" class="form-control" length="200" maxlength="200">
							<label for="company_name"><span class='translate' data-i18n='87' notes='Company Name'></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="name_of_injury_person" id="name_of_injury_person" class="select-single mobile-employee-select-single">
							</select>
							<label for="name_of_injury_person"><span class='translate' data-i18n='650' notes='Name of injured person'></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="other_injury_person" id="other_injury_person" class="form-control" length="200" maxlength="200">
							<label for="other_injury_person"><span class='translate' data-i18n='713' notes='Others injured (not included in list above)'></span> </label>
						</div>

						<div class="md-form">
							<input type="text" name="company_name_1" id="company_name_1" class="form-control" length="200" maxlength="200">
							<label for="company_name_1"><span class='translate' data-i18n='87' notes='Company Name'></span> </label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1712' notes='Others Involved'></span></h6>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1713' notes='Were others involved?'></span></label>
							<div class="form-check custom-radio pl-0" id="where_other_involved">
								<input type="radio" class="form-check-input" id="where_other_involved_yes" name="where_other_involved" value="1" required>
								<label class="form-check-label mr-2" for="where_other_involved_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="where_other_involved_no" name="where_other_involved" value="0">
								<label class="form-check-label mr-2" for="where_other_involved_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class='cond-form-check-area'> 
							<div class="pt-1 position-relative my-4">
								<select name="other_1" id="other_1" class="select-single mobile-employee-select-single">
								</select>
								<label for="other_1"><span class='translate' data-i18n='690' notes='Other 1'></span> </label>
							</div>

							<div class="md-form">
								<input type="text" name="other_1_text" id="other_1_text" class="form-control" length="200" maxlength="200">
								<label for="other_1_text" ><span class='translate' data-i18n='691' notes='Other 1 (not included in list above)'></span></label>
							</div>

							<div class="md-form">
								<input type="text" name="company_name_2" id="company_name_2" class="form-control" length="200" maxlength="200">
								<label for="company_name_2"><span class='translate' data-i18n='87' notes='Company Name'></span> </label>
							</div>

							<div class="pt-1 position-relative my-4">
								<select name="other_2" id="other_2" class="select-single mobile-employee-select-single">
								</select>
								<label for="other_2"><span class='translate' data-i18n='692' notes='Other 2'></span></label>
							</div>

							<div class="md-form">
								<input type="text" name="other_2_text" id="other_2_text" class="form-control" length="200" maxlength="200">
								<label for="other_2_text"><span class='translate' data-i18n='693' notes='Other 2 (not included in list above)'></span></label>
							</div>

							<div class="md-form">
								<input type="text" name="company_name_3" id="company_name_3" class="form-control" length="200" maxlength="200">
								<label for="company_name_3"><span class='translate' data-i18n='87' notes='Company Name'></span> </label>
							</div>

							<div class="pt-1 position-relative my-4">
								<select name="other_3" id="other_3" class="select-single mobile-employee-select-single">
								</select>
								<label for="other_3"><span class='translate' data-i18n='694' notes='Other 3'></label>
							</div>

							<div class="md-form">
								<input type="text" name="other_3_text" id="other_3_text" class="form-control" length="200" maxlength="200">
								<label for="other_3_text"><span class='translate' data-i18n='695' notes='Other 3 (not included in list above)'></span></label>
							</div>

							<div class="md-form">
								<input type="text" name="company_name_4" id="company_name_4" class="form-control" length="200" maxlength="200">
								<label for="company_name_4"><span class='translate' data-i18n='87' notes='Company Name'></span> </label>
							</div>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='450' notes='Equipment Involved'></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="equipment_involved" id="equipment_involved" class="select-multiple" multiple>
							</select>
							<label for="equipment_involved"><span class='translate' data-i18n="9559" notes="Please select Site and Department/Job to select Equipment"></span></label>
						</div>

						<div id="other_equipment" class="md-form d-none">
							<input type="text" name="equipment_involved_other" id="equipment_involved_other" class="form-control" length="200" maxlength="200">
							<label for="equipment_involved_other"><span class='translate' data-i18n='688' notes='Other'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1714' notes='Incident Description'></span></h6>

						<div class="md-form">
							<textarea name="incident_details" id="incident_details" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="incident_details"><span class='translate' data-i18n='1715' notes='Describe the incident'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1716' notes='Preliminary Report Checklist'></span></h6>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='584' notes='Is a Gas Check or Temperature Check Required?'></span></label>
							<div class="form-check custom-radio no-radio pl-0" id="gas_or_temperature_required">
								<input type="radio" class="form-check-input" id="gas_or_temperature_required_yes" name="gas_or_temperature_required" value="1" required>
								<label class="form-check-label mr-2" for="gas_or_temperature_required_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="gas_or_temperature_required_no" name="gas_or_temperature_required" value="0">
								<label class="form-check-label mr-2" for="gas_or_temperature_required_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="gas_or_temperature_required_na" name="gas_or_temperature_required" value="-1">
								<label class="form-check-label mr-2" for="gas_or_temperature_required_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class='cond-form-check-area'> 
							<div class="md-form">
								<textarea name="why_not_gas_or_temperature_required" id="why_not_gas_or_temperature_required" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="why_not_gas_or_temperature_required"><span class='translate' data-i18n='476' notes='Explain why not'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1717' notes='Are there any disruptions of process? Did notification to others in the area take place?'></span></label>
							<div class="form-check custom-radio no-radio pl-0" id="any_disruptions_of_process">
								<input type="radio" class="form-check-input" id="any_disruptions_of_process_yes" name="any_disruptions_of_process" value="1" required>
								<label class="form-check-label mr-2" for="any_disruptions_of_process_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>
								<input type="radio" class="form-check-input" id="any_disruptions_of_process_no" name="any_disruptions_of_process" value="0">
								<label class="form-check-label mr-2" for="any_disruptions_of_process_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class='cond-form-check-area'> 
							<div class="md-form">
								<textarea name="why_not_any_disruptions_of_process" id="why_not_any_disruptions_of_process" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="why_not_any_disruptions_of_process"><span class='translate' data-i18n='476' notes='Explain why not'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='496' notes='Has Management (and the client) been notifed?'></span></label>
							<div class="form-check custom-radio no-radio pl-0" id="management_been_notifed">
								<input type="radio" class="form-check-input" id="management_been_notifed_yes" name="management_been_notifed" value="1" required>
								<label class="form-check-label mr-2" for="management_been_notifed_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>
								<input type="radio" class="form-check-input" id="management_been_notifed_no" name="management_been_notifed" value="0">
								<label class="form-check-label mr-2" for="management_been_notifed_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class='cond-form-check-area'> 
							<div class="md-form">
								<textarea name="why_not_management_notifed" id="why_not_management_notifed" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="why_not_management_notifed"><span class='translate' data-i18n='476' notes='Explain why not'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='550' notes='If the employee is injured, is the employee in direct care of management?'></span></label>
							<div class="form-check custom-radio no-radio pl-0" id="employee_direct_care_of_management">
								<input type="radio" class="form-check-input" id="employee_direct_care_of_management_yes" name="employee_direct_care_of_management" value="1" required>
								<label class="form-check-label mr-2" for="employee_direct_care_of_management_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="employee_direct_care_of_management_no" name="employee_direct_care_of_management" value="0">
								<label class="form-check-label mr-2" for="employee_direct_care_of_management_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="employee_direct_care_of_management_na" name="employee_direct_care_of_management" value="-1">
								<label class="form-check-label mr-2" for="employee_direct_care_of_management_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>

						</div>

						<div class='cond-form-check-area'> 
							<div class="md-form">
								<textarea name="why_not_employee_care_of_management" id="why_not_employee_care_of_management" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="why_not_employee_care_of_management"><span class='translate' data-i18n='476' notes='Explain why not'></span></label>
							</div>
						</div>
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='585' notes='Is D&A testing required? If so has the process been initiated and is the employee in proper care and custody?'></span></label>
							<div class="form-check custom-radio  no-radio pl-0" id="testing_process_been_initiated">
								<input type="radio" class="form-check-input" id="testing_process_been_initiated_yes" name="testing_process_been_initiated" value="1" required>
								<label class="form-check-label mr-2" for="testing_process_been_initiated_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="testing_process_been_initiated_no" name="testing_process_been_initiated" value="0">
								<label class="form-check-label mr-2" for="testing_process_been_initiated_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="testing_process_been_initiated_na" name="testing_process_been_initiated" value="-1">
								<label class="form-check-label mr-2" for="testing_process_been_initiated_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class='cond-form-check-area'> 
							<div class="md-form">
								<textarea name="why_not_process_been_initiated" id="why_not_process_been_initiated" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="why_not_process_been_initiated"><span class='translate' data-i18n='476' notes='Explain why not'></span></label>
							</div>
						</div>
						
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1413' notes='Include Photos'></span></h6>

						<div class="form-group photoImage" id="incident_pictures"> 
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n='2340' notes='ADD IMAGES'></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n='1389' notes='Please take scene pictures from all perspectives'></span></small>
							<div class="row photoGallery" id="galleryid"></div>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" note="PRELIMINARY INCIDENT" class = "trans_input" value="1003"  tag="1003" />
						<input type="hidden" name="formtype" id="formtype" value="HR" />
						<input type="hidden" name="formid" id="formid" value="224335" />
						<input type="hidden" name="version" id="version" value="25" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="incident_short_description" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
						<input type="hidden" name="incident_id" id="incident_id"  value=""/>
						<input type="hidden" name="formmisc" id="formmisc"  value=""/>

					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script src="/js/groupEquipment.js"></script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>

<script type="text/javascript">

var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},
		
		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
			
			if(theForm.formid.value == '')	{
				toastr.error(i18next.t(9578))   //Invalid form id
				return false;
			}

			if(theForm.version.value == '')	{
				toastr.error(i18next.t(9579))   //Invalid version
				return false;
			}

			return true;
		}	
	}
	
$('#equipment_involved').change(function(e){
	$("#equipment_involved_other").prop('required',false)
	if(checkOther('equipment_involved', $(this).val())){
		$("#other_equipment").removeClass("d-none")
		$("#equipment_involved_other").prop('required',true)
	}
	else{
		$("#equipment_involved_other").val('').parent().find('label').removeClass('active filled')
		$("#equipment_involved_other").prop('required',false)
		$("#other_equipment").addClass("d-none")
	}
})
</script>
