

						<div class="mb-4">
							<label for="Access to the workplace"><strong><span class='translate' data-i18n='9184' notes='Access to the workplace'></span></strong></label>
						</div>

						<div class="mb-4">
							<label for="travelway_in_good_order" class="hide-show"><span class='translate' data-i18n="9188" notes="Is the travelway in good order"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_tgo" name="travelway_in_good_order" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_tgo"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_tgo" name="travelway_in_good_order" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_tgo"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_tgo" name="travelway_in_good_order" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_tgo"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_tgo" name="travelway_in_good_order" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_tgo"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_tgo" id="comments_tgo" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_tgo"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="access_workplace"><span class='translate' data-i18n="9232" notes="Access to workplace"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_access" name="access_workplace" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_access"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_access" name="access_workplace" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_access"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_access" name="access_workplace" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_access"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_access" name="access_workplace" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_access"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_acc" id="comments_acc" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_acc"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label for="emergency_exit_cleared"><span class='translate' data-i18n="9189" notes="Emergency exit cleared"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_eec" name="emergency_exit_cleared" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_eec"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_eec" name="emergency_exit_cleared" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_eec"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_eec" name="emergency_exit_cleared" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_eec"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_eec" name="emergency_exit_cleared" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_eec"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_eec" id="comments_eec" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_eec"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="signs_in_order"><span class='translate' data-i18n="9191" notes="Are signs and barricades in good order"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_sio" name="signs_in_order" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_sio"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_sio" name="signs_in_order" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_sio"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_sio" name="signs_in_order" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_sio"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_sio" name="signs_in_order" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_sio"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_sio" id="comments_sio" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_sio"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="others_access"><span class='translate' data-i18n="9193" notes="Others"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_others_access" name="others_access" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_others_access"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_others_access" name="others_access" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_others_access"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_others_access" name="others_access" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_others_access"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_others_access" name="others_access" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_others_access"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_others_access" id="comments_others_access" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_others_access"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="Workplace"><strong><span class='translate' data-i18n='959' notes='Workplace'></span></strong></label>
						</div>

						<div class="mb-4">
							<label for="cleanliness_order"><span class='translate' data-i18n="9195" notes="Cleanliness and good order"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_cleanliness_order" name="cleanliness_order" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_cleanliness_order"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_cleanliness_order" name="cleanliness_order" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_cleanliness_order"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_cleanliness_order" name="cleanliness_order" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_cleanliness_order"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_cleanliness_order" name="cleanliness_order" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_cleanliness_order"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_clo" id="comments_clo" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_clo"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
			
						<div class="mb-4">
							<label for="protective_guard"><span class='translate' data-i18n="9197" notes="Protective guard"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_protective_guard" name="protective_guard" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_protective_guard"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_protective_guard" name="protective_guard" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_protective_guard"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_protective_guard" name="protective_guard" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_protective_guard"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_protective_guard" name="protective_guard" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_protective_guard"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_protective_guard" id="comments_protective_guard" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_protective_guard"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="lockout_exhaust"><span class='translate' data-i18n="9199" notes="Lockout (Zero Energy)"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_lockout_exhaust" name="lockout_exhaust" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_lockout_exhaust"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_lockout_exhaust" name="lockout_exhaust" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_lockout_exhaust"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_lockout_exhaust" name="lockout_exhaust" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_lockout_exhaust"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_lockout_exhaust" name="lockout_exhaust" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_lockout_exhaust"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_lockout_exhaust" id="comments_lockout_exhaust" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_lockout_exhaust"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="fire_extinguisher_nearby"><span class='translate' data-i18n="9201" notes="Fire extinguisher nearby"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_fire_extinguisher_nearby" name="fire_extinguisher_nearby" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_fire_extinguisher_nearby"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_fire_extinguisher_nearby" name="fire_extinguisher_nearby" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_fire_extinguisher_nearby"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_fire_extinguisher_nearby" name="fire_extinguisher_nearby" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_fire_extinguisher_nearby"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_fire_extinguisher_nearby" name="fire_extinguisher_nearby" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_fire_extinguisher_nearby"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_fen" id="comments_fen" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_fen"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="ladder_scaffold"><span class='translate' data-i18n="9203" notes="Stepladder, ladder, scaffold"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_ladder_scaffold" name="ladder_scaffold" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_ladder_scaffold"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_ladder_scaffold" name="ladder_scaffold" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_ladder_scaffold"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_ladder_scaffold" name="ladder_scaffold" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_ladder_scaffold"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_ladder_scaffold" name="ladder_scaffold" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_ladder_scaffold"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_sls" id="comments_sls" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_sls"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="unobstructed_electrical_installation"><span class='translate' data-i18n="9205" notes="Unobstructed electrical installation"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_unobstructed_electrical_installation" name="unobstructed_electrical_installation" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_unobstructed_electrical_installation"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_unobstructed_electrical_installation" name="unobstructed_electrical_installation" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_unobstructed_electrical_installation"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_unobstructed_electrical_installation" name="unobstructed_electrical_installation" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_unobstructed_electrical_installation"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_unobstructed_electrical_installation" name="unobstructed_electrical_installation" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_unobstructed_electrical_installation"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_unobstructed_electrical_installation" id="comments_unobstructed_electrical_installation" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_unobstructed_electrical_installation"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="lifting_accessory"><span class='translate' data-i18n="9207" notes="Lifting accessory"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_lifting_accessory" name="lifting_accessory" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_lifting_accessory"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_lifting_accessory" name="lifting_accessory" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_lifting_accessory"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_lifting_accessory" name="lifting_accessory" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_lifting_accessory"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_lifting_accessory" name="lifting_accessory" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_lifting_accessory"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_lifting_accessory" id="comments_lifting_accessory" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_lifting_accessory"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="appropriate_tooling"><span class='translate' data-i18n="9208" notes="Appropriate tooling"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_appropriate_tooling" name="appropriate_tooling" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_appropriate_tooling"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_appropriate_tooling" name="appropriate_tooling" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_appropriate_tooling"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_appropriate_tooling" name="appropriate_tooling" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_appropriate_tooling"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_appropriate_tooling" name="appropriate_tooling" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_appropriate_tooling"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_appropriate_tooling" id="comments_appropriate_tooling" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_appropriate_tooling"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="PPE"><span class='translate' data-i18n="1087" notes="PPE"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_PPE" name="PPE" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_PPE"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_PPE" name="PPE" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_PPE"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_PPE" name="PPE" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_PPE"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_PPE" name="PPE" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_PPE"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_ppe" id="comments_ppe" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_ppe"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="eyewash_firstaid"><span class='translate' data-i18n="9206" notes="Eye wash, first aid"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_eyewash_firstaid" name="eyewash_firstaid" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_eyewash_firstaid"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_eyewash_firstaid" name="eyewash_firstaid" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_eyewash_firstaid"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_eyewash_firstaid" name="eyewash_firstaid" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_eyewash_firstaid"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_eyewash_firstaid" name="eyewash_firstaid" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_eyewash_firstaid"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_eyewash_firstaid" id="comments_eyewash_firstaid" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_eyewash_firstaid"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="lighting"><span class='translate' data-i18n="9204" notes="Lighting"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_lighting" name="lighting" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_lighting"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_lighting" name="lighting" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_lighting"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_lighting" name="lighting" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_lighting"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_lighting" name="lighting" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_lighting"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_lighting" id="comments_lighting" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_lighting"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label for="others_workplace"><span class='translate' data-i18n="9193" notes="Others"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_others_workplace" name="others_workplace" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_others_workplace"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_others_workplace" name="others_workplace" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_others_workplace"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_others_workplace" name="others_workplace" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_others_workplace"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_others_workplace" name="others_workplace" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_others_workplace"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_others_workplace" id="comments_others_workplace" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_others_workplace"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label for="Workplace"><strong><span class='translate' data-i18n='9202' notes='Method of work'></span></strong></label>
						</div>

						<div class="mb-4">
							<label for="safe_and_efficient"><span class='translate' data-i18n="9200" notes="Are current work methods safe and efficient"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class='form-check-input lock_supervisor_entry_lock' id="safe_and_efficient_yes"  name="safe_and_efficient"  onclick="showHideRadio(event)" value="1" required>
								<label class="form-check-label mr-2" for="safe_and_efficient_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class='form-check-input lock_supervisor_entry_lock' id="safe_and_efficient_no"  name="safe_and_efficient" onclick="showHideRadio(event)" value="0">
								<label class="form-check-label mr-2" for="safe_and_efficient_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						
							<!-- <div class="md-form  d-none">
								<textarea name="reason_not_safe_and_efficient" id="reason_not_safe_and_efficient" class="form-control md-textarea lock_supervisor_entry_lock" wrap="VIRTUAL"></textarea>
								<label for="activity-observed"><span class='translate' data-i18n='8588' notes='Why is the activity not safe and efficient?'></span></label>
							</div> -->
						</div>

						<div class="mb-4">
							<label for="specific_work_procedure_method"><span class='translate' data-i18n="9198" notes="Specific work procedure discussed"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class='form-check-input lock_supervisor_entry_lock' id="specific_work_procedure_method_yes"  name="specific_work_procedure_method"  onclick="showHideRadio(event)" value="1" required>
								<label class="form-check-label mr-2" for="specific_work_procedure_method_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class='form-check-input lock_supervisor_entry_lock' id="specific_work_procedure_method_no"  name="specific_work_procedure_method" onclick="showHideRadio(event)" value="0">
								<label class="form-check-label mr-2" for="specific_work_procedure_method_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="md-form pt-1 position-relative my-4">
							<input type="text" name="title_procedure" id="title_procedure" class="form-control" length="200" maxlength="200">
							<label for="title_procedure"><span class='translate' data-i18n="9196" notes="Title of procedure"></span></label>
						</div>

						<div class="md-form">
							<textarea name="comments_workplace_inspection" id="comments_workplace_inspection" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="comments_workplace_inspection"><span class='translate' data-i18n='81' notes='Comments'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1387' notes='Shift Start Workplace Conditions'></span></h6>
							<div class="form-group photoImage" id="start_state_pictures"> 
								<label class="d-block"><span class='translate' data-i18n='838' notes='Start State Pictures of the Workplace'></span></label>
								<canvas id="canvasa_1" style='display:none;'></canvas>
								<div class="btn-group d-flex" role="group">
									<div class="btn btn-block btn-outline-secondary file-field px-1">
										<i class="fa fa-upload"></i> <span class='translate' data-i18n='2340' notes='ADD IMAGES'></span>
										<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
									</div>
								</div>
								<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
								<div class="row photoGallery" id="galleryida"></div>
							</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='8530' notes='Planning'></span></h6>
						<hr style="border-color: #0f70b7; border-width: 2px;"/>

						<div class="mb-4">
							<label for="exchange_work"><span class='translate' data-i18n="9194" notes="Exchange on the work to be done"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="exchange_work_yes" name="exchange_work" value="1">
								<label class="form-check-label mr-2" for="exchange_work_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="exchange_work_no" name="exchange_work" value="0">
								<label class="form-check-label mr-2" for="exchange_work_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label for="specific_work_procedure_planning"><span class='translate' data-i18n="9198" notes="Specific work procedure discussed"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="specific_work_procedure_planning_yes" name="specific_work_procedure_planning" value="1">
								<label class="form-check-label mr-2" for="specific_work_procedure_planning_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="specific_work_procedure_planning_no" name="specific_work_procedure_planning" value="0">
								<label class="form-check-label mr-2" for="specific_work_procedure_planning_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						
							<div class="md-form">
								<textarea name="new_guideline" id="new_guideline" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="new_guideline"><span class='translate' data-i18n='9192' notes='New Guideline'></span></label>
							</div>
						
							<div class="md-form">
								<textarea name="daily_safety_act" id="daily_safety_act" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="daily_safety_act"><span class='translate' data-i18n='9190' notes='Daily Safety Act'></span></label>
							</div>
													
							<div class="md-form">
								<textarea name="future_specific_risk" id="future_specific_risk" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="future_specific_risk"><span class='translate' data-i18n='9187' notes='Present or Future Specific Risk'></span></label>
							</div>
						
							<div class="md-form">
								<textarea name="corrective_action" id="corrective_action" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="corrective_action"><span class='translate' data-i18n='2712' notes='Corrective action'></span></label>
							</div>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='2090' notes='Decision'></span></h6>
						<hr style="border-color: #076633; border-width: 2px;"/>
						<div id="lock_section_decision_div">
							<div class="form-check">
								<input type="checkbox" class="form-check-input ml-0 lock_section_decision_lock" name="confirm_understand" id="confirm_understand"  value = '' onclick="boxChecked(event.target)" required>
								<label class="form-check-label" for="confirm_understand"><span class='translate' data-i18n="8540" notes="I confirm that we understand each other"></span></label>
							</div>
							<div class="form-check">
								<input type="checkbox" class="form-check-input ml-0 lock_section_decision_lock" name="confirm_safe" id="confirm_safe"  value = ''   onclick="boxChecked(event.target)" required>
								<label class="form-check-label" for="confirm_safe"><span class='translate' data-i18n="8541" notes="I confirm that the work can be done safely"></span></label>
							</div>
							<div class="form-check">
								<input type="checkbox" class="form-check-input ml-0 lock_section_decision_lock" name="authorize_proceed" id="authorize_proceed"  value = ''  onclick="boxChecked(event.target)" required>
								<label class="form-check-label" for="authorize_proceed"><span class='translate' data-i18n="8542" notes="I authorize the employee to proceed with the work"></span></label>
							</div>

							<div class="md-form">
								<textarea name="special_conditions" id="special_conditions" class="form-control md-textarea lock_section_decision_lock" wrap="VIRTUAL" required></textarea>
								<label for="special_conditions"><span class='translate' data-i18n='9233' notes='Special Conditions'></span></label>
							</div>

							<div class="md-form">
								<textarea name="actions_taken" id="actions_taken" class="form-control md-textarea lock_section_decision_lock" wrap="VIRTUAL" required></textarea>
								<label for="actions_taken"><span class='translate' data-i18n='9185' notes='Actions Taken'></span></label>
							</div>

							<div class="md-form">
								<textarea name="persons_contacted" id="persons_contacted" class="form-control md-textarea lock_section_decision_lock" wrap="VIRTUAL" required></textarea>
								<label for="persons_contacted"><span class='translate' data-i18n='9186' notes='Persons Contacted'></span></label>
							</div>
							<div class="my-4">
								<label class="text-muted"><span class='translate' data-i18n="217" notes="Employee signature"></span></label>
								<div class="btn-group d-flex" role="group" aria-label="Action subforms">
									<div id="employee_signature" class='btn btn-outline-secondary col waves-effect p-2 m-0 lock_section_decision_lock sign' signaturename='signature_employee' disabled><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
									<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
									<div id="clearemployee_signature" class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
								</div>
								<img id='signature_employee_img' src='' class='signatureImage d-block pt-2'/>
								<input type="hidden" name="signature_employee" id="signature_employee" class='modalSignature' value='' required>
								<input type="hidden" name="vector_employee" id='vector_employee' value=''>
								<input type="hidden" name="signature_employee_comments" id='signature_employee_comments' class="sig_comment" value=''>
								<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="employee_signature_img_time" id="employee_signature_img_time" notes='signature_employee_img_time' readonly/></small>
							</div>

							<div class="my-4">
								<label class="text-muted"><span class='translate' data-i18n="850" notes="Supervisor Signature"></span></label>
								<div class="btn-group d-flex" role="group" aria-label="Action subforms">
									<div id="supervisor_signature_lock_section_decision" class='btn btn-outline-secondary col waves-effect p-2 m-0 lock_section_decision_lock sign' signaturename='signature_supervisor'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
									<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
									<div id="clearsupervisor_signature_lock_section_decision" class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
								</div>
								<img id='signature_supervisor_img' src='' class='signatureImage d-block pt-2'/>
								<input type="hidden" name="signature_supervisor" id="signature_supervisor" class='modalSignature' value='' required>
								<input type="hidden" name="vector_supervisor" id='vector_supervisor' value='' >
								<input type="hidden" name="signature_supervisor_comments" id='signature_supervisor_comments' class="sig_comment" value=''>
								<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="supervisor_signature_img_time" id="supervisor_signature_img_time" notes='signature_supervisor_img_time' readonly/></small>
							</div>
						</div>

							<button type="button"  name="lock_section_decision" id="lock_section_decision" class="btn btn-primary btn-block my-4 waves-effect waves-light check_lock"><span class='translate' data-i18n="8543" notes="Lock section"></span></button>
							<small class="form-text text-muted d-none"><span class='translate' data-i18n='8529' notes='Entries locked:'></span> <input style='border: none; display: inline; width: 300px; background:none;' type="text" name="lock_section_decision_time" id="lock_section_decision_time" readonly/></small>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='9234' notes='Execution (2nd visit)'></span></h6>
						<hr style="border-color: #f8ea19; border-width: 2px;"/>
						<div id="lock_section_execution_div">
							<div class="mb-4">
								<label for="work_conform_decisions"><span class='translate' data-i18n="9235" notes="Does the work conform to the decisions"></span></label>
								<div class="form-check custom-radio no-sub pl-0">
									<input type="radio" class="form-check-input lock_section_execution_lock" id="work_conform_decisions_yes" name="work_conform_decisions" value="1" required>
									<label class="form-check-label mr-2" for="work_conform_decisions_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input lock_section_execution_lock" id="work_conform_decisions_no" name="work_conform_decisions" value="0">
									<label class="form-check-label mr-2" for="work_conform_decisions_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							
								<div class="md-form">
									<textarea name="supervisor_comments" id="supervisor_comments" class="form-control md-textarea lock_section_execution_lock" wrap="VIRTUAL"></textarea>
									<label for="supervisor_comments"><span class='translate' data-i18n='81' notes='Comments'></span></label>
								</div>
							</div>

							<div class="my-4">
								<label class="text-muted"><span class='translate' data-i18n="217" notes="Employee signature"></span></label>
								<div class="btn-group d-flex" role="group" aria-label="Action subforms">
									<div id="employee_signature_lock_section_execution" class='btn btn-outline-secondary col waves-effect p-2 m-0 lock_section_execution_lock sign' signaturename='signature_execution_employee' disabled><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
									<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
									<div id="clearemployee_signature_lock_section_execution" class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
								</div>
								<img id='signature_execution_employee_img' src='' class='signatureImage d-block pt-2'/>
								<input type="hidden" name="signature_execution_employee" id="signature_execution_employee" class='modalSignature' value='' required>
								<input type="hidden" name="vector_employee_execution" id='vector_employee_execution' value=''>
								<input type="hidden" name="signature_execution_employee_comments" id='signature_execution_employee_comments' class="sig_comment" value=''>
								<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="employee_signature_execution_img_time" id="employee_signature_execution_img_time" notes='signature_execution_employee_img_time' readonly/></small>
							</div>

							<div class="my-4">
								<label class="text-muted"><span class='translate' data-i18n="850" notes="Supervisor Signature"></span></label>
								<div class="btn-group d-flex" role="group" aria-label="Action subforms">
									<div id='supervisor_signature_lock_section_execution' class='btn btn-outline-secondary col waves-effect p-2 m-0 lock_section_execution_lock sign' signaturename='signature_execution_supervisor'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
									<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
									<div id='clearsupervisor_signature_lock_section_execution' class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none' ><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
								</div>
								<img id='signature_execution_supervisor_img' src='' class='signatureImage d-block pt-2'/>
								<input type="hidden" name="signature_execution_supervisor" id="signature_execution_supervisor" class='modalSignature' value='' required>
								<input type="hidden" name="vector_supervisor_execution" id='vector_supervisor_execution' value=''>
								<input type="hidden" name="signature_execution_supervisor_comments" id='signature_execution_supervisor_comments' class="sig_comment" value=''>
								<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="supervisor_signature_execution_img_time" id="supervisor_signature_execution_img_time" notes='signature_execution_supervisor_img_time' readonly/></small>
							</div>
						</div>

						<button type="button"  name="lock_section_execution" id="lock_section_execution" class="btn btn-primary btn-block my-4 waves-effect waves-light check_lock"><span class='translate' data-i18n="8543" notes="Lock section"></span></button>
						<small class="form-text text-muted d-none"><span class='translate' data-i18n='8529' notes='Entries locked:'></span> <input style='border: none; display: inline; width: 300px; background:none;' type="text" name="lock_section_execution_time" id="lock_section_execution_time" readonly/></small>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1394' notes='Shift End Workplace Conditions'></span></h6>
							<div class="form-group photoImage" id="end_state_pictures"> 
								<label class="d-block"><span class='translate' data-i18n='423' notes='End State Pictures of the Workplace'></span></label>
								<canvas id="canvasa_2" style='display:none;'></canvas>
								<div class="btn-group d-flex" role="group">
									<div class="btn btn-block btn-outline-secondary file-field px-1">
										<i class="fa fa-upload"></i> <span class='translate' data-i18n='2340' notes='ADD IMAGES'></span>
										<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
									</div>
								</div>
								<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
								<div class="row photoGallery" id="galleryidb"></div>
							</div>

							<div class="md-form">
								<textarea name="end_state_details" id="end_state_details" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="end_state_details"><span class='translate' data-i18n='422' notes='End State Details'></span></label>
							</div>
