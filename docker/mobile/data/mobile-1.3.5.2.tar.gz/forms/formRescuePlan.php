<?php	
  $strPageTitle = 'Rescue Plan';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");	
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
        
						<h6 class="text-secondary"><span class='translate' data-i18n="2248" notes="Rescue Plan"></span></h6>
						<div class="pt-1 position-relative my-4">
							<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
							</select>
							<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
						</div>

						<form name="rescue_plan" id="TemplateForm" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>

						<label for="form_type"><span class='translate' data-i18n="481" notes="Form Type"></span></label>
						<div class="form-check custom-radio pl-0">
							<input type="radio" class="form-check-input trans_input" id="confined_space" name="form_type" value="94" required>
							<label class="form-check-label mr-2" for="confined_space"><span class='translate' data-i18n="94" notes="Confined Space"></span></label>

							<input type="radio" class="form-check-input trans_input" id="working_at_heights" name="form_type" value="2371">
							<label class="form-check-label mr-2" for="working_at_heights"><span class='translate' data-i18n="2371" notes="Working at Heights"></span></label> 
						</div>
						<div class="pt-1 position-relative my-4">
							<select name="equipment_involved" id="equipment_involved" class="select-multiple" multiple required>
							</select>
							<label for="equipment_involved"><span class='translate' data-i18n="9559" notes="Please select Site and Department/Job to select Equipment"></span></label>
						</div>
						<div class="md-form">
							<textarea name="work_being_performed" id="work_being_performed" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="work_being_performed"><span class='translate' data-i18n="939" notes="Work Being Performed"></span></label>
						</div>
						<div class="pt-1 position-relative my-4">
							<select name="retrieval_equipment" id="retrieval_equipment" class="select-multiple mobile-retrievalEquipmentList-select" multiple required>
							</select>
							<label for="retrieval_equipment"><span class='translate' data-i18n="796" notes="Retrieval Equipment"></span></label>
								
							<div id="other_retrieval_equipment_div" class="md-form" style="display:none">
								<input type="text" name="other_retrieval_equipment" id="other_retrieval_equipment" class="form-control" length="200" maxlength="200">
								<label for="other_retrieval_equipment"><span class='translate' data-i18n="706" notes="Other Retrieval Equipment"></span></label>
							</div>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="special_ppe_requirements" id="special_ppe_requirements" class="select-multiple mobile-retrievalSpecialPPEList-select" multiple required>
							</select>
							<label for="special_ppe_requirements"><span class='translate' data-i18n="835" notes="Special PPE requirements"></span></label>
						</div>
						<div id="blue_box" style="display:none">
								<div class="md-form">
									<input type="text" name="blue_box_air_tender" id="blue_box_air_tender" class="form-control" length="200" maxlength="200">
									<label for="blue_box_air_tender"><span class='translate' data-i18n="65" notes="Blue Box Air Tender"></span></label>
								</div>			
							
								<div class="md-form">
									<input type="text" name="blue_box_hose_tender" id="blue_box_hose_tender" class="form-control" length="200" maxlength="200">
									<label for="blue_box_hose_tender"><span class='translate' data-i18n="66" notes="Blue Box Hose Tender"></span></label>
								</div>
						</div>
						<div id="other_chosen" class="md-form" style="display:none">
							<textarea name="other_special_ppe" id="other_special_ppe" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="other_special_ppe"><span class='translate' data-i18n="709" notes="Other Special PPE"></span></label>
						</div>
						<div class="d-flex">
							<div class="md-form w-50 mr-3">
								<input type="number" step="0.01" name="estimated_working_height" id="estimated_working_height" class="form-control" min=0 required>
								<label for="estimated_working_height"><span class='translate' data-i18n="2372" notes="Working Height"></span></label>
							</div>
							<div class="pt-1 position-relative my-4 w-50">
								<select class="select-single" name="estimated_working_height_unit" id="estimated_working_height_unit" required>
									<option value="4321" class='translate trans_input' data-i18n='4321' notes = 'Metres'></option>
									<option value="4322" class='translate trans_input' data-i18n='4322' notes = 'Feet'></option>
								</select>
								<label for="estimated_working_height_unit"><span class='translate' data-i18n="2373" notes="UoM"></span></label>
							</div>
						</div>
						<div class="pt-1 position-relative my-4">
							<select name="hazards_present" id="hazards_present" class="select-multiple mobile-retrievalHazardsPresentList-select" multiple required>
							</select>
							<label for="hazards_present"><span class='translate' data-i18n="515" notes="Hazards present"></span></label>
						</div>	
						<div class="pt-1 position-relative my-4">
							<select name="estimated_rescue_timeline" id="estimated_rescue_timeline" required>
								<option value="4317" class='translate trans_input' data-i18n='4317' notes = '5 minutes'></option>
								<option value="4318" class='translate trans_input' data-i18n='4318' notes = '10 minutes'></option>
								<option value="2871" class='translate trans_input' data-i18n='2871' notes = '15 minutes'></option>
								<option value="4319" class='translate trans_input' data-i18n='4319' notes = '20 minutes'></option>
								<option value="4320" class='translate trans_input' data-i18n='4320' notes = '25 minutes'></option>
								<option value="2872" class='translate trans_input' data-i18n='2872' notes = '30 minutes'></option>
							</select>
							<label for="estimated_rescue_timeline"><span class='translate' data-i18n="455" notes="Estimated rescue timeline"></span></label>
						</div>
						<div class="pt-1 position-relative my-4">
							<select name="rescue_type" id="rescue_type" class="select-single mobile-retrievalRescueTypeList-select" required>
							</select>
							<label for="rescue_type"><span class='translate' data-i18n="793" notes="Rescue type"></span></label>
						</div>	
						<div class="pt-1 position-relative my-4">
							<select name="communication_strategy" id="communication_strategy" class="select-multiple mobile-retrievalCommunicationStrategyList-select" multiple required>
							</select>
							<label for="communication_strategy"><span class='translate' data-i18n="84" notes="Communication Strategy"></span></label>
							
							<div id="other_communication" style="display:none" class="md-form">
								<textarea name="other_communication_methods" id="other_communication_methods" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="other_communication_text"><span class='translate' data-i18n="697" notes="Other Communication Methods"></span></label>
							</div>
							
						</div>	
						<div class="pt-1 position-relative my-4">
							<select name="key_contacts" id="key_contacts" class="select-multiple mobile-retrievalKeyContactsList-select" multiple required>
							</select>
							<label for="key_contacts"><span class='translate' data-i18n="618" notes="Key Contacts"></span></label>
							
							<div id="other_key_contacts" style="display:none" class="md-form">
								<textarea name="other_contacts" id="other_contacts" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="other_contacts"><span class='translate' data-i18n="698" notes="Other Contacts"></span></label>
							</div>
							
						</div>	

						<div class="form-group photoImage" id="pictures_of_workspace"> 
							<label class="d-block"><span class='translate' data-i18n="2374" notes="Pictures of Workplace"></span></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="Add Images"></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
								<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
								<div class="row photoGallery" id="galleryid_wp"></div>
						</div>
						
						<div class="md-form">
							<textarea name="rescue_plan_steps_and_details" id="rescue_plan_steps_and_details" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="rescue_plan_steps_and_details"><span class='translate' data-i18n="789" notes="Rescue Plan Steps and Details"></span></label>
						</div>
						<div class="my-4 mt-3">
							<label class="text-muted"><span class='translate' data-i18n="2375" notes="Rescue Sketch"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='rescue_sketch_draw'><i class="fa fa-pen"></i> <span class='translate' data-i18n="2376" notes="Draw"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none' sketchname='rescue_sketch_draw'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='rescue_sketch_draw_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="rescue_sketch_draw" id="rescue_sketch_draw" class='modalSignature' value='' >
							<input type="hidden" name="vector_manager" id='vector_manager' value=''>
							<input type="hidden" name="rescue_sketch_draw_comments" id='rescue_sketch_draw_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="rescue_sketch_draw_img_time" id="rescue_sketch_draw_img_time" notes='rescue_sketch_draw_img_time' readonly/></small>
						</div>
							<div class="form-group photoImage" id="rescue_sketch_pic"> 
								<canvas id="canvas2" style='display:none;'></canvas>
								<div class="btn-group d-flex" role="group">
									<div class="btn btn-block btn-outline-secondary file-field px-1">
										<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="Add Images"></span>
										<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
									</div>
								</div>
								<div id="siteHelp" class="form-text text-muted" ></div>
									<div class="row photoGallery" id="galleryid_rsp"></div>
							</div>
		
						<div class="md-form">
							<textarea name="alternative_rescue_details" id="alternative_rescue_details" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="alternative_rescue_details"><span class='translate' data-i18n="29" notes="Alternative Rescue Details"></span></label>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="746" notes="Plan Approver"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='plan_approver'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='plan_approver_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="plan_approver" id="plan_approver" class='modalSignature' value='' >
							<input type="hidden" name="vector_manager" id='vector_manager_1' value=''>
							<input type="hidden" name="plan_approver_comments" id='plan_approver_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="plan_approver_img_time" id="plan_approver_img_time" notes='plan_approver_img_time' readonly/></small>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag="2248" class = "trans_input" value="2248" note="RESCUE PLAN" />
						<input type="hidden" name="formtype" id="formtype" value="SUP" />
						<input type="hidden" name="formid" id="formid" value="372338" />
						<input type="hidden" name="version" id="version" value="1" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>


<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}	
	};



</script>
<script src="/js/groupEquipment.js"></script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
<script type="text/javascript" src="/js/jquery.signaturepad.min.js"></script>
<script>

	$('#retrieval_equipment').change(function(e){
		$("#other_retrieval_equipment").prop('required',false)
			if(checkOther('retrieval_equipment', $(this).val())){
				$("#other_retrieval_equipment_div").show()
				$("#other_retrieval_equipment").prop('required',true)
			}else{
				$("#other_retrieval_equipment_div").hide()
				$("#other_retrieval_equipment").prop('required',false)
				$("#other_retrieval_equipment").val('').parent().find('label').removeClass('active filled')
			}
	})

	$('#special_ppe_requirements').change(function(e){
		$("#other_special_ppe").prop('required',false)
			if(checkOther('special_ppe_requirements', $(this).val())){
				$("#other_chosen").show()
				$("#other_special_ppe").prop('required',true)
			}else{
				$("#other_chosen").hide()
				$("#other_special_ppe").prop('required',false)
				$("#other_special_ppe").val('').parent().find('label').removeClass('active filled')
			}

			if(checkOther('special_ppe_requirements', $(this).val(), i18next.t("2668"))){ // SABA (Blue Box)
				$("#blue_box").show()
				$("#blue_box_air_tender").prop('required',true)
				$("#blue_box_hose_tender").prop('required',true)
			}else{
				$("#blue_box").hide()
				$("#blue_box_air_tender").prop('required',false)
				$("#blue_box_air_tender").val('').parent().find('label').removeClass('active filled')
				$("#blue_box_hose_tender").prop('required',false)
				$("#blue_box_hose_tender").val('').parent().find('label').removeClass('active filled')
			}
	})

	$('#communication_strategy').change(function(e){
		$("#other_communication_methods").prop('required',false)
			if(checkOther('communication_strategy', $(this).val())){
				$("#other_communication").show()
				$("#other_communication_methods").prop('required',true)
			}else{
				$("#other_communication").hide()
				$("#other_communication_methods").prop('required',false)
				$("#other_communication_methods").val('').parent().find('label').removeClass('active filled')
			}
	})

	$('#key_contacts').change(function(e){
		$("#other_contacts").prop('required',false)
			if(checkOther('key_contacts', $(this).val())){
				$("#other_key_contacts").show()
				$("#other_contacts").prop('required',true)
			}else{
				$("#other_key_contacts").hide()
				$("#other_contacts").prop('required',false)
				$("#other_contacts").val('').parent().find('label').removeClass('active filled')
			}
	})

	function clearEquipmentFields(id) {
        if(id === 'job_number' || id === 'site'){
           
            all_rest = []
            let optionData = `<select name="equipment_involved" id="equipment_involved" class="select-multiple mobile-equipment-select" multiple>`
            all_rest.forEach((data)=>{
                optionData += `<option value="${data.id}">${data.text}</option>`
            })
            optionData += `</select>`
            $(`#equipment_involved`).html(optionData)
			if(main_current_draft_object){
            	main_current_draft_object.equipment_involved = null
			}
            initializeEquipmentSelect2(`equipment_involved`)
            $(`#equipment_involved`).parent().find('label').html(i18next.t("9559"))
			$(`#equipment_involved`).val("").trigger("change").parent().find('label').removeClass(['filled',"active"])
        }
    }
</script>