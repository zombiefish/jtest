<?php	
  $strPageTitle = 'Cap and Powder Mag Audit';
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
        
						<h6 class="text-secondary"><span class='translate' data-i18n="1022" notes="Cap and Powder Mag Audit"></span></h6>
						<div class="pt-1 position-relative my-4">
							<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
							</select>
							<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
						</div>

						<form name="daily_log" id="TemplateForm" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>
						
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="62" notes="Auditor"></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="auditor" id="auditor" class="select-single mobile-supervisors-select" required>
							</select>
							<label for="auditor"><span class='translate' data-i18n="62" notes="Auditor"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1660" notes="Powder Magazine"></span></h6>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="181" notes="Does the magazine provide protection from vehicle impact or vehicle fires"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="pow_mag_vehicle_impact_fires_yes" name="pow_mag_vehicle_impact_fires" value="1" required>
								<label class="form-check-label mr-2" for="pow_mag_vehicle_impact_fires_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="pow_mag_vehicle_impact_fires_no" name="pow_mag_vehicle_impact_fires" value="0">
								<label class="form-check-label mr-2" for="pow_mag_vehicle_impact_fires_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="1661" notes="Do “Danger Explosives” signs from all approaches mark the magazine?"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="pow_explosives_signs_yes" name="pow_explosives_signs" value="1" required>
								<label class="form-check-label mr-2" for="pow_explosives_signs_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="pow_explosives_signs_no" name="pow_explosives_signs" value="0">
								<label class="form-check-label mr-2" for="pow_explosives_signs_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>	
						
							<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="599" notes="Is the magazine in good condition?"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="pow_mag_good_condition_yes" name="pow_mag_good_condition" value="1" required>
								<label class="form-check-label mr-2" for="pow_mag_good_condition_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="pow_mag_good_condition_no" name="pow_mag_good_condition" value="0">
								<label class="form-check-label mr-2" for="pow_mag_good_condition_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>	

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="38" notes="Are the explosives in good condition?"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="pow_explosives_good_condition_yes" name="pow_explosives_good_condition" value="1" required>
								<label class="form-check-label mr-2" for="pow_explosives_good_condition_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="pow_explosives_good_condition_no" name="pow_explosives_good_condition" value="0">
								<label class="form-check-label mr-2" for="pow_explosives_good_condition_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>	

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="597" notes="Is the magazine clean, dry and free of grit?"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="pow_mag_clean_yes" name="pow_mag_clean" value="1" required>
								<label class="form-check-label mr-2" for="pow_mag_clean_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="pow_mag_clean_no" name="pow_mag_clean" value="0">
								<label class="form-check-label mr-2" for="pow_mag_clean_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>	

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="37" notes="Are the explosives being rotated properly?"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="pow_explosives_rotated_yes" name="pow_explosives_rotated" value="1" required>
								<label class="form-check-label mr-2" for="pow_explosives_rotated_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="pow_explosives_rotated_no" name="pow_explosives_rotated" value="0">
								<label class="form-check-label mr-2" for="pow_explosives_rotated_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>																			

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="607" notes="Is there an accumulation of damaged explosives?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="pow_accum_damaged_explosives_yes" name="pow_accum_damaged_explosives" value="1" required>
								<label class="form-check-label mr-2" for="pow_accum_damaged_explosives_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="pow_accum_damaged_explosives_no" name="pow_accum_damaged_explosives" value="0">
								<label class="form-check-label mr-2" for="pow_accum_damaged_explosives_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>		

			<div class='cond-form-check-area'> 
						<div class="md-form">
							<input type="number" step='.01' name="pow_damaged_explosives_kg" id="pow_damaged_explosives_kg" value='N/A' class="form-control" required>
							<label for="pow_damaged_explosives_kg"><span class='translate' data-i18n="537" notes="How many Kg?"></span></label>
						</div>
            </div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="45" notes="Are there any tools and/or equipment stored in magazine?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="pow_tools_in_magazine_yes" name="pow_tools_in_magazine" value="1" required>
								<label class="form-check-label mr-2" for="pow_tools_in_magazine_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="pow_tools_in_magazine_no" name="pow_tools_in_magazine" value="0">
								<label class="form-check-label mr-2" for="pow_tools_in_magazine_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="31" notes="Are kettle loaders and loading accessories stored separately and properly?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="pow_kettle_loaders_stored_yes" name="pow_kettle_loaders_stored" value="1" required>
								<label class="form-check-label mr-2" for="pow_kettle_loaders_stored_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="pow_kettle_loaders_stored_no" name="pow_kettle_loaders_stored" value="0">
								<label class="form-check-label mr-2" for="pow_kettle_loaders_stored_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="499" notes="Has refuse been removed from magazine?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="pow_refuse_removed_yes" name="pow_refuse_removed" value="1" required>
								<label class="form-check-label mr-2" for="pow_refuse_removed_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="pow_refuse_removed_no" name="pow_refuse_removed" value="0">
								<label class="form-check-label mr-2" for="pow_refuse_removed_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>		
						
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="490" notes="Are products (boxes/containers/totes) labelled properly?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="pow_products_labelled_properly_yes" name="pow_products_labelled_properly" value="1" required>
								<label class="form-check-label mr-2" for="pow_products_labelled_properly_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="pow_products_labelled_properly_no" name="pow_products_labelled_properly" value="0">
								<label class="form-check-label mr-2" for="pow_products_labelled_properly_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>	

						<div class="md-form">
							<input type="number" min="0" onkeyup="if(this.value<0){this.value= this.value * -1}" step='.01' onchange="setTwoNumberDecimal(this)" name="pow_quantity_explosives_kg" id="pow_quantity_explosives_kg" class="form-control" required>
							<label for="pow_quantity_explosives_kg"><span class='translate' data-i18n="1662" notes="Qty. of explosives stored in the magazine? (Kg)"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1663" notes="Cap Magazine"></span></h6>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="598" notes="Is the magazine conspicuously marked by 'DANGER EXPLOSIVE' signs from all approaches?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="cap_marked_danger_signs_yes" name="cap_marked_danger_signs" value="1" required>
								<label class="form-check-label mr-2" for="cap_marked_danger_signs_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="cap_marked_danger_signs_no" name="cap_marked_danger_signs" value="0">
								<label class="form-check-label mr-2" for="cap_marked_danger_signs_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="599" notes="Is the magazine in good condition?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="cap_magazine_good_yes" name="cap_magazine_good" value="1" required>
								<label class="form-check-label mr-2" for="cap_magazine_good_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="cap_magazine_good_no" name="cap_magazine_good" value="0">
								<label class="form-check-label mr-2" for="cap_magazine_good_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="34" notes="Are the detonators in good condition?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="cap_detonators_good_yes" name="cap_detonators_good" value="1" required>
								<label class="form-check-label mr-2" for="cap_detonators_good_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="cap_detonators_good_no" name="cap_detonators_good" value="0">
								<label class="form-check-label mr-2" for="cap_detonators_good_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="46" notes="Are there approved detonator carriers marked 'EXPLOSIVES' available to transport detonators?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="cap_detonators_carriers_yes" name="cap_detonators_carriers" value="1" required>
								<label class="form-check-label mr-2" for="cap_detonators_carriers_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="cap_detonators_carriers_no" name="cap_detonators_carriers" value="0">
								<label class="form-check-label mr-2" for="cap_detonators_carriers_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="499" notes="Has refuse been removed from magazine?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="cap_refuse_removed_yes" name="cap_refuse_removed" value="1" required>
								<label class="form-check-label mr-2" for="cap_refuse_removed_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="cap_refuse_removed_no" name="cap_refuse_removed" value="0">
								<label class="form-check-label mr-2" for="cap_refuse_removed_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="490" notes="Are products (boxes/containers/totes) labelled properly?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="cap_products_labelled_properly_yes" name="cap_products_labelled_properly" value="1" required>
								<label class="form-check-label mr-2" for="cap_products_labelled_properly_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="cap_products_labelled_properly_no" name="cap_products_labelled_properly" value="0">
								<label class="form-check-label mr-2" for="cap_products_labelled_properly_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="md-form">
							<input type="number" min="0" onkeyup="if(this.value<0){this.value= this.value * -1}" onchange="setTwoNumberDecimal(this)" name="cap_quantity_detonators_units" id="cap_quantity_detonators_units" class="form-control" required>
							<label for="cap_quantity_detonators_units"><span class='translate' data-i18n="1664" notes="Qty. of detonators stored in the magazine (Units)"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="81" notes="Comments"></span></h6>

						<div class="md-form">
							<textarea name="comments" id="comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="comments"><span class='translate' data-i18n="81" notes="Comments"></span></label>
						</div>


						<div class="form-group photoImage" id="multiphoto_picker_1"> 
							<label class="d-block"><span class='translate' data-i18n="1413" notes="Include Photos"></span></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i><span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
							<div class="row photoGallery" id="galleryid"></div>
						</div>

                        <div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="63" notes="Auditor Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='signature_auditor'><i class="fa fa-pen"></i><span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_auditor_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_auditor" id="signature_auditor" class='modalSignature' value='' required>
							<input type="hidden" name="vector_signature" id='vector_signature' value=''>
							<input type="hidden" name="signature_auditor_comments" id='signature_auditor_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_auditor_img_time" id="signature_auditor_img_time" notes='signature_auditor_img_time' readonly/></small>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag="1022" class = "trans_input" value="1022" />
						<input type="hidden" name="formtype" id="formtype" value="SUP" />
						<input type="hidden" name="formid" id="formid" value="372288" />
						<input type="hidden" name="version" id="version" value="1" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>


<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
			return true;
		}	
	}

	function setTwoNumberDecimal(el) {
        el.value = parseFloat(el.value).toFixed(2);
    };

</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>

<script type="text/javascript">
$('input:radio[name=pow_accum_damaged_explosives]').on('change', function(e) {
	if(e.currentTarget.defaultValue == 0) {
		document.getElementById('pow_damaged_explosives_kg').value = ''
	}
})
</script>