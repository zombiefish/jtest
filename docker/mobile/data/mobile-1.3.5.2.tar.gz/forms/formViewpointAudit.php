<?php	
  $strPageTitle = 'Viewpoint Audit';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary">Viewpoint Audit</h6>
          <div class="pt-1 position-relative my-4">
            <select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
            </select>
            <label for="draft">Form Drafts</label>
          </div>

          <form name="formViewpointAudit" id="formViewpointAudit" class="needs-validation" method="POST" action="#" novalidate>
          
						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4">Audit</h6>

						<div class="pt-1 position-relative my-4">
							<select name="auditor" id="auditor" class="select-single mobile-supervisors-select" required>
							</select>
							<label for="auditor">Auditor</label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="employee" id="employee" class="select-single mobile-employee-select-single" required>
							</select>
							<label for="employee">Employee</label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="project_manager" id="project_manager" class="select-single mobile-supervisors-select" required>
							</select>
							<label for="project_manager">Project Manager</label>
						</div>

						<div class="md-form">
							<input type="text" name="reference_number" id="reference_number" class="form-control" length="200" maxlength="200">
							<label for="reference_number">Reference Number</label>
						</div>

						<div class="md-form">
							<input type="text" name="date_submitted" id="date_submitted" class="form-control datepicker pt-4" required>
							<label for="date_submitted">Date Submitted by Trainer</label>
						</div>

						<div class="mb-4" >
							<label class="d-block">Is the Record Entered in Viewpoint?</label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="entered_viewpoint_yes" name="entered_viewpoint" value="1" required>
								<label class="form-check-label mr-2" for="entered_viewpoint_yes">Yes</label>

								<input type="radio" class="form-check-input" id="entered_viewpoint_no" name="entered_viewpoint" value="0">
								<label class="form-check-label mr-2" for="entered_viewpoint_no">No</label>
							</div>
						</div>

						<div class="md-form">
							<input type="number" name="Elapsed_Time" id="Elapsed_Time" class="form-control" min="0">
							<label for="Elapsed_Time">Elapsed Time in Days</label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="Record_Status" id="Record_Status" class="select-single mobile-recordstatus-select" required>
							</select>
							<label for="Record_Status">What is the Training Record Status</label>
						</div>

					    <div class="form-group photoImage" id="info"> 
						    <label class="d-block">Include Photos</label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> Add Images
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted">Please take scene pictures from all perspectives</small>
							<div class="row photoGallery" id="galleryid"></div>
						</div>

						<h6 class="text-secondary pt-4">Comments</h6>
						<div class="md-form">
							<textarea name="sts_feedback" id="sts_feedback" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="sts_feedback">STS Feedback</label>
						</div>

						<h6 class="text-secondary pt-4">Correction and Action Requirements </h6>

						<div class="mb-4">
							<label class="d-block">Were any areas of improvement identified?</label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input radio-check" id="any_areas_of_improvement_identified_yes" name="any_areas_of_improvement_identified" value="1" required>
								<label class="form-check-label mr-2" for="any_areas_of_improvement_identified_yes">Yes</label>

								<input type="radio" class="form-check-input radio-check" id="any_areas_of_improvement_identified_no" name="any_areas_of_improvement_identified" value="0">
								<label class="form-check-label mr-2" for="any_areas_of_improvement_identified_no">No</label>
							</div>
						</div>

<div class='cond-form-check-area'> 

						<div class="mb-4">
							<label class="d-block">Is a follow up required with the employee</label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="follow_up_with_the_employee_yes" name="follow_up_with_the_employee" value="1" required>
								<label class="form-check-label mr-2" for="follow_up_with_the_employee_yes">Yes</label>

								<input type="radio" class="form-check-input" id="follow_up_with_the_employee_no" name="follow_up_with_the_employee" value="0">
								<label class="form-check-label mr-2" for="follow_up_with_the_employee_no">No</label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block">Is a follow up required with the task</label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="follow_up_with_the_task_yes" name="follow_up_with_the_task" value="1" required>
								<label class="form-check-label mr-2" for="follow_up_with_the_task_yes">Yes</label>

								<input type="radio" class="form-check-input" id="follow_up_with_the_task_no" name="follow_up_with_the_task" value="0">
								<label class="form-check-label mr-2" for="follow_up_with_the_task_no">No</label>
							</div>
						</div>
</div>		
			
						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" value="VIEWPOINT AUDIT" />
						<input type="hidden" name="formtype" id="formtype" value="STS" />
						<input type="hidden" name="formid" id="formid" value="236709"/>
						<input type="hidden" name="version" id="version" value="13" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="employee" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}	
	}
	function radioButtonCheck() {
		$('.radio-check').change((e) =>{
			requiredRadio(e.currentTarget.defaultValue)
		})
	};
	document.addEventListener('DOMContentLoaded', radioButtonCheck, false);
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>