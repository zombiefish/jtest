<?php	
  $strPageTitle = 'Monthly Safety Meeting';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary"><span class='translate' data-i18n='1026' notes='Monthly Safety Meeting'></span></h6>
          <div class="pt-1 position-relative my-4">
            <select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
            </select>
            <label for="draft"><span class='translate' data-i18n='1474' notes='Form Drafts'></span></label>
          </div>

          <form name="formMonthlySafetyMeeting" id="formMonthlySafetyMeeting" class="needs-validation" method="POST" action="#" novalidate>
          
						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1672' notes='Minutes'></span></h6>

						<div class="md-form">
							<input type="text" name="time" id="time" class="form-control timepicker">
							<label for="time"><span class='translate' data-i18n='862' notes='Time'></span></label>
						</div>


						<div class="pt-1 position-relative my-4">
							<select name="host" id="host" class="select-single mobile-supervisors-select" required>
							</select>
							<label for="host"><span class='translate' data-i18n='518' notes='Host'></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="attendance" id="attendance" class="select-multiple mobile-employee-select" multiple required>
							</select>
							<label for="attendance"><span class='translate' data-i18n='57' notes='Attendance'></span></label>
						</div>

						<div class="md-form">
							<textarea name="old_business" id="old_business" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="old_business"><span class='translate' data-i18n='1673' notes='Old Business'></span></label>
						</div>

						<div class="form-group photoImage" id="pictures"> 
							<label class="d-block"><span class='translate' data-i18n='1413' notes='Include Photos'></span></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n='2340' notes='ADD IMAGES'></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n='1389' notes='Please take scene pictures from all perspectives'></span></small>
							<div class="row photoGallery" id="galleryid"></div>
						</div>

						<div class="md-form">
							<textarea name="safety_share_1" id="safety_share_1" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="safety_share_1"><span class='translate' data-i18n='1674' notes='Safety Share'></span> 1</label>
						</div>

						<div class="md-form">
							<textarea name="safety_share_2" id="safety_share_2" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="safety_share_2"><span class='translate' data-i18n='1674' notes='Safety Share'></span> 2</label>
						</div>

						<div class="md-form">
							<textarea name="safety_share_3" id="safety_share_3" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="safety_share_3"><span class='translate' data-i18n='1674' notes='Safety Share'></span> 3</label>
						</div>

						<div class="md-form">
							<input type="text" name="site_procedure" id="site_procedure" class="form-control" length="200" maxlength="200">
							<label for="site_procedure"><span class='translate' data-i18n='830' notes='Site Specific Procedure or Protocol Reviewed'></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1675' notes='Reviewed Hazard and/or MOL alerts'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="mol_review_yes" name="mol_review" value="1" required>
								<label class="form-check-label mr-2" for="mol_review_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="mol_review_no" name="mol_review" value="0">
								<label class="form-check-label mr-2" for="mol_review_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<!-- <div class="mb-4">
							<label class="d-block">Accident Review for previous month</label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="accident_review_yes" name="accident_review" value="1" required>
								<label class="form-check-label mr-2" for="accident_review_yes">Yes</label>

								<input type="radio" class="form-check-input" id="accident_review_no" name="accident_review" value="0">
								<label class="form-check-label mr-2" for="accident_review_no">No</label>
							</div>
						</div> -->

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1677' notes='Incident Review for previous month'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="incident_review_yes" name="incident_review" value="1" required>
								<label class="form-check-label mr-2" for="incident_review_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="incident_review_no" name="incident_review" value="0">
								<label class="form-check-label mr-2" for="incident_review_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<!-- <div class="md-form">
							<input type="number" step='.01' name="month_trif" id="month_trif" class="form-control">
							<label for="month_trif">Previous Month TRIFR</label>
						</div> -->

						<div class="md-form">
							<input type="number" step='.01' name="month_trif_ytd" id="month_trif_ytd" class="form-control">
							<label for="month_trif_ytd"><span class='translate' data-i18n='3916' notes='Year to Date TRIF'></span></label>
						</div>

						<!-- <div class="mb-4">
							<label class="d-block">WSN TRIFR Reviw for Previous Month</label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="wsn_stats_yes" name="wsn_stats" value="1" >
								<label class="form-check-label mr-2" for="wsn_stats_yes">Yes</label>

								<input type="radio" class="form-check-input" id="wsn_stats_no" name="wsn_stats" value="0">
								<label class="form-check-label mr-2" for="wsn_stats_no">No</label>
							</div>
						</div> -->

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1679' notes='Reviewed JHSC latest workplace inspection'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="jhsc_review_yes" name="jhsc_review" value="1" required>
								<label class="form-check-label mr-2" for="jhsc_review_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="jhsc_review_no" name="jhsc_review" value="0">
								<label class="form-check-label mr-2" for="jhsc_review_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<!-- <div class="md-form">
							<input type="text" name="monthly_topic" id="monthly_topic" class="form-control" required>
							<label for="monthly_topic">Monthly Safety Topic</label>
						</div> -->

						<div class="md-form">
							<input type="text" name="on_job_safety" id="on_job_safety" class="form-control" length="200" maxlength="200" required>
							<label for="on_job_safety"><span class='translate' data-i18n='681' notes='On the job safety topic'></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="on_job_safety_1" id="on_job_safety_1" class="form-control" length="200" maxlength="200" required>
							<label for="on_job_safety_1"><span class='translate' data-i18n='676' notes='Off the job safety topic'></span></label>
						</div>

						<div class="md-form">
							<textarea name="new_business" id="new_business" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="new_business"><span class='translate' data-i18n='1680' notes='New Business'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='81' notes='Comments'></span></h6>

						<div class="md-form">
							<textarea name="comments" id="comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="comments"><span class='translate' data-i18n='81' notes='Comments'></span></label>
						</div>

						<!--- Common form header, this should be an include -->
						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag = "1026" class = "trans_input" value="1026" note="MONTHLY SAFETY MEETING" />
						<input type="hidden" name="formtype" id="formtype" value="SUP" />
						<input type="hidden" name="formid" id="formid" value="236336"/>
						<input type="hidden" name="version" id="version" value="23" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>

				</div>
			</div>
		</div>
	</div>
</main>

    <div id="sync-wrapper">
    </div>

    <div id="output">
    </div>

	<div><!--- row -->
</div> <!--- container -->

<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}	
	}
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>