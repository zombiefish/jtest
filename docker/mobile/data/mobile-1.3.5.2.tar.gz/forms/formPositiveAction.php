<?php	
  $strPageTitle = 'Positive Recognition';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary"><span class='translate' data-i18n="751" note="Positive Recognition"></span></h6>
          <div class="pt-1 position-relative my-4">
            <select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
            </select>
            <label for="draft"><span class='translate' data-i18n="1474" note="From Drafts"></span></label>
          </div>

          <form name="PositiveIdentification" id="PositiveIdentification" class="needs-validation" method="GET" action="#" novalidate>
		  
		  <canvas id="canvas" style='display:none;'></canvas>

						<?php include 'includes/CommonFormHeader.php' ?>
						<?php include 'includes/CommonFormFooter.php' ?>
						<input type="hidden" name="formname" id="formname" class = "trans_input" value="2561" tag="2561" />
						<input type="hidden" name="formtype" id="formtype" value="HR" />
						<input type="hidden" name="formid" id="formid" value="350049"/>
						<input type="hidden" name="version" id="version" value="2" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?><script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}	
	}
</script>


<script>
		$("#info").before('<small class="alert alert-primary d-block" role="alert"> <span class="translate" data-i18n="3097" note="This form requires a pid "></span> </small>');
</script>