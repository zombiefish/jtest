<?php	
  $strPageTitle = 'Daily Drilling Report';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<form name="daily_drilling_report" id="TemplateForm" class="needs-validation" method="POST" action="#" novalidate>
				<div class="card mb-4">
					<div class="card-body">
						<h6 class="text-secondary"><span class='translate' data-i18n="9299" notes="Daily Drilling Report"></span></h6>
						<div class="pt-1 position-relative my-4">
							<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
							</select>
							<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
						</div>

						<?php include 'includes/CommonFormHeader.php' ?>
					</div>
				</div>
				<canvas id="canvas" style='display:none;'></canvas>
				<div class="card mb-4">
					<div class="card-body">
						<div class="pt-1 position-relative my-4">
							<select name="equipment_id" id="equipment_id" class="select-single">
							</select>
							<label for="equipment_id"><span class='translate' data-i18n="9559" notes="Please select Site and Department/Job to select Equipment"></span></label>
						</div>

						<div class="mb-4">
							<label for="cleanliness_order"><span class='translate' data-i18n='820' notes='Shift'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="shift_days" name="shift" tag="1095" value="1095" notes="Days" required>
								<label class="form-check-label mr-2" for="shift_days"><span class='translate' data-i18n='1095' notes='Days'></span></label>

								<input type="radio" class="form-check-input trans_input" id="shift_nights" name="shift" tag="1375" value="1375" notes="Nights">
								<label class="form-check-label mr-2" for="shift_nights"><span class='translate' data-i18n='1375' notes='Nights'></span></label> 
							</div>
						</div>

						<div class="mb-4">
							<label for="cleanliness_order"><span class='translate' data-i18n='9300' notes='Unit of measurement'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="unit_imperial" name="unit" tag="9301" value="9301" notes="Imperial" onChange="populateUnit(this)" required>
								<label class="form-check-label mr-2" for="unit_imperial"><span class='translate' data-i18n='9301' notes='Imperial'></span></label>
							
								<input type="radio" class="form-check-input trans_input" id="unit_metric" name="unit" tag="2765" value="2765" notes="Metric" onChange="populateUnit(this)">
								<label class="form-check-label mr-2" for="unit_metric"><span class='translate' data-i18n='2765' notes='Metric'></span></label> 
							</div>
						</div>
					</div>
				</div>

				<div>
					<!-- Accordian Wrapper -->
					<div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
						<ul id="crews" class="pl-0">
						</ul>
					</div>  
					<div class="btn btn-flat px-0 font-weight-bolder text-primary" id='addCrew'><i class="fa fa-plus"></i><span class='translate' data-i18n='9322' notes='ADD ENTRY'></span></div>
					<input type="hidden" name="removeCrew" id="removeCrew" value="" />
				</div>

				<div class="card mb-4">
					<div class="card-body">
						<!-- <table> -->
						<table class="w-100 table">				
							
							<thead>
								<tr>
									<th class="text-right" style="border-bottom: none" scope="col">
										<span class='translate' data-i18n='9346' notes='Total Shift Hours'> :</span>
									</th>
									<th name="total_shift_hours" id="total_shift_hours" class="mb-0 font-weight-bold" style="border-bottom: none"  scope="col">
										
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td class="text-right">
										<span class='translate' data-i18n='9323' notes='Total Hours Drilled'> :</span>
									</td>
									<td name="total_hours_drilled" id="total_hours_drilled" class="mb-0 font-weight-bold"></td>
								</tr>
								<tr>
									<td class="text-right">
										<span class='translate' data-i18n='9324' notes='Total Production Drilled'> :</span>
									</td>
									<td name="total_production_meters_drilled" id="total_production_meters_drilled" class="mb-0 font-weight-bold"></td>
								</tr>
								<tr>
									<td class="text-right">
										<span class='translate' data-i18n='9325' notes='Total Cable Drilled'> :</span>
									</td>
									<td name="total_cable_meters_drilled" id="total_cable_meters_drilled" class="mb-0 font-weight-bold"></td>
								</tr>
								<tr>
									<td class="text-right">
										<span class='translate' data-i18n='9326' notes='Total Redrill'> :</span>
									</td>
									<td name="total_redrill_meters_drilled" id="total_redrill_meters_drilled" class="mb-0 font-weight-bold"></td>
								</tr>
							</tbody>
						
						</table>
					</div>
				</div>

				<div>
					<!-- Accordian Wrapper -->
					<div class="accordion md-accordion" role="tablist" aria-multiselectable="true">
						<ul id="used" class="pl-0">
						</ul>
					</div>  
					<div class="btn btn-flat px-0 font-weight-bolder text-primary" id='addUsedMaterial'><i class="fa fa-plus"></i><span class='translate' data-i18n='9322' notes='ADD ENTRY'></span></div>
				</div>	

				<div class="card mb-4">
					<div class="card-body">
						<div class="md-form">
							<textarea name="comments" id="comments" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="comments"><span class='translate' data-i18n="81" notes="Comments"></span></label>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n='850' notes='Supervisor Signature'></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='signature_supervisor'><i class="fa fa-pen"></i> <span class='translate' data-i18n='1396' notes='Sign'></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n='1422' notes='Clear'></span></div>
							</div>
							<img id='signature_supervisor_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_supervisor" id="signature_supervisor" class='modalSignature' value='' required>
							<input type="hidden" name="vector_supervisor" id='vector_supervisor' value=''>
							<input type="hidden" name="signature_supervisor_comments" id='signature_supervisor_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_supervisor_img_time" id="signature_supervisor_img_time" notes='signature_supervisor_img_time' readonly/></small>
						</div>
						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag= "9299" class = "trans_input" value="9299" />
						<input type="hidden" name="formtype" id="formtype" value="SR" />
						<input type="hidden" name="formid" id="formid" value="372458" />
						<input type="hidden" name="version" id="version" value="1" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
						<input type="hidden" name="numCrews" id="numCrews" value='1' />
						<input type="hidden" name="totalCrews" id="totalCrews" value='20' />     
						<input type="hidden" name="numUsed" id="numUsed" value='1' />
						<input type="hidden" name="totalUsed" id="totalUsed" value='5' /> 
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</div>
				</div>
			</form>
		</div>
	</div>
</main>

<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
			return true;
		}	
	}

	$( document ).ready(function() {
		getCalculationItems()
		addCrew(1,"afterDelete")
		addUsedMaterial(1)
	});

	let totalShiftHours=0,totalHoursDrilled=0,totalProductionMetersDrilled=0,totalCableMetersDrilled=0,totalRedrillMetersDrilled=0;
	let unit="unit"
	let hoursCalculationFactors=[]
	let productionMetersCalculationFactor=[]
	let cableMetersCalculationFactor=[]
	var invalidChars = ["-","+","e"]

	function addCrew(crewNum,mode){
		const crewsModal = 
		`
			<li class="delete_entry ui-state-default card mb-4 crewsection" id="timeEntryIndex_${crewNum}">
				<div> 
					<!-- Accordion card -->
					<div class="card">
						<!-- Card header -->
						<div class="card-header px-3" role="tab" id="heading_${crewNum}">
							<!-- Sort Number, Three Icons -->
							<div class="w-100 px-3">
								<span class='text-muted' id="entry_order_${crewNum}">${crewNum}</span>
								<span class="float-right row align-items-center">
									<i class="fas fa-arrows-alt is-3 mr-4 handle" style="color:#696969;cursor: grab;" data-i18n='3804'  note="Drag and Sort" title=""></i>
									<div class="dropdown">
										<i class="far fa-trash-alt mr-4 text-primary" data-i18n='3805' note="Delete Event Category" title="" style="cursor: pointer;" data-toggle="dropdown"></i>
										<div class="dropdown-menu dropdown-menu-right dropdown-primary">
											<Strong><span class='translate' data-i18n='2314' notes='Delete this item?'></span></Strong>
											<a class="dropdown-item"><i><span class='translate' data-i18n='1380' notes='No'></span></i></a>
											<a class="dropdown-item" onclick="deleteEntry(this)"><i><span class='translate' data-i18n='1379' notes='Yes'></span></i></a>
										</div>
									</div>
									<a data-toggle="collapse" data-target="#collapse_${crewNum}" aria-expanded="true" class="mr-3">
										<i class="fas fa-angle-down rotate-icon"></i>
									</a>
								</span>
							</div>
							<!-- Event Header -->
							<br />
							<h6 class="text-secondary pt-4"><span class='translate' data-i18n='3360' notes='Time Entry'></span></h6>
							<div class="md-form">
								<input type="text" class="form-control timepicker " name="start_time_${crewNum}" id="start_time_${crewNum}" required>
								<label for="start_time_${crewNum}"><span class='translate' data-i18n="2367" notes="Start Time"></span></label>
							</div>
							
							<div class="pt-1 position-relative my-4">
								<select name="time_and_delays_code_${crewNum}" id="time_and_delays_code_${crewNum}" class="mobile-drillingtimeanddelayscode-select ">
								</select>
								<label for="time_and_delays_code_${crewNum}"><span class='translate' data-i18n="9302" notes="Time & Delays Code"></span></label>
							</div>

							<div class="md-form">
								<input type="text" class="form-control timepicker " name="end_time_${crewNum}" id="end_time_${crewNum}" required>
								<label for="end_time_${crewNum}"><span class='translate' data-i18n="2368" notes="End Time"></span></label>
							</div>

							<div id="collapse_${crewNum}" class="collapse show" role="tabpanel" data-parent="#accordionEx">
								<div class="md-form pt-1 position-relative my-4">
									<input type="text" name="ring_no_${crewNum}" id="ring_no_${crewNum}" class="form-control" length="200" maxlength="200">
									<label for="ring_no_${crewNum}" style="width:100%"><span class='translate' data-i18n="9310" notes="Ring"></span> #</label>
								</div>

								<div class="md-form pt-1 position-relative my-4">
									<input type="text" name="hole_no_${crewNum}" id="hole_no_${crewNum}" class="form-control" length="200" maxlength="200">
									<label for="hole_no_${crewNum}" style="width:100%"><span class='translate' data-i18n="9311" notes="Hole"></span> #</label>
								</div>

								<div class="md-form pt-1 position-relative my-4">
									<input type="number" name="planned_length_${crewNum}" id="planned_length_${crewNum}" class="form-control" min="0.00" step="0.01">
									<label for="planned_length_${crewNum}" style="width:100%"><span class='translate' data-i18n="9312" notes="Planned Length"></span></label>
								</div>

								<h6 class="text-secondary pt-4"><span class='translate' data-i18n='9313' notes='Angles'></span></h6>
								<div class="md-form">
									<input type="text" name="angles_dip_${crewNum}" id="angles_dip_${crewNum}" class="form-control" length="200" maxlength="200"> 
									<label for="angles_dip_${crewNum}" style="width:100%"><span class='translate' data-i18n="9314" notes="Dip"></span></label>
								</div>

								<div class="md-form">
									<input type="text" name="angles_dump_${crewNum}" id="angles_dump_${crewNum}" class="form-control" length="200" maxlength="200">
									<label for="angles_dump_${crewNum}" style="width:100%"><span class='translate' data-i18n="9315" notes="Dump"></span></label>
								</div>

								<div class="md-form">
									<input type="text" name="from_${crewNum}" id="from_${crewNum}" class="form-control" length="200" maxlength="200">
									<label for="from_${crewNum}"><span class='translate' data-i18n='1134' notes='From'></span></label>
								</div>

								<div class="md-form">
									<input type="text" name="to_${crewNum}" id="to_${crewNum}" class="form-control" length="200" maxlength="200">
									<label for="to_${crewNum}"><span class='translate' data-i18n='9341' notes='To'></span></label>
								</div>		

								<div class="pt-1 position-relative my-4">
									<select name="bit_size_${crewNum}" id="bit_size_${crewNum}" class="select-single mobile-drillingbitsize-select">
									</select>
									<label for="bit_size_${crewNum}"><span class='translate' data-i18n="9316" notes="Bit Size"></span></label>
								</div>

								<div class="md-form pt-1 position-relative my-4">
									<input type="number" name="drilling_length_${crewNum}" id="drilling_length_${crewNum}" class="form-control " min="0.00" step="0.01">
									<label for="drilling_length_${crewNum}" style="width:100%"><span class='translate' data-i18n="9317" notes="Drilled Length"></span></label>
								</div>

								<div class="pt-1 position-relative my-4">
									<select name="drilling_code_${crewNum}" id="drilling_code_${crewNum}" class="select-single mobile-drillingcode-select ">
									</select>
									<label for="drilling_code_${crewNum}"><span class='translate' data-i18n="9318" notes="Drilling Code"></span></label>
								</div>

								<div class="md-form pt-1 position-relative my-4">
									<input type="number" name="redrill_${crewNum}" id="redrill_${crewNum}" class="form-control " min="0.00" step="0.01">
									<label for="redrill_${crewNum}" style="width:100%"><span class='translate' data-i18n="9319" notes="Redrill"></span></label>
								</div>

								<div class="pt-1 position-relative my-4">
									<select name="status_code_${crewNum}" id="status_code_${crewNum}" class="select-single mobile-drillingStatuscode-select ">
									</select>
									<label for="status_code_${crewNum}"><span class='translate' data-i18n="9320" notes="Status Code"></span></label>
								</div>

								<div class="pt-1 position-relative my-4">
									<select name="log_code_${crewNum}" id="log_code_${crewNum}" class="select-single mobile-drillinglogcode-select">
									</select>
									<label for="log_code_${crewNum}"><span class='translate' data-i18n="9321" notes="Log Code"></span></label>
								</div>
							</div>
						</div>
					</div>
				</div>
			</li>
		`	
		$("#crews").append(crewsModal)
		crews=crewNum
		if((crewNum>1 && !mode) || mode=='afterDelete'){
			initializeSelect2Dynamic(`time_and_delays_code_${crewNum}`)
			initializeSelect2Dynamic(`bit_size_${crewNum}`)
			initializeSelect2Dynamic(`drilling_code_${crewNum}`)
			initializeSelect2Dynamic(`status_code_${crewNum}`)  
			initializeSelect2Dynamic(`log_code_${crewNum}`)  
			formHeader.populateDrillingTimeDelaysCodeSelect(`time_and_delays_code_${crewNum}`)
			formHeader.populateDrillingBitSizeSelect(`bit_size_${crewNum}`)
			formHeader.populateDrillingCodeSelect(`drilling_code_${crewNum}`)
			formHeader.populateStatusCodeSelect(`status_code_${crewNum}`)	
			formHeader.populateDrillingLogCodeSelect(`log_code_${crewNum}`)	
			initializePickadate()
			try {$('.translate').localize()} catch {}
		}	

		if (document.getElementById('unit_imperial').checked || document.getElementById('unit_metric').checked) {
			if (document.getElementById('unit_imperial').checked) {
				selectedUnit = document.getElementById('unit_imperial')
			}
			else{
				selectedUnit = document.getElementById('unit_metric')
			}
			populateUnit(selectedUnit)		
		}

		refreshTotal()

		// prevent input illegal letter in number input
		$(`input[id$='_${crewNum}']`).on("keydown",( (e) => {
			if(e.currentTarget.type=="number" && invalidChars.includes(e.key)){
				e.preventDefault()
			}
		}))

		$(`select[id$='_${crewNum}'],input[id$='_${crewNum}']`).on("keyup change",debounce( (e) => {
			calculate(e)
		},2000));

		function calculate(e) {		
			let ele=e.currentTarget
			if(ele.id.startsWith("start_time_") || ele.id.startsWith("end_time_") || ele.id.startsWith("time_and_delays_code_")){
				let startTime=$(`#start_time_${crewNum}`).val()
				let endTime=$(`#end_time_${crewNum}`).val()
				if(startTime && endTime){	
					calculateHours()
				}
			}

			if(ele.id.startsWith("drilling_length_") || ele.id.startsWith("drilling_code_")){
				calculateMeters()
			}
		
			if(ele.id.startsWith("status_code_") || ele.id.startsWith("redrill_")){
				calculateRedrill()	
			}
		}
	}

	function calculateShiftLength(timeIn,timeOut){
		timeInMinutes=convertMilitaryTime(timeIn)
		timeOutMinutes=convertMilitaryTime(timeOut)
		timeDifference=timeOutMinutes-timeInMinutes
		if(timeDifference<0){
			timeDifference=timeDifference+24*60
		}		
		return timeDifference
	}

	function convertMilitaryTime(timeStamp){
		amPM=timeStamp.substr(length-3)
		timeHour=Number(timeStamp.substr(0,2))
		timeMin=Number(timeStamp.substr(3,2))
		if(amPM=="AM" && timeHour==12){
			timeHour=0
		}
		if(amPM=="PM" && timeHour!=12){
			timeHour=timeHour+12
		}
		totalMinuites = timeHour * 60 + timeMin
		return totalMinuites
	}

	function calculateHours(){
		totalShiftHours=0
		totalHoursDrilled=0
		for (let i = 1; i <=crews; i++) {
			let startTime=$(`#start_time_${i}`).val()
			let endTime=$(`#end_time_${i}`).val()
			let timeDelayCode=$(`#time_and_delays_code_${i}`).val()
			if(startTime && endTime){					
				let shiftLength=calculateShiftLength(startTime,endTime)
				if(hoursCalculationFactors.includes(parseInt(timeDelayCode))){
					totalHoursDrilled +=shiftLength
				}
				totalShiftHours +=shiftLength
			}
		}
		refreshTotal()
	}

	function calculateMeters(){
		totalProductionMetersDrilled=0
		totalCableMetersDrilled=0
		for (let i = 1; i <=crews; i++) {
			let drillingLength=$(`#drilling_length_${i}`).val()
			let drillingCode=$(`#drilling_code_${i}`).val()
			if(productionMetersCalculationFactor.includes(parseInt(drillingCode))){
				totalProductionMetersDrilled +=parseFloat(drillingLength)
			}
			else if(cableMetersCalculationFactor.includes(parseInt(drillingCode))){
				totalCableMetersDrilled +=isNaN(parseFloat(drillingLength))?0:parseFloat(drillingLength)
			}
		}
		refreshTotal()
	}

	function calculateRedrill(){
		totalRedrillMetersDrilled=0
		for (let i = 1; i <=crews; i++) {
			let statusCode=$(`#status_code_${i}`).val()
			let reDrill=$(`#redrill_${i}`).val()
			if(parseInt(statusCode)===parseInt(status_completed_rld_id)){   //status code complete
				totalRedrillMetersDrilled +=isNaN(parseFloat(reDrill))?0:parseFloat(reDrill)
			}
		}
		refreshTotal()
	}

	function debounce(callback, wait) {
	let timeout;
	return (...args) => {
		clearTimeout(timeout);
		timeout = setTimeout(function () { callback.apply(this, args); }, wait);
	};
	}

	populateUnit = (selectedUnit) => {
		unit=selectedUnit.value==i18next.t("9301")?'ft':selectedUnit.value==i18next.t("2765")?'m':unit
		let newLables = document.querySelectorAll(`[for^='planned_length_'],[for^='drilling_length_'],[for^='redrill_']`)
		for (newLable of newLables) {
			innerText1=newLable.innerText.split("(")
			newLable.innerHTML = innerText1[0]+' '+'('+unit+')'
		}
		refreshTotal()
	}

	function convertMinToHours(minutes){
		hoursLengh=Math.floor(minutes/60)
		minsLengh=minutes%60
		timeLength=hoursLengh + " hr "+ minsLengh+" min"
		return timeLength
	}

	function refreshTotal(){
		let capitalUnit = unit.toUpperCase()
		let totalShiftLength = convertMinToHours(totalShiftHours)
		let totalDrilledLength = convertMinToHours(totalHoursDrilled)
		roundTotalProductionMetersDrilled=isNaN(totalProductionMetersDrilled)?Number(0).toFixed(2):totalProductionMetersDrilled.toFixed(2)
		roundTotalCableMetersDrilled=isNaN(totalCableMetersDrilled)?Number(0).toFixed(2):totalCableMetersDrilled.toFixed(2)
		roundTotalRedrillMetersDrilled=isNaN(totalRedrillMetersDrilled)?Number(0).toFixed(2):totalRedrillMetersDrilled.toFixed(2)
		$("#total_shift_hours").text(`${totalShiftLength}`)
		$("#total_hours_drilled").text(`${totalDrilledLength}`)
		$("#total_production_meters_drilled").text(`${roundTotalProductionMetersDrilled} ${capitalUnit}`)
		$("#total_cable_meters_drilled").text(`${roundTotalCableMetersDrilled} ${capitalUnit}`)
		$("#total_redrill_meters_drilled").text(`${roundTotalRedrillMetersDrilled} ${capitalUnit}`)
	}

	let totalUsedMaterial=parseInt(document.getElementById('totalUsed').value)

	// add a used material
	document.getElementById('addUsedMaterial').addEventListener('click',(e)=>{
		usedmaterialcount = parseInt(document.getElementById('numUsed').value)
		if(usedmaterialcount < totalUsedMaterial) {
			usedmaterialcount++
			addUsedMaterial(usedmaterialcount)
			document.getElementById('numUsed').value = usedmaterialcount
			if(usedmaterialcount === totalUsedMaterial)	
			document.getElementById('addUsedMaterial').classList.add('d-none')
		} 
	})

	function addUsedMaterial(usedNum,mode){
		const usedModal = 
		`<li class="delete_usedMaterial ui-state-default card mb-4 usedsection" id="usedMaterialIndex_${usedNum}">
			<div class="card">
				<!-- Card header -->
				<div class="card-header px-3" role="tab" id="material_heading_${usedNum}">
					<!-- Sort Number, Three Icons -->
					<div class="w-100 px-3">
						<span class='text-muted' id="material_order_${usedNum}">${usedNum}</span>
						<span class="float-right row align-items-center">
							<div class="dropdown">
								<i class="far fa-trash-alt mr-4 text-primary" data-i18n='3805' note="Delete Event Category" title="" style="cursor: pointer;" data-toggle="dropdown"></i>
								<div class="dropdown-menu dropdown-menu-right dropdown-primary">
									<Strong><span class='translate' data-i18n='2314' notes='Delete this item?'></span></Strong>
									<a class="dropdown-item"><i><span class='translate' data-i18n='1380' notes='No'></span></i></a>
									<a class="dropdown-item" onclick="deleteUsedMaterial(this)"><i><span class='translate' data-i18n='1379' notes='Yes'></span></i></a>
								</div>
							</div>
						</span>
					</div>
					<!-- Event Header -->
					<br />
					<div class="pt-1 position-relative my-4">
						<select name="material_used_${usedNum}" id="material_used_${usedNum}" class="select-single mobile-drillingmaterialused-select"  required>
						</select>
						<label for="material_used_${usedNum}"><span class='translate' data-i18n="642" notes="Material Used"></span></label>
					</div>

					<div class="md-form">
						<input type="text" name="amount_used_${usedNum}" id="amount_used_${usedNum}" class="form-control" length="200" maxlength="200" required>
						<label for="amount_used_${usedNum}" style="width:100%"><span class='translate' data-i18n="9342" notes="Amount Used"></span></label>
					</div>
				</div>
			</div>		
		</li>`

		$("#used").append(usedModal)
		if((usedNum>1 && !mode) || mode=='afterDelete'){
			initializeSelect2Dynamic(`material_used_${usedNum}`)			
			formHeader.populateDrillingMaterialUsedSelect(`material_used_${usedNum}`)	
			try {$('.translate').localize()} catch {}
		}
	}

	function dragAndSort(){
		$( "#crews" ).sortable({
			stop: function( event, ui ) {
				reorder("timeEntry")
			}
		});
		$( "#crews" ).sortable({ handle: '.handle'})
		$( "#crews" ).draggable({ handle: '.handle'})
		$( "#crews" ).disableSelection()
	}



	function reorder(section){
		let fields=null, number=null,deletePointName=null,indexNumber=null
		if(section=="timeEntry"){
			headerFields=`[id^='timeEntryIndex_'],[id^='heading_'],[id^='entry_order_']`
			specificFields=`[id^='start_time_'],[id^='time_and_delays_code_'],[id^='end_time_'],[id^='collapse_'],[id^='ring_no_'],
				[id^='hole_no_'],[id^='planned_length_'],[id^='angles_dip_'],[id^='angles_dump_'],
				[id^='from_'],[id^='to_'],[id^='bit_size_'],[id^='drilling_length_'],[id^='drilling_code_'],[id^='redrill_'],[id^='status_code_'],[id^='log_code_']`
			number='numCrews'
			deletePointName='delete_entry'
			indexNumber="timeEntryIndex_"
		}
		else if(section=="usedMaterial"){
			headerFields=`[id^='usedMaterialIndex_'],[id^='material_heading_'],[id^='material_order_']`
			specificFields=`[id^='material_used_'],[id^='amount_used_']`
			number='numUsed'
			deletePointName='delete_usedMaterial'
			indexNumber="usedMaterialIndex_"
		}

		for(i = 0; i < parseInt(document.getElementById(number).value); i++){
			document.getElementsByClassName(deletePointName)[i].id = indexNumber + (i+1)
			allFields=[headerFields,specificFields]
			for(fields in allFields){
				let newEntries = document.getElementsByClassName(deletePointName)[i].querySelectorAll(allFields[fields])
				for (newEntry of newEntries) {
					let id=newEntry.id.split('_')
					id.pop()
					newId=id.join('_')+'_'+(i+1)
					newEntry.id=newId
					newEntry.name=newId
					if(fields==1 && newEntry.tagName === 'SELECT'){
						newEntry.setAttribute("data-select2-id", newId)
						let elementValue=null
						let arrayDom = Array.from(newEntry.nextElementSibling.getElementsByTagName("span"))						
						arrayDom.forEach(element => {							
							if(element.firstElementChild){
								if (element.firstElementChild.hasAttribute("aria-labelledby")){
									elementValue=element.firstElementChild.getAttribute("aria-labelledby")
									let elementValueStrings=elementValue.split("-")
									elementValueStrings[1]=newId
									elementValue=elementValueStrings.join('-')
									element.firstElementChild.setAttribute("aria-labelledby", elementValue);
								}
							}	
							if (element.id){
								element.id=elementValue
							}
						})
					}				
					if(fields==1 && newEntry.parentElement.getElementsByTagName('label')){
						newEntry.parentElement.getElementsByTagName('label')[0].setAttribute('for',newId)				
					}
				}
			}
			document.getElementsByClassName(deletePointName)[i].firstElementChild.querySelector('.text-muted').innerHTML=i+1
			if(section=="timeEntry"){
				let collapseElements = document.getElementsByClassName(deletePointName)[i].querySelectorAll('[data-target^="#collapse"]')
				for (k of collapseElements) {
					k.setAttribute("data-target", '#collapse_'+(i+1))
				}
			}	
		}
	}

	//Function to delete an step category
	function deleteEntry(ele) {
		id=ele.parentNode.parentNode.parentNode.parentNode.firstChild.nextElementSibling.id
		crewNum=id.split("_").pop()
		ele.closest(".delete_entry").remove()
		// remove eventlister of crewNum
		$(`input[id$='_${crewNum}']`).off("keyup change")
		crews=document.getElementById('numCrews').value
		crews--
		document.getElementById('numCrews').value = crews
		reorder("timeEntry")
		recalculateAndRefresh()
		if (crews === 0){
			addCrew(1,"afterDelete")
			document.getElementById('numCrews').value = crews
			return
		}
		document.getElementById('addCrew').classList.remove('d-none')	
	}

	//Function to delete an step category
	function deleteUsedMaterial(ele) {
		// search the material_order_id
		id=ele.parentNode.parentNode.parentNode.parentNode.firstChild.nextElementSibling.id
		materialNum=id.split("_").pop()
		ele.closest(".delete_usedMaterial").remove()
		materials=document.getElementById('numUsed').value
		materials--
		document.getElementById('numUsed').value = materials
		reorder("usedMaterial")
		if (materials === 0){
			addUsedMaterial(1,"afterDelete")
			materials++
			document.getElementById('numUsed').value = materials
			return
		}
		document.getElementById('addUsedMaterial').classList.remove('d-none')
	}

	function getCalculationItems() {
		openCacheData().then((rdata) => {
			let drillingCalculationItems = remoteData[38].DrillingCalculation
			for(drillingCalculationItem of drillingCalculationItems){
				if(drillingCalculationItem.ref_dcv_hours_drilled==1){
					hoursCalculationFactors.push(parseInt(drillingCalculationItem.ref_dcv_rld_id))
				}
				if(drillingCalculationItem.ref_dcv_production_meters_drilled==1){
					productionMetersCalculationFactor.push(parseInt(drillingCalculationItem.ref_dcv_rld_id))
				}
				if(drillingCalculationItem.ref_dcv_cable_meters_drilled==1){
					cableMetersCalculationFactor.push(parseInt(drillingCalculationItem.ref_dcv_rld_id))
				}
			}

		})
		selectCachePromise().then((selectListData)=> {
			status_completed_rld_id = selectListData.ref_drilling_status_code.find((list) => list.rld_code === 'C').rld_id
		})
	}

	function recalculateAndRefresh(){
		calculateHours()
		calculateMeters()
		calculateRedrill()	
		refreshTotal()
	}

	function draftPostProcess(){
		recalculateAndRefresh()
	}

	// Populate the Form from a Draft by showing the sections activated in FormHandler
	function populateMaterialUsed(numUsed,totalUsed) {
		$(`.usedsection`).remove()
		document.getElementById('addUsedMaterial').classList.remove('d-none')
		if(numUsed >= totalUsed)
			document.getElementById('addUsedMaterial').classList.add('d-none')
		for (a = 1; a <= numUsed; a++) {
			addUsedMaterial(a,"loadDraft")
		}
	}

    function clearEquipmentFields(id) {
        if(id === 'job_number' || id === 'site'){
           
            all_rest = []
            let optionData = `<select name="equipment_id" id="equipment_id" class="select-multiple mobile-equipment-select">`
            all_rest.forEach((data)=>{
                optionData += `<option value="${data.id}">${data.text}</option>`
            })
            optionData += `</select>`
            $(`#equipment_id`).html(optionData)
			if(main_current_draft_object){
            	main_current_draft_object.equipment_id = null
			}
            initializeEquipmentSelect2(`equipment_id`)
            $(`#equipment_id`).parent().find('label').html(i18next.t("9559"))
			$(`#equipment_id`).val("").trigger("change").parent().find('label').removeClass(['filled',"active"])
        }
    }

</script>

<script src="/js/groupEquipment.js"></script>
<script src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
