<?php	
  $strPageTitle = 'Workplace Inspection';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary"><span class='translate' data-i18n='1028' notes='Workplace Inspection'></span></h6>
          <div class="pt-1 position-relative">
            <select name="draft" id="draft" class="select-single md-form" onChange="getFormData(this)">
            </select>
            <label for="draft"><span class='translate' data-i18n='1474' notes='Form Drafts'></span></label>
          </div>

          <form name="formWorkplaceInspection" id="formWorkplaceInspection" class="needs-validation" method="POST" action="#" novalidate>
          
						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1665' notes='Inspection'></span></h6>

          <div class="pt-1 my-4 position-relative">
		        <select name="inspection_type" id="inspection_type" class="select-single mobile-inspectiontype-select" searchable="Search here..">
		        </select>
            <label for="inspection_type"><span class='translate' data-i18n='572' notes='Inspection Type'></span></label>
	        </div>

          <div class="pt-1 my-4 position-relative">
		        <select name="workers_present" id="workers_present" class="select-multiple mobile-employee-select" multiple>
		        </select>
            <label for="workers_present"><span class='translate' data-i18n='958' notes='Workers Present'></span></label>
	       </div>

           <div class="form-group photoImage" id="workplace_pictures"> 
				<label class="d-block"><span class='translate' data-i18n='969' notes='Workplace Pictures'></span></label>
				<canvas id="canvas" style='display:none;'></canvas>
				<div class="btn-group d-flex" role="group">
					<div class="btn btn-block btn-outline-secondary file-field px-1">
						<i class="fa fa-upload"></i> <span class='translate' data-i18n='2340' notes='ADD IMAGES'></span>
						<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
					</div>
				</div>
				<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n='1389' notes='Please take scene pictures from all perspectives'></span></small>
				<div class="row photoGallery" id="galleryid"></div>
			</div>

			<h6 class="text-secondary pt-4"><span class='translate' data-i18n='81' notes='Comments'></span></h6>
			<div class="md-form">
				<textarea name="comments" id="comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
				<label for="comments"><span class='translate' data-i18n="3915" notes="Comment"></span></label>
			</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" note="WORKPLACE INSPECTION" class = "trans_input" value="1028" tag="1028" />
						<input type="hidden" name="formtype" id="formtype" value="SUP" />
						<input type="hidden" name="formid" id="formid" value="131091"/>
						<input type="hidden" name="version" id="version" value="72" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}	
	}
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>