<?php	
  $strPageTitle = 'Employee Discipline';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
					<h6 class="text-secondary"><span class='translate' data-i18n="998" notes="Employee Discipline"></span></h6>

					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
						</select>
						<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
					</div>

					<form name="employeeDiscipline" id="employeeDiscipline" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>

						<input type='hidden' name='disc_legend' id='disc_legend' class='trans_input_multi' value='1477,1478,3093,1479,3094,1480' notes='Type A – Discharge 
These infractions are of an ultimate severity and may require the employee to be removed from the work site and escorted off the property. The discipline for this type of offence will be discharge (termination of employment)

Type B
These fractions are of a major severity. The usual discipline for a first time offence of this nature is a one-day suspension without pay.

Type C
These are severe infractions. The usual discipline for a first time offence of this nature is a written warning.'>
						                     	
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1475" notes="Discipline"></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="employee_name" id="employee_name" class="select-single mobile-employee-select-id-single" required></select>
							<label for="employee_name"><span class='translate' data-i18n="190" notes="Employee"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1476" notes="Discipline Violation"></span></h6>
						<div class="md-form">
							<textarea name="discipline_violation" id="discipline_violation" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="discipline_violation"><span class='translate' data-i18n="1476" notes="Discipline Violation"></span></label>
						</div>

						<div>					
							<span class='translate' data-i18n="1477" notes="Type A – Discharge"></span>
							<small class="d-block mb-3"><span class='translate' data-i18n="1478" notes="These infractions are of an ultimate severity and may require the employee 
							to be removed from the work site and escorted off the property. The discipline for this type of offence 
							will be discharge (termination of employment)."></span></small>

							<span class='translate' data-i18n="3093" notes="Type B"></span>
							<small class="d-block mb-3"><span class='translate' data-i18n="1479" notes="These fractions are of a major severity. The usual discipline for a
							first time offence of this nature is a one-day suspension without pay."></span></small>

							<span class='translate' data-i18n="3094" notes="Type C"></span>
							<small class="d-block mb-3"><span class='translate' data-i18n="1480" notes="These are severe infractions. The usual discipline for a first time
							offence of this nature is a written warning."></span></small>
						</div> 					

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="474" notes="Event Type"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="event_type_a" name="event_type" value="A" notes="A" required>
								<label class="form-check-label mr-2" for="event_type_a">A</label>

								<input type="radio" class="form-check-input trans_input" id="event_type_b" name="event_type" value="B" notes="B">
								<label class="form-check-label mr-2" for="event_type_b">B</label>

								<input type="radio" class="form-check-input trans_input" id="event_type_c" name="event_type" value="C" notes="C">
								<label class="form-check-label mr-2" for="event_type_c">C</label>

							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="861" notes="This is to confirm you have been counselled for:"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="counselled_written_warning" name="counselled" value="1481" notes="Written Warning" required>
								<label class="form-check-label mr-2 d-block h-auto" for="counselled_written_warning"><span class='translate' data-i18n="1481" notes="Written Warning"></span></label>
							</div>
							<div class="form-check custom-radio pl-0 ">
								<input type="radio" class="form-check-input trans_input" id="counselled_written_warning_safety_bonus_loss" name="counselled" value="1482" notes="Written Warning with Loss of Safety Bonus">
								<label class="form-check-label mr-2 d-block h-auto" for="counselled_written_warning_safety_bonus_loss"><span class='translate' data-i18n="1482" notes="Written Warning with Loss of Safety Bonus"></span></label>
							</div>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="counselled_time_off_wage_loss" name="counselled" value="1483" notes="Time Off and Loss of Wages">
								<label class="form-check-label mr-2 d-block h-auto" for="counselled_time_off_wage_loss"><span class='translate' data-i18n="1483" notes="Time Off and Loss of Wages"></span></label>
							</div>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="counselled_time_off_wage_loss_safety_bonus" name="counselled" value="1484" notes="Time Off and Loss of Wages and Safety Bonus">
								<label class="form-check-label mr-2 d-block h-auto" for="counselled_time_off_wage_loss_safety_bonus"><span class='translate' data-i18n="1484" notes="Time Off and Loss of Wages and Safety Bonus"></span></label>
							</div>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="counselled_discharge" name="counselled" value="1485" notes="Discharge">
								<label class="form-check-label mr-2 d-block h-auto" for="counselled_discharge"><span class='translate' data-i18n="1485" notes="Discharge"></span></label>
							</div>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="counselled_discharge_loss_safety_bonus" name="counselled" value="1486" notes="Discharge with Loss of Safety Bonus">
								<label class="form-check-label mr-2 d-block h-auto" for="counselled_discharge_loss_safety_bonus"><span class='translate' data-i18n="1486" notes="Discharge with Loss of Safety Bonus"></span></label>
							</div>
						</div>

						<div class="md-form">
							<textarea name="event" id="event" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="event"><span class='translate' data-i18n="165" notes="Discipline Event Description"></span></label>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="217" notes="Employee Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='signature_employee'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_employee_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_employee" id="signature_employee" class='modalSignature' value='' required>
							<input type="hidden" name="vector_employee" id='vector_employee' value=''>
							<input type="hidden" name="signature_employee_comments" id='signature_employee_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_employee_img_time" id="signature_employee_img_time" notes='signature_employee_img_time' readonly/></small>
						</div>

						<canvas id="canvas" style='display:none;'></canvas>
						
						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="850" notes="Supervisor Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='signature_superintendent'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_superintendent_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_superintendent" id="signature_superintendent" class='modalSignature' value=''>
							<input type="hidden" name="vector_superintendent" id='vector_superintendent'  value=''>
							<input type="hidden" name="signature_superintendent_comments" id='signature_superintendent_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_superintendent_img_time" id="signature_superintendent_img_time" notes='signature_superintendent_img_time' readonly/></small>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="1487" notes="Superintendent or Manager Signature"></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='signature_manager'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_manager_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_manager" id="signature_manager" class='modalSignature' value='' >
							<input type="hidden" name="vector_manager" id='vector_manager' value=''>
							<input type="hidden" name="signature_manager_comments" id='signature_manager_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_manager_img_time" id="signature_manager_img_time" notes='signature_manager_img_time' readonly/></small>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag="998" class = "trans_input" value="998"/>
						<input type="hidden" name="formtype" id="formtype" value="HR" />
						<input type="hidden" name="formid" id="formid" value="248310" />
						<input type="hidden" name="version" id="version" value="29" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="employee_name" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
						
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript">

	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
			
			return true;
		}	
	}
</script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
<script type="text/javascript" src="/js/formHandler2.js"></script>
