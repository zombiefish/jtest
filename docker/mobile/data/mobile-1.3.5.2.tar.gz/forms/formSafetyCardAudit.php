<?php	
  $strPageTitle = 'Safety Card Audit';
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary"><span class='translate' data-i18n="1014" notes="Safety Card Audit"></span></h6>
          <div class="pt-1 position-relative my-4">
            <select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
            </select>
            <label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
          </div>

          <form name="TemplateForm" id="TemplateForm" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1611" notes="Safety Card"></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="employee" id="employee" tag="205" class="select-single mobile-employee-select-single" required>
							</select>
							<label for="employee"><span class='translate' data-i18n="205" notes="Employee of card audited"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="other_worker" id="other_worker" class="form-control otherclass" length="200" maxlength="200">
							<label for="other_worker"><span class='translate' data-i18n="1612" notes="Other Worker (If not an Employee)"></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="auditor" id="auditor" class="select-single mobile-supervisors-select" required>
							</select>
							<label for="auditor"><span class='translate' data-i18n="62" notes="Auditor"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="1613" notes="All portions of card filled out?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="portions_card_fille_out_yes" name="portions_card_fille_out" value="1" required>
								<label class="form-check-label mr-2" for="portions_card_fille_out_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="portions_card_fille_out_no" name="portions_card_fille_out" value="0">
								<label class="form-check-label mr-2" for="portions_card_fille_out_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="portions_card_fille_out_na" name="portions_card_fille_out" value="-1">
								<label class="form-check-label mr-2" for="portions_card_fille_out_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="11" notes="5-Point Safety System properly filled out and followed up by Supervisor?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="five_point_safety_system_yes" name="five_point_safety_system" value="1" required>
								<label class="form-check-label mr-2" for="five_point_safety_system_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="five_point_safety_system_no" name="five_point_safety_system" value="0">
								<label class="form-check-label mr-2" for="five_point_safety_system_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="five_point_safety_system_na" name="five_point_safety_system" value="-1">
								<label class="form-check-label mr-2" for="five_point_safety_system_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="571" notes="Information clear and legible?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="information_clear_legible_yes" name="information_clear_legible" value="1" required>
								<label class="form-check-label mr-2" for="information_clear_legible_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="information_clear_legible_no" name="information_clear_legible" value="0">
								<label class="form-check-label mr-2" for="information_clear_legible_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="information_clear_legible_na" name="information_clear_legible" value="-1">
								<label class="form-check-label mr-2" for="information_clear_legible_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="513" notes="Hazard Triangle properly completed?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="hazard_triangle_properly_completed_yes" name="hazard_triangle_properly_completed" value="1" required>
								<label class="form-check-label mr-2" for="hazard_triangle_properly_completed_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="hazard_triangle_properly_completed_no" name="hazard_triangle_properly_completed" value="0">
								<label class="form-check-label mr-2" for="hazard_triangle_properly_completed_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="hazard_triangle_properly_completed_na" name="hazard_triangle_properly_completed" value="-1">
								<label class="form-check-label mr-2" for="hazard_triangle_properly_completed_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>								
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="513" notes="Hazard Report completed?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="hazard_report_completed_yes" name="hazard_report_completed" value="1" required>
								<label class="form-check-label mr-2" for="hazard_report_completed_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="hazard_report_completed_no" name="hazard_report_completed" value="0">
								<label class="form-check-label mr-2" for="hazard_report_completed_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="hazard_report_completed_na" name="hazard_report_completed" value="-1">
								<label class="form-check-label mr-2" for="hazard_report_completed_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>								
							</div>
						</div>						

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="800" notes="Reviewed by Supervisor?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="reviewed_by_supervisor_yes" name="reviewed_by_supervisor" value="1" required>
								<label class="form-check-label mr-2" for="reviewed_by_supervisor_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="reviewed_by_supervisor_no" name="reviewed_by_supervisor" value="0">
								<label class="form-check-label mr-2" for="reviewed_by_supervisor_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="reviewed_by_supervisor_na" name="reviewed_by_supervisor" value="-1">
								<label class="form-check-label mr-2" for="reviewed_by_supervisor_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="799" notes="Reviewed at quitting time?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="reviewed_at_quitting_time_yes" name="reviewed_at_quitting_time" value="1" required>
								<label class="form-check-label mr-2" for="reviewed_at_quitting_time_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="reviewed_at_quitting_time_no" name="reviewed_at_quitting_time" value="0">
								<label class="form-check-label mr-2" for="reviewed_at_quitting_time_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="reviewed_at_quitting_time_na" name="reviewed_at_quitting_time" value="-1">
								<label class="form-check-label mr-2" for="reviewed_at_quitting_time_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="950" notes="Worker concerns communicated?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="worker_concerns_communicated_yes" name="worker_concerns_communicated" value="1" required>
								<label class="form-check-label mr-2" for="worker_concerns_communicated_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="worker_concerns_communicated_no" name="worker_concerns_communicated" value="0">
								<label class="form-check-label mr-2" for="worker_concerns_communicated_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="worker_concerns_communicated_na" name="worker_concerns_communicated" value="-1">
								<label class="form-check-label mr-2" for="worker_concerns_communicated_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="951" notes="Worker concerns followed up?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="worker_concerns_followed_up_yes" name="worker_concerns_followed_up" value="1" required>
								<label class="form-check-label mr-2" for="worker_concerns_followed_up_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="worker_concerns_followed_up_no" name="worker_concerns_followed_up" value="0">
								<label class="form-check-label mr-2" for="worker_concerns_followed_up_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="worker_concerns_followed_up_na" name="worker_concerns_followed_up" value="0">
								<label class="form-check-label mr-2" for="worker_concerns_followed_up_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="81" notes="Comments"></span></h6>

						<div class="md-form">
							<textarea name="sts_feedback" id="sts_feedback" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="sts_feedback"><span class='translate' data-i18n="1614" notes="Auditor Feedback"></span></label>
						</div>

						<div class="form-group photoImage" id="safety_pictures"> 
							<label class="d-block"><span class='translate' data-i18n="741" notes="Pictures"></span></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="Add Images"></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
			                  <small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
			                <div class="row photoGallery" id="galleryid"></div>
			            </div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1976" notes="Correction & Action Requirements"></span></h6>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="915" notes="Were any areas of improvement identified?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input radio-check" id="any_areas_of_improvement_identified_yes" name="any_areas_of_improvement_identified" value="1" required>
								<label class="form-check-label mr-2" for="any_areas_of_improvement_identified_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input radio-check" id="any_areas_of_improvement_identified_no" name="any_areas_of_improvement_identified" value="0">
								<label class="form-check-label mr-2" for="any_areas_of_improvement_identified_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>
						
						<div class='cond-form-check-area'> 
												
								<div class="mb-4">
									<label class="d-block"><span class='translate' data-i18n="3765" notes="Is a follow up required with employee?"></span></label>
									<div class="form-check custom-radio pl-0">
										<input type="radio" class="form-check-input" id="follow_up_with_the_employee_yes" name="follow_up_with_the_employee" value="1" required>
										<label class="form-check-label mr-2" for="follow_up_with_the_employee_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

										<input type="radio" class="form-check-input" id="follow_up_with_the_employee_no" name="follow_up_with_the_employee" value="0">
										<label class="form-check-label mr-2" for="follow_up_with_the_employee_no"><span class='translate' data-i18n="1380" notes="No"></span></label>  
									</div>
								</div>
							
								<div class="mb-4">
									<label class="d-block"><span class='translate' data-i18n="3766" notes="Is a follow up required with task?"></span></label>
									<div class="form-check custom-radio pl-0">
										<input type="radio" class="form-check-input" id="follow_up_with_the_task_yes" name="follow_up_with_the_task" value="1" required>
										<label class="form-check-label mr-2" for="follow_up_with_the_task_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

										<input type="radio" class="form-check-input" id="follow_up_with_the_task_no" name="follow_up_with_the_task" value="0">
										<label class="form-check-label mr-2" for="follow_up_with_the_task_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

										<input type="radio" class="form-check-input" id="follow_up_with_the_task_na" name="follow_up_with_the_task" value="-1">
										<label class="form-check-label mr-2" for="follow_up_with_the_task_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>  
									</div>
								</div>
						</div>
						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" note="SAFETY CARD AUDIT" class = "trans_input" value="1014" tag="1014" />
						<input type="hidden" name="formtype" id="formtype" value="HR" />
						<input type="hidden" name="formid" id="formid" value="236756" />
						<input type="hidden" name="version" id="version" value="18" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="employee" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
					
				</div>
			</div>
		</div>
	</div>
</main>




    <div id="sync-wrapper">
    </div>

    <div id="output">
    </div>

	<div><!--- row -->
</div> <!--- container -->

<script type="text/javascript">
	var formBody = {
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}	
	}

	function radioButtonCheck() {
		$('.radio-check').change((e) =>{
			requiredRadio(e.currentTarget.defaultValue)
		})
	};
	document.addEventListener('DOMContentLoaded', radioButtonCheck, false);

</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>