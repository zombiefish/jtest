<?php	
  $strPageTitle = 'Lock out Tag out';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
						<h6 class="text-secondary"><span class='translate' data-i18n="9295" notes="Lockout / Tagout"></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="draft" id="draft" class="select-single lock" onChange="getFormData(this)">
							</select>
							<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
						</div>

						<form name="LOTO" id="TemplateForm" class="needs-validation" method="POST" action="#" novalidate>
						<canvas id="canvas" style='display:none;'></canvas>
						<?php include 'includes/CommonFormHeader.php' ?>

						<div class="pt-1 position-relative my-4">

							<select name="completed_by" id="completed_by" class="select-multiple mobile-employee-select-id lock" multiple required>
							</select>
							<label for="completed_by"><span class='translate' data-i18n='9271' notes='Procedure completed by'></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="type_of_intervention" id="type_of_intervention" class="select-single select-default form-control mobile-intervention-type-select lock" required>
							</select>
							<label for="type_of_intervention"><span class='translate' data-i18n="9272" notes="Type of intervention"></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="equipment_type" id="equipment_type" class="select-single select-default form-control mobile-loto-equipment-select lock" required>
							</select>
							<label for="equipment_type"><span class='translate' data-i18n="1239" notes="Equipment Type"></span></label>
						</div>
						
						<div class="pt-1 position-relative my-4">
							<select name="equipment_id" id="equipment_id" class="select-single select-default form-control mobile-loto-equipment-id-select lock" required>
							</select>
							<label for="equipment_id"><span class='translate' data-i18n="1238" notes="Equipment ID"></span></label>
						</div>

						<button type="button"  name="select_equipment_procedure" id="select_equipment_procedure" class="btn btn-primary btn-block my-4 waves-effect waves-light" onclick="getSingleLotoProcedure()"><span class='translate' data-i18n="9290" notes="SELECT EQUIPMENT PROCEDURE"></span></button>

						<div id="equipmentProcedure"></div>
						<div class="md-form d-none">
							<textarea name="comments" id="comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="comments"><span class='translate' data-i18n='81' notes='Comments'></span></label>
						</div>
				
						<div class="form-check pl-0 mb-4 d-none">
							<input type="checkbox" class="form-check-input ml-0" id="needs_revision" name="needs_revision" value="0" onchange="getCheckboxStatus(this)">
							<label class="form-check-label" for="needs_revision"><span class='translate' data-i18n='9287' notes='Procedure Needs Revision'></label>  
						</div>
						<button type="button"  name="finalLock" id="finalLock" class="btn btn-primary btn-block my-4 waves-effect waves-light d-none"><i class="fa fa-check" style="font-size:24px"></i>   <span class='translate' data-i18n="9288" notes="All locks have been removed and are accounted for"></span><p id="all_unlock"></p></button>
                        <div id="loto_status_select"  class="pt-1 position-relative my-4 d-none">
							<select name="loto_status" id="loto_status" class="select-single form-control mobile-loto-status-select" required>
							</select>
							<label for="loto-status"><span class='translate' data-i18n="9570" notes="Loto status"></span></label>
						</div>
						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" note="Lockout / Tagout" class = "trans_input" value="9295"  tag="9295" />
						<input type="hidden" name="formtype" id="formtype" value="LOTO" />
						<input type="hidden" name="formid" id="formid" value="372468" />
						<input type="hidden" name="version" id="version" value="1" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace|completed_by|type_of_intervention" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
						<input type="hidden" name="all_unlock_time" id="all_unlock_time" value="" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>


<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
			return true;
		}	
	}

	let currentEquipmentProcedure=null;currentEquipmentPic=null; totalSteps=null;currentLockState=null; currentLockStep=null; 
		timeStamp=null; timeElement=null; loadDraft=null;
	let lotoEquipmentProcedures = []
	let lotoEquipmentProceduresByTypeList = []
	let lotoEquipmentlist = []
	let energySourceList = []
	let lockoutDeviceList = []
	let sourceLocationList = []	
	let specialPPEList = []	
	let accessoriesList = []	
	let validationElements = []	
	let unlockedSteps = []
	let lotoObj=null
	
	function newLotoObj(){
		return (
			lotoObj={
				"lsu_rld_site_id": null,
				"lsu_rld_job_id": null,
				"lsu_rld_level_id": null,
                "lsu_rld_lock_status_id":null,
				"lsu_workplace": null,
				"lsu_per_supervisor": null,
				"lsu_rld_type_of_intervention": null,
				"lsu_lte_id": null,
				"lsu_lth_equipment_number": null,
				"lsu_all_unlock_time": null,
				"completed_by": [],
				"lsu_comments": null,
				"lsu_document_version_number": null,
				"lsu_is_revision_needed": false,
				"lth_id": null,
				"step": [],
				"loto_hazard_actions": [],
				"loto_general_actions": [],
				"loto_positive_ids": [],
				"distribution": []
			}
		)
	}

	function newStep() {
		return {
            "lss_lts_id": null,
            "lss_lock_time": null,
            "lss_unlock_time": null,
            "lss_notes": null,
            "lss_lock_signature": null,
            "lss_unlock_signature": null
		}
	}




	document.getElementById("equipment_type").onchange = (event) => {
		$("#select_equipment_procedure").attr("disabled", false)
		$("#equipmentProcedure").empty()
		$("#steps").empty()

		let lte_id=$("#equipment_type").val()
		if(lotoEquipmentProcedures.length<1){	
			lotoEquipmentProcedures=lotoProceduresAttachment
			lotoEquipmentProcedures = groupBy(lotoEquipmentProcedures, "lth_lte_id")
		}	
		lotoEquipmentProceduresByTypeList=lotoEquipmentProcedures[lte_id]
	
		equipmentIdSelect = document.getElementsByClassName('mobile-loto-equipment-id-select')
		let optionData = `<option></option>`
		for(let a=0; a <equipmentIdSelect.length; a++) {				
			if(lotoEquipmentProceduresByTypeList){
				lotoEquipmentProceduresByTypeList.forEach((data)=>{
					if(data.steps){
						if(data.steps.length>0){
							optionData += `<option  value="${data.lth_equipment_number}">${data.lth_equipment_number}</option>`
						}	
					}			
				})
				$(equipmentIdSelect[a]).empty().append(optionData)
				$(equipmentIdSelect[a]).parent().find('label').removeClass('filled')
			}
			else{
				$(equipmentIdSelect[a]).empty()
				$(equipmentIdSelect[a]).parent().find('label').removeClass('filled')
			}
		}	
		let findEquip=lotoEquipmentlist.find(equipment=>parseInt(equipment.lte_id)===parseInt(lte_id))
		if(findEquip){
			currentEquipmentPic=findEquip.lta_filename
		}	
	};

	document.getElementById("equipment_id").onchange = (event) => {
		$("#select_equipment_procedure").attr("disabled", false)
		$("#equipmentProcedure").empty()
		$("#steps").empty()
	};

	function getSingleLotoProcedure(mode) {
		if(!mode && !($("#equipment_type").val() && $("#equipment_id").val())){
			failedValidate("procedure")
			return
		}
        $("#loto_status_select").removeClass('d-none')
        $('#loto_status_select').addClass('required')
		newLotoObj()
		let lth_equipment_number=$("#equipment_id").val()
		currentEquipmentProcedure=lotoEquipmentProceduresByTypeList.find(procedure => procedure.lth_equipment_number === lth_equipment_number)
		lotoObj["lth_id"]=currentEquipmentProcedure["lth_id"]
		if(energySourceList.length<1){
			energySourceList = selectListData.ref_energy_source
		}
		if(lockoutDeviceList.length<1){
			lockoutDeviceList = selectListData.ref_lockout_devices
		}
		if(sourceLocationList.length<1){
			sourceLocationList = selectListData.ref_source_and_location
		}
		if(specialPPEList.length<1){
			specialPPEList = selectListData.ref_personal_protective_equipment
		}
		if(accessoriesList.length<1){
			accessoriesList = selectListData.ref_accessories
		}
		addEquipmentProcedure(currentEquipmentProcedure)
		$("#select_equipment_procedure").attr("disabled", true)
	}

function getEmployeeName(id){
	let employee=userEmployeeIncludingDisabledSelectData.find(employee=>employee.per_id==id)
	employeeName=null
	if(employee){
		employeeName=employee.per_full_name
	}
	return employeeName
}

function replaceArrayWithSemicolumn(array){
	var result = array.map(function (item) {
	return item}).join("; ")
	return result
}

function addEquipmentProcedure(currentEquipmentProcedure,numLocation,mode){	
	$("#comments").parent().removeClass('d-none')	
	$("#needs_revision").parent().removeClass('d-none')		
	let preparedBy=getEmployeeName(currentEquipmentProcedure.lth_created_by)
	let validatedBy=[]
	const zeroPad = (num, places) => String(num).padStart(places, '0')
	lotoObj.lsu_document_version_number=zeroPad(currentEquipmentProcedure.lth_document_number, 6)+"."+zeroPad(currentEquipmentProcedure.lth_version, 3)
	if(currentEquipmentProcedure.lth_validated_by){
		for(i of currentEquipmentProcedure.lth_validated_by){
			validatedBy.push(getEmployeeName(i))
		}
	}
	let approvedBy=[]
	if(currentEquipmentProcedure.lth_approved_by){
		for(j of currentEquipmentProcedure.lth_approved_by){
			approvedBy.push(getEmployeeName(j))
		}
	}
	validatedBy=replaceArrayWithSemicolumn(validatedBy)
	approvedBy=replaceArrayWithSemicolumn(approvedBy)

	let equipmentProcedureModal = 
	`<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1308' notes='Document Information'></span></h6>
	<div class="d-inline-flex  w-100">
		<div class="w-100">
			<div>
				<p><b><span class='translate' data-i18n="1908" notes="Version"></span>: </b> ${lotoObj.lsu_document_version_number}</p>
			</div>
			<div>
				<p><b><span class='translate' data-i18n="9275" notes="Prepared By"></span>: </b> ${preparedBy}</p>
			</div>
			<div>
				<p><b><span class='translate' data-i18n="9276" notes="Validated By"></span>: </b> ${validatedBy}</p>
			</div>
			<div>
				<p><b><span class='translate' data-i18n="2118" notes="Approved By"></span>: </b> ${approvedBy}</p>
			</div>
		</div>`	

		if(currentEquipmentPic){
			equipmentProcedureModal+=
			`<div class="flex-shrink-1 text-center">
				<span class="d-flex justify-content-center align-items-center mb-2" style="background-repeat:no-repeat;background-position:center;background-size:contain; height:80px; width:150px; background-image: url(${currentEquipmentPic})"></span>
				<small><span class='translate' data-i18n="9274" notes="Equipment Picture"></span></small>
				</div>`
		}

	equipmentProcedureModal+=
	`</div>

	<h6 class="text-secondary pt-4"><span class='translate' data-i18n='9273' notes='Pre-lockout instructions'></span></h6>
	<div>
		<p>${currentEquipmentProcedure.lth_pre_lockeout_instruction}</p>
	</div>
	<div id="steps"></div>
	`
	
	$("#equipmentProcedure").empty().append(equipmentProcedureModal);

	if(currentEquipmentProcedure.steps){
		totalSteps=currentEquipmentProcedure.steps.length
		for(k in currentEquipmentProcedure.steps){
			lotoObj.step.push(newStep())
			lotoObj.step[k].lss_lts_id=currentEquipmentProcedure.steps[k].lts_id
			addStep(parseInt(k)+1)			
		}
	}

	function addStep(numStep){
		let energySource="";  lockoutDevice="";  sourceLocation=""; stepPicture=""
		if(energySourceList.find(source=>parseInt(source.rld_id)===parseInt(currentEquipmentProcedure.steps[numStep-1].lts_rld_energy_source))){
			energySource=energySourceList.find(source=>parseInt(source.rld_id)===parseInt(currentEquipmentProcedure.steps[numStep-1].lts_rld_energy_source)).rld_name
		}
		if(lockoutDeviceList.find(device=>parseInt(device.rld_id)===parseInt(currentEquipmentProcedure.steps[numStep-1].lts_rld_lockout_device))){
			lockoutDevice=lockoutDeviceList.find(device=>parseInt(device.rld_id)===parseInt(currentEquipmentProcedure.steps[numStep-1].lts_rld_lockout_device)).rld_name
		}
		if(sourceLocationList.find(location=>parseInt(location.rld_id)===parseInt(currentEquipmentProcedure.steps[numStep-1].lts_rld_source_location))){
			sourceLocation=sourceLocationList.find(location=>parseInt(location.rld_id)===parseInt(currentEquipmentProcedure.steps[numStep-1].lts_rld_source_location)).rld_name
		}
		stepPicture=currentEquipmentProcedure.steps[numStep-1].lts_pic

		let specialPPE=[]
		if(currentEquipmentProcedure.steps[numStep-1].special_ppe){
			for(i of currentEquipmentProcedure.steps[numStep-1].special_ppe){
				if(specialPPEList.find(ppe=>parseInt(ppe.rld_id)===parseInt(i))){
					ppe=specialPPEList.find(ppe=>parseInt(ppe.rld_id)===parseInt(i)).rld_name
					specialPPE.push(ppe)
				}				
			}
		}

		let accessories=[]
		if(currentEquipmentProcedure.steps[numStep-1].accessories){
			for(j of currentEquipmentProcedure.steps[numStep-1].accessories){
				if(accessoriesList.find(accessory=>parseInt(accessory.rld_id)===parseInt(j))){
					accessory=accessoriesList.find(accessory=>parseInt(accessory.rld_id)===parseInt(j)).rld_name
					accessories.push(accessory)
				}			
			}
		}

		let stepsModal = 
		`<h6 class="text-secondary pt-4"><span class='translate' data-i18n='2262' notes='Step'></span> ${numStep}</h6>
		<div class="d-inline-flex  w-100">
			<div class="w-100">
				<div>
					<p><b><span class='translate' data-i18n="9277" notes="Energy Source"></span>: </b> ${energySource}</p>
				</div>
				<div>
					<p><b><span class='translate' data-i18n="9278" notes="Lockout Device"></span>: </b> ${lockoutDevice}</p>
				</div>
				<div>
					<p><b><span class='translate' data-i18n="9279" notes="Source and Location"></span>: </b> ${sourceLocation}</p>
				</div>
				<div>
					<p><b><span class='translate' data-i18n="834" notes="Special PPE"></span>: </b> ${specialPPE}</p>
				</div>
				<div>
					<p><b><span class='translate' data-i18n="" notes="Accessories"></span>Accessories: </b> ${accessories}</p>
				</div>
			</div>`

			if(stepPicture){
				stepsModal+=
				`<div class="flex-shrink-1 text-center">
					<span class="d-flex justify-content-center align-items-center mb-2" style="background-repeat:no-repeat;background-position:center;background-size:contain; height:80px; width: 150px; background-image: url(${stepPicture})"> </span>					
					<small><span class='translate' data-i18n="9280" notes="Location Picture"></span></small>
					</div>`
			}

		stepsModal+=
		`</div>
		
		<div class="d-inline-flex  w-100">
			<div class="w-100">
				<div>
					<p><b><span class='translate' data-i18n="9530" notes="Energy Source to Lock Out"></span></b></p>
				</div>
				<div>
					<p>${currentEquipmentProcedure.steps[numStep-1].lts_element_to_neutralize}</p>
				</div>
			</div>
		</div>
				
		<div class="d-inline-flex  w-100">
			<div class="w-100">
				<div>
					<p><b><span class='translate' data-i18n="2687" notes="Instructions"></span></b></p>
				</div>
				<div>
					<p>${currentEquipmentProcedure.steps[numStep-1].lts_instruction}</p>
				</div>
			</div>
		</div>
						
		<div class="d-inline-flex  w-100">
			<div class="w-100">
				<div>
					<p><b><span class='translate' data-i18n="9282" notes="Validation"></span></b></p>
				</div>				
				<div id="validation_step_${numStep}"></div>
			</div>
		</div>
		<p class="form-text text-muted d-none"><span class='translate' data-i18n='9284' notes='Locked' style='color:red;'></span>: <input style='border: none; display: inline; width: 300px; background:none; color:red;' type="text" name="lock_${numStep}_time" id="lock_${numStep}_time" readonly></p>
		<p class="form-text text-muted d-none"><span class='translate' data-i18n='9285' notes='Unlocked' style='color:darkgreen;'></span>: <input style='border: none; display: inline; width: 300px; background:none; color:darkgreen;' type="text" name="unlock_${numStep}_time" id="unlock_${numStep}_time" readonly></p>
		<div class="md-form">
			<textarea name="comments_${numStep}" id="comments_${numStep}" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
			<label for="comments_${numStep}"><span class='translate' data-i18n='9283' notes='Notes and Remarks'></span></label>
		</div>
		<div class="my-4 d-none">
			<label class="text-muted"><span class='translate' data-i18n="" notes=""></span></label>
			<div class="btn-group d-flex" role="group" aria-label="Action subforms">
				<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='signature_lock_${numStep}' id="sign_lock_${numStep}"><i class="fa fa-pen"></i><span class='translate' data-i18n="1396" notes="Sign"></span></div>
				<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
				<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
			</div>
			<img id='signature_lock_${numStep}_img' src='' class='signatureImage d-block pt-2'/>
			<input type="hidden" name="signature_lock_${numStep}" id="signature_lock_${numStep}" class='modalSignature' value='' required>
			<input type="hidden" name="vector_lock_${numStep}" id='vector_lock_${numStep}' value=''>
			<input type="hidden" name="signature_lock_${numStep}_comments" id='signature_lock_${numStep}_comments' class="sig_comment" value=''>
			<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_lock_${numStep}_img_time" id="signature_lock_${numStep}_img_time" notes='signature_lock_${numStep}_img_time' readonly/></small>
		</div>
		<div class="my-4 d-none">
			<label class="text-muted"><span class='translate' data-i18n="" notes=""></span></label>
			<div class="btn-group d-flex" role="group" aria-label="Action subforms">
				<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='signature_unlock_${numStep}' id="sign_unlock_${numStep}"><i class="fa fa-pen"></i><span class='translate' data-i18n="1396" notes="Sign"></span></div>
				<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
				<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
			</div>
			<img id='signature_unlock_${numStep}_img' src='' class='signatureImage d-block pt-2'/>
			<input type="hidden" name="signature_unlock_${numStep}" id="signature_unlock_${numStep}" class='modalSignature' value='' >
			<input type="hidden" name="vector_unlock_${numStep}" id='vector_unlock_${numStep}' value=''>
			<input type="hidden" name="signature_unlock_${numStep}_comments" id='signature_unlock_${numStep}_comments' class="sig_comment" value=''>
			<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_unlock_${numStep}_img_time" id="signature_unlock_${numStep}_img_time" notes='signature_unlock_${numStep}_img_time' readonly/></small>
		</div>
		<button type="button"  name="button_lock_${numStep}" id="button_lock_${numStep}" class="btn btn-primary btn-block my-4 waves-effect waves-light" onclick="sign(this)" disabled="true"><span class='translate' data-i18n="9284" notes="Locked"></span></button>
		<button type="button"  name="button_unlock_${numStep}" id="button_unlock_${numStep}" class="btn btn-primary btn-block my-4 waves-effect waves-light d-none" onclick="sign(this)" disabled="true"><span class='translate' data-i18n="9286" notes="unlock"></span></button>`

		$("#steps").append(stepsModal)	
		
		let innerHTML=""
		for(k in currentEquipmentProcedure.steps[numStep-1].validation){
			innerHTML = innerHTML+
			`<div class="form-check pl-0 mb-4">
				<input type="checkbox" class="form-check-input ml-0" id="step_${numStep}_validation_${k}" name="step_${numStep}_validation_${k}" value="0" onchange="getCheckboxStatus(this)" required>
				<label class="form-check-label" for="step_${numStep}_validation_${k}">${currentEquipmentProcedure.steps[numStep-1].validation[k]}</label>
			</div>`
		}
		let validationHtml=document.getElementById("validation_step_" + numStep)
		validationHtml.innerHTML = innerHTML
		$(`#button_lock_1`).attr("disabled", false)
	}
	initializeSignatures()
	try {$('.translate').localize()} catch {}
}

function failedValidate(mode) {
	let formModal = new SofvieModal()	
	formModal.setModalElements(`danger`, `modalTitle`, i18next.t("1403")) // "Validation error"
	if(mode=="procedure"){
		formModal.setModalElements(`danger`, `modalText`, i18next.t("9366"))  // "Please select equipment type and equipment id first"
	}
	else if(mode=="stepValidation"){	
		formModal.setModalElements(`danger`, `modalText`, i18next.t("9420"))  // "Please check all validation items"
	}
	formModal.setModalElements(`danger`, `modalButtons`, `<a role="button" class="btn btn-danger waves-effect" id="modalClose"><span class='translate' data-i18n="1405" notes="Ok"></a>`)
	formModal.handleModal(`danger`)  
	$('.translate').localize()
	$('#modalClose').click(()=>{
		$(`#${formModal.name}`).modal('hide')
		$(`#${formModal.name}`).hide()
	})
	return false
}

function sign(lock_id) {
	let eleId=lock_id.id.split("_")
	currentLockState=eleId[1]
	currentLockStep=eleId[eleId.length-1]
	if(currentLockState=="lock"){
		if(parseInt(currentLockStep)==1){
			try	{
				headForm = formHeader.formValidate(form)// Call any form validation code in the header
				if(headForm === false)	{// If the header failed, abort
					return false// Return failure to abort the event
				}
				else{
					if(checkValidation()){
						$(`#sign_${currentLockState}_${currentLockStep}`).click()
					}
				}
			} catch(err)	{
				console.error('formHeader.formValidate: ' + err)
				return false
			}
		}
		else{
			if(checkValidation()){
				$(`#sign_${currentLockState}_${currentLockStep}`).click()
			}
		}
	}
	else{
		$(`#sign_${currentLockState}_${currentLockStep}`).click()
	}
}

function checkValidation(){
	if(currentLockState=="lock"){
		validationElements = document.querySelectorAll(`[id^='step_${currentLockStep}_validation_']`)	
		if($(`#lock_${currentLockStep}_time`).val()!='' ){
			return true
		}
		else{
			for(validationElement of validationElements){
				if(validationElement.classList.contains("form-check-input")){
					if(validationElement.value==0){
						failedValidate("stepValidation")
						return false
					}
				}	
			}
			return true		
		}
	}
	else {
		return false
	}
}

function checkSignature(){
	if($(`#signature_${currentLockState}_${currentLockStep}`).val()){
		lockAndUnlock()
	}
}

function lockAndUnlock(timeStamp) {
	$(`#button_${currentLockState}_${currentLockStep}`).addClass('d-none')
	if(currentLockState=="lock"){
		document.getElementById(`button_unlock_${currentLockStep}`).classList.remove('d-none')
		timeElement=document.getElementById(`lock_${currentLockStep}_time`)
		timeElement.parentElement.classList.remove('d-none')
		if(!timeStamp){
			timeStamp = moment().format('YYYY-MM-DD hh:mm:ss a')
			timeElement.value = timeStamp
		}
		else{
			timeElement.value = timeStamp
		}
		inputs = document.getElementsByClassName('lock')
		if(parseInt(currentLockStep)==1){
			for (let obj of inputs){
				obj.setAttribute('disabled' , true);
				if (obj.classList.contains('sign')){
					$("#"+obj.id).off("click")
					$("#clear"+obj.id).off('click')
					$("#"+obj.id).next().addClass("read-only")
				}
			}
			$("#select_equipment_procedure").addClass("d-none")
			$("#button_lock_2").attr("disabled", false)
		}
		if(!$(`#button_unlock_${parseInt(currentLockStep)-1}`).hasClass( "d-none" )){
			if(checkValidation()){
				for(validationElement of validationElements){
					validationElement.setAttribute('disabled' , true)
				}
			}
			$(`#comments_${currentLockStep}`).attr("disabled", true)

			if(parseInt(currentLockStep)==currentEquipmentProcedure.steps.length){
				let unlock_buttons = document.querySelectorAll('[id^="button_unlock_"]')
				for(unlock_button of unlock_buttons){
					unlock_button.removeAttribute("disabled")
				}
			}
			$(`#button_lock_${parseInt(currentLockStep)+1}`).attr("disabled", false)
		}
	}
	else if(currentLockState=="unlock"){
		timeElement=document.getElementById(`unlock_${currentLockStep}_time`)
		timeElement.parentElement.classList.remove('d-none')
		if(!timeStamp){
			timeStamp = moment().format('YYYY-MM-DD hh:mm:ss a')
			timeElement.value = timeStamp
		}
		else{
			timeElement.value = timeStamp
		}
		unlockedSteps.push(currentLockStep)		
		if(unlockedSteps.length==currentEquipmentProcedure.steps.length){
			el=`<button type="button"  name="fully_unlock" id="fully_unlock" class="btn btn-primary btn-block my-4 waves-effect waves-light" onclick="confirm(this)"><span class='translate' data-i18n="9289" notes="FULLY UNLOCKED"></span></button>`
			$(el).insertAfter( $(`#button_lock_${currentEquipmentProcedure.steps.length}`))
			$('.translate').localize()
		}
	}	
}

function confirm(ele){
	let formModal = new SofvieModal();                                                                                                 // initialize the Modal 
	formModal.setModalElements(`info`, `modalTitle`, i18next.t("9291")) // "Final Confirmation"
	formModal.setModalElements(`info`, `modalText`, i18next.t("9292")+`<br />`+i18next.t("9293"))  // "Have All Locks Been Removed and accounted for" “This Action Cannot be reversed”
	formModal.setModalElements(`info`, `modalButtons`, `<a role="button" class="btn btn-outline-primary waves-effect modalClose"><span class='translate' data-i18n="1257" notes="Cancel"></a><a role="button" class="btn btn-primary waves-effect modalClose" id="confirm"><span class='translate' data-i18n="9294" notes="Confirm"></a>`)
	formModal.handleModal(`info`)  
	$('.translate').localize()
	$('.modalClose').click(()=>{
		$(`#${formModal.name}`).modal('hide')
		$(`#${formModal.name}`).hide()
	})
	$('#confirm').click(()=>{
		$("#fully_unlock").addClass('d-none')
		$("#finalLock").removeClass('d-none')	

		timeStamp = moment().format('YYYY-MM-DD hh:mm:ss a')
		$("#all_unlock").empty().append(timeStamp)
		$("#all_unlock_time").val(timeStamp)
	})
}

function getCheckboxStatus(ele){
	let status = ele.checked;
	if (status) {
		ele.value='1'
	} else {
		ele.value='0'
	}
	if(ele.id=="needs_revision" && ele.value=='1'){
		$("#gen-modal-open").click()
	}
}

function convertToObj(json){
	lotoObj.header_date=json["date"]
	lotoObj.lsu_rld_site_id=json["site"]
	lotoObj.lsu_rld_job_id=json["job_number"]
	lotoObj.lsu_rld_level_id=json["level"]
	lotoObj.lsu_workplace=json["workplace"]
	lotoObj.lsu_per_supervisor=json["supervisor"]
	lotoObj.lsu_rld_type_of_intervention=json["type_of_intervention"]
	lotoObj.lsu_lte_id=json["equipment_type"]
	lotoObj.lsu_lth_equipment_number=json["equipment_id"]
	lotoObj.lsu_all_unlock_time=json["all_unlock_time"]
    lotoObj.lsu_rld_lock_status_id = json["loto_status"]
	lotoObj.lsu_comments=json["comments"]
	lotoObj.lsu_is_revision_needed=json["needs_revision"]	
	let completed_persons=json["completed_by"].split("|")
	for(person of completed_persons){
		lotoObj.completed_by.push(person)
	}
	for(i=0;i<totalSteps;i++){
		lotoObj.step[i].lss_lock_time=json[`lock_${i+1}_time`]
		lotoObj.step[i].lss_unlock_time=json[`unlock_${i+1}_time`]
		lotoObj.step[i].lss_notes=json[`comments_${i+1}`]
		lotoObj.step[i].lss_lock_signature=json[`signature_lock_${i+1}`]
		lotoObj.step[i].lss_unlock_signature=json[`signature_unlock_${i+1}`]
	}
	lotoObj.distribution=[]
	let distributionList=json["Report_Distribution1"]
	distributionList=distributionList.split("|")
	for(name of distributionList){
		lotoObj.distribution.push(name)
	}
	lotoObj.loto_general_actions=[]
	lotoObj.loto_hazard_actions=[]
	lotoObj.loto_positive_ids=[]
	for(child of json["Children"]){
		if(child["formdata"].formid=="131200"){   //General action
			lotoObj.loto_general_actions.push(child["formdata"])
		}
		else if(child["formdata"].formid=="131042"){   //Hazard Report
			lotoObj.loto_hazard_actions.push(child["formdata"])
		}
		else if(child["formdata"].formid=="166071"){   //Positive Recognition
			lotoObj.loto_positive_ids.push(child["formdata"])
		}
	}
	changePropertyNames(lotoObj)
}

function changePropertyNames(lotoObj){
	lotoObj.loto_general_actions.forEach((val)=>{
		val['sga_action_is_complete']=0
		val['sga_completed_action_type_rld_id']=null
		val['sga_completed_action_taken']=null
		val['sga_action_type_rld_id']=parseInt(val.action_type)
		val['sga_action_by_who_per_id']=val.action_by_who ? val.action_by_who.split("|").map(Number): []
		val['sga_action_by_when']=val.general_action_by_when
		val['sga_created_date']= val.general_action_by_when_submit
		val['sga_created_by_per_id']=parseInt(val.submittedby)
		val['sga_completed_action_date']=null
		val['sga_recommended_action']=val.recommended_action
		changeNameInCommon(val)
		delete val.action_type
		delete val.action_by_who
		delete val.general_action_by_when
		delete val.general_action_by_when_submit
		delete val.recommended_action
	})
	
	lotoObj.loto_hazard_actions.forEach((val)=>{
		val['action_by_who']=val.action_by_who ? val.action_by_who.split("|").map(Number): []
		val['hazard_type']=parseInt(val.hazard_type)
		val['action_complete_by_who']=val.action_completed_by_who
		val['action_completed_date']=val.action_completed_date ? val.action_completed_date :null
		val['immediate_action_required_and_performed'] = parseInt(val.immediate_action_required_and_performed)
		val['further_action_required'] = val.further_action_required ? parseInt(val.further_action_required) : 0
		val['action_type_score'] = val.action_type ? val['action_type_score']=parseInt(val.action_type.split('|')[1]) : 0
		val['action_type'] = val.action_type ? val['action_type']=parseInt(val.action_type.split('|')[0]) : 0
		val['hazard_identification']=val.hazard_identification?parseInt(val.hazard_identification.split('|')[0]):0
		val['hazard_identification_score']=parseInt(val.hazard_identification_score)
		val['immediate_action_type'] = val.immediate_action_type ? val['immediate_action_type']=parseInt(val.immediate_action_type.split('|')[0]) : 0
		val['immediate_action_score'] = val.immediate_action_score ? val['immediate_action_score']=parseInt(val.immediate_action_score) : 0
		val['potential_risk']=val.potential_risk? parseInt(val.potential_risk.split('|')[0]):0
		val['potential_risk_score']=parseInt(val.potential_risk_score)
		val['submittedby']=parseInt(val.submittedby)
		val['completed_action_score']=null
		val['completed_action_type']=null
		val['action_by_when']=val.action_by_when ? val.action_by_when :null
		changeNameInCommon(val)
	})

	lotoObj.loto_positive_ids.forEach((val)=>{
		val['RecognitionType']=parseInt(val.recognition_type)
		val['RecognitionOf']=[]
		val['EventDescription']=val.event_description
		val['RecognitionGivenType']= parseInt(val.recognition_given_type)
		val['WasRecognitionGiven']=parseInt(val.was_recognition_given)
		let recognitionofs=val.recognition_of.split("|")
		for(recognitionof of recognitionofs){
			val['RecognitionOf'].push(parseInt(recognitionof))
		}	
		changeNameInCommon(val)
		delete val.recognition_type
		delete val.recognition_of
		delete val.event_description
		delete val.recognition_given_type
		delete val.was_recognition_given
	})

	function changeNameInCommon(val){
		val['HeaderDate']=val.date
		val['Site']=parseInt(val.site)
		val['JobNumber']=parseInt(val.job_number)
		val['SiteLevel']=parseInt(val.level)
		val['Workplace']=val.workplace
		val['Supervisor']=parseInt(val.supervisor)
		delete val.date
		delete val.site
		delete val.job_number
		delete val.level
		delete val.workplace
		delete val.supervisor
		delete val.moduleId
		delete val.myFile
		delete val.draftField
		delete val.keyField
		delete val._rev
		delete val._id
		delete val.formname
		delete val.formtype
		delete val.formid
		delete val.version
		delete val.modal_report_distribution
		delete val.startFormTimeStamp
		delete val.endFormTimeStamp
		delete val.submittedby
		delete val.submissionId
		delete val.date_submit
		delete val.displayReferenceValue
		delete val["child-draft"]
		delete val["selected-draft"]
	}
	delete lotoObj['Children']
	return lotoObj
}

function draftPostProcess(parsedJSON){
	loadDraft=true
	if(parsedJSON["equipment_type"] && parsedJSON["equipment_id"]){
		getSingleLotoProcedure("loadDraft")

		$.each(parsedJSON, (name, val) => {	
			let $el = $('[name="' + name + '"]')
			if(name.startsWith("comments_")){
				$el[0].value=val
				if(val){
					$el[0].parentElement.getElementsByTagName("label")[0].classList.add('active')
				}	
			}
			if(name.startsWith("signature_")){
				$el[0].value=val
				if(val){
					$el[0].classList.remove('required')
				}	
			}
		})
	}
	let keys = Object.keys(parsedJSON)
	let lockAndUnlocksSteps=[]
	for(key of keys){
		if(key.includes("_validation_")){
			if(parsedJSON[key]==1){
				$(`#${key}`).prop( "checked", true )
				$(`#${key}`).val(1)
			}			
		}	
		if(key.includes("_img_time")){
			lockAndUnlocksSteps.push(key)
		}
	}
	lockAndUnlocksSteps.sort()
	
	for(lockAndUnlocksStep of lockAndUnlocksSteps){
		if(parsedJSON[lockAndUnlocksStep]){
			lockAndUnlocksStep=lockAndUnlocksStep.split("_")
			currentLockState=lockAndUnlocksStep[1]
			currentLockStep=lockAndUnlocksStep[2]
			timeStamp=parsedJSON[`${currentLockState}_${currentLockStep}_time`]
			lockAndUnlock(timeStamp)
		}
	}
}
</script>


<script src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
