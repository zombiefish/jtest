<?php	
  $strPageTitle = 'Employee Review Annual';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
					<h6 class="text-secondary"><span class='translate' data-i18n="1001" notes="Employee Review Annual"></span></h6>

					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
						</select>
						<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
					</div>

					<form name="employeeAnnualReview" id="employeeAnnualReview" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1490" notes="Legend"></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="employee_name" id="employee_name" class="select-single mobile-employee-select-id-single"  required>
							</select>
							<label for="employee_name"><span class='translate' data-i18n="190" notes="Employee"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="pay_class" id="pay_class" class="form-control" length="200" maxlength="200">
							<label for="pay_class"><span class='translate' data-i18n="122" notes="Current Pay Class"></span></label>
						</div>

						<div>					
							1 - <span class='translate' data-i18n="1516" notes="1 - Unsatisfactory Performance"></span>
							<small class="d-block mb-3"><span class='translate' data-i18n="1517" notes="Consistently fails to meet minimum position requirements."></span></small>

							2 - <span class='translate' data-i18n="1518" notes="2 - Opportunity for Improvement"></span>
							<small class="d-block mb-3"><span class='translate' data-i18n="1519" notes="Meets some, but not all positions requirements."></span></small>

							3 - <span class='translate' data-i18n="1520" notes="3 - Meets Expectations"></span>
							<small class="d-block mb-3"><span class='translate' data-i18n="1521" notes="Consistently meets position requirements."></span></small>

							4 - <span class='translate' data-i18n="1522" notes="4 - Exceeds Expectations"></span>
							<small class="d-block mb-3"><span class='translate' data-i18n="1523" notes="Consistently superior and significantly exceeds position requirements."></span></small>
						</div> 

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="804" notes="Safety"></span></h6>

						<div class="form-group mb-5">
							<label class="d-block"><span class='translate' data-i18n="1524" notes="Communicating Effectively for Safety"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons" id='safety_communication'>
								<label class="btn btn-outline-primary form-check-label " onclick="calcSafetyScore(this)">
									<input class="form-check-input" type="radio" name="safety_communication" id="safety_communication_1" value="1"> 1
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcSafetyScore(this)">
									<input class="form-check-input" type="radio" name="safety_communication" id="safety_communication_2" value="2"> 2
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcSafetyScore(this)">
									<input class="form-check-input" type="radio" name="safety_communication" id="safety_communication_3" value="3"> 3
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcSafetyScore(this)">
									<input class="form-check-input" type="radio" name="safety_communication" id="safety_communication_4" value="4"> 4
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
							<small class="form-text text-muted"><span class='translate' data-i18n="1525" notes="Promoting Safety through effective communication."></span></small>
						</div>

						<div class="form-group my-5">
							<label class="d-block"><span class='translate' data-i18n="1526" notes="Contributing to a Culture of Safety"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons" id='safety_culture'>
								<label class="btn btn-outline-primary form-check-label" onclick="calcSafetyScore(this)">
									<input class="form-check-input" type="radio" name="culture" id="culture_1" required value="1"> 1
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcSafetyScore(this)">
									<input class="form-check-input" type="radio" name="culture" id="culture_2" value="2"> 2
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcSafetyScore(this)">
									<input class="form-check-input" type="radio" name="culture" id="culture_3" value="3"> 3
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcSafetyScore(this)">
									<input class="form-check-input" type="radio" name="culture" id="culture_4" value="4"> 4
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
							<small class="form-text text-muted"><span class='translate' data-i18n="1527" notes="A commitment to apply skills, attitudes, and the Technica Core Values to everyday work."></span></small>
						</div>

						<div class="form-group my-5">
							<label class="d-block"><span class='translate' data-i18n="1528" notes="Recognizing, Responding to, and Reporting Incidents"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons" id="safety_recognition">
								<label class="btn btn-outline-primary form-check-label" onclick="calcSafetyScore(this)">
									<input class="form-check-input" type="radio" name="safety_recognition" id="safety_recognition_1" required value="1"> 1
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcSafetyScore(this)">
									<input class="form-check-input" type="radio" name="safety_recognition" id="safety_recognition_2" value="2"> 2
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcSafetyScore(this)">
									<input class="form-check-input" type="radio" name="safety_recognition" id="safety_recognition_3" value="3"> 3
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcSafetyScore(this)">
									<input class="form-check-input" type="radio" name="safety_recognition" id="safety_recognition_4" value="4"> 4
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
							<small class="form-text text-muted"><span class='translate' data-i18n="772" notes="Recognizing the occurrence of an incident or near miss, responding effectively to mitigate harm to individuals, ensuring proper reporting and preventing re-occurrence."></span></small>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="1530" notes="Safety Statistics"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="safety_stats_yes" name="safety_stats" value="1" onclick="calcSafetyScore(this)"required>
								<label class="form-check-label mr-2" for="safety_stats_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="safety_stats_no" name="safety_stats" value="0" onclick="calcSafetyScore(this)">
								<label class="form-check-label mr-2" for="safety_stats_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
							<small class="form-text text-muted"><span class='translate' data-i18n="1694" notes="Direct cause of a Recordable Incident, Restricted Work Injury, Medical Treatment Injury, of Lost Time Injury in the last 12 months?"></span></small>
						</div>
						<div class='cond-form-check-area'>
							<div class="md-form">
								<input type="text" name="incident_numbers" id="incident_numbers" class="form-control" length="200" maxlength="200">
								<label for="incident_numbers"><span class='translate' data-i18n="1531" notes="If yes, which incident numbers?"></span></label>
							</div>
						</div>
						<!-- Steve to do: Overall Safety Score formula -->
						<input type="hidden" name="safety_score" id="safety_score" value="0">
			
						<div class="md-form">
							<textarea name="safety_comments" id="safety_comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="safety_comments"><span class='translate' data-i18n="81" notes="Comments"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="944" notes="Work Performance"></span></h6>

						<div class="form-group mb-5">
							<label class="d-block"><span class='translate' data-i18n="1532" notes="Ethics and Integrity"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons" id="work_performance_ethics">
								<label class="btn btn-outline-primary form-check-label" onclick="calcWorkPerformanceScore(this)" >
									<input class="form-check-input" type="radio" name="performance_1" id="performance_1_1" value='1' required> 1
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcWorkPerformanceScore(this)">
									<input class="form-check-input" type="radio" name="performance_1" id="performance_1_2" value='2'> 2
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcWorkPerformanceScore(this)">
									<input class="form-check-input" type="radio" name="performance_1" id="performance_1_3" value='3'> 3
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcWorkPerformanceScore(this)">
									<input class="form-check-input" type="radio" name="performance_1" id="performance_1_4" value='4'> 4
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
							<small class="form-text text-muted"><span class='translate' data-i18n="1533" notes="Earns others trust and respect through consistency, honesty and professionalism."></span></small>
						</div>

						<div class="form-group my-5">
							<label class="d-block"><span class='translate' data-i18n="1534" notes="Attention to Detail"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons" id="work_performance_attention_to_detail">
								<label class="btn btn-outline-primary form-check-label" onclick="calcWorkPerformanceScore(this)">
									<input class="form-check-input" type="radio" name="performance_2" id="performance_2_1" value='1' required> 1
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcWorkPerformanceScore(this)">
									<input class="form-check-input" type="radio" name="performance_2" id="performance_2_2" value='2'> 2
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcWorkPerformanceScore(this)">
									<input class="form-check-input" type="radio" name="performance_2" id="performance_2_3" value='3'> 3
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcWorkPerformanceScore(this)">
									<input class="form-check-input" type="radio" name="performance_2" id="performance_2_4" value='4'> 4
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
							<small class="form-text text-muted"><span class='translate' data-i18n="1535" notes="Diligently attends to details and pursues quality in accomplishing tasks."></span></small>
						</div>

						<div class="form-group my-5">
							<label class="d-block"><span class='translate' data-i18n="1536" notes="Accountability and Dependability"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons" id="work_performance_accountability">
								<label class="btn btn-outline-primary form-check-label" onclick="calcWorkPerformanceScore(this)">
									<input class="form-check-input" type="radio" name="performance_3" id="performance_3_1" value='1'required> 1
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcWorkPerformanceScore(this)">
									<input class="form-check-input" type="radio" name="performance_3" id="performance_3_2" value='2'> 2
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcWorkPerformanceScore(this)">
									<input class="form-check-input" type="radio" name="performance_3" id="performance_3_3" value='3'> 3
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcWorkPerformanceScore(this)">
									<input class="form-check-input" type="radio" name="performance_3" id="performance_3_4" value='4'> 4
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
							<small class="form-text text-muted"><span class='translate' data-i18n="1537" notes="Takes personal responsibility for the quality and timeliness of work and achieves results with little oversight."></span></small>
						</div>

						<!-- Steve to do: Overall Work Performance Score formula -->
						<input type="hidden" name="wp_score_1" id="wp_score_1" value="0">
						<div class="md-form">
							<textarea name="safety_comments_1" id="safety_comments_1" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="safety_comments_1"><span class='translate' data-i18n="81" notes="Comments"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1538" notes="Compliance"></span></h6>

						<div class="form-group mb-5">
							<label class="d-block"><span class='translate' data-i18n="1539" notes="Policies and Procedures"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons" id="compliance_policies_procedures">
								<label class="btn btn-outline-primary form-check-label" onclick="calcComplianceScore(this)">
									<input class="form-check-input" type="radio" name="compliance_1" id="compliance_1_1" value='1'required> 1
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcComplianceScore(this)">
									<input class="form-check-input" type="radio" name="compliance_1" id="compliance_1_2" value='2'> 2
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcComplianceScore(this)">
									<input class="form-check-input" type="radio" name="compliance_1" id="compliance_1_3" value='3'> 3
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcComplianceScore(this)">
									<input class="form-check-input" type="radio" name="compliance_1" id="compliance_1_4" value='4'> 4
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
							<small class="form-text text-muted"><span class='translate' data-i18n="1540" notes="Follows workplace policies and procedures safely and efficiently while working."></span></small>
						</div>

						<div class="form-group my-5">
							<label class="d-block"><span class='translate' data-i18n="1541" notes="Core Values"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons" id="compliance_core_values">
								<label class="btn btn-outline-primary form-check-label" onclick="calcComplianceScore(this)">
									<input class="form-check-input" type="radio" name="compliance_2" id="compliance_2_1" value='1' required> 1
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcComplianceScore(this)">
									<input class="form-check-input" type="radio" name="compliance_2" id="compliance_2_2" value='2'> 2
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcComplianceScore(this)">
									<input class="form-check-input" type="radio" name="compliance_2" id="compliance_2_3" value='3'> 3
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcComplianceScore(this)">
									<input class="form-check-input" type="radio" name="compliance_2" id="compliance_2_4" value='4'> 4
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
							<small class="form-text text-muted"><span class='translate' data-i18n="1542" notes="Works in accord with the Technica Core Values (Respect, Integrity, Courage, Honesty and Humility)"></span></small>
						</div>

						<div class="form-group my-5">
							<label class="d-block"><span class='translate' data-i18n="1543" notes="Care of Tools and Equipment"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons" id="compliance_care_tools_equipment">
								<label class="btn btn-outline-primary form-check-label" onclick="calcComplianceScore(this)">
									<input class="form-check-input" type="radio" name="compliance_3" id="compliance_3_1" value='1' required> 1
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcComplianceScore(this)">
									<input class="form-check-input" type="radio" name="compliance_3" id="compliance_3_2" value='2'> 2
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcComplianceScore(this)">
									<input class="form-check-input" type="radio" name="compliance_3" id="compliance_3_3" value='3'> 3
								</label>
								<label class="btn btn-outline-primary form-check-label" onclick="calcComplianceScore(this)">
									<input class="form-check-input" type="radio" name="compliance_3" id="compliance_3_4" value='4'> 4
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
							<small class="form-text text-muted"><span class='translate' data-i18n="1544" notes="Shows care and conscientiousness before, during and after using tools, machines, equipment and/or vehicles to complete assigned work."></span></small>
						</div>

						<!-- Steve to do: Overall Compliance Score formula -->
						<input type="hidden" name="safety_score_2" id="safety_score_2" value="0">

						<div class="md-form">
							<textarea name="safety_comments_2" id="safety_comments_2" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="safety_comments_2"><span class='translate' data-i18n="81" notes="Comments"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1545" notes="Positive Recognition Points"></span></h6>

						<div class="md-form">
							<input type="number" min="0" max="3" name="PRpoints" id="PRpoints" class="form-control" oninput="calcPosRecScore(this)">
							<label for="PRpoints"><span class='translate' data-i18n="1546" notes="Number of points (0-3)"></span></label>
							<small class="form-text text-muted"><span class='translate' data-i18n="1547" notes="Enter the amount of Positive Recognition Points that you feel this employee has demonstrated through their work performance."></span></small>
						</div>

						<div class="md-form">
							<textarea name="points_given" id="points_given" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="points_given" class="pr-5"><span class='translate' data-i18n="748" notes="Please explain the reasoning behind the amount of points given."></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1548" notes="Overall Employee Performance"></span></h6>

						<!-- Steve to do: Overall Safety Score formula -->
						<input type="hidden" name="overall_1" id="overall_1" value = '0'>
						<!-- Steve to do: Overall Work Performance Score formula -->
						<input type="hidden" name="overall_2" id="overall_2" value = '0'>
						<!-- Steve to do: Overall Compliance Score formula -->
						<input type="hidden" name="overall_3" id="overall_3" value = '0'>
						<!-- Steve to do: Overall Positive Recognition Score formula -->
						<input type="hidden" name="overall_4" id="overall_4" value = '0'>
						<!-- Steve to do: Overall Employee Score formula -->
						<input type="input" name="overallSummary" id="overallSummary" style="background-color: transparent; border:none;"value = '0' disabled>

						

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1549" notes="Performance Summary"></span></h6>

						<div class="md-form">
							<textarea name="effectiveness" id="effectiveness" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="effectiveness"><span class='translate' data-i18n="1550" notes="Effectiveness"></span></label>
							<small class="form-text text-muted"><span class='translate' data-i18n="622" notes="List all aspects of the employee's performance that contributed to his/her effectiveness."></span></small>
						</div>

						<div class="md-form">
							<textarea name="improvement" id="improvement" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="improvement"><span class='translate' data-i18n="1551" notes="Performance improvement"></span></label>
							<small class="form-text text-muted"><span class='translate' data-i18n="623" notes="List aspects of the employee's performance that require improvement for greater effectiveness."></span></small>
						</div>

						<div class="md-form">
							<textarea name="responsibility" id="responsibility" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="responsibility"><span class='translate' data-i18n="1552" notes="Responsibility"></span></label>
							<small class="form-text text-muted"><span class='translate' data-i18n="559" notes="In what way is the employee ready for increased responsibility?"></span></small>
						</div>

						<div class="md-form">
							<textarea name="training" id="training" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="training"><span class='translate' data-i18n="1553" notes="Training"></span></label>
							<small class="form-text text-muted"><span class='translate' data-i18n="922" notes="What additional training will they need to be more successful?"></span></small>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1510" notes="Goal and Development Summary"></span></h6>

						<div class="md-form">
							<textarea name="goals_1" id="goals_1" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="goals_1"><span class='translate' data-i18n="1511" notes="Performance Goals"></span></label>
							<small class="form-text text-muted"><span class='translate' data-i18n="1512" notes="Performance Goals"></span></small>
						</div>

						<div class="md-form">
							<textarea name="goals_2" id="goals_2" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="goals_2"><span class='translate' data-i18n="1513" notes="Development Goals"></span></label>
							<small class="form-text text-muted"><span class='translate' data-i18n="625" notes="List the employee's development goals for the coming year."></span></small>
						</div>

						<div class="md-form">
							<textarea name="goals_3" id="goals_3" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="goals_3"><span class='translate' data-i18n="1514" notes="Other work"></span></label>
							<small class="form-text text-muted"><span class='translate' data-i18n="180" notes="Does the employee have a desire and ability to progress to another type of work?"></span></small>
						</div>
						
						<canvas id="canvas" style='display:none;'></canvas>
						
						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="217" notes="Employee Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='employee_signature'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='employee_signature_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="employee_signature" id="employee_signature" class='modalSignature' value='' required>
							<input type="hidden" name="vector_employee" id='vector_employee' value=''>
							<input type="hidden" name="employee_signature_comments" id='employee_signature_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="employee_signature_img_time" id="employee_signature_img_time" notes='employee_signature_img_time' readonly/></small>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="465" notes="Evaluator Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='evaluator_signature'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='evaluator_signature_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="evaluator_signature" id="evaluator_signature" class='modalSignature' value=''>
							<input type="hidden" name="vector_evaluator" id='vector_evaluator' value=''>
							<input type="hidden" name="evaluator_signature_comments" id='evaluator_signature_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="evaluator_signature_img_time" id="evaluator_signature_img_time" notes='evaluator_signature_img_time' readonly/></small>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="640" notes="Manager Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='manager_signature'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='manager_signature_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="manager_signature" id="manager_signature" class='modalSignature' value='' >
							<input type="hidden" name="vector_manager" id='vector_manager' value=''>
							<input type="hidden" name="manager_signature_comments" id='manager_signature_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="manager_signature_img_time" id="manager_signature_img_time" notes='manager_signature_img_time' readonly/></small>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag='1001' class = "trans_input" value="1001"/>
						<input type="hidden" name="formtype" id="formtype" value="HR" />
						<input type="hidden" name="formid" id="formid" value="248322" />
						<input type="hidden" name="version" id="version" value="31" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="employee_name" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>

</main>
<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
			
			return true;
		}	
	}
	function calcSafetyScore()	{
     setTimeout(()=>{
     incidentModifierValue = 0  
     safetyCommunications = $('#safety_communication').find('.active').length > 0 ? $('#safety_communication').find('.active').children()[0].value : 0 
     safetyCulture = $('#safety_culture').find('.active').length > 0 ? $('#safety_culture').find('.active').children()[0].value : 0 
     safetyRecognition = $('#safety_recognition').find('.active').length > 0 ? $('#safety_recognition').find('.active').children()[0].value : 0 
     // Calculate and populate safety_score
     if(document.querySelector('input[name="safety_stats"]:checked'))
     incidentModifierValue = document.querySelector('input[name="safety_stats"]:checked').value === '1' ? -10 : 0
     // Calculate Score
     var safetyValue =  parseInt(parseFloat((parseInt(safetyCommunications, 10) + parseInt(safetyCulture, 10) + parseInt(safetyRecognition, 10)) / 12) * 100 + incidentModifierValue , 10)
     document.getElementById('overall_1').value = safetyValue
     document.getElementById('safety_score').value = safetyValue     
     calcOverallScore()
     }, 100)
  }
  
  function calcWorkPerformanceScore()	{
     setTimeout(()=>{
     workPerformanceEthics = $('#work_performance_ethics').find('.active').length > 0 ? $('#work_performance_ethics').find('.active').children()[0].value : 0 
     workPerformanceAttentionToDetail = $('#work_performance_attention_to_detail').find('.active').length > 0 ? $('#work_performance_attention_to_detail').find('.active').children()[0].value : 0 
     workPerformanceAccountability = $('#work_performance_accountability').find('.active').length > 0 ? $('#work_performance_accountability').find('.active').children()[0].value : 0 
     // Calculate Score
     const performanceValue =  parseInt(parseFloat((parseInt(workPerformanceEthics, 10) + parseInt(workPerformanceAttentionToDetail, 10) + parseInt(workPerformanceAccountability, 10)) / 12) * 100 , 10)
     // Put Values in page
     document.getElementById('overall_2').value = performanceValue
     document.getElementById('wp_score_1').value = performanceValue     
     calcOverallScore()
     }, 100)
  }

  function calcComplianceScore()	{
     setTimeout(()=>{
     compliancePoliciesProcedures = $('#compliance_policies_procedures').find('.active').length > 0 ? $('#compliance_policies_procedures').find('.active').children()[0].value : 0 
     complianceCoreValues = $('#compliance_core_values').find('.active').length > 0 ? $('#compliance_core_values').find('.active').children()[0].value : 0 
     complianceCareToolsEquipment = $('#compliance_care_tools_equipment').find('.active').length > 0 ? $('#compliance_care_tools_equipment').find('.active').children()[0].value : 0 
     // Calculate Score
     const complianceValue =  parseInt(parseFloat((parseInt(compliancePoliciesProcedures, 10) + parseInt(complianceCoreValues, 10) + parseInt(complianceCareToolsEquipment, 10)) / 12) * 100 , 10)
      // Put Values in page
     document.getElementById('overall_3').value = complianceValue
     document.getElementById('safety_score_2').value = complianceValue 
     calcOverallScore()  
     }, 100)
  }

  function calcPosRecScore(posrec) {
     document.getElementById('overall_4').value = posrec.value * 5
     calcOverallScore()
  }

  function calcOverallScore(posrec) {
    var overAllEmployeePoints = parseInt(parseFloat((parseInt(document.getElementById('overall_1').value,10) + parseInt(document.getElementById('overall_2').value,10)
     + parseInt(document.getElementById('overall_3').value, 10)) / 3),10) + parseInt(document.getElementById('overall_4').value,10)
          if(overAllEmployeePoints > 100) {
                overAllEmployeePoints = 100;
              }
          document.getElementById('overallSummary').value = overAllEmployeePoints
  }
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>