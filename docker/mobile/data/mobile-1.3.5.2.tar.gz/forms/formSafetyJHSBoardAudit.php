<?php	
  $strPageTitle = 'Safety-JHS Board Audit';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary"><span class='translate' data-i18n='1015' notes='Safety-jhs Board Audit'></span></h6>
          <div class="pt-1 position-relative my-4">
            <select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
            </select>
            <label for="draft"><span class='translate' data-i18n='1474' notes='Form Drafts'></span></label>
          </div>

          <form name="formSafetyJHSBoardAudit" id="formSafetyJHSBoardAudit" class="needs-validation" method="POST" action="#" novalidate>
          
						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1985' notes='Safety/JHS Board'></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="auditor" id="auditor" class="select-single mobile-supervisors-select" required>
							</select>
							<label for="auditor"><span class='translate' data-i18n='62' notes='Auditor'></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1615' notes='Clean and Organized'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="clean_and_organized_yes" name="clean_and_organized" value="1" required>
								<label class="form-check-label mr-2" for="clean_and_organized_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="clean_and_organized_no" name="clean_and_organized" value="0">
								<label class="form-check-label mr-2" for="clean_and_organized_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="clean_and_organized_na" name="clean_and_organized" value="-1">
								<label class="form-check-label mr-2" for="clean_and_organized_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>

					    <div class="form-group photoImage" id="board_picture"> 
							<label class="d-block"><span class='translate' data-i18n='1413' notes='Include Photos'></span></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n='2340' notes='ADD IMAGES'></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
								<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n='1389' notes='Please take scene pictures from all perspectives'></span></small>
								<div class="row photoGallery" id="galleryid"></div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1616' notes='Updated JHSC Member List and Contact Info'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="updated_jhsc_member_list_and_contact_Info_yes" name="updated_jhsc_member_list_and_contact_Info" value="1">
								<label class="form-check-label mr-2" for="updated_jhsc_member_list_and_contact_Info_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="updated_jhsc_member_list_and_contact_Info_no" name="updated_jhsc_member_list_and_contact_Info" value="0">
								<label class="form-check-label mr-2" for="updated_jhsc_member_list_and_contact_Info_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="updated_jhsc_member_list_and_contact_Info_na" name="updated_jhsc_member_list_and_contact_Info" value="-1">
								<label class="form-check-label mr-2" for="updated_jhsc_member_list_and_contact_Info_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1617' notes='First Aid Regulation 101 Poster'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="first_aid_regulation_101_poster_yes" name="first_aid_regulation_101_poster" value="1">
								<label class="form-check-label mr-2" for="first_aid_regulation_101_poster_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="first_aid_regulation_101_poster_no" name="first_aid_regulation_101_poster" value="0">
								<label class="form-check-label mr-2" for="first_aid_regulation_101_poster_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="first_aid_regulation_101_poster_na" name="first_aid_regulation_101_poster" value="-1">
								<label class="form-check-label mr-2" for="first_aid_regulation_101_poster_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1618' notes='What you should know OESA poster'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="should_know_oesa_poster_yes" name="should_know_oesa_poster" value="1">
								<label class="form-check-label mr-2" for="should_know_oesa_poster_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="should_know_oesa_poster_no" name="should_know_oesa_poster" value="0">
								<label class="form-check-label mr-2" for="should_know_oesa_poster_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="should_know_oesa_poster_na" name="should_know_oesa_poster" value="-1">
								<label class="form-check-label mr-2" for="should_know_oesa_poster_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1619' notes='WSIB in case of Injury at Work Poster'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="wsib_in_case_of_Injury_at_work_poster_yes" name="wsib_in_case_of_Injury_at_work_poster" value="1">
								<label class="form-check-label mr-2" for="wsib_in_case_of_Injury_at_work_poster_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="wsib_in_case_of_Injury_at_work_poster_no" name="wsib_in_case_of_Injury_at_work_poster" value="0">
								<label class="form-check-label mr-2" for="wsib_in_case_of_Injury_at_work_poster_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="wsib_in_case_of_Injury_at_work_poster_na" name="wsib_in_case_of_Injury_at_work_poster" value="-1">
								<label class="form-check-label mr-2" for="wsib_in_case_of_Injury_at_work_poster_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1620' notes='Technica 10 Fundamental Rules Poster'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="technica_10_fundamental_rules_poster_yes" name="technica_10_fundamental_rules_poster" value="1">
								<label class="form-check-label mr-2" for="technica_10_fundamental_rules_poster_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="technica_10_fundamental_rules_poster_no" name="technica_10_fundamental_rules_poster" value="0">
								<label class="form-check-label mr-2" for="technica_10_fundamental_rules_poster_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="technica_10_fundamental_rules_poster_na" name="technica_10_fundamental_rules_poster" value="-1">
								<label class="form-check-label mr-2" for="technica_10_fundamental_rules_poster_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1621' notes='Work Refusal Flow Chart'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="work_refusal_flow_chart_yes" name="work_refusal_flow_chart" value="1">
								<label class="form-check-label mr-2" for="work_refusal_flow_chart_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="work_refusal_flow_chart_no" name="work_refusal_flow_chart" value="0">
								<label class="form-check-label mr-2" for="work_refusal_flow_chart_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="work_refusal_flow_chart_na" name="work_refusal_flow_chart" value="-1">
								<label class="form-check-label mr-2" for="work_refusal_flow_chart_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1622' notes='Health & Safety At Work Poster'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="health_safety_at_work_poster_yes" name="health_safety_at_work_poster" value="1">
								<label class="form-check-label mr-2" for="health_safety_at_work_poster_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="health_safety_at_work_poster_no" name="health_safety_at_work_poster" value="0">
								<label class="form-check-label mr-2" for="health_safety_at_work_poster_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="health_safety_at_work_poster_na" name="health_safety_at_work_poster" value="-1">
								<label class="form-check-label mr-2" for="health_safety_at_work_poster_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1623' notes='Technica Mining HSE Policy 2018'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="technica_mining_hse_policy_2018_yes" name="technica_mining_hse_policy_2018" value="1" required>
								<label class="form-check-label mr-2" for="technica_mining_hse_policy_2018_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="technica_mining_hse_policy_2018_no" name="technica_mining_hse_policy_2018" value="0">
								<label class="form-check-label mr-2" for="technica_mining_hse_policy_2018_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="technica_mining_hse_policy_2018_na" name="technica_mining_hse_policy_2018" value="-1">
								<label class="form-check-label mr-2" for="technica_mining_hse_policy_2018_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1624' notes='Technica Injury Reporting Protocol 2018'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="technica_injury_reporting_protocol_2018_yes" name="technica_injury_reporting_protocol_2018" value="1" required>
								<label class="form-check-label mr-2" for="technica_injury_reporting_protocol_2018_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="technica_injury_reporting_protocol_2018_no" name="technica_injury_reporting_protocol_2018" value="0">
								<label class="form-check-label mr-2" for="technica_injury_reporting_protocol_2018_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="technica_injury_reporting_protocol_2018_na" name="technica_injury_reporting_protocol_2018" value="-1">
								<label class="form-check-label mr-2" for="technica_injury_reporting_protocol_2018_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1625' notes='JHSC Meeting Minutes'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="jhsc_meeting_minutes_yes" name="jhsc_meeting_minutes" value="1" required>
								<label class="form-check-label mr-2" for="jhsc_meeting_minutes_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="jhsc_meeting_minutes_no" name="jhsc_meeting_minutes" value="0">
								<label class="form-check-label mr-2" for="jhsc_meeting_minutes_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="jhsc_meeting_minutes_na" name="jhsc_meeting_minutes" value="-1">
								<label class="form-check-label mr-2" for="jhsc_meeting_minutes_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1626' notes='JHSC and STS workplace inspection'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="jhsc_sts_workplace_inspection_yes" name="jhsc_sts_workplace_inspection" value="1" required>
								<label class="form-check-label mr-2" for="jhsc_sts_workplace_inspection_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="jhsc_sts_workplace_inspection_no" name="jhsc_sts_workplace_inspection" value="0">
								<label class="form-check-label mr-2" for="jhsc_sts_workplace_inspection_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="jhsc_sts_workplace_inspection_na" name="jhsc_sts_workplace_inspection" value="-1">
								<label class="form-check-label mr-2" for="jhsc_sts_workplace_inspection_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1627' notes='OHSA Green Book Dec 2017'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="ohsa_green_book_dec_2017_yes" name="ohsa_green_book_dec_2017" value="1" required>
								<label class="form-check-label mr-2" for="ohsa_green_book_dec_2017_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="ohsa_green_book_dec_2017_no" name="ohsa_green_book_dec_2017" value="0">
								<label class="form-check-label mr-2" for="ohsa_green_book_dec_2017_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="ohsa_green_book_dec_2017_na" name="ohsa_green_book_dec_2017" value="-1">
								<label class="form-check-label mr-2" for="ohsa_green_book_dec_2017_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1628' notes='Sexual Harassment Guidline poster?'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="sexual_harassment_guideline_poster_yes" name="sexual_harassment_guideline_poster" value="1" required>
								<label class="form-check-label mr-2" for="sexual_harassment_guideline_poster_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="sexual_harassment_guideline_poster_no" name="sexual_harassment_guideline_poster" value="0">
								<label class="form-check-label mr-2" for="sexual_harassment_guideline_poster_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="sexual_harassment_guideline_poster_na" name="sexual_harassment_guideline_poster" value="-1">
								<label class="form-check-label mr-2" for="sexual_harassment_guideline_poster_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='81' notes='Comments'></span></h6>
						<div class="md-form">
							<textarea name="sts_feedback" id="sts_feedback" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="sts_feedback"><span class='translate' data-i18n='840' notes='STS Feedback'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1601' notes='Correction and Action Requirements'></span></h6>
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='915' notes='Were any areas of improvement identified?'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input radio-check" id="any_areas_of_improvement_identified_yes" name="any_areas_of_improvement_identified" value="1" required>
								<label class="form-check-label mr-2" for="any_areas_of_improvement_identified_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input radio-check" id="any_areas_of_improvement_identified_no" name="any_areas_of_improvement_identified" value="0">
								<label class="form-check-label mr-2" for="any_areas_of_improvement_identified_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

<div class='cond-form-check-area'> 
						
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1602' notes='Is a follow up required with the employee'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="follow_up_with_the_employee_yes" name="follow_up_with_the_employee" value="1" required>
								<label class="form-check-label mr-2" for="follow_up_with_the_employee_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="follow_up_with_the_employee_no" name="follow_up_with_the_employee" value="0">
								<label class="form-check-label mr-2" for="follow_up_with_the_employee_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1603' notes='Is a follow up required with the task'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="follow_up_with_the_task_yes" name="follow_up_with_the_task" value="1" required>
								<label class="form-check-label mr-2" for="follow_up_with_the_task_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="follow_up_with_the_task_no" name="follow_up_with_the_task" value="0">
								<label class="form-check-label mr-2" for="follow_up_with_the_task_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>
</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" note="SAFETY-JHS BOARD AUDIT" class = "trans_input" value="1015" tag="1015"/>
						<input type="hidden" name="formtype" id="formtype" value="STS" />
						<input type="hidden" name="formid" id="formid" value="236762"/>
						<input type="hidden" name="version" id="version" value="16" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>

				</div>
			</div>
		</div>
	</div>
</main>

    <div id="sync-wrapper">
    </div>

    <div id="output">
    </div>

<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}	
	}
	function radioButtonCheck() {
		$('.radio-check').change((e) =>{
			requiredRadio(e.currentTarget.defaultValue)
		})
	};
	document.addEventListener('DOMContentLoaded', radioButtonCheck, false);
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>