<?php	
  $strPageTitle = 'Preliminary Investigation';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
					<h6 class="text-secondary"><span class='translate' data-i18n="1002" notes="Preliminary investigation"></span></h6>
					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
						</select>
						<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
					</div>

					<form name="PreliminaryInvestigation" id="PreliminaryInvestigation" class="needs-validation" method="GET" action="#" novalidate>
          
						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1721" notes="Investigation Team"></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="investigator_1" id="investigator_1" class="select-single mobile-employee-select-single" required>
							</select>
							<label for="investigator_1"><span class='translate' data-i18n="576" notes="Investigator 1 (lead)"></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="investigator_2" id="investigator_2" class="select-single mobile-employee-select-single">
							</select>
							<label for="investigator_2"><span class='translate' data-i18n="577" notes="Investigator 2"></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="investigator_3" id="investigator_3" class="select-single mobile-employee-select-single">
							</select>
							<label for="investigator_3"><span class='translate' data-i18n="578" notes="Investigator 3"></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="investigator_4" id="investigator_4" class="select-single mobile-employee-select-single">
							</select>
							<label for="investigator_4"><span class='translate' data-i18n="579" notes="Investigator 4 (JHSC)"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="investigator_5" id="investigator_5" class="form-control" length="200" maxlength="200">
							<label for="investigator_5"><span class='translate' data-i18n="580" notes="Investigator 5 (other)"></span></label>
						</div>

						<div class="md-form">
							<input type="text" class="form-control timepicker" name="investigation_time" id="investigation_time" required>
							<label for="investigation_time"><span class='translate' data-i18n="575" notes="Investigation Time"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1950" notes="Investigation Summary - What Happened?"></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="event_type" id="event_type" class="select-single mobile-incidenttypes-select" onChange="document.getElementById('formmisc').value = this.value" required>
							</select>
							<label for="event_type"><span class='translate' data-i18n="9168" notes="Incident Class"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="event_location" id="event_location" class="form-control" length="200" maxlength="200" required>
							<label for="event_location"><span class='translate' data-i18n="469" notes="Event location"></span></label>
						</div>

						<div class="pt-1 md-form"> 
							<input type="text" name="event_date" id="event_date" class="form-control datepicker" required/>
							<label for="event_date"><span class='translate' data-i18n="466" notes="Event Date"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="event_time" id="event_time" class="form-control timepicker" required>
							<label for="event_time"><span class='translate' data-i18n="473" notes="Event Time"></span></label>
						</div>

						<div class="pt-1 position-relative">
							<select name="event_shift" id="event_shift" class="select-single mobile-shift-select" required>
							</select>
							<label for="event_shift"><span class='translate' data-i18n="470" notes="Event Shift"></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="event_shift_schedule" id="event_shift_schedule" class="select-single mobile-eventshiftschedule-select" required>
							</select>
							<label for="event_shift_schedule"><span class='translate' data-i18n="471" notes="Event Shift Schedule"></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="event_shift_supervisor" id="event_shift_supervisor" class="select-single mobile-employee-select-single" required>
							</select>
							<label for="event_shift_supervisor"><span class='translate' data-i18n="472" notes="Event Shift Supervisor"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="1727" notes="Was the scene secured?"></span></label>
							<div class="form-check custom-radio no-sub pl-0" id="scene_secured">
								<input type="radio" class="form-check-input" id="scene_secured_yes" name="scene_secured" value="1" required>
								<label class="form-check-label mr-2" for="scene_secured_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="scene_secured_no" name="scene_secured" value="0">
								<label class="form-check-label mr-2" for="scene_secured_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="scene_secured_na" name="scene_secured" value="-1">
								<label class="form-check-label mr-2" for="scene_secured_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form">
							<textarea name="event_detail_summary" id="event_detail_summary" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="event_detail_summary"><span class='translate' data-i18n="468" notes="Event details & summary (point form)"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1728" notes="Investigation Summary - Who was directly involved"></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="who_involved" id="who_involved" class="select-single mobile-employee-select-single" required>
							</select>
							<label for="who_involved"><span class='translate' data-i18n="931" notes="Who was involved with the incident?"></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
						<select name="who_involved_position" id="who_involved_position" class="select-single mobile-employeeposition-select" single  required>
							</select>
							<label for="who_involved_position"><span class='translate' data-i18n='1277' notes = 'Position'></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="others_involved" id="others_involved" class="form-control" length="200" maxlength="200">
							<label for="others_involved"><span class='translate' data-i18n="1713" notes="Were others involved?"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="898" notes="Was the involved safety card gathered?"></span></label>
							<div class="form-check custom-radio no-radio pl-0" id='was_5pt_card_gathered'>
								<input type="radio" class="form-check-input" id="was_5pt_card_gathered_yes" name="was_5pt_card_gathered" value="1" required>
								<label class="form-check-label mr-2" for="was_5pt_card_gathered_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="was_5pt_card_gathered_no" name="was_5pt_card_gathered" value="0">
								<label class="form-check-label mr-2" for="was_5pt_card_gathered_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="was_5pt_card_gathered_na" name="was_5pt_card_gathered" value="-1">
								<label class="form-check-label mr-2" for="was_5pt_card_gathered_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>
						<div class='cond-form-check-area'> 
							<div class="md-form">
								<textarea name="why_no" id="why_no" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="why_no"><span class='translate' data-i18n="1733" notes="If no, explain why."></span></label>
							</div>
						</div>
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="899" notes="Was the safety card completed accordingly for the task being performed?"></span></label>
							<div class="form-check custom-radio  no-radio pl-0" id='was_5pt_card_completed'>
								<input type="radio" class="form-check-input" id="was_5pt_card_completed_yes" name="was_5pt_card_completed" value="1" required>
								<label class="form-check-label mr-2" for="was_5pt_card_completed_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="was_5pt_card_completed_no" name="was_5pt_card_completed" value="0">
								<label class="form-check-label mr-2" for="was_5pt_card_completed_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="was_5pt_card_completed_na" name="was_5pt_card_completed" value="-1">
								<label class="form-check-label mr-2" for="was_5pt_card_completed_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>

							</div>
						</div>
						<div class='cond-form-check-area'> 
							<div class="md-form">
								<textarea name="why_no_1" id="why_no_1" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="why_no_1"><span class='translate' data-i18n="1733" notes="If no, explain why."></span></label>
							</div>
						</div>
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="888" notes="Was a statement gathered from the worker involved?"></span></label>
							<div class="form-check custom-radio no-radio pl-0" id='was_statement_gathered'>
								<input type="radio" class="form-check-input" id="was_statement_gathered_yes" name="was_statement_gathered" value="1" required>
								<label class="form-check-label mr-2" for="was_statement_gathered_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="was_statement_gathered_no" name="was_statement_gathered" value="0">
								<label class="form-check-label mr-2" for="was_statement_gathered_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="was_statement_gathered_na" name="was_statement_gathered" value="-1">
								<label class="form-check-label mr-2" for="was_statement_gathered_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>

							</div>
						</div>
						<div class='cond-form-check-area'> 
							<div class="md-form">
								<textarea name="why_no_2" id="why_no_2" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="why_no_2"><span class='translate' data-i18n="1733" notes="If no, explain why."></span></label>
							</div>
						</div>
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="902" notes="Was the task being performed routine?"></span></label>
							<div class="form-check custom-radio no-radio pl-0" id='was_task_routine'>
								<input type="radio" class="form-check-input" id="was_task_routine_yes" name="was_task_routine" value="1" required>
								<label class="form-check-label mr-2" for="was_task_routine_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="was_task_routine_no" name="was_task_routine" value="0">
								<label class="form-check-label mr-2" for="was_task_routine_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="was_task_routine_na" name="was_task_routine" value="-1">
								<label class="form-check-label mr-2" for="was_task_routine_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>

							</div>
						</div>
						<div class='cond-form-check-area'> 
							<div class="md-form">
								<textarea name="why_no_3" id="why_no_3" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="why_no_3"><span class='translate' data-i18n="1733" notes="If no, explain why."></span></label>
							</div>
						</div>
						<div class="md-form">
							<textarea name="describe_task_preformed" id="describe_task_preformed" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="describe_task_preformed"><span class='translate' data-i18n="138" notes="Describe the task being performed"></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="task_planned_or_changed" id="task_planned_or_changed" class="select-single" required>
								<option class="translate trans_input" value="2857" data-i18n="2857" notes="Planned"></option>
								<option class="translate trans_input" value="3756" data-i18n="3756" notes="Change in line-up"></option>
								<option class="translate trans_input" value="688" data-i18n="688" notes="Other"></option>
							</select>
							<label for="task_planned_or_changed"><span class='translate' data-i18n="1729" notes="Was the task being performed planned?"></span></label>
						</div>

						<div class="md-form">
							<textarea name="what_qualifications_required" id="what_qualifications_required" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="what_qualifications_required" class="pr-5"><span class='translate' data-i18n="927" notes="What specific training qualifications were required?"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="897" notes="Was the involved qualified for the task?"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="was_involved_qualified_yes" name="was_involved_qualified" value="1" required>
								<label class="form-check-label mr-2" for="was_involved_qualified_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="was_involved_qualified_no" name="was_involved_qualified" value="0">
								<label class="form-check-label mr-2" for="was_involved_qualified_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="was_involved_qualified_na" name="was_involved_qualified" value="-1">
								<label class="form-check-label mr-2" for="was_involved_qualified_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>

							</div>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="who_witnessed" id="who_witnessed" class="select-single mobile-employee-select-single">
							</select>
							<label for="who_witnessed"><span class='translate' data-i18n="932" notes="Who witnessed the incident?"></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
						<select name="who_witnessed_position" id="who_witnessed_position" class="select-single mobile-employeeposition-select" single >
							</select>
							<label for="who_witnessed_position"><span class='translate' data-i18n='1277' notes = 'Position'></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="Others_witnessed" id="Others_witnessed" class="form-control" length="200" maxlength="200">
							<label for="Others_witnessed"><span class='translate' data-i18n="1731" notes="Other witnesses"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="1732" notes="Was a statement gathered from the incident witness(es)?"></span></label>
							<div class="form-check custom-radio no-radio pl-0">
								<input type="radio" class="form-check-input" id="was_statement_gathered_from_witness_yes" name="was_statement_gathered_from_witness" value="1" required>
								<label class="form-check-label mr-2" for="was_statement_gathered_from_witness_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="was_statement_gathered_from_witness_no" name="was_statement_gathered_from_witness" value="0">
								<label class="form-check-label mr-2" for="was_statement_gathered_from_witness_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="was_statement_gathered_from_witness_na" name="was_statement_gathered_from_witness" value="-1">
								<label class="form-check-label mr-2" for="was_statement_gathered_from_witness_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>

							</div>
						</div>
						<div class='cond-form-check-area'> 
							<div class="md-form">
								<textarea name="why_no_4" id="why_no_4" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="why_no_4"><span class='translate' data-i18n="1733" notes="If no, explain why."></span></label>
							</div>
						</div>
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1734" notes="Investigation Summary - Workplace Conditions"></span></h6>
          
						<div class="md-form">
							<input type="text" name="equipment_tooling_involved" id="equipment_tooling_involved" class="form-control" length="200" maxlength="200">
							<label for="equipment_tooling_involved"><span class='translate' data-i18n="131" notes="Describe equipment and/or tooling involved"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="equipment_make_mode_unit_number" id="equipment_make_mode_unit_number" class="form-control" length="200" maxlength="200">
							<label for="equipment_make_mode_unit_number"><span class='translate' data-i18n="146" notes="Detail equipment make, model & unit number"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="tooling_make_model_unit_number" id="tooling_make_model_unit_number" class="form-control" length="200" maxlength="200">
							<label for="tooling_make_model_unit_number"><span class='translate' data-i18n="151" notes="Detail tooling make, model & unit number"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="safety_device_condition" id="safety_device_condition" class="form-control" length="200" maxlength="200">
							<label for="safety_device_condition"><span class='translate' data-i18n="148" notes="Detail safety devices involved & condition"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="ppe_involved_condition" id="ppe_involved_condition" class="form-control" length="200" maxlength="200">
							<label for="ppe_involved_condition"><span class='translate' data-i18n="1735" notes="Detail P.P.E. involved and condition"></span></label>
						</div>

						<div class="md-form">
							<textarea name="worksite_details_layout" id="worksite_details_layout" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="worksite_details_layout"><span class='translate' data-i18n="142" notes="Describe worksite details and layout"></span></label>
						</div>

                        <div class="form-group photoImage" id="workplace_conditions_photos"> 
							<label class="d-block"><span class='translate' data-i18n="1413" notes="Include Photos"></span></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="Add Images"></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
							<div class="row photoGallery" id="galleryid"></div>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1736" notes="Investigation Summary - Environment"></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="detail_climate" id="detail_climate" class="select-single mobile-climate-select" required>
							</select>
							<label for="detail_climate"><span class='translate' data-i18n="1737" notes="Climate conditions"></span></label>
						</div>
						
						<div class="pt-1 position-relative my-4">
							<select name="detail_temperature" id="detail_temperature" class="select-single mobile-temperature-select">
							</select>
							<label for="detail_temperature"><span class='translate' data-i18n="150" notes="Detail the temperature"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="describe_overhead_conditions" id="describe_overhead_conditions" class="form-control" length="200" maxlength="200" required>
							<label for="describe_overhead_conditions"><span class='translate' data-i18n="132" notes="Describe overhead conditions"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="describe_underfoot_conditions" id="describe_underfoot_conditions" class="form-control" length="200" maxlength="200">
							<label for="describe_underfoot_conditions"><span class='translate' data-i18n="1738" notes="Describe underfoot conditions"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="describe_lighting_conditions" id="describe_lighting_conditions" class="form-control" length="200" maxlength="200">
							<label for="describe_lighting_conditions"><span class='translate' data-i18n="1739" notes="Describe lighting conditions"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="describe_environmental_noise" id="describe_environmental_noise" class="form-control" length="200" maxlength="200">
							<label for="describe_environmental_noise"><span class='translate' data-i18n="135" notes="Describe the environmental noise"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="describe_environmental_ergonomics" id="describe_environmental_ergonomics" class="form-control" length="200" maxlength="200">
							<label for="describe_environmental_ergonomics"><span class='translate' data-i18n="134" notes="Describe the environmental ergonomics"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="describe_access_workplace" id="describe_access_workplace" class="form-control" length="200" maxlength="200">
							<label for="describe_access_workplace"><span class='translate' data-i18n="133" notes="Describe the access to the workplace"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="describe_workplace_housekeeping" id="describe_workplace_housekeeping" class="form-control" length="200" maxlength="200">
							<label for="describe_workplace_housekeeping"><span class='translate' data-i18n="141" notes="Describe the workplace housekeeping"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1740" notes="Investigation Summary - General Comments"></span></h6>

						<div class="md-form">
							<textarea name="other_comments_notes" id="other_comments_notes" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="other_comments_notes"><span class='translate' data-i18n="696" notes="Other comments & notes"></span></label>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag="1002" class = "trans_input" value="1002" note="PRELIMINARY INVESTIGATION" />
						<input type="hidden" name="formtype" id="formtype" value="HI" />
						<input type="hidden" name="formid" id="formid" value="220234" />
						<input type="hidden" name="version" id="version" value="28" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
						<input type="hidden" name="incident_id" id="incident_id"  value=""/>
						<input type="hidden" name="formmisc" id="formmisc"  value=""/>
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}	
	}
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>