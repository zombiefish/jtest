<?php	
  $strPageTitle = 'VFL Audit';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>
<input type="hidden" value = "<?php	echo(_RESOURCEDOMAIN);?>"/>
<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
						<h6 class="text-secondary"><span class='translate' data-i18n="1005" notes="VFL Audit"></span></h6>
						<div class="pt-1 position-relative my-4">
							<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
							</select>
							<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
						</div>

						<form name="vfl_audit" id="vfl_audit" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>
						
						<div class="pt-1 position-relative my-4">
							<select name="audit_type" id="audit_type" class="select-single mobile-audittype-select" required>
							</select>
							<label for="audit_type"><span class='translate' data-i18n="883" notes="Type of Audit"></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="with_supervisor" id="with_supervisor" class="select-single mobile-supervisors-select" required>
							</select>
							<label for="with_supervisor"><span class='translate' data-i18n="844" notes="Supervisor"></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="hazard_topic" id="hazard_topic" class="select-single mobile-hazardtopic-select" required>
							</select>
							<label for="hazard_topic"><span class='translate' data-i18n="836" notes="Specific Hazard Topic"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="892" notes="Was Pre-audit Meeting Held?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="pre_audit_meeting_held_yes" name="pre_audit_meeting_held" value="1" required>
								<label class="form-check-label mr-2" for="pre_audit_meeting_held_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="pre_audit_meeting_held_no" name="pre_audit_meeting_held" value="0">
								<label class="form-check-label mr-2" for="pre_audit_meeting_held_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="891" notes="Was Post-audit Meeting Held?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="post_audit_meeting_held_yes" name="post_audit_meeting_held" value="1" required>
								<label class="form-check-label mr-2" for="post_audit_meeting_held_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="post_audit_meeting_held_no" name="post_audit_meeting_held" value="0">
								<label class="form-check-label mr-2" for="post_audit_meeting_held_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<canvas id="canvas" style='display:none;'></canvas>
						
						<div class="md-form">
							<textarea name="area_visited" id="area_visited" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="area_visited"><span class='translate' data-i18n="52" notes="Area Visited"></span></label>
						</div>

						<div class="md-form">
							<textarea name="general_comments" id="general_comments" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="general_comments"><span class='translate' data-i18n="485" notes="General Comments"></span></label>
						</div>

						<div class="md-form">
							<textarea name="observations" id="observations" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="observations"><span class='translate' data-i18n="663" notes="Observations"></span></label>
						</div>

						<div class="md-form">
							<textarea name="worker_interaction" id="worker_interaction" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="worker_interaction"><span class='translate' data-i18n="1554" notes="Worker Interactions"></span></label>
						</div>
						
						<div class="pt-1 position-relative my-4">
							<select name="employees_contacted" id="employees_contacted" class="select-multiple mobile-employee-select" multiple required>
							</select>
							<label for="employees_contacted"><span class='translate' data-i18n="420" notes="Employees Contacted"></label>
						</div>
						
            			<div class="form-group photoImage" id="multiphoto_picker_1"> 
							<label class="d-block"><span class='translate' data-i18n="1413" notes="Include Photos"></span></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i><span class='translate' data-i18n="2340" notes="Add Images"></span> 
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
							<div class="row photoGallery" id="galleryid"></div>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag = "1005" class = "trans_input" value="1005" tag="VFL Audit" />
						<input type="hidden" name="formtype" id="formtype" value="HR" />
						<input type="hidden" name="formid" id="formid" value="138900" />
						<input type="hidden" name="version" id="version" value="40" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="with_supervisor" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript">

	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
			
			return true;

		}	
	}
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>