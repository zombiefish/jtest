<?php	
  $strPageTitle = 'PPE Audit';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary"><span class='translate' data-i18n="1029" notes="PPE Audit"></span></h6>
          <div class="pt-1 position-relative my-4">
            <select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
            </select>
            <label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
          </div>

          <form name="formPPEAudit" id="formPPEAudit" class="needs-validation" method="GET" action="#" novalidate>
          
						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1681" notes="PPE Standard"></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="employee" id="employee" class="select-single mobile-employee-select-single" required>
							</select>
							<label for="investigator_1"><span class='translate' data-i18n="190" notes="Employee"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="492" notes="Hard Hat"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="hard_hat_good" name="hard_hat" value="1643" required>
								<label class="form-check-label mr-2" for="hard_hat_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="hard_hat_action" name="hard_hat" value="1644">
								<label class="form-check-label mr-2" for="hard_hat_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="hard_hat_na" name="hard_hat" value="1381">
								<label class="form-check-label mr-2" for="hard_hat_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>

							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="hard_hat_comment" id="hard_hat_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="hard_hat_comment"><span class='translate' data-i18n="493" notes="Hard Hat Comment"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="494" notes="Hard Hat Reflective Striping"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="hard_hat_reflective_striping_good" name="hard_hat_reflective_striping" value="1643" required>
								<label class="form-check-label mr-2" for="hard_hat_reflective_striping_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="hard_hat_reflective_striping_action" name="hard_hat_reflective_striping" value="1644">
								<label class="form-check-label mr-2" for="hard_hat_reflective_striping_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="hard_hat_reflective_striping_na" name="hard_hat_reflective_striping" value="1381">
								<label class="form-check-label mr-2" for="hard_hat_reflective_striping_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>

							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="hard_hat_reflective_striping_comment" id="hard_hat_reflective_striping_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="hard_hat_reflective_striping_comment"><span class='translate' data-i18n="495" notes="Hard Hat Reflective Striping Comment"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="1682" notes="Worker Name on Hard Hat"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="worker_name_on_hat_good" name="worker_name_on_hat" value="1643" required>
								<label class="form-check-label mr-2" for="worker_name_on_hat_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="worker_name_on_hat_action" name="worker_name_on_hat" value="1644">
								<label class="form-check-label mr-2" for="worker_name_on_hat_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="worker_name_on_hat_na" name="worker_name_on_hat" value="1381">
								<label class="form-check-label mr-2" for="worker_name_on_hat_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="worker_name_on_hat_comment" id="worker_name_on_hat_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="worker_name_on_hat_comment"><span class='translate' data-i18n='3757' notes='Worker Name on Hard Hat Comment'></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="1683" notes="Ear Muffs"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="ear_muffs_good" name="ear_muffs" value="1643" required>
								<label class="form-check-label mr-2" for="ear_muffs_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="ear_muffs_action" name="ear_muffs" value="1644">
								<label class="form-check-label mr-2" for="ear_muffs_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="ear_muffs_na" name="ear_muffs" value="1381">
								<label class="form-check-label mr-2" for="ear_muffs_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="ear_muff_comment" id="ear_muff_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="ear_muff_comment"><span class='translate' data-i18n="188" notes="Ear Muffs Comment"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="519" notes="Hot Dots"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="hot_dots_good" name="hot_dots" value="1643" required>
								<label class="form-check-label mr-2" for="hot_dots_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="hot_dots_action" name="hot_dots" value="1644">
								<label class="form-check-label mr-2" for="hot_dots_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="hot_dots_na" name="hot_dots" value="1381">
								<label class="form-check-label mr-2" for="hot_dots_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="hot_dot_comment" id="hot_dot_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="hot_dot_comment"><span class='translate' data-i18n="520" notes="Hot Dots Comment"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="808" notes="Safety Glasses Compliant with Fitted Eye Wear Program"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="glasses_good" name="glasses" value="1643" required>
								<label class="form-check-label mr-2" for="glasses_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="glasses_action" name="glasses" value="1644">
								<label class="form-check-label mr-2" for="glasses_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="glasses_na" name="glasses" value="1381">
								<label class="form-check-label mr-2" for="glasses_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="glasses_comment" id="glasses_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="glasses_comment"><span class='translate' data-i18n="488" notes="Glasses Comment"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="1684" notes="Coveralls and Striping"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="coveralls_striping_good" name="coveralls_striping" value="1643" required>
								<label class="form-check-label mr-2" for="coveralls_striping_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="coveralls_striping_action" name="coveralls_striping" value="1644">
								<label class="form-check-label mr-2" for="coveralls_striping_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="coveralls_striping_na" name="coveralls_striping" value="1381">
								<label class="form-check-label mr-2" for="coveralls_striping_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="coveralls_stripping_comment" id="coveralls_stripping_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="coveralls_stripping_comment"><span class='translate' data-i18n='3758' notes='Coveralls and Striping Comment'></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="1685" notes="Miners Belt"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="miners_belt_good" name="miners_belt" value="1643" required>
								<label class="form-check-label mr-2" for="miners_belt_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="miners_belt_action" name="miners_belt" value="1644">
								<label class="form-check-label mr-2" for="miners_belt_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="miners_belt_na" name="miners_belt" value="1381">
								<label class="form-check-label mr-2" for="miners_belt_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="miner_belt_comment" id="miner_belt_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="miner_belt_comment"><span class='translate' data-i18n='3759' notes='Miners Belt Comment'></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="490" notes="Gloves"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="gloves_good" name="gloves" value="1643" required>
								<label class="form-check-label mr-2" for="gloves_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="gloves_action" name="gloves" value="1644">
								<label class="form-check-label mr-2" for="gloves_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="gloves_na" name="gloves" value="1381">
								<label class="form-check-label mr-2" for="gloves_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="glove_comment" id="glove_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="glove_comment"><span class='translate' data-i18n="491" notes="Gloves Comment"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="69" notes="Boots"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="boots_good" name="boots" value="1643" required>
								<label class="form-check-label mr-2" for="boots_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="boots_action" name="boots" value="1644">
								<label class="form-check-label mr-2" for="boots_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="boots_na" name="boots" value="1381">
								<label class="form-check-label mr-2" for="boots_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="boot_comment" id="boot_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="boot_comment"><span class='translate' data-i18n='3760' notes='Boots Comment'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1686" notes="PPE Specialty"></span></h6>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="482" notes="Full Body Harness"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="full_body_harness_good" name="full_body_harness" value="1643" required>
								<label class="form-check-label mr-2" for="full_body_harness_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="full_body_harness_action" name="full_body_harness" value="1644">
								<label class="form-check-label mr-2" for="full_body_harness_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="full_body_harness_na" name="full_body_harness" value="1381">
								<label class="form-check-label mr-2" for="full_body_harness_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="body_harness_comment" id="body_harness_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="body_harness_comment"><span class='translate' data-i18n='3761' notes='Body Harness Comment'></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="1687" notes="Half Mask"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="half_mask_good" name="half_mask" value="1643" required>
								<label class="form-check-label mr-2" for="half_mask_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="half_mask_action" name="half_mask" value="1644">
								<label class="form-check-label mr-2" for="half_mask_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="half_mask_na" name="half_mask" value="1381">
								<label class="form-check-label mr-2" for="half_mask_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="half_mask_comment" id="half_mask_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="half_mask_comment"><span class='translate' data-i18n='3762' notes='Half Mask Comment'></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="523" notes="Hot Work PPE"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="hot_work_ppe_good" name="hot_work_ppe" value="1643" required>
								<label class="form-check-label mr-2" for="hot_work_ppe_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="hot_work_ppe_action" name="hot_work_ppe" value="1644">
								<label class="form-check-label mr-2" for="hot_work_ppe_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="hot_work_ppe_na" name="hot_work_ppe" value="1381">
								<label class="form-check-label mr-2" for="hot_work_ppe_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="hot_work_comment" id="hot_work_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="hot_work_comment"><span class='translate' data-i18n='3763' notes='Hot Work Comment'></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="678" notes="Oilers"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="oilers_good" name="oilers" value="1643" required>
								<label class="form-check-label mr-2" for="oilers_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="oilers_action" name="oilers" value="1644">
								<label class="form-check-label mr-2" for="oilers_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="oilers_na" name="oilers" value="1381">
								<label class="form-check-label mr-2" for="oilers_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="oiler_comment" id="oiler_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="oiler_comment"><span class='translate' data-i18n="679" notes="Oilers Comment"></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="1688" notes="Medium Voltage Arc Flash Kit"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="mvaFlashKit_good" name="mvaFlashKit" value="1643" required>
								<label class="form-check-label mr-2" for="mvaFlashKit_good"><span class='translate' data-i18n="1643" notes="Good"></span></label>

								<input type="radio" class="form-check-input trans_input" id="mvaFlashKit_action" name="mvaFlashKit" value="1644">
								<label class="form-check-label mr-2" for="mvaFlashKit_action"><span class='translate' data-i18n="1644" notes="Action Required"></span></label>

								<input type="radio" class="form-check-input trans_input" id="mvaFlashKit_na" name="mvaFlashKit" value="1381">
								<label class="form-check-label mr-2" for="mvaFlashKit_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="md-form cond-form-check-area">
							<textarea name="mvaFlashKit_comment" id="mvaFlashKit_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="mvaFlashKit_comment"><span class='translate' data-i18n='3764' notes='Medium Voltage Arc Flash Kit Comment'></span></label>
						</div>						

						<div class="md-form">
							<textarea name="other" id="other" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="other"><span class='translate' data-i18n="1689" notes="Other Comment"></span></label>
						</div>

					    <div class="form-group photoImage" id="ppe_pictures"> 
							<label class="d-block"><span class='translate' data-i18n="1691" notes="Take Pictures"></span></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="Add Images"></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
								<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
								<div class="row photoGallery" id="galleryid"></div>
						</div>
						
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1690" notes="General Comment"></span></h6>
						<div class="md-form">
							<textarea name="general_comment" id="general_comment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="general_comment"><span class='translate' data-i18n="1690" notes="General Comment"></span></label>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" note="PPE AUDIT" class = "trans_input" value="1029" tag="1029"/>
						<input type="hidden" name="formtype" id="formtype" value="SC" />
						<input type="hidden" name="formid" id="formid" value="131106"/>
						<input type="hidden" name="version" id="version" value="63" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>


<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}	
	}
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
<script>
$("input:radio.form-check-input").change((data)=>{
	if(data.target.value !== i18next.t("1644"))
	    data.target.parentNode.parentNode.nextElementSibling.firstChild.nextElementSibling.value = ''
})
// $(document).ready(function() {
// 	setTimeout(()=>{
// 		const checkButtons = document.getElementsByClassName(`custom-radio`)
// 	for (let a = 0; a < checkButtons.length; a++) {
// 		let fieldName = checkButtons[a].firstChild.nextElementSibling.getAttribute('name')
// 		if($(`input[type=radio][name=${fieldName}]:checked`).val() === 'Action Required') {
// 			$(`input[type=radio][name=${fieldName}]`).parent().parent().nextAll(`.cond-form-check-area:first`).show()
// 		}
// 	}
// 	},100)
// })
</script>