<?php	
  $strPageTitle = 'Supervisor Lineup Audit';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary"><span class='translate' data-i18n='1016' notes='Supervisor Lineup Audit'></span></h6>

          <div class="pt-1 position-relative my-4">
            <select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
            </select>
            <label for="draft"><span class='translate' data-i18n='1474' notes='Form Drafts'></span></label>
          </div>

          <form name="formSupervisorLinUpAudit" id="formSupervisorLinUpAudit" class="needs-validation" method="POST" action="#" novalidate>
          
						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='993' notes='Line Up'></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="auditor" id="auditor" class="select-single mobile-supervisors-select" tag="62"  required>
							</select>
							<label for="auditor"><span class='translate' data-i18n='62' notes='Auditor'></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1631' notes='Clear and Informative instruction'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="clear_and_informative_communication_yes" name="clear_and_informative_communication" value="1" required>
								<label class="form-check-label mr-2" for="clear_and_informative_communication_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="clear_and_informative_communication_no" name="clear_and_informative_communication" value="0">
								<label class="form-check-label mr-2" for="clear_and_informative_communication_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="clear_and_informative_communication_na" name="clear_and_informative_communication" value="-1">
								<label class="form-check-label mr-2" for="clear_and_informative_communication_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>
					
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1632' notes='All personel have had a chance to interact'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="personel_have_had_a_chance_to_interact_yes" name="personel_have_had_a_chance_to_interact" value="1" required>
								<label class="form-check-label mr-2" for="personel_have_had_a_chance_to_interact_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="personel_have_had_a_chance_to_interact_no" name="personel_have_had_a_chance_to_interact" value="0">
								<label class="form-check-label mr-2" for="personel_have_had_a_chance_to_interact_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="personel_have_had_a_chance_to_interact_na" name="personel_have_had_a_chance_to_interact" value="-1">
								<label class="form-check-label mr-2" for="personel_have_had_a_chance_to_interact_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1633' notes='Clear equipment directive'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="clear_equipment_directives_yes" name="clear_equipment_directives" value="1" required>
								<label class="form-check-label mr-2" for="clear_equipment_directives_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="clear_equipment_directives_no" name="clear_equipment_directives" value="0">
								<label class="form-check-label mr-2" for="clear_equipment_directives_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="clear_equipment_directives_na" name="clear_equipment_directives" value="-1">
								<label class="form-check-label mr-2" for="clear_equipment_directives_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1634' notes='Safety topic discussed'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="safety_topic_discussed_yes" name="safety_topic_discussed" value="1" required>
								<label class="form-check-label mr-2" for="safety_topic_discussed_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="safety_topic_discussed_no" name="safety_topic_discussed" value="0">
								<label class="form-check-label mr-2" for="safety_topic_discussed_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="safety_topic_discussed_na" name="safety_topic_discussed" value="-1">
								<label class="form-check-label mr-2" for="safety_topic_discussed_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='972' notes='Workplace specific hazards discussed?'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="workplace_hazards_discussed_yes" name="workplace_hazards_discussed" value="1" required>
								<label class="form-check-label mr-2" for="workplace_hazards_discussed_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="workplace_hazards_discussed_no" name="workplace_hazards_discussed" value="0">
								<label class="form-check-label mr-2" for="workplace_hazards_discussed_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="workplace_hazards_discussed_na" name="workplace_hazards_discussed" value="-1">
								<label class="form-check-label mr-2" for="workplace_hazards_discussed_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1635' notes='Professional and Positive Attitude'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="professional_and_positive_attitude_yes" name="professional_and_positive_attitude" value="1" required>
								<label class="form-check-label mr-2" for="professional_and_positive_attitude_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="professional_and_positive_attitude_no" name="professional_and_positive_attitude" value="0">
								<label class="form-check-label mr-2" for="professional_and_positive_attitude_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="professional_and_positive_attitude_na" name="professional_and_positive_attitude" value="-1">
								<label class="form-check-label mr-2" for="professional_and_positive_attitude_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='737' notes='Personal experience and knowledge shared?'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="personal_experience_and_knowledge_shared_yes" name="personal_experience_and_knowledge_shared" value="1" required>
								<label class="form-check-label mr-2" for="personal_experience_and_knowledge_shared_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="personal_experience_and_knowledge_shared_no" name="personal_experience_and_knowledge_shared" value="0">
								<label class="form-check-label mr-2" for="personal_experience_and_knowledge_shared_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="personal_experience_and_knowledge_shared_na" name="personal_experience_and_knowledge_shared" value="-1">
								<label class="form-check-label mr-2" for="personal_experience_and_knowledge_shared_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1636' notes='Recent incidents discussed'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="recent_incidents_discussed_yes" name="recent_incidents_discussed" value="1" required>
								<label class="form-check-label mr-2" for="recent_incidents_discussed_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="recent_incidents_discussed_no" name="recent_incidents_discussed" value="0">
								<label class="form-check-label mr-2" for="recent_incidents_discussed_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="recent_incidents_discussed_na" name="recent_incidents_discussed" value="-1">
								<label class="form-check-label mr-2" for="recent_incidents_discussed_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1637' notes='Site activities discussed'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="site_activities_discussed_yes" name="site_activities_discussed" value="1" required>
								<label class="form-check-label mr-2" for="site_activities_discussed_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="site_activities_discussed_no" name="site_activities_discussed" value="0">
								<label class="form-check-label mr-2" for="site_activities_discussed_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="site_activities_discussed_na" name="site_activities_discussed" value="-1">
								<label class="form-check-label mr-2" for="site_activities_discussed_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='957' notes='Workers are engaged and the tone is right?'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="workers_are_engaged_right_yes" name="workers_are_engaged_right" value="1" required>
								<label class="form-check-label mr-2" for="workers_are_engaged_right_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="workers_are_engaged_right_no" name="workers_are_engaged_right" value="0">
								<label class="form-check-label mr-2" for="workers_are_engaged_right_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="workers_are_engaged_right_na" name="workers_are_engaged_right" value="-1">
								<label class="form-check-label mr-2" for="workers_are_engaged_right_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>
					
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='970' notes='Workplace scheduling conflicts discussed?'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="workplace_scheduling_conflicts_discussed_yes" name="workplace_scheduling_conflicts_discussed" value="1" required>
								<label class="form-check-label mr-2" for="workplace_scheduling_conflicts_discussed_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="workplace_scheduling_conflicts_discussed_no" name="workplace_scheduling_conflicts_discussed" value="0">
								<label class="form-check-label mr-2" for="workplace_scheduling_conflicts_discussed_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="workplace_scheduling_conflicts_discussed_na" name="workplace_scheduling_conflicts_discussed" value="-1">
								<label class="form-check-label mr-2" for="workplace_scheduling_conflicts_discussed_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>
					
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='158' notes='Did the supervisor assess the work for the requirement of a JHA?'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="asses_for_jha_yes" name="asses_for_jha" value="1" required>
								<label class="form-check-label mr-2" for="asses_for_jha_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="asses_for_jha_no" name="asses_for_jha" value="0">
								<label class="form-check-label mr-2" for="asses_for_jha_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="asses_for_jha_na" name="asses_for_jha" value="-1">
								<label class="form-check-label mr-2" for="asses_for_jha_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>
					
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1638' notes='Did the supervisor assess the work for the requirement of a Procedure'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="asses_for_precedure_yes" name="asses_for_precedure" value="1" required>
								<label class="form-check-label mr-2" for="asses_for_precedure_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="asses_for_precedure_no" name="asses_for_precedure" value="0">
								<label class="form-check-label mr-2" for="asses_for_precedure_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="asses_for_precedure_na" name="asses_for_precedure" value="-1">
								<label class="form-check-label mr-2" for="asses_for_precedure_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>
					
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1639' notes='Did the supervisor check with the employee(s) for experience and qualifications pertaining to the work'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="check_for_qualifications_yes" name="check_for_qualifications" value="1" required>
								<label class="form-check-label mr-2" for="check_for_qualifications_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="check_for_qualifications_no" name="check_for_qualifications" value="0">
								<label class="form-check-label mr-2" for="check_for_qualifications_no"><span class='translate' data-i18n='1380' notes='No'></span></label>

								<input type="radio" class="form-check-input" id="check_for_qualifications_na" name="check_for_qualifications" value="-1">
								<label class="form-check-label mr-2" for="check_for_qualifications_na"><span class='translate' data-i18n='1381' notes='N/A'></span></label>
							</div>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="duration" id="duration" class="select-single mobile-duration-select" required>
							</select>
							<label for="duration"><span class='translate' data-i18n='186' notes='Duration of Line Up'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='81' notes='Comments'></span></h6>
						<div class="md-form">
							<textarea name="sts_feedback" id="sts_feedback" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="sts_feedback"><span class='translate' data-i18n='840' notes='STS Feedback'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1601' notes='Correction and Action Requirements'></span></h6>
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='915' notes='Were any areas of improvement identified?'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input radio-check" id="any_areas_of_improvement_identified_yes" name="any_areas_of_improvement_identified" value="1" required>
								<label class="form-check-label mr-2" for="any_areas_of_improvement_identified_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input radio-check" id="any_areas_of_improvement_identified_no" name="any_areas_of_improvement_identified" value="0">
								<label class="form-check-label mr-2" for="any_areas_of_improvement_identified_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<canvas id="canvas" style='display:none;'></canvas>
<div class='cond-form-check-area'> 		

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1602' notes='Is a follow up required with the employee'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="follow_up_with_the_employee_yes" name="follow_up_with_the_employee" value="1" required>
								<label class="form-check-label mr-2" for="follow_up_with_the_employee_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="follow_up_with_the_employee_no" name="follow_up_with_the_employee" value="0">
								<label class="form-check-label mr-2" for="follow_up_with_the_employee_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1603' notes='Is a follow up required with the task'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="follow_up_with_the_task_yes" name="follow_up_with_the_task" value="1" required>
								<label class="form-check-label mr-2" for="follow_up_with_the_task_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="follow_up_with_the_task_no" name="follow_up_with_the_task" value="0">
								<label class="form-check-label mr-2" for="follow_up_with_the_task_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>
</div>
						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag = "1016" class = "trans_input" value="1016" note="SUPERVISOR LINE UP AUDIT" />
						<input type="hidden" name="formtype" id="formtype" value="MNG" />
						<input type="hidden" name="formid" id="formid" value="236760"/>
						<input type="hidden" name="version" id="version" value="19" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="auditor" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}	
	}

	function radioButtonCheck() {
		$('.radio-check').change((e) =>{
			requiredRadio(e.currentTarget.defaultValue)
		})
	};
	document.addEventListener('DOMContentLoaded', radioButtonCheck, false);
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>