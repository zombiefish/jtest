<?php	
    $strPageTitle = 'Meeting Minutes';
    include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
    include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
    include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
    include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
    ?>
<main class="col containter-fluid mobile-content">
    <div class="row">
    <div class="col-12 mb-4">
        <div class="card mb-4">
            <div class="card-body">
                <h6 class="text-secondary"><span class='translate' data-i18n="2452" notes="Meeting Minutes"></span></h6>
                <div class="pt-1 position-relative my-4">
                    <select name="draft" id="draft" class="select-single" onChange="getFormData(this)"  >
                    </select>
                    <label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
                </div>
                <form name="meeting_minutes" id="TemplateForm" class="needs-validation" method="POST" action="#"
                    novalidate>
                    <?php include 'includes/CommonFormHeader.php' ?>
                    <div class="pt-1 position-relative my-4">
                        <select name="attendees" id="attendees" class="select-multiple mobile-employee-select-other" onchange="toggleAttendeesOther()" multiple required>
                        </select>
                        <label for="attendees"><span class='translate' data-i18n="2453" notes="Attendees"></span></label>
                    </div>
                    <div id="attendees_other_item" class="md-form"  style="display:none">
                        <input type="text" name="attendees_other" id="attendees_other" length="200" maxlength="200" class="form-control"  >
                        </input>
                    </div>
                    <div class="pt-1 position-relative my-4">
                        <select name="stakeholders" id="stakeholders" class="select-multiple mobile-employee-select-other" onchange="toggleStakeholdersOther()" multiple required>
                        </select>
                        <label for="stakeholders"><span class='translate' data-i18n="1340" notes="Stakeholders"></span></label>
                    </div>
                    <div id="stakeholders_other_item"  class="md-form" style="display:none">
                        <input type="text" name="stakeholders_other" id="stakeholders_other" length="200" maxlength="200" class="form-control"  >
                        </input>
                    </div>
                    <div class="md-form">
                        <textarea name="share" id="share" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
                        <label for="share"><span class='translate' data-i18n="2454" notes="Share"></span></label>
                    </div>
                    <div class="md-form">
                        <textarea name="agenda" id="agenda" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
                        <label for="agenda"><span class='translate' data-i18n="2455" notes="Agenda"></span></label>
                    </div>
                    <div id="crews"></div>
                    <div id='addCrew' class='btn btn-sm btn-primary translate' data-i18n='[html]2459' notes='ADD DISCUSSION'><i class="fa fa-plus"></i>  </div> 
                    <div id='removeCrew' class='btn btn-sm btn-outline-primary'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n="2460" notes="REMOVE DISCUSSION GROUP"></span> </div>
                    <div><br />
                    </div>
                    <div class="form-group photoImage" id="meeting_pictures">
                        <label class="d-block"><span class='translate' data-i18n="741" notes="Pictures"></span></label>
                        <canvas id="canvas" style='display:none;'></canvas>
                        <div class="btn-group d-flex" role="group">
                            <div class="btn btn-block btn-outline-secondary file-field px-1">
                                <i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="Add Images"></span>
                                <input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
                            </div>
                        </div>
                        <div class="row photoGallery" id="galleryid"></div>
                    </div>
                    <?php include 'includes/CommonFormFooter.php' ?>
                    <input type="hidden" name="formname" id="formname" note="MEETING MINUTES" class = "trans_input" value="2452" tag="2452" />
                    <input type="hidden" name="formtype" id="formtype" value="SUP" />
                    <input type="hidden" name="formid" id="formid" value="372388" />
                    <input type="hidden" name="version" id="version" value="1" />
                    <input type="hidden" name="_rev" id="_rev" value="" />
                    <input type="hidden" name="_id" id="_id" value="" />
                    <input type="hidden" name="keyField" id="keyField" value="site|workplace" />
                    <input type="hidden" name="draftField" id="draftField" value="draft" />
                    <input type="hidden" name="numCrews" id="numCrews" value='1' />
                    <input type="hidden" name="totalCrews" id="totalCrews" value='30' />                        
                </form>
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    var formBody = {

        formInitialize: function (theForm) {
            if (debug) console.log('formBody.formInitialize() called.');
         },

        formTerminate: function (theForm) {
            if (debug) console.log('formBody.formTerminate() called.');
        },

        formValidate: function (theForm) {
            if (debug) console.log('formBody.formValidate() called.');
            return true;
        }
    }


    function toggleAttendeesOther(){


        let attendee = document.getElementById("attendees")
		let otherSelected = false;
		
		for(let c = 0;c < attendees.selectedOptions.length;c++){
			if(attendees.selectedOptions[c].value.toUpperCase() == 'OTHER'){
				otherSelected=true;
			}
		}
		if(otherSelected){
			let otherControls = document.getElementById("attendees_other_item")
			otherControls.style.display = "block"
			document.getElementById('attendees_other').removeAttribute("isrequired")
			document.getElementById('attendees_other').setAttribute("required",true)

		} else {
			let otherControls = document.getElementById("attendees_other_item")
			otherControls.style.display = "none"
			document.getElementById('attendees_other').removeAttribute("required")
			document.getElementById('attendees_other').setAttribute("isrequired","")

			// clear value of the text box.
			let otherControlsText = document.getElementById('attendees_other')
			otherControlsText.value = ""
		}



    }
    function toggleStakeholdersOther(){

        let stakeholders = document.getElementById("stakeholders")
		let otherSelected = false;
		
		for(let c = 0;c < stakeholders.selectedOptions.length;c++){
			if(stakeholders.selectedOptions[c].value.toUpperCase() == 'OTHER'){
				otherSelected=true;
			}
		}

		if(otherSelected){
			let otherControls = document.getElementById("stakeholders_other_item")
			otherControls.style.display = "block"
			document.getElementById('stakeholders_other').removeAttribute("isrequired")
			document.getElementById('stakeholders_other').setAttribute("required",true)

		} else {
			let otherControls = document.getElementById("stakeholders_other_item")
 
			otherControls.style.display = "none"
			document.getElementById('stakeholders_other').removeAttribute("required")
			document.getElementById('stakeholders_other').setAttribute("isrequired","")

			// clear value of the text box.
			let otherControlsText = document.getElementById('stakeholders_other')
			otherControlsText.value = ""
		}
    }
    
	$( document ).ready(function() {
		addCrew(1)
	});
	
    function addCrew(crewNum,mode){
		const crewsModal = 
		`<div class="crewsection" value=${crewNum}>
            <h6 class="text-secondary pt-4"><span class='translate text-secondary pt-4' data-i18n="2456" notes="Discussion"></span> ${crewNum}</h6>
            <div class="pt-1 position-relative my-4 md-form">
                <label for="discussion_${crewNum}"><span class='translate' data-i18n="2457" notes="Discussion Item"></span></label>
                <input type="text" name="discussion_${crewNum}" id="discussion_${crewNum}" length="200" maxlength="200" class="form-control" required></input>
            </div>
            <div class="pt-1 position-relative my-4">
                <select name="person_responsible_${crewNum}" id="person_responsible_${crewNum}" class="select-single mobile-employee-select-single" required>
                </select>
                <label for="person_responsible_${crewNum}"><span class='translate' data-i18n="2458" notes="Person Responsible"></span></label>
            </div>
            <div class="md-form">
                <textarea name="notes_${crewNum}" id="notes_${crewNum}" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
                <label for="notes_${crewNum}"><span class='translate' data-i18n="1296" notes="Notes"></span></label>
            </div>
        </div>`
		
		$("#crews").append(crewsModal);
        if(crewNum>1 && !mode){
            initializeSelect2Dynamic(`person_responsible_${crewNum}`)
			formHeader.populateEmployeeSelectSingle(`person_responsible_${crewNum}`)
            try {$('.translate').localize()} catch {}
        }
	}
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>