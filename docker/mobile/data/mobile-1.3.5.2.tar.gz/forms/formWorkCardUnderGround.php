

						<div class="mb-4">
							<label for="Access to Worksite"><strong><span class='translate' data-i18n='8495' notes='Access to Worksite'></span></strong></label>
						</div>

						<div class="mb-4">
							<label for="personal_safety_equipment"><span class='translate' data-i18n="8496" notes="Personal safety equipment"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_pse" name="personal_safety_equipment" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_pse"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_pse" name="personal_safety_equipment" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_pse"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_pse" name="personal_safety_equipment" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_pse"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_pse" name="personal_safety_equipment" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_pse"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_pse" id="comments_pse" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_pse"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="blasting_box" class="hide-show"><span class='translate' data-i18n="8497" notes="Blasting box, blasting line"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_bla" name="blasting_box" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_bla"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_bla" name="blasting_box" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_bla"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_bla" name="blasting_box" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_bla"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_bla" name="blasting_box" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_bla"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_bb" id="comments_bb" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_bb"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label for="scaling"><span class='translate' data-i18n="8498" notes="Scaling"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_scaling" name="scaling" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_scaling"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_scaling" name="scaling" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_scaling"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_scaling" name="scaling" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_scaling"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_scaling" name="scaling" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_scaling"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_sc" id="comments_sc" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_sc"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="ventilation_work_site"><span class='translate' data-i18n="8506" notes="Ventilation"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_ventilation_work_site" name="ventilation_work_site" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_ventilation_work_site"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_ventilation_work_site" name="ventilation_work_site" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_ventilation_work_site"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_ventilation_work_site" name="ventilation_work_site" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_ventilation_work_site"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_ventilation_work_site" name="ventilation_work_site" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_ventilation_work_site"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_ven" id="comments_ven" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_ven"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="open_holes"><span class='translate' data-i18n="8499" notes="Open holes, warning panels and signs"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_open_holes" name="open_holes" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_open_holes"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_open_holes" name="open_holes" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_open_holes"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_open_holes" name="open_holes" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_open_holes"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_open_holes" name="open_holes" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_open_holes"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_oh" id="comments_oh" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_oh"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="cleanliness_work_site"><span class='translate' data-i18n="8500" notes="Cleanliness, deposit, gallery"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_cleanliness_work_site" name="cleanliness_work_site" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_cleanliness_work_site"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_cleanliness_work_site" name="cleanliness_work_site" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_cleanliness_work_site"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_cleanliness_work_site" name="cleanliness_work_site" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_cleanliness_work_site"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_cleanliness_work_site" name="cleanliness_work_site" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_cleanliness_work_site"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_cle" id="comments_cle" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_cle"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="visibility"><span class='translate' data-i18n="8501" notes="Visibility versus mobile equipment (flashing light, clothing, detection system, etc.)"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_visibility" name="visibility" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_visibility"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_visibility" name="visibility" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_visibility"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_visibility" name="visibility" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_visibility"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_visibility" name="visibility" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_visibility"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_vis" id="comments_vis" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_vis"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label for="Work Area"><strong><span class='translate' data-i18n='8505' notes='Work Area'></span></strong></label>
						</div>
					
						<div class="mb-4">
							<label for="ventilation_work_area"><span class='translate' data-i18n="8506" notes="Ventilation"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_ventilation_work_area" name="ventilation_work_area" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_ventilation_work_area"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_ventilation_work_area" name="ventilation_work_area" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_ventilation_work_area"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_ventilation_work_area" name="ventilation_work_area" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_ventilation_work_area"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_ventilation_work_area" name="ventilation_work_area" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_ventilation_work_area"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_ven_area" id="comments_ven_area" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_ven_area"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="security_perimeter"><span class='translate' data-i18n="8507" notes="Security perimeter (tape, label, sign, barrier)"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_security_perimeter" name="security_perimeter" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_security_perimeter"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_security_perimeter" name="security_perimeter" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_security_perimeter"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_security_perimeter" name="security_perimeter" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_security_perimeter"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_security_perimeter" name="security_perimeter" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_security_perimeter"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_sec" id="comments_sec" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_sec"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="electric_wire"><span class='translate' data-i18n="8508" notes="Electric wire securely hooked"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_electric_wire" name="electric_wire" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_electric_wire"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_electric_wire" name="electric_wire" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_electric_wire"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_electric_wire" name="electric_wire" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_electric_wire"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_electric_wire" name="electric_wire" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_electric_wire"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_ele" id="comments_ele" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_ele"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="header_chain"><span class='translate' data-i18n="8509" notes="Header (chain 12 inches from the clams)"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_header_chain" name="header_chain" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_header_chain"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_header_chain" name="header_chain" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_header_chain"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_header_chain" name="header_chain" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_header_chain"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_header_chain" name="header_chain" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_header_chain"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_header" id="comments_header" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_header"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="hoses"><span class='translate' data-i18n="8510" notes="Air and water hoses"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_hoses" name="hoses" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_hoses"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_hoses" name="hoses" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_hoses"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_hoses" name="hoses" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_hoses"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_hoses" name="hoses" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_hoses"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_hose" id="comments_hose" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_hose"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="chipping"><span class='translate' data-i18n="8511" notes="Chipping (apply safety principles)"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_chipping" name="chipping" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_chipping"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_chipping" name="chipping" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_chipping"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_chipping" name="chipping" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_chipping"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_chipping" name="chipping" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_chipping"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_chip" id="comments_chip" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_chip"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="support_bolts"><span class='translate' data-i18n="8512" notes="Support: Bolts, Grids, etc."></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_support_bolts" name="support_bolts" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_support_bolts"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_support_bolts" name="support_bolts" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_support_bolts"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_support_bolts" name="support_bolts" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_support_bolts"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_support_bolts" name="support_bolts" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_support_bolts"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_sup" id="comments_sup" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_sup"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="racking_watering"><span class='translate' data-i18n="8513" notes="Racking (watering)"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_racking_watering" name="racking_watering" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_racking_watering"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_racking_watering" name="racking_watering" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_racking_watering"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_racking_watering" name="racking_watering" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_racking_watering"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_racking_watering" name="racking_watering" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_racking_watering"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_rac" id="comments_rac" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_rac"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="cleanliness_work_area"><span class='translate' data-i18n="8514" notes="Cleanliness in good order"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_cleanliness_work_area" name="cleanliness_work_area" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_cleanliness_work_area"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_cleanliness_work_area" name="cleanliness_work_area" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_cleanliness_work_area"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_cleanliness_work_area" name="cleanliness_work_area" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_cleanliness_work_area"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_cleanliness_work_area" name="cleanliness_work_area" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_cleanliness_work_area"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_cle_good" id="comments_cle_good" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_cle_good"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="drilling_face"><span class='translate' data-i18n="8515" notes="Drilling: Face and bottom of well washed and identified holes"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_drilling_face" name="drilling_face" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_drilling_face"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_drilling_face" name="drilling_face" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_drilling_face"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_drilling_face" name="drilling_face" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_drilling_face"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_drilling_face" name="drilling_face" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_drilling_face"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_drilling_face" id="comments_drilling_face" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_drilling_face"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="drilling_well"><span class='translate' data-i18n="8516" notes="Drilling: Well washed and identified floor holes"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_drilling_well" name="drilling_well" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_drilling_well"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_drilling_well" name="drilling_well" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_drilling_well"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_drilling_well" name="drilling_well" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_drilling_well"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_drilling_well" name="drilling_well" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_drilling_well"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_drilling_well" id="comments_drilling_well" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_drilling_well"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="drilling_copper"><span class='translate' data-i18n="8517" notes="Drilling: Copper pipe on site"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_drilling_copper" name="drilling_copper" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_drilling_copper"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_drilling_copper" name="drilling_copper" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_drilling_copper"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_drilling_copper" name="drilling_copper" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_drilling_copper"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_drilling_copper" name="drilling_copper" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_drilling_copper"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_drilling_pipe" id="comments_drilling_pipe" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_drilling_pipe"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="drilling_no_explosive"><span class='translate' data-i18n="8518" notes="Drilling: No explosives when drilling"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_drilling_no_explosive" name="drilling_no_explosive" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_drilling_no_explosive"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_drilling_no_explosive" name="drilling_no_explosive" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_drilling_no_explosive"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_drilling_no_explosive" name="drilling_no_explosive" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_drilling_no_explosive"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_drilling_no_explosive" name="drilling_no_explosive" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_drilling_no_explosive"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_drilling_no" id="comments_drilling_no" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_drilling_no"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="drilling_sounding"><span class='translate' data-i18n="8519" notes="Drilling: Sounding and purging during drilling"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_drilling_sounding" name="drilling_sounding" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_drilling_sounding"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_drilling_sounding" name="drilling_sounding" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_drilling_sounding"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_drilling_sounding" name="drilling_sounding" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_drilling_sounding"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_drilling_sounding" name="drilling_sounding" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_drilling_sounding"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_drilling_sounding" id="comments_drilling_sounding" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_drilling_sounding"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="drilling_person"><span class='translate' data-i18n="8520" notes="Drilling: Person in front of drilling equipment"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_drilling_person" name="drilling_person" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_drilling_person"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_drilling_person" name="drilling_person" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_drilling_person"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_drilling_person" name="drilling_person" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_drilling_person"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_drilling_person" name="drilling_person" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_drilling_person"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_drilling_per" id="comments_drilling_per" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_drilling_per"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="no_metal"><span class='translate' data-i18n="8521" notes="No metal in contact with explosives"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_no_metal" name="no_metal" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_no_metal"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_no_metal" name="no_metal" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_no_metal"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_no_metal" name="no_metal" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_no_metal"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_no_metal" name="no_metal" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_no_metal"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_no_metal" id="comments_no_metal" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_no_metal"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="zero_energy"><span class='translate' data-i18n="8522" notes="Zero energy"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_zero_energy" name="zero_energy" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_zero_energy"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_zero_energy" name="zero_energy" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_zero_energy"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_zero_energy" name="zero_energy" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_zero_energy"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_zero_energy" name="zero_energy" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_zero_energy"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_zero" id="comments_zero" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_zero"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="mechanical_inspection"><span class='translate' data-i18n="8523" notes="Mechanical inspection (verification card)"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_mechanical_inspection" name="mechanical_inspection" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_mechanical_inspection"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_mechanical_inspection" name="mechanical_inspection" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_mechanical_inspection"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_mechanical_inspection" name="mechanical_inspection" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_mechanical_inspection"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_mechanical_inspection" name="mechanical_inspection" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_mechanical_inspection"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>
							
							<div class="md-form d-none">
								<textarea name="comments_mech" id="comments_mech" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_mech"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>
						
						<div class="mb-4">
							<label for="equipment_cleanliness"><span class='translate' data-i18n="8524" notes="Equipment cleanliness"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input hide_comment" id="compliant_equipment_cleanliness" name="equipment_cleanliness" value="8502" notes="Compliant" required>
								<label class="form-check-label mr-2" for="compliant_equipment_cleanliness"><span class='translate' data-i18n="8502" notes="Compliant"></span></label>

								<input type="radio" class="form-check-input show_comment" id="non_compliant_equipment_cleanliness" name="equipment_cleanliness" value="8503" notes="Non-compliant">
								<label class="form-check-label mr-2" for="non_compliant_equipment_cleanliness"><span class='translate' data-i18n="8503" notes="Non-compliant"></span></label> 

								<input type="radio" class="form-check-input show_comment" id="corrected_equipment_cleanliness" name="equipment_cleanliness" value="8504" notes="Corrected">
								<label class="form-check-label mr-2" for="corrected_equipment_cleanliness"><span class='translate' data-i18n="8504" notes="Corrected"></span></label>

								<input type="radio" class="form-check-input hide_comment" id="not_applicable_equipment_cleanliness" name="equipment_cleanliness" value="3914" notes="Not Applicable">
								<label class="form-check-label mr-2" for="not_applicable_equipment_cleanliness"><span class='translate' data-i18n="3914" notes="Not Applicable"></span></label> 
							</div>

							<div class="md-form d-none">
								<textarea name="comments_equip" id="comments_equip" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments_equip"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>
						</div>

						<div class="md-form pt-1 position-relative my-4">
							<input type="text" name="refuge_location" id="refuge_location" class="form-control" length="200" maxlength="200" required>
							<label for="refuge_location"><span class='translate' data-i18n="8525" notes="Location of the closest refuge"></span></label>
						</div>
							
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1387' notes='Shift Start Workplace Conditions'></span></h6>
							<div class="form-group photoImage" id="start_state_pictures"> 
								<label class="d-block"><span class='translate' data-i18n='838' notes='Start State Pictures of the Workplace'></span></label>
								<canvas id="canvasa_1" style='display:none;'></canvas>
								<div class="btn-group d-flex" role="group">
									<div class="btn btn-block btn-outline-secondary file-field px-1">
										<i class="fa fa-upload"></i> <span class='translate' data-i18n='2340' notes='ADD IMAGES'></span>
										<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
									</div>
								</div>
								<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
								<div class="row photoGallery" id="galleryida"></div>
							</div>

							<div class="md-form">
								<textarea name="start_state_details" id="start_state_details" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="start_state_details"><span class='translate' data-i18n='837' notes='Start state details'></span></label>
							</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='8526' notes='Supervisor Visit'></span></h6>
						<div id="lock_supervisor_entry_div">
							<div class="md-form">
								<textarea name="activity_observed" id="activity_observed" class="form-control md-textarea lock_supervisor_entry_lock" wrap="VIRTUAL"></textarea>
								<label for="activity_observed"><span class='translate' data-i18n='19' notes='Activity observed'></span></label>
							</div>

							<div class="mb-4">
								<label for="activity_observed_safe"><span class='translate' data-i18n="8527" notes="Is the activity observed safe and efficient?"></span></label>
								<div class="form-check custom-radio no-sub pl-0">
									<input type="radio" class='form-check-input lock_supervisor_entry_lock' id="activity_observed_safe_yes"  name="activity_observed_safe"  onclick="showHideRadio(event)" value="1" required>
									<label class="form-check-label mr-2" for="activity_observed_safe_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class='form-check-input lock_supervisor_entry_lock' id="activity_observed_safe_no"  name="activity_observed_safe" onclick="showHideRadio(event)" value="0">
									<label class="form-check-label mr-2" for="activity_observed_safe_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							
								<div class="md-form  d-none">
									<textarea name="reason_not_safe" id="reason_not_safe" class="form-control md-textarea lock_supervisor_entry_lock" wrap="VIRTUAL"></textarea>
									<label for="activity-observed"><span class='translate' data-i18n='8588' notes='Why is the activity not safe and efficient?'></span></label>
								</div>
							</div>
						</div>

						<!-- <span id='lock_supervisor_entry_time'></span>	 -->							
						<button type="button"  name="lock_supervisor_entry" id="lock_supervisor_entry" class="btn btn-primary btn-block my-4 waves-effect waves-light check_lock"><span class='translate' data-i18n="8548" notes="Lock supervisor entry"></span></button>
						<small class="form-text text-muted d-none"><span class='translate' data-i18n='8529' notes='Entries locked:'></span> <input style='border: none; display: inline; width: 300px; background:none;' type="text" name="lock_supervisor_entry_time" id="lock_supervisor_entry_time" readonly/></small>				
						<!--  -->

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='8530' notes='Planning'></span></h6>
						<hr style="border-color: #0f70b7; border-width: 2px;"/>
						<div>
							<label for="Review of work to be done"><strong><span class='translate' data-i18n='8531' notes='Review of work to be done'></span></strong></label>
						</div>
							<div class="md-form">
								<textarea name="first_visit" id="first_visit" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="first_visit"><span class='translate' data-i18n='8532' notes='First Visit'></span></label>
							</div>
 
							<div class="md-form">
								<textarea name="second_visit" id="second_visit" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="second_visit"><span class='translate' data-i18n='8533' notes='Second Visit'></span></label>
							</div>

							<div class="md-form pt-1 position-relative my-4">
								<input type="text" name="plan_number" id="plan_number" class="form-control" length="200" maxlength="200">
								<label for="plan_number"><span class='translate' data-i18n="8534" notes="Plan Number"></span></label>
							</div>

							<div class="md-form pt-1 position-relative my-4">
								<input type="text" name="specification_type" id="specification_type" class="form-control" length="200" maxlength="200">
								<label for="specification_type"><span class='translate' data-i18n="8535" notes="Type of specification"></span></label>
							</div>

						<div class="mb-4">
							<label for="plans_correspond"><span class='translate' data-i18n="8536" notes="Plans and specifications correspond to the workplace"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="plans_correspond_yes" name="plans_correspond" value="1">
								<label class="form-check-label mr-2" for="plans_correspond_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="plans_correspond_no" name="plans_correspond" value="0">
								<label class="form-check-label mr-2" for="plans_correspond_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label for="plans_understood"><span class='translate' data-i18n="8537" notes="Plans and specifications are understood and followed"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="plans_understood_yes" name="plans_understood" value="1">
								<label class="form-check-label mr-2" for="plans_understood_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="plans_understood_no" name="plans_understood" value="0">
								<label class="form-check-label mr-2" for="plans_understood_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						
							<div class="md-form">
								<textarea name="biggest_risk_today" id="biggest_risk_today" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="biggest_risk_today"><span class='translate' data-i18n='8538' notes='What is my biggest risk today?'></span></label>
							</div>
						
							<div class="md-form">
								<textarea name="to_control" id="to_control" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="to_control"><span class='translate' data-i18n='8539' notes='What did I do to control it?'></span></label>
							</div>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='2090' notes='Decision'></span></h6>
						<hr style="border-color: #076633; border-width: 2px;"/>
						<div id="lock_section_decision_div">
							<div class="form-check">
								<input type="checkbox" class="form-check-input ml-0 lock_section_decision_lock" name="confirm_understand" id="confirm_understand"  value = '' onclick="boxChecked(event.target)" required>
								<label class="form-check-label" for="confirm_understand"><span class='translate' data-i18n="8540" notes="I confirm that we understand each other"></span></label>
							</div>
							<div class="form-check">
								<input type="checkbox" class="form-check-input ml-0 lock_section_decision_lock" name="confirm_safe" id="confirm_safe"  value = ''   onclick="boxChecked(event.target)" required>
								<label class="form-check-label" for="confirm_safe"><span class='translate' data-i18n="8541" notes="I confirm that the work can be done safely"></span></label>
							</div>
							<div class="form-check">
								<input type="checkbox" class="form-check-input ml-0 lock_section_decision_lock" name="authorize_proceed" id="authorize_proceed"  value = ''  onclick="boxChecked(event.target)" required>
								<label class="form-check-label" for="authorize_proceed"><span class='translate' data-i18n="8542" notes="I authorize the employee to proceed with the work"></span></label>
							</div>
							<div class="my-4">
								<label class="text-muted"><span class='translate' data-i18n="217" notes="Employee signature"></span></label>
								<div class="btn-group d-flex" role="group" aria-label="Action subforms">
									<div id="employee_signature" class='btn btn-outline-secondary col waves-effect p-2 m-0 lock_section_decision_lock sign' signaturename='signature_employee' disabled><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
									<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
									<div id="clearemployee_signature" class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
								</div>
								<img id='signature_employee_img' src='' class='signatureImage d-block pt-2'/>
								<input type="hidden" name="signature_employee" id="signature_employee" class='modalSignature' value='' required>
								<input type="hidden" name="vector_employee" id='vector_employee' value=''>
								<input type="hidden" name="signature_employee_comments" id='signature_employee_comments' class="sig_comment" value=''>
								<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="employee_signature_img_time" id="employee_signature_img_time" notes='signature_employee_img_time' readonly/></small>
							</div>

							<div class="my-4">
								<label class="text-muted"><span class='translate' data-i18n="850" notes="Supervisor Signature"></span></label>
								<div class="btn-group d-flex" role="group" aria-label="Action subforms">
									<div id="supervisor_signature_lock_section_decision" class='btn btn-outline-secondary col waves-effect p-2 m-0 lock_section_decision_lock sign' signaturename='signature_supervisor'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
									<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
									<div id="clearsupervisor_signature_lock_section_decision" class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
								</div>
								<img id='signature_supervisor_img' src='' class='signatureImage d-block pt-2'/>
								<input type="hidden" name="signature_supervisor" id="signature_supervisor" class='modalSignature' value='' required>
								<input type="hidden" name="vector_supervisor" id='vector_supervisor' value='' >
								<input type="hidden" name="signature_supervisor_comments" id='signature_supervisor_comments' class="sig_comment" value=''>
								<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="supervisor_signature_img_time" id="supervisor_signature_img_time" notes='signature_supervisor_img_time' readonly/></small>
							</div>
						</div>

							<button type="button"  name="lock_section_decision" id="lock_section_decision" class="btn btn-primary btn-block my-4 waves-effect waves-light check_lock"><span class='translate' data-i18n="8543" notes="Lock section"></span></button>
							<small class="form-text text-muted d-none"><span class='translate' data-i18n='8529' notes='Entries locked:'></span> <input style='border: none; display: inline; width: 300px; background:none;' type="text" name="lock_section_decision_time" id="lock_section_decision_time" readonly/></small>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='8545' notes='Execution'></span></h6>
						<hr style="border-color: #f8ea19; border-width: 2px;"/>
						<div id="lock_section_execution_div">
							<div class="md-form pt-1 position-relative my-4">
								<input type="text" name="second_visit_location" id="second_visit_location" class="form-control lock_section_execution_lock" length="200" maxlength="200">
								<label for="second_visit_location"><span class='translate' data-i18n="8546" notes="Location of second visit"></span></label>
							</div>

							<div class="mb-4">
								<label for="first_visit_accordance"><span class='translate' data-i18n="8547" notes="Is work in accordance with the decisions taken during first visit?"></span></label>
								<div class="form-check custom-radio no-sub pl-0">
									<input type="radio" class="form-check-input lock_section_execution_lock" id="first_visit_accordance_yes" name="first_visit_accordance" value="1" required>
									<label class="form-check-label mr-2" for="first_visit_accordance_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input lock_section_execution_lock" id="first_visit_accordance_no" name="first_visit_accordance" value="0">
									<label class="form-check-label mr-2" for="first_visit_accordance_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							
								<div class="md-form">
									<textarea name="supervisor_comments" id="supervisor_comments" class="form-control md-textarea lock_section_execution_lock" wrap="VIRTUAL"></textarea>
									<label for="supervisor_comments"><span class='translate' data-i18n='846' notes='Supervisor Comments'></span></label>
								</div>
							</div>

							<div class="my-4">
								<label class="text-muted"><span class='translate' data-i18n="850" notes="Supervisor Signature"></span></label>
								<div class="btn-group d-flex" role="group" aria-label="Action subforms">
									<div id='supervisor_signature_lock_section_execution' class='btn btn-outline-secondary col waves-effect p-2 m-0 lock_section_execution_lock sign' signaturename='signature_execution_supervisor'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
									<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
									<div id='clearsupervisor_signature_lock_section_execution' class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none' ><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
								</div>
								<img id='signature_execution_supervisor_img' src='' class='signatureImage d-block pt-2'/>
								<input type="hidden" name="signature_execution_supervisor" id="signature_execution_supervisor" class='modalSignature' value='' required>
								<input type="hidden" name="vector_supervisor_execution" id='vector_supervisor_execution' value=''>
								<input type="hidden" name="signature_execution_supervisor_comments" id='signature_execution_supervisor_comments' class="sig_comment" value=''>
								<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="supervisor_signature_execution_img_time" id="supervisor_signature_execution_img_time" notes='signature_execution_supervisor_img_time' readonly/></small>
							</div>
						</div>

						<button type="button"  name="lock_section_execution" id="lock_section_execution" class="btn btn-primary btn-block my-4 waves-effect waves-light check_lock"><span class='translate' data-i18n="8548" notes="Lock supervisor entry"></span></button>
						<small class="form-text text-muted d-none"><span class='translate' data-i18n='8529' notes='Entries locked:'></span> <input style='border: none; display: inline; width: 300px; background:none;' type="text" name="lock_section_execution_time" id="lock_section_execution_time" readonly/></small>	

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1394' notes='Shift End Workplace Conditions'></span></h6>
							<div class="form-group photoImage" id="end_state_pictures"> 
								<label class="d-block"><span class='translate' data-i18n='423' notes='End State Pictures of the Workplace'></span></label>
								<canvas id="canvasa_2" style='display:none;'></canvas>
								<div class="btn-group d-flex" role="group">
									<div class="btn btn-block btn-outline-secondary file-field px-1">
										<i class="fa fa-upload"></i> <span class='translate' data-i18n='2340' notes='ADD IMAGES'></span>
										<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
									</div>
								</div>
								<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
								<div class="row photoGallery" id="galleryidb"></div>
							</div>

							<div class="md-form">
								<textarea name="end_state_details" id="end_state_details" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="end_state_details"><span class='translate' data-i18n='422' notes='End State Details'></span></label>
							</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='8550' notes='Drilling and Loading'></span></h6>
							<div class="md-form">
								<input type="number" min="0" oninput="this.value =!!this.value && Math.abs(this.value) >= 0 ? Math.abs(this.value) : null" name="quantity_1" id="quantity_1" class="form-control">
								<label for="quantity_1"><span class='translate' data-i18n='8551' notes='Number of holes'></span></label>
							</div>

							<div class="md-form pt-1 position-relative my-4">
								<input type="text" name="placement_of_holes" id="placement_of_holes" class="form-control" length="200" maxlength="200">
								<label for="placement_of_holes"><span class='translate' data-i18n="8552" notes="Placement of holes"></span></label>
							</div>

							<div class="md-form pt-1 position-relative my-4">
								<input type="text" name="station_number" id="station_number" class="form-control" length="200" maxlength="200">
								<label for="station_number"><span class='translate' data-i18n="8553" notes="Station number"></span></label>
							</div>

							<div class="md-form pt-1 position-relative my-4">
								<input type="text" name="station_distance" id="station_distance" class="form-control" length="200" maxlength="200">
								<label for="station_distance"><span class='translate' data-i18n="8554" notes="Distance of station"></span></label>
							</div>

							<label class="text-muted"><span class='translate' data-i18n="2508" notes="Explosives"></span></label>

							<div class="form-check mb-3">
								<input type="checkbox" class="form-check-input ml-0" name="anfo" id="anfo" onclick="showHideCheckBox(event)" value = ''>
								<label class="form-check-label" for="anfo"><span class='translate' data-i18n="8615" notes="Anfo"></span></label>
							</div>

							<div class="md-form pt-1 position-relative my-4 d-none">
								<input type="text" name="quantity_and_type_anfo" id="quantity_and_type_anfo" class="form-control" length="200" maxlength="200">
								<label for="quantity_and_type_anfo"><span class='translate' data-i18n="8555" notes="Quantity and Type"></span></label>
							</div>

							<div class="form-check mb-3">
								<input type="checkbox" class="form-check-input ml-0" name="stick_powder" id="stick_powder" onclick="showHideCheckBox(event)" value = ''>
								<label class="form-check-label" for="stick_powder"><span class='translate' data-i18n="8556" notes="Stick Powder"></span></label>
							</div>

							<div class="md-form pt-1 position-relative my-4 d-none">
								<input type="text" name="quantity_and_type_powder" id="quantity_and_type_powder" class="form-control" length="200" maxlength="200">
								<label for="quantity_and_type_powder"><span class='translate' data-i18n="8555" notes="Quantity and Type"></span></label>
							</div>

							<div class="form-check">
								<input type="checkbox" class="form-check-input ml-0" name="emulsion" id="emulsion" onclick="showHideCheckBox(event)" value = ''>
								<label class="form-check-label" for="emulsion"><span class='translate' data-i18n="8557" notes="Emulsion"></span></label>
							</div>

							<div class="md-form pt-1 position-relative my-4 d-none">
								<input type="text" name="quantity_and_type_emulsion" id="quantity_and_type_emulsion" class="form-control" length="200" maxlength="200">
								<label for="quantity_and_type_emulsion"><span class='translate' data-i18n="8555" notes="Quantity and Type"></span></label>
							</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='8558' notes='Ground Support'></span></h6>
