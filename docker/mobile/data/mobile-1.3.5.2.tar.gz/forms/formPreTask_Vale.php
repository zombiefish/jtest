<?php	
  $strPageTitle = 'Vale N.A.P.G. FLHA';
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
						<h6 class="text-secondary"><span class='translate' data-i18n="3935" notes="Vale N.A.P.G. FLHA"></span></h6>
						<div class="pt-1 position-relative my-4">
							<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
							</select>
							<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
						</div>

						<form name="PreTask" id="PreTask" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>

						<div class="md-form">
							<input type="text" name="supervisor_contact" id="supervisor_contact" class="form-control lock" length="200" maxlength="200" required>
							<label for="supervisor_contact"><span class='translate' data-i18n="2840" notes="Supervisor Contact (Radio Channel./ Phone #)"></span></label>
						</div>	

						<div class="md-form">
							<input type="text" name="vale_contact" id="vale_contact" class="form-control lock" length="200" maxlength="200" required>
							<label for="vale_contact"><span class='translate' data-i18n="2463" notes="Vale Contact Person"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="820" notes="Shift"></span></h6>
						<div class="form-check custom-radio pl-0">
							<input type="radio" class="form-check-input trans_input" id="shift_days" name="shift" value="1095" required>
							<label class="form-check-label mr-2" for="shift_days"><span class='translate' data-i18n="1095" notes="Days"></span></label>

							<input type="radio" class="form-check-input trans_input" id="shift_nights" name="shift" value="1375">
							<label class="form-check-label mr-2" for="shift_nights"><span class='translate' data-i18n="1375" notes="Nights"></span></label> 
						</div>


						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="2464" notes="Am I equipped for work?"></span></h6>
						<small class="form-text text-muted"><span class='translate' data-i18n="2465" notes="Take the time"></span></small><br>
						<div class="mb-4">
							<label class="text-muted d-block"><span class='translate' data-i18n="2466" notes="Do I understand the task?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="understand_work_yes" name="understand_work" value="1" required>
								<label class="form-check-label mr-2" for="understand_work_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="understand_work_no" name="understand_work" value="0">
								<label class="form-check-label mr-2" for="understand_work_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="text-muted d-block"><span class='translate' data-i18n="2467" notes="Am I trained and competent for the task?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="trained_competent_yes" name="trained_competent" value="1" required>
								<label class="form-check-label mr-2" for="trained_competent_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="trained_competent_no" name="trained_competent" value="0">
								<label class="form-check-label mr-2" for="trained_competent_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="text-muted d-block"><span class='translate' data-i18n="2468" notes="Am I familiar with the equipment and work area?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="familiar_with_equipment_work_yes" name="familiar_with_equipment_work" value="1" required>
								<label class="form-check-label mr-2" for="familiar_with_equipment_work_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="familiar_with_equipment_work_no" name="familiar_with_equipment_work" value="0">
								<label class="form-check-label mr-2" for="familiar_with_equipment_work_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="text-muted d-block"><span class='translate' data-i18n="2469" notes="Do I have the proper tools and equipment?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="proper_tools_equipment_yes" name="proper_tools_equipment" value="1" required>
								<label class="form-check-label mr-2" for="proper_tools_equipment_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="proper_tools_equipment_no" name="proper_tools_equipment" value="0">
								<label class="form-check-label mr-2" for="proper_tools_equipment_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="text-muted d-block"><span class='translate' data-i18n="2470" notes="Do I understand the SOP and/or JHA for the task?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="understand_SOP_JHA_yes" name="understand_SOP_JHA" value="1" required>
								<label class="form-check-label mr-2" for="understand_SOP_JHA_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="understand_SOP_JHA_no" name="understand_SOP_JHA" value="0">
								<label class="form-check-label mr-2" for="understand_SOP_JHA_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="text-muted d-block"><span class='translate' data-i18n="2471" notes="Have I informed others who may be affected by the work?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="informed_others_yes" name="informed_others" value="1" required>
								<label class="form-check-label mr-2" for="informed_others_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="informed_others_no" name="informed_others" value="0">
								<label class="form-check-label mr-2" for="informed_others_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>
						
						<div id="equipped_for_work_alert" class="alert alert-danger mt-3 text-center d-none contact-supervisor" role="alert"><span class='translate' data-i18n="1392" notes="Safe work conditions are not met. Please contact your supervisor."></span></div>
						
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="2472" notes="Critical Communication Information"></span></h6>

						<div class="md-form">
							<textarea name="notes" id="notes" class="form-control md-textarea lock" wrap="VIRTUAL" required></textarea>
							<label for="notes"><span class='translate' data-i18n="1296" notes="Notes"></span></label>
						</div>


						<div class="md-form">
							<input type="text" name="INVAC_Location" id="INVAC_Location" class="form-control lock" length="200" maxlength="200" required>
							<label for="INVAC_Location"><span class='translate' data-i18n="2473" notes="INVAC Location"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="OUTVAC_Location" id="OUTVAC_Location" class="form-control lock" length="200" maxlength="200" required>
							<label for="OUTVAC_Location"><span class='translate' data-i18n="2474" notes="OUTVAC Location"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="refuge_location" id="refuge_location" class="form-control lock" length="200" maxlength="200" required>
							<label for="refuge_location"><span class='translate' data-i18n="2475" notes="REFUGE Location"></span></label>
						</div>
						<div id="crews"></div>

						<div id='addCrew' class='btn btn-sm btn-primary lock'><i class="fa fa-plus"></i> <span class='translate' data-i18n="2481" notes="ADD TASK"></span></div>
						<div id='removeCrew' class='btn btn-sm btn-outline-primary lock'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n="2482" notes="REMOVE TASK"></span></div>
						
						<!-- Working at Heights -->
						<h6 class="text-secondary pt-4 "><span class='translate' data-i18n="2483" notes="Critical Activity Requirements"></span></h6>
						<div class="form-check pl-0">
							<input type="checkbox" class="form-check-input ml-0" name="working_at_heights" id="working_at_heights"   value = '0' onchange="changeWorkingAtHeights()">
							<label class="form-check-label" for="working_at_heights"><strong><span class='translate' data-i18n="2371" notes="Working at Heights"></span></strong></label>
						</div>
						<br>
						<div id = "workingAtHeights" class="d-none">
							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2489" notes="Have you calculated the fall distance?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="calculated_fall_distance_yes" name="calculated_fall_distance" value="1">
									<label class="form-check-label mr-2" for="calculated_fall_distance_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="calculated_fall_distance_no" name="calculated_fall_distance" value="0">
									<label class="form-check-label mr-2" for="calculated_fall_distance_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>

							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2490" notes="Do you have an approved written rescue plan?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="approved_rescue_plan_yes" name="approved_rescue_plan" value="1">
									<label class="form-check-label mr-2" for="approved_rescue_plan_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="approved_rescue_plan_no" name="approved_rescue_plan" value="0">
									<label class="form-check-label mr-2" for="approved_rescue_plan_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>
						</div>

						<!-- Automotive Vehicles -->
						<div class="form-check pl-0">
							<input type="checkbox" class="form-check-input ml-0" name="automotive_vehicles" id="automotive_vehicles"   value = '0' onchange="changeAutomotiveVehicles()">
							<label class="form-check-label" for="automotive_vehicles"><strong><span class='translate' data-i18n="2502" notes="Automotive Vehicles"></span></strong></label>
						</div>
						<br>
						<div id = "automotiveVehicles" class="d-none">
							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2503" notes="Have you completed a pre-use inspection?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="completed_pre_use_inspect_yes" name="completed_pre_use_inspect" value="1">
									<label class="form-check-label mr-2" for="completed_pre_use_inspect_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="completed_pre_use_inspect_no" name="completed_pre_use_inspect" value="0">
									<label class="form-check-label mr-2" for="completed_pre_use_inspect_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>

							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2504" notes="Is your vehicle equipped for the area (flashing beacon, buggy whip first aid kit, fire extinguisher, b/u alarm, spill kit)?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="vehicle_equipped_yes" name="vehicle_equipped" value="1">
									<label class="form-check-label mr-2" for="vehicle_equipped_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="vehicle_equipped_no" name="vehicle_equipped" value="0">
									<label class="form-check-label mr-2" for="vehicle_equipped_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>
						</div>

						<!-- Mobile Equipment -->
						<div class="form-check pl-0">
							<input type="checkbox" class="form-check-input ml-0" name="mobile_equipment" id="mobile_equipment"   value = '0' onchange="changeMobileEquipment()">
							<label class="form-check-label" for="mobile_equipment"><strong><span class='translate' data-i18n="2499" notes="Mobile Equipment"></span></strong></label>
						</div>
						<br>
						<div id = "mobileEquipment" class="d-none">
							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2500" notes="Are you trained and authorized to operate this specific model of equipment?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="trained_authorized_yes" name="trained_authorized" value="1">
									<label class="form-check-label mr-2" for="trained_authorized_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="trained_authorized_no" name="trained_authorized" value="0">
									<label class="form-check-label mr-2" for="trained_authorized_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>

							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2501" notes="Is there adequate separation between people/equipment?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="adeq_separation_bw_people_yes" name="adeq_separation_bw_people" value="1">
									<label class="form-check-label mr-2" for="adeq_separation_bw_people_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="adeq_separation_bw_people_no" name="adeq_separation_bw_people" value="0">
									<label class="form-check-label mr-2" for="adeq_separation_bw_people_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>
						</div>

						<!-- Lockout, Tagout, Check -->
						<div class="form-check pl-0">
							<input type="checkbox" class="form-check-input ml-0" name="lock_tag_out_check" id="lock_tag_out_check"   value = '0' onchange="changeLockTagOutCheck()">
							<label class="form-check-label" for="lock_tag_out_check"><strong><span class='translate' data-i18n="2532" notes="Lockout, Tagout, Check"></span></strong></label>
						</div>
						<br>
						<div id = "lockTagOutCheck" class="d-none">
							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2484" notes="Have you verified isolation and no residual energy is present?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="verified_isolation_yes" name="verified_isolation" value="1" >
									<label class="form-check-label mr-2" for="verified_isolation_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="verified_isolation_no" name="verified_isolation" value="0">
									<label class="form-check-label mr-2" for="verified_isolation_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>

							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2485" notes="Do you have an individual lock & tag and is it installed?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="individual_lock_yes" name="individual_lock" value="1">
									<label class="form-check-label mr-2" for="individual_lock_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="individual_lock_no" name="individual_lock" value="0">
									<label class="form-check-label mr-2" for="individual_lock_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>
						</div>


						<!-- Lifting Operations  -->
						<div class="form-check pl-0">
							<input type="checkbox" class="form-check-input ml-0" name="lifting_operations" id="lifting_operations" value = '0' onchange="changeLiftingOperations()">
							<label class="form-check-label" for="lifting_operations"><strong><span class='translate' data-i18n="2505" notes="Lifting Operations"></span></strong></label>
						</div>
						<br>
						<div id = "liftingOperations" class="d-none">
							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2506" notes="Is the rigging/lifting equipment appropriate and inspected?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="lifting_equipment_appropriate_yes" name="lifting_equipment_appropriate" value="1" >
									<label class="form-check-label mr-2" for="lifting_equipment_appropriate_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="lifting_equipment_appropriate_no" name="lifting_equipment_appropriate" value="0">
									<label class="form-check-label mr-2" for="lifting_equipment_appropriate_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>

							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2507" notes="Is the area access secure and no personnel under loads?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="area_access_secure_yes" name="area_access_secure" value="1">
									<label class="form-check-label mr-2" for="area_access_secure_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="area_access_secure_no" name="area_access_secure" value="0">
									<label class="form-check-label mr-2" for="area_access_secure_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>
						</div>

						<!-- Confined Space  -->
						<div class="form-check pl-0">
							<input type="checkbox" class="form-check-input ml-0" name="confined_space" id="confined_space" value = '0' onchange="changeConfinedSpace()">
							<label class="form-check-label" for="confined_space"><strong><span class='translate' data-i18n="94" notes="Confined Space"></span></strong></label>
						</div>
						<br>
						<div id = "confinedSpace" class="d-none">
							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2491" notes="Do you have an approved permit?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="approved_permit_yes" name="approved_permit" value="1" >
									<label class="form-check-label mr-2" for="approved_permit_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="approved_permit_no" name="approved_permit" value="0">
									<label class="form-check-label mr-2" for="approved_permit_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>

							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2492" notes="Is there an approved written rescue plan?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="written_rescue_plan_yes" name="written_rescue_plan" value="1">
									<label class="form-check-label mr-2" for="written_rescue_plan_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="written_rescue_plan_no" name="written_rescue_plan" value="0">
									<label class="form-check-label mr-2" for="written_rescue_plan_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>
						</div>

						<!-- Machine Guarding -->

						<div class="form-check pl-0">
							<input type="checkbox" class="form-check-input ml-0" name="machine_guarding" id="machine_guarding" value = '0' onchange="changeMachineGuarding()">
							<label class="form-check-label" for="machine_guarding"><strong><span class='translate' data-i18n="2496" notes="Machine Guarding"></span></strong></label>
						</div>
						<br>
						<div id = "machineGuarding" class="d-none">
							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2497" notes="Are proper guards in place on moving equipment?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="proper_guards_yes" name="proper_guards" value="1">
									<label class="form-check-label mr-2" for="proper_guards_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="proper_guards_no" name="proper_guards" value="0">
									<label class="form-check-label mr-2" for="proper_guards_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>

							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2498" notes="Have you removed all items that can become entangled?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="removed_all_items_yes" name="removed_all_items" value="1">
									<label class="form-check-label mr-2" for="removed_all_items_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="removed_all_items_no" name="removed_all_items" value="0">
									<label class="form-check-label mr-2" for="removed_all_items_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>
						</div>

						<!-- Ground Stability -->


						<div class="form-check pl-0">
							<input type="checkbox" class="form-check-input ml-0" name="ground_stability" id="ground_stability" value = '0' onchange="changeGroundStability()">
							<label class="form-check-label" for="ground_stability"><strong><span class='translate' data-i18n="2493" notes="Ground Stability"></span></strong></label>
						</div>
						<br>
						<div id = "groundStability" class="d-none">
							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2494" notes="Is ground support installed on the working face?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="ground_support_installed_yes" name="ground_support_installed" value="1" >
									<label class="form-check-label mr-2" for="ground_support_installed_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="ground_support_installed_no" name="ground_support_installed" value="0">
									<label class="form-check-label mr-2" for="ground_support_installed_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>

							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2495" notes="Are the ground support controls inspected and in good condition?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="support_controls_inspected_yes" name="support_controls_inspected" value="1">
									<label class="form-check-label mr-2" for="support_controls_inspected_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="support_controls_inspected_no" name="support_controls_inspected" value="0">
									<label class="form-check-label mr-2" for="support_controls_inspected_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>
						</div>

						<!-- Explosives   -->

						<div class="form-check pl-0">
							<input type="checkbox" class="form-check-input ml-0" name="explosives" id="explosives" value = '0' onchange="changeExplosives()">
							<label class="form-check-label" for="explosives"><strong><span class='translate' data-i18n="2508" notes="Explosives"></span></strong></label>
						</div>
						<br>
						<div id = "explosivesQuestions" class="d-none">
							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2509" notes="Are caps and powder stored properly/separated?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="caps_powder_stored_yes" name="caps_powder_stored" value="1" >
									<label class="form-check-label mr-2" for="caps_powder_stored_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="caps_powder_stored_no" name="caps_powder_stored" value="0">
									<label class="form-check-label mr-2" for="caps_powder_stored_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>

							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2510" notes="Is proper entry/re-entry protocol in place?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="proper_entry_protocol_yes" name="proper_entry_protocol" value="1">
									<label class="form-check-label mr-2" for="proper_entry_protocol_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="proper_entry_protocol_no" name="proper_entry_protocol" value="0">
									<label class="form-check-label mr-2" for="proper_entry_protocol_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>
						</div>

						<!-- Working with Electricity -->

						<div class="form-check pl-0">
							<input type="checkbox" class="form-check-input ml-0" name="work_with_electricity" id="work_with_electricity" value = '0' onchange="changeWorkWithElectricity()">
							<label class="form-check-label" for="work_with_electricity"><strong><span class='translate' data-i18n="2486" notes="Working with Electricity"></span></strong></label>
						</div>
						<br>
						<div id = "workWithElectricity" class="d-none">
							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2487" notes="Has the equipment been completely isolated?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="equipment_isolated_yes" name="equipment_isolated" value="1" >
									<label class="form-check-label mr-2" for="equipment_isolated_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="equipment_isolated_no" name="equipment_isolated" value="0">
									<label class="form-check-label mr-2" for="equipment_isolated_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>

							<div class="mb-4">
								<label class="text-muted d-block"><span class='translate' data-i18n="2488" notes="Have you applied your personal lock & tag to work on the de-energized system?"></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="personal_lock_tag_yes" name="personal_lock_tag" value="1">
									<label class="form-check-label mr-2" for="personal_lock_tag_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

									<input type="radio" class="form-check-input" id="personal_lock_tag_no" name="personal_lock_tag" value="0">
									<label class="form-check-label mr-2" for="personal_lock_tag_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
								</div>
							</div>
						</div>

						<div id="critical_activity_requirements" class="alert alert-danger mt-3 text-center d-none contact-supervisor" role="alert"><span class='translate' data-i18n="1392" notes="Safe work conditions are not met. Please contact your supervisor."></span></div>
						
						<h6 class="text-secondary pt-4 "> <i class="fa fa-exclamation-triangle"></i><span class='translate' data-i18n="2511" notes="Hazard Recognition"></span></h6>

						<p><span class='translate' data-i18n="2512" notes="WHAT COULD GO WRONG?"></span></strong></p> 
						<p><span class='translate' data-i18n="2513" notes="What hazards are associated with this job?"></span></strong></p>
						<p><span class='translate' data-i18n="[html]2533" notes="Mechanical - Stored energy, moving part or rotating parts?"></span></p>
						<p><span class='translate' data-i18n="[html]2534" notes="Electrical - Shock hazard, overhead power lines?"></span></p>
						<p><span class='translate' data-i18n="[html]2535" notes="Pressure - Pneumatics, hydraulics, stored energy?"></span></p>
						<p><span class='translate' data-i18n="[html]2536" notes="Temperature - Extreme weather, hot equipment?"></span></p>
						<p><span class='translate' data-i18n="[html]2537" notes="Chemical - Oils, muds, degreasers/ Air Quality?"></span></p>
						<p><span class='translate' data-i18n="[html]2538" notes="Sound - Compressors, impact noise, vent fans?"></span></p>
						<p><span class='translate' data-i18n="[html]2539" notes="Gravity - Cranes, hoisted rods, high-walls?"></span></p>
						<p><span class='translate' data-i18n="[html]2540" notes="Motion - Vehicles, mobile equipment?"></span></p>


						<h6 class="text-secondary pt-4 "> <i class="fa fa-search"></i><span class='translate' data-i18n="2514" notes="Identify the risk"></span></h6>

						<p><strong><span class='translate' data-i18n="2515" notes="HOW BAD COULD IT BE?"></span></strong></p>
						<p><strong><span class='translate' data-i18n="2516" notes="Are there risks associated with the hazards?"></span></strong></p>
						<p>• <span class='translate' data-i18n="2541" notes="Can I be injured by being caught in, on, or between anything?"></span></p>
						<p>• <span class='translate' data-i18n="2542" notes="Can I strain or over-exert myself?"></span></p>
						<p>• <span class='translate' data-i18n="2543" notes="Can I fall onto, into or from anything?"></span></p>
						<p>• <span class='translate' data-i18n="2544" notes="Can I slip or trip on anything?"></span></p>
						<p>• <span class='translate' data-i18n="2545" notes="Can I be struck by a moving part?"></span></p>
						<p>• <span class='translate' data-i18n="2546" notes="Can I spill or pollute something?"></span></p>
						<p>• <span class='translate' data-i18n="2547" notes="Do I need a permit?"></span></p>
						<p>• <span class='translate' data-i18n="2548" notes="Can weather conditions, work environment or poor lighting affect job safety?"></span></p>
						<p>• <span class='translate' data-i18n="2549" notes="Can I continue to safely access or egress the worksite?"></span></p>
						<p>• <span class='translate' data-i18n="2550" notes="Can I come into contact with or be exposed to something that may harm me (electricity, heat, gas, hazardous substances or stored energy)?"></span></p>
						<p>• <span class='translate' data-i18n="2551" notes="Does anything need to be locked out, tagged out and zero energy verified?"></span></p>
						<p>• <span class='translate' data-i18n="2552" notes="Can something fall on me or can I cause something to fall on someone else?"></span></p>
						<p>• <span class='translate' data-i18n="2553" notes="Can I be injured by nearby activities or can my activities injure others nearby?"></span></p>
						<p>• <span class='translate' data-i18n="2554" notes="Could there be any uncontrolled movement, like ground movement, machine movement?"></span></p>
						
						<h6 class="text-secondary pt-4 "> <i class="fa fa-fire-extinguisher"></i><span class='translate' data-i18n="2517" notes="Necessary Controls Applied"></span></h6>
						<p><strong><span class='translate' data-i18n="2518" notes="HOW CAN I MANAGE IT?"></span></strong></p>
						<p><strong><span class='translate' data-i18n="2519" notes="Hierarchy of Controls"></span></strong></p>
						
						<span style="width:100%; height: 100%" id ="hierarchy_of_controls"></span>
                        <script src="/images/hierarchy_of_controls.js"></script>
						<br>
						<br>
						<p><span class='translate' data-i18n="[html]2555" notes="Elimination - Improper tools, hazardous material, machines, equipment."></span></p>
						<p><span class='translate' data-i18n="[html]2556" notes="Administrative - Procedures, JHA, real time."></span></p>
						<p><span class='translate' data-i18n="[html]2557" notes="Engineering - Redesign, guarding."></span></p>
						<p><span class='translate' data-i18n="[html]2558" notes="Substitution - Replacing a hazard with something non-hazardous."></span></p>
						<p><span class='translate' data-i18n="[html]2559" notes="PPE - Face shield. fall protection, puncture/cut-resistant gloves."></span></p>
						
						
						<div id="hazard_action_for_unsafe_tasks" class="alert alert-danger mt-3 text-center contact-supervisor" role="alert"><span class='translate' data-i18n="2522" notes="Please create Hazard Actions for all unsafe tasks identified."></span></div>
						
						<div id="hazard_action_for_unsafe_tasks" class="alert alert-primary mt-3 contact-supervisor" role="alert"><p class="mb-1"><span class='translate' data-i18n="[html]2524" notes="Stop and Think - What has Changed?"></span></p><p class="py-0 mb-1"><span class='translate' data-i18n="3936" notes="20 - 20 - 20 - Every 20 minutes, take 20 seconds and look 20 feet around"></span></p></div>
						
						<h6 class="text-secondary pt-4 "><span class='translate' data-i18n="1387" notes="Shift Start Workplace Conditions"></span></h6>

						<div class="form-group photoImage" id="start_state_pictures"> 
							<label class="d-block"><span class='translate' data-i18n="838" notes="Start State Pictures of the Workplace"></span></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1 image_input_to_lock">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
							<div class="row photoGallery" id="galleryid"></div>
						</div>

						<div class="md-form">
							<textarea name="start_state_details" id="start_state_details" class="form-control md-textarea lock" wrap="VIRTUAL"></textarea>
							<label for="start_state_details"><span class='translate' data-i18n="837" notes="Start State Details"></span></label>
						</div>

						<h6 class="text-secondary pt-4 "><span class='translate' data-i18n="1394" notes="Shift End Workplace Conditions"></span></h6>

						<div class="form-group photoImage" id="end_state_pictures"> 
							<label class="d-block"><span class='translate' data-i18n="423" notes="End State Pictures of the Workplace"></span></label>
							<canvas id="canvas2" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1 image_input_to_lock">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
							<div class="row photoGallery" id="galleryid2"></div>
						</div>

						<div class="md-form">
							<textarea name="end_state_details" id="end_state_details" class="form-control md-textarea lock" wrap="VIRTUAL"></textarea>
							<label for="end_state_details"><span class='translate' data-i18n="422" notes="End State Details"></span></label>
						</div>	
						<div class="md-form">
							<textarea name="supervisor_comments" id="supervisor_comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="supervisor_comments" class="pr-5"><span class='translate' data-i18n="846" notes="Supervisor Comments"></span></label>
						</div>

						<button type="button"  name="lock_comment" id="lock_comment" class="btn btn-primary btn-block my-4 waves-effect waves-light"><span class='translate' data-i18n="2525" notes="Lock Comment"></span></button>
						
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1395" notes="Signatures"></span></h6>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="850" notes="Supervisor Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign lock' signaturename='signature_supervisor'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_supervisor_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_supervisor" id="signature_supervisor" class='modalSignature' value=''>
							<input type="hidden" name="vector_supervisor" id='vector_supervisor' value=''>
							<input type="hidden" name="signature_supervisor_comments" id='signature_supervisor_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_supervisor_img_time" id="signature_supervisor_img_time" notes='signature_supervisor_img_time' readonly/></small>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="640" notes="Manager Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign lock' signaturename='signature_manager'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_manager_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_manager" id="signature_manager" class='modalSignature' value=''>
							<input type="hidden" name="vector_manager" id='vector_manager' value=''>
							<input type="hidden" name="signature_manager_comments" id='signature_manager_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_manager_img_time" id="signature_manager_img_time" notes='signature_manager_img_time' readonly/></small>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="1397" notes="Other Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign lock' signaturename='signature_other'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_other_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_other" id="signature_other" class='modalSignature' value='' >
							<input type="hidden" name="vector_other" id='vector_other' value=''>
							<input type="hidden" name="signature_other_comments" id='signature_other_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_other_img_time" id="signature_other_img_time" notes='signature_other_img_time' readonly/></small>
						</div>

						<h6 class="text-secondary pt-4 "><span class='translate' data-i18n="1188" notes="Review"></span></h6>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="9409" notes="End of Shift Review"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign lock' signaturename='signature_end_of_shift_review'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1188" notes="Review"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<!-- <div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div> -->
							</div>
							<img id='signature_end_of_shift_review_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_end_of_shift_review" id="signature_end_of_shift_review" class='modalSignature' value=''>
							<input type="hidden" name="vector_review" id='vector_review' value=''>
							<input type="hidden" name="signature_end_of_shift_review_comments" id='signature_end_of_shift_review_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_end_of_shift_review_img_time" id="signature_end_of_shift_review_img_time" notes='signature_end_of_shift_review_img_time' readonly/></small>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag='3935' class = "trans_input" value="3935" note="Vale N.A.P.G. FLHA" />
						<input type="hidden" name="formtype" id="formtype" value="SUP" />
						<input type="hidden" name="formid" id="formid" value="372398" />
						<input type="hidden" name="version" id="version" value="1" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
						<input type="hidden" name="lockButton" id="lockButton" value="false" />
						<input type="hidden" name="numCrews" id="numCrews" value='1' />
						<input type="hidden" name="totalCrews" id="totalCrews" value='5' />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>


<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.')
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.')
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.')
			return true
		}	
	}

	function initializeRadioButton() {
		$('input[type=radio]').change((e) => {
			if ($('input[name="understand_work"]:checked').val() == 0 ||
			    $('input[name="trained_competent"]:checked').val() == 0 ||
				$('input[name="familiar_with_equipment_work"]:checked').val() == 0 ||
				$('input[name="proper_tools_equipment"]:checked').val() == 0 ||
				$('input[name="understand_SOP_JHA"]:checked').val() == 0 ||
				$('input[name="informed_others"]:checked').val() == 0) {
					// console.log("Turn on Alert")
					$('#equipped_for_work_alert').removeClass("d-none")
			}
			else {
				$('#equipped_for_work_alert').addClass("d-none")
			}
			initRadioOnCriticalActivityRequirements()
		});
	};

	function initializeRadioButtonOnRecall() {
		if ($('input[name="understand_work"]:checked').val() == 0 ||
			$('input[name="trained_competent"]:checked').val() == 0 ||
			$('input[name="familiar_with_equipment_work"]:checked').val() == 0 ||
			$('input[name="proper_tools_equipment"]:checked').val() == 0 ||
			$('input[name="understand_SOP_JHA"]:checked').val() == 0 ||
			$('input[name="informed_others"]:checked').val() == 0) {
				// console.log("Turn on Alert")
				$('#equipped_for_work_alert').removeClass("d-none")
		}
		else {
			$('#equipped_for_work_alert').addClass("d-none")
		}
		// initRadioOnCriticalActivityRequirements()
	};


	function initRadioOnCriticalActivityRequirements(){
		if ($('input[name="calculated_fall_distance"]:checked').val() == 0 ||
			$('input[name="approved_rescue_plan"]:checked').val() == 0 ||
			$('input[name="completed_pre_use_inspect"]:checked').val() == 0 ||
			$('input[name="vehicle_equipped"]:checked').val() == 0 ||
			$('input[name="trained_authorized"]:checked').val() ==0 ||
			$('input[name="adeq_separation_bw_people"]:checked').val() ==0 ||
			$('input[name="verified_isolation"]:checked').val() == 0||
			$('input[name="individual_lock"]:checked').val() == 0 ||
			$('input[name="lifting_equipment_appropriate"]:checked').val() == 0||
			$('input[name="area_access_secure"]:checked').val() == 0 ||
			$('input[name="approved_permit"]:checked').val() == 0 ||
			$('input[name="written_rescue_plan"]:checked').val() == 0 ||
			$('input[name="proper_guards"]:checked').val() == 0 ||
			$('input[name="removed_all_items"]:checked').val() == 0 ||
			$('input[name="ground_support_installed"]:checked').val() == 0 ||
			$('input[name="support_controls_inspected"]:checked').val() == 0 ||
			$('input[name="caps_powder_stored"]:checked').val() == 0 ||
			$('input[name="proper_entry_protocol"]:checked').val() == 0 ||
			$('input[name="equipment_isolated"]:checked').val() == 0 ||
			$('input[name="personal_lock_tag"]:checked').val() == 0) {
				
				$('#critical_activity_requirements').removeClass("d-none")
		}
		else {
			$('#critical_activity_requirements').addClass("d-none")
		}
	}	

	document.addEventListener('DOMContentLoaded', initializeRadioButton, false);

	document.getElementById('lock_comment').addEventListener('click', function(e) {
		document.getElementById('supervisor_comments').setAttribute('disabled' , true);
		document.getElementById('lockButton').value='true';
		document.getElementById('lock_comment').classList.add("d-none")
	})

	function initiateCheckBoxOnRecall (el) {
		if (el[0].name === 'working_at_heights'){
			changeWorkingAtHeights()
		}
		else if (el[0].name === 'automotive_vehicles'){
			changeAutomotiveVehicles()
		}
		else if (el[0].name === 'mobile_equipment'){
			changeMobileEquipment()
		}
		else if (el[0].name === 'lock_tag_out_check'){
			changeLockTagOutCheck()
		}
		else if (el[0].name === 'lifting_operations'){
			changeLiftingOperations()
		}
		else if (el[0].name === 'confined_space'){
			changeConfinedSpace()
		}
		else if (el[0].name === 'machine_guarding'){
			changeMachineGuarding()
		}
		else if (el[0].name === 'ground_stability'){
			changeGroundStability()
		}
		else if (el[0].name === 'explosives'){
			changeExplosives()
		}
		else if (el[0].name === 'work_with_electricity'){
			changeWorkWithElectricity()
		}
	}

	// Adding required attribute
	function makeAttributeRequired(element) {
		element.removeAttribute('isrequired')
		element.setAttribute('required', '')
	}

	// Removing  required attribute
	function removeAttributeRequired(element) {
		element.setAttribute('isrequired','')
		element.removeAttribute('required')
	}

	function changeWorkingAtHeights(){
		el_1 = document.getElementById("calculated_fall_distance_yes")
		el_2 = document.getElementById("approved_rescue_plan_yes")
		if (document.getElementById("working_at_heights").checked == true) {
			document.getElementById("working_at_heights").value = '1'
			$('#workingAtHeights').removeClass("d-none")
			makeAttributeRequired(el_1)
			makeAttributeRequired(el_2)
		}
		else{
			$('#workingAtHeights').addClass("d-none")
			document.getElementById("working_at_heights").value = '0'
			el_1.checked = false
			removeAttributeRequired(el_1)
			removeAttributeRequired(el_2)
			document.getElementById("approved_rescue_plan_yes").checked = false
			document.getElementById("calculated_fall_distance_no").checked = false
			document.getElementById("approved_rescue_plan_no").checked = false
		}
		initRadioOnCriticalActivityRequirements()
	}

	function changeAutomotiveVehicles(){
		el_1 = document.getElementById("completed_pre_use_inspect_yes")
		el_2 = document.getElementById("vehicle_equipped_yes")
		if (document.getElementById("automotive_vehicles").checked == true) {
			$('#automotiveVehicles').removeClass("d-none")
			document.getElementById("automotive_vehicles").value = '1'
			makeAttributeRequired(el_1)
			makeAttributeRequired(el_2)
		}
		else{
			$('#automotiveVehicles').addClass("d-none")
			removeAttributeRequired(el_1)
			removeAttributeRequired(el_2)
			document.getElementById("automotive_vehicles").value = '0'
			document.getElementById("completed_pre_use_inspect_yes").checked = false
			document.getElementById("vehicle_equipped_yes").checked = false
			document.getElementById("completed_pre_use_inspect_no").checked = false
			document.getElementById("vehicle_equipped_no").checked = false
		}
		initRadioOnCriticalActivityRequirements()
	}

	function changeMobileEquipment(){
		el_1 = document.getElementById("trained_authorized_yes")
		el_2 = document.getElementById("adeq_separation_bw_people_yes")
		if (document.getElementById("mobile_equipment").checked == true) {
			$('#mobileEquipment').removeClass("d-none")
			document.getElementById("mobile_equipment").value = '1'
			makeAttributeRequired(el_1)
			makeAttributeRequired(el_2)
		}
		else{
			$('#mobileEquipment').addClass("d-none")
			document.getElementById("mobile_equipment").value = '0'
			removeAttributeRequired(el_1)
			removeAttributeRequired(el_2)
			document.getElementById("trained_authorized_yes").checked = false
			document.getElementById("adeq_separation_bw_people_yes").checked = false
			document.getElementById("trained_authorized_no").checked = false
			document.getElementById("adeq_separation_bw_people_no").checked = false
		}
		initRadioOnCriticalActivityRequirements()
	}

	function changeLockTagOutCheck(){
		el_1 = document.getElementById("verified_isolation_yes")
		el_2 = document.getElementById("individual_lock_yes")
		if (document.getElementById("lock_tag_out_check").checked == true) {
			$('#lockTagOutCheck').removeClass("d-none")
			document.getElementById("lock_tag_out_check").value = '1'
			makeAttributeRequired(el_1)
			makeAttributeRequired(el_2)
		}
		else{
			$('#lockTagOutCheck').addClass("d-none")
			document.getElementById("lock_tag_out_check").value = '0'
			removeAttributeRequired(el_1)
			removeAttributeRequired(el_2)
			document.getElementById("verified_isolation_yes").checked = false
			document.getElementById("individual_lock_yes").checked = false
			document.getElementById("verified_isolation_no").checked = false
			document.getElementById("individual_lock_no").checked = false
		}
		initRadioOnCriticalActivityRequirements()
	}

	function changeLiftingOperations(){
		el_1 = document.getElementById("lifting_equipment_appropriate_yes")
		el_2 = document.getElementById("area_access_secure_yes")
		if (document.getElementById("lifting_operations").checked == true) {
			$('#liftingOperations').removeClass("d-none")
			document.getElementById("lifting_operations").value = '1'
			makeAttributeRequired(el_1)
			makeAttributeRequired(el_2)
		}
		else{
			$('#liftingOperations').addClass("d-none")
			document.getElementById("lifting_operations").value = '0'
			removeAttributeRequired(el_1)
			removeAttributeRequired(el_2)
			document.getElementById("lifting_equipment_appropriate_yes").checked = false
			document.getElementById("area_access_secure_yes").checked = false
			document.getElementById("lifting_equipment_appropriate_no").checked = false
			document.getElementById("area_access_secure_no").checked = false
		}
		initRadioOnCriticalActivityRequirements()
	}

	function changeConfinedSpace(){
		el_1 = document.getElementById("approved_permit_yes")
		el_2 = document.getElementById("written_rescue_plan_yes")
		if (document.getElementById("confined_space").checked == true) {
			$('#confinedSpace').removeClass("d-none")
			document.getElementById("confined_space").value = '1'
			makeAttributeRequired(el_1)
			makeAttributeRequired(el_2)
		}
		else{
			$('#confinedSpace').addClass("d-none")
			document.getElementById("confined_space").value = '0'
			removeAttributeRequired(el_1)
			removeAttributeRequired(el_2)
			document.getElementById("approved_permit_yes").checked = false
			document.getElementById("written_rescue_plan_yes").checked = false
			document.getElementById("approved_permit_no").checked = false
			document.getElementById("written_rescue_plan_no").checked = false
		}
		initRadioOnCriticalActivityRequirements()
	}

	function changeMachineGuarding(){
		el_1 = document.getElementById("proper_guards_yes")
		el_2 = document.getElementById("removed_all_items_yes")
		if (document.getElementById("machine_guarding").checked == true) {
			$('#machineGuarding').removeClass("d-none")
			document.getElementById("machine_guarding").value = '1'
			makeAttributeRequired(el_1)
			makeAttributeRequired(el_2)
		}
		else{
			$('#machineGuarding').addClass("d-none")
			document.getElementById("machine_guarding").value = '0'
			removeAttributeRequired(el_1)
			removeAttributeRequired(el_2)
			document.getElementById("proper_guards_yes").checked = false
			document.getElementById("removed_all_items_yes").checked = false
			document.getElementById("proper_guards_no").checked = false
			document.getElementById("removed_all_items_no").checked = false
		}
		initRadioOnCriticalActivityRequirements()
	}

	function changeGroundStability(){
		el_1 = document.getElementById("ground_support_installed_yes")
		el_2 = document.getElementById("support_controls_inspected_yes")
		if (document.getElementById("ground_stability").checked == true) {
			$('#groundStability').removeClass("d-none")
			document.getElementById("ground_stability").value = '1'
			makeAttributeRequired(el_1)
			makeAttributeRequired(el_2)
		}
		else{
			$('#groundStability').addClass("d-none")
			document.getElementById("ground_stability").value = '0'
			removeAttributeRequired(el_1)
			removeAttributeRequired(el_2)
			document.getElementById("ground_support_installed_yes").checked = false
			document.getElementById("support_controls_inspected_yes").checked = false
			document.getElementById("ground_support_installed_no").checked = false
			document.getElementById("support_controls_inspected_no").checked = false
		}
		initRadioOnCriticalActivityRequirements()
	}

	function changeExplosives(){
		el_1 = document.getElementById("caps_powder_stored_yes")
		el_2 = document.getElementById("proper_entry_protocol_yes")
		if (document.getElementById("explosives").checked == true) {
			$('#explosivesQuestions').removeClass("d-none")
			document.getElementById("explosives").value = '1'
			makeAttributeRequired(el_1)
			makeAttributeRequired(el_2)
		}
		else{
			$('#explosivesQuestions').addClass("d-none")
			document.getElementById("explosives").value = '0'
			removeAttributeRequired(el_1)
			removeAttributeRequired(el_2)
			document.getElementById("caps_powder_stored_yes").checked = false
			document.getElementById("proper_entry_protocol_yes").checked = false
			document.getElementById("caps_powder_stored_no").checked = false
			document.getElementById("proper_entry_protocol_no").checked = false
		}
		initRadioOnCriticalActivityRequirements()
	}

	function changeWorkWithElectricity(){
		el_1 = document.getElementById("equipment_isolated_yes")
		el_2 = document.getElementById("personal_lock_tag_yes")
		if (document.getElementById("work_with_electricity").checked == true) {
			$('#workWithElectricity').removeClass("d-none")
			document.getElementById("work_with_electricity").value = '1'
			makeAttributeRequired(el_1)
			makeAttributeRequired(el_2)
		}
		else{
			$('#workWithElectricity').addClass("d-none")
			document.getElementById("work_with_electricity").value = '0'
			removeAttributeRequired(el_1)
			removeAttributeRequired(el_2)
			document.getElementById("equipment_isolated_yes").checked = false
			document.getElementById("personal_lock_tag_yes").checked = false
			document.getElementById("equipment_isolated_no").checked = false
			document.getElementById("personal_lock_tag_no").checked = false
		}
		initRadioOnCriticalActivityRequirements()
	}

	function draftPreProcess(parsedJSON) {
		unlock()
		var locked = parsedJSON.lockButton
		if(parsedJSON.formname === 'Vale N.A.P.G. FLHA' && locked === 'true') {
			setTimeout(() => {
				$('#lock_comment').click()
			}, 200);	
		}

		if(parsedJSON['signature_end_of_shift_review_img_time']){
			lock()
			setTimeout(() => {
				$('.deleteGalleryImage, .clear_sign').addClass('d-none')
			}, 2000);	
		}
		else{
			document.getElementById('lock_comment').classList.remove("d-none")
			$('#supervisor_comments').removeAttr("disabled")
		}
		$('.clear_sign').addClass('d-none')
	}

	function lock(lock_id, lock_time) {
		$('#lock_comment').click()
		inputs = document.querySelectorAll('.lock,.form-check-input')
		if(inputs){
			for (let obj of inputs){
				obj.setAttribute('disabled' , true);
				if (obj.classList.contains('sign')){
					obj.classList.add("d-none")
					obj.nextElementSibling.classList.remove("d-none")
					if(obj.getAttribute('signaturename')!="signature_end_of_shift_review"){
						obj.nextElementSibling.classList.add("read-only")  //signature comment only can show not edit
						obj.nextElementSibling.nextElementSibling.classList.add("d-none")
					}
				}
			}
		}

		imgUploads=document.querySelectorAll('.file-field')
		if(imgUploads){
			for (let obj of imgUploads){
				obj.parentElement.parentElement.classList.add("read-only")  //signature comment only can show not edit
			}
		}

		// lock images
		images = document.querySelectorAll('.image_input_to_lock')
		if(images){
			for (let obj of images) {
				obj.style.display = "none"
			}
		}

		$('.deleteGalleryImage').addClass('d-none')
		document.getElementById('addCrew').classList.add("d-none") 
		document.getElementById('removeCrew').classList.add("d-none") 
	}

	function unlock(){
		inputs = document.querySelectorAll('.lock,.form-check-input')
		if(inputs){
			for (let obj of inputs){
				obj.removeAttribute("disabled")
				if (obj.classList.contains('sign')){
					obj.classList.remove("d-none")
					obj.nextElementSibling.classList.add("d-none")
					if(obj.getAttribute('signaturename')!="signature_end_of_shift_review"){
						obj.nextElementSibling.classList.remove("read-only")  //signature comment only can show not edit
						obj.nextElementSibling.nextElementSibling.classList.remove("d-none")
					}
				}
			}
		}


		imgUploads=document.querySelectorAll('.file-field')
		if(imgUploads){
			for (let obj of imgUploads){
				obj.parentElement.parentElement.classList.remove("read-only")  //signature comment only can show not edit
			}
		}

		// unlock images
		images = document.querySelectorAll('.image_input_to_lock')
		if(images){
			for (let obj of images) {
				obj.style.display = ""
			}
		}

		$('.deleteGalleryImage').removeClass('d-none')
		document.getElementById('lockButton').value='false';	
		document.getElementById('addCrew').classList.remove("d-none") 
		document.getElementById('removeCrew').classList.remove("d-none") 
	}

	$( document ).ready(function() {
		addCrew(1)
	});
	
	function addCrew(crewNum,mode){
		const crewsModal = 
		`<div class="crewsection" value=${crewNum}>
			<h6 class="text-secondary pt-4"><span class='translate' data-i18n="2476" notes="Task"></span> ${crewNum}</h6>
			<div class="md-form">
				<input type="text" name="task_${crewNum}_desc" id="task_${crewNum}_desc" class="form-control lock" length="200" maxlength="200" required>
				<label for="task_${crewNum}_desc"><span class='translate' data-i18n="2477" notes="Task Description"></span></label>
			</div>
			<div class="md-form">
				<textarea type="text" name="task_${crewNum}_controls" id="task_${crewNum}_controls" class="form-control md-textarea lock" wrap="VIRTUAL" required></textarea>
				<label for="task_${crewNum}_controls"><span class='translate' data-i18n="2478" notes="Controls"></span></label>
			</div>
			<div class="md-form">
				<input type="text" name="task_${crewNum}_hazard" id="task_${crewNum}_hazard" class="form-control lock" length="200" maxlength="200" required>
				<label for="task_${crewNum}_hazard"><span class='translate' data-i18n="1320" notes="Hazard"></span></label>
			</div>
			<div class="md-form">
				<textarea type="text" name="task_${crewNum}_risk_involved" id="task_${crewNum}_risk_involved" class="form-control md-textarea lock" wrap="VIRTUAL" required></textarea>
				<label for="task_${crewNum}_risk_involved"><span class='translate' data-i18n="2479" notes="What is the risk to me/others?"></span></label>
			</div>
			<div class="md-form">
				<textarea type="text" name="task_${crewNum}_action_to_do" id="task_${crewNum}_action_to_do" class="form-control md-textarea lock" wrap="VIRTUAL" required></textarea>
				<label for="task_${crewNum}_action_to_do"><span class='translate' data-i18n="2480" notes="What am I doing about it?"></span></label>
			</div>
		</div>`

		$("#crews").append(crewsModal);
		if(crewNum && !mode){
			try {$('.translate').localize()} catch {}
		}	
	}

</script>

<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
