<?php	
    $strPageTitle = 'Technician Field Service Report';
    include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
    include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
    include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
    include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
    ?>

<main class="col containter-fluid mobile-content">
    <div class="row">
        <div class="col-12 mb-4">
            <div class="card mb-4">
                <div class="card-body">
                    <h6 class="text-secondary"><span class='translate' data-i18n="8966" notes="Technician Field Service Report"></span></h6>
                    <div class="pt-1 position-relative my-4">
                        <select name="draft" id="draft" class="select-single" onChange="getFormData(this)"  >
                        </select>
                        <label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
                    </div>
                    <form name="tfsr" id="TemplateForm" class="needs-validation" method="POST" action="#"
                        novalidate>
                        <?php include 'includes/CommonFormHeader.php' ?>

                        <!-- Shift -->
                        <h6><span class='translate' data-i18n="820" notes="Shift"></span></h6>
                        <div class="form-check custom-radio pl-0">
                            <input type="radio" class="form-check-input trans_input" id="shift_day" name="shift" value="1095" notes="Days" required>
                            <label class="form-check-label mr-2" for="shift_day"><span class='translate' data-i18n="1095" notes="Days"></span></label>

                            <input type="radio" class="form-check-input trans_input" id="shift_night" name="shift" value="1375" notes="Nights" required>
                            <label class="form-check-label mr-2" for="shift_night"><span class='translate' data-i18n="1375" notes="Nights"></span></label> 
                        </div>

                        <!-- Technician Name -->
                        <div class="pt-1 position-relative my-4">
                            <select name="technician_name" id="technician_name" class="select-single mobile-employee-select-single" required></select>
                            <label for="technician_name"><span class='translate' data-i18n="8967" notes="Technician Name"></span></label>
						</div>

                        <!-- Customer Company - text input -->
                        <div class="md-form">
							<input type="text" name="customer_company" id="customer_company" class="form-control" length="200" maxlength="200">
							<label for="customer_company"><span class='translate' data-i18n='8968' notes='Customer Company'></span></label>
						</div>

                        <!-- Customer Name  - text input -->
                        <div class="md-form">
							<input type="text" name="customer_name" id="customer_name" class="form-control" length="200" maxlength="200">
							<label for="customer_name"><span class='translate' data-i18n='8969' notes='Customer Name'></span></label>
						</div>
                        <!-- Customer Contact (phone/email) - text input -->
                        <div class="md-form">
							<input type="text" name="customer_contact" id="customer_contact" class="form-control" length="200" maxlength="200">
							<label for="customer_contact"><span class='translate' data-i18n='8970' notes='Customer Contact (phone/email)'></span></label>
						</div>

                        <!-- Service Summary -->
                        <h6 class="text-secondary pt-4"><span class='translate' data-i18n="8971" notes="Service Summary"></span></h6>

                        <div id="crewsections">       
                            <canvas id="canvas" style='display:none;'></canvas>
                            <div id="crews"></div>
                        </div>
                        <div id='addCrew' class='btn btn-sm btn-primary'><i class="fa fa-plus"></i> <span class='translate' data-i18n="8994" notes="Add Service"></span></div>
                        <div id='removeCrew' class='btn btn-sm btn-outline-primary'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n="8995" notes="Remove Service"></span> </div>
                        <div><br /></div>
                        <p>
                            <div id="total_service_hours"><label id='total_service_hours1'for="total_service_hours"><span class='translate' data-i18n="8996" notes="Total Service Hours"></span></label>
                            </div>
                            <div id="total_travel_hours"><label id='total_travel_hours1'for="total_travel_hours"><span class='translate' data-i18n="8997" notes="Total Travel Hours"></span></label>
                            </div>
                            <div id="total_delay_hours"><label id='total_delay_hours1'for="total_delay_hours"><span class='translate' data-i18n="8998" notes="Total Delay Hours"></span></label>
                            </div>
                            <div id="total_hours_worked"><label id='total_hours_worked1'for="total_hours_worked"><strong><span class='translate' data-i18n="8999" notes="Total Hours Worked"></span></strong></label>
                            </div>
                        </p>

                        <div class="md-form">
							<textarea name="comments" id="comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="comments"><span class='translate' data-i18n="81" notes="Comments"></span></label>
						</div>

                        <div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="850" notes="Supervisor Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='signature_supervisor'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_supervisor_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_supervisor" id="signature_supervisor" class='modalSignature' value=''>
							<input type="hidden" name="vector_employee" id='vector_employee' value=''>
							<input type="hidden" name="signature_supervisor_comments" id='signature_supervisor_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_supervisor_img_time" id="signature_supervisor_img_time" notes='signature_supervisor_img_time' readonly/></small>
						</div>

                        

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="9001" notes="Customer Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='signature_customer'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_customer_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_customer" id="signature_customer" class='modalSignature' value=''>
							<input type="hidden" name="vector_employee" id='vector_employee' value=''>
							<input type="hidden" name="signature_customer_comments" id='signature_customer_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_customer_img_time" id="signature_customer_img_time" notes='signature_customer_img_time' readonly/></small>
						</div>



                        <?php include 'includes/CommonFormFooter.php' ?>
                        <input type="hidden" name="formname" id="formname" note="Technician Field Service Report" class = "trans_input" value="8966" tag="8966" />
                        <input type="hidden" name="formtype" id="formtype" value="SUP" />
                        <input type="hidden" name="formid" id="formid" value="372438" />
                        <input type="hidden" name="version" id="version" value="1" />
                        <input type="hidden" name="_rev" id="_rev" value="" />
                        <input type="hidden" name="_id" id="_id" value="" />
                        <input type="hidden" name="keyField" id="keyField" value="site|workplace" />
                        <input type="hidden" name="draftField" id="draftField" value="draft" />
                        <input type="hidden" name="numCrews" id="numCrews" value='1' />
                        <input type="hidden" name="totalCrews" id="totalCrews" value='10' />     
                    </form>
                </div>
            </div>

        </div>
    </div>
</main>

<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>

<script>
    var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
			
			return true;
		}	
	}
    let lists = []
    openCacheData().then(()=>{
        lists = remoteData
        setOtherDefault(1)
        // draft variable to post load
        let draftRecords = ''
    })
    
    // Restrict decimals more than 2
    function setTwoNumberDecimal(el) {
        el.value = parseFloat(el.value).toFixed(2);
        CalculateTotals()
    };

    // Set default OTHER in the control
    function setOtherDefault(elementId ){  
        var otherList = [{ rld_option: null, rld_name : ['Other'] }]
        let controlId = 'unit_make_'+ elementId   
        let optionData = ``
        optionData += '<option></option>'
        otherList.forEach((data)=>{
            optionData += `<option value="Other" class="Other">${data.rld_name}</option>`
        })   
        document.getElementById(controlId).innerHTML = optionData     
        document.getElementById(controlId).parentNode.style.display = 'block'	
    }
   
    // function for calculate the totals and grand totals
    function CalculateTotals(){
        let serviceTotal = 0
        let travelTotal = 0
        let delayTotal = 0
        let grandTotal = 0
        let numCrews=parseInt(document.getElementById("numCrews").value)
        for (let i = 1; i <= numCrews; i++) {
            if(parseFloat(document.getElementById("service_" + i).value))
                serviceTotal += parseFloat(document.getElementById("service_" + i).value)
            if(parseFloat(document.getElementById("travel_" + i).value))
                travelTotal += parseFloat(document.getElementById("travel_" + i).value)
            if(parseFloat(document.getElementById("delay_" + i).value))
                delayTotal += parseFloat(document.getElementById("delay_" + i).value)
        }        
        document.getElementById('total_service_hours').innerHTML = i18next.t('8996')+" " + serviceTotal.toFixed(2) 
        document.getElementById('total_travel_hours').innerHTML = i18next.t('8997')+" " + travelTotal.toFixed(2) 
        document.getElementById('total_delay_hours').innerHTML = i18next.t('8998')+" " + delayTotal.toFixed(2) 
        grandTotal = (serviceTotal + travelTotal + delayTotal).toFixed(2) 
        document.getElementById('total_hours_worked').innerHTML = "<strong>"+i18next.t('8999')+" " + grandTotal + "</strong>" 
    }

    // function to Bind On save from draft
    function unitModelOnRebind(){
        if(draftRecords){
            numCrews=parseInt(document.getElementById('numCrews').value)
            for (let i = 1; i <= numCrews; i++) {            
                unitID = draftRecords['unit_id_' + i].toUpperCase()            
                unit_make = draftRecords['unit_make_' + i].toUpperCase()            
                other_unit_make = draftRecords['other_unit_make_' + i].toUpperCase()  
                
                controlID = 'unit_make_' + i
                if(unit_make!= 'OTHER'){
                    findMachinesOnRebind(unitID, controlID, unit_make)
                    hideOtherControl(i)
                }
                else{
                    setOtherDefault(i)
                    validateOtherandHideOnRebind(i, unit_make) 
                }
                
            }
        }    
    }

    // remove a service 
    document.getElementById('removeCrew').addEventListener('click',(e)=>{
        CalculateTotals()
    })

    // get machines and bind to the control on rebind
    function findMachinesOnRebind(machNumber, controlId, unit_make) {
        mach = []
        tfsr_site = document.getElementById('site').value
        tfsr_job = document.getElementById('job_number').value
        if(tfsr_site && tfsr_job) {
            lists[40]['preopEquipmentSiteJob'].forEach((data)=>{
                if(data.psj_rld_site_id == tfsr_site && !data.psj_rld_job_id ) {
                    if(data.pet_equipment_identifier && machNumber === data.pet_equipment_identifier.toUpperCase()) {
                        mach.push({
                            unit_id: data.pet_equipment_identifier,
                            unit_make: data.pet_poe_id
                        })
                    }
                }
                if(data.psj_rld_site_id == tfsr_site && data.psj_rld_job_id == tfsr_job) {
                    if(data.pet_equipment_identifier && machNumber === data.pet_equipment_identifier.toUpperCase()) {
                        mach.push({
                            unit_id: data.pet_equipment_identifier,
                            unit_make: data.pet_poe_id
                        })
                    }
                }
                if(!data.psj_rld_job_id && !data.psj_rld_site_id) {
                    if(data.pet_equipment_identifier && machNumber === data.pet_equipment_identifier.toUpperCase()) {
                        mach.push({
                            unit_id: data.pet_equipment_identifier,
                            unit_make: data.pet_poe_id
                        })
                    }
                }
            })
        }        
        
        if(mach.length > 0){
            let opts = ''
            if(mach.length > 1){
                opts += '<option></option>'
            }
            mach.forEach((rec) =>{
                let equipname = getMachineName(rec.unit_make)
                opts += `<option value='${rec.unit_make}'>${equipname}</option>`	
            })
           
            opts += `<option value = "Other">Other</option>`
            document.getElementById(controlId).innerHTML = opts
            if(mach.length == 1){
                document.getElementById(controlId).nextSibling.nextSibling.nextSibling.classList.add('filled')
            }
            document.getElementById(controlId).parentNode.style.display = 'block'	      	
            document.getElementById(controlId).value = unit_make      	
        }
        else {       
            let opts = `<option value = "Other">Other</option>`
            document.getElementById(controlId).innerHTML = opts       
            let elementID = controlId.split("_").pop()
            setOtherDefault(elementID)
        }
    }

    // get machines and bind to the control
    function findMachines(machNumber,  controlId) {
        tfsr_site = document.getElementById('site').value
        tfsr_job = document.getElementById('job_number').value
        mach = []
        if(tfsr_site && tfsr_job) {
            lists[40]['preopEquipmentSiteJob'].forEach((data)=>{
                if(data.psj_rld_site_id == tfsr_site && !data.psj_rld_job_id ) {
                    if(data.pet_equipment_identifier && machNumber === data.pet_equipment_identifier.toUpperCase()) {
                        mach.push({
                            unit_id: data.pet_equipment_identifier,
                            unit_make: data.pet_poe_id
                        })
                    }
                }
                if(data.psj_rld_site_id == tfsr_site && data.psj_rld_job_id == tfsr_job) {
                    if(data.pet_equipment_identifier && machNumber === data.pet_equipment_identifier.toUpperCase()) {
                        mach.push({
                            unit_id: data.pet_equipment_identifier,
                            unit_make: data.pet_poe_id
                        })
                    }
                }
                if(!data.psj_rld_job_id && !data.psj_rld_site_id) {
                    if(data.pet_equipment_identifier && machNumber === data.pet_equipment_identifier.toUpperCase()) {
                        mach.push({
                            unit_id: data.pet_equipment_identifier,
                            unit_make: data.pet_poe_id
                        })
                    }
                }
            })
        }

        if(mach.length > 0){
            let opts = ''
            if(mach.length > 1){
                opts += '<option></option>'
            }
            mach.forEach((rec) =>{
                let equipname = getMachineName(rec.unit_make)
                opts += `<option value='${rec.unit_make}'>${equipname}</option>`	
            })
           
            opts += `<option value = "Other">Other</option>`
            document.getElementById(controlId).innerHTML = opts
            if(mach.length == 1){
                document.getElementById(controlId).nextSibling.nextSibling.nextSibling.classList.add('filled')
            }
            document.getElementById(controlId).parentNode.style.display = 'block'	      	
        }
        else {              
            let elementID = controlId.split("_").pop()
            setOtherDefault(elementID)
        }
    }

    // get machine/equipment name
    function getMachineName(type) {
        let mname = ''
        lists[23]['PreOpEquipment'].forEach((data)=>{
        if(data.poe_id === type) 
            mname = data.poe_equip_description
        })
        return mname
    } 

    // hiding the other unit textbox 
    function hideOtherControl(elementID){
        $("#other_unit_make_id_"+elementID).hide()
        $("#other_unit_make_"+elementID).prop('required',false)
        $("#other_unit_make_"+elementID).val('').parent().find('label').removeClass('active filled')
    }

    // // validate and hide the other input field
    function validateOtherandHide(elementID){        
        $("#other_unit_make_"+elementID).prop('required',false)      
        unit_make = document.getElementById('unit_make_'+elementID).value
        if(checkSingleSelectOtherExists('unit_make_'+elementID, unit_make)){
            $("#other_unit_make_id_"+elementID).show()
            $("#other_unit_make_"+elementID).prop('required',true)
        }else{
            $("#other_unit_make_id_"+elementID).hide()
            $("#other_unit_make_"+elementID).prop('required',false)
            $("#other_unit_make_"+elementID).val('').parent().find('label').removeClass('active filled')
        }
    }

    // function calling on rebind from draft if other
    function validateOtherandHideOnRebind(elementID , unit_make){        
        $("#other_unit_make_"+elementID).prop('required',false)       
        if(checkSingleSelectOtherExists('unit_make_'+elementID, unit_make)){
            $("#other_unit_make_id_"+elementID).show()
            $("#other_unit_make_"+elementID).prop('required',true)
            $("#unit_make_"+elementID).val('Other') 
        }else{
            $("#other_unit_make_id_"+elementID).hide()
            $("#other_unit_make_"+elementID).prop('required',false)
            $("#other_unit_make_"+elementID).val('').parent().find('label').removeClass('active filled')
        }
    }

    // calling on pre load of the form on draft mode and set the records from the draft for the post page process
    function draftPreProcess(parsedJSON){
        draftRecords = parsedJSON
    }

    // reload page from Draft mode 
    function draftPostProcess(){      
        unitModelOnRebind()
        CalculateTotals() // calculate on load from draft

    }

    $( document ).ready(function() {
		addCrew(1)
	});
	
    function addCrew(crewNum,mode){
		const crewsModal = 
		`<div class="crewsection" value=${crewNum}>
            <h6 class="text-secondary pt-4"><span class='translate text-secondary pt-4"' data-i18n="3031" notes="Service"></span> ${crewNum}</h6>
            <!-- Service Type - select - required -->
            <div class="pt-1 position-relative my-4">
                <select name="service_type_${crewNum}" id="service_type_${crewNum}" class="select-single mobile-servicetype-select" required>
                </select>
                <label for="service_type_${crewNum}"><span class='translate' data-i18n="8972" notes="Service Type"></span></label>
            </div>
        
            <!-- Unit ID - text input (same as pre-op) -->
            <div class="pt-1 position-relative my-4 md-form">
                <label for="unit_id_${crewNum}"><span class='translate' data-i18n="8984" notes="Unit ID"></span></label>
                <input type="text" name="unit_id_${crewNum}" id="unit_id_${crewNum}" class="form-control unitid" length="200" maxlength="200"></input>
            </div>

            <!-- Unit Make/Model - select (same as pre-op) + have "Other" option in the drop-down if no Unit ID is entered -->  
            <div class="pt-1 position-relative my-4">
                <select name="unit_make_${crewNum}" id="unit_make_${crewNum}" class="select-single other-select unitmake" required>
                </select>
                <label for="unit_make_${crewNum}"><span class='translate' data-i18n="8985" notes="Unit Make/Model"></span></label>
            </div>  

            <!-- other_unit_make_${crewNum} -->
            <div id="other_unit_make_id_${crewNum}" class="md-form" style="display:none">
                <input type="text" class="form-control" name="other_unit_make_${crewNum}" id = "other_unit_make_${crewNum}" length="200" maxlength="200" required>
                <label for="other_unit_make_${crewNum}"><span class='translate' data-i18n="9000" notes="Other Unit Make/Model"></span>
                </label>
            </div>

                                
            <!-- Unit Hours - number input  (with 2 decimals and only positive numbers) -->
            <div class="md-form">
                <input type="number" min='0' onchange="setTwoNumberDecimal(this)" onkeyup="if(this.value<0){this.value= this.value * -1}" step='0.01' name="unit_hours_${crewNum}" id="unit_hours_${crewNum}" class="form-control">
                <label for="unit_hours_${crewNum}"><span class='translate' data-i18n="8986" notes="Unit Hours"></span></label>
            </div>

            <!-- Equipment Status - select - required -->    
            <div class="pt-1 position-relative my-4">
                <select name="equipment_status_${crewNum}" id="equipment_status_${crewNum}" class="select-single mobile-equipment-status-select" required></select>
                <label for="equipment_status_${crewNum}"><span class='translate' data-i18n="3457" notes="Equipment Status"></span></label>
            </div>  

            <!-- Work Completed - text area - required -->
            <div class="md-form">
                <textarea name="work_completed_${crewNum}" id="work_completed_${crewNum}" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
                <label for="work_completed_${crewNum}"><span class='translate' data-i18n="941" notes="Work Completed"></span>
                </label>
            </div>

            <!-- Work Order / Purchase Order - text input -->
            <div class="md-form">
                <input type="text" name="work_order_${crewNum}" id="work_order_${crewNum}" class="form-control" length="200" maxlength="200">
                <label for="work_order_${crewNum}"><span class='translate' data-i18n='8990' notes='Work Order / Purchase Order'></span></label>
            </div>
            <!-- Work Order Item - text input -->
            <div class="md-form">
                <input type="text" name="work_order_item_${crewNum}" id="work_order_item_${crewNum}" class="form-control" length="200" maxlength="200">
                <label for="work_order_item_${crewNum}"><span class='translate' data-i18n='8991' notes='Work Order Item'></span></label>
            </div>

            <!-- Service - number input (with 2 decimals and only positive numbers) - required -->
            <div class="md-form">
                <input type="number" min='0' onchange="setTwoNumberDecimal(this)" onkeyup="if(this.value<0){this.value= this.value * -1}"  step='0.01' name="service_${crewNum}" id="service_${crewNum}" class="form-control" required>
                <label for="service_${crewNum}"><span class='translate' data-i18n="3031" notes="Service"></span></label>
            </div>
            <!-- Travel - number input (with 2 decimals and only positive numbers) -->
            <div class="md-form">
                <input type="number" min='0' onchange="setTwoNumberDecimal(this)" onkeyup="if(this.value<0){this.value= this.value * -1}"  step='0.01' name="travel_${crewNum}" id="travel_${crewNum}" class="form-control">
                <label for="travel_${crewNum}"><span class='translate' data-i18n="8992" notes="Travel"></span></label>
            </div>
            <!-- Delay - number input (with 2 decimals and only positive numbers) -->
            <div class="md-form">
                <input type="number" min='0' onchange="setTwoNumberDecimal(this)" onkeyup="if(this.value<0){this.value= this.value * -1}" step='0.01' name="delay_${crewNum}" id="delay_${crewNum}" class="form-control">
                <label for="delay_${crewNum}"><span class='translate' data-i18n="1582" notes="Delay"></span></label>
            </div>
            <!-- Pictures of Service Provided -->
            <div class="form-group photoImage" id="images_${crewNum}"> 
                <label class="d-block"><span class='translate' data-i18n="8993" notes="Pictures of Service Provided"></span></label>
                <canvas id="canvas${crewNum}" style='display:none;'></canvas>
                <div class="btn-group d-flex" role="group">
                    <div class="btn btn-block btn-outline-secondary file-field px-1">
                        <i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="Add Images"></span>
                        <input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
                    </div>
                </div>
                <!-- <div id="siteHelp" class="form-text text-muted" ></div> -->
                <div class="row photoGallery" id="galleryid${crewNum}"></div>
            </div>
        </div>`
		
		$("#crews").append(crewsModal);
        if(crewNum>1 && !mode){
            initializeSelect2Dynamic(`service_type_${crewNum}`)
            initializeSelect2Dynamic(`equipment_status_${crewNum}`)
            initializeSelect2Dynamic(`unit_make_${crewNum}`)
            formHeader.populateServiceTypeSelect(`service_type_${crewNum}`)
            formHeader.populateEquipmentStatusSelect(`equipment_status_${crewNum}`)      
            setOtherDefault(`${crewNum}`)
			addImagePicker('images_' + crewNum)
            try {$('.translate').localize()} catch {}
		}
        
        $(`#unit_make_${crewNum}`).change(function(e) {
            $(`#other_unit_make_${crewNum}`).prop('required',false)      
            if(checkSingleSelectOtherExists(`unit_make_${crewNum}`, $(this).val())){
                $(`#other_unit_make_id_${crewNum}`).show()
                $(`#other_unit_make_${crewNum}`).prop('required',true)
            }else{
                $(`#other_unit_make_id_${crewNum}`).hide()
                $(`#other_unit_make_${crewNum}`).prop('required',false)
                $(`#other_unit_make_${crewNum}`).val('').parent().find('label').removeClass('active filled')
            }       
        });

        // key up event to listen find the machine and bind
        document.getElementById(`unit_id_${crewNum}`).addEventListener('keyup',function(e){
            unitID = document.getElementById(`unit_id_${crewNum}`).value.toUpperCase()  
            controlID = `unit_make_${crewNum}` 
            findMachines(unitID,  controlID)     
            hideOtherControl(crewNum) 
        })

	}

$('#job_number').on("change", (event)=>{
	clearTFSRFields(event)
})

$('#site').on("change", (event)=>{
	clearTFSRFields(event)
})

function clearTFSRFields(event) {
    if(!event.currentTarget.value) {
        allElementsId = document.getElementsByClassName('unitid')
        allElementsMake = document.getElementsByClassName('unitid')
        numElements = allElementsId.length
        $('.unitid').each((rec)=>{
            $(`#unit_id_${rec+1}`).val("").parent().find('label').removeClass(['filled',"active"])
            $(`#unit_make_${rec+1}`).val("").trigger("change").parent().find('label').removeClass(['filled',"active"])
        })
    }
}

</script>
