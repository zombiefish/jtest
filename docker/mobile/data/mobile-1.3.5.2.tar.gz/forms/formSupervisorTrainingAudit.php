<?php	
  $strPageTitle = 'Supervisor Training Audit';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary"><span class='translate' data-i18n='1017' notes='Supervisor Training Audit'></span></h6>
          <div class="pt-1 position-relative my-4">
            <select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
            </select>
            <label for="draft"><span class='translate' data-i18n='1474' notes='Form Drafts'></span></label>
          </div>

          <form name="formSupervisorTraining" id="formSupervisorTraining" class="needs-validation" method="POST" action="#" novalidate>
          
						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1650' notes='Audit'></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="project_manager" id="project_manager" class="select-single mobile-supervisors-select" required>
							</select>
							<label for="project_manager"><span class='translate' data-i18n='761' notes='Project Manager'></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="auditor" id="auditor" class="select-single mobile-supervisors-select" tag="62" required>
							</select>
							<label for="auditor"><span class='translate' data-i18n='62' notes='Auditor'></span></label>
						</div>

					    <div class="form-group photoImage" id="info"> 
						    <label class="d-block"><span class='translate' data-i18n='1413' notes='Include Photos'></span></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n='2340' notes='ADD IMAGES'></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n='1389' notes='Please take scene pictures from all perspectives'></span></small>
							<div class="row photoGallery" id="galleryid"></div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='603' notes='Is the supervisor qualified in all appropriate supervising MTCU modules?'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="supervisor_common_core_yes" name="supervisor_common_core" value="1" required>
								<label class="form-check-label mr-2" for="supervisor_common_core_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="supervisor_common_core_no" name="supervisor_common_core" value="0">
								<label class="form-check-label mr-2" for="supervisor_common_core_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1640' notes='MTCU U6100 - U61008'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="mtcu_umodules_yes" name="mtcu_umodules" value="1" required>
								<label class="form-check-label mr-2" for="mtcu_umodules_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="mtcu_umodules_no" name="mtcu_umodules" value="0">
								<label class="form-check-label mr-2" for="mtcu_umodules_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='847' notes='Supervisor H&S Awareness in 5 Steps HSAT-S'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="supervisor_hs_awareness_yes" name="supervisor_hs_awareness" value="1" required>
								<label class="form-check-label mr-2" for="supervisor_hs_awareness_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="supervisor_hs_awareness_no" name="supervisor_hs_awareness" value="0">
								<label class="form-check-label mr-2" for="supervisor_hs_awareness_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='859' notes='Technica Supervisor Indoc TMSD-03'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="technica_indoc_yes" name="technica_indoc" value="1" required>
								<label class="form-check-label mr-2" for="technica_indoc_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="technica_indoc_no" name="technica_indoc" value="0">
								<label class="form-check-label mr-2" for="technica_indoc_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1641' notes='Completed Check the Beat?'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="check_the_beat_yes" name="check_the_beat" value="1" required>
								<label class="form-check-label mr-2" for="check_the_beat_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="check_the_beat_no" name="check_the_beat" value="0">
								<label class="form-check-label mr-2" for="check_the_beat_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='121' notes='Current First Aid w/CPR'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="first_aid_yes" name="first_aid" value="1" required>
								<label class="form-check-label mr-2" for="first_aid_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="first_aid_no" name="first_aid" value="0">
								<label class="form-check-label mr-2" for="first_aid_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='858' notes='Technica Site Specific Orientation'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="technica_site_orientation_yes" name="technica_site_orientation" value="1" required>
								<label class="form-check-label mr-2" for="technica_site_orientation_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="technica_site_orientation_no" name="technica_site_orientation" value="0">
								<label class="form-check-label mr-2" for="technica_site_orientation_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='79' notes='Client Site Specific Orientation'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="site_orientation_yes" name="site_orientation" value="1" required>
								<label class="form-check-label mr-2" for="site_orientation_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="site_orientation_no" name="site_orientation" value="0">
								<label class="form-check-label mr-2" for="site_orientation_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='80' notes='Client Trained Confined Space Awareness VCSA'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="confined_space_awareness_yes" name="confined_space_awareness" value="1" required>
								<label class="form-check-label mr-2" for="confined_space_awareness_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="confined_space_awareness_no" name="confined_space_awareness" value="0">
								<label class="form-check-label mr-2" for="confined_space_awareness_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>
		
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='81' notes='Comments'></span></h6>
						<div class="md-form">
							<textarea name="sts_feedback" id="sts_feedback" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="sts_feedback"><span class='translate' data-i18n='840' notes='STS Feedback'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1601' notes='Correction and Action Requirements'></span></h6>
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='915' notes='Were any areas of improvement identified?'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input radio-check" id="any_areas_of_improvement_identified_yes" name="any_areas_of_improvement_identified" value="1" required>
								<label class="form-check-label mr-2" for="any_areas_of_improvement_identified_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input radio-check" id="any_areas_of_improvement_identified_no" name="any_areas_of_improvement_identified" value="0">
								<label class="form-check-label mr-2" for="any_areas_of_improvement_identified_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>
						
						<div class='cond-form-check-area'> 	
							<div class="mb-4">
								<label class="d-block"><span class='translate' data-i18n='1602' notes='Is a follow up required with the employee'></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="follow_up_with_the_employee_yes" name="follow_up_with_the_employee" value="1" required>
									<label class="form-check-label mr-2" for="follow_up_with_the_employee_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

									<input type="radio" class="form-check-input" id="follow_up_with_the_employee_no" name="follow_up_with_the_employee" value="0">
									<label class="form-check-label mr-2" for="follow_up_with_the_employee_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
								</div>
							</div>

							<div class="mb-4">
								<label class="d-block"><span class='translate' data-i18n='1603' notes='Is a follow up required with the task'></span></label>
								<div class="form-check custom-radio pl-0">
									<input type="radio" class="form-check-input" id="follow_up_with_the_task_yes" name="follow_up_with_the_task" value="1" required>
									<label class="form-check-label mr-2" for="follow_up_with_the_task_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

									<input type="radio" class="form-check-input" id="follow_up_with_the_task_no" name="follow_up_with_the_task" value="0">
									<label class="form-check-label mr-2" for="follow_up_with_the_task_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
								</div>
							</div>
						</div>		

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag = "1017" class = "trans_input" value="1017" note="SUPERVISOR TRAINING AUDIT" />
						<input type="hidden" name="formtype" id="formtype" value="STS" />
						<input type="hidden" name="formid" id="formid" value="236773"/>
						<input type="hidden" name="version" id="version" value="11" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|auditor" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}	
	}
	function radioButtonCheck() {
		$('.radio-check').change((e) =>{
			requiredRadio(e.currentTarget.defaultValue)
		})
	};
	document.addEventListener('DOMContentLoaded', radioButtonCheck, false);
</script>
