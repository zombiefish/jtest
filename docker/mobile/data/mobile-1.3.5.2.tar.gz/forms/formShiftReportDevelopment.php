<?php	
  $strPageTitle = 'Shift Report Development';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>
<input type="hidden" value = "<?php	echo(_RESOURCEDOMAIN);?>"/>
<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
					<h6 class="text-secondary"><span class='translate' data-i18n='1231' notes = 'Shift Report Development'></span></h6>
					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
						</select>
						<label for="draft"><span class='translate' data-i18n='1474' notes = 'Form drafts'></span></label>
					</div>

					<form name="TemplateForm" id="TemplateForm" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>
					
						<label class="d-block"><span class='translate' data-i18n='820' notes = 'Shift'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="shift_days" name="shift" value="1095" required>
								<label class="form-check-label mr-2" for="shift_days"><span class='translate' data-i18n='1095' notes = 'Days'></span></label>

								<input type="radio" class="form-check-input trans_input" id="shift_nights" name="shift" value="1375">
								<label class="form-check-label mr-2" for="shift_nights"><span class='translate' data-i18n='1375' notes = 'Nights'></span></label> 
							</div>

						<div class="md-form">
							<input type="text" name="safety_topic" id="safety_topic" class="form-control" length="200" maxlength="200" required>
							<label for="safety_topic"><span class='translate' data-i18n='815' notes = 'Safety Topic'></span></label>
						</div>

						<div class="md-form">
							<textarea name="safety_notes" id="safety_notes" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="safety_notes"><span class='translate' data-i18n='809' notes = 'Safety Notes Log'></span></label>
						</div>

						<div class="md-form">
							<textarea name="safety_communications" id="safety_communications" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="safety_communications"><span class='translate' data-i18n='85' notes = 'Communications from Previous Shift'></span></label>
						</div>						

						<canvas id="canvas" style='display:none;'></canvas>
						
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1556' notes = 'Workplace Details'></span></h6>

						<div id='workPlaces'></div>
						
						<!--  Buttons for Add and Remove Shifts-->
						<div id='addCrew' class='btn btn-sm btn-primary'><i class="fa fa-plus"></i> <span class='translate' data-i18n='1211' notes = 'Add Workplace'></span></div>
						<div id='removeCrew' class='btn btn-sm btn-outline-primary'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n='2378' notes = 'Remove Workplace'></span></div>

						<div class="md-form">
							<textarea name="next_shift_requirements" id="next_shift_requirements" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="next_shift_requirements"><span class='translate' data-i18n='661' notes = 'Next Shift Requirements'></span></label>
						</div>

						<div class="md-form">
							<textarea name="extras_delays" id="extras_delays" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="extras_delays"><span class='translate' data-i18n='477' notes = 'Extras and/or Delays'></span></label>
						</div>

						<div class="md-form">
							<textarea name="end_state_summary" id="end_state_summary" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="end_state_summary"><span class='translate' data-i18n='425' notes = 'End-States Summary'></span></label>
						</div>

						<div id='equipments'></div>

						<!--  Buttons for Add and Remove Shifts-->
						<div id='addEquipment' class='btn btn-sm btn-primary'><i class="fa fa-plus"></i> <span class='translate' data-i18n='1234' notes = 'Add Equipment'></span></div>
						<div id='removeEquipment' class='btn btn-sm btn-outline-primary'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n='1587' notes = 'Remove Equipment'></span></div>

						<div class="md-form">
							<textarea name="eq_down_details" id="eq_down_details" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="eq_down_details"><span class='translate' data-i18n='430' notes = 'Equipment Down Details'></span></label>
						</div>

						<div class="md-form">
							<textarea name="eq_end_state" id="eq_end_state" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="eq_end_state"><span class='translate' data-i18n='431' notes = 'Equipment End-State Summary'></span></label>
						</div>

						<div class="md-form">
							<textarea name="eq_parts_required" id="eq_parts_required" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="eq_parts_required"><span class='translate' data-i18n='452' notes = 'Equipment Parts Required'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='81' notes = 'Comments'></span></h6>
						<div class="md-form">
							<textarea name="positive_recognition" id="positive_recognition" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="positive_recognition"><span class='translate' data-i18n='81' notes = 'Comments'></span></label>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag = "1231" class = "trans_input" value="1231" note="Shift Report Development" />
						<input type="hidden" name="formtype" id="formtype" value="SR" />
						<input type="hidden" name="formid" id="formid" value="333851" />
						<input type="hidden" name="version" id="version" value="9" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
						<input type="hidden" name="numCrews" id="numCrews" value='1' />
						<input type="hidden" name="totalCrews" id="totalCrews" value='15' />
						<input type="hidden" name="numEquipments" id="numEquipments" value='0' />
						<input type="hidden" name="totalEquipments" id="totalEquipments" value='15' />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript">

function fetchSite() {
 return	` where Filter = 'Fraser Mine'`
}
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');

			return true;
		}	
	}
</script>
<script src="/js/groupEquipment.js"></script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>

<script>
	let equipment = ''
	const totalEquipments = document.getElementById('totalEquipments').value
	document.getElementById('removeEquipment').classList.add('d-none')

// add an Equipment
document.getElementById('addEquipment').addEventListener('click',(e)=>{
	equipment = parseInt(document.getElementById('numEquipments').value)
	if(equipment < totalEquipments) {
		addEquipment(equipment)
		equipment++
		if(equipment == totalEquipments){
			e.currentTarget.classList.add('d-none')
		}
		document.getElementById('numEquipments').value = equipment
	} 
	if(equipment > 0 && equipment <= totalEquipments)
  	 document.getElementById('removeEquipment').classList.remove('d-none')
	
})

function addEquipment(equipment,mode){
	groupName=String.fromCharCode(97 + parseInt(equipment))
	capitalGroupName=groupName.toUpperCase()
		
	const equipmentsModal = 
	`<div class="equipmentsection" value=${equipment}>
			<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1588' notes = 'Equipment Group'></span> ${capitalGroupName}</h6>
			<div class="pt-1 position-relative my-4">
				<select name="equipment_group_${groupName}" id="equipment_group_${groupName}" class="select-multiple shift-report" multiple required>
				</select>
				<label for="equipment_group_${groupName}"><span class='translate' data-i18n="9559" notes="Please select Site and Department/Job to select Equipment></span></label>
			</div>

			<div class="pt-1 position-relative my-4">
				<select name="equipment_group_${groupName}_location" id="equipment_group_${groupName}_location" class="select-single mobile-equipmentlocation" required>
				</select>
				<label for="equipment_group_${groupName}_location"><span class='translate' data-i18n='629' notes = 'Location'></span></label>
			</div>

			<div class="md-form">
				<input type="text" name="equipment_group_${groupName}_details" id="equipment_group_${groupName}_details" class="form-control" length="200" maxlength="200" required>
				<label for="equipment_group_${groupName}_details"><span class='translate' data-i18n='22' notes = 'Additional Details'></span></label>
			</div>
		</div>	`
	
	$("#equipments").append(equipmentsModal);
	if(!mode){
		initializeSelect2Dynamic(`equipment_group_${groupName}`)
		initializeSelect2Dynamic(`equipment_group_${groupName}_location`)
		preop_site_job_equipment_select()
		formHeader.populateEquipmentLocationSelect($("#site").val(),`equipment_group_${groupName}_location`)
		try {$('.translate').localize()} catch {}
	}		
}

// remove an Equipment 
document.getElementById('removeEquipment').addEventListener('click',(e)=>{
	let myEquipment = $(`.equipmentsection[value="${equipment}"]`)
	myEquipment.remove()
	equipment--
	document.getElementById('numEquipments').value = equipment
	if(equipment > 0 && equipment <= totalEquipments)
	document.getElementById('removeEquipment').classList.remove('d-none')
	document.getElementById('addEquipment').classList.remove('d-none')
	if(equipment >= totalEquipments)
	document.getElementById('addEquipment').classList.add('d-none')
	if(equipment === 0)
	document.getElementById('removeEquipment').classList.add('d-none')
})

// Populate the Form from a Draft by showing the sections activated in FormHandler
function populateEquipmentDynamicForm(numEquipments,totalEquipments) {
	$(`.equipmentsection`).remove()
	if(numEquipments > 0 && numEquipments <= totalEquipments){
		document.getElementById('removeEquipment').classList.remove('d-none')
	}	
	if(numEquipments >= totalEquipments){
		document.getElementById('addEquipment').classList.add('d-none')
	}	
	for (let a = 1; a <= numEquipments; a++) {
		addEquipment(a-1,"loadDraft")
	}
}

$( document ).ready(function() {
    addCrew(1)
});

function addCrew(crewNum,mode){
	const workPlacesModal = 
	`<div class="crewsection" value=${crewNum}>
		<h6 class="text-secondary pt-4"><span class='translate' data-i18n='959' notes = 'Workplace'></span> ${crewNum}</h6>
		<div class="pt-1 position-relative my-4">
			<select name="workplace_${crewNum}" id="workplace_${crewNum}" class="select-multiple mobile-employee-select" multiple required>
			</select>
			<label for="workplace_${crewNum}"><span class='translate' data-i18n='1557' notes = 'Workers'></span></label>
		</div>

		<div class="pt-1 position-relative my-4">
			<select name="workplace_${crewNum}_hours" id="workplace_${crewNum}_hours" class="select-single mobile-hourssummary-select" required>
			</select>
			<label for="workplace_${crewNum}_hours"><span class='translate' data-i18n='526' notes = 'Hours'></span></label>
		</div>

		<div class="pt-1 position-relative my-4">
		<select name="workplace_${crewNum}_position" id="workplace_${crewNum}_position" class="select-multiple mobile-employeeposition-select" multiple >
			</select>
			<label for="workplace_${crewNum}_position"><span class='translate' data-i18n='750' notes = 'Position Details'></span></label>
		</div>

		<div class="md-form">
			<textarea name="work_completed_${crewNum}" id="work_completed_${crewNum}" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
			<label for="work_completed_${crewNum}"><span class='translate' data-i18n='941' notes = 'Work Completed'></span></label>
		</div>

		<div class="form-group photoImage" id="workplace_pictures_${crewNum}"> 
			<label class="d-block"><span class='translate' data-i18n='2377' notes = 'Workplace Photos'></span></label>
			<canvas id="canvas_${crewNum}" style='display:none;'></canvas>
			<div class="btn-group d-flex" role="group">
				<div class="btn btn-block btn-outline-secondary file-field px-1">
					<i class="fa fa-upload"></i> <span class='translate' data-i18n='2340' notes = 'Add Images'></span>
					<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
				</div>
			</div>
			<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n='1389' notes = 'Please take scene pictures from all perspectives'></span></small>
			<div class="row photoGallery" id="wpgalleryid_${crewNum}"></div>
		</div>
	</div>	`
	
	$("#workPlaces").append(workPlacesModal);
	if(crewNum>1 &&!mode){
		initializeSelect2Dynamic(`workplace_${crewNum}`)
		initializeSelect2Dynamic(`workplace_${crewNum}_hours`)
		initializeSelect2Dynamic(`workplace_${crewNum}_position`)
		formHeader.populateEmployeeSelect(`workplace_${crewNum}`)
		formHeader.populateHoursSummarySelect(`workplace_${crewNum}_hours`)
		formHeader.populateEmployeePositionSelect(`workplace_${crewNum}_position`)
		addImagePicker('workplace_pictures_' + crewNum)
		try {$('.translate').localize()} catch {}
	}
}

function clearEquipmentFields(id) {
	let convert = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v"]
	if(id === 'job_number' || id === 'site'){
		$('.shift-report').each((rec)=>{
			all_rest = []
			let optionData = `<select name="equipment_group_${rec}" id="equipment_group_${rec}" class="select-multiple shift-report" multiple>`
			all_rest.forEach((data)=>{
				optionData += `<option value="${data.id}">${data.text}</option>`
			})
			optionData += `</select>`
			$(`#equipment_group_${convert[rec]}`).html(optionData)
			if(main_current_draft_object){
				main_current_draft_object[`equipment_group_${convert[rec]}`] = null
			}
			$(`#equipment_group_${convert[rec]}`).parent().find('label').html(i18next.t("9559"))
			$(`#equipment_group_${convert[rec]}`).val("").trigger("change").parent().find('label').removeClass(['filled',"active"])
		})
	}
}

// END of Section RMR
</script>