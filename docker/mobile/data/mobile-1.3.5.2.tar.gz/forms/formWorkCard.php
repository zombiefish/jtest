<?php	
  $strPageTitle = 'Work Card';include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
					<h6 class="text-secondary"><span class='translate' data-i18n='8582' notes='Work Card'></span></h6>
					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
						</select>
						<label for="draft"><span class='translate' data-i18n='1474' notes='Form Drafts'></span></label>
					</div>

					<form name="formWorkCard" id="formWorkCard" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeaderLineup.php' ?>

						<div class="md-form">
							<textarea name="comments" id="comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="comments"><span class='translate' data-i18n='81' notes='Comments'></span></label>
						</div>

						<div class="form-check pl-0">
							<input type="checkbox" class="form-check-input ml-0" name="committed" id="committed" value = '0' onchange="boxChecked(event.target)" required>
							<label class="form-check-label" for="committed"><span class='translate' data-i18n="8493" notes="I am committed to work safely!"></span></label>
						</div>

						<div class="col-3 offset-9">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 306.15 306.77">
							<defs>
								<style>
								.a {fill: #076633;}
								.b {fill: #0f70b7;}
								.c {fill: #f8ea19;}
								.d {fill: #be1522;}
								.e, .f, .g {fill: none;stroke-miterlimit: 10;}
								.e, .f {stroke: #231f20;}
								.f {stroke-linecap: round;}
								.g { stroke: #000;}
								</style>
							</defs>
							<g>
								<g>
								<g>
									<path class="a" d="M268.21,135.32a118.24,118.24,0,0,1,1.39,18.07A116.5,116.5,0,0,1,157.66,269.81l-17.51-22.05a96.61,96.61,0,0,0,12.93.86,95.24,95.24,0,0,0,95.23-95.23Z"/>
									<path class="b" d="M268.21,135.32l-19.9,18.07a95.21,95.21,0,0,0-91.79-95.16h0L140.14,37.58a117.73,117.73,0,0,1,12.94-.71A116.54,116.54,0,0,1,268.21,135.32Z"/>
									<path class="b" d="M248.31,153.39l-35.37-10.34A61.4,61.4,0,0,0,152.5,92.42a62.37,62.37,0,0,0-7.14.41l11.16-34.6A95.21,95.21,0,0,1,248.31,153.39Z"/>
									<path class="a" d="M212.94,143.05l35.37,10.34a95.24,95.24,0,0,1-95.23,95.23,96.61,96.61,0,0,1-12.93-.86h0l17.6-32.56,0-.22a61.44,61.44,0,0,0,55.22-71.92Z"/>
									<path class="c" d="M157.72,215l0,.22-17.6,32.56h0a94.12,94.12,0,0,1-79-69.32h0c26.06-16.85,30.67-34.08,30.67-34.08h0a61.4,61.4,0,0,0,60.65,70.84C154.26,215.19,156,215.12,157.72,215Z"/>
									<path class="c" d="M140.15,247.76l17.51,22.05c-1.52.07-3,.1-4.58.1A115.73,115.73,0,0,1,42,188.74a140,140,0,0,0,19.15-10.31h0A94.12,94.12,0,0,0,140.15,247.76Z"/>
									<path class="d" d="M140.14,37.58l16.38,20.64h0c-1.14,0-2.29-.07-3.44-.07A95.26,95.26,0,0,0,62,125.56c-4.86,15.88-14.42,36.66-58.1,42.4h-.1q-.69-7.2-.7-14.58c0-3,.09-6,.27-9,33.92-4.81,39.17-27.84,39.17-27.84A116.62,116.62,0,0,1,140.14,37.58Z"/>
									<path class="d" d="M156.52,58.23l-11.16,34.6h0a61.39,61.39,0,0,0-53.51,51.51h0s-4.61,17.23-30.67,34.08A140,140,0,0,1,42,188.74a204.07,204.07,0,0,1-31.66,10.93A149.23,149.23,0,0,1,3.78,168h.1c43.68-5.74,53.24-26.52,58.1-42.4a95.26,95.26,0,0,1,91.1-67.4C154.23,58.16,155.38,58.18,156.52,58.23Z"/>
								</g>
								<g>
									<path class="e" d="M42.52,116.51a116.55,116.55,0,0,1,225.69,18.81,118.24,118.24,0,0,1,1.39,18.07A116.5,116.5,0,0,1,157.66,269.81c-1.52.07-3,.1-4.58.1A115.73,115.73,0,0,1,42,188.74"/>
									<path class="e" d="M62,125.56a95.26,95.26,0,0,1,91.1-67.4c1.15,0,2.3,0,3.44.07a95.23,95.23,0,0,1-3.44,190.39,96.61,96.61,0,0,1-12.93-.86,94.12,94.12,0,0,1-79-69.32"/>
									<path class="e" d="M145.36,92.83a62.37,62.37,0,0,1,7.14-.41A61.39,61.39,0,0,1,157.72,215c-1.72.15-3.46.22-5.22.22a61.38,61.38,0,0,1-7.14-122.35"/>
									<polyline class="e" points="140.14 37.58 156.52 58.22 156.52 58.23 145.36 92.83 145.36 92.84"/>
									<polyline class="e" points="212.94 143.05 248.31 153.39 268.21 135.32"/>
									<polyline class="e" points="157.74 215.19 140.14 247.75 140.15 247.76 157.66 269.81 157.74 269.91"/>
									<path class="e" d="M91.84,144.35s-4.61,17.23-30.67,34.08A140,140,0,0,1,42,188.74a204.07,204.07,0,0,1-31.66,10.93"/>
									<path class="e" d="M62,125.56c-4.86,15.88-14.42,36.66-58.1,42.4"/>
									<path class="f" d="M3.35,144.35c33.92-4.81,39.17-27.84,39.17-27.84"/>
									<path class="e" d="M3.35,144.35A150.4,150.4,0,1,1,3.78,168q-.69-7.2-.7-14.58C3.08,150.36,3.17,147.34,3.35,144.35Z"/>
								</g>
								</g>
								<g>
								<path d="M166.66,164.28c-.92,1.76-10.38,20.3-10.38,20.3-2.16,2.77-6.08,3-7.93,0l-11.69-22s-.85-1.38-1.46,0-8.69,15.77-8.69,15.77l-4.7-5.31,27.47-50.53c1.53-2.77,4.84-2.85,6.68,0,2.42,3.73,14.7,29.07,14.7,29.07s1.92,2.83-1.54,2.52H145.05l3.3-7h12.08l-7.2-14.54s-1.11-1-1.57-.07-11.08,19.84-11.08,19.84a3.26,3.26,0,0,0-.15,3.54c1.15,1.77,10.62,19.92,10.62,19.92s1.53,2.47,2.76,0l9-17.92,9.24.15,12.77,23a41.86,41.86,0,1,0-4.79,5l-11.68-21.73S167.58,162.51,166.66,164.28Z"/>
								<path d="M180,186l6,11.19h7.76l-9-16.17A41,41,0,0,1,180,186Z"/>
								</g>
								<g>
								<circle class="g" cx="107.97" cy="89.48" r="16.5"/>
								<line class="g" x1="107.97" y1="79.22" x2="107.97" y2="72.98"/>
								<line class="g" x1="107.97" y1="105.98" x2="107.97" y2="99.73"/>
								<line class="g" x1="97.71" y1="89.48" x2="91.47" y2="89.48"/>
								<line class="g" x1="124.47" y1="89.44" x2="118.22" y2="89.44"/>
								</g>
								<g>
								<circle class="g" cx="80.54" cy="123.48" r="16.5"/>
								<line class="g" x1="88.8" y1="117.4" x2="93.82" y2="113.69"/>
								<line class="g" x1="67.25" y1="133.26" x2="72.28" y2="129.56"/>
								<line class="g" x1="74.46" y1="115.22" x2="70.75" y2="110.19"/>
								<line class="g" x1="90.36" y1="136.74" x2="86.65" y2="131.71"/>
								</g>
								<g>
								<circle class="g" cx="220.86" cy="114.85" r="16.5"/>
								<line class="g" x1="227.71" y1="107.22" x2="231.89" y2="102.58"/>
								<line class="g" x1="209.83" y1="127.12" x2="214" y2="122.47"/>
								<line class="g" x1="213.23" y1="107.99" x2="208.59" y2="103.82"/>
								<line class="g" x1="233.16" y1="125.85" x2="228.51" y2="121.67"/>
								</g>
								<g>
								<circle class="g" cx="227.42" cy="177.3" r="16.5"/>
								<line class="g" x1="234.27" y1="169.67" x2="238.45" y2="165.03"/>
								<line class="g" x1="216.39" y1="189.57" x2="220.56" y2="184.93"/>
								<line class="g" x1="219.79" y1="170.44" x2="215.14" y2="166.27"/>
								<line class="g" x1="239.71" y1="188.3" x2="235.07" y2="184.13"/>
								</g>
								<g>
								<circle class="g" cx="116.86" cy="223.34" r="16.5"/>
								<line class="g" x1="123.72" y1="215.71" x2="127.89" y2="211.06"/>
								<line class="g" x1="105.83" y1="235.61" x2="110.01" y2="230.96"/>
								<line class="g" x1="109.24" y1="216.48" x2="104.59" y2="212.31"/>
								<line class="g" x1="129.16" y1="234.34" x2="124.52" y2="230.16"/>
								</g>
								<g>
								<circle class="g" cx="121.95" cy="217.57" r="7.87"/>
								<line class="g" x1="125.22" y1="213.93" x2="127.21" y2="211.72"/>
								<line class="g" x1="116.69" y1="223.42" x2="118.68" y2="221.2"/>
								<line class="g" x1="118.31" y1="214.3" x2="116.1" y2="212.31"/>
								<line class="g" x1="127.81" y1="222.81" x2="125.6" y2="220.82"/>
								</g>
								<path  id="text-path" style="fill:none; stroke:none;" class="g" d="M33.15,112.71A126.27,126.27,0,1,1,33.82,199"/>
								<text style="font-family:Arial, Helvetica, sans-serif;">
								<textPath href="#text-path" class="translate" data-i18n="2819" note="INSPECTION">
								</textPath>
								<textPath href="#text-path" startOffset="25%" class="translate" data-i18n="8617" note="PLANNING">
								</textPath>
								<textPath href="#text-path" startOffset="55%" class="translate" data-i18n="8659" note="DECISION">
								</textPath>
								<textPath href="#text-path" startOffset="81%"  class="translate" data-i18n="8671" note="EXECUTION">
								</textPath>
							</g>
							</svg>
						</div>

					<canvas id="canvas" style='display:none;'></canvas>	

					<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1665' notes='Inspection'></span></h6>
						<hr style="border-color: #be1522; border-width: 2px;"/>
							<div class="pt-1 position-relative my-4">
								<select name="work_card_type" id="work_card_type" class="select-single mobile-workcardTtype-select" onChange="loadContents(this)" required>
								</select>
								<label for="work_card_type"><span class='translate' data-i18n='8494' notes='Work Card Type'></span></label>
							</div>
							
					<div id="loadContents"></div>
					<div id="crews"></div>
						<!--  Buttons for Add and Remove work_accomplished-->
						<div id='addCrew' class='btn btn-sm btn-primary'><i class="fa fa-plus"></i> <span class='translate' data-i18n='8561' notes='ADD WORK ACCOMPLISHED'></span></div>
						<div id='removeCrew' class='btn btn-sm btn-outline-primary'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n='8562' notes='REMOVE WORK ACCOMPLISHED'></span></div>
							<div class="md-form">
								<textarea name="materials_required" id="materials_required" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="materials_required"><span class='translate' data-i18n='8563' notes='Materials required for next shift'></span></label>
							</div>

							<?php include 'includes/CommonFormFooter.php' ?>

							<input type="hidden" name="formname" id="formname" class = "trans_input" value="8582" tag="8582" tag="Work Card" />
							<input type="hidden" name="formtype" id="formtype" value="SR" />
							<input type="hidden" name="formid" id="formid" value="372418" />
							<input type="hidden" name="version" id="version" value="1" />
							<input type="hidden" name="_rev" id="_rev" value="" />
							<input type="hidden" name="_id" id="_id" value="" />
							<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
							<input type="hidden" name="draftField" id="draftField" value="draft" />
							<input type="hidden" name="numCrews" id="numCrews" value="1" />
							<input type="hidden" name="totalCrews" id="totalCrews" value='10' />  							
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript">

	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
			$('#work_card_type').val("Correspondence")
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');

			return true;
		}	
	}
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
<script>
	let not_loadDraft = true
	document.getElementById('removeCrew').classList.add('d-none')

function lock(lock_id, lock_time) {
	document.getElementById(lock_id + "_time").parentElement.classList.remove('d-none')
	document.getElementById(lock_id + "_time").value = lock_time
	document.getElementById(lock_id).style.display = "none";

	inputs = document.getElementsByClassName(lock_id + '_lock')
	for (let obj of inputs){
		obj.setAttribute('disabled' , true);
		if (obj.classList.contains('sign')){
			$("#"+obj.id).off("click")
			$("#clear"+obj.id).off('click')
			$("#"+obj.id).next().addClass("read-only")  //signature comment only can show not edit
		}
	}
}

function boxChecked(e) {
	element = e
	if (element.checked){
		element.value = "1"

	}
	else {
		element.value = ""
	}	
}


function showHideCheckBox(e){
	element = e.target
	if (element.checked){
		element.parentElement.nextElementSibling.classList.remove('d-none')
		element.parentElement.nextElementSibling.firstElementChild.required = true
	} else {
		element.parentElement.nextElementSibling.classList.add('d-none')
		element.parentElement.nextElementSibling.firstElementChild.required = false
	}
	
	boxChecked(element)
}


function showHideRadio(e){
	element = e.target
	if(element.id=="activity_observed_safe_yes"){
		document.getElementById("reason_not_safe").value=""
		document.getElementById("reason_not_safe").parentElement.classList.add('d-none')
		element.parentElement.nextElementSibling.firstElementChild.required = false
	}
	else if (element.id=="activity_observed_safe_no"){
		document.getElementById("reason_not_safe").parentElement.classList.remove('d-none')
		element.parentElement.nextElementSibling.firstElementChild.required = true
	}
}

function draftPreProcess(parsedJSON) {
	$('#override').value=parsedJSON['override']

	if ($('#override').value==1){
		$('#lineup_workplace').classList.remove('d-none')
		$('#override').prop("checked", true);
	}

	not_loadDraft = false;
}

function draftPostProcess(parsedJSON){
	for(let i in parsedJSON){
		if(i.startsWith("lock_") && i.endsWith('_time') && parsedJSON[i]){
			lock(i.slice(0, -5),parsedJSON[i])
		}
	}

	if (parsedJSON.activity_observed_safe == "0") {
		document.getElementById("reason_not_safe").parentElement.classList.remove('d-none')
	}

	checkboxes = document.querySelectorAll('[type="checkbox"]')
	for (i of checkboxes) {
		if (parsedJSON[i.name]=="1") {
			i.parentElement.nextElementSibling.classList.remove('d-none')
			i.parentElement.nextElementSibling.firstElementChild.required = true
		}
	}

	radio_buttons = document.getElementsByClassName('custom-radio')
	for (i of radio_buttons) {
		col = i.firstElementChild.getAttribute("name")
		if (parsedJSON[col] == "8503" || parsedJSON[col] == "8504") {
			i.nextElementSibling.classList.remove('d-none')
		}
	}

	for (i of document.getElementsByClassName("sign")) {
		img_notes = i.getAttribute('signaturename') + '_img_time'
		img_id = $(`[notes=${img_notes}]`)[0].id
		if (parsedJSON[img_id]) {
			$(`[notes=${img_notes}]`)[0].parentElement.classList.remove('d-none')
			$(`[notes=${img_notes}]`)[0].value = parsedJSON[img_id]
		}
	}
}

function loadContents(el) {
	// it'snot loaddraft, it's I click and change the work type manually
	if(not_loadDraft){
		// it's already has draft
		if(form._id.value)	{
			// clear the saved draft from couch db
			clearDBForm()
			//clear the hidden image and comments created by loading draft
			$('.singleImage').remove()
		}
	} else {
		not_loadDraft = true
	}

	let locks = []
	if(el.value==i18next.t('9182')){
		$('#loadContents').empty().append(`<?php include 'formWorkCardSurface.php' ?>`)
		$('.translate').localize()
		locks = ['lock_section_decision', 'lock_section_execution']
	}
	else if(el.value==i18next.t('9183')){
		$('#loadContents').empty().append(`<?php include 'formWorkCardUnderGround.php' ?>`)
		$('.translate').localize()
		locks = ['lock_supervisor_entry', 'lock_section_decision', 'lock_section_execution']
	}
	else{
		$('#loadContents').empty()
	}

	initializeSignatures()
	initializeImagePickers()

	for (let i in locks){
		document.getElementById(locks[i]).addEventListener('click', function(e) {
			if (validate(locks[i])){
				innerhtmltext=""
				if(locks[i]=='lock_supervisor_entry'){
					innerhtmltext=`<span class='translate' data-i18n="8528" notes="Are you sure you want to lock the Supervisor Visit section entries? If entries are locked, they cannot be modified."></span>`
				}
				else if(locks[i]=='lock_section_decision'){
					innerhtmltext=`<span class='translate' data-i18n="8544" notes="Are you sure you want to lock the Decision section entries? If entries are locked, they cannot be modified."></span>`
				}
				else if(locks[i]=='lock_section_execution'){
					innerhtmltext=`<span class='translate' data-i18n="8549" notes="Are you sure you want to lock the Supervisor Entry section entries? If entries are locked, they cannot be modified."></span>`
				}

				let formModal = new SofvieModal();                                          // initialize the Modal 
				formModal.setModalElements(`warning`, `modalTitle`, i18next.t("8548"))
				formModal.setModalElements(`warning`, `modalText`, innerhtmltext)
				formModal.setModalElements(`warning`, `modalButtons`, `<a role="button" class="px-1 flex-fill btn btn-outline-warning waves-effect cancelLock" data-dismiss="modal"><span class='translate' data-i18n="1257" notes="Cancel"></span></a><a role="button" class="px-1 flex-fill btn btn-warning waves-effect confirmLock"><span class='translate' data-i18n="1379" notes="Yes"></span></a>`)
				formModal.handleModal(`warning`) 
				$('.confirmLock').click((e)=>{
					$(`#${formModal.name}`).modal('hide')
					$(`#${formModal.name}`).hide()
					lock_time = new Date().toLocaleString()
					lock(locks[i], lock_time)
				})
				$('.cancelLock').click((e)=>{
					$(`#${formModal.name}`).modal('hide')
					$(`#${formModal.name}`).hide()
				})
			}
		})
	}

	// validate signature
	let imageFields = document.querySelectorAll('.modalSignature')
	imageFields.forEach((data)=>{
		if(data.hasAttribute('required')) {
			if(data.value  && data.hasAttribute('required')){
			form.classList.add('validated');
			data.previousElementSibling.previousElementSibling.childNodes[1].classList.remove('invalid')
			}
			else {
				form.classList.remove('validated')
				data.previousElementSibling.previousElementSibling.childNodes[1].classList.add('invalid')
			}
		}
	})

	function validate(lock_id) {
		inputs = document.getElementsByClassName(lock_id + '_lock')
		validated = true
		for (let obj of inputs){
			element = document.getElementById(obj.id)
			if (element.tagName != "DIV" && !element.checkValidity()) {
				validated = failedValidate()
			}
			else if (element.tagName == "DIV") {
				if (element.parentElement.nextElementSibling.nextElementSibling.value == '') {
					element.classList.add('invalid')
					validated = failedValidate()

				} else {
					element.classList.remove('invalid')
				}
			}


		}
		document.getElementById(lock_id + "_div").classList.add("was-validated")
		return validated
	}

	
	function failedValidate() {
		let formModal = new SofvieModal();                                                                                                 // initialize the Modal 
		formModal.setModalElements(`danger`, `modalTitle`, i18next.t("8733")) // Section not locked
		formModal.setModalElements(`danger`, `modalText`, i18next.t("8734"))  // Section not locked. Please revisit the fields marked in red.)
		formModal.setModalElements(`danger`, `modalButtons`, `<a role="button" class="btn btn-danger waves-effect" id="modalClose"><span class='translate' data-i18n="1405" notes="Ok"></a>`)
		formModal.handleModal(`danger`)  
		$('.translate').localize()
		$('#modalClose').click(()=>{
			$(`#${formModal.name}`).modal('hide')
			$(`#${formModal.name}`).hide()
		})
		return false

	}

	$('.show_comment').change(function(e){
		if(e.target.value){
			e.target.parentElement.nextElementSibling.classList.remove('d-none')
			e.target.parentElement.nextElementSibling.firstElementChild.required = true
		}
	});

	$('.hide_comment').change(function(e){
		if(e.target.value){
			e.target.parentElement.nextElementSibling.firstElementChild.value = ''
			e.target.parentElement.nextElementSibling.firstElementChild.required = false
			e.target.parentElement.nextElementSibling.classList.add('d-none')
		}
	});
}

$(document).ready(function() {
	addCrew(1)
});

function addCrew(numCrews,mode){
	const crewsModal = 
	`<div class="crewsection" value=${numCrews}>
		<h6 class="text-secondary pt-4"><span class='translate' data-i18n='8559' notes='Work Accomplished'></span> ${numCrews}</h6>
			<div class="pt-1 position-relative my-4">
				<select name="work_accomplished_${numCrews}" id="work_accomplished_${numCrews}" class="select-single mobile-workAccomplished-select">
				</select>
				<label for="work_accomplished_${numCrews}"><span class='translate' data-i18n='8559' notes='Work Accomplished'></span></label>
			</div>

			<div class="md-form">
				<textarea name="work_accomplished_details_${numCrews}" id="work_accomplished_details_${numCrews}" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
				<label for="work_accomplished_details_${numCrews}"><span class='translate' data-i18n='8560' notes='Work Accomplished Details'></span></label>
			</div>
	</div>`
	
	$("#crews").append(crewsModal);
	if(numCrews>1 && !mode){
		initializeSelect2Dynamic(`work_accomplished_${numCrews}`)
		formHeader.populateWorkAccomplishedSelect(`work_accomplished_${numCrews}`)
		try {$('.translate').localize()} catch {}
	}
}

</script>