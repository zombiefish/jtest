<?php	
  $strPageTitle = 'Pre-Task';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
						<h6 class="text-secondary"><span class='translate' data-i18n="994" notes="Pre-Task"></span></h6>
						<div class="pt-1 position-relative my-4 lock">
							<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
							</select>
							<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
						</div>

						<form name="PreTask" id="PreTask" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="820" notes="Shift"></span></h6>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="shift_days" name="shift" value="1095" notes="Days" required>
								<label class="form-check-label mr-2" for="shift_days"><span class='translate' data-i18n="1095" notes="Days"></span></label>

								<input type="radio" class="form-check-input trans_input" id="shift_nights" name="shift" value="1375" notes="Nights">
								<label class="form-check-label mr-2" for="shift_nights"><span class='translate' data-i18n="1375" notes="Nights"></span></label> 
							</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1376" notes="Pre-Task Assessment"></span></h6>
						<div class="md-form">
							<textarea type="text" name="assigned_tasks" id="assigned_tasks" class="form-control md-textarea lock" wrap="VIRTUAL" required></textarea>
							<label for="assigned_tasks"><span class='translate' data-i18n="56" notes="Assigned Tasks to be Performed"></span></label>
						</div>
		
            			<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1377" notes="Worst Case Scenario"></span></h6>

						<div class="md-form">
							<textarea name="worst_case" id="worst_case" class="form-control md-textarea lock" wrap="VIRTUAL" required></textarea>
							<label for="worst_case" class="pr-5"><span class='translate' data-i18n="627" notes="List the worst thing that can happen to you or your coworkers at your workplace"></span></label>
						</div>

						<div class="md-form">
							<textarea name="what_are_you_doing" id="what_are_you_doing" class="form-control md-textarea lock" wrap="VIRTUAL" required></textarea>
							<label for="what_are_you_doing"><span class='translate' data-i18n="923" notes="Worst Case Scenario"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1378" notes="Workplace Conditions"></span></h6>

						<div class="md-form">
							<input type="text" name="being_safe" id="being_safe" class="form-control lock" length="200" maxlength="200" required>
							<label for="being_safe"><span class='translate' data-i18n="933" notes="Why are you BEING SAFE?"></span></label>
						</div>	

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="604" notes="Is the travelway in good order?"></span></label>
							<div class="form-check custom-radio no-radio pl-0">
								<input type="radio" class="form-check-input" id="travelways_yes" name="travelways" value="1" required>
								<label class="form-check-label mr-2" for="travelways_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="travelways_no" name="travelways" value="0">
								<label class="form-check-label mr-2" for="travelways_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="travelways_na" name="travelways" value="-1">
								<label class="form-check-label mr-2" for="travelways_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="595" notes="Is the housekeeping in good order?"></span></label>
							<div class="form-check custom-radio no-radio pl-0">
								<input type="radio" class="form-check-input" id="housekeeping_yes" name="housekeeping" value="1" required>
								<label class="form-check-label mr-2" for="housekeeping_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="housekeeping_no" name="housekeeping" value="0">
								<label class="form-check-label mr-2" for="housekeeping_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="housekeeping_na" name="housekeeping" value="-1">
								<label class="form-check-label mr-2" for="housekeeping_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="605" notes="Is the ventilation in good order?"></span> <br><small><span class='translate' data-i18n="1382" notes="(Condition, Volume, Quality)"></span></small></label>
							<div class="form-check custom-radio no-radio pl-0">
								<input type="radio" class="form-check-input" id="ventilation_yes" name="ventilation" value="1" required>
								<label class="form-check-label mr-2" for="ventilation_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="ventilation_no" name="ventilation" value="0">
								<label class="form-check-label mr-2" for="ventilation_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="ventilation_na" name="ventilation" value="-1">
								<label class="form-check-label mr-2" for="ventilation_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="586" notes="Is dust control in good order?"></span></label>
							<div class="form-check custom-radio no-radio pl-0">
								<input type="radio" class="form-check-input" id="dust_control_yes" name="dust_control" value="1" required>
								<label class="form-check-label mr-2" for="dust_control_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="dust_control_no" name="dust_control" value="0">
								<label class="form-check-label mr-2" for="dust_control_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="dust_control_na" name="dust_control" value="-1">
								<label class="form-check-label mr-2" for="dust_control_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="40" notes="Are the signs and barricades in good order?"></span></label>
							<div class="form-check custom-radio no-radio pl-0">
								<input type="radio" class="form-check-input" id="signs_barricades_yes" name="signs_barricades" value="1" required>
								<label class="form-check-label mr-2" for="signs_barricades_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="signs_barricades_no" name="signs_barricades" value="0">
								<label class="form-check-label mr-2" for="signs_barricades_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="signs_barricades_na" name="signs_barricades" value="-1">
								<label class="form-check-label mr-2" for="signs_barricades_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="30" notes="Are ground conditions in good order?"></span></label>
							<div class="form-check custom-radio no-radio pl-0">
								<input type="radio" class="form-check-input" id="ground_conditions_yes" name="ground_conditions" value="1" required>
								<label class="form-check-label mr-2" for="ground_conditions_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="ground_conditions_no" name="ground_conditions" value="0">
								<label class="form-check-label mr-2" for="ground_conditions_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="ground_conditions_na" name="ground_conditions" value="-1">
								<label class="form-check-label mr-2" for="ground_conditions_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>								
							</div>
						</div>	

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="1383" notes="Are communication tools in good order?"></span> <br><small><span class='translate' data-i18n="1384" notes="(radio, telephone, etc.)"></span></small></label>
							<div class="form-check custom-radio no-radio pl-0">
								<input type="radio" class="form-check-input" id="leaky_feed_yes" name="leaky_feed" value="1" required>
								<label class="form-check-label mr-2" for="leaky_feed_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="leaky_feed_no" name="leaky_feed" value="0">
								<label class="form-check-label mr-2" for="leaky_feed_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="leaky_feed_na" name="leaky_feed" value="-1">
								<label class="form-check-label mr-2" for="leaky_feed_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>								
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="51" notes="Are your hand tools in good order?"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="hand_tools_yes" name="hand_tools" value="1" required>
								<label class="form-check-label mr-2" for="hand_tools_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="hand_tools_no" name="hand_tools" value="0">
								<label class="form-check-label mr-2" for="hand_tools_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="hand_tools_na" name="hand_tools" value="-1">
								<label class="form-check-label mr-2" for="hand_tools_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>								
							</div>
						</div>
		
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1385" notes="Safe Work Requirements"></span></h6>

						<div class="my-4">
							<label class="d-block"><span class='translate' data-i18n="170" notes="Do you have a hot work permit?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="hot_work_permit_yes" name="hot_work_permit" value="1" required>
								<label class="form-check-label mr-2" for="hot_work_permit_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="hot_work_permit_no" name="hot_work_permit" value="0">
								<label class="form-check-label mr-2" for="hot_work_permit_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="hot_work_permit_na" name="hot_work_permit" value="-1">
								<label class="form-check-label mr-2" for="hot_work_permit_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>
	
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="173" notes="Do you have the proper PPE?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="proper_ppe_yes" name="proper_ppe" value="1" required>
								<label class="form-check-label mr-2" for="proper_ppe_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="proper_ppe_no" name="proper_ppe" value="0">
								<label class="form-check-label mr-2" for="proper_ppe_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="proper_ppe_na" name="proper_ppe" value="-1">
								<label class="form-check-label mr-2" for="proper_ppe_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>
	
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="174" notes="Do you have the SDS for the chemicals you are using?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="sds_chemicals_yes" name="sds_chemicals" value="1" required>
								<label class="form-check-label mr-2" for="sds_chemicals_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="sds_chemicals_no" name="sds_chemicals" value="0">
								<label class="form-check-label mr-2" for="sds_chemicals_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="sds_chemicals_na" name="sds_chemicals" value="-1">
								<label class="form-check-label mr-2" for="sds_chemicals_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="50" notes="Are you registered for Working Alone?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="working_alone_yes" name="working_alone" value="1" required>
								<label class="form-check-label mr-2" for="working_alone_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="working_alone_no" name="working_alone" value="0">
								<label class="form-check-label mr-2" for="working_alone_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="working_alone_na" name="working_alone" value="-1">
								<label class="form-check-label mr-2" for="working_alone_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>								
							</div>
						</div>
            
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="936" notes="Will you be Working at Heights or require travel restraint and have a rescue plan?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="working_at_heights_yes" name="working_at_heights" value="1" required>
								<label class="form-check-label mr-2" for="working_at_heights_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="working_at_heights_no" name="working_at_heights" value="0">
								<label class="form-check-label mr-2" for="working_at_heights_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="working_at_heights_na" name="working_at_heights" value="-1">
								<label class="form-check-label mr-2" for="working_at_heights_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="1386" notes="Do you have locks and tags?"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="lock_tag_yes" name="lock_tag" value="1" required>
								<label class="form-check-label mr-2" for="lock_tag_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="lock_tag_no" name="lock_tag" value="0">
								<label class="form-check-label mr-2" for="lock_tag_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="lock_tag_na" name="lock_tag" value="-1">
								<label class="form-check-label mr-2" for="lock_tag_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>								
							</div>
						</div>

            			<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="172" notes="Do you have the prints, procedures or risk assessments for your work?"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="any_procedures_yes" name="any_procedures" value="1" required>
								<label class="form-check-label mr-2" for="any_procedures_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="any_procedures_no" name="any_procedures" value="0">
								<label class="form-check-label mr-2" for="any_procedures_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="any_procedures_na" name="any_procedures" value="-1">
								<label class="form-check-label mr-2" for="any_procedures_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

            			<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="505" notes="Have you communicated with the mobile equipment operators in the area?"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="equipment_communication_yes" name="equipment_communication" value="1" required>
								<label class="form-check-label mr-2" for="equipment_communication_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="equipment_communication_no" name="equipment_communication" value="0">
								<label class="form-check-label mr-2" for="equipment_communication_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

								<input type="radio" class="form-check-input" id="equipment_communication_na" name="equipment_communication" value="-1">
								<label class="form-check-label mr-2" for="equipment_communication_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<h6 class="text-secondary pt-4 "><span class='translate' data-i18n="1387" notes="Shift Start Workplace Conditions"></span></h6>

						<div class="form-group photoImage" id="start_state_pictures"> 
							<label class="d-block"><span class='translate' data-i18n="838" notes="Start State Pictures of the Workplace"></span></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1 image_input_to_lock">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
							<div class="row photoGallery" id="galleryid"></div>
						</div>

						<div class="md-form">
							<textarea name="start_state_details" id="start_state_details" class="form-control md-textarea lock" wrap="VIRTUAL"></textarea>
							<label for="start_state_details"><span class='translate' data-i18n="837" notes="Start State Details"></span></label>
						</div>

            			<div class="form-group mt-4">
							<label class="d-block"><span class='translate' data-i18n="971" notes="Workplace Score"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons">
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="workplace_score" id="workplace_score_1" value="1" required > 1
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="workplace_score" id="workplace_score_2" value="2"> 2
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="workplace_score" id="workplace_score_3" value="3"> 3
								</label>
      							<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="workplace_score" id="workplace_score_4" value="4"> 4
								</label>
                				<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="workplace_score" id="workplace_score_5" value="5"> 5
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
            			</div>

						<div class="form-group mt-4">
							<label class="d-block"><span class='translate' data-i18n="616" notes="Job Definition Score"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons">
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="job_definition_score" id="job_definition_score_1" value="1" required > 1
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="job_definition_score" id="job_definition_score_2" value="2"> 2
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="job_definition_score" id="job_definition_score_3" value="3"> 3
								</label>
                				<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="job_definition_score" id="job_definition_score_4" value="4"> 4
								</label>
                				<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="job_definition_score" id="job_definition_score_5" value="5"> 5
								</label>								
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
            			</div>

						<div class="form-group mt-4">
							<label class="d-block"><span class='translate' data-i18n="475" notes="Job Definition Score"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons">
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="experience_score" id="experience_score_1" value="1" required > 1
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="experience_score" id="experience_score_2" value="2"> 2
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="experience_score" id="experience_score_3" value="3"> 3
								</label>
                				<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="experience_score" id="experience_score_4" value="4"> 4
								</label>
                				<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="experience_score" id="experience_score_5" value="5"> 5
								</label>								
							</div>
						  	<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div> 
            			</div>
												
						<h6 class='text-center m-0'><span class='translate' data-i18n="959" notes="Workplace"></span></h6>
						
            			<canvas id='safetyTriangle' style="background-image:url('/images/SafetyTriangle_i18n.png'); margin: 0 auto; display: block; background-size: contain;"></canvas>
				
						<h6 style='overflow: hidden'><span style="float:left;" class='translate' data-i18n="1390" notes="Job Definition"></span><span style="float:right;" class='translate' data-i18n="1391" notes="Experience"></span></h6>

						<div class="alert alert-danger mt-3 text-center d-none contact-supervisor" role="alert"><span class='translate' data-i18n="1392" notes="Safe work conditions are not met. Please contact your supervisor."></span></div>

						<div class="md-form">
							<textarea name="comments" id="comments" class="form-control md-textarea lock" wrap="VIRTUAL"></textarea>
							<label for="comments" class="pr-5"><span class='translate' data-i18n="81" notes="Comments"></span></label>
						</div>

						<div class="form-check">
							<input type="checkbox" class="form-check-input" name="commitment" id="commitment" value = '0' onchange="getSafetyCheckboxStatus()" required>
							<label class="form-check-label" for="commitment"><span class='translate' data-i18n="1393" notes="I am committed to working safely!"></span></label>
						</div>

						<h6 class="text-secondary pt-4 "><span class='translate' data-i18n="1394" notes="Shift End Workplace Conditions"></span></h6>

						<div class="form-group photoImage" id="end_state_pictures"> 
							<label class="d-block"><span class='translate' data-i18n="423" notes="End State Pictures of the Workplace"></span></label>
							<canvas id="canvas2" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1 image_input_to_lock">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
							<div class="row photoGallery" id="galleryid2"></div>
						</div>

						<div class="md-form">
							<textarea name="end_state_details" id="end_state_details" class="lock form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="end_state_details"><span class='translate' data-i18n="422" notes="Please take scene pictures from all perspectives"></span></label>
						</div>	
						<div class="md-form">
							<textarea name="supervisor_comments" id="supervisor_comments" class="lock form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="supervisor_comments" class="pr-5"><span class='translate' data-i18n="846" notes="Supervisor Comments"></span></label>
						</div>

						<button type="button"  name="lock_comment" id="lock_comment" class="btn btn-primary btn-block my-4 waves-effect waves-light"><span class='translate' data-i18n="2525" notes="Lock Comment"></span></button>
						
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1395" notes="Signatures"></span></h6>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="850" notes="Supervisor Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign lock' signaturename='signature_supervisor'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_supervisor_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_supervisor" id="signature_supervisor" class='modalSignature' value=''>
							<input type="hidden" name="vector_supervisor" id='vector_supervisor' value=''>
							<input type="hidden" name="signature_supervisor_comments" id='signature_supervisor_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_supervisor_img_time" id="signature_supervisor_img_time" notes='signature_supervisor_img_time' readonly/></small>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="640" notes="Manager Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign lock' signaturename='signature_manager'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_manager_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_manager" id="signature_manager" class='modalSignature' value=''>
							<input type="hidden" name="vector_manager" id='vector_manager' value=''>
							<input type="hidden" name="signature_manager_comments" id='signature_manager_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_manager_img_time" id="signature_manager_img_time" notes='signature_manager_img_time' readonly/></small>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="1397" notes="Other Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign lock' signaturename='signature_other'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_other_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_other" id="signature_other" class='modalSignature' value='' >
							<input type="hidden" name="vector_other" id='vector_other' value=''>
							<input type="hidden" name="signature_other_comments" id='signature_other_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_other_img_time" id="signature_other_img_time" notes='signature_other_img_time' readonly/></small>
						</div>

						<h6 class="text-secondary pt-4 "><span class='translate' data-i18n="1188" notes="Review"></span></h6>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="9409" notes="End of Shift Review"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign lock' signaturename='signature_end_of_shift_review'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1188" notes="Review"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<!-- <div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div> -->
							</div>
							<img id='signature_end_of_shift_review_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_end_of_shift_review" id="signature_end_of_shift_review" class='modalSignature' value=''>
							<input type="hidden" name="vector_review" id='vector_review' value=''>
							<input type="hidden" name="signature_end_of_shift_review_comments" id='signature_end_of_shift_review_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_end_of_shift_review_img_time" id="signature_end_of_shift_review_img_time" notes='signature_end_of_shift_review_img_time' readonly/></small>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag='994' class = "trans_input" value="994" note="PRE-TASK" />
						<input type="hidden" name="formtype" id="formtype" value="SUP" />
						<input type="hidden" name="formid" id="formid" value="236193" />
						<input type="hidden" name="version" id="version" value="30" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
						<input type="hidden" name="lockButton" id="lockButton" value="false" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>


<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.')
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.')
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.')
			return true
		}	
	}

	function getSafetyCheckboxStatus(){
		var status = document.getElementById("commitment").checked;
		if (status) {
			document.getElementById("commitment").value='1'
		} else {
			document.getElementById("commitment").value='0'
		}
	}

    ///////////////////////////////////////////////////////// 
	// This code is for creating the interactive triangle  //
	/////////////////////////////////////////////////////////

	document.getElementById('lock_comment').addEventListener('click', function(e) {
		document.getElementById('supervisor_comments').setAttribute('disabled' , true);
		document.getElementById('lockButton').value='true';
		document.getElementById('lock_comment').classList.add("d-none")
	})

	canvas = document.getElementById("safetyTriangle")
	ctx = canvas.getContext("2d")
	const canvasWidth =  500
	const canvasHeight = 500
    let formWidth = document.getElementById("PreTask").offsetWidth;
	let percent = canvasResize(canvas)
	radios = document.querySelectorAll('input[name="workplace_score"] , input[name="experience_score"], input[name="job_definition_score"]')

	for(data in radios) {
		if(radios[data].parentNode)
		radios[data].parentNode.addEventListener('click', (event)=>{
			setTimeout(()=>{
			if(document.forms[0].workplace_score && document.forms[0].job_definition_score && document.forms[0].experience_score)
			  {
				let percent = canvasResize(canvas)
				workplaceScore = document.forms[0].workplace_score.value
				jobDefScore = document.forms[0].job_definition_score.value
				experienceScore = document.forms[0].experience_score.value	
				drawSafetyTriangle(workplaceScore, jobDefScore, experienceScore,percent)
			  }
			},100)
	      })
		}

    window.onresize = () => {
		let percent = canvasResize(canvas)
		if(document.forms[0].workplace_score && document.forms[0].job_definition_score && document.forms[0].experience_score)
			{
			let percent = canvasResize(canvas)
			workplaceScore = document.forms[0].workplace_score.value
			jobDefScore = document.forms[0].job_definition_score.value
			experienceScore = document.forms[0].experience_score.value	
			drawSafetyTriangle(workplaceScore, jobDefScore, experienceScore, percent)
			}
	}

	function canvasResize(canvas) {
		let percent = 1
		var oForm = document.getElementById('PreTask');
        formWidth = oForm.offsetWidth
	    canvas.width = canvasWidth
	    canvas.height = canvasHeight	
	    if(formWidth <= canvasWidth){
			canvas.width = formWidth
			canvas.height = formWidth
		}
        return percent
	}
	 
	function drawSafetyTriangle(workplaceScore, jobDefScore, experienceScore, percent = 1) {
		let workplace = []
		workplace[5] = {x: canvas.width * 0.5, y: canvas.height * 0.09}
		workplace[4] = {x: canvas.width * 0.5, y: canvas.height * 0.19}
		workplace[3] = {x: canvas.width * 0.5, y: canvas.height * 0.27}
		workplace[2] = {x: canvas.width * 0.5, y: canvas.height * 0.40}
		workplace[1] = {x: canvas.width * 0.5, y: canvas.height * 0.53}

		let jobDef = []
		jobDef[5] = {x: canvas.width * 0.02, y: canvas.height * 0.916}
		jobDef[4] = {x: canvas.width * 0.101, y: canvas.height * 0.87}
		jobDef[3] = {x: canvas.width * 0.18, y: canvas.height * 0.825}
		jobDef[2] = {x: canvas.width * 0.294, y: canvas.height * 0.754}
		jobDef[1] = {x: canvas.width * 0.414, y: canvas.height * 0.684}

		let experience= []
		experience[5] = {x: canvas.width * 0.98, y: canvas.height * 0.916}
		experience[4] = {x: canvas.width * 0.899, y: canvas.height * 0.87}
		experience[3] = {x: canvas.width * 0.82, y: canvas.height * 0.825}
		experience[2] = {x: canvas.width * 0.706, y: canvas.height * 0.754}
		experience[1] = {x: canvas.width * 0.586, y: canvas.height * 0.684}

		if(workplaceScore >= 4 || jobDefScore >= 4 || experienceScore >= 4){
			ctx.fillStyle = "red";
			//There are multiple conditions to deal with one of the categories being 3 withthe the other two being green
			$(".contact-supervisor").removeClass("d-none");
		} else if ( workplaceScore <= 2 && jobDefScore <= 2 && experienceScore <= 3 ){
			ctx.fillStyle = "green";
			$(".contact-supervisor").addClass("d-none");
		} 
		else if ( workplaceScore <= 2 && jobDefScore <= 3 && experienceScore <= 2 ){
			ctx.fillStyle = "green";
			$(".contact-supervisor").addClass("d-none");
		} 
		else if ( workplaceScore <= 3 && jobDefScore <= 2 && experienceScore <= 2 ){
			ctx.fillStyle = "green";
			$(".contact-supervisor").addClass("d-none");
		} else {
			ctx.fillStyle = "yellow";
			$(".contact-supervisor").removeClass("d-none");
		}
		if(workplaceScore && jobDefScore && experienceScore) {
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			// Draw the triangle
			ctx.beginPath()
			ctx.moveTo(jobDef[jobDefScore].x,jobDef[jobDefScore].y)
			ctx.lineTo(workplace[workplaceScore].x,workplace[workplaceScore].y)
			ctx.lineTo(experience[experienceScore].x,experience[experienceScore].y)
			ctx.lineTo(jobDef[jobDefScore].x,jobDef[jobDefScore].y)
			ctx.strokeStyle = 'black'
			ctx.fill()
			ctx.stroke()
		}
	}

	function draftPreProcess(parsedJSON) {
		unlock()
		var locked = parsedJSON.lockButton
		if(parsedJSON.formid === '236193' && locked === 'true') {
			setTimeout(() => {
				$('#lock_comment').click()
			}, 200);	
		}

		if(parsedJSON['signature_end_of_shift_review_img_time']){
			lock()
			setTimeout(() => {
				$('.deleteGalleryImage, .clear_sign').addClass('d-none')
			}, 2000);	
		}
		else{
			document.getElementById('lock_comment').classList.remove("d-none")
			$('#supervisor_comments').removeAttr("disabled")
		}
		$('.clear_sign').addClass('d-none')
	}

	function lock(lock_id, lock_time) {
		$('#lock_comment').click()
		inputs = document.querySelectorAll('.lock,.form-check-input')
		if(inputs){
			for (let obj of inputs){
				obj.setAttribute('disabled' , true);
				if (obj.classList.contains('sign')){
					obj.classList.add("d-none")
					obj.nextElementSibling.classList.remove("d-none")
					if(obj.getAttribute('signaturename')!="signature_end_of_shift_review"){
						obj.nextElementSibling.classList.add("read-only")  //signature comment only can show not edit
						obj.nextElementSibling.nextElementSibling.classList.add("d-none")
					}
				}
			}
		}

		imgUploads=document.querySelectorAll('.file-field')
		if(imgUploads){
			for (let obj of imgUploads){
				obj.parentElement.parentElement.classList.add("read-only")  //signature comment only can show not edit
			}
		}

		// lock images
		images = document.querySelectorAll('.image_input_to_lock')
		if(images){
			for (let obj of images) {
				obj.style.display = "none"
			}
		}

		$('.deleteGalleryImage').addClass('d-none')
	}

	function unlock(){	
		inputs = document.querySelectorAll('.lock,.form-check-input')
		if(inputs){
			for (let obj of inputs){
				obj.removeAttribute("disabled")
				if (obj.classList.contains('sign')){
					obj.classList.remove("d-none")
					obj.nextElementSibling.classList.add("d-none")
					if(obj.getAttribute('signaturename')!="signature_end_of_shift_review"){
						obj.nextElementSibling.classList.remove("read-only")  //signature comment only can show not edit
						obj.nextElementSibling.nextElementSibling.classList.remove("d-none")
					}
				}
			}
		}


		imgUploads=document.querySelectorAll('.file-field')
		if(imgUploads){
			for (let obj of imgUploads){
				obj.parentElement.parentElement.classList.remove("read-only")  //signature comment only can show not edit
			}
		}

		// unlock images
		images = document.querySelectorAll('.image_input_to_lock')
		if(images){
			for (let obj of images) {
				obj.style.display = ""
			}
		}

		$('.deleteGalleryImage').removeClass('d-none')
		document.getElementById('lockButton').value='false';	
	}

</script>

<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
