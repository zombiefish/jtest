<?php	
    $strPageTitle = 'Time Sheet';
    include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
    include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
    include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
    include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
    ?>
<main class="col containter-fluid mobile-content">
    <div class="row">
        <div class="col-12 mb-4">
            <div class="card mb-4">
                <div class="card-body">
                    <h6 class="text-secondary"><span class='translate' data-i18n="2252" notes="Time Sheet"></span></h6>
                    <div class="pt-1 position-relative my-4">
                        <select name="draft" id="draft" class="select-single" onChange="getFormData(this)"  >
                        </select>
                        <label for="draft"><span class='translate' data-i18n="1474" notes="From Drafts"></span></label>
                    </div>
                    <form name="time_sheet" id="TemplateForm" class="needs-validation" method="POST" action="#"
                        novalidate>
                        <?php include 'includes/CommonFormHeader.php' ?>
                        <h6 class="text-secondary pt-4"><span class='translate' data-i18n="820" notes="Shift"></span></h6>
                        <div class="form-check custom-radio pl-0">
                            <input type="radio" class="form-check-input trans_input" id="shift_days" name="shift" value="1095"  required>
                            <label class="form-check-label mr-2" for="shift_days"><span class='translate' data-i18n="1095" notes="Days"></span></label>
                            <input type="radio" class="form-check-input trans_input" id="shift_nights" name="shift" value="1375">
                            <label class="form-check-label mr-2" for="shift_nights"><span class='translate' data-i18n="1375" notes="Nights"></span></label>
                        </div>
                        <h6 class="text-secondary pt-4"><span class='translate' data-i18n="2379" notes="Contact"></span></h6>
                        <div class="md-form">
                            <input type="text" name="contact_name" id="contact_name" class="form-control" length="200" maxlength="200" required>
                            <label for="contact_name"><span class='translate' data-i18n="98" notes="Contact Name"></span></label>
                        </div>
                        <div class="md-form">
                            <input type="tel" name="contact_number" id="contact_number" class="form-control" data-slots="_" placeholder="(___) ___-____" required>
                            <label for="contact_number"><span class='translate' data-i18n="99" notes="Contact Number"></span></label>
                        </div>
                        <h6 class="text-secondary pt-4"><span class='translate' data-i18n="2380" notes="Work Details"></span></h6>
                        <div class="md-form">
                            <input type="text" name="work_order_no" id="work_order_no" class="form-control" length="200" maxlength="200">
                            <label for="work_order_no"><span class='translate' data-i18n="943" notes="Work Order Number"></span></label>
                        </div>
                        <div class="md-form">
                            <input type="text" name="purchase_order_no" id="purchase_order_no" class="form-control" length="200" maxlength="200">
                            <label for="purchase_order_no"><span class='translate' data-i18n="765" notes="Purchase Order Number"></span></label>
						</div>
						<div class="md-form">
                            <textarea name="work_description" id="work_description" class="form-control md-textarea"
                                wrap="VIRTUAL" required></textarea>
                            <label for="work_description"><span class='translate' data-i18n="942" notes="Work Description"></span></label>
                        </div>
                        <div class="form-group photoImage" id="multiphoto_picker_1">
                            <label class="d-block"><span class='translate' data-i18n="744" notes="Pictures of Work Area"></span></label>
                            <canvas id="canvas" style='display:none;'></canvas>
                            <div class="btn-group d-flex" role="group">
                                <div class="btn btn-block btn-outline-secondary file-field px-1">
                                    <i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="Add Images"></span>
                                    <input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
                                </div>
                            </div>
                            <div class="row photoGallery" id="galleryid"></div>
                        </div>
                        <h6 class="text-secondary pt-4"><span class='translate' data-i18n="2381" notes="Employees"></span></h6>
                        <div id="employee_groups">
                            <div id="crews"></div>
                        </div>
                        <div id='addCrew' class='btn btn-sm btn-primary translate' data-i18n='[html]2388' notes='Add Employee Group'><span class='translate' data-i18n="2388" notes="ADD EMPLOYEE GROUP"></span></div>
                        <div id='removeCrew' class='btn btn-sm btn-outline-primary'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n="2389" notes="REMOVE EMPLOYEE GROUP"></span></div>
                        <p>
                            <div id="grand_total_area">
                                <label id='grand_total'for="grand_total_area"><strong><span class='translate' data-i18n="2390" notes="Grand Total of Hours:"></span></strong></label>
                            </div>
                        </p>


                        <h6 class="text-secondary pt-4"><span class='translate' data-i18n="2391" notes="Equipment and Materials"></span></strong></h6>


                        <div class="md-form">
                            <textarea name="material_used" id="material_used" class="form-control md-textarea"
                                wrap="VIRTUAL" required></textarea>
                            <label for="material_used"><span class='translate' data-i18n="642" notes="Material Used"></span></label>
                        </div>

                        <div class="md-form">
                            <textarea name="material_required" id="material_required" class="form-control md-textarea"
                                wrap="VIRTUAL" required></textarea>
                            <label for="material_required"><span class='translate' data-i18n="641" notes="Material Required"></span></label>
                        </div>
 
                        <div class="pt-1 position-relative my-4">
                            <select name="equipment_used" id="equipment_used" class="select-multiple" multiple>
                            </select>
                            <label for="equipment_used"><span class='translate' data-i18n="9559" notes="Please select Site and Department/Job to select Equipment"></span></label>
                        </div>

                        <div class="md-form">
                            <textarea name="equipment_used_details" id="equipment_used_details" class="form-control md-textarea"
                                wrap="VIRTUAL"></textarea>
                            <label for="equipment_used_details"><span class='translate' data-i18n="454" notes="Equipment Used Details"></span></label>
                        </div>

                        <div class="my-4">
                            <label class="text-muted"><span class='translate' data-i18n="2392" notes="Work Acceptance"></span></label>
                            <div class="btn-group d-flex" role="group" aria-label="Action subforms">
                                <div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign'
                                    signaturename='signature_acceptance'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span>
                                </div>
                                <div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'>
                                    <i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span>
                                </div>
                            </div>
                            <img id='signature_acceptance_img' src='' class='signatureImage d-block pt-2' />
                            <input type="hidden" name="signature_acceptance" id="signature_acceptance" class='modalSignature'
                                value='' required>
                            <input type="hidden" name="vector_signature" id='vector_signature' value=''>
                            <input type="hidden" name="signature_acceptance_comments" id='signature_acceptance_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_acceptance_img_time" id="signature_acceptance_img_time" notes='signature_acceptance_img_time' readonly/></small>
                        </div>

                        <?php include 'includes/CommonFormFooter.php' ?>
                        <input type="hidden" name="formname" id="formname" class = "trans_input" value="2252" tag="2252" tag="TIME SHEET" />
                        <input type="hidden" name="formtype" id="formtype" value="SUP" />
                        <input type="hidden" name="formid" id="formid" value="372348" />
                        <input type="hidden" name="version" id="version" value="1" />
                        <input type="hidden" name="_rev" id="_rev" value="" />
                        <input type="hidden" name="_id" id="_id" value="" />
                        <input type="hidden" name="keyField" id="keyField" value="site|workplace" />
                        <input type="hidden" name="draftField" id="draftField" value="draft" />
                        <input type="hidden" name="numCrews" id="numCrews" value='1' />
                        <input type="hidden" name="totalCrews" id="totalCrews" value='10' />     
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    var formBody = {

        formInitialize: function (theForm) {
            if (debug) console.log('formBody.formInitialize() called.');
            loadMachines() 
            document.getElementById("draft").addEventListener('click',calculateAllHours)
        },

        formTerminate: function (theForm) {
            if (debug) console.log('formBody.formTerminate() called.');
        },

        formValidate: function (theForm) {
            if (debug) console.log('formBody.formValidate() called.');
            return true;
        }
    }

	const lists = remoteData

    function calculateAllHours(){
       grandTotal()
    }

    //Calculate the hours for a particular section.
    //Return the calculated value. 
    function calculateHours(section){
        let employeeCount = countEmployeesInGroup(section)
        let hours = document.getElementById("hours_" + section).value
        let tot_hrs = 0;
        if (hours){
            tot_hrs = employeeCount * hours
        }
        return tot_hrs
    }

    //Calculate the grand total.
    function grandTotal() {
        numCrews=parseInt(document.getElementById("numCrews").value)
        let gtotal = 0
        for (let i = 1; i <= numCrews; i++) {
            if(document.getElementById("total_hours_" + i)){
                let hrs = document.getElementById("total_hours_" + i)
                hrs.innerHTML = "<strong>"+i18next.t('2387')+" " + calculateHours(i) + "</strong>"  //Total Group Hours:
                gtotal += calculateHours(i)
            }
        }
        document.getElementById("grand_total").innerHTML ="<strong>"+i18next.t('2390')+" " + gtotal + "</strong>"  //Grand Total of Hours        
    }

    function countEmployeesInGroup(section) {
        let total_employees = document.getElementById('employee_' + section).selectedOptions.length
        return total_employees
    }

    // A solution that responds to the input event instead of key events (like keyup) will give a smooth experience (no wiggles), and also works when changes are made without the keyboard (context menu, mouse drag, other device...).
    // The code below will look for input elements that have both a placeholder attribute and a data-slots attribute. The latter should define the character(s) in the placeholder that is/are intended as input slot, for example, "_". An optional data-accept attribute can be provided with a regular expression that defines which characters are allowed in such a slot. The default is \d, i.e. digits.
    // This code empowers all input tags having a placeholder and data-slots attribute
    // Not written by James.
    document.addEventListener('DOMContentLoaded', () => {
        for (const el of document.querySelectorAll("[placeholder][data-slots]")) {
            const pattern = el.getAttribute("placeholder"),
                slots = new Set(el.dataset.slots || "_"),
                prev = (j => Array.from(pattern, (c,i) => slots.has(c)? j=i+1: j))(0),
                first = [...pattern].findIndex(c => slots.has(c)),
                accept = new RegExp(el.dataset.accept || "\\d", "g"),
                clean = input => {
                    input = input.match(accept) || [];
                    return Array.from(pattern, c =>
                        input[0] === c || slots.has(c) ? input.shift() || c : c
                    );
                },
                format = () => {
                    const [i, j] = [el.selectionStart, el.selectionEnd].map(i => {
                        i = clean(el.value.slice(0, i)).findIndex(c => slots.has(c));
                        return i<0? prev[prev.length-1]: back? prev[i-1] || first: i;
                    });
                    el.value = clean(el.value).join``;
                    el.setSelectionRange(i, j);
                    back = false;
                };
            let back = false;
            el.addEventListener("keydown", (e) => back = e.key === "Backspace");
            el.addEventListener("input", format);
            el.addEventListener("focus", format);
            el.addEventListener("blur", () => el.value === pattern && (el.value=""));
        }
    });

	$( document ).ready(function() {
		addCrew(1)
	});
	
    function addCrew(crewNum,mode){
		const crewsModal = 
		`<div class="crewsection" value=${crewNum}>
            <h6 class="text-secondary pt-4"><span class='translate' data-i18n="2382" notes="Employee Group"></span> ${crewNum}</h6>
            <div class="pt-1 position-relative my-4">
                <select name="employee_${crewNum}" id="employee_${crewNum}"
                    class="select-multiple mobile-employee-select" onchange="grandTotal()"
                    multiple required>
                </select>
                <label for="employee_${crewNum}"><span class='translate' data-i18n="2383" notes="Employee Name(s)"></span></label>
            </div>
            <div class="pt-1 position-relative my-4">
                <select name="occupation_${crewNum}" id="occupation_${crewNum}"
                    class="select-multiple mobile-employeeoccupation-select" multiple required>
                </select>
                <label for="occupation_${crewNum}"><span class='translate' data-i18n="664" notes="Occupation"></span></label>
            </div>
            <div class="pt-1 position-relative my-4 md-form">
                <label for="hours_${crewNum}"><span class='translate' data-i18n="526" notes="Hours"></span></label>
                <input type="number" step="0.25" name="hours_${crewNum}" id="hours_${crewNum}" class="form-control" onchange="grandTotal()"  min=0
                    onkeyup="grandTotal()" required></input>
            </div>
            <label class="d-block"><span class='translate' data-i18n="2384" notes="Pay Type"></span></label>
            <div class="form-check custom-radio pl-0">
                <input type="radio" class="form-check-input" id="employee_pay_regular_${crewNum}" name="employee_pay_${crewNum}" value="2385" required>
                <label class="form-check-label mr-2" for="employee_pay_regular_${crewNum}"><span class='translate' data-i18n="2385" notes="Regular"></span></label>
                <input type="radio" class="form-check-input" id="employee_pay_overtime_${crewNum}" name="employee_pay_${crewNum}" value="2386">
                <label class="form-check-label mr-2" for="employee_pay_overtime_${crewNum}"><span class='translate' data-i18n="2386" notes="Overtime"></span></label>
                <input type="radio" class="form-check-input" id="employee_pay_na_${crewNum}" name="employee_pay_${crewNum}" value="1381">
                <label class="form-check-label mr-2" for="employee_pay_na_${crewNum}"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
            </div>
            <p><div>
                <label id="total_hours_${crewNum}"><strong><span class='translate' data-i18n="2387" notes="Total Group Hours:"></span></strong></label>
            </div></p>            
        </div>`
		
		$("#crews").append(crewsModal);
        if(crewNum>1 && !mode){
            initializeSelect2Dynamic(`employee_${crewNum}`)
            initializeSelect2Dynamic(`occupation_${crewNum}`)
            formHeader.populateEmployeeSelect(`employee_${crewNum}`)
            formHeader.populateEmployeeOccupationSelect(`occupation_${crewNum}`)
            try {$('.translate').localize()} catch {}
        }
	}
    
    function draftPostProcess(parsedJSON){
        calculateAllHours()
    }

    function clearEquipmentFields(id) {
        if(id === 'job_number' || id === 'site'){
           
            all_rest = []
            let optionData = `<select name="equipment_used" id="equipment_used" class="select-multiple mobile-equipment-select" multiple>`
            all_rest.forEach((data)=>{
                optionData += `<option value="${data.id}">${data.text}</option>`
            })
            optionData += `</select>`
            $(`#equipment_used`).html(optionData)
            if(main_current_draft_object) {
                main_current_draft_object.equipment_used = ""
            }
            initializeEquipmentSelect2(`equipment_used`)
            $(`#equipment_used`).val("").trigger("change").parent().find('label').removeClass(['filled',"active"])
            $(`#equipment_used`).parent().find('label').html(i18next.t("9559"))
        }
    }

</script>
<script src="/js/groupEquipment.js"></script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>