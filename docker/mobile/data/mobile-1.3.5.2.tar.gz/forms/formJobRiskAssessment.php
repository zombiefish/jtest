<?php	
  $strPageTitle = 'Job Risk Assessment';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>
<script src="//code.jquery.com/jquery-1.12.4.js"></script>
<link href="<?php echo _RESOURCEDOMAIN; ?>/datatables/css/jquery.dataTables.min.css" rel="stylesheet">

<main class="col containter-fluid mobile-content">
	<div class="col-12 mb-4">
		<form name="formJobRiskAssessment" id="formJobRiskAssessment" class="needs-validation" method="POST" action="#" novalidate>
			<canvas id="canvas" style='display:none;'></canvas>
			<div class="card mb-4">
				<div class="card-body">
					<h6 class="text-secondary"><span class='translate' data-i18n='2253' notes='Job Risk Assessment'></span></h6>
					<label for="rmm_jra_title"><span class='translate' data-i18n='1308' notes='Document Information'></span></label>
					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single-jra" onChange="getRADraftData(this)">
						</select>
						<label for="draft"><span class='translate' data-i18n='1474' notes='Form Drafts'></span></label>
					</div>

					<div class="md-form">
						<textarea name="rmm_jra_title" id="rmm_jra_title" class="form-control md-textarea character_counter" wrap="VIRTUAL" onkeyup="inputBinding(this)" required ></textarea>
						<label for="rmm_jra_title"><span class='translate' data-i18n='1304' notes='Title'></span></label>
					</div>

					<div class="md-form">
						<textarea name="rmm_jra_scope" id="rmm_jra_scope" class="form-control md-textarea character_counter" wrap="VIRTUAL"  onkeyup="inputBinding(this)" required></textarea>
						<label for="rmm_jra_scope"><span class='translate' data-i18n='1309' notes='Scope / Context'></span></label>
					</div>

					<?php include 'includes/CommonFormHeaderRMM.php' ?>
				</div>
			</div>

			<div >
				<!-- Accordian Wrapper -->
				<div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
					<ul id="sortable" class="pl-0">
					</ul>
				</div>  
				<div class="btn btn-flat px-0 font-weight-bolder text-primary" id="addStepCategoryButton"><i class="fa fa-plus"></i><span class='translate' data-i18n='2270' notes='ADD STEP'></span></div>
			
			</div>
			<div id='blackLines'></div>
			<div class="card mb-4">
				<div class="card-body">
					<?php include 'includes/CommonFormFooterRMM.php' ?>
				</div>
			</div>	

			<input type="hidden" name="formname" id="formname" note="Job Risk Assessment" class = "trans_input" value="2253"  tag="2253" />
			<input type="hidden" name="formtype" id="formtype" value="JRA" />
			<input type="hidden" name="formid" id="formid" value="999999" />
			<input type="hidden" name="version" id="version" value="1" />
			<input type="hidden" name="_rev" id="_rev" value="" />
			<input type="hidden" name="_id" id="_id" value="" />
			<input type="hidden" name="keyField" id="keyField" value="rmm_jra_site|rmm_jra_workplace" />
			<input type="hidden" name="draftField" id="draftField" value="draft" />
		</form>
	</div>
</main>

<script type="text/javascript">

var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
			formHeader.populateProjectSelect()
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},
		
		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
			
			if(theForm.formid.value == '')	{
				alert("There is an issue with form id");
				throw("Invalid form id");
				return false;
			}

			if(theForm.version.value == '')	{
				alert("There is an issue with form version");
				throw("Invalid version");
				return false;
			}

			return true;
		}	
}

var today = moment(new Date(),'YYYY-MM-DD')

var todayDate = today.subtract(_POUCHDB_DELETE_THRESHOLD_DAYS, 'days').format('YYYY-MM-DD')

jraObject = {
	"jra_data": newJraData(),
	"jra_hazard_actions": [],
	"jra_general_actions": [],
}

// Function for a new jra object
function newJraData() {
	return {
		"rmm_jra_id": null,
		"rmm_jra_document_number": null,
		"rmm_jra_doc_version_number": null,
		"rmm_jra_title": null,
		"rmm_jra_scope": null,
		"rmm_jra_expiry_date": null,
		"rmm_jra_site_id": null,
		"rmm_jra_job_id": null,
		"rmm_jra_workplace": null,
		"rmm_jra_pra_id": null,
		"rmm_jra_other_participants": null,
		"rmm_jra_state": "draft",
		"rmm_jra_date": moment(new Date(),'YYYY-MM-DD').format('YYYY-MM-DD'),
		"rmm_jra_created_by_per_id": null,
		"participants": [],
		"approvers": [],
		"rmm_jra_is_submitted": false,
		"rmm_jra_revision_no": null,
		"step_categories": [newStepCategory()],
		"approversList": [],
		"rmm_jra_executive_summary": null,
		"rmm_jra_submitted_date": null,
		"applicable_line_items": [],
		"rmm_jra_created_date": null
	}
}

// Function for a new step category object
function newStepCategory() {
	return {
		rmm_jsc_step: null,
		rmm_jsc_id: null,
		rmm_jsc_sort: 1,
		rmm_jsc_enable: true,
		threats: [newThreat()]
	}
}

// Function for a threat object
function newThreat() {
	return {
		rmm_jth_id: null,
		rmm_jth_jsc: null,
		rmm_jth_threat: null,
		rmm_jth_outcome: null,
		applicable_line_items: [],
		rmm_jth_severity_category: null,
		rmm_jth_likelyhood_preliminary_id: null,
		rmm_jth_severity_preliminary_id: null,
		rmm_jth_preliminary_risk: null,
		rmm_jth_preliminary_risk_text: null,
		rmm_jth_risk_alara_preliminary: null,
		rmm_jth_likelyhood_residual: null,
		rmm_jth_severity_residual: null,
		rmm_jth_residual_risk: null,
		rmm_jth_residual_risk_text: null,
		rmm_jth_risk_alara_residual: null,
		rmm_jth_created_by_per: null,
		rmm_jth_modified_date: null,
		rmm_jth_modified_by_per: null,
		rmm_jth_enable: true,
		rmm_jth_enote: null,
		control_measures: [],
		additional_control_measures:[],
		rmm_jth_risk: null
	}
}

// Function for a tag object
function newTag() {
	return {
		rmm_jta_id: null,
		rmm_jta_jth: null,
		tag: null,
		rmm_jta_tag_name:null,    
		rmm_jta_blueline: false,
		rmm_jta_enable: true
	}
}


tmpDeletedStepCategories = []
tmpDeletedThreat = []
likelyHoodList = []
severityList = []

risk_values = {}
let data=[]
changesInForm = false

function addThreat(ele,inputStepIndex,init,mode='normal') {
	if(inputStepIndex!="null"){
		stepIndex=inputStepIndex
		stepLabel=stepIndex+1
	}
	else{
		element=ele.previousElementSibling
		element=element.id.split('-')
		stepIndex=parseInt(element.pop())
		stepLabel=stepIndex+1
	}
	appendNode=document.getElementById(`threat_html-${stepIndex}`)
	if(!init){
		jraObject.jra_data.step_categories[stepIndex].threats.push(newThreat())
	}	
	threatIndex=jraObject.jra_data.step_categories[stepIndex].threats.length-1
				
	let addThreatsModel = document.createElement('div')
	addThreatsModel.innerHTML = 
			`
			<div id="rmmRiskBar-${threatIndex}-${stepIndex}"class="delete-event row position-relative riskBar barMuted">
			<div class="position-absolute w-100 p-2 ml-5">
				<span class="float-right">
					<div class="dropdown">	
						<i id='rmm_oev_delete-${threatIndex}-${stepLabel}' class="far fa-trash-alt mr-4 check-index text-primary" data-i18n='3807' title="" style="cursor: pointer;" data-toggle="dropdown"></i>
						<div class="dropdown-menu dropdown-menu-right dropdown-primary">
							<span style="font-weight: bold;"><Strong><span class='translate' data-i18n='2269' notes='Delete this Threat?'></span></Strong></span>
							<a class="dropdown-item"><i><span class='translate' data-i18n='1380' notes='No'></span></i></a>
							<a class="dropdown-item" name="rmm_jth_threat_delete-${threatIndex}-${stepLabel}" id="rmm_jth_threat_delete-${threatIndex}-${stepLabel}"  onclick="deleteEvent(this)"><i><span class='translate' data-i18n='1379' notes='Yes'></span></i></a>		
						</div>
					</div>
				</span>
			</div>
			<div class="col-12">
				<div class="md-form mb-0">
					<input class="form-control" name="rmm_jth_threat-${threatIndex}-${stepLabel}" id="rmm_jth_threat-${threatIndex}-${stepLabel}" onkeyup="inputBinding(this,'threat')" type="text" maxlength="200" required/>
					<label for="rmm_jth_threat-${threatIndex}-${stepLabel}"><span class='translate' data-i18n='2115' notes='Threat'></span></label>
				</div>
			</div>
			<div class="col-12">
				<div class="md-form mb-0">
					<textarea class="md-textarea form-control" rows="1" name="rmm_jth_outcome-${threatIndex}-${stepLabel}" id="rmm_jth_outcome-${threatIndex}-${stepLabel}" onkeyup="inputBinding(this,'threat')" type="text" required></textarea>
					<label for="rmm_jth_outcome-${threatIndex}-${stepLabel}"><span class='translate' data-i18n='2264' notes='Outcome/Context'></span></label>
				</div>
			</div>
			<div class="col-12 d-flex flex-row mt-2">
				<div id= "control_measure-${threatIndex}-${stepLabel}" class="chips md-form mb-0 mt-3 w-100">                                               
				</div>
				<i class="far fa-list-alt mt-4 px-2 pt-3"  data-i18n='2265' note="Black Line Controls" title="" onclick="openBlueLineControlModal(this)" style="cursor: pointer;"></i>
			</div>
			<div class="col-6 col-xl-3">
				<div class="pt-1 position-relative my-4">
					<select name="rmm_jth_likelyhood_preliminary-${threatIndex}-${stepLabel}" id="rmm_jth_likelyhood_preliminary-${threatIndex}-${stepLabel}" class="select-single-jra mobile-likelihood-select" single onChange="evalPreliminaryRisk(this)">
					</select>
					<label for="rmm_jth_likelyhood_preliminary-${threatIndex}-${stepLabel}"><span class='translate' data-i18n='2110' notes='Likelihood'></span></label>
				</div>				
			</div>
			<div class="col-6 col-xl-3">
				<div class="pt-1 position-relative my-4">
					<select name="rmm_jth_severity_preliminary-${threatIndex}-${stepLabel}" id="rmm_jth_severity_preliminary-${threatIndex}-${stepLabel}" class="select-single-jra mobile-severity-select" single onChange="evalPreliminaryRisk(this)">
					</select>
					<label for="rmm_jth_severity_preliminary-${threatIndex}-${stepLabel}"><span class='translate' data-i18n='2111' notes='Severity'></span></label>
				</div>
			</div>
			<div class="col-6 col-xl-3 d-flex flex-row mt-2">
				<div class="md-form mb-0 mt-3 w-100">
					<input class="form-control" name="rmm_jth_preliminary_risk-${threatIndex}-${stepLabel}" id="rmm_jth_preliminary_risk-${threatIndex}-${stepLabel}" type="text" disabled/>
					<label for="rmm_jth_preliminary_risk-${threatIndex}-${stepLabel}"><span class='translate' data-i18n='2117' notes='Residual Risk'></span></label>
				</div>
				<div class="dropdown dropdown-menu-left">
					<i class="fa fa-table mt-4 px-2 pt-2" style="cursor: pointer;" data-i18n='3806' note="Legends" title="" data-toggle="dropdown"></i>
					<div class="dropdown-menu dropdown-menu-right dropdown-primary">
					<small>
						<table class="table table-bordered table-sm riskMatrix">
							<tr>
								<th colspan="2" rowspan="2"><span class='translate' data-i18n='2297' notes='Risk'></span></th>
								<th colspan="5"><span class='translate' data-i18n='3616' notes='Severity of Loss'></span></th>
							</tr>
							<tr>
								<td><span class='translate' data-i18n='4918' notes='Minor'></span></td>
								<td><span class='translate' data-i18n='1076' notes='Moderate'></span></td>
								<td><span class='translate' data-i18n='4919' notes='Significant'></span></td>
								<td><span class='translate' data-i18n='1078' notes='Major'></span></td>
								<td><span class='translate' data-i18n='1079' notes='Catastrophic'></span></td>
							</tr>
							<tr>
								<th rowspan="5"><span class="vertical-text translate" style="writing-mode: vertical-lr;" data-i18n='2110' note="Likelihood"></span></th>
								<td><span class='translate' data-i18n='4913' notes='Certain'></span></td>
								<td class="yellow"><span class='translate' data-i18n='3627' notes='Medium'></span></td>
								<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
								<td class="danger-color text-white"><span class='translate' data-i18n='3626' notes='Extreme'></span></td>
								<td class="danger-color text-white"><span class='translate' data-i18n='3626' notes='Extreme'></span></td>
								<td class="danger-color text-white"><span class='translate' data-i18n='3626' notes='Extreme'></span></td>
							</tr>
							<tr>
								<td><span class='translate' data-i18n='4914' notes='Likely'></span></td>
								<td class="yellow"><span class='translate' data-i18n='3627' notes='Medium'></span></td>
								<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
								<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
								<td class="danger-color text-white"><span class='translate' data-i18n='3626' notes='Extreme'></span></td>
								<td class="danger-color text-white"><span class='translate' data-i18n='3626' notes='Extreme'></span></td>
							</tr>
							<tr>
								<td><span class='translate' data-i18n='4915' notes='Possible'></span></td>
								<td class="success-color text-white"><span class='translate' data-i18n='3628' notes='Low'></span></td>
								<td class="yellow"><span class='translate' data-i18n='3627' notes='Medium'></span></td>
								<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
								<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
								<td class="danger-color text-white"><span class='translate' data-i18n='3626' notes='Extreme'></span></td>
							</tr>
							<tr>
								<td><span class='translate' data-i18n='4916' notes='Unlikely'></span></td>
								<td class="success-color text-white"><span class='translate' data-i18n='3628' notes='Low'></span></td>
								<td class="success-color text-white"><span class='translate' data-i18n='3628' notes='Low'></span></td>
								<td class="yellow"><span class='translate' data-i18n='3627' notes='Medium'></span></td>
								<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
								<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
							</tr>
							<tr>
								<td><span class='translate' data-i18n='4917' notes='Rare'></span></td>
								<td class="success-color text-white"><span class='translate' data-i18n='3628' notes='Low'></span></td>
								<td class="success-color text-white"><span class='translate' data-i18n='3628' notes='Low'></span></td>
								<td class="success-color text-white"><span class='translate' data-i18n='3628' notes='Low'></span></td>
								<td class="yellow"><span class='translate' data-i18n='3627' notes='Medium'></span></td>
								<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
							</tr>
						</table>
					</small>
					</div>
				</div>
			</div>
			<div class="col-6 col-xl-3">
				<div class="pt-1 position-relative my-4">
					<select class='select-single-jra' name="rmm_jth_risk_alara_preliminary-${threatIndex}-${stepLabel}"  id="rmm_jth_risk_alara_preliminary-${threatIndex}-${stepLabel}" onChange="changeALARA(this)">
						<option value=""></option>
						<option value="1"><span class='translate' data-i18n='1379' notes='yes'>${i18next.t('1379')}</span></option>
						<option value="0"><span class='translate' data-i18n='1380' notes='no'>${i18next.t('1380')}</span></option>
					</select>
					<span style="position:absolute;top:-23px;right:-3px;"><i class="fas fa-question-circle text-secondary trans_tooltip" data-toggle="tooltip" note="ALARA is an acronym that stands for As Low As Reasonably Achievable" tag="3809"></i></span>
					<label for="rmm_jth_risk_alara_preliminary-${threatIndex}-${stepLabel}" title=""><span class='translate' data-i18n='2267' notes='Is Risk Alara?'></span></i></label>
				</div>
			</div>
			<div id = "rmm_additional_controls-${threatIndex}-${stepLabel}" class="container-fluid d-none">
			<div class="row">
		<!-- Start -->
		<div class="col-12 d-flex flex-row mt-2">
			<div id= "additional_measure-${threatIndex}-${stepLabel}" class="chips md-form mb-0 mt-3 w-100">
			</div>
		</div>
		<div class="col-6 col-xl-3">
			<div class="pt-1 position-relative my-4">
				<select name="rmm_jth_likelyhood_residual-${threatIndex}-${stepLabel}" id="rmm_jth_likelyhood_residual-${threatIndex}-${stepLabel}" class="select-single-jra mobile-likelihood-select" single onChange="evalResidualRisk(this)">
				</select>
				<label for="rmm_jth_likelyhood_residual-${threatIndex}-${stepLabel}"><span class='translate' data-i18n='2110' notes='Likelihood'></span></label>
			</div>				
		</div>
		<div class="col-6 col-xl-3">
			<div class="pt-1 position-relative my-4">
				<select class='select-single-jra mobile-severity-select' name="rmm_jth_severity_residual-${threatIndex}-${stepLabel}" id="rmm_jth_severity_residual-${threatIndex}-${stepLabel}" onChange="evalResidualRisk(this)">
					<option value=""></option>
				</select>
				<label for="rmm_jth_severity_residual-${threatIndex}-${stepLabel}" note="Severity"><span class='translate' data-i18n='2111' notes='Likelihood'></span></label>
			</div>
		</div>
		<div class="col-6 col-xl-3 d-flex flex-row mt-2">
			<div class="md-form mb-0 mt-3 w-100">
				<input class="form-control" name="rmm_jth_residual_risk-${threatIndex}-${stepLabel}" id="rmm_jth_residual_risk-${threatIndex}-${stepLabel}" type="text" disabled/>
				<label for="rmm_jth_residual_risk-${threatIndex}-${stepLabel}"  note="Residual Risk"><span class='translate' data-i18n='2117' notes='Likelihood'></span></label>
			</div>
			<div class="dropdown dropdown-menu-left">
				<i class="fa fa-table mt-4 px-2 pt-2" style="cursor: pointer;" note="Legends" title="{{menu.translateLabels(3806)}}" data-toggle="dropdown"></i>
				<div class="dropdown-menu dropdown-menu-right dropdown-primary">
					<table class="table table-bordered table-sm riskMatrix">
						<tr>
							<th colspan="2" rowspan="2"><span class='translate' data-i18n='2297' notes='Risk'></span></th>
							<th colspan="5"><span class='translate' data-i18n='3616' notes='Severity of Loss'></span></th>
						</tr>
						<tr>
							<td><span class='translate' data-i18n='4918' notes='Minor'></span></td>
							<td><span class='translate' data-i18n='1076' notes='Moderate'></span></td>
							<td><span class='translate' data-i18n='4919' notes='Significant'></span></td>
							<td><span class='translate' data-i18n='1078' notes='Major'></span></td>
							<td><span class='translate' data-i18n='1079' notes='Catastrophic'></span></td>
						</tr>
						<tr>
							<th rowspan="5"><span class="vertical-text translate" style="writing-mode: vertical-lr;" data-i18n='2110' note="Likelihood"></span></th>
							<td><span class='translate' data-i18n='4913' notes='Certain'></span></td>
							<td class="yellow"><span class='translate' data-i18n='3627' notes='Medium'></span></td>
							<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
							<td class="danger-color text-white"><span class='translate' data-i18n='3626' notes='Extreme'></span></td>
							<td class="danger-color text-white"><span class='translate' data-i18n='3626' notes='Extreme'></span></td>
							<td class="danger-color text-white"><span class='translate' data-i18n='3626' notes='Extreme'></span></td>
						</tr>
						<tr>
							<td><span class='translate' data-i18n='4914' notes='Likely'></span></td>
							<td class="yellow"><span class='translate' data-i18n='3627' notes='Medium'></span></td>
							<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
							<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
							<td class="danger-color text-white"><span class='translate' data-i18n='3626' notes='Extreme'></span></td>
							<td class="danger-color text-white"><span class='translate' data-i18n='3626' notes='Extreme'></span></td>
						</tr>
						<tr>
							<td><span class='translate' data-i18n='4915' notes='Possible'></span></td>
							<td class="success-color text-white"><span class='translate' data-i18n='3628' notes='Low'></span></td>
							<td class="yellow"><span class='translate' data-i18n='3627' notes='Medium'></span></td>
							<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
							<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
							<td class="danger-color text-white"><span class='translate' data-i18n='3626' notes='Extreme'></span></td>
						</tr>
						<tr>
							<td><span class='translate' data-i18n='4916' notes='Unlikely'></span></td>
							<td class="success-color text-white"><span class='translate' data-i18n='3628' notes='Low'></span></td>
							<td class="success-color text-white"><span class='translate' data-i18n='3628' notes='Low'></span></td>
							<td class="yellow"><span class='translate' data-i18n='3627' notes='Medium'></span></td>
							<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
							<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
						</tr>
						<tr>
							<td><span class='translate' data-i18n='4917' notes='Rare'></span></td>
							<td class="success-color text-white"><span class='translate' data-i18n='3628' notes='Low'></span></td>
							<td class="success-color text-white"><span class='translate' data-i18n='3628' notes='Low'></span></td>
							<td class="success-color text-white"><span class='translate' data-i18n='3628' notes='Low'></span></td>
							<td class="yellow"><span class='translate' data-i18n='3627' notes='Medium'></span></td>
							<td class="warning-color"><span class='translate' data-i18n='3622' notes='High'></span></td>
						</tr>
					</table>
				</div>
			</div>
		</div>
		<div class="col-6 col-xl-3">
			<div class="pt-1 position-relative my-4">
				<select class='select-single-jra' name="rmm_jth_risk_alara_residual-${threatIndex}-${stepLabel}"  id="rmm_jth_risk_alara_residual-${threatIndex}-${stepLabel}">
					<option value=""></option>
					<option value="1"><span class='translate' data-i18n='1379' notes='yes'>${i18next.t('1379')}</span></option>
					<option value="0"><span class='translate' data-i18n='1380' notes='no'>${i18next.t('1380')}</span></option>
				</select>
				<span style="position:absolute;top:-23px;right:-3px;"><i class="fas fa-question-circle text-secondary trans_tooltip" data-toggle="tooltip" note="ALARA is an acronym that stands for As Low As Reasonably Achievable" tag="3809"></i></span>
				<label for="rmm_jth_risk_alara_residual-${threatIndex}-${stepLabel}" title=""><span class='translate' data-i18n='2267' notes='Is Risk Alara?'></span></label>
			</div>
		</div>
	</div>
			</div>
		</div>
	`
	 appendNode.appendChild(addThreatsModel)

	if(mode === 'normal'){
		formHeader.populateSeveritySelect()
		formHeader.populateLikelihoodSelect()
		initializeSelect2Jra()
	}
	else {
		initializeSelect2JraDynamic(`rmm_jth_likelyhood_preliminary-${threatIndex}-${stepLabel}`)
		initializeSelect2JraDynamic(`rmm_jth_severity_preliminary-${threatIndex}-${stepLabel}`)
		initializeSelect2JraDynamic(`rmm_jth_risk_alara_preliminary-${threatIndex}-${stepLabel}`)
		initializeSelect2JraDynamic(`rmm_jth_likelyhood_residual-${threatIndex}-${stepLabel}`)
		initializeSelect2JraDynamic(`rmm_jth_severity_residual-${threatIndex}-${stepLabel}`)
		initializeSelect2JraDynamic(`rmm_jth_risk_alara_residual-${threatIndex}-${stepLabel}`)
		formHeader.populateSeveritySelect(`rmm_jth_severity_preliminary-${threatIndex}-${stepLabel}`)
		formHeader.populateLikelihoodSelect(`rmm_jth_likelyhood_preliminary-${threatIndex}-${stepLabel}`)
		formHeader.populateSeveritySelect(`rmm_jth_severity_residual-${threatIndex}-${stepLabel}`)
		formHeader.populateLikelihoodSelect(`rmm_jth_likelyhood_residual-${threatIndex}-${stepLabel}`)
		initializeTagsAndPulldowns()
	}
	
	try {
		 $('.translate').localize()
		 reinitializeTranslateTooltips() 
		 $('[data-toggle="tooltip"]').tooltip()
		} catch {}
}	

function initializeSelect2JraDynamic(id) {
  if(!localStorage.getItem(`noinitialize`)) {
    $(`#${id}`).select2({theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder:""})
      .on('select2:select', function(event){
        nameObj = event.currentTarget.name.split('-')
        if(nameObj.length == 1){
          jraObject.jra_data[`${nameObj[0]}`] = parseInt(event.currentTarget.value)
        }
        else {
          jraObject.jra_data.step_categories[nameObj[2]-1].threats[nameObj[1]][`${nameObj[0]}`] = parseInt(event.currentTarget.value)
        }
        $(this).parent().find('label').addClass('filled')
      })
      .on('select2:unselect', function(event){
        if($(".select2-selection__choice")[0]){
        $(this).parent().find('label').addClass('filled')
        }
        else {
          $(this).parent().find('label').removeClass('filled')
        }
        if (event.target.parentNode.querySelector('.mobile-distribution-select')){
          removeDistributionGroup()
        }
      })
      .on('select2:open', function () {
        $('.select2-search__field').attr('placeholder', i18next.t("2346"))
        $('.select2-results').css({'max-height':'260px'})
      })
      .on('select2:close', function () {
        $('.select2-search__field').attr('placeholder', i18next.t("2346"))
       })

    $('.select2-selection__arrow b').addClass("fa fa-caret-down")
  }
}

function refreshSelectsValues() {
	jraObject.jra_data.step_categories.forEach((step, stepindex)=>{
		step.threats.forEach((threat, threatindex)=>{
			$(`#rmm_jth_severity_preliminary-${threatindex}-${stepindex+1}`).val(threat.rmm_jth_severity_preliminary_id).trigger('change')
			$(`#rmm_jth_severity_residual-${threatindex}-${stepindex+1}`).val(threat.rmm_jth_severity_residual).trigger('change')
			$(`#rmm_jth_likelyhood_preliminary-${threatindex}-${stepindex+1}`).val(threat.rmm_jth_likelyhood_preliminary_id).trigger('change')
			$(`#rmm_jth_likelyhood_residual-${threatindex}-${stepindex+1}`).val(threat.rmm_jth_likelyhood_residual).trigger('change')
			$(`#rmm_jth_risk_alara_preliminary-${threatindex}-${stepindex+1}`).val(threat.rmm_jth_risk_alara_preliminary).trigger('change')
			$(`#rmm_jth_risk_alara_residual-${threatindex}-${stepindex+1}`).val(threat.rmm_jth_risk_alara_residual).trigger('change')
		})
	})
}

function inputBinding(element, mode='normal') {
	elementName = element.name.split("-")[0]
	switch(mode){
		case "step": 
			stepIndex = element.name.split("-")[1]
			jraObject.jra_data.step_categories[stepIndex][elementName] = element.value
			break
		case "threat": 
			stepIndex = element.name.split("-")[2]-1
			jraObject.jra_data.step_categories[stepIndex].threats[element.name.split("-")[1]][`${elementName}`] = element.value
			break
		default:
			jraObject.jra_data[`${element.name}`] = element.value
			break

	}
}

function recallJRADraft(draftData, submissionId) {

	draftObj = draftData.formdata
	jraObject = {
		"jra_data": newJraData(),
		"jra_hazard_actions": [],
		"jra_general_actions": [],
	}

	$("#submissionId").val(draftData.submissionID)
	$("#sortable").empty()
	for (let i = 0; i < draftObj.jra_data.step_categories.length; i++) {
		addStepCategory("",i)
		for(j = 0; j < draftObj.jra_data.step_categories[i].threats.length-1; j++) {
			addThreat(null,i)
		}
	}

	$(`#rmm_jra_site`).val(draftObj.jra_data["rmm_jra_site_id"]).trigger('change').parent().find('label').addClass(['filled',"active"])
	$(`#rmm_jra_job`).val(draftObj.jra_data["rmm_jra_job_id"]).trigger('change').parent().find('label').addClass(['filled',"active"])
	$(`#rmm_jra_pra`).val(draftObj.jra_data["rmm_jra_pra_id"]).trigger('change').parent().find('label').addClass(['filled',"active"])
	for (let item in draftObj.jra_data) {
		if(item !== 'rmm_jra_site_id' && item !== 'rmm_jra_job_id' && item !== 'rmm_jra_pra_id') {
			$(`#${item}`).val(draftObj.jra_data[item]).trigger('change').parent().find('label').addClass(['filled',"active"])
		}
		if(item === 'applicable_line_items') {
			setTimeout(()=>{
				$(`#applicable_line_items`).val(draftObj.jra_data['applicable_line_items']).trigger('change').parent().find('label').addClass(['filled',"active"])
				$(`#participants`).val(draftObj.jra_data['participants']).trigger('change').parent().find('label').addClass(['filled',"active"])
				$(`#approvers`).val(draftObj.jra_data['approvers']).trigger('change').parent().find('label').addClass(['filled',"active"])
			},1000)
		}
	}

	draftObj.jra_data.step_categories.forEach((step, stepindex) => {
		$(`#rmm_jsc_step-${stepindex}`).val(step.rmm_jsc_step).trigger('change').parent().find('label').addClass(['filled',"active"])
		step.threats.forEach((threat, threatindex)=>{
			Object.keys(threat).forEach((key) => {
				$(`#${key}-${threatindex}-${stepindex+1}`).val(threat[key]).trigger('change').parent().find('label').addClass(['filled',"active"])
				if( key === 'rmm_jth_preliminary_risk') {
					$(`#${key}-${threatindex}-${stepindex+1}`).val(i18next.t(threat[key])).trigger('change').parent().find('label').addClass(['filled',"active"])
				}
				if( key === 'rmm_jth_residual_risk') {
					$(`#${key}-${threatindex}-${stepindex+1}`).val(i18next.t(threat[key])).trigger('change').parent().find('label').addClass(['filled',"active"])
				}
				if(threat[`rmm_jth_risk_alara_preliminary-${threatindex}-${stepindex+1}`] == 0) {
					$(`#rmm_jth_severity_residual-${threatindex}-${stepindex+1}`).prop('required',true)
					$(`#rmm_jth_likelyhood_residual-${threatindex}-${stepindex+1}`).prop('required',true)
					$(`#rmm_jth_risk_alara_residual-${threatindex}-${stepindex+1}`).prop('required',true)
				}
			})
		})
		jraThreatDots(stepindex)
	})

	$(`#applicable_line_items`).trigger('change').parent().find('label').addClass(['filled',"active"])
	thisDraft =  $('#currentDraft').val()
	sessionStorage.removeItem('draftpick')
	$('#draft').val(thisDraft).trigger('change')
	jraObject = draftObj
}

addAdditionalControls = (threatIndex,stepIndex) => {
	index = threatIndex.name.split("-")
	let prev_element = document.getElementById(`rmm_additional_controls-${index[1]}-${index[2]}`)
	document.getElementById(`rmm_additional_controls-${index[1]}-${index[2]}`).classList.remove("d-none");

}

//Function to delete an event
function deleteEvent(ele) {
	id=ele.id
	id=id.split('-')
	stepIndex=id.pop()
	threatIndex=id.pop()
	stepIndex=parseInt(stepIndex)-1
	ele.closest(".delete-event").remove()
	let tmp_ev_obj = {}
	jraObject.jra_data.step_categories[stepIndex].threats.splice(threatIndex,1)[0]
	reorderThreats(stepIndex)
	if (jraObject.jra_data.step_categories[stepIndex].threats.length === 0){
		addThreat(null,stepIndex)
		return
	}
	
}

function addStepCategory(init, stepI, mode='normal') {
	let newCat = newStepCategory()
	newCat.rmm_jsc_sort =  jraObject.jra_data.step_categories.length + 1
	if(!init){
		jraObject.jra_data.step_categories.push(newCat)
	}	
	stepLabel=jraObject.jra_data.step_categories.length
	stepIndex=stepLabel-1
	if(stepI >= 0) {
		stepIndex = stepI
		stepLabel = stepI + 1
	}
	const addStepCategoryModal = 
	`
	<li class="delete-step ui-state-default card mb-4" id="stepIndex-${stepIndex}">
		<div  id="stepIndex-${stepIndex}"> 
			<!-- Accordion card -->
			<div class="card">
				<!-- Card header -->
				<div class="card-header px-0" role="tab" id="heading-${stepIndex}">
					<!-- Sort Number, Three Icons -->
					<div class="position-absolute w-100 px-3">
						<span class='text-muted' id="step-order-${stepIndex}">${stepLabel}</span>
						<span class="float-right row align-items-center">
							<i class="fas fa-arrows-alt is-3 mr-4 handle" style="color:#696969;cursor: grab;" data-i18n='3804'  note="Drag and Sort" title=""></i>
							<div class="dropdown">
								<i class="far fa-trash-alt mr-4 text-primary" data-i18n='3805' note="Delete Event Category" title="" style="cursor: pointer;" data-toggle="dropdown"></i>
								<div class="dropdown-menu dropdown-menu-right dropdown-primary">
									<Strong><span class='translate' data-i18n='2271' notes='Delete this step?'></span></Strong>
									<a class="dropdown-item"><i><span class='translate' data-i18n='1380' notes='No'></span></i></a>
									<a class="dropdown-item" onclick="deleteStepCategory(this)"><i><span class='translate' data-i18n='1379' notes='Yes'></span></i></a>
								</div>
							</div>
							<a data-toggle="collapse" data-parent="#accordionEx" data-target="#collapse-${stepIndex}" aria-expanded="true" class="mr-3">
								<i class="fas fa-angle-down rotate-icon"></i>
							</a>
						</span>
					</div>
					<!-- Event & Risk Header -->
					<div class="px-5 pb-0">
						<div class="container-fluid"> 
							<div class="row">
								<div class="col-6">
									<div class="md-form mb-0 mt-3">
										<input class="form-control" name="rmm_jsc_step-${stepIndex}" id="rmm_jsc_step-${stepIndex}" type="text" maxlength="200"  onkeyup="inputBinding(this,'step')" required/>
										<label for="rmm_jsc_step-${stepIndex}"><span class='translate' data-i18n='2262' notes='Step'></span></label>
									</div>
								</div>
								<div id="threatDots_${stepIndex}" class="col-4 style='transform: translateY(-10px);'"><small class="d-block"><span class='translate' data-i18n='2263' notes='Risks'></span></small>
									<i class="fa fa-circle text-muted pt-3 pr-2"></i>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Card Body -->
				<div id="collapse-${stepIndex}" class="collapse show" role="tabpanel" aria-labelledby="heading-${stepIndex}" data-parent="#accordionEx">
					<div class="card-body px-5 pt-0">
						<div id="threat_html-${stepIndex}">
						</div>
						<div class="btn btn-flat px-0 font-weight-bold text-primary" onclick="addThreat(this,'null','','noselect2')"><i class="fa fa-plus"></i><span class='translate' data-i18n='2268' notes='Add Threat'></span></div>
					</div>
				</div>
			</div>
		</div>
	</li>
	`
	
	$("#sortable").append(addStepCategoryModal)
	addThreat(document.getElementById(`threat_html-${stepIndex}`),stepIndex,'init', mode)
	
	if(mode == 'normal') {
		setTimeout(()=>{
			initializeTagsAndPulldowns()
		},100)
	}
}

$('#addStepCategoryButton').click((e)=>{
	addStepCategory('',-1, "noselect2")
})

//Function to delete an step category
function deleteStepCategory(ele) {
	id=ele.parentNode.parentNode.parentNode.parentNode.firstChild.nextElementSibling.id
	stepIndex=id.split("-").pop()
	ele.closest(".delete-step").remove()
	let tmp_ec_obj = {}
	jraObject.jra_data.step_categories[stepIndex].rmm_jsc_enable = false
	tmp_ec_obj = jraObject.jra_data.step_categories.splice(stepIndex,1)[0]
	jraObject.jra_data.step_categories.forEach((val, index) => {
		val.rmm_jsc_sort = parseInt(index)+1
	});
	tmpDeletedStepCategories.push(tmp_ec_obj)
	reorderStep()
	if ( jraObject.jra_data.step_categories.length === 0){
		addStepCategory()
		return
	}
}

function reorderStep(){
	jraObject.jra_data.step_categories.forEach((val, index) => { 

		document.getElementsByClassName('delete-step')[index].id = "stepIndex-" + index
		let newSteps = document.getElementsByClassName('delete-step')[index].querySelectorAll("[id^='rmm_jsc_step-'],[id^='collapse-'],[id^='threat_html-']")
		for (i of newSteps) {
			let id=i.id.split('-')
			id.pop()
			newId=id+'-'+index
			i.id=newId
			i.name=newId
			if(i.nextElementSibling){
				if(i.nextElementSibling.hasAttribute("for")){
					i.nextElementSibling.setAttribute('for',newId)
				}
			}	
			
		}
		let newThreats = document.getElementsByClassName('delete-step')[index].querySelectorAll("[id^='rmm_oev_delete-'],[id^='rmm_jth_'],[id^='control_measure-'],[id^='rmm_additional_controls-'],[id^='additional_measure-']")	
		for (i of newThreats) {
			let id=i.id.split('-')
			id.pop()
			id=id.join("-")
			newId=id+'-'+(index+1)
			i.id=newId
			i.name=newId
			if(i.nextElementSibling){
				if(i.nextElementSibling.hasAttribute("for")){
					i.nextElementSibling.setAttribute('for',newId)
				}
			}		
		}
		document.getElementsByClassName('delete-step')[index].firstElementChild.id='stepIndex-'+index
		document.getElementsByClassName('delete-step')[index].firstElementChild.firstElementChild.firstElementChild.id='heading-'+index
		document.getElementsByClassName('delete-step')[index].firstElementChild.querySelector('.text-muted').innerHTML=index+1

		let collapseElements = document.getElementsByClassName('delete-step')[index].querySelectorAll("[data-target^='#collapse-']")
		for (i of collapseElements) {
			i.setAttribute('data-target', '#collapse-'+index)
		}
	})
}

function reorderThreats(stepIndex){ 
	stepLabel=stepIndex+1
	myThreats=document.getElementsByClassName('delete-step')[stepIndex].getElementsByClassName('delete-event')
	for(let i = 0; i < myThreats.length; i++){
		needChangeThreatsNames=myThreats[i].querySelectorAll("[id^='rmm_oev_delete-'],[id^='rmm_jth_'],[id^='control_measure-'],[id^='rmm_additional_controls-'],[id^='additional_measure-']")
		for (j of needChangeThreatsNames) {
			let id=j.id.split('-')
			newId=`${id[0]}-${i}-${stepLabel}`
			j.setAttribute("id",newId)
			j.name=newId
			if(j.nextElementSibling){
				if(j.nextElementSibling.hasAttribute('for')){
					j.nextElementSibling.setAttribute('for',newId)
				}
			}		
		}
	}
}

function dragAndSort(){
	$( "#sortable" ).sortable({
		items: "li:not(.ui-state-disabled)",
		stop: function( event, ui ) {
			id_moved = ui.item[0]
			c = document.getElementById("sortable").children
			for (i = 0; i < c.length; i++){
				if (id_moved.id == c[i].id) {
					old_index = parseInt(id_moved.id.split("-").pop())
					new_index = parseInt(i)
				}
			}

			moved = jraObject.jra_data.step_categories.pop(old_index)
			jraObject.jra_data.step_categories.splice(new_index, 0, moved)

			for(i in jraObject.jra_data.step_categories){
				jraObject.jra_data.step_categories[parseInt(i)].rmm_jsc_sort=parseInt(i)+1
			}
			reorderStep()
		}

	});

	$( "#sortable" ).sortable({ handle: '.handle'})
	$( "#sortable" ).draggable({ handle: '.handle'})
	$( "#sortable" ).disableSelection()

}

// An abstrect function to initialize the dropdowns and tags
function initializeTagsAndPulldowns(){
		initializeTags() 
		setTimeout(() => {
			initializeBlueline()
		}, 1000); 
}

function validateChips(){
	let chipVal = true
	jraObject.jra_data.step_categories.forEach((step, stepIndex)=> {
		step.threats.forEach((threat, threatIndex)=>{
			if(threat.control_measures.length == 0) {
					chipVal = false
					$(`#control_measure-${threatIndex}-${stepIndex+1}`).css('border-bottom','1px solid rgb(220, 53, 69)')
			}
			if(threat.rmm_jth_risk_alara_preliminary == 0) {
					if(threat.additional_control_measures.length == 0) {
						chipVal = false
						$(`#additional_measure-${threatIndex}-${stepIndex+1}`).css('border-bottom','1px solid rgb(220, 53, 69)')
					}
			}
		})
	})
	return chipVal
}


function groupby(xs, key) {
	return xs.reduce(function(rv, x) {
		(rv[x[key]] = rv[x[key]] || []).push(x.tag);
		return rv;
	}, {});
};

// Function to open Blue line control modal
function openBlueLineControlModal(ele){
	function failedValidate() {
		let formModal = new SofvieModal();                                                                                                 // initialize the Modal 
		formModal.setModalElements(`danger`, `modalTitle`, i18next.t("1403")) // "Validation error"
		formModal.setModalElements(`danger`, `modalText`, i18next.t("3855"))  // "Select an Applicable line item"
		formModal.setModalElements(`danger`, `modalButtons`, `<a role="button" class="btn btn-danger waves-effect" id="modalClose"><span class='translate' data-i18n="1405" notes="Ok"></a>`)
		formModal.handleModal(`danger`)  
		$('.translate').localize()
		$('#modalClose').click(()=>{
			$(`#${formModal.name}`).modal('hide')
			$(`#${formModal.name}`).hide()
		})
		return false

	}

	if (applicable_line_items === [] || applicable_line_items === undefined || applicable_line_items === null) {
		return
	}
	if ($("#applicable_line_items").val().length === 0){
		failedValidate()
		return
	}	
	rmm_pra_id = jraObject.rmm_jra_pra
	rmm_pec_id = []
	for(i of jraObject.jra_data.applicable_line_items){
		rmm_pec_id.push(i)
	}
	currentElement=ele.parentElement.firstChild.nextElementSibling.id
	currentIndex=currentElement.split("-")
	ec_index = currentIndex[2]-1
	th_index = currentIndex[1]
	current_ora_blueline=OraBluelineData.filter((data) => data.rmm_pra_id ==rmm_pra_id)
	current_pra_blueline=[]
	for(i in rmm_pec_id){
		current_pra_blueline.push(PraBluelineData.filter((data) => data.rmm_pec_id ==rmm_pec_id[i]))
	}
	jraObject.jra_data.step_categories[ec_index].threats[th_index].control_measures.forEach((cm)=>{
		
		let new_ora_blueLine = []
		for (let i = 0; i < current_ora_blueline.length; i++) {
			if(cm.tag.trim().toLowerCase() !== current_ora_blueline[i].tag.trim().toLowerCase() ){
				new_ora_blueLine.push(current_ora_blueline[i]) 
			}
		}
		current_ora_blueline = new_ora_blueLine

		let new_pra_blueLine = []
		for (let i = 0; i < current_pra_blueline.length; i++) {
			let sub_pra_blueLine =[]
			for(let j = 0; j < current_pra_blueline[i].length; j++){
				if(cm.tag.trim().toLowerCase()  !== current_pra_blueline[i][j].tag.trim().toLowerCase() ){
					sub_pra_blueLine.push(current_pra_blueline[i][j]) 
				}
			}
			new_pra_blueLine.push(sub_pra_blueLine)
		}
		current_pra_blueline = new_pra_blueLine
	})

	event_grouped_ora_blueline = groupby(current_ora_blueline, "event")
	event_grouped_pra_blueline =[]
	for(i in current_pra_blueline){
		event_grouped_pra_blueline.push(groupby(current_pra_blueline[i], "event"))
	}
	event_grouped_ora_blueline2 = []
	event_grouped_pra_blueline2 = []
	function addTagName (data, arr) {
		for (const [key, value] of Object.entries(data)) {
			arr.push({"event": key, "tags": value})
		}
	}

	addTagName(event_grouped_ora_blueline, event_grouped_ora_blueline2)
	for(i in event_grouped_pra_blueline){
		addTagName(event_grouped_pra_blueline[i], event_grouped_pra_blueline2)
	}
	
	getShowAccordianIds()

	

	function getShowAccordianIds(){
                var expanded_elements = document.getElementsByClassName('collapse show')
                exp_ids = []
                for (let i = 0; i < expanded_elements.length; i++) {
                    exp_ids.push(expanded_elements[i].id)
                }
            }

	const blackLinesModal = 
	`
	<div class="modal" id="blackLinesModal" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
		<div class="modal-dialog modal-notify modal-info" style="background-color:" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<p class="heading lead"><span class='translate' data-i18n="2265" notes="Black Line Controls"></span></p>
				</div>

				<div class="col-12">
					<div class="card my-3">
					<h5 class="card-title pl-4 pt-4 mt-1"><strong><span class='translate' data-i18n="3629" note="ORA Controls"></span></strong></h5>
						<table id="oraTable" class="blackLineTable display pl-2 pr-2" style="width:100%"></table>
					</div>
				</div>

				<div class="col-12">
					<div class="card my-3">
						<h5 class="card-title pl-4 pt-4 mt-1"><strong><span class='translate' data-i18n="3630" note="PRA Controls"></span></strong></h5>
						<table id="praTable" class="blackLineTable display pl-2 pr-2" style="width:100%"></table>
					</div>
				</div>
				<div class="modal-footer justify-content-center">
					<a role="button" type="button" class="btn btn-outline-primary btn-rounded m-0 mr-3" id="cancelBlackLinesModal" data-dismiss="modal"><span class='translate' data-i18n="1257" notes="Cancel"></span></a>
					<a role="button" class="btn btn-primary btn-rounded m-0" id="saveBlackLinesModal" data-dismiss="modal"><span class='translate' data-i18n="2266" notes="Apply"></span></a>
				</div>
			</div>
		</div>
	</div>`
	
	$("#blackLines").empty().append(blackLinesModal)
	$('.translate').localize()
	let selectedItems =[]
	$("#saveBlackLinesModal").click(() => {
		if (selectedItems.length > 0) {
			contolData = pushTagstoCMAndCloseModal(selectedItems,ec_index,th_index)
			setbackAccordian()
			setTimeout(() => {
				refreshtags(`#control_measure-${th_index}-${ec_index+1}`, contolData)
			}, 1000)
		}
		
		function refreshtags(id, controlData) {
			$(id).replaceWith($(id).clone())
			$(id).materialChip({
				placeholder: '+ ' + i18next.t(2478),
				secondaryPlaceholder: i18next.t(2109),
				data: controlData
			})
			params = id.split("-")
			initializeBlueline(parseInt(params[2])-1,parseInt(params[1]))
		}

		function setbackAccordian(){
			setTimeout(() => {
				var accordian_elements = document.getElementsByClassName('collapse')
				for (let i = 0; i < accordian_elements.length; i++) {
					if(!exp_ids.includes(accordian_elements[i].id)){
						var removeClass_id = "#"+accordian_elements[i].id
						$(removeClass_id).removeClass('show')
					}
				}
			}, 500)
		}

		//Function to Push Tags to CM and close Modal
		function pushTagstoCMAndCloseModal (selectedItems,ec_index,th_index) {
			selectedItems.forEach((tag)=>{
				blueLineCMObj = newTag()
				blueLineCMObj.tag = tag
				blueLineCMObj.rmm_jta_blueline = true
				jraObject.jra_data.step_categories[ec_index].threats[th_index].control_measures.push(blueLineCMObj)
			})
			return jraObject.jra_data.step_categories[ec_index].threats[th_index].control_measures
		}
	})
	
	/* Formatting function for row details - modify as you need */
	function format(d) {
		tags = ""
		for (i of d.tags) {
			tags += 
			'<tr class="selectable">' +
			'<td>' +
			i +
			'</td>' +
			'</tr>'
		}
		return (
			'<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;" class="multi">' +
			tags +
			'</table>'
		);
	}

	oraTable = $("#oraTable").DataTable( {
		name: "oraTable",
		data: event_grouped_ora_blueline2,
		bLengthChange: false,
		oLanguage: {
				sSearch: i18next.t("1136")
				},
		language: {
				emptyTable: i18next.t("1370"),
				info: "_START_ to _END_ of _TOTAL_",
				infoEmpty: "0 of 0",
				infoFiltered: ""
				},
		columnDefs: [
            {
                target: 2,
                visible: false,
            },

        ],
		columns: [
			{
				className: 'dt-control',
				orderable: false,
				data: null,
				defaultContent: '',
			},
			{ data: 'event' },
			{ data: 'tags'}
		],
		order: [[1, 'asc']],
	} );

	praTable = $("#praTable").DataTable( {
		name: "praTable",
		data: event_grouped_pra_blueline2,
		bLengthChange: false,
		oLanguage: {
					sSearch: i18next.t("1136")
				},
		language: {
					emptyTable: i18next.t("1370"),
					info: "_START_ to _END_ of _TOTAL_",
					infoEmpty: "0 of 0",
					infoFiltered: ""
				},
		columnDefs: [
            {
                target: 2,
                visible: false,
            },
        ],
		columns: [
			{
				className: 'dt-control',
				orderable: false,
				data: null,
				defaultContent: '',
			},
			{ data: 'event'},
			{ data: 'tags'}
		],
		order: [[1, 'asc']],
	} )

	function selectItems(event, blueLineTable){
		ele = event.target
		var tr = $(ele).closest('tr');
		if (!ele.classList.contains("dt-control") && (ele.parentElement.classList.contains("even") || ele.parentElement.classList.contains("odd"))){
			tr.toggleClass('selected')
			if (blueLineTable.row(tr).child.isShown()) {
				if(ele.parentElement.classList.contains('selected')){
					$.each($(tr.next()).find("tr.selectable"), function(){
						this.classList.add('selected')
						selectedItems.push(this.textContent)
					})
				}
				else{
					$.each($(tr.next()).find("tr.selectable"), function(){
						let idx = selectedItems.indexOf(this.textContent)
						if (idx != -1) selectedItems.splice(idx, 1)
						this.classList.remove('selected')
					});
				}
			}
			else {
				let row = blueLineTable.row(tr)
				if(tr.hasClass('selected')){					
					$.each(row.data().tags,function () {
						selectedItems.push(this.valueOf())
					})
				}
				else{
					$.each(row.data().tags,function () {
						let idx = selectedItems.indexOf(this.valueOf())
						if (idx != -1) selectedItems.splice(idx, 1);
					})
				}
			}

		}
		else if(ele.parentElement.classList.contains('selectable')){ //child element is choosen
			pareantElementSelected=true
			if(ele.parentElement.classList.contains('selected')){
				tagElements=$(ele).closest('table').find("tr.selectable")
				$.each(tagElements, function(){
					if(!this.classList.contains('selected')){
						pareantElementSelected=false
						return
					}
				})
			}
			else{
				pareantElementSelected=false
			}
			if(pareantElementSelected==false){
				$(ele).closest('table').parent().parent().prev().first().removeClass('selected')
			}
			else if(pareantElementSelected==true){
				$(ele).closest('table').parent().parent().prev().first().addClass('selected')
			}
			if(tr.hasClass('selected') && !selectedItems.includes(ele.textContent)){
				selectedItems.push(ele.textContent)
			}
			else if(!tr.hasClass('selected')){
				let idx = selectedItems.indexOf(ele.textContent)
				if (idx != -1) selectedItems.splice(idx, 1);
			}
		}
		selectedItems = [... new Set(selectedItems)]
	}

	function expandTags(event,blueLineTable){
		ele = event.target
		var tr = $(ele).closest('tr');
		var row = blueLineTable.row(tr);
		
		if (row.child.isShown()) {
			// ele row is already open - close it
			row.child.hide();
			tr.removeClass('shown');
		} else {
			if (row.child()) {
				row.child.show();
			} else {
				row.child(format(row.data())).show();
			}
			tr.addClass('shown');

			if (ele.parentElement.classList.contains('selected')) {
				$.each([$(tr.next()).find("tr.selectable")], function(){
					this.addClass('selected')
				});
			}
		}	

		$(".multi").css("width", "100%")
	}

	$('#oraTable tbody').on('click', 'td', (event) => selectItems(event, oraTable))	
	$('#oraTable tbody').on('click', 'td.dt-control', (event) => expandTags(event, oraTable))
	$('#praTable tbody').on('click', 'td', (event) => selectItems(event, praTable))	
	$('#praTable tbody').on('click', 'td.dt-control', (event) => expandTags(event, praTable))

	$('tbody').on('click', "tr.selectable", function () {
        $(this).closest('tr').toggleClass('selected');
    });
	$(".dataTables_wrapper").css("paddingLeft", "20px")
	$(".dataTables_wrapper").css("paddingRight", "20px")
	$("#blackLinesModal").modal("show");

	formHeader.populateSeveritySelect()
	formHeader.populateLikelihoodSelect()
	initializePickadate()
	initializeSelect2Jra()
	id=ele.previousSibling.previousSibling.id.split('-')
}

// Function to Evaluate Preliminary Risk
evalPreliminaryRisk = (threatObject) =>{
	indexInfo = threatObject.name.split("-")
	stepIndex = indexInfo[2]
	stepIndexObject = indexInfo[2] -1
	threatIndex = indexInfo[1]
	risk_element_id = `rmm_jth_preliminary_risk-${threatIndex}-${stepIndex}`
	likelihood_element_id = `rmm_jth_likelyhood_preliminary-${threatIndex}-${stepIndex}`
	severity_element_id = `rmm_jth_severity_preliminary-${threatIndex}-${stepIndex}`
	severity_path = jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].rmm_jth_severity_preliminary_id
	likelihood_path = jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].rmm_jth_likelihood_preliminary
	jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].rmm_jth_severity_preliminary_id = parseInt($('#'+severity_element_id).val())
	jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].rmm_jth_likelyhood_preliminary_id = parseInt($('#'+likelihood_element_id).val())
	severity_value = $('#'+ severity_element_id).val()
	likelihood_value = $('#'+ likelihood_element_id).val()
	if(severity_value >= 0 && likelihood_value >= 0) {
		likelyhoodScore = $('option:selected', '#'+likelihood_element_id).attr('score')
		severityScore = $('option:selected', '#'+severity_element_id).attr('score')
		jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].preliminary_likelyhood_score = likelyhoodScore
		jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].preliminary_severity_score = severityScore
		let preliminary_risk = evalRisk(severityScore, likelyhoodScore)
		risk = i18next.t(preliminary_risk)
		$('#'+risk_element_id).val(risk).parent().find('label').addClass(['filled',"active"])
		jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].rmm_jth_preliminary_risk = parseInt(preliminary_risk)
		jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].rmm_jth_preliminary_risk_text = i18next.t(preliminary_risk)
		jraThreatDots(stepIndexObject)
	}
}

// Function to Evaluate Preliminary Risk
evalResidualRisk = (threatObject) =>{
	indexInfo = threatObject.name.split("-")
	stepIndex = indexInfo[2]
	stepIndexObject = indexInfo[2] -1
	threatIndex = indexInfo[1]
	risk_element_id = `rmm_jth_residual_risk-${threatIndex}-${stepIndex}`
	likelihood_element_id = `rmm_jth_likelyhood_residual-${threatIndex}-${stepIndex}`
	severity_element_id = `rmm_jth_severity_residual-${threatIndex}-${stepIndex}`
	severity_path = jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].rmm_jth_severity_residual
	likelihood_path = jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].rmm_jth_likelihood_residual
	jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].rmm_jth_likelyhood_residual = parseInt($('#'+likelihood_element_id).val())
	jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].rmm_jth_severity_residual = parseInt($('#'+severity_element_id).val())
	severity_value = $('#'+severity_element_id).val()
	likelihood_value = $('#'+likelihood_element_id).val()
	if(severity_value >= 0 && likelihood_value >= 0) {
		likelyhoodScore = $('option:selected', '#'+likelihood_element_id).attr('score')
		severityScore = $('option:selected', '#'+severity_element_id).attr('score')
		jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].residual_likelyhood_score = likelyhoodScore
		jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].residual_severity_score = severityScore
		let residual_risk = evalRisk(severityScore, likelyhoodScore)
		risk = i18next.t(residual_risk)
		$('#'+risk_element_id).val(risk).parent().find('label').addClass(['filled',"active"])
		jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].rmm_jth_residual_risk = parseInt(residual_risk)
		jraObject.jra_data.step_categories[stepIndexObject].threats[threatIndex].rmm_jth_residual_risk_text = i18next.t(residual_risk)
		jraThreatDots(stepIndexObject)
	}
}

evalRisk = (severity,likelyhood) => {

	let Extreme = ['31','41','51','42','52','53']
	let High = ['21','22','32','33','43','44','54','55']
	let Medium = ['11','12','23','34','45']
	let Low = ['13','14','15','24','25','35']
	let code = `${severity}${likelyhood}`
	let risk = null
	if (Extreme.find(o => o === code)){
		risk = "3626"
	}
	if (High.find(o => o === code)){
		risk = "3622"
	}
	if (Medium.find(o => o === code)){
		risk = "3627"
	}
	if (Low.find(o => o === code)){
		risk = "3628"
	}
	return risk
}


// Function to change ALARA
function changeALARA(threatIndex, stepIndex){
	index = threatIndex.name.split("-")
	risk_alara_element = `rmm_jth_risk_alara_preliminary-${index[1]}-${index[2]}`
	$(`#${risk_alara_element}`)[0].parentNode.querySelector('label').classList.add(['filled',"active"])
	let risk_alara_value = $('#'+risk_alara_element).val()

	if(risk_alara_value === "0"){
		addAdditionalControls(threatIndex, stepLabel)
	}

	if(risk_alara_value === "1"){
		$(`#rmm_jth_severity_residual-${index[1]}-${index[2]}`).val('').trigger('change').parent().find('label').removeClass(["filled","active"])
		$(`#rmm_jth_likelyhood_residual-${index[1]}-${index[2]}`).val('').trigger('change').parent().find('label').removeClass(["filled","active"])
		$(`#rmm_jth_risk_alara_residual-${index[1]}-${index[2]}`).val('').trigger('change').parent().find('label').removeClass(["filled","active"])
		document.getElementById(`rmm_additional_controls-${index[1]}-${index[2]}`).classList.add("d-none")
		$(`#additional_measure-${index[1]}-${index[2]}`).find('.chip').remove()
	}
	else {
		$(`#rmm_jth_severity_residual-${index[1]}-${index[2]}`).val('').trigger('change').parent().find('label').removeClass(["filled","active"])
		$(`#rmm_jth_likelyhood_residual-${index[1]}-${index[2]}`).val('').trigger('change').parent().find('label').removeClass(["filled","active"])
		$(`#rmm_jth_risk_alara_residual-${index[1]}-${index[2]}`).val('').trigger('change').parent().find('label').removeClass(["filled","active"])
		$(`#rmm_jth_risk_alara_residual-${index[1]}-${index[2]}`).val('').trigger('change').parent().find('label').removeClass(["filled","active"])
	}
}


//Function to get Score for a given Ref ID
function getScoreForRisk (ref_id,type) {
	let score = null
	switch(type){
		case "likelyHood":
			likelyHoodList.forEach((val, index) => {
				if (val.rld_id === ref_id){
					score = val.rld_score
				}
			})
			break;
		case "severity":
			severityList.forEach((val, index) => {
				if (val.rld_id === ref_id){
					score = val.rld_score
				}
			})
			break; 
	}
	return score
}

// Function to initialize tags
function initializeTags(){
	setTimeout(()=>{
		jraObject.jra_data.step_categories.forEach((ec_val, i) => {
			ec_index = ec_val.rmm_jsc_sort
			ec_val.threats.forEach((ev_val, j) =>{
				id = "#control_measure-"+j+"-"+ec_index
				$(id).materialChip({
					placeholder: '+ ' + i18next.t(2478),
					secondaryPlaceholder: i18next.t(2109),
					data: ev_val.control_measures
				}).on('chip.add',(e, chip)=>{
					params = e.currentTarget.id.split("-")
				document.getElementById(`control_measure-${params[1]}-${params[2]}`).style.borderBottomColor = '#ced4da'
				for (let index = 0; index < ev_val.control_measures.length-1; index++) {
						if (ev_val.control_measures[index].tag.trim().toLowerCase() === chip.tag.trim().toLowerCase()){
							ev_val.control_measures.pop()
							break
						}
					}
					changesInForm = true
				}).on('chip.delete',()=>{
					changesInForm = true
				}).on('chip.select',(e)=>{
					params = e.currentTarget.id.split("-")
					document.getElementById(`additional_measure-${params[1]}-${params[2]}`).style.borderBottom = ''
				});
			})
		})
		jraObject.jra_data.step_categories.forEach((ec_val, i) => {
			ec_index = ec_val.rmm_jsc_sort                          
			ec_val.threats.forEach((ev_val, j) =>{
				id = "#additional_measure-"+j+"-"+ec_index
				$(id).materialChip({
					placeholder: '+ ' + i18next.t(3952), //Additional Control
					secondaryPlaceholder: i18next.t(2116),
					data: ev_val.additional_control_measures
				}).on('chip.add',(e, chip)=>{
					params = e.currentTarget.id.split("-")
					document.getElementById(`additional_measure-${params[1]}-${params[2]}`).style.borderBottomColor = '#ced4da'
					for (let index = 0; index < ev_val.additional_control_measures.length-1; index++) {
						if (ev_val.additional_control_measures[index].tag.trim().toLowerCase() === chip.tag.trim().toLowerCase()){
							throwToastr('error',i18next.t(3860),2000)
							ev_val.additional_control_measures.pop()
							break;
						}
					}
					changesInForm = true
				}).on('chip.delete',()=>{
					changesInForm = true
				}).on('chip.select',(e)=>{
					params = e.currentTarget.id.split("-")
					document.getElementById(`additional_measure-${params[1]}-${params[2]}`).style.borderBottom = ''
				})
			})
		})
	},1000)
}

function initializeBlueline(ec_val,th_val){
	if(typeof ec_val === 'number' && typeof th_val === 'number'){
		ec_index = ec_val+1
		jraObject.jra_data.step_categories[ec_val].threats[th_val].control_measures.forEach((cm)=>{
			id = "control_measure-"+th_val+"-"+ec_index
			let cmObjsWebElements = document.getElementById(id).getElementsByClassName('chip')
			if (cmObjsWebElements.length > 0){
				for (let index = 0; index < cmObjsWebElements.length; index++) {
					let chipText = cmObjsWebElements[index].innerText
					if (chipText===cm.tag){
						if (cm.rmm_jta_blueline){
							cmObjsWebElements[index].classList.add("chip-blueline")
						}
					}
				}
			}
		})
	}
	else{
		jraObject.jra_data.step_categories.forEach((ec_val, i) => {
			ec_index = ec_val.rmm_jsc_sort
			ec_val.threats.forEach((th_val, j) =>{
				th_val.control_measures.forEach((cm)=>{
					id = "control_measure-"+j+"-"+ec_index
					let cmObjsWebElements = document.getElementById(id).getElementsByClassName('chip')
					if (cmObjsWebElements.length > 0){
						for (let index = 0; index < cmObjsWebElements.length; index++) {
							let chipText = cmObjsWebElements[index].innerText
							if (chipText===cm.tag){
								if (cm.rmm_jta_blueline){
									cmObjsWebElements[index].classList.add("chip-blueline")
								}
							}
						}
					}
				})
			})
		})
	}
}

function jraThreatDots(stepIndex) {
	threatList = jraObject.jra_data.step_categories[stepIndex].threats
	$(`#threatDots_${stepIndex}`).html('')
	threatList.forEach((threat, threatIndex)=>{
		risk = threat.rmm_jth_residual_risk_text ? threat.rmm_jth_residual_risk_text : threat.rmm_jth_preliminary_risk_text
		switch(risk){
			case "Medium": $(`#threatDots_${stepIndex}`).append('<i class="fa fa-circle yellow-text pt-3 pr-2"></i>')
				break
			case "Extreme": $(`#threatDots_${stepIndex}`).append('<i class="fa fa-circle text-danger pt-3 pr-2"></i>')
				break
			case "High": $(`#threatDots_${stepIndex}`).append('<i class="fa fa-circle text-warning pt-3 pr-2"></i>')
				break
			case "Low": $(`#threatDots_${stepIndex}`).append('<i class="fa fa-circle text-success pt-3 pr-2"></i>')
				break
			default:  $(`#threatDots_${stepIndex}`).append('<i class="fa fa-circle text-muted pt-3 pr-2"></i>')
				break
		}
		jraThreatBars(risk, threatIndex, stepIndex)
	})
}

function jraThreatBars(risk, threatIndex, stepIndex) {
	$(`#rmmRiskBar-${threatIndex}-${stepIndex}`).removeClass(['barExtreme','barHigh','barLow','barMedium',])
	if(risk){
		$(`#rmmRiskBar-${threatIndex}-${stepIndex}`).removeClass('barMuted')
	}
	$(`#rmmRiskBar-${threatIndex}-${stepIndex}`).addClass(`bar${risk}`)
}

</script>
<script type="text/javascript" src="/js/RAformHandler.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footerRMM.php");?>
