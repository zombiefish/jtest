<?php	
  $strPageTitle = 'Employee Review 60 Day';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
					<h6 class="text-secondary"><span class='translate' data-i18n="1000" notes="Employee Review 60 Day"></span></h6>

					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
						</select>
						<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
					</div>

					<form name="employee60DayReview" id="employee60DayReview" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1490" notes="Legend"></span></h6>

						<div class="pt-1 position-relative my-4">
							<select name="employee_name" id="employee_name" class="select-single mobile-employee-select-id-single" required>
							</select>
							<label for="employee_name"><span class='translate' data-i18n="190" notes="Employee"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="pay_class" id="pay_class" class="form-control" length="200" maxlength="200">
							<label for="pay_class"><span class='translate' data-i18n="122" notes="Current Pay Class"></span></label>
						</div>

						<div>
							<label><span class='translate' data-i18n="798" notes="Review Scoring Legend"></span></label>
							<p><span class='translate' data-i18n="1491" notes="Each new Employee will have a review completed by their Supervisor. This review is to take place prior to the completion of 60-days of employment. There are three rankings to each section summarized below:"></span></p>
							<ol>
								<li><span class='translate' data-i18n="1492" notes="Employee meets requirements, only a quick review with the employee required."></span></li>
								<li><span class='translate' data-i18n="1493" notes="Employee requires improvement. Results to be reviewed with employee and an improvement plan needs to be discussed. Form will be forwarded to Superintendent and Project Manager for review. Probation will need to be extended in this case."></span></li>
								<li><span class='translate' data-i18n="1494" notes="Employee does not meet expectation. Form will be forwarded to Superintendent and Project Manager for further action."></span></li>
							</ol>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1495" notes="Evaluation"></span></h6>

						<div class="form-group mb-5">
							<label class="d-block"><span class='translate' data-i18n="59" notes="Attitude"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons">
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="attitude_score" id="attitude_score_1" value="1" notes="1"required> 1
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="attitude_score" id="attitude_score_2" value="2" notes="2"> 2
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="attitude_score" id="attitude_score_3" value="3" notes="3"> 3
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
							<ol class="mt-2">
								<li><span class='translate' data-i18n="1496" notes="Always demonstrates Core Values: Respect, Integrity, Courage, Honesty, and Humility. Employee is a positive addition to the team."></span></li>
								<li><span class='translate' data-i18n="1497" notes="Usually demonstrates most of the core values and presents as a positive addition to the team."></span></li>
								<li><span class='translate' data-i18n="1498" notes="Does not display Technica Core Values, is not a positive addition to the team."></span></li>
							</ol>
						</div>

						<div class="form-group my-5">
							<label class="d-block"><span class='translate' data-i18n="804" notes="Safety"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons">
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="safety_score" id="safety_score_1" value="1" required> 1
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="safety_score" id="safety_score_2" value="2"> 2
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="safety_score" id="safety_score_3" value="3"> 3
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
							<ol class="mt-2">
								<li><span class='translate' data-i18n="1499" notes="Active participant in safety program. Completes pre-op slips and five point cards to a high standard. Identifies and corrects hazards in the workplace."></span></li>
								<li><span class='translate' data-i18n="1500" notes="Participates in safety program but is not familiar with all jobsite procedures and policies."></span></li>
								<li><span class='translate' data-i18n="1501" notes="Does not follow safe work practices even when the employee has been made aware of the procedures and policies."></span></li>
							</ol>
						</div>

						<div class="form-group my-5">
							<label class="d-block"><span class='translate' data-i18n="944" notes="Work Performance"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons">
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="performance_score" id="performance_score_1" value="1" required > 1
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="performance_score" id="performance_score_2" value="2"> 2
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="performance_score" id="performance_score_3" value="3"> 3
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
							<ol class="mt-2">
								<li><span class='translate' data-i18n="1502" notes="Actively engaged in planning and execution of work assigned and meets or exceeds standards, performance, and quality."></span></li>
								<li><span class='translate' data-i18n="1503" notes="Completes work tasks to a high quality but struggles with quantity of work completed."></span></li>
								<li><span class='translate' data-i18n="1504" notes="Inconsistently demonstrates ability to work to standards and execute tasks as assigned."></span></li>
							</ol>
						</div>

            			<div class="form-group my-5">
							<label class="d-block"><span class='translate' data-i18n="201" notes="Employee Class Verification"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons">
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="class_score" id="class_score_1" value="1" required > 1
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="class_score" id="class_score_2" value="2"> 2
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="class_score" id="class_score_3" value="3"> 3
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>

							<ol class="mt-2">
								<li><span class='translate' data-i18n="1505" notes="Employee is in the correct class."></span></li>
								<li><span class='translate' data-i18n="1506" notes="It is recommended that employee should be assigned a higher class."></span></li>
								<li><span class='translate' data-i18n="1507" notes="It is recommended that employee should be assigned a lower class."></span></li>
							</ol>
						</div>

            			<div class="form-group my-5">
							<label class="d-block"><span class='translate' data-i18n="201" notes="Attendance"></span></label>
							<div class="btn-group btn-group-sm d-flex" data-toggle="buttons">
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="attendance_score" id="attendance_score_1" value="1" required> 1
								</label>
								<label class="btn btn-outline-primary form-check-label">
									<input class="form-check-input" type="radio" name="attendance_score" id="attendance_score_2" value="2"> 2
								</label>
							</div>
							<div class="invalid-feedback"><span class='translate' data-i18n="1694" notes="Please select a value"></span></div>
							<ol class="mt-2">
								<li><span class='translate' data-i18n="1508" notes="Meets expectations: employee consistently reports to work as scheduled. If applicable, absences have been accounted for with proper leave approval."></span></li>
								<li><span class='translate' data-i18n="1509" notes="Does not meet expectations: employee has failed to report to work as scheduled on one or more occasion without leave approval. If employee does not meet expectations, the reviewer will be asked to confirm that he/she has received a communication from their superior in relation to this expectation (this could be in the form of a personal contact or a written warning)."></span></li>
							</ol>
						</div>

						<div class="md-form">
							<textarea name="results" id="results" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="results"><span class='translate' data-i18n="795" notes="Results"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1510" notes="Goal and Development Summary"></span></h6>

						<div class="md-form">
							<textarea name="goals_1" id="goals_1" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="goals_1"><span class='translate' data-i18n="1511" notes="Performance Goals"></span></label>
							<small class="form-text text-muted"><span class='translate' data-i18n="1512" notes="List the employee's performance goals for the coming year."></span></small>
						</div>

						<div class="md-form">
							<textarea name="goals_2" id="goals_2" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="goals_2"><span class='translate' data-i18n="1513" notes="Development Goals"></span></label>
							<small class="form-text text-muted"><span class='translate' data-i18n="625" notes="List the employee's development goals for the coming year."></span></small>
						</div>

						<div class="md-form">
							<textarea name="goals_3" id="goals_3" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="goals_3"><span class='translate' data-i18n="1514" notes="Other work"></span></label>
							<small class="form-text text-muted"><span class='translate' data-i18n="180" notes="Does the employee have a desire and ability to progress to another type of work?"></span></small>
						</div>

						<canvas id="canvas" style='display:none;'></canvas>
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1395" notes="Signatures"></span></h6>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="217" notes="Employee Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='employee_signature'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='employee_signature_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="employee_signature" id="employee_signature" class='modalSignature' value='' required>
							<input type="hidden" name="vector_employee" id='vector_employee' value=''>
							<input type="hidden" name="employee_signature_comments" id='employee_signature_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="employee_signature_img_time" id="employee_signature_img_time" notes='employee_signature_img_time' readonly/></small>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="465" notes="Evaluator Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='evaluator_signature'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='evaluator_signature_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="evaluator_signature" id="evaluator_signature" class='modalSignature' value=''>
							<input type="hidden" name="vector_evaluator" id='vector_evaluator' value=''>
							<input type="hidden" name="evaluator_signature_comments" id='evaluator_signature_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="evaluator_signature_img_time" id="evaluator_signature_img_time" notes='evaluator_signature_img_time' readonly/></small>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="640" notes="Manager Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='manager_signature'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='manager_signature_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="manager_signature" id="manager_signature" class='modalSignature' value='' >
							<input type="hidden" name="vector_manager" id='vector_manager' value=''>
							<input type="hidden" name="manager_signature_comments" id='manager_signature_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="manager_signature_img_time" id="manager_signature_img_time" notes='manager_signature_img_time' readonly/></small>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag="1000" class = "trans_input" value="1000" />
						<input type="hidden" name="formtype" id="formtype" value="HR" />
						<input type="hidden" name="formid" id="formid" value="339913" />
						<input type="hidden" name="version" id="version" value="6" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="employee_name" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					
					</form>
				</div>
			</div>
		</div>
	</div>

</main>
<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
			
			return true;
		}	
	}
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>