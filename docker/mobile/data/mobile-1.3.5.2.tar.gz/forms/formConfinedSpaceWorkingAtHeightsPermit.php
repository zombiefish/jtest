<?php	
  $strPageTitle = 'Confined Space / Working at Heights Permit';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
	
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
        
						<h6 class="text-secondary"><span class='translate' data-i18n="2245" notes="Confined Space / Working at Heights Permit"></span></h6>
						<div class="pt-1 position-relative my-4">
							<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
							</select>
							<label for="draft"><span class='translate' data-i18n="1474" notes="Form Drafts"></span></label>
						</div>

						<form name="working_at_heights" id="TemplateForm" class="needs-validation" method="POST" action="#" novalidate>

							<?php include 'includes/CommonFormHeader.php' ?>

							<div class="md-form">
								<input type="text" class="form-control timepicker" name="time_of_initial_entry" id="time_of_initial_entry" required>
								<label for="time_of_initial_entry"><span class='translate' data-i18n="863" notes="Time Of Initial Entry"></span></label>
							</div>

							<h6 class="text-secondary"><span class='translate' data-i18n="820" notes="Shift"></span></h6>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="shift_day" name="shift" value="3287" notes="Day" required>
								<label class="form-check-label mr-2" for="shift_day"><span class='translate' data-i18n="3287" notes="Day"></span></label>

								<input type="radio" class="form-check-input trans_input" id="shift_night" name="shift" value="3288" notes="Night" required>
								<label class="form-check-label mr-2" for="shift_night"><span class='translate' data-i18n="3288" notes="Night"></span></label> 
							</div>
							<div class="md-form pt-1 position-relative my-4">
								<input type="text" name="confined_space" id="confined_space" class="form-control" length="200" maxlength="200" required>
								<label for="confined_space"><span class='translate' data-i18n="94" notes="Confined Space"></span></label>
							</div>
							<label><span class='translate' data-i18n="884" notes="Type of Space"></span></label>
							<div id="type_of_space_div" class="form-check pl-0">
								<input type="checkbox" class="form-check-input ml-0" name="restricted" id="restricted"  value = '0' onchange="getSafetyCheckboxStatus()" >
								<label class="form-check-label" for="restricted"><span class='translate' data-i18n="794" notes="Restricted"></span></label>

								<input type="checkbox" class="form-check-input ml-0" name="confined" id="confined" value = '0' onchange="getSafetyCheckboxStatus()" >
								<label class="form-check-label" style="margin-left: 20px;" for="confined"><span class='translate' data-i18n="93" notes="Confined"></span></label>
							</div>
							<div class="md-form">
								<textarea name="work_being_performed" id="work_being_performed" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="work_being_performed"><span class='translate' data-i18n="939" notes="Work being performed"></span></label>
							</div>
							<div class="pt-1 position-relative my-4">
								<select name="potential_hazards" id="potential_hazards"  class="select-multiple mobile-potentialhazards-select" multiple required>
								</select>
								<label for="potential_hazards"><span class='translate' data-i18n="752" notes="Potential Hazards"></label>
									
								<div id="other_potential_hazards_div" class="md-form" style="display:none">
									<input type="text" name="other_potential_hazards" id="other_potential_hazards" class="form-control" length="200" maxlength="200">
									<label for="other_potential_hazards"><span class='translate' data-i18n='704' notes='Other Potential Hazards'></span></label>
								</div>
																				
							</div>
							<h6 class="text-secondary"><span class='translate' data-i18n="2342" notes="Initial Air Quality Test"></span></h6>
							<div id="air_quality">
								<div class="md-form pt-1 position-relative my-4">
									<input type="number" name="oxygen" id="oxygen" class="form-control" min="0.00" step="0.01" max="100.00" required>
									<label for="oxygen" style="width:100%"><span class='translate' data-i18n="2343" notes="Oxygen (19.5% - 23.0%)"></span></label>
								</div>
								<div class="md-form pt-1 position-relative my-4">
									<input type="number" name="lel" id="lel" class="form-control" min="0.00" step="0.01" max="100.00" required>
									<label for="lel" style="width:100%"><span class='translate' data-i18n="2344" notes="LEL (<10%)"></span></label>
								</div>
								<div class="md-form pt-1 position-relative my-4">
									<input type="text" name="toxic_gas" id="toxic_gas" class="form-control" length="200" maxlength="200" required>
									<label for="toxic_gas"><span class='translate' data-i18n="875" notes="Toxic Gas"></span></label>
								</div>
								<div class="md-form">
									<input type="text" class="form-control timepicker" name="time_of_test" id="time_of_test" required>
									<label for="time_of_test"><span class='translate' data-i18n="864" notes="Time of Test"></span></label>
								</div>
							<div class="pt-1 position-relative my-4">
								<select name="name_of_tester" id="name_of_tester" class="select-single mobile-employee-select-single" required></select>
								<label for="name_of_tester"><span class='translate' data-i18n="653" notes="Name of Tester"></span></label>
							</div>
							<div class="pt-1 position-relative my-4">
								<select name="determine_controls" id="determine_controls" class="select-multiple mobile-determinecontrolsequipment-select" multiple required>
								</select>
								<label for="determine_controls"><span class='translate' data-i18n="156" notes="Determine Controls / Equipment"></span></label>
							
								<div id="other_controls_div" class="md-form" style="display:none">
									<input type="text" name="other_controls" id="other_controls" class="form-control" length="200" maxlength="200">
									<label for="other_controls"><span class='translate' data-i18n='700' notes='Other Controls / Equipment'></span></label>
								</div>
						
								<small class="form-text text-muted"><span class='translate' data-i18n="2345" notes="Equipment checked must be available and in good working condition"></span></small>
							</div>
							<div class="pt-1 position-relative my-4">
								<select name="personal_protective_equipment" id="personal_protective_equipment" class="select-multiple mobile-workingatheightsspecialppe-select" multiple required>
								</select>
								<label for="personal_protective_equipment"><span class='translate' data-i18n="834" notes="Special PPE"></span></label>
								
								<div id="other_special_ppe_div" class="md-form" style="display:none">
									<input type="text" name="other_personal_protective_equipment" id="other_personal_protective_equipment" class="form-control" length="200" maxlength="200">
									<label for="other_personal_protective_equipment"><span class='translate' data-i18n='709' notes='Other Special PPE'></span></label>
								</div>
									
								<small class="form-text text-muted"><span class='translate' data-i18n="2345" notes="Equipment checked must be available and in good working condition"></span></small>

							</div>	
							<label for="is_rescue_plan_available"><span class='translate' data-i18n="591" notes="Is Rescue Plan Available"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="available" name="is_rescue_plan_available" value="1379" notes="Yes" required>
								<label class="form-check-label mr-2" for="available"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input trans_input" id="not_available" name="is_rescue_plan_available" value="1380" notes="No">
								<label class="form-check-label mr-2" for="not_available"><span class='translate' data-i18n="1380" notes="No"></span></label> 
								
								<div id="rescue_plan_details_div" style="display:none" class="md-form">
									<textarea name="rescue_plan_details" id="rescue_plan_details" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
									<label for="rescue_plan_details"><span class='translate' data-i18n='788' notes='Rescue Plan Details'></span></label>
								</div>
										
							</div>

							<div class="md-form">
								<textarea name="rescue_team_details" id="rescue_team_details" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
								<label for="rescue_team_details"><span class='translate' data-i18n="792" notes="Rescue Team Details"></span></label>
							</div>
							<div class="pt-1 position-relative my-4">
								<select name="confined_space_supervisor_name" id="confined_space_supervisor_name" class="select-single mobile-employee-select-single" required>
								</select>
								<label for="confined_space_supervisor_name"><span class='translate' data-i18n="96" notes="Confined Space Supervisor Name"></span></label>
							</div>
							<div class="my-4">
								<label class="text-muted"><span class='translate' data-i18n="97" notes="Confined Space Supervisor Signature"></span></label>
								<div class="btn-group d-flex" role="group" aria-label="Action subforms">
									<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='confined_space_supervisor_signature'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
									<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
									<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
								</div>
								<img id='confined_space_supervisor_signature_img' src='' class='signatureImage d-block pt-2'/>
								<input type="hidden" name="confined_space_supervisor_signature" id="confined_space_supervisor_signature" class='modalSignature' value='' required>
								<input type="hidden" name="vector_manager" id='vector_manager' value=''>
								<input type="hidden" name="confined_space_supervisor_signature_comments" id='confined_space_supervisor_signature_comments' class="sig_comment" value=''>							
								<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="confined_space_supervisor_signature_img_time" id="confined_space_supervisor_signature_img_time" notes='confined_space_supervisor_signature_img_time' readonly/></small>
							</div>
							
							<div class="form-group photoImage" id="picture_of_confined_space"> 
								<label class="d-block"><span class='translate' data-i18n="2347" notes="Pictures of Confined Space"></span></label>
								<canvas id="canvas" style='display:none;'></canvas>
								<div class="btn-group d-flex" role="group">
									<div class="btn btn-block btn-outline-secondary file-field px-1">
										<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="Add Images"></span>
										<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
									</div>
								</div>
								<div id="siteHelp" class="form-text text-muted" ></div>
								<div class="row photoGallery" id="galleryid"></div>
							</div>

							<?php include 'includes/CommonFormFooter.php' ?>


							<input type="hidden" name="formname" id="formname" tag = "2245" class = "trans_input" value="2245" />
							<input type="hidden" name="formtype" id="formtype" value="WAH" />
							<input type="hidden" name="formid" id="formid" value="372358" />
							<input type="hidden" name="version" id="version" value="1" />
							<input type="hidden" name="_rev" id="_rev" value="" />
							<input type="hidden" name="_id" id="_id" value="" />
							<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
							<input type="hidden" name="draftField" id="draftField" value="draft" />
							<input type="hidden" name="type_of_space" id="type_of_space" value="" />
						</form>
				</div>
			</div>
		</div>
	</div>
</main>


<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}	
	};

	function getSafetyCheckboxStatus(){
		var the_inputs=document.getElementsByTagName("input");
		for(var n=0;n<the_inputs.length;n++){
			if(the_inputs[n].type=="checkbox"){
				var status = the_inputs[n].checked;
					if (status) {
						the_inputs[n].value='1'
					} else {
						the_inputs[n].value='0'
					}
			}
		}
		inputTypeofSpace()
	};

</script>
			
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>

<script>
	$('#potential_hazards').change(function(e){
		$("#other_potential_hazards").prop('required',false)
			if(checkOther('potential_hazards', $(this).val())){
				$("#other_potential_hazards_div").show()
				$("#other_potential_hazards").prop('required',true)
			}else{
				$("#other_potential_hazards_div").hide()
				$("#other_potential_hazards").prop('required',false)
				$("#other_potential_hazards").val('').parent().find('label').removeClass('active filled')
			}
	})

	$('#determine_controls').change(function(e){
			$("#other_controls").prop('required', false)
			if(checkOther('determine_controls', $(this).val())){
				$("#other_controls_div").show()
				$("#other_controls").prop('required',true)
			}
			else{
				$("#other_controls").val('').parent().find('label').removeClass('active filled')
				$("#other_controls").prop('required', false)
				$("#other_controls_div").hide()
			}
	});

	$('#personal_protective_equipment').change(function(e){
		$("#other_personal_protective_equipment").prop('required',false)
			if(checkOther('personal_protective_equipment', $(this).val())){
				$("#other_special_ppe_div").show()
				$("#other_personal_protective_equipment").prop('required',true)
			}
			else{
				$("#other_personal_protective_equipment").val('').parent().find('label').removeClass('active filled')
				$("#other_personal_protective_equipment").prop('required',false)
				$("#other_special_ppe_div").hide()
			}
	});

	$('input[type="radio"][name="is_rescue_plan_available"]').change((data)=>{
		$("#rescue_plan_details").prop('required',false);
	    if(data.target.value === 'No') {
	        $("#rescue_plan_details_div").show();
			$("#rescue_plan_details").prop('required',true);
		} else {
			$("#rescue_plan_details").val('').parent().find('label').removeClass('active filled')
			$("#rescue_plan_details").prop('required',false);
			$("#rescue_plan_details_div").hide();
		}
	});


	function draftPostProcess(){
		var is_resue_plan=document.getElementById("not_available");
		if(is_resue_plan.value == 'No') {
	        $("#rescue_plan_details_div").show();
			$("#rescue_plan_details").prop('required',true);
			document.getElementById("not_available").checked
		}
	};	

	function inputTypeofSpace(){
		var typeofSpace=[]	
		if(document.getElementById('restricted').value==1){
			typeofSpace.push(i18next.t("794"))
		} 
		if(document.getElementById('confined').value==1){
			//give a space between 2 words
			if(document.getElementById('restricted').value==1){
				typeofSpace.push(" " + i18next.t("93"))
			}
			else {typeofSpace.push(i18next.t("93"))}
		} 
	document.getElementById('type_of_space').value=typeofSpace
	}

</script>