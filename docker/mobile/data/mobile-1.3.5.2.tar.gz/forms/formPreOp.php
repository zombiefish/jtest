<?php	
  $strPageTitle = 'Equipment Pre-Op';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>
<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
					<h6 class="text-secondary"><span class='translate' data-i18n="1427" notes="Equipment Pre-Op"></span></h6>
					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
						</select>
						<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
					</div>

					<form name="preop" id="preop" class="needs-validation" method="POST" action="#" novalidate>

					<?php include 'includes/CommonFormHeader.php' ?>
					
					<h6 class="text-secondary pt-4"><span class='translate' data-i18n="820" notes="Shift"></span></h6>
					<div class="form-check custom-radio pl-0">
						<input type="radio" class="form-check-input trans_input" id="shift_days" name="shift" value="1095" notes="Days" required>
						<label class="form-check-label mr-2" for="shift_days"><span class='translate' data-i18n="1095" notes="Days"></span></label>

						<input type="radio" class="form-check-input trans_input" id="shift_nights" name="shift" value="1375" notes="Nights">
						<label class="form-check-label mr-2" for="shift_nights"><span class='translate' data-i18n="1375" notes="Nights"></span></label> 
					</div>

					<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1235" notes="Equipment Number"></span></h6>
					<div class="md-form">
					<input type="text" name="machine_number" id="machine_number" tag="1235" class="form-control" length="200" maxlength="200" required>
						<label for="machine_number"><span class='translate' data-i18n="1235" notes="Equipment Number"></span></label>
					</div>	

					<input type="hidden" name="pet_id" id="pet_id" value="" />


						<div class="pt-1 position-relative my-4" style="display:none;">
							<select name="machineType" id="machineType" tag="1239" class="select-single" required></select>
							<label for="machineType"><span class='translate' data-i18n="1239" notes="Equipment Type"></span></label>
						</div>

						<div class='btn btn-primary btn-lg' id='selectMachine' style='display:none;'><span class='translate' data-i18n="9437" notes="Select Equipment"></span></div>

						<div id='preopCheck' style='display:none;'>
							<div class="md-form" id='start-measure-readings'></div>
							<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1432" notes="Start of Shift Equipment Photos"></span></h6>
							<div class="form-group photoImage preOP" id="photo-front-start" required > 
								<label class="d-block"><span class='translate' data-i18n="1433" notes="Front of equipment photo"></span></label>
								<canvas id="canvas-front-start" style='display:none;'></canvas>
								<div class="btn-group d-flex" role="group">
									<div class="btn btn-block btn-outline-secondary file-field px-1">
										<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
										<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
									</div>
								</div>
								<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1434" notes="Please take multiple pictures."></span></small>
								<div class="row photoGallery" id="galleryid-front-start"></div>
							</div>	

							<div class="form-group photoImage preOP" id="photo-left-start" required> 
								<label class="d-block"><span class='translate' data-i18n="1435" notes="Left side of equipment photo"></span></label>
								<canvas id="canvas-left-start" style='display:none;'></canvas>
								<div class="btn-group d-flex" role="group">
									<div class="btn btn-block btn-outline-secondary file-field px-1">
										<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
										<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
									</div>
								</div>
								<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1434" notes="Please take multiple pictures."></span></small>
								<div class="row photoGallery" id="galleryid-left-start"></div>
							</div>

							<div class="form-group photoImage preOP" id="photo-back-start" required> 
								<label class="d-block"><span class='translate' data-i18n="1436" notes="Back of equipment photo"></span></label>
								<canvas id="canvas-back-start" style='display:none;'></canvas>
								<div class="btn-group d-flex" role="group">
									<div class="btn btn-block btn-outline-secondary file-field px-1">
										<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
										<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
									</div>
								</div>
								<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1434" notes="Please take multiple pictures."></span></small>
								<div class="row photoGallery" id="galleryid-back-start"></div>
							</div>

							<div class="form-group photoImage preOP" id="photo-right-start" required> 
								<label class="d-block"><span class='translate' data-i18n="1437" notes="Right side of equipment photo"></span></label>
								<canvas id="canvas-right-start" style='display:none;'></canvas>
								<div class="btn-group d-flex" role="group">
									<div class="btn btn-block btn-outline-secondary file-field px-1">
										<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
										<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
									</div>
								</div>
								<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1434" notes="Please take multiple pictures."></span></small>
								<div class="row photoGallery" id="galleryid-right-start"></div>
							</div>

<!-- insert the preop questions here -->
            				<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1438" notes="Pre-Op Questions"></span></h6>
							<div id='preopQuestions'></div>

<!-- End of Pre Op Questions -->

							<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1465" notes="Comments or Defects"></span></h6>
							<div class="md-form">
								<textarea name="comments" id="comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments"><span class='translate' data-i18n="1465" notes="Comments or Defects"></span></label>
							</div>
<!-- end of PREOP -->
            				<div id='end-pre-op-button' class='btn btn-primary btm-sm'><span class='translate' data-i18n="1466" notes="Finish Pre-Op"></span></div>			
						</div> <!-- Close preop check -->


<!-- these filled out at the end of the shift -->

           				<div id='postOpCheck' style='display:none;'>
					  	<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1467" notes="Equipment Post-Op"></span></h6>
            			<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1468" notes="Location of Machine at end of shift"></span></h6>
						<div class="pt-1 position-relative my-4">
							<select name="levelendshift" id="levelendshift" class="select-single postOP" required></select>
							<label for="levelendshift"><span class='translate' data-i18n="621" notes="Level"></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="workplaceendshift" id="workplaceendshift" class="form-control postOP" value="" length="200" maxlength="200" required>
							<label for="workplaceendshift"><span class='translate' data-i18n="959" notes="Workplace"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1469" notes="End of Shift Equipment Photos"></span></h6>

						<canvas id="canvas" style='display:none;'></canvas>

						<div class="form-group photoImage postOP" id="photo-front-end"> 
							<label class="d-block"><span class='translate' data-i18n="1433" notes="Front of equipment photo"></span></label>
							<canvas id="canvas-front-end" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
									<input type="file" class="pics postop_pics postOP" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1434" notes="Please take multiple pictures."></span></small>
							<div class="row photoGallery" id="galleryid-front-end"></div>
						</div>

						<div class="form-group photoImage postOP" id="photo-left-end"> 
							<label class="d-block"><span class='translate' data-i18n="1435" notes="Left side of equipment photo"></span></label>
							<canvas id="canvas-left-end" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
									<input type="file" class="pics postop_pics postOP" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1434" notes="Please take multiple pictures."></span></small>
							<div class="row photoGallery" id="galleryid-left-end"></div>
						</div>

						<div class="form-group photoImage postOP" id="photo-back-end"> 
							<label class="d-block"><span class='translate' data-i18n="1436" notes="Back of equipment photo"></span></label>
							<canvas id="canvas-back-end" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
									<input type="file" class="pics postop_pics postOP" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1434" notes="Please take multiple pictures."></span></small>
							<div class="row photoGallery" id="galleryid-back-end"></div>
						</div>

						<div class="form-group photoImage postOP" id="photo-right-end"> 
							<label class="d-block"><span class='translate' data-i18n="1437" notes="Right side of equipment photo"></span></label>
							<canvas id="canvas-right-end" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
									<input type="file" class="pics postop_pics postOP" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1434" notes="Please take multiple pictures."></span></small>
							<div class="row photoGallery" id="galleryid-right-end"></div>
						</div>
						<div  id='end-measure-readings'></div>
						<div id='emr'></div>
						<!-- <div class="md-form">
							<input type="number" step='0.1' name="engineend" id="engineend" class="form-control postOP">
							<label for="engineend"><strong><span class='translate' data-i18n="1994" notes="Engine"></span> <span class='engine_unit'></span>: </strong><span class='translate' data-i18n="8725" notes="End of shift"></span></label>
						</div> -->

						<div class="md-form">
							<textarea name="othercomments" id="othercomments" class="form-control md-textarea postOP" wrap="VIRTUAL"></textarea>
							<label for="othercomments"><span class='translate' data-i18n="1471" notes="Other meter readings or comments"></span></label>
						</div>

		    			<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1395" notes="Signatures"></span></h6>
			    		<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="850" notes="Supervisor Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign postOP' signaturename='signature_supervisor_photo'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none' id="clearSignButton"><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_supervisor_photo_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_supervisor_photo" id="signature_supervisor_photo" class='modalSignature postOP' value=''>
							<input type="hidden" name="vector_supervisor" id='vector_supervisor' value=''>
							<input type="hidden" name="signature_supervisor_photo_comments" id='signature_supervisor_photo_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_supervisor_photo_img_time" id="signature_supervisor_photo_img_time" notes='signature_supervisor_photo_img_time' readonly/></small>
						</div>

						<div id="engineUnitModalPH"></div>
					<!-- </div>	 -->

						<h6 class="text-secondary pt-4 "><span class='translate' data-i18n="1188" notes="Review"></span></h6>
						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="9409" notes="End of Shift Review"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign lock' signaturename='signature_end_of_shift_review'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1188" notes="Review"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<!-- <div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div> -->
							</div>
							<img id='signature_end_of_shift_review_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_end_of_shift_review" id="signature_end_of_shift_review" class='modalSignature lock' value=''>
							<input type="hidden" name="vector_review" id='vector_review' value=''>
							<input type="hidden" name="signature_end_of_shift_review_comments" id='signature_end_of_shift_review_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_end_of_shift_review_img_time" id="signature_end_of_shift_review_img_time" notes='signature_end_of_shift_review_img_time' readonly/></small>
						</div>

			            <input type="hidden" name = 'preopStatus' id = 'preopStatus' value = 'PREOP'/>
						<input type="hidden" name="formname" id="formname" tag="1427" class = "trans_input" value="1427" note="PRE-OP" />
						<input type="hidden" name="formtype" id="formtype" value="SUP" />
						<input type="hidden" name="formid" id="formid" value="372278" />
						<input type="hidden" name="version" id="version" value="4" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace|machine_number|machineType" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />

					</div>
					<?php include 'includes/CommonFormFooter.php' ?>
				</form>
			</div>
		</div>
	</div>
</main>



<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
			return true;
		}	
	}


let lists = []
let questions = []

openCacheData().then((rdata)=>{
	lists = remoteData
	// Trigger form handling for Header
	try	{
		lists[24]['PreOpQuestions'].forEach((data)=>{
			questions[data.poq_id] = {
				fieldName: data.poq_preop_identifier,
				fieldType: data.poq_preop_questionmode_id,
				question: data.poq_preop_question,
				sort: data.poq_sort_order,
				poq_pct_id : data.poq_pct_id
				}                
		})
	} 
	catch(err)	{
	}
})




 function insertQuestion(qlist){
	const q = questions[qlist.questionNumber]
	let varExclamation = `<span><i class="fas fa-exclamation"></i></span>`
	let varSpecial = `special`
	/* as per the fieldtype(means 'must pass inspection') checking the condition and creating the html
	-- 1-  check the fieldtype and set the required or special validation
	-- 2-  check the poq_pct_id, if 1 then set radio button; else if 2 then set text box  */

	let htmlQuestion=`<div class="mb-4">
						<label class="d-block">${q.fieldType=='2'? varExclamation:''}  ${q.question}</label>
						${(q.fieldType=='1' || q.fieldType=='2')?( () => {
						   switch(q.poq_pct_id){
							case 1:   
								return `<div class="form-check custom-radio pl-0">						
									<input type="radio" class="form-check-input" id="${q.fieldName}_yes" name="${q.fieldName}" value="1" ${q.fieldType=='2'?varSpecial:''} required>
									<label class="form-check-label mr-2" for="${q.fieldName}_yes"><span class='translate' data-i18n="1405" notes="Ok"></span></label>

									<input type="radio" class="form-check-input" id="${q.fieldName}_no" name="${q.fieldName}" value="0" ${q.fieldType=='2'?varSpecial:''}>
									<label class="form-check-label mr-2" for="${q.fieldName}_no"><span class='translate' data-i18n="1440" notes="Defective"></span></label>

									<input type="radio" class="form-check-input" id="${q.fieldName}_na" name="${q.fieldName}" value="-1" ${q.fieldType=='2'?varSpecial:''}w>
									<label class="form-check-label mr-2" for="${q.fieldName}_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>					
								</div>`
								break
							default:
								return `<div class="md-form">
										<input type="text" name="${q.fieldName}" id="${q.fieldName}"  class="form-control" ${q.fieldType=='2'?varSpecial:''} length="200" maxlength="200" required>
											<label for="${q.fieldName}" class="active"><span class='translate' data-i18n="2339" notes="Text">Text</span></label>					
										</div>`
								break
						   } })()
						: `<div class="mb-4">
						<label class="d-block">${qlist.questionNumber}</label>
						</div>`}
					</div>`
	document.getElementById('preopQuestions').innerHTML += htmlQuestion

} 

 function findMachines(machNumber = document.getElementById('machine_number').value.toUpperCase(), site, job) {
		mach = []
		tfsr_site = document.getElementById('site').value ? document.getElementById('site').value : site
        tfsr_job = document.getElementById('job_number').value ? document.getElementById('job_number').value : job
		if(tfsr_site && tfsr_job) {
			lists[40]['preopEquipmentSiteJob'].forEach((data)=>{
				if(data.psj_rld_site_id == tfsr_site && !data.psj_rld_job_id ) {
					if(data.pet_equipment_identifier && machNumber === data.pet_equipment_identifier.toUpperCase()) {
						mach.push({
							machineNumber: data.pet_equipment_identifier,
							machineType: data.pet_poe_id
						})
					}
				}
				if(data.psj_rld_site_id == tfsr_site && data.psj_rld_job_id == tfsr_job) {
					if(data.pet_equipment_identifier && machNumber === data.pet_equipment_identifier.toUpperCase()) {
						mach.push({
							machineNumber: data.pet_equipment_identifier,
							machineType: data.pet_poe_id
						})
					}
				}
				if(!data.psj_rld_job_id && !data.psj_rld_site_id) {
					if(data.pet_equipment_identifier && machNumber === data.pet_equipment_identifier.toUpperCase()) {
						mach.push({
							machineNumber: data.pet_equipment_identifier,
							machineType: data.pet_poe_id
						})
					}
				}
			})
		}

		if(mach.length > 0){
			let opts = ''
			if(mach.length > 1){
			opts += '<option></option>'
			}
			mach.forEach((rec) =>{
			opts += `<option value='${rec.machineType}'>${getMachineName(rec.machineType)}</option>`	
			})
			document.getElementById('machineType').innerHTML = opts
			if(mach.length == 1){
				document.getElementById('machineType').nextSibling.nextSibling.nextSibling.classList.add('filled')
			}

			document.getElementById('machineType').parentNode.style.display = 'block'	
			document.getElementById('selectMachine').style.display = 'block'
			activateMachineTypeSelect()		
		}
		else {
			document.getElementById('machineType').innerHTML = ''
			document.getElementById('selectMachine').style.display = 'none'
			document.getElementById('preopCheck').style.display = 'none'
		}
 }

 function getMachineName(type) {
	let mname = ''
		lists[23]['PreOpEquipment'].forEach((data)=>{
		if(data.poe_id === type) 
			mname = data.poe_equip_description
		})
	return mname
 }

 function getQuestions(machineNumber,machineName){
    let qlist = []
	    lists[22]['PreOpEquipQuestionLookup'].forEach((data)=>{
	     	if(data.pet_equipment_identifier && data.pet_equipment_identifier.toUpperCase() === machineNumber.toUpperCase() && data.pet_poe_id == machineName){
				qlist.push({questionNumber: data.peq_poq_id, questionSort: data.peq_sort_order}) // unit property will be removed.
			 }
		 })
		return qlist
} 

function getMeasures(machineNumber,machineName){
    let mList = []
	lists[34]['EquipmentMeasureData'].forEach((data)=>{
		if(machineNumber== data.pet_equipment_identifier && machineName == data.pet_poe_id){
			mList.push(data)
		}
	})
		
	return mList
}

function populateEquipmentMeasures( shift, tag,required,mNumber = document.getElementById('machine_number').value, mType = document.getElementById('machineType').value){
	let equipMeasure = ''// = `<div class="md-form">`
	//filter the measure data for the equipment type and identifier.
	let measures = getMeasures(mNumber,mType)

	measures.forEach((measure) =>{
		equipMeasure = equipMeasure +  `<div class="md-form"><input type="number" step='0.1' name="measure-${shift}-${measure.pem_rld_measure_id}" id="measure-${shift}-${measure.pem_rld_measure_id}"  class="form-control "  ${required} min="0" >`
		equipMeasure = equipMeasure + `<label for="measure-${shift}-${measure.pem_rld_measure_id}" ><strong>${measure.ltr_text}</span> <span class='engine_unit'></span>:</strong> <span class='translate' data-i18n="${tag}" notes="${shift} of shift" ></label></div><br>`
	})

	document.getElementById(`${shift}-measure-readings`).innerHTML  = equipMeasure
	document.getElementById(`${shift}-measure-readings`).style.display = 'block'

	if(shift === 'end') {
		measures.forEach((measure) =>{
			if(parsedJSON){
				if(parsedJSON[`measure-${shift}-${measure.pem_rld_measure_id}`]) {
					document.getElementById(`measure-${shift}-${measure.pem_rld_measure_id}`).value = parsedJSON[`measure-${shift}-${measure.pem_rld_measure_id}`]
					$(`#measure-${shift}-${measure.pem_rld_measure_id}`).parent().find('label').addClass('active')
				}
			}
			
		})
	}

	$('.translate').localize()
	
}

function populateQuestions(mNumber = document.getElementById('machine_number').value, mType = document.getElementById('machineType').value) {
	if(mNumber && mType) {
		const quest = getQuestions(mNumber,mType)	
		quest.forEach((q) => {
			insertQuestion(q)
		})
		$('.translate').localize()
		document.getElementById('preopCheck').style.display = 'block'
		document.getElementById('machineType').nextSibling.nextSibling.nextSibling.classList.add('filled')
		document.getElementById('machineType').parentNode.style.display = 'block'	
		document.getElementById('selectMachine').style.display = 'block'
	 } 
}

function clearFieldsPictures() {
  for(let a = 0; a < $('.photoGallery').length;a++){
	$('.photoGallery')[a].parentNode.querySelector('canvas').style.display = 'none'
	$('.photoGallery')[a].innerHTML = ''
	$('#engine-start, #comments, #workplaceendshift, #engineend, #comments_location').val('').parent().find('label').removeClass('active filled')
  } ///////////////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}

function activateMachineTypeSelect() {
	let select2LanguageFunction = window[`sofvie_select2_languages_${selectedLanguage}`]
    if (!(typeof select2LanguageFunction === "function"))
    {
      select2LanguageFunction = {}
      console.error("Failed to get Select2 Translations")
    }

	$('#machineType').select2({theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder:""})
    .on('select2:select', function(){
		document.getElementById('preopQuestions').innerHTML = ''
		document.getElementById('preopCheck').style.display = 'none'
		$(this).parent().find('label').addClass('filled')
		clearFieldsPictures()
	   }
	)
	$('#machineType ~ span b').addClass("fa fa-caret-down");
}

function closeModal(modal) {
	let backDrops = $(".modal-backdrop");
	if(backDrops[backDrops.length - 1]) {
		backDrops[backDrops.length - 1].remove();
	}
	modal.hideModal()
}

document.getElementById('machine_number').addEventListener("keyup", (event)=>{
	event.target.value = event.target.value.toUpperCase();
	findMachines() 
})

function setPetId () {
	mtype = document.getElementById('machineType').value
	mnumber = document.getElementById('machine_number').value
	lists[40]['preopEquipmentSiteJob'].forEach((rec)=>{
		if(rec.pet_equipment_identifier.toUpperCase() === mnumber.toUpperCase() && rec.pet_poe_id == parseInt(mtype)) {
			document.getElementById('pet_id').value = rec.pet_id
		}
	})
}

document.getElementById('selectMachine').addEventListener("click", (event)=>{
	setPetId()
	document.getElementById('preopQuestions').innerHTML = ''
	populateQuestions()
	populateEquipmentMeasures('start', 8724,'required')
})

document.getElementById('end-pre-op-button').addEventListener('click', (event)=>{
	let form = document.getElementsByName("preop")[0]
	let Sig = ValidateModalSignatureFields(event);
	let Images = ValidateImageFields(event);

	let special = checkSpecialFields()
	if(!special) {
		   showDefectModal()
		   event.preventDefault();
		   event.stopImmediatePropagation()
		} else {
			if (!invalidContentValidation(form) || !Sig || !Images) {
					event.preventDefault();
					event.stopImmediatePropagation()
					let formModal = new SofvieModal();
					if(form.classList.contains('invalid-content'))
						formModal.handleModal(`invalidContent`)
					else 
						formModal.handleModal(`validate`)
					$('.confirmValidation').click(()=>{
						closeModal(formModal)
					})
				}
				else{
					let formModal = new SofvieModal();
					formModal.setModalElements(`warning`, `modalTitle`, `<span class='translate' data-i18n="1472" notes="Pre OP Completion"></span>`)
					formModal.setModalElements(`warning`, `modalText`, `<span class='translate' data-i18n="1473" notes="You are about to complete the Pre OP. Once completed, the data cannot be changed."></span>`)
					formModal.handleModal(`warning`) 
					$('.confirm').click((e)=>{
						document.getElementById('preopStatus').value = 'POSTOP'
						form.classList.add('validated');
						window.sessionStorage.setItem('modalsave','1')
						$('body')[0].classList.remove('modal-open')
						$(`#themodal`).modal('hide');
						$(`themodal`).hide();
						formModal.hideModal()
						$( "#saveDraft" ).trigger( "click" );
						$('.modal-backdrop').remove()
						populateEquipmentMeasures('end', 8725,'required')
						postOpAction()
					})
				}
				form.classList.add('was-validated'); 
			
		}
})

function showDefectModal() {
	spModal = new SofvieModal()
			 spModal.setModalElements('danger', 'modalText', `
			 <strong><span class='translate' data-i18n="3102" notes="This equipment may not be operated due to the reported major defect."></span></strong>
			 <br><br><span class='translate' data-i18n="3103" notes="A major defect was identified for Seatbelts, Lights, Brakes or Horn. Please inform your supervisor. Tap the Yes button to report the defect."></span>`)
			spModal.setModalElements('danger', 'modalTitle', `<span class='translate' data-i18n="3104" notes="Major Defect Detected"></span>`)
			spModal.handleModal('danger') 
			$('.translate').localize()
			$('.confirm').click((e)=>{
				if($('#draft').val()) {
				var url = new URL(window.location.href);
						let urldraftid = url.searchParams.get("draftid");
						draftID = $('#draft').val()
						if(urldraftid)
						draftID = urldraftid
							dbDraft.get(draftID).then(function(doc) {
								dbDraft.remove(doc);
                                OpenHazardReport()
							});	
				}else{
					OpenHazardReport()
				}
			})
}

function OpenHazardReport() {
	let form = document.getElementsByName("preop")[0]
				var arrParent = {};		
				var json = toJSONString( form );																				// Create storage for all forms
				arrParent = JSON.parse(json);
				sessionStorage.setItem("lastformdata", JSON.stringify(arrParent));
				setTimeout(function(){ window.open(`${window.location.origin}/forms/formHap.php`,'_self') }, 1000);
}

function checkSpecialFields() {
	   let sp = document.querySelectorAll(`input[type='radio'][special='']:checked`)
			for(let a in sp){
				if(sp[a].classList){
				if(sp[a].value !== '1')
				return false
	     }
	   }
	return true
}

function canAddEndMeasures(parsedJSON){
	// Determine if the parsed JSON contains any items that start with
	// measure-end.  This will indicate whether to display the end 
	// measures.
	if(parsedJSON['preopStatus']=='POSTOP') return true

	return false
}

function draftPreProcess(parsedJSON) {
	// End measures are injected in, however only add the end measures
	// for a post op, otherwise pre-op wil not validate.
	unlock()
	let addEndMeasures = canAddEndMeasures(parsedJSON)
	if (parsedJSON['machine_number']) {
		findMachines(parsedJSON['machine_number'], parsedJSON.site, parsedJSON.job_number) 
		if (parsedJSON['machineType']) {
			populateEquipmentMeasures('end', 8725,'', parsedJSON['machine_number'], parsedJSON['machineType'])
			populateEquipmentMeasures('start', 8724,'required', parsedJSON['machine_number'], parsedJSON['machineType'])

			document.getElementById('preopQuestions').innerHTML = ''
			populateQuestions(parsedJSON['machine_number'], parsedJSON['machineType'])
		
		}
	}
	if(parsedJSON['signature_end_of_shift_review_img_time']){
		lock()
		setTimeout(() => {
			$('.deleteGalleryImage, .clear_sign').addClass('d-none')
		}, 2000);		
	}
	else{
		$('#comments').removeAttr("disabled")
	}
}

</script>

<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>

<script>
 function postOpAction() { 
	let form = document.getElementsByName("preop")[0]
	let mode = document.getElementById('preopStatus').value
	req =  document.querySelectorAll('.postOP')
	pre = document.querySelectorAll('input:not(.postOP), textarea:not(.postOP)')
	preSelect = document.querySelectorAll('select:not(.postOP)')
	prePhoto = document.querySelectorAll('#preopCheck .photoImage .btn-block')	
	switch(mode) {
		case "PREOP" :  
			document.getElementById('submitForm').disabled = true
			$('#end-pre-op-button').css('display','block')
			$('#postOpCheck').css('display','none')
			for(let data in req) {
				if(req[data].classList){
					req[data].removeAttribute("required")
				}
			}
			break
		case "POSTOP" : document.getElementById('submitForm').disabled = false
			// make sure that you can remove images from Postop Recall
			$('.preOP .photoGallery .deleteGalleryImage').prop("onclick", null).off("click").removeClass('fa-trash-alt')
			$('.deleteGalleryImage').addClass('d-none')
			$('#end-pre-op-button, #selectMachine').css('display','none')
			$('#postOpCheck').css('display','block')
			populateEquipmentMeasures('end', 8725,'required')

			pre.disabled = true
			for(let predata in pre) {
				if(pre[predata].classList && pre[predata].name != 'workplace' && !pre[predata].name.startsWith('measure-end')){
					pre[predata].disabled = true
				}
			}
			for(let data in req) {
				if(req[data].classList && req[data].name != 'myFile'){
					req[data].setAttribute("required","")
				}
			}
			for(let preSelectData in preSelect) {
				if(preSelect[preSelectData].classList && preSelect[preSelectData].name != 'site' && preSelect[preSelectData].name != 'job_number'  
				&& preSelect[preSelectData].name != 'level' && preSelect[preSelectData].name != 'supervisor'){
					preSelect[preSelectData].disabled = true
				}
			}
			for(let prePhotoData in prePhoto) {				
				if(prePhoto[prePhotoData].classList){
					prePhoto[prePhotoData].style.display = "none"
					prePhoto[prePhotoData].parentElement.parentElement.classList.add("read-only")
				}
			}	
			document.getElementById('signature_supervisor_photo').required = false		
			document.getElementById('Report_Distribution1').disabled = false
			document.getElementById('signature_supervisor_photo').disabled = false
			document.getElementById('draft').disabled = false
			setTimeout(()=>{
				form.classList.remove('was-validated'); 
				form.classList.remove('validated'); 
			},200)
			let postPic = document.querySelectorAll('.postop_pics')
			for(let pp in postPic) {
				if(postPic[pp].type === 'file') {
					picsExist = postPic[pp].parentNode.parentNode.nextSibling.nextSibling.nextElementSibling.innerHTML
						if(picsExist) {
							postPic[pp].removeAttribute('required')
						}
					}
			}

			break
		default:
			break
	}
}

$('#end-measure-readings').on('change', (e)=> {
	let data = {
		measures: null,
		values: null
	}
	let mNumber = document.getElementById('machine_number').value
	let mType = document.getElementById('machineType').value
	let measures = getMeasures(mNumber, mType)
	let measure_rld = e.target.name.split('-')[2]
	
	measures.forEach((itm) =>{
		if(itm.pem_rld_measure_id==measure_rld){
			data.measures = itm

		}
	})

	// data.measures = measures
	let values = []
	// let cont = true
	let i=0

		
	let endValue = document.getElementById('measure-end-'  + measure_rld   ) 
	let startValue = document.getElementById('measure-start-' + measure_rld) 
	
	if(endValue!=null && startValue!=null){
		let value = {}
		value.start = startValue.value
		value.end = endValue.value  
		values.push(value)
		i++
	} else {

	}
	let vals = {
		val: values
	}

	data.values = values

	$('#emr').trigger('change', data)

})

function lock(lock_id, lock_time) {
	inputs = document.querySelectorAll('.postOP,.form-check-input,.lock')
	if(inputs){
		for (let obj of inputs){
			obj.setAttribute('disabled' , true);
			if (obj.classList.contains('sign')){
				obj.classList.add("d-none")
				obj.nextElementSibling.classList.remove("d-none")
				if(obj.getAttribute('signaturename')!="signature_end_of_shift_review"){
					obj.nextElementSibling.classList.add("read-only")  //signature comment only can show not edit
					obj.nextElementSibling.nextElementSibling.classList.add("d-none")
				}
			}
		}
	}


	$('[id^=measure-end-]').attr('disabled',true)
	

	imgUploads=document.querySelectorAll('.file-field')
	if(imgUploads){
		for (let obj of imgUploads){
			obj.parentElement.parentElement.classList.add("read-only")  //signature comment only can show not edit
		}
	}

	// lock images
	images = document.querySelectorAll('.image_input_to_lock')
	if(images){
		for (let obj of images) {
			obj.style.display = "none"
		}
	}

	postPhoto = document.querySelectorAll('#postOpCheck .photoImage .btn-block')	
	if(postPhoto){
		for(let postPhotoData in postPhoto) {
			if(postPhoto[postPhotoData].classList){
				postPhoto[postPhotoData].style.display = "none"
			}
		}	
	}

	$('.deleteGalleryImage').addClass('d-none')
}

function unlock(){	
	inputs = document.querySelectorAll('.postOP,.form-check-input')
	if(inputs){
		for (let obj of inputs){
			obj.removeAttribute("disabled")
			if (obj.classList.contains('sign')){
				obj.classList.remove("d-none")
				obj.nextElementSibling.classList.add("d-none")
				if(obj.getAttribute('signaturename')!="signature_end_of_shift_review"){
					obj.nextElementSibling.classList.remove("read-only")  //signature comment only can show not edit
					obj.nextElementSibling.nextElementSibling.classList.remove("d-none")
				}
			}
		}
	}


	imgUploads=document.querySelectorAll('.file-field')
	if(imgUploads){
		for (let obj of imgUploads){
			obj.parentElement.parentElement.classList.remove("read-only")  //signature comment only can show not edit
		}
	}


	// unlock images
	images = document.querySelectorAll('.image_input_to_lock')
	if(images){
		for (let obj of images) {
			obj.style.display = ""
		}
	}

	postPhoto = document.querySelectorAll('#postOpCheck .photoImage .btn-block')	
	if(postPhoto){
		for(let postPhotoData in postPhoto) {
			if(postPhoto[postPhotoData].classList){
				postPhoto[postPhotoData].style.display = ""
			}
		}	
	}

	$('.deleteGalleryImage').removeClass('d-none')	
}

$('#job_number').on("change", (event)=>{
	clearPreop(event)
})

$('#site').on("change", (event)=>{
	clearPreop(event)
})

function clearPreop(event) {
	if(!event.currentTarget.value) {
		$('#machine_number').val("").parent().find('label').removeClass(['filled',"active"])
		$(`#machineType`).parent().css('display','none')
		$('#machineType').val("").trigger("change").parent().find('label').removeClass(['filled',"active"])
		setPetId()
		document.getElementById('preopQuestions').innerHTML = ''
		$('#preopCheck').css("display", "none")

	}
}

</script>
