<?php	
  $strPageTitle = 'Hot Work Permit';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
					
					<h6 class="text-secondary"><span class='translate' data-i18n="2247" notes="Hot Work Permit"></span></h6>
					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
						</select>
						<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
					</div>
          			<form name="hotWorkPermit" id="hotWorkPermit" class="needs-validation" method="POST" action="#" novalidate>
					  	
						<?php include 'includes/CommonFormHeader.php' ?>
						
						  <div class="md-form">
							<textarea type="text" name="workdescription" id="workdescription" class="form-control md-textarea"  wrap="VIRTUAL" required></textarea>
							<label for="workdescription"><span class='translate' data-i18n="942" notes="Work Description"></span></label>
						</div>
						<div class="pt-1 position-relative my-4">
						    <select name="hot_work_type" id="hot_work_type" class="select-multiple mobile-hotworktype-select" multiple required> 
							</select>
							<label for="hot_work_type"><span class='translate' data-i18n="525" notes="Hot Work Type"></span></label>
						</div>

						<div id="other_hotwork_type"class="md-form" style="display:none"> 

							<!-- Conditionally hide the contents of this div - based on the hot work hazards selection = Other -->
							<input type="text" class="form-control" name="hot_work_type_other" id="hot_work_type_other" length="200" maxlength="200" isrequired>
							<label for="hot_work_type_other"><span class='translate' data-i18n="702" notes="Other Hot Work Type"></span></label>

						</div>  


						<div class="pt-1 position-relative my-4">
						    <select name="hot_work_hazards" id="hot_work_hazards" class="select-multiple mobile-hotworkhazardstype-select" multiple required>
							</select>
							<label for="hot_work_hazards"><span class='translate' data-i18n="2361" notes="Identify Hot Work Hazards"></span></label>
						</div>

						<div id="other_hotwork_hazards_section"class="md-form" style="display:none">
							<!-- Conditionally hide the contents of this div - based on the hot work hazards selection = Other -->
							<input type="text" class="form-control" name="other_hotwork_hazards" id="other_hotwork_hazards" length="200" maxlength="200" isrequired >
							<label for="other_hotwork_hazards"><span class='translate' data-i18n='3101' notes='Other Hazards'></span></label>

						</div>
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="459" notes="Evaluate Risk"></span></label>
							<div class="form-check custom-radio no-sub pl-0">
								<input type="radio" class="form-check-input" id="evaluate_risk_low" name="evaluate_risk" value="0"  >
								<label for="evaluate_risk_low"><span class='translate form-check-label mr-2 d-block' data-i18n="2362" notes="Low Risk"></span></label>

								<input type="radio" class="form-check-input" id="evaluate_risk_high" name="evaluate_risk" value="1"  >
								<label for="evaluate_risk_high"><span class='translate form-check-label mr-2' data-i18n="2363" notes="High Risk"></label>
							</div>
						</div>
						<div class="pt-1 position-relative my-4">
						    <select name="determine_controls" id="determine_controls" class="select-multiple mobile-determinecontrols-select" multiple required>
							</select>
							<label for="determine_controls"><span class='translate' data-i18n='156' notes="Determine Controls / Equipment"></span>					 
							</label>
						</div>

						
						<!-- Conditionally hide the contents of this div - based on determine controls = Other	 -->
						<div id="other_controls_equipment_section"class="md-form" style="display:none">
							<input type="text" class="form-control" name="other_controls_equipment" id="other_controls" length="200" maxlength="200" isrequired>
							<label for="other_controls_equipment">
							<span class='translate' data-i18n="700" notes="Other Controls / Equipment"></span>
							</label>
						</div>

						<!-- Canvas place holder -->
						<canvas id="canvas" style='display:none;'></canvas>

						<div class="pt-1 position-relative my-4">
						    <select name="personal_protective_equipment" id="personal_protective_equipment" class="select-multiple mobile-personalprotectiveequipment-select" multiple required>
							</select>
							<label for="personal_protective_equipment">
							<span class="translate" data-i18n="834" notes="Special PPE"></span>
							</label>
						</div>

						<div id="other_ppe" class="md-form" style="display:none">
							<!-- Conditionally hide the contents of this div - based on personal protective equipment = other -->
							<input type="text" class="form-control" name="other_Special_PPE" id = "other_Special_PPE" length="200" maxlength="200" isrequired>
							<label for="other_Special_PPE"><span class='translate' data-i18n="709" notes="Other Special PPE"></span>
							</label>

						</div>

						<div class="md-form">
							<textarea name="comments" id="comments" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="comments"><span class='translate' data-i18n="81" notes="Comments"></span>
							</label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="2364" notes="Pre-Work Signatures"></span></h6>
						<div class="pt-1 position-relative my-4">
							<select name="workers_present" id="workers_present" class="select-multiple mobile-employee-select" multiple required>
							</select>
							<label for="workers_present"><span class='translate' data-i18n="958" notes="Workers Present"></span>														  
							</label>
						</div>
						<div class="my-4">
							<label class="text-muted">
							    <span class='translate' data-i18n="845" notes="Supervisor / Designate"></span>
							</label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign translate' signaturename='supervisor_signature_start'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='supervisor_signature_start_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="supervisor_signature_start" id="supervisor_signature_start" class='modalSignature' value='' required>
							<input type="hidden" name="vector_supervisor_start" id='vector_supervisor_start' value=''>
							<input type="hidden" name="supervisor_signature_start_comments" id='supervisor_signature_start_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="supervisor_signature_start_img_time" id="supervisor_signature_start_img_time" notes='supervisor_signature_start_img_time' readonly/></small>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="2366" notes="Completion of Hot Work"></span></h6>

						<div class="md-form">
							<input type="text" class="form-control timepicker" name="completion_time" id="completion_time" required>
							<label for="completion_time"><span class='translate' data-i18n="521" notes="Hot Work Completed"></span></label>
						</div>

						<div class="md-form">
							<input type="text" class="form-control timepicker" name="watcher_time_left" id="watcher_time_left" required>
							<label for="watcher_time_left"><span class='translate' data-i18n="913" notes="Watcher Left Hot Work Area"></span></label>
						</div>
						
						<div class="pt-1 position-relative my-4">
							<select name="worker_watcher" id="worker_watcher" class="select-single mobile-employee-select-single" single required>
							</select>
							<label for="worker_watcher"><span class='translate' data-i18n="949" notes="Worker / Watcher"></span></label>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="845" notes="Supervisor / Designate"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign translate' signaturename='supervisor_signature_end'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='supervisor_signature_end_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="supervisor_signature_end" id="supervisor_signature_end" class='modalSignature' value='' required>
							<input type="hidden" name="vector_supervisor_end" id='vector_supervisor_end' value=''>
							<input type="hidden" name="supervisor_signature_end_comments" id='supervisor_signature_end_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="supervisor_signature_end_img_time" id="supervisor_signature_end_img_time" notes='supervisor_signature_end_img_time' readonly/></small>
						</div>


						<!-- conditionally displayed if high risk section is selected -->

						<div id="hi_risk_area"  style="display:none">
							<h6 class="text-secondary pt-4"><span class='translate' data-i18n="2363" notes="High Risk"></span></h6>
							<label class="text-muted"><span class='translate' data-i18n="2422" notes="Why is this high risk hot work?"></span></label>
							<br>
							<div class="form-check pl-0 d-inline-block mr-3">
								<input type="checkbox" class="form-check-input ml-0" name="gas_test" id="gas_test" onchange="getCheckboxStatus('gas_test')" value="0" >
								<label class="form-check-label" id="gtest" for="gas_test"><span class='translate' data-i18n="778" notes="Requires Gas Test"></span></label>
							</div>
							<div class="form-check pl-0 d-inline-block">
								<input type="checkbox" class="form-check-input ml-0" name="location" id="location" onchange="getCheckboxStatus('location')" value="0">
								<label class="form-check-label" for="location"><span class='translate' data-i18n="517" notes="High Risk Location"></span></label>
							</div>
						

							<!-- nested condtional display sections -->

							<div id="requires_gas_test">

								<h6 class="text-secondary pt-4"><span class='translate' data-i18n="2349" notes="Air Quality Test"></span></h6>

								<div id="gasTests"></div>
								<div id='addGasTest' class='btn btn-sm btn-primary d-none'><i class="fa fa-plus"></i> <span class='translate' data-i18n='2351' notes='ADD AIR QUALITY TEST'></span></div>
								<div id='removeGasTest' class='btn btn-sm btn-outline-primary d-none'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n='2352' notes='REMOVE AIR QUALITY TEST'></span></div>
							</div>

						
							
							<div id="high_risk_location_section">
								<h6 class="text-secondary pt-4"><span class='translate' data-i18n="517" notes="High Risk Location"></span></h6>
								<div class="md-form">
							 	
									<input type="text" name="location_details" id="location_details" class="form-control" value="" length="200" maxlength="200" isrequired/>
									<label for="location_details"><span class='translate' data-i18n="630" notes="Location Details"></span></label>
								</div>
								<div class="pt-1 position-relative my-4">
									<select name="precautions_control" id="precautions_control" class="select-multiple mobile-highriskprecautions-select" multiple isrequired>
									</select>
									<label for="precautions_control"><span class='translate' data-i18n="755" notes="Precautions"></span></label>
								</div>
								
								<div class="md-form">
									<div class="pt-1 position-relative my-4" id="additional_precautions" style="display:none">
										<input type="text" name="additionalprecautions" id="additionalprecautions" class="form-control" length="200" maxlength="200" isrequired></input>
										<label for="additionalprecautions"><span class='translate' data-i18n="2836" notes="Other Precautions"></span></label>
									</div>
								</div>
							</div>
						</div>
						<!-- end the conditional field -->

						<div id="crews"></div>

						<div id='addCrew' class='btn btn-sm btn-primary'><i class="fa fa-plus"></i> <span class='translate' data-i18n='2369' notes='ADD WATCHER'></span></div>
                        <div id='removeCrew' class='btn btn-sm btn-outline-primary'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n='2370' notes='REMOVE WATCHER'></span></div>

						<?php include 'includes/CommonFormFooter.php' ?>
						<input type="hidden" name="formname" id="formname" class = "trans_input" value="2247" tag="2247">
						<input type="hidden" name="formtype" id="formtype" value="SUP" />
						<input type="hidden" name="formid" id="formid" value="372368" />
						<input type="hidden" name="version" id="version" value="1" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
						<input type="hidden" name="numCrews" id="numCrews" value='1' />
						<input type="hidden" name="totalCrews" id="totalCrews" value='10' />
						<input type="hidden" name="numAirTest" id="numAirTest" value='0' />
						<input type="hidden" name="totalAirTest" id="totalAirTest" value='6' />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>

<script type="text/javascript">

	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.')
			document.getElementById("evaluate_risk_low").addEventListener("change",toggleHighRisk)
			document.getElementById("evaluate_risk_high").addEventListener("change",toggleHighRisk)
			document.getElementById("location").addEventListener("change",toggleHighRiskLocation)
			document.getElementById("gas_test").addEventListener("change",toggleGasTest)			
		},
		
 
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		},		
		
	}

	$('#hot_work_type').change(function(e){
		$("#hot_work_type_other").prop('required',false)
			if(checkOther('hot_work_type', $(this).val())){
				$("#other_hotwork_type").show()
				$("#hot_work_type_other").prop('required',true)
			}else{
				$("#other_hotwork_type").hide()
				$("#hot_work_type_other").prop('required',false)
				$("#hot_work_type_other").val('').parent().find('label').removeClass('active filled')
			}
	})

	$('#determine_controls').change(function(e){
		$("#other_controls").prop('required',false)
			if(checkOther('determine_controls', $(this).val())){
				$("#other_controls_equipment_section").show()
				$("#other_controls").prop('required',true)
			}else{
				$("#other_controls_equipment_section").hide()
				$("#other_controls").prop('required',false)
				$("#other_controls").val('').parent().find('label').removeClass('active filled')
			}
	})	

	$('#precautions_control').change(function(e){
		$("#additionalprecautions").prop('required',false)
			if(checkOther('precautions_control', $(this).val())){
				$("#additional_precautions").show()
				$("#additionalprecautions").prop('required',true)
			}else{
				$("#additional_precautions").hide()
				$("#additionalprecautions").prop('required',false)
				$("#additionalprecautions").val('').parent().find('label').removeClass('active filled')
			}
	})	

	$('#personal_protective_equipment').change(function(e){
		$("#other_Special_PPE").prop('required',false)
			if(checkOther('personal_protective_equipment', $(this).val())){
				$("#other_ppe").show()
				$("#other_Special_PPE").prop('required',true)
			}else{
				$("#other_ppe").hide()
				$("#other_Special_PPE").prop('required',false)
				$("#other_Special_PPE").val('').parent().find('label').removeClass('active filled')
			}
	})

	$('#hot_work_hazards').change(function(e){
		$("#other_hotwork_hazards").prop('required',false)
			if(checkOther('hot_work_hazards', $(this).val())){
				$("#other_hotwork_hazards_section").show()
				$("#other_hotwork_hazards").prop('required',true)
			}else{
				$("#other_hotwork_hazards_section").hide()
				$("#other_hotwork_hazards").prop('required',false)
				$("#other_hotwork_hazards").val('').parent().find('label').removeClass('active filled')
			}
	})

	function toggleHighRisk(){
		let hiriskarea = document.getElementById("hi_risk_area") 
		let val = document.getElementById("evaluate_risk_high").checked
		if(val == true){ 
			hiriskarea.style.display = ""
		} else {
			hiriskarea.style.display = "none"

		}
	} 

	function toggleHighRiskLocation(){
		let section = document.getElementById("high_risk_location_section")
		 let kids = document.getElementById("high_risk_location_section").children
		let val = document.getElementById("location").checked
		if(val == true){ 
			document.getElementById('location_details').setAttribute("required","")
			document.getElementById('location_details','').removeAttribute("isrequired")
			$('#location_details').val('').trigger('change').parent().find('label').removeClass('filled')
			document.getElementById('precautions_control').setAttribute("required","")
			document.getElementById('precautions_control','').removeAttribute("isrequired")
			$('#precautions_control').val('').trigger('change').parent().find('label').removeClass('filled')
			section.style.display=""
			for(let c = 0;c<kids.length;c++){
				kids[c].style.display = ""
			}
		} else {
			section.style.display="none"
			document.getElementById('location_details').setAttribute("isrequired","")
			document.getElementById('location_details','').removeAttribute("required")
			$('#location_details').val('').trigger('change').parent().find('label').removeClass('filled')
			document.getElementById('precautions_control').setAttribute("isrequired","")
			document.getElementById('precautions_control','').removeAttribute("required")
			$('#precautions_control').val('').trigger('change').parent().find('label').removeClass('filled')
			for(let c = 0;c<kids.length;c++){
				kids[c].style.display = "none"
			}
			document.getElementById('location_details').value = ""
			
			document.getElementById('additionalprecautions').value = ""
			let precautions = document.getElementById('precautions_control')

			let selected = []
			for(let c=0;c<precautions.options.length;c++){
				if( precautions.options[c].selected){
					selected.push(precautions.options[c].value)
				}
			}
			let c= precautions.options.length
			while(c>=0){
				if(selected[c]){
					precautions.remove(c)
				} 
				c--
			}
		}
	}

	function toggleGasTest(){
		let section = document.getElementById("requires_gas_test")	
		let val = document.getElementById("gas_test").checked
		let num = document.getElementById('numAirTest').value
		if(val == true){ 
			$('#addGasTest').click()
			document.getElementById('numAirTest').value = 1
			document.getElementById('addGasTest').classList.remove('d-none')
			if (num==1){
				document.getElementById('removeGasTest').classList.add('d-none')
			}
			section.style.display = ""
			let kids = document.getElementById("requires_gas_test").children
			for(let c = 0;c<kids.length;c++){
				kids[c].style.display = ""
				document.getElementById('oxygen_1').setAttribute("required","")
				document.getElementById("oxygen_1").removeAttribute("isrequired")
				$('#oxygen_1').val('').trigger('change').parent().find('label').removeClass('filled')
				document.getElementById('lel_1').setAttribute("required","")
				document.getElementById("lel_1").removeAttribute("isrequired")
				$('#lel_1').val('').trigger('change').parent().find('label').removeClass('filled')
				document.getElementById('toxic_gas_1').setAttribute("required","")
				document.getElementById("toxic_gas_1").removeAttribute("isrequired")
				$('#toxic_gas_1').val('').trigger('change').parent().find('label').removeClass('filled')
				document.getElementById('time_of_test_1').setAttribute("required","")
				document.getElementById("time_of_test_1").removeAttribute("isrequired")
				$('#time_of_test_1').val('').trigger('change').parent().find('label').removeClass('filled')
				document.getElementById('name_of_tester_1').setAttribute("required","")
				document.getElementById("name_of_tester_1").removeAttribute("isrequired")
				$('#name_of_tester_1').val('').trigger('change').parent().find('label').removeClass('filled')
			}
			
		} else {
			section.style.display = "none"
			document.getElementById('addGasTest').classList.remove('d-none')
			document.getElementById('removeGasTest').classList.add('d-none')

			//Remove all added gas tests.
			//get the number of tests added


			let testCount = document.getElementById('numAirTest').value
			for(let num = 1;num<=testCount;num++){
				document.getElementById('oxygen_'+ num).setAttribute("isrequired","")
				document.getElementById("oxygen_" + num).removeAttribute("required")
				document.getElementById('oxygen_' + num).value = ''
				document.getElementById('lel_'+num).setAttribute("isrequired","")
				document.getElementById("lel_" + num).removeAttribute("required")
				document.getElementById('lel_'+num).value = ''
				document.getElementById('toxic_gas_'+num).setAttribute("isrequired","")
				document.getElementById("toxic_gas_" + num).removeAttribute("required")
				document.getElementById("toxic_gas_" + num).value = ''
				document.getElementById('time_of_test_'+num).setAttribute("isrequired","")
				document.getElementById("time_of_test_" + num).removeAttribute("required")
				document.getElementById("time_of_test_" + num).value = ''
				document.getElementById('name_of_tester_'+num).setAttribute("isrequired","")
				document.getElementById("name_of_tester_" + num).removeAttribute("required")
				document.getElementById("name_of_tester_" + num).value = ''

				let selections = document.getElementById('name_of_tester_' + num).options
				if (selections){
					for(let i=selections.length-1;i>=0;i--){
						if(selections[i].selected)
							selections.remove(i);
					}
					document.getElementById('lbl_name_of_tester_' + num).classList.remove('filled')
				}
			}
			removeAllGasTests()
		}
	}



	let airtestcount = ''
	let totalAirTest =  parseInt(document.getElementById('totalAirTest').value)
	document.getElementById('removeGasTest').classList.add('d-none')


	function getCheckboxStatus(ele){
		var status = document.getElementById(ele).checked;
		if (status) {
			document.getElementById(ele).value='1'
		} else {
			document.getElementById(ele).value='0'
		}
	}
// add a gas test
document.getElementById('addGasTest').addEventListener('click',(e)=>{
	airtestcount = document.getElementById('numAirTest').value
	if(airtestcount < totalAirTest) {
		airtestcount++
		addGasTest(airtestcount)
		let myGasTest = $(`.gasTestSection[value="${airtestcount}"]`)
		makeGasTestRequired(myGasTest.find('[isrequired]'))
		if(airtestcount === totalAirTest)
			document.getElementById('addGasTest').classList.add('d-none')
		document.getElementById('numAirTest').value = airtestcount
	} 
	if(airtestcount > 0 && airtestcount <= totalAirTest)
  	 document.getElementById('removeGasTest').classList.remove('d-none')
})

function addGasTest(tester,mode){	
	const gasTestsModal = 
		`<div class="gasTestSection" value=${tester}>
			<h6 class="text-secondary pt-4"><span class='translate' data-i18n="2350" notes="Test"></span> ${tester}</h6>
			<div class="md-form">
				<input type="number" class="form-control" name="oxygen_${tester}" id="oxygen_${tester}" min="0.00" step="0.01" max="100.00" isrequired>
				<label for="oxygen_${tester}"><span class='translate' data-i18n="2343" notes="Oxygen (19.5% - 23.0%)"></span></label>
			</div>
			<div class="md-form">
				<input type="text" class="form-control" name="lel_${tester}" id="lel_${tester}" length="200" maxlength="200" isrequired>
				<label for="lel_${tester}"><span class='translate' data-i18n="632" notes="Lower Explosive Limit"></label>
			</div>

			<div class="md-form">
				<input type="text" name="toxic_gas_${tester}" id="toxic_gas_${tester}" class="form-control" length="200" maxlength="200" isrequired>
				<label for="toxic_gas_${tester}"><span class='translate' data-i18n="875" notes="Toxic Gas"></label>
			</div>

			<div class="md-form">
				<input type="text" class="form-control timepicker" name="time_of_test_${tester}" id="time_of_test_${tester}" isrequired>
				<label for="time_of_test_${tester}"><span class='translate' data-i18n="864" notes="Time of Test"></span></label>
			</div>

			<div class="pt-1 position-relative my-4">
				<select name="name_of_tester_${tester}" id="name_of_tester_${tester}" class="select-single mobile-employee-select-single" single isrequired>
				</select>
				<label for="name_of_tester_${tester}"  id="lbl_name_of_tester_${tester}"><span class='translate' data-i18n="653" notes="Name of Tester"><span></label>
			</div>
		</div>`
	
	$("#gasTests").append(gasTestsModal)
	if(!mode){  
		formHeader.populateEmployeeSelectSingle(`name_of_tester_${tester}`)
		try {$('.translate').localize()} catch {}	
		initializeSelect2Dynamic(`name_of_tester_${tester}`)
		initializePickadate()
	}			
}



// remove a gas test 
document.getElementById('removeGasTest').addEventListener('click',(e)=>{
	removeGasTest()
})


function removeAllGasTests(){
	let testCount = document.getElementById('numAirTest').value
	for(let c=testCount;c>=0;c--){
		removeGasTest()
	}
	document.getElementById('numAirTest').value=0
}

function removeGasTest(){
	let myGasTest = $(`.gasTestSection[value="${airtestcount}"]`)
	myGasTest.remove()
	if(airtestcount>0)
	airtestcount--
	document.getElementById('numAirTest').value = airtestcount
	if(airtestcount > 0 && airtestcount <= totalAirTest)
		document.getElementById('removeGasTest').classList.remove('d-none')
	document.getElementById('addGasTest').classList.remove('d-none')
	if(airtestcount >= totalAirTest)
	document.getElementById('addGasTest').classList.add('d-none')
	if(airtestcount === 1)
		document.getElementById('removeGasTest').classList.add('d-none')
}

// Populate the Form from a Draft by showing the sections activated in FormHandler
function populateGasTestDynamicForm(numAirTest,totalAirTest) {
	$(`.gasTestSection`).remove()
	airtestcount = numAirTest
	document.getElementById('addGasTest').classList.remove('d-none')
	if(airtestcount > 0 && airtestcount <= totalAirTest)
		document.getElementById('removeGasTest').classList.remove('d-none')
	if(airtestcount >= totalAirTest)
		document.getElementById('addGasTest').classList.add('d-none')
	for (a = 1; a <= airtestcount; a++) {
		addGasTest(a,"loadDraft")
		let getGasTest = $(`.gasTestSection[value="${a}"]`)	
		makeGasTestRequired(getGasTest.find('[isrequired]'))
	}
}

// when adding a crew make crew fields required
function makeGasTestRequired(elements) {
	for(let data in elements){
		if(elements[data].attributes) {
			elements[data].removeAttribute('isrequired')
			elements[data].setAttribute('required', '')
		}
	}
}

function draftPostProcess(parsedJSON) {
    toggleHighRisk()
    toggleHighRiskLocation()
}
// END of Section RMR

$( document ).ready(function() {
		addCrew(1)
	});

function addCrew(crewNum,mode){
	const crewsModal = 
	`<div class="crewsection" value=${crewNum}>
		<h6 class="text-secondary pt-4"><span class='translate' data-i18n="912" notes="Watcher"></span> ${crewNum}</h6>
		<div class="pt-1 position-relative my-4">
			<select name="employee_${crewNum}" id="employee_${crewNum}" class="select-single mobile-employee-select-single" required>
			</select>
			<label for="employee_${crewNum}"><span class='translate' data-i18n="649" notes="Name"></span></label>
		</div>

		<div class="md-form">
			<input type="text" class="form-control timepicker" name="firewatch_starttime_${crewNum}" id="firewatch_starttime_${crewNum}" required>
			<label for="firewatch_starttime_${crewNum}"><span class='translate' data-i18n="2367" notes="Start Time"></span></label>
		</div>

		<div class="md-form">
			<input type="text" class="form-control timepicker" name="firewatch_endtime_${crewNum}" id="firewatch_endtime_${crewNum}" required>
			<label for="firewatch_endtime_${crewNum}"><span class='translate' data-i18n="2368" notes="End Time"></span></label>
		</div>

		<div class="my-4">
			<label class="text-muted"><span class='translate' data-i18n="823" notes="Signature"></span></label>
			<div class="btn-group d-flex" role="group" aria-label="Action subforms">
				<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign translate' signaturename='supervisor_firewatchsignature_${crewNum}'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
				<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
				<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
			</div>
			<img id='supervisor_firewatchsignature_${crewNum}_img' src='' class='signatureImage d-block pt-2'/>
			<input type="hidden" name="supervisor_firewatchsignature_${crewNum}" id="supervisor_firewatchsignature_${crewNum}" class='modalSignature' value='' required>
			<input type="hidden" name="vector_employee_${crewNum}" id='vector_employee_${crewNum}'value=''>
			<input type="hidden" name="supervisor_firewatchsignature_${crewNum}_comments" id='supervisor_firewatchsignature_${crewNum}_comments' class="sig_comment" value=''>
			<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="supervisor_firewatchsignature_${crewNum}_img_time" id="supervisor_firewatchsignature_${crewNum}_img_time" notes='supervisor_firewatchsignature_${crewNum}_img_time' readonly/></small>
		</div>
	</div>`
	
	$("#crews").append(crewsModal);
	if(crewNum>1 && !mode){
		initializeSelect2Dynamic(`employee_${crewNum}`)
		formHeader.populateEmployeeSelectSingle(`employee_${crewNum}`)
		$('.sign').off('click')
		$(`.sign_comment`).off('click')
		initializeSignatures()
		initializePickadate()
		try {$('.translate').localize()} catch {}
	}
}
</script>

<script>
document.addEventListener("DOMContentLoaded", function(){
	// prepopulate the worker watcher with the current user logged in.
	openCacheData().then((rdata)=>{
		$('#worker_watcher').val(remoteData[_EMPLOYEE].Employee[0].per_full_name).trigger('change').parent().find('label').addClass('filled')
	})
});
</script>