<?php	
  $strPageTitle = 'Shift Report Construction';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>
<input type="hidden" value = "<?php	echo(_RESOURCEDOMAIN);?>"/>
<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary"><span class='translate' data-i18n="1229" notes="Shift Report Construction"></span></h6>
          <div class="pt-1 position-relative my-4">
            <select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
            </select>
            <label for="draft"><span class='translate' data-i18n='1474' notes='Form Drafts'></span></label>
          </div>

          <form name="TemplateForm" id="TemplateForm" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='820' notes='Shift'></span></h6>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="shift_days" name="shift" value="1095" required>
								<label class="form-check-label mr-2" for="shift_days"><span class='translate' data-i18n="1095" notes="Days"></span></label>

								<input type="radio" class="form-check-input trans_input" id="shift_nights" name="shift" value="1375">
								<label class="form-check-label mr-2" for="shift_nights"><span class='translate' data-i18n="1375" notes="Nights"></span></label> 
							</div>

						<div class="md-form">
							<input type="text" name="safety_topic" id="safety_topic" class="form-control" length="200" maxlength="200" required>
							<label for="safety_topic"><span class='translate' data-i18n="815" notes="Safety Topic"></span></label>
						</div>

						<div class="md-form">
							<textarea name="safety_notes" id="safety_notes" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="safety_notes"><span class='translate' data-i18n='809' notes = 'Safety Notes Log'></span></label>
						</div>

						<div class="md-form">
							<textarea name="safety_communications" id="safety_communications" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="safety_communications"><span class='translate' data-i18n='85' notes = 'Communications from Previous Shift'></span></label>
						</div>		
						
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1556" notes="Workplace Details"></span></h6>
						<canvas id="canvas" style='display:none;'></canvas>
						<div id="crews"></div>
            			<div id='addCrew' class='btn btn-sm btn-primary'><i class="fa fa-plus"></i> <span class='translate' data-i18n="1211" notes="Add Workplace"></span></div>
						<div id='removeCrew' class='btn btn-sm btn-outline-primary'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n="2378" notes="Remove Workplace"></span></div>

						<div class="md-form">
							<textarea name="extras_delays" id="extras_delays" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="extras_delays"><span class='translate' data-i18n="477" notes="Extras and/or Delays"></span></label>
						</div>

						<div class="md-form">
							<textarea name="end_states" id="end_states" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="end_states"><span class='translate' data-i18n="425" notes="End-States Summary"></span></label>
						</div>

						<div class="md-form">
							<textarea name="next_shift_requirements" id="next_shift_requirements" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="next_shift_requirements"><span class='translate' data-i18n="661" notes="Next Shift Requirements"></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="81" notes="Comments"></span></h6>
						<div class="md-form">
							<textarea name="positive_recognition" id="positive_recognition" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="positive_recognition"><span class='translate' data-i18n="81" notes="Comments"></span></label>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag="1229" class = "trans_input" value="1229" note="SHIFT REPORT CONSTRUCTION" />
						<input type="hidden" name="formtype" id="formtype" value="SR" />
						<input type="hidden" name="formid" id="formid" value="333840" />
						<input type="hidden" name="version" id="version" value="8" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
						<input type="hidden" name="numCrews" id="numCrews" value='1' />
						<input type="hidden" name="totalCrews" id="totalCrews" value='15' />     
					</form>
					
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript">

function fetchSite() {
 return	` where Filter = 'Fraser Mine'`
}


	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');

			return true;
		}	
	}

	$( document ).ready(function() {
		addCrew(1)
	});
	
    function addCrew(crewNum,mode){
		const crewsModal = 
		`<div class="crewsection" value=${crewNum}>
			<h6 class="text-secondary pt-4"><span class='translate' data-i18n='959' notes = 'Workplace'></span> ${crewNum}</h6>
			<div class="pt-1 position-relative my-4">
				<select name="workplace_${crewNum}" id="workplace_${crewNum}" class="select-multiple mobile-employee-select" multiple required>
				</select>
				<label for="workplace_${crewNum}"><span class='translate' data-i18n="1557" notes="Workers"></span></label>
			</div>

			<div class="pt-1 position-relative my-4">
				<select name="workplace_${crewNum}_hours" id="workplace_${crewNum}_hours" class="select-single mobile-hourssummary-select" required>
				</select>
				<label for="workplace_${crewNum}_hours"><span class='translate' data-i18n="526" notes="Hours"></span></label>
			</div>

			<div class="md-form">
				<textarea type="text" name="work_completed_${crewNum}" id="work_completed_${crewNum}" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
				<label for="work_completed_${crewNum}"><span class='translate' data-i18n="941" notes="Work Completed"></span></label>
			</div>

			<div class="form-group photoImage" id="workplace_picture_${crewNum}"> 
				<label class="d-block"><span class='translate' data-i18n="969" notes="Workplace Pictures"></span></label>
				<canvas id="wpcanvas${crewNum}" style='display:none;'></canvas>
				<div class="btn-group d-flex" role="group">
					<div class="btn btn-block btn-outline-secondary file-field px-1">
						<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
						<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
					</div>
				</div>
				<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
				<div class="row photoGallery" id="wpgalleryid${crewNum}"></div>
			</div>

			<div class="pt-1 position-relative my-4">
				<select name="equipment_group_${crewNum}" id="equipment_group_${crewNum}" class="select-multiple shift-report" multiple>
				</select>
				<label for="equipment_group_${crewNum}"><span class='translate' data-i18n="9559" notes="Please select Site and Department/Job to select Equipment"></span></label>
			</div>

			<div class="pt-1 position-relative my-4">
				<select name="equipment_location_group_${crewNum}" id="equipment_location_group_${crewNum}" class="select-single mobile-equipmentlocation">
				</select>
				<label for="equipment_location_group_${crewNum}"><span class='translate' data-i18n="451" notes="Equipment Location"></span></label>
			</div>

			<div class="md-form">
				<input type="text" name="equipment_details_${crewNum}" id="equipment_details_${crewNum}" class="form-control" length="200" maxlength="200">
				<label for="equipment_details_${crewNum}"><span class='translate' data-i18n="429" notes="Equipment Details"></span></label>
			</div>
		</div>`
		
		$("#crews").append(crewsModal);
		if(crewNum>1 && !mode){
			initializeSelect2Dynamic(`workplace_${crewNum}`)
			initializeSelect2Dynamic(`workplace_${crewNum}_hours`)
			initializeSelect2Dynamic(`equipment_group_${crewNum}`)
			initializeSelect2Dynamic(`equipment_location_group_${crewNum}`)  
			formHeader.populateEmployeeSelect(`workplace_${crewNum}`)
			formHeader.populateHoursSummarySelect(`workplace_${crewNum}_hours`)
			preop_site_job_equipment_select()
			formHeader.populateEquipmentLocationSelect($("#site").val(),`equipment_location_group_${crewNum}`)	
			addImagePicker('workplace_picture_' + crewNum)
			try {$('.translate').localize()} catch {}
		}	
	}

	function clearEquipmentFields(id) {
        if(id === 'job_number' || id === 'site'){
			$('.shift-report').each((rec)=>{
				all_rest = []
				let optionData = `<select name="equipment_group_${rec+1}" id="equipment_group_${rec+1}" class="select-multiple shift-report" multiple>`
				all_rest.forEach((data)=>{
					optionData += `<option value="${data.id}">${data.text}</option>`
				})
				optionData += `</select>`
				$(`#equipment_group_${rec+1}`).html(optionData)
				if(main_current_draft_object){
					main_current_draft_object[`equipment_group_${rec+1}`] = null
				}
				$(`#equipment_group_${rec+1}`).parent().find('label').html(i18next.t("9559"))
				$(`#equipment_group_${rec+1}`).val("").trigger("change").parent().find('label').removeClass(['filled',"active"])
        	})
    	}
	}


</script>
<script src="/js/groupEquipment.js"></script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
