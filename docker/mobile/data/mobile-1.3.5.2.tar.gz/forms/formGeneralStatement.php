<?php	
  $strPageTitle = 'General Statement';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
					<h6 class="text-secondary"><span class='translate' data-i18n="2173" notes="General Statement"><span></h6>

					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
						</select>
						<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></label>
					</div>

          			<form name="generalStatement" id="generalStatement" class="needs-validation" method="GET" action="#" novalidate>
          
						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1741" notes="Statement Information"></h6>

						<div class="pt-1 position-relative my-4">
							<select name="worker" id="worker" class="select-single mobile-employee-select-single" required>
							</select>
							<label for="worker"><span class='translate' data-i18n="947" notes="Worker"></label>
						</div>

						<div class="md-form">
							<input type="text" name="Other_Worker" id="Other_Worker" length="200" maxlength="200" class="form-control otherclass">							
							<label for="Other_Worker"><span class='translate' data-i18n="948" notes="Worker (not included in list above)"></label>
						</div>

						<div class="md-form">
							<input type="text" name="occupation" id="occupation" length="200" maxlength="200" class="form-control">
							<label for="occupation"><span class='translate' data-i18n="664" notes="Occupation"></label>
						</div>

						<div class="md-form">
							<input type="text" name="department" id="department" length="200" maxlength="200" class="form-control">
							<label for="department"><span class='translate' data-i18n="127" notes="Department"></label>
						</div>

						<div class="md-form">
							<input type="text" name="company" id="company" length="200" maxlength="200" class="form-control">
							<label for="company"><span class='translate' data-i18n="86" notes="Company"></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="involvement" id="involvement" class="select-single mobile-involvement-select" required>
							</select>
							<label for="involvement"><span class='translate' data-i18n="581" notes="Involvement"></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1742" notes="Instructions & Hints"></h6>

						<div class="my-4">
							<span class='translate' data-i18n="1743" notes="Please consider the following when completing your statement"></span>
							<small>
								<ul>
									<li> <span class='translate' data-i18n="1744" notes="What were you doing before the incident occurred?"></li>						
									<li> <span class='translate' data-i18n="1745" notes="Who was with you when the incident occurred?"></li>
									<li> <span class='translate' data-i18n="1746" notes="What equipment/tools were involved when the incident occurred?"></li>
									<li> <span class='translate' data-i18n="1747" notes="In your own words what took place during the incident?"></li>
									<li> <span class='translate' data-i18n="1748" notes="Did anything such as equipment/tools or other objects contribute to the incident?"></li>
									<li> <span class='translate' data-i18n="1749" notes="What are the environmental conditions? (cold, hot, wet, slippery, windy, dust, noise etc.)"></li>
									<li> <span class='translate' data-i18n="1750" notes="Was this work in your line up?"></li>
									<li> <span class='translate' data-i18n="1751" notes="Did you have the proper training for the task you were performing?"></li>
									<li> <span class='translate' data-i18n="1752" notes="Did you have the proper PPE at the time?"></li>
									<li> <span class='translate' data-i18n="1753" notes="In your own opinion what could have prevented this incident from occurring?"></li>
								</ul>
							</small>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1754" notes="Statement Summary"></h6>

						<div class="md-form">
							<textarea name="worker_statement" id="worker_statement" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="worker_statement"><span class='translate' data-i18n="956" notes="Worker Statement"></label>
						</div>

						<div class="form-group photoImage" id="general_photos"> 
							<label class="d-block"><span class='translate' data-i18n="1413" notes="Include Photos"></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="ADD IMAGES"></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></small>
							<div class="row photoGallery" id="galleryid"></div>
						</div>

                        <div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="955" notes="Worker Signature"></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='signature'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></div>
							</div>
							<img id='signature_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature" id="signature" class='modalSignature' value='' required>
							<input type="hidden" name="vector_employee" id='vector_employee' value=''>
							<input type="hidden" name="signature_comments" id='signature_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_img_time" id="signature_img_time" notes='signature_img_time' readonly/></small>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>
						<input type="hidden" name="formname" id="formname" tag="2173" class = "trans_input" value="2173" />
						<input type="hidden" name="formtype" id="formtype" value="SUP" />
						<input type="hidden" name="formid" id="formid" value="372308" />
						<input type="hidden" name="version" id="version" value="1" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
						
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');

			return true;
		}	
	}
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
