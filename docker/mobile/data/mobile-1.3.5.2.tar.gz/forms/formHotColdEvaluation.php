<?php	
  $strPageTitle = 'Hot / Cold Evaluation';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary"><span class='translate' data-i18n='1232' notes='Hot / Cold Evaluation'></span></h6>

          <div class="pt-1 position-relative my-4">
            <select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
            </select>
            <label for="draft"><span class='translate' data-i18n='1474' notes='Form Drafts'></span></label>
          </div>

          <form name="hotColdEvaluation" id="hotColdEvaluation" class="needs-validation" method="GET" action="#" novalidate>
          
						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1665' notes='Inspection'></span></h6>

						<div class="md-form">
							<input type="text" name="evaluation_time" id="evaluation_time" class="form-control timepicker" required>
							<label for="evaluation_time"><span class='translate' data-i18n='463' notes='Evaluation Time'></span></label>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='464' notes='Evaluation Type'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="evaluation_type_hot" name="evaluation_type" value="1666" required>
								<label class="form-check-label mr-2" for="evaluation_type_hot"><span class='translate' data-i18n='1666' notes='Hot'></span></label>

								<input type="radio" class="form-check-input" id="evaluation_type_cold" name="evaluation_type" value="1667">
								<label class="form-check-label mr-2" for="evaluation_type_cold"><span class='translate' data-i18n='1667' notes='Cold'></span></label> 
							</div>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="workers_present" id="workers_present" class="select-multiple mobile-employee-select" multiple>
							</select>
							<label for="workers_present"><span class='translate' data-i18n='958' notes='Workers Present'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1668' notes='Measurements'></span></h6>

						<!-- <a id='hotColdChart'>
							<img src="<?php echo _RESOURCEDOMAIN; ?>/img/temperature_reference_chart.jpg" alt="Temperature Reference Chart" class="img-fluid mx-auto d-block" />
						</a> -->
						<h5><span class='translate' data-i18n='4094' notes='Quick Reference - Work Rest Regimen - Using Wet Bulb Temp Readings'></span></h5>
						<div class="table-responsive text-wrap mb-3">
							<table class="w-100 table-sm table-bordered">
								<thead>
									<tr>
										<th></th>
										<th colspan="4" class="text-center"><span class='translate' data-i18n='4315' notes='Work Demands'></span></th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<th><span class='translate' data-i18n='4095' notes='Work Per Hour (%)'></span></th>
										<th><span class='translate' data-i18n='3511' notes='Light'></span></th>
										<th><span class='translate' data-i18n='1076' notes='Moderate'></span></th>
										<th><span class='translate' data-i18n='3512' notes='Heavy'></span></th>
										<th><span class='translate' data-i18n='3513' notes='Very Heavy'></span></th>
									</tr>
									<tr>

										<td>
											<span class='translate' data-i18n='4096' notes='100% Work Permitted'></span>
										</td>
										<td>
											29.5°C
										</td>
										<td>
											27.5°C
										</td>
										<td>
											26°C
										</td>
										<td>
											---
										</td>
									</tr>
									<tr>
		
										<td>
											75% <span class='translate' data-i18n='4097' notes='Work'></span>, 25% <span class='translate' data-i18n='4098' notes='Rest'></span>
										</td>
										<td>
											30.5°C
										</td>
										<td>
											28.5°C
										</td>
										<td>
											27.5°C
										</td>
										<td>
											---
										</td>
									</tr>
									<tr>
					
										<td>
											50% <span class='translate' data-i18n='4097' notes='Work'></span>, 50% <span class='translate' data-i18n='4098' notes='Rest'></span>
										</td>
										<td>
											31.5°C
										</td>
										<td>
											29.5°C
										</td>
										<td>
											28.5°C
										</td>
										<td>
											27.5°C
										</td>
									</tr>
									<tr>
								
										<td>
											25% <span class='translate' data-i18n='4097' notes='Work'></span>,75% <span class='translate' data-i18n='4098' notes='Rest'></span>
										</td>
										<td>
											32.5°C
										</td>
										<td>
											31.0°C
										</td>
										<td>
											30.0°C
										</td>
										<td>
											29.5°C
										</td>
									</tr>
									<tr>
								
										<td>
											<span class='translate' data-i18n='4099' notes='No Work Advised'></span>
										</td>
										<td>
											33.0°C
										</td>
										<td>
											32.0°C
										</td>
										<td>
											31.0°C
										</td>
										<td>
											30.0°C
										</td>
									</tr>
								</tbody>
							</table>
						</div>
						<h5><span class='translate' data-i18n='4100' notes='Quick Reference - Web Bulb Temperature Chart'></span></h5>
						<div class="table-responsive text-wrap mb-3">
							<table class="w-100 table-sm table-bordered">
								<thead>
									<tr>
										<th ></th>
										<th colspan="12"><span class='translate' data-i18n='4102' notes='Relative Humidity in %'></span></th>
									</tr>
								</thead>
								<tbody>
									<tr>

										<th><span class='translate' data-i18n='4101' notes='Dry Bulb Temp (°C)'></span></th>
										<td>45</td>
										<td>50</td>
										<td>55</td>
										<td>60</td>
										<td>65</td>
										<td>70</td>
										<td>75</td>
										<td>80</td>
										<td>85</td>
										<td>90</td>
										<td>95</td>
										<td>100</td>
									</tr>
									<tr>	

										<td>40.0
										</td>
										<td class="danger-color-dark text-white">29.4
										</td>									
										<td class="danger-color-dark text-white">30.6
										</td>
										<td class="danger-color-dark text-white">31.7
										</td>
										<td class="danger-color-dark text-white">32.7
										</td>	
										<td class="danger-color-dark text-white">33.8
										</td>
										<td class="danger-color-dark text-white">34.8
										</td>
										<td class="danger-color-dark text-white">35.7
										</td>
										<td class="danger-color-dark text-white">
										</td>
										<td class="danger-color-dark text-white">
										</td>
										<td class="danger-color-dark text-white">
										</td>
										<td class="danger-color-dark text-white">
										</td>
										<td class="danger-color-dark text-white">
										</td>
									</tr>		
									<tr>	
										<td>37.5
										</td>
										<td class="warning-color-dark text-white">27.4
										</td>									
										<td class="warning-color-dark text-white">28.5
										</td>
										<td class="warning-color-dark text-white">29.5
										</td>
										<td class="warning-color-dark text-white">30.6
										</td>	
										<td class="warning-color-dark text-white">31.5
										</td>
										<td class="danger-color-dark text-white">32.5
										</td>
										<td class="danger-color-dark text-white">33.4
										</td>
										<td class="danger-color-dark text-white">34.3
										</td>
										<td class="danger-color-dark text-white">35.1
										</td>
										<td class="danger-color-dark text-white">35.9
										</td>
										<td class="danger-color-dark text-white">
										</td>
										<td class="danger-color-dark text-white">
										</td>
									</tr>
									<tr>	

										<td>35.0
										</td>
										<td class="success-color-dark text-white">25.4
										</td>									
										<td class="success-color-dark text-white">26.4
										</td>
										<td class="warning-color-dark text-white">27.4
										</td>
										<td class="warning-color-dark text-white">28.4
										</td>	
										<td class="warning-color-dark text-white">29.3
										</td>
										<td class="warning-color-dark text-white">30.2
										</td>
										<td class="warning-color-dark text-white">31.1
										</td>
										<td class="danger-color-dark text-white">31.9
										</td>
										<td class="danger-color-dark text-white">32.7
										</td>
										<td class="danger-color-dark text-white">35.5
										</td>
										<td class="danger-color-dark text-white"d>34.4
										</td>
										<td class="danger-color-dark text-white">35.0
										</td>
									</tr>
									<tr>	

										<td>32.5
										</td>
										<td class="success-color-dark text-white">23.4
										</td>									
										<td class="success-color-dark text-white">24.3
										</td>
										<td class="success-color-dark text-white">25.3
										</td>
										<td class="success-color-dark text-white">26.2
										</td>	
										<td class="warning-color-dark text-white">27.1
										</td>
										<td class="warning-color-dark text-white">27.1
										</td>
										<td class="warning-color-dark text-white">28.7
										</td>
										<td class="warning-color-dark text-white">29.5
										</td>
										<td class="warning-color-dark text-white">30.3
										</td>
										<td class="warning-color-dark text-white">31.1
										</td>
										<td class="warning-color-dark text-white">31.8
										</td>
										<td class="danger-color-dark text-white">32.5
										</td>
									</tr>
									<tr>	

										<td>30
										</td>
										<td class="success-color-dark text-white">21.4
										</td>									
										<td class="success-color-dark text-white">22.3
										</td>
										<td class="success-color-dark text-white">23.2
										</td>
										<td class="success-color-dark text-white">24.0
										</td>	
										<td class="success-color-dark text-white">24.8
										</td>
										<td class="success-color-dark text-white">25.6
										</td>
										<td class="success-color-dark text-white">26.4
										</td>
										<td class="warning-color-dark text-white">27.2
										</td>
										<td class="warning-color-dark text-white">27.9
										</td>
										<td class="warning-color-dark text-white">28.6
										</td>
										<td class="warning-color-dark text-white">29.3
										</td>
										<td class="warning-color-dark text-white">30.0
										</td>
									</tr>
									<tr>	

										<td>27.5
										</td>
										<td class="success-color-dark text-white">19.4
										</td>									
										<td class="success-color-dark text-white">20.2
										</td>
										<td class="success-color-dark text-white">21.1
										</td>
										<td class="success-color-dark text-white">21.9
										</td>	
										<td class="success-color-dark text-white">22.6
										</td>
										<td class="success-color-dark text-white">23.4
										</td>
										<td class="success-color-dark text-white">24.1
										</td>
										<td class="success-color-dark text-white">24.8
										</td>
										<td class="success-color-dark text-white">25.5
										</td>
										<td class="success-color-dark text-white">26.2
										</td>
										<td class="warning-color-dark text-white">26.9
										</td>
										<td class="warning-color-dark text-white">27.5
										</td>
									</tr>

								</tbody>
							</table>
						</div>
						
						<table class="w-100 table-sm table-bordered">
							<tbody>
								<tr>
									<td class="success-color-dark px-4">
									</td>
									<td>
									<span class='translate' data-i18n='4103' notes='OK to Work'></span>
									</td>
								</tr>
								<tr>
									<td class="warning-color-dark px-4">
									</td>
									<td>
									<span class='translate' data-i18n='4104' notes='Caution - Evaluate the work demand at this temperature, self-pace and evaluate if work rest regimen is needed'></span>
									</td>
								</tr>
								<tr>
									<td class="danger-color-dark px-4">
									</td>
									<td>
									<span class='translate' data-i18n='4105' notes='Stop - Work is not advised at these temperatures without work/rest regimen established.'></span>
									</td>
								</tr>
							</tbody>



						</table>
						<div class="md-form">
							<input type="number" step="any" name="db_1" id="db_1" class="form-control" required>
							<label for="db_1"><span class='translate' data-i18n='183' notes='Dry Bulb (DB)'></span></label>
						</div>

						<div class="md-form">
							<input type="number" step="any" name="rh_1" id="rh_1" class="form-control" required>
							<label for="rh_1"><span class='translate' data-i18n='776' notes='Relative Humidity (RH)'></span></label>
						</div>

						<div class="md-form">
							<input type="number" step="any" name="wb_1" id="wb_1" class="form-control" required>
							<label for="wb_1"><span class='translate' data-i18n='921' notes='Wet Bulb (WB)'></span></label>
						</div>
					
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='904' notes='Was Worker Encouraged to Self-Pace?'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="encouraged_yes" name="encouraged" value="1" required>
								<label class="form-check-label mr-2" for="encouraged_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="encouraged_no" name="encouraged" value="0">
								<label class="form-check-label mr-2" for="encouraged_no"><span class='translate' data-i18n="1380" notes="No"></span></label> 
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='162' notes='Did Worker Have Water in the Work Area?'></span></label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="water_area_yes" name="water_area" value="1" required>
								<label class="form-check-label mr-2" for="water_area_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="water_area_no" name="water_area" value="0">
								<label class="form-check-label mr-2" for="water_area_no"><span class='translate' data-i18n="1380" notes="No"></span></label> 

								<input type="radio" class="form-check-input" id="water_area_na" name="water_area" value="-1">
								<label class="form-check-label mr-2" for="water_area_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="text-muted d-block"><span class='translate' data-i18n='611' notes='Is Work/Rest Required?'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="work_rest_yes" name="work_rest" value="1" required>
								<label class="form-check-label mr-2" for="work_rest_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="work_rest_no" name="work_rest" value="0">
								<label class="form-check-label mr-2" for="work_rest_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>
	<div class='cond-form-check-area'>
						<div class="pt-1 position-relative my-4">
							<select name="classification" id="classification" class="select-single mobile-classification-select">
							</select>
							<label for="classification"><span class='translate' data-i18n='940' notes='Work Classification'></span></label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="work_rest_established" id="work_rest_established" class="select-single mobile-workrest-select">
							</select>
							<label for="work_rest_established"><span class='translate' data-i18n='946' notes='Work Rest Regime Established'></span></label>
						</div>

						<div class="md-form">
							<textarea name="desc_work" id="desc_work" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="desc_work"><span class='translate' data-i18n='145' notes='Description of Work'></span></label>
						</div>
   </div>
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1669' notes='Person Conducting Readings'></span></h6>

						<div class="md-form">
							<input type="text" name="person_1" id="person_1" class="form-control" length="200" maxlength="200" required>
							<label for="person_1"><span class='translate' data-i18n='649' notes='Name'></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="device_1" id="device_1" class="form-control" length="200" maxlength="200" required>
							<label for="device_1"><span class='translate' data-i18n='643' notes='Measuring Device Serial #'></span></label>
						</div>

						<div class="md-form">
							<textarea name="corrective_1" id="corrective_1" class="form-control md-textarea" wrap="VIRTUAL"" required></textarea>
							<label for="corrective_1"><span class='translate' data-i18n='1670' notes='Correction of Work'></span></label>
						</div>

						<canvas id="canvas" style='display:none;'></canvas>
						
						<?php include 'includes/CommonFormFooter.php' ?>
						<input type="hidden" name="formname" id="formname" class = "trans_input" value="1023" tag="1023" />
						<input type="hidden" name="formtype" id="formtype" value="HR" />
						<input type="hidden" name="formid" id="formid" value="235063" />
						<input type="hidden" name="version" id="version" value="32" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript" src="/js/jquery.min.3.6.0.js"></script>
<script type="text/javascript" src="<?php echo _RESOURCEDOMAIN; ?>/js/popper.min.js"></script>
<script type="text/javascript">
    
	//  Event to clear values if Work/Rest Required is set to No.
    $('input[type=radio][name=work_rest]').change((data)=>{
		if(data.target.value == 0){
			$('#classification').val('').trigger('change').parent().find('label').removeClass('filled') 
			$('#work_rest_established').val('').trigger('change').parent().find('label').removeClass('filled') 
			$('#desc_work').val('').parent().find('label').removeClass('active filled')
		}
	})
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');

			if(theForm.formid.value == '')	{
				alert("There is an issue with form id");
				throw("Invalid form id");
				return false;
			}

			if(theForm.version.value == '')	{
				alert("There is an issue with form version");
				throw("Invalid version");
				return false;
			}

			return true;
		}	
	}

</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>