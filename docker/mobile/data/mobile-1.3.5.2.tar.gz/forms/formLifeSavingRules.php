<?php	
  $strPageTitle = 'Life Saving Rules';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
					<h6 class="text-secondary"><span class='translate' data-i18n="1445" notes="Life Saving Rules"></span></h6>

					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
						</select>
						<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
					</div>

					<form name="employeeDiscipline" id="employeeDiscipline" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="2687" notes="Instructions"></span></h6>
						<div>					
							<strong class='translate' data-i18n="2688" notes="Type of Employee"></strong>
							<span class='d-block mb-3'><strong class=' translate' data-i18n="2944" notes="Internal"></strong> - <span class='translate' data-i18n="2689" notes="Employee on company payroll"></span></span>
							<span class='d-block mb-3'><strong class=' translate' data-i18n="2690" notes="External"></strong> - <span class='translate' data-i18n="2691" notes="Consultant, Contractor, Agency employee, Volunteer, Visitor"></span></span>					
						</div> 	
						<div>
							<span class='d-block mb-3'><strong class=' translate' data-i18n="2692" notes="Number of offenses by this individual within a 3-year period."></strong><span class='translate' data-i18n="2693" notes="This approach implies no more than 3 offenses in a 3-year period by an individual. Please provide if it's the 1st, 2nd or 3rd one made by this person."></span></span>
							<span class='d-block mb-3'><strong class=' translate' data-i18n="2694" notes="Gross negligence (Yes/No)."></strong> - <span class='translate' data-i18n="2695" notes="Select Yes if the situation implies gross negligence and requires more severe response or punishment. Normally, Yes implies that the repercussion can be directly suspension or termination."></span></span>					
						</div> 	
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="2688" notes="Type of employee"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="employee_type_internal" name="employee_type" value="2944" required>
								<label class="form-check-label mr-2" for="employee_type_internal"><span class='translate' data-i18n="2944" notes="Internal"></span></label>

								<input type="radio" class="form-check-input trans_input" id="employee_type_external" name="employee_type"  value="2690">
								<label class="form-check-label mr-2" for="employee_type_external"><span class='translate' data-i18n="2690" notes="External"></span></label>
							</div>
						</div>							
						<div class="pt-1 position-relative my-4 d-none" id="employee_select_div">
							<select name="employee_name" id="employee_name" class="select-single mobile-employee-select-id-single"></select>
							<label for="employee_name"><span class='translate' data-i18n="190" notes="Employee"></span></label>
						</div>
						<div class="md-form d-none" id="employee_input_div">
							<input type="text" name="external_employee" id="external_employee" class="form-control" length="200" maxlength="200">
							<label for="external_employee"><span class='translate' data-i18n='190' notes='Employee'></span></label>
						</div>
						<div class="pt-1 position-relative my-4">
							<select name="rule_breaking" id="rule_breaking" class="select-multiple mobile-rule-breaking-select" multiple required>
							</select>
							<label for="rule_breaking"><span class='translate' data-i18n='2696' notes='Rule Breaking'></span></label>
							<div id="rule_breaking_other_div" class="md-form" style="display:none"><input type="text" name="rule_breaking_other" id="rule_breaking_other" class="form-control" length="200" maxlength="200">
							<label for="rule_breaking_other"><span class='translate' data-i18n='2701' notes='Other rules broken'></span></label></div>									
						</div>
						<div class="md-form">
							<textarea name="rule_breaking_description" id="rule_breaking_description" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="rule_breaking_description"><span class='translate' data-i18n="2702" notes="Description of rule breaking"></span></label>
						</div>

						<div class="form-group photoImage" id="situation_pictures"> 
								<label class="d-block"><span class='translate' data-i18n="2703" notes="Pictures of situation or environment"></span></label>
								<canvas id="canvas" style='display:none;'></canvas>
								<div class="btn-group d-flex" role="group">
									<div class="btn btn-block btn-outline-secondary file-field px-1">
										<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="Add Images"></span>
										<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
									</div>
								</div>
								<div id="siteHelp" class="form-text text-muted" ></div>
								<div class="row photoGallery" id="galleryid"></div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="2704" notes="Number of offense(s) by this individual on a 3-year period"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input trans_input" id="number_of_offences_1st" name="number_of_offences" value="2705" required>
								<label class="form-check-label mr-2" for="number_of_offences_1st"><span class='translate' data-i18n="2705" notes="1st"></span></label>

								<input type="radio" class="form-check-input trans_input" id="number_of_offences_2nd" name="number_of_offences" value="2706">
								<label class="form-check-label mr-2" for="number_of_offences_2nd"><span class='translate' data-i18n="2706" notes="2nd"></span></label>

								<input type="radio" class="form-check-input trans_input" id="number_of_offences_3rd" name="number_of_offences" value="2707">
								<label class="form-check-label mr-2" for="number_of_offences_3rd"><span class='translate' data-i18n="2707" notes="3rd"></span></label>
							</div>
						</div>	

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n="2708" notes="Gross negligence Y/N"></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="gross_negligence_yes" name="gross_negligence" value="1" required>
								<label class="form-check-label mr-2" for="gross_negligence_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

								<input type="radio" class="form-check-input" id="gross_negligence_no" name="gross_negligence" value="0">
								<label class="form-check-label mr-2" for="gross_negligence_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
							</div>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="sanction_type" id="sanction_type" class="select-multiple mobile-sanction-type-select" multiple required>
							</select>
							<label for="sanction_type"><span class='translate' data-i18n='2709' notes='Type of sanction'></span></label>
							<div id="sanction_type_other_div" class="md-form" style="display:none"><input type="text" name="sanction_type_other" id="sanction_type_other" class="form-control" length="200" maxlength="200">
							<label for="sanction_type_other"><span class='translate' data-i18n='2718' notes='Other types of sanctions'></span></label></div>									
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="1395" notes="Signatures"></span></h6>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="217" notes="Employee Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='signature_employee'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_employee_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_employee" id="signature_employee" class='modalSignature' value=''>
							<input type="hidden" name="vector_employee" id='vector_employee' value=''>
							<input type="hidden" name="signature_employee_comments" id='signature_employee_comments' class="sig_comment" value=''>
							<small class="form-text text-muted md-form d-none"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_employee_img_time" id="signature_employee_img_time" notes='signature_employee_img_time' readonly/></small>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="850" notes="Supervisor Signature"></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='signature_supervisor'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_supervisor_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_supervisor" id="signature_supervisor" class='modalSignature' value=''>
							<input type="hidden" name="vector_supervisor" id='vector_supervisor' value=''>
							<input type="hidden" name="signature_supervisor_comments" id='signature_supervisor_comments' class="sig_comment" value=''>
							<small class="form-text text-muted md-form d-none"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_supervisor_img_time" id="signature_supervisor_img_time" notes='signature_supervisor_img_time' readonly/></small>
						</div>

						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n="1487" notes="Superintendent or Manager Signature"></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='signature_manager'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
							</div>
							<img id='signature_manager_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="signature_manager" id="signature_manager" class='modalSignature' value='' >
							<input type="hidden" name="vector_manager" id='vector_manager' value=''>
							<input type="hidden" name="signature_manager_comments" id='signature_manager_comments' class="sig_comment" value=''>
							<small class="form-text text-muted md-form d-none"><input class="form-control form-control-sm border-0 text-center" type="text" name="signature_manager_img_time" id="signature_manager_img_time" notes='signature_manager_img_time' readonly/></small>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" tag="1445" class = "trans_input" value="1445"/>
						<input type="hidden" name="formtype" id="formtype" value="HR" />
						<input type="hidden" name="formid" id="formid" value="372428" />
						<input type="hidden" name="version" id="version" value="1" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript">

	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
			
			return true;
		}	
	}
</script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<script>
	$('#rule_breaking').change(function(e){
		$("#rule_breaking_other").prop('required',false)
			if(checkOther('rule_breaking', $(this).val())){
				$("#rule_breaking_other_div").show()
				$("#rule_breaking_other").prop('required',true)
			}else{
				$("#rule_breaking_other_div").hide()
				$("#rule_breaking_other").prop('required',false)
				$("#rule_breaking_other").val('').parent().find('label').removeClass('active filled')
			}
	})

	$('#sanction_type').change(function(e){
		$("#sanction_type_other").prop('required',false)
			if(checkOther('sanction_type', $(this).val())){
				$("#sanction_type_other_div").show()
				$("#sanction_type_other").prop('required',true)
			}else{
				$("#sanction_type_other_div").hide()
				$("#sanction_type_other").prop('required',false)
				$("#sanction_type_other").val('').parent().find('label').removeClass('active filled')
			}
	})

	$('#employee_type_internal').change(function(e){
		$('#employee_select_div').removeClass('d-none')
		$("#employee_name").prop('required',true)	
		$('#employee_input_div').addClass('d-none')	
		$("#external_employee").prop('required',false)
		$("#external_employee").val('')		
	});

	$('#employee_type_external').change(function(e){
		$('#employee_select_div').addClass('d-none')
		$("#employee_name").prop('required',false)
		$("#employee_name").val('')	
		$('#employee_input_div').removeClass('d-none')	
		$("#external_employee").prop('required',true)
	});

	function draftPreProcess(parsedJSON) {
		if(parsedJSON.employee_type=="Internal"){
			$('#employee_select_div').removeClass('d-none')
			$("#employee_name").prop('required',true)	
			$('#employee_input_div').addClass('d-none')	
			$("#external_employee").prop('required',false)
			$("#external_employee").val('')		
		}
		if(parsedJSON.employee_type=="External"){
			$('#employee_select_div').addClass('d-none')
			$("#employee_name").prop('required',false)
			$("#employee_name").val('')	
			$('#employee_input_div').removeClass('d-none')	
			$("#external_employee").prop('required',true)
		}
		}
</script>
