<?php	
  $strPageTitle = 'Procedure-PHR Audit';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary">Procedure-PHR Audit</h6>
          <div class="pt-1 position-relative my-4">
            <select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
            </select>
			<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
          </div>

          <form name="formPHRAudit" id="formPHRAudit" class="needs-validation" method="POST" action="#" novalidate>
          
						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4">Safety Audit</h6>

						<div class="pt-1 position-relative my-4">
							<select name="auditor" id="auditor" class="select-single mobile-supervisors-select" required>
							</select>
							<label for="auditor">Auditor</label>
						</div>

						<div class="md-form">
							<textarea name="description" id="description" class="form-control md-textarea" wrap="VIRTUAL" requied></textarea>
							<label for="description">Description</label>
						</div>

						<div class="md-form">
							<input type="text" name="reference_number" id="reference_number" class="form-control" length="200" maxlength="200">
							<label for="reference_number">Reference Number</label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="employee_present" id="employee_present" class="select-multiple mobile-employee-select" multiple required>
							</select>
							<label for="employee_present">Employees Present</label>
						</div>

						<div class="mb-4">
							<label class="d-block">Has the Auditor reviewed the procedure/PHR beforehand?</label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="auditor_review_yes" name="auditor_review" value="1" required>
								<label class="form-check-label mr-2" for="auditor_review_yes">Yes</label>

								<input type="radio" class="form-check-input" id="auditor_review_no" name="auditor_review" value="0">
								<label class="form-check-label mr-2" for="auditor_review_no">No</label>

								<input type="radio" class="form-check-input" id="auditor_review_na" name="auditor_review" value="-1">
								<label class="form-check-label mr-2" for="auditor_review_na">N/A</label>

							</div>
						</div>

						<div class="mb-4">
							<label class="d-block">Is the procedure/PHR specific to the work being performed?</label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="specific_work_yes" name="specific_work" value="1" required>
								<label class="form-check-label mr-2" for="specific_work_yes">Yes</label>

								<input type="radio" class="form-check-input" id="specific_work_no" name="specific_work" value="0">
								<label class="form-check-label mr-2" for="specific_work_no">No</label>

								<input type="radio" class="form-check-input" id="specific_work_na" name="specific_work" value="-1">
								<label class="form-check-label mr-2" for="specific_work_na">N/A</label>

							</div>
						</div>

						<div class="mb-4">
							<label class="d-block">Is the document available in the field</label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="available_field_yes" name="available_field" value="1" required>
								<label class="form-check-label mr-2" for="available_field_yes">Yes</label>

								<input type="radio" class="form-check-input" id="available_field_no" name="available_field" value="0">
								<label class="form-check-label mr-2" for="available_field_no">No</label>

								<input type="radio" class="form-check-input" id="available_field_na" name="available_field" value="-1">
								<label class="form-check-label mr-2" for="available_field_na">N/A</label>

							</div>
						</div>

						<div class="mb-4">
							<label class="d-block">Is the methodology accurate and apply to the work being performed</label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="accurate_yes" name="accurate" value="1" required>
								<label class="form-check-label mr-2" for="accurate_yes">Yes</label>

								<input type="radio" class="form-check-input" id="accurate_no" name="accurate" value="0">
								<label class="form-check-label mr-2" for="accurate_no">No</label>

								<input type="radio" class="form-check-input" id="accurate_na" name="accurate" value="-1">
								<label class="form-check-label mr-2" for="accurate_na">N/A</label>

							</div>
						</div>

						<div class="mb-4">
							<label class="d-block">Are the controls listed and effective</label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="controls_yes" name="controls" value="1" required>
								<label class="form-check-label mr-2" for="controls_yes">Yes</label>

								<input type="radio" class="form-check-input" id="controls_no" name="controls" value="0">
								<label class="form-check-label mr-2" for="controls_no">No</label>

								<input type="radio" class="form-check-input" id="controls_na" name="controls" value="-1">
								<label class="form-check-label mr-2" for="controls_na">N/A</label>

							</div>
						</div>

						<div class="mb-4">
							<label class="d-block">Have all the workers reviewed the procedure before doing the work</label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="employee_review_yes" name="employee_review" value="1" required>
								<label class="form-check-label mr-2" for="employee_review_yes">Yes</label>

								<input type="radio" class="form-check-input" id="employee_review_no" name="employee_review" value="0">
								<label class="form-check-label mr-2" for="employee_review_no">No</label>

								<input type="radio" class="form-check-input" id="employee_review_na" name="employee_review" value="-1">
								<label class="form-check-label mr-2" for="employee_review_na">N/A</label>

							</div>
						</div>

						<div class="mb-4">
							<label class="d-block">Are the requied tools/equipment listed available for the work being performed</label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="tool_listed_yes" name="tool_listed" value="1" required>
								<label class="form-check-label mr-2" for="tool_listed_yes">Yes</label>

								<input type="radio" class="form-check-input" id="tool_listed_no" name="tool_listed" value="0">
								<label class="form-check-label mr-2" for="tool_listed_no">No</label>

								<input type="radio" class="form-check-input" id="tool_listed_na" name="tool_listed" value="-1">
								<label class="form-check-label mr-2" for="tool_listed_na">N/A</label>

							</div>
						</div>

						<div class="mb-4">
							<label class="d-block">Was the training needs analysis completed?</label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="training_needs_yes" name="training_needs" value="1" required>
								<label class="form-check-label mr-2" for="training_needs_yes">Yes</label>

								<input type="radio" class="form-check-input" id="training_needs_no" name="training_needs" value="0">
								<label class="form-check-label mr-2" for="training_needs_no">No</label>

								<input type="radio" class="form-check-input" id="training_needs_na" name="training_needs" value="-1">
								<label class="form-check-label mr-2" for="training_needs_na">N/A</label>

							</div>
						</div>

						<div class="mb-4">
							<label class="d-block">Are the workers doing the work properly trained or have the qualifications required as listed??</label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="training_as_listed_yes" name="training_as_listed" value="1" required>
								<label class="form-check-label mr-2" for="training_as_listed_yes">Yes</label>

								<input type="radio" class="form-check-input" id="training_as_listed_no" name="training_as_listed" value="0">
								<label class="form-check-label mr-2" for="training_as_listed_no">No</label>

								<input type="radio" class="form-check-input" id="training_as_listed_na" name="training_as_listed" value="-1">
								<label class="form-check-label mr-2" for="training_as_listed_na">N/A</label>

							</div>
						</div>

						<div class="mb-4">
							<label class="d-block">If there are sub-contractors doing the work, have they reviewed the procedure/PHR?</label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="sub_contractors_yes" name="sub_contractors" value="1" required>
								<label class="form-check-label mr-2" for="sub_contractors_yes">Yes</label>

								<input type="radio" class="form-check-input" id="sub_contractors_no" name="sub_contractors" value="0">
								<label class="form-check-label mr-2" for="sub_contractors_no">No</label>

								<input type="radio" class="form-check-input" id="sub_contractors_na" name="sub_contractors" value="-1">
								<label class="form-check-label mr-2" for="sub_contractors_na">N/A</label>

							</div>
						</div>

						<div class="mb-4">
							<label class="d-block">Are there any opportunities to improve the Procedure/PHR?</label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="improve_opportunities_yes" name="improve_opportunities" value="1" required>
								<label class="form-check-label mr-2" for="improve_opportunities_yes">Yes</label>

								<input type="radio" class="form-check-input" id="improve_opportunities_no" name="improve_opportunities" value="0">
								<label class="form-check-label mr-2" for="improve_opportunities_no">No</label>

								<input type="radio" class="form-check-input" id="improve_opportunities_na" name="improve_opportunities" value="-1">
								<label class="form-check-label mr-2" for="improve_opportunities_na">N/A</label>

							</div>
						</div>

						<div class="mb-4">
							<label class="d-block">Could any of the work practices observed result in a loss?</label>
							<div class="form-check custom-radio pl-0 no-sub">
								<input type="radio" class="form-check-input" id="potential_loss_yes" name="potential_loss" value="1" required>
								<label class="form-check-label mr-2" for="potential_loss_yes">Yes</label>

								<input type="radio" class="form-check-input" id="potential_loss_no" name="potential_loss" value="0">
								<label class="form-check-label mr-2" for="potential_loss_no">No</label>

								<input type="radio" class="form-check-input" id="potential_loss_na" name="potential_loss" value="-1">
								<label class="form-check-label mr-2" for="potential_loss_na">N/A</label>
							</div>
						</div>

						<h6 class="text-secondary pt-4">Comments</h6>

						<div class="md-form">
							<textarea name="sts_feedback" id="sts_feedback" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="sts_feedback">STS Feedback</label>
						</div>

						<h6 class="text-secondary pt-4">Correction and Action Requirements</h6>
						<div class="mb-4">
							<label class="d-block">Were any areas of improvement identified?</label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input radio-check" id="any_areas_of_improvement_identified_yes" name="any_areas_of_improvement_identified" value="1" required>
								<label class="form-check-label mr-2" for="any_areas_of_improvement_identified_yes">Yes</label>

								<input type="radio" class="form-check-input radio-check" id="any_areas_of_improvement_identified_no" name="any_areas_of_improvement_identified" value="0">
								<label class="form-check-label mr-2" for="any_areas_of_improvement_identified_no">No</label>
							</div>
						</div>
						
						<canvas id="canvas" style='display:none;'></canvas>

<div class='cond-form-check-area'> 

						<div class="mb-4">
							<label class="d-block">Is a follow up required with the employee</label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="follow_up_with_the_employee_yes" name="follow_up_with_the_employee" value="1" required>
								<label class="form-check-label mr-2" for="follow_up_with_the_employee_yes">Yes</label>

								<input type="radio" class="form-check-input" id="follow_up_with_the_employee_no" name="follow_up_with_the_employee" value="0">
								<label class="form-check-label mr-2" for="follow_up_with_the_employee_no">No</label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block">Is a follow up required with the task</label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="follow_up_with_the_task_yes" name="follow_up_with_the_task" value="1" required>
								<label class="form-check-label mr-2" for="follow_up_with_the_task_yes">Yes</label>

								<input type="radio" class="form-check-input" id="follow_up_with_the_task_no" name="follow_up_with_the_task" value="0">
								<label class="form-check-label mr-2" for="follow_up_with_the_task_no">No</label>
							</div>
						</div>
</div>
						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="formname" id="formname" value="PROCEDURE-PHR AUDIT" />
						<input type="hidden" name="formtype" id="formtype" value="STS" />
						<input type="hidden" name="formid" id="formid" value="236765"/>
						<input type="hidden" name="version" id="version" value="12" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}	
	}

	function radioButtonCheck() {
		$('.radio-check').change((e) =>{
			requiredRadio(e.currentTarget.defaultValue)
		})
	};
	document.addEventListener('DOMContentLoaded', radioButtonCheck, false);
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>