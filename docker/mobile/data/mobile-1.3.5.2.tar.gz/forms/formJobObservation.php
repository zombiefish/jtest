<?php	
  $strPageTitle = 'Job Observation';
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
						<h6 class="text-secondary"><span class='translate' data-i18n='1025' notes='Job Observation'></span></h6>
						<div class="pt-1 position-relative my-4">
							<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
							</select>
							<label for="draft"><span class='translate' data-i18n='1474' notes='Form Drafts'></span></label>
						</div>

						<form name="TemplateForm" id="TemplateForm" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='766' notes='Reason'></span></h6>
						<div class="pt-1 position-relative my-4">
							<select name="reason" id="reason" class="select-single mobile-demoreason-select" required>
							</select>
							<label for="reason"><span class='translate' data-i18n='766' notes='Reason'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='19' notes='Activity Observed'></span></h6>
						<div class="md-form">
							<textarea name="activity_observed" id="activity_observed" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="activity_observed"><span class='translate' data-i18n='19' notes='Activity Observed'></span></label>
						</div>

						<div class="md-form">
							<input type="text" name="reference_number" id="reference_number" class="form-control" length="200" maxlength="200">
							<label for="reference_number"><span class='translate' data-i18n='775' notes='Reference Number'></span></label>
						</div>

						<div class="form-group photoImage" id="info_multiphoto"> 
						    <label class="d-block"><span class='translate' data-i18n='1413' notes='Include Photos'></span></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n='2340' notes='ADD IMAGES'></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n='1389' notes='Please take scene pictures from all perspectives'></span></small>
							<div class="row photoGallery" id="galleryid"></div>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="employees_observed" id="employees_observed" class="select-multiple mobile-employee-select" multiple required>
							</select>
							<label for="employees_observed"><span class='translate' data-i18n='1671' notes='Employees Observed'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='81' notes='Comments'></span></h6>

						<div class="md-form">
							<textarea name="positive_recognition" id="positive_recognition" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="positive_recognition"><span class='translate' data-i18n='81' notes='Comments'></span></label>
						</div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='1601' notes='Correction and Action Requirements'></span></h6>
					
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='915' notes='Were any areas of improvement identified?'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input radio-check" id="hazards_identified_yes" name="hazards_identified" value="1" required>
								<label class="form-check-label mr-2" for="hazards_identified_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input radio-check" id="hazards_identified_no" name="hazards_identified" value="0">
								<label class="form-check-label mr-2" for="hazards_identified_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

<div class='cond-form-check-area'> 
						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1602' notes='Is a follow up required with the employee'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="follow_up_with_the_employee_yes" name="employee_followup" value="1" required>
								<label class="form-check-label mr-2" for="follow_up_with_the_employee_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="follow_up_with_the_employee_no" name="employee_followup" value="0">
								<label class="form-check-label mr-2" for="follow_up_with_the_employee_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>

						<div class="mb-4">
							<label class="d-block"><span class='translate' data-i18n='1603' notes='Is a follow up required with the task'></span></label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="follow_up_with_the_task_yes" name="task_followup" value="1" required>
								<label class="form-check-label mr-2" for="follow_up_with_the_task_yes"><span class='translate' data-i18n='1379' notes='Yes'></span></label>

								<input type="radio" class="form-check-input" id="follow_up_with_the_task_no" name="task_followup" value="0">
								<label class="form-check-label mr-2" for="follow_up_with_the_task_no"><span class='translate' data-i18n='1380' notes='No'></span></label>
							</div>
						</div>
</div>

						<?php include 'includes/CommonFormFooter.php' ?>
						<input type="hidden" name="formname" id="formname" tag = "1025" class = "trans_input" value="1025" note="JOB OBSERVATION" />
						<input type="hidden" name="formtype" id="formtype" value="HR" />
						<input type="hidden" name="formid" id="formid" value="131097" />
						<input type="hidden" name="version" id="version" value="69" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>


<script type="text/javascript">

	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
			return true;
		}
	}	

	function radioButtonCheck() {
		$('.radio-check').change((e) =>{
			requiredRadio(e.currentTarget.defaultValue)
		})
	};
	document.addEventListener('DOMContentLoaded', radioButtonCheck, false);

</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>