<?php	
  $strPageTitle = 'A&M Shift Report';include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
					<h6 class="text-secondary"><span class='translate' data-i18n='3687' notes='A&M Shift Report'></span></h6>
					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
						</select>
						<label for="draft"><span class='translate' data-i18n='1474' notes='Form Drafts'></span></label>
					</div>

					<form name="a_m_shift_report" id="TemplateForm" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>

						<div class="md-form">
							<input type="text" name="client_contact_information" id="client_contact_information" class="form-control" length="200" maxlength="200" required>
							<label for="client_contact_information"><span class='translate' data-i18n='3688' notes='Client Contact Information'></span></label>
						</div>
					
						<div class="my-4">
							<label class="text-muted"><span class='translate' data-i18n='3689' notes='Client Contact Signature'></span></label>
							<div class="btn-group d-flex" role="group" aria-label="Action subforms">
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='client_contact_signature'><i class="fa fa-pen"></i> <span class='translate' data-i18n='1396' notes='Sign'></span></div>
								<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
								<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n='1422' notes='Clear'></span></div>
							</div>
							<img id='client_contact_signature_img' src='' class='signatureImage d-block pt-2'/>
							<input type="hidden" name="client_contact_signature" id="client_contact_signature" class='modalSignature' value='' required>
							<input type="hidden" name="vector_signature" id='vector_signature' value=''><input type="hidden" name="client_contact_signature_comments" id='client_contact_signature_comments' class="sig_comment" value=''>
							<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="client_contact_signature_img_time" id="client_contact_signature_img_time" notes='client_contact_signature_img_time' readonly/></small>
						</div>

						<div class="md-form">
							<input type="text" name="safety_topic" id="safety_topic" class="form-control" length="200" maxlength="200" required>
							<label for="safety_topic"><span class='translate' data-i18n='815' notes='Safety Topic'></span></label>
						</div>

						<h6 class="text-secondary"><span class='translate' data-i18n='820' notes='Shift'></span></h6>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="shift_days" name="shift" tag="1095" value="1095" notes="Days" required>
								<label class="form-check-label mr-2" for="shift_days"><span class='translate' data-i18n='1095' notes='Days'></span></label>

								<input type="radio" class="form-check-input" id="shift_nights" name="shift" tag="1375" value="1375" notes="Nights">
								<label class="form-check-label mr-2" for="shift_nights"><span class='translate' data-i18n='1375' notes='Nights'></span></label> 
							</div>

						<canvas id="canvas" style='display:none;'></canvas>
						
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='3691' notes='Tasks'></span></h6>
						<div id="crews"></div>
						<!--  Buttons for Add and Remove Shifts-->
						<div id='addCrew' class='btn btn-sm btn-primary'><i class="fa fa-plus"></i> <span class='translate' data-i18n='2481' notes='ADD TASK'></span></div>
						<div id='removeCrew' class='btn btn-sm btn-outline-primary'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n='2482' notes='REMOVE TASK'></span></div>

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='3696' notes='Input / Output'></span></h6>
							<div id="locations"></div>
							<!--  Buttons for Add and Remove Shifts-->
							<div id='addLocation' class='btn btn-sm btn-primary'><i class="fa fa-plus"></i> <span class='translate' data-i18n='3699' notes='ADD LOCATION'></span></div>
							<div id='removeLocation' class='btn btn-sm btn-outline-primary'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n='3700' notes='REMOVE LOCATION'></span></div>
							<p>
								<div id="total_collections">
									<label id="total_collections"><strong><span class='translate' data-i18n='3701' notes='Total Collections and Deliveries'></span></strong></label>
								</div>
							</p>

							<div class="md-form">
								<textarea name="comments" id="comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="comments"><span class='translate' data-i18n='81' notes='Comments'></span></label>
							</div>

							<div class="md-form">
								<textarea name="delays_and_additional_details" id="delays_and_additional_details" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
								<label for="delays_and_additional_details"><span class='translate' data-i18n='3702' notes='Delays and Additional Details'></span></label>
							</div>

							<?php include 'includes/CommonFormFooter.php' ?>

							<input type="hidden" name="formname" id="formname" class = "trans_input" value="3687" tag="3687" tag="A&M SHIFT REPORT" />
							<input type="hidden" name="formtype" id="formtype" value="SR" />
							<input type="hidden" name="formid" id="formid" value="372408" />
							<input type="hidden" name="version" id="version" value="1" />
							<input type="hidden" name="_rev" id="_rev" value="" />
							<input type="hidden" name="_id" id="_id" value="" />
							<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
							<input type="hidden" name="draftField" id="draftField" value="draft" />
							<input type="hidden" name="numCrews" id="numCrews" value="1" />
							<input type="hidden" name="totalCrews" id="totalCrews" value='15' />
							<input type="hidden" name="numLocation" id="numLocation" value="1" />
							<input type="hidden" name="totalLocations" id="totalLocations" value="25" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript">

	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');

			return true;
		}	
	}
</script>

<script>
$( document ).ready(function() {
		addCrew(1)
		addLocation(1)
	});

function addCrew(crewNum,mode){
	picName=String.fromCharCode(97 + parseInt(crewNum))
	const crewsModal = 
	`<div class="crewsection" value=${crewNum}>
		<h6 class="text-secondary pt-4"><span class='translate' data-i18n='2476' notes='Task'></span> ${crewNum}</h6>
		<div class="pt-1 position-relative my-4">
			<select name="task_contract_${crewNum}" id="task_contract_${crewNum}" class="select-single mobile-amtaskcontract-select" required>
			</select>
			<label for="task_contract_${crewNum}"><span class='translate' data-i18n='3692' notes='Task Contract'></span></label>
		</div>

		<div class="pt-1 position-relative my-4">
			<select name="task_type_${crewNum}" id="task_type_${crewNum}" class="select-single mobile-amtasktype-select" required>
			</select>
			<label for="task_type_${crewNum}"><span class='translate' data-i18n='8325' notes='Task Type'></span></label>
		</div>

		<div class="pt-1 position-relative my-4">
			<select name="attendees_${crewNum}" id="attendees_${crewNum}" class="select-multiple mobile-employee-select" multiple required>
			</select>
			<label for="attendees_${crewNum}"><span class='translate' data-i18n='8449' notes='Employees on Task'></span></label>
		</div>

		<div class="md-form">
			<input type="text" class="form-control timepicker" name="time_in_${crewNum}" id="time_in_${crewNum}"  onchange="checkTime(${crewNum})" required>
			<label for="time_in_${crewNum}"><span class='translate' data-i18n='2355' notes='Time In'></span></label>
		</div>
		<div class="md-form">
			<input type="text" class="form-control timepicker" name="time_out_${crewNum}" id="time_out_${crewNum}" onchange="checkTime(${crewNum})" required>
			<label for="time_out_${crewNum}"><span class='translate' data-i18n='2356' notes='Time Out'></span></label>
		</div>

		<p>
			<div id="total_area_${crewNum}">
				<label id="total_hours_${crewNum}"><strong><span class='translate' data-i18n='3695' notes='Shift length'></span></strong></label>
			</div>
		</p>
		<input type="hidden" name="shift_length_${crewNum}" id="shift_length_${crewNum}" value="" />
	</div>`
	
	$("#crews").append(crewsModal);
	if(crewNum>1 && !mode){
		initializeSelect2Dynamic(`task_contract_${crewNum}`)
		initializeSelect2Dynamic(`task_type_${crewNum}`)
		initializeSelect2Dynamic(`attendees_${crewNum}`)
		formHeader.populateAMTaskContractSelect(`task_contract_${crewNum}`)
		formHeader.populateAMTaskTypeSelect(`task_type_${crewNum}`)
		initializePickadate()
		try {$('.translate').localize()} catch {}
	}
	formHeader.populateEmployeeSelect(`attendees_${crewNum}`)	
}

	let locationSec = ''
	const totallocation = parseInt(document.getElementById('totalLocations').value)   
	document.getElementById('removeLocation').classList.add('d-none')


// add a location
document.getElementById('addLocation').addEventListener('click',(e)=>{
	locationSec = document.getElementById('numLocation').value
	if(locationSec < totallocation) {
		locationSec++
		addLocation(locationSec)
		if(locationSec === totallocation){
			document.getElementById('addLocation').classList.add('d-none')
		}
		document.getElementById('numLocation').value = locationSec
	} 
	if(locationSec > 1 && locationSec <= totallocation)
  	 document.getElementById('removeLocation').classList.remove('d-none')
})

function addLocation(numLocation,mode){
	locationName=String.fromCharCode(96 + parseInt(numLocation))	
	const locationsModal = 
	`<div class="locationsection" value=${numLocation}>	
		<h6 class="text-secondary pt-4"><span class='translate' data-i18n='629' notes='Location'></span> ${numLocation}</h6>
		<div class="pt-1 position-relative my-4">
			<select name="location_${numLocation}" id="location_${numLocation}" class="select-single mobile-amsupplieslocation-select" required>
			</select>
			<label for="location_${numLocation}"><span class='translate' data-i18n='629' notes='Location'></span></label>
		</div>

		<div class="pt-1 position-relative my-4">
			<select name="type_${numLocation}" id="type_${numLocation}" class="select-single mobile-amsuppliestype-select" required>
			</select>
			<label for="type_${numLocation}"><span class='translate' data-i18n='1054' notes='Type'></span></label>
		</div>

		<div class="md-form">
			<input type="number" min="0" onkeyup="if(this.value<0){this.value= this.value * -1}" step="any"  name="quantity_${numLocation}" id="quantity_${numLocation}" class="form-control" onchange="calculateTotalCollections(${numLocation})" required>
			<label for="quantity_${numLocation}"><span class='translate' data-i18n='3697' notes='Quantity'></span></label>
		</div>

		<div class="form-group photoImage" id="pictures_of_bin_at_location_${locationName}"> 
			<label class="d-block"><span class='translate' data-i18n='3698' notes='Pictures of Receptacles at Location'></span></label>
			<canvas id="canvasa_${numLocation}" style='display:none;'></canvas>
			<div class="btn-group d-flex" role="group">
				<div class="btn btn-block btn-outline-secondary file-field px-1">
					<i class="fa fa-upload"></i> <span class='translate' data-i18n='2340' notes='ADD IMAGES'></span>
					<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
				</div>
			</div>
			<div id="siteHelp" class="form-text text-muted" ></div>
			<div class="row photoGallery" id="galleryid${locationName}"></div>
		</div>
	</div>`
	
	$("#locations").append(locationsModal);
	if(numLocation>1 && !mode){
		initializeSelect2Dynamic(`location_${numLocation}`)
		initializeSelect2Dynamic(`type_${numLocation}`)	
		formHeader.populateAMSuppliesLocationSelect(document.getElementById("site"),`location_${numLocation}`)	
		formHeader.populateAMSuppliesTypeSelect(`type_${numLocation}`)	
		addImagePicker('pictures_of_bin_at_location_' + locationName)
		try {$('.translate').localize()} catch {}
	}
}

// remove a location 
document.getElementById('removeLocation').addEventListener('click',(e)=>{
	let myLocation = $(`.locationsection[value="${locationSec}"]`)
	myLocation.remove()
	loadedPhotos = $('.singleImage')
	for(loadedPhoto of loadedPhotos){
		if(loadedPhoto.id.includes('pictures_of_bin_at_location_' + locationName)){
			loadedPhoto.remove()
		}
	}
	locationSec--
	document.getElementById('numLocation').value = locationSec
	if(locationSec > 1 && locationSec <= totallocation)
	document.getElementById('removeLocation').classList.remove('d-none')
	document.getElementById('addLocation').classList.remove('d-none')
	if(locationSec >= totallocation)
	document.getElementById('addLocation').classList.add('d-none')
	if(locationSec === 1)
	document.getElementById('removeLocation').classList.add('d-none')
	calculateTotalCollections(locationSec)
})

// Populate the Form from a Draft by showing the sections activated in FormHandler
function populateLocationDynamicForm(numLocation,totalLocation) {
	$(`.locationsection`).remove()
	locationSec = numLocation
	if(locationSec > 1 && locationSec <= totallocation)
	document.getElementById('removeLocation').classList.remove('d-none')
	if(locationSec >= totallocation)
	document.getElementById('addLocation').classList.add('d-none')
	for (a = 1; a <= locationSec; a++) {
		addLocation(a,"loadDraft")
	}
}

//Return the calculated value. 
function checkTime(section){
	let hrs=document.getElementById("total_hours_" + section)
	let innerHTML="<strong>"+i18next.t('3695')+" "+" </strong>"  //Shift length
	if(document.getElementById("time_in_" + section).value){
		var timeIn = document.getElementById("time_in_" + section).value
	}
	if(document.getElementById("time_out_" + section).value)
	{
		var timeOut = document.getElementById("time_out_" + section).value
	}
	if(timeIn && timeOut) {
		shiftLength=calculateShiftLength(timeIn,timeOut)
		innerHTML = "<strong>"+i18next.t('3695')+" " + shiftLength + "</strong>" //Shift length
		document.getElementById("shift_length_" + section).value = shiftLength
	}
	hrs.innerHTML = innerHTML
}

function calculateShiftLength(timeIn,timeOut){
	timeInMinutes=convertMilitaryTime(timeIn)
	timeOutMinutes=convertMilitaryTime(timeOut)
	timeDifference=timeOutMinutes-timeInMinutes
	if(timeDifference<0){
		timeDifference=timeDifference+24*60
	}
	hoursShiftLengh=Math.floor(timeDifference/60)
	minsShiftLengh=timeDifference%60
	shiftLength=hoursShiftLengh + "h "+ minsShiftLengh+"m"
	return shiftLength
}

function convertMilitaryTime(timeStamp){
	amPM=timeStamp.substr(length-3)
	timeHour=Number(timeStamp.substr(0,2))
	timeMin=Number(timeStamp.substr(3,2))
	if(amPM=="AM" && timeHour==12){
		timeHour=0
	}
	if(amPM=="PM" && timeHour!=12){
		timeHour=timeHour+12
	}
	totalMinuites = timeHour * 60 + timeMin
	return totalMinuites

}

function calculateTotalCollections(locationSec){
	let gtotal = 0
	for (let i = 1; i <= locationSec; i++) {
		if(document.getElementById("quantity_" + i).value){
			quantity = document.getElementById("quantity_" + i).value
			gtotal += Number(quantity)			
		}
	}
	if(gtotal % 1 != 0){
		gtotal=parseFloat(gtotal).toFixed(2)
	}	
	document.getElementById("total_collections").innerHTML ="<strong>"+i18next.t('3701') +" " + gtotal + "</strong>"
}


function draftPostProcess(parsedJSON){
	numCrews=parseInt(parsedJSON['numCrews'])
	locationSec=parseInt(parsedJSON['numLocation'])
	calculateTotalCollections(locationSec)

	for(let i=1; i<=numCrews;i++){
		checkTime(i)
	}
}
</script>

<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>

