<?php	
  $strPageTitle = 'Employee Improvement Action';
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary">Employee Improvement Action</h6>

          <div class="pt-1 position-relative my-4">
            <label for="draft">Form Drafts</label>
            <select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
            </select>
          </div>

          <form name="TemplateForm" id="TemplateForm" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>

						<h6 class="text-secondary pt-4">Improvement Identification</h6>
						<div class="pt-1 position-relative my-4">
							<select name="employee" id="employee" class="select-single mobile-employee-select" required>
							</select>
							<label for="employee_name">Employee</label>
						</div>

						<div class="md-form">
							<textarea name="improvement_description" id="improvement_description" class="form-control md-textarea" wrap="VIRTUAL" length="1000" maxlength="4000" required></textarea>
							<label for="improvement_description">Improvement Description</label>
						</div>

						<div class="md-form">
							<textarea name="objective" id="objective" class="form-control md-textarea" wrap="VIRTUAL" length="1000" maxlength="4000" required></textarea>
							<label for="objective">Objective</label>
						</div>

						<div class="md-form">
							<textarea name="available_support" id="available_support" class="form-control md-textarea" wrap="VIRTUAL" length="1000" maxlength="4000" required></textarea>
							<label for="available_support">Available Support</label>
						</div>

						<h6 class="text-secondary pt-4">Actions Identification</h6>
						<div class="md-form">
							<textarea name="recommended_action" id="recommended_action" class="form-control md-textarea" wrap="VIRTUAL" length="1000" maxlength="4000" required></textarea>
							<label for="recommended_action">Recommended Action</label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="action_type" id="action_type" class="select-single" required>
								<?php echo GenList("REF_ActionTypeList", "Value", "Display", "", "Select Action Type", "","", "Display") ?>
							</select>
							<label for="action_type">Action Type</label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="action_by_who" id="action_by_who" class="select-single mobile-employee-select" required>
							</select>
							<label for="action_by_who">By Who</label>
						</div>

						<div class="md-form">
							<input type="text" name="action_by_when" id="action_by_when" class="form-control datepicker" required>
							<label for="action_by_when">By When</label>
						</div>

						<div class="mb-4">
							<label class="d-block">Action Status</label>
							<div class="form-check custom-radio pl-0">
								<input type="radio" class="form-check-input" id="action_status_incomplete" name="action_status" value="INCOMPLETE" required>
								<label class="form-check-label mr-2" for="action_status_incomplete">Incomplete</label>

								<input type="radio" class="form-check-input" id="action_status_complete" name="action_status" value="COMPLETE">
								<label class="form-check-label mr-2" for="action_status_complete">Complete</label>
							</div>
						</div>
                    <div class='cond-form-check-area'>
						<div class="pt-1 position-relative my-4">
							<select name="action_completed_by_who" id="action_completed_by_who" class="select-single mobile-employee-select" required>
							</select>
							<label for="action_completed_by_who">Completed By Who</label>
						</div>

						<div class="md-form">
							<input type="text" name="action_completed_date" id="action_completed_date" class="form-control datepicker">
							<label for="action_completed_date">Completed When</label>
						</div>

						<div class="md-form">
							<textarea name="completed_action_taken" id="completed_action_taken" class="form-control md-textarea" wrap="VIRTUAL" length="1000" maxlength="4000"></textarea>
							<label for="completed_action_taken">Completed Action Taken</label>
						</div>

						<div class="pt-1 position-relative my-4">
							<select name="completed_action_type" id="completed_action_type" class="select-single" required>
							<?php echo GenList("REF_ActionTypeList", "Value", "Display", "", "Select Action Type", "","", "Display") ?>								
							</select>
							<label for="completed_action_type">Completed Action Type</label>
						</div>

            <div class="form-group photoImage"> 
							<label class="d-block">Include Photos</label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div id="enablePhotoButton" class="btn btn-block btn-outline-secondary" onClick="capturePicture('canvas', 'completed_action_attachment', 'galleryid')">
                <i class="fa fa-images"></i> Take Photos
              </div>
							<small id="siteHelp" class="form-text text-muted">Please take scene pictures from all perspectives</small>
							<div class="row photoGallery" id="galleryid"></div>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type="hidden" name="completed_action_score" id="completed_action_score" value="" />
						<input type="hidden" name="formname" id="formname" value="EMPLOYEE IMPROVEMENT ACTION" />
						<input type="hidden" name="formtype" id="formtype" value="HR" />
						<input type="hidden" name="formid" id="formid" value="248842" />
						<input type="hidden" name="version" id="version" value="8" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="endFormTimeStamp" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<div id="output">
</div>

<script type="text/javascript">

	var formBody = {
		
		formInitialize: function (theForm)	{
			if(debug) console.log('formBody.formInitialize() called.');
		},
	
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},
		
		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		}		

	}
</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>