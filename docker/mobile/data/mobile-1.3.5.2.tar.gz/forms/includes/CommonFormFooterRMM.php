<script>
</script>
<!-- here -->
<div id="info"></div>
<div class="btn-group d-flex flex-wrap flex-sm-nowrap" role="group" aria-label="Action subforms">
	<a  id='hap-modal-rmm-open' class="my-2 m-sm-0 btn btn-sm btn-outline-primary col waves-effect px-1 flex-fill"><span class='translate' data-i18n="1999" notes="Hazard Action"></span><span class="col px-2 pb-0"><span class="badge badge-primary" id="ha"></span></span></a>
	<a  id='gen-modal-rmm-open' class="rounded-0 btn btn-sm btn-outline-primary col waves-effect px-1 flex-fill"><span class='translate' data-i18n="1039" notes="General Action"></span><span class="col px-2 pb-0"><span class="badge badge-primary" id="ga"></span></span></a>
</div>

<div class="btn-group d-flex mt-4 mb-2" role="group" aria-label="Form Actions">
  <button type="button" name="cancelForm" id="cancelForm" class="btn btn-primary px-1"><span class='translate' data-i18n="1257" notes="Cancel"></span></button>
  <div class="btn-group dropup flex-fill" role="group">
    <button class="btn w-100 btn-primary dropdown-toggle text-nowrap px-1" id='draftDropdown' type="button" data-toggle="dropdown"><span class='translate' data-i18n="1399" notes="Draft"></span></button>
    <div class="dropdown-menu dropdown-primary dropdown-menu-right">
      <button type="button" name="saveDraft" id="saveDraft" class="dropdown-item"><span class='translate' data-i18n="1400" notes="Save Draft"></span></button>
      <div name="reset" class="dropdown-item" style="display:none;"id="deleteDraft"><span class='translate' data-i18n="1408" notes="Delete Draft"></span></div>
    </div>
  </div>
  <button name="submitJRAForm" id="submitJRAForm" class="btn btn-primary text-nowrap px-1"><span class='translate' data-i18n="1315" notes="Submit"></span></button>
</div>

<input type="hidden" name="positive_identification_opportunities_identified" id="positive_identification_opportunities_identified" value="0">
<input type="hidden" name="hazards_identified" id="hazards_identified" value="0">
<input type="hidden" name="general_actions_identified" id="general_actions_identified" value="0">
<input type="hidden" name="email_form_report" id="email_form_report" value="">
<input type="hidden" id="windowHeight" value = "0">
<input type="hidden" id="windowWidth" value = "0">
<input type="hidden" name="formLanguage" id="formLanguage" value = "en">

<!--spinner for File upload-->

<div class="spinnerContainer remotespinnerContainer SWspinnerContainer " id='filespinner'>
  <div class="preloader-wrapper big active">
    <div class="spinner-layer spinner-blue-only">
      <div class="circle-clipper left">
        <div class="circle"></div>
      </div>
      <div class="gap-patch">
        <div class="circle"></div>
      </div>
      <div class="circle-clipper right">
        <div class="circle"></div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
	var childHandle = '';


(function () {
	document.getElementById('windowHeight').value = window.innerHeight
	document.getElementById('windowWidth').value = window.innerWidth
    var location = window.document.location;

    var preventNavigation = function () {
        var originalHashValue = location.hash;

        window.setTimeout(function () {
            location.hash = 'preventNavigation' + ~~ (9999 * Math.random());
            location.hash = originalHashValue;
        }, 0);
    };
})();

document.getElementById('filespinner').classList.add('d-none')

let formFooter = {
	formInitialize: function (theForm)	{
		openCacheData().then((rdata) =>{
			openSelectCacheData().then((rdata) =>{
				formHeader.populateActionTypeSelect()
				formHeader.populateHazardTypeSelect()
				formHeader.populateHazardIDSelect()
				formHeader.populateEmployeePositionSelect()
				formHeader.populateEmployeeOccupationSelect()
				formHeader.populateActionTypeScoreSelect()
				formHeader.populateInvolvementSelect()
				formHeader.populateWorkrestSelect()
				formHeader.populateHazardTopicSelect()
				formHeader.populatePotentialHazardsSelect()
				formHeader.populateLikelihoodSelect()
				formHeader.populateSeveritySelect()
				formFooter.populateFormSubmissionLanguage()

				localStorage.removeItem(`noinitialize`)
				
				initializePickadate()
				initializeI18N().then(() => {
					if (typeof addStepCategory === "function") {
						dragAndSort()
						addStepCategory('init')
					}

					populateDefaultValues(remoteData)

					draftCheck(window.location.pathname)

					if(!window.localStorage.getItem('refresh')) {
						$("#footerSpinner").addClass('d-none')
					}
				})
			})
		})
	},

	populateFormSubmissionLanguage: () => {
		document.getElementById('formLanguage').value = selectedLanguage
	},

	formTerminate: (theForm) => {
	//	console.log('formFooter.formTerminate() called.');
	},

	formValidate: function (theForm) {
		val = new SofvieValidation();
		err2 = val.materialRadioButtonValidationShowError();
			if(err2) {
				return true
			}
			else  {
				return false;
			}
	},

	redirectURL: function (theURL)	{
		if(document.forms[0].submissionId.value) {
		window.open(`${theURL}?submissionId=${document.forms[0].submissionId.value}`, '_blank')
		}
		else
			alert('Cannot reference subform, contact admin');
		
	},

	closeChild: function ()	{
		childHandle.close();
	}
}

	// Defunct Function  Can REmove
	function validateSelect2() {
		returnValue = true;
		// Validate the Select2 Drop Downs
		Array.from(document.getElementsByClassName(`select2-selection__rendered`)).forEach((data) => {
			if(data.id !== 'select2-draft-container')	{
				data.parentNode.style.backgroundRepeat = 'no-repeat'
				data.parentNode.style.backgroundPosition = `center right calc(2.25rem / 4)`
				data.parentNode.style.backgroundSize = `calc(2.25rem / 2) calc(2.25rem / 2)`
				if(data.innerText === '' ){
					data.parentNode.style.borderColor = '#dc3545'
					data.parentNode.style.backgroundImage = `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='%23dc3545' viewBox='-2 -2 7 7'%3e%3cpath stroke='%23d9534f' d='M0 0l3 3m0-3L0 3'/%3e%3ccircle r='.5'/%3e%3ccircle cx='3' r='.5'/%3e%3ccircle cy='3' r='.5'/%3e%3ccircle cx='3' cy='3' r='.5'/%3e%3c/svg%3E")`
					returnValue = false;
				} else {
					data.parentNode.style.borderColor = '#28a745'
					data.parentNode.style.backgroundImage = `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%2328a745' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e")`
				}
				data.parentNode.addEventListener('click', (e) => {
					data.parentNode.style.borderColor = 'inherit'
					data.parentNode.style.backgroundImage = `none`
					})
			}
		})
		// End for each
	 return returnValue
	}

	function countSubFormAttachments()	{
 		// Retrieve JSON list of saved form drafts
		//Get all matching drafts for this form name 
		rmmDbDraft.allDocs({
			include_docs: true,
			attachments: true,
			startkey: '',
			endkey: '\ufff0'
		}).then((result) => {
			let ele = document.getElementById('pos')
			let gaele = document.getElementById('ga')
			let haele = document.getElementById('ha')
			let countp = 0 ,counth = 0 ,countg = 0
			let subid=0
			subid =  $("#submissionId").val()
			for(row of result.rows){
				let id = ''
				// Get the formID, parse from the ID.
				id = row.id.substring(0, row.id.indexOf(' '))

				if(row.doc.submissionID === subid){
					// PID
					if (id === '166071') countp ++
					// GA
					if (id === '131200') countg ++
					// HA
					if (id === '131042') counth ++
				}
			}
			// if(countp>0) {ele.innerHTML = countp} else {ele.innerHTML = ''}
			if(counth>0) {haele.innerHTML = counth} else {haele.innerHTML = ''}
			if(countg>0) {gaele.innerHTML = countg} else {gaele.innerHTML = ''}
			
		}).catch((err) => {
			console.error(err)
		})
	}

	function modalDeleteDraft() {
		formModal = new SofvieModal()
		// initialize the Modal 
		formModal.setModalElements(`danger`, `modalTitle`, i18next.t('1408'))
		// Display the Warning Modal
		formModal.handleModal(`danger`)
		// create event listener for OK button
		$(`.modal-footer .confirm`).click(() => {
        	formModal.hideModal()       
			// Send request to submit form
			let url = new URL(window.location.href);
			let urldraftid = url.searchParams.get("draftid");
			draftID = $('#currentDraft').val()
			if(urldraftid)
			draftID = urldraftid
				rmmDbDraft.get(draftID).then(function(doc) {
					rmmDbDraft.remove(doc);
					setTimeout(function(){ window.history.back() }, 1000);
				});
		})
	}



</script>


