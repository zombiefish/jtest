<div class="pt-1 position-relative my-4">
	<select name="Report_Distribution1" id="Report_Distribution1" class="select-multiple select-default mobile-distribution-select" multiple >
	</select>
	<label for="Report_Distribution1"><span class='translate' data-i18n="166" notes="Distribution"><span></label>
</div>
<script>
</script>
<!-- here -->
<div id="info"></div>
<div class="btn-group d-flex flex-wrap flex-sm-nowrap" role="group" aria-label="Action subforms">
    <a  id='pos-modal-open'  class="rounded-0 btn btn-sm btn-outline-primary col waves-effect px-1 flex-fill"><span class='translate' data-i18n="751" notes="Positive Recognition"></span><span class="col px-2 pb-0"><span class="badge badge-primary" id="pos"></span></span></a>
	<a  id='hap-modal-open' class="my-2 m-sm-0 btn btn-sm btn-outline-primary col waves-effect px-1 flex-fill"><span class='translate' data-i18n="1999" notes="Hazard Action"></span><span class="col px-2 pb-0"><span class="badge badge-primary" id="ha"></span></span></a>
	<a  id='gen-modal-open' class="rounded-0 btn btn-sm btn-outline-primary col waves-effect px-1 flex-fill"><span class='translate' data-i18n="1039" notes="General Action"></span><span class="col px-2 pb-0"><span class="badge badge-primary" id="ga"></span></span></a>
</div>

<div id="formButtonGroup" class="btn-group d-flex mt-4 mb-2" role="group" aria-label="Form Actions">
  <button type="button" name="cancelForm" id="cancelForm" class="btn btn-primary px-1"><span class='translate' data-i18n="1257" notes="Cancel"></span></button>
  <div class="btn-group dropup flex-fill" role="group">
    <button class="btn w-100 btn-primary dropdown-toggle text-nowrap px-1" id='draftDropdown' type="button" data-toggle="dropdown"><span class='translate' data-i18n="1399" notes="Draft"></span></button>
    <div class="dropdown-menu dropdown-primary dropdown-menu-right">
      <button type="button" name="saveDraft" id="saveDraft" class="dropdown-item"><span class='translate' data-i18n="1400" notes="Save Draft"></span></button>
      <div name="reset" class="dropdown-item" style="display:none;"id="deleteDraft"><span class='translate' data-i18n="1408" notes="Delete Draft"></span></div>
    </div>
  </div>
  <button type="submit" name="submitForm" id="submitForm" class="btn btn-primary text-nowrap px-1"><span class='translate' data-i18n="1315" notes="Submit"></span></button>
</div>

<input type="hidden" name="positive_identification_opportunities_identified" id="positive_identification_opportunities_identified" value="0">
<input type="hidden" name="hazards_identified" id="hazards_identified" value="0">
<input type="hidden" name="general_actions_identified" id="general_actions_identified" value="0">
<input type="hidden" name="email_form_report" id="email_form_report" value="">
<input type="hidden" id="windowHeight" value = "0">
<input type="hidden" id="windowWidth" value = "0">
<input type="hidden" name="formLanguage" id="formLanguage" value = "en">

<!--spinner for File upload-->

<div class="spinnerContainer SWspinnerContainer" id='filespinner'>
  <div class="preloader-wrapper big active">
    <div class="spinner-layer spinner-blue-only">
      <div class="circle-clipper left">
        <div class="circle"></div>
      </div>
      <div class="gap-patch">
        <div class="circle"></div>
      </div>
      <div class="circle-clipper right">
        <div class="circle"></div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
	var childHandle = '';


(function () {
	document.getElementById('windowHeight').value = window.innerHeight
	document.getElementById('windowWidth').value = window.innerWidth
    var location = window.document.location;

    var preventNavigation = function () {
        var originalHashValue = location.hash;

        window.setTimeout(function () {
            location.hash = 'preventNavigation' + ~~ (9999 * Math.random());
            location.hash = originalHashValue;
        }, 0);
    };
})();

document.getElementById('filespinner').classList.add('d-none')
let formFooter = {
	formInitialize: (theForm) => {
		openCacheData().then((rdata) =>{
			openSelectCacheData().then((rdata) =>{
				formHeader.populateDurationSelect()
				formHeader.populateActionTypeSelect()
				formHeader.populateHazardTypeSelect()		
				formHeader.populateHazardIDSelect()	
				formHeader.populateRotationDaysSelect()
				formHeader.populateHoursSummarySelect()
				formHeader.populateEmployeePositionSelect()
				formHeader.populateEmployeeOccupationSelect()
				formHeader.populateActionTypeScoreSelect()
				formHeader.populatePotentialLossSelect()
				formHeader.populateDemoReasonSelect()		
				formHeader.populateTopicTypeSelect()
				formHeader.populatePreliminaryIncidentType()
				formHeader.populateEventShiftScheduleSelect()
				formHeader.populateIncidentTypesSelect()
				formHeader.populateTrainingAuditTypesSelect()
				formHeader.populateContextSelect()
				formHeader.populateContentSelect()
				formHeader.populateInspectionType()
				formHeader.populateClimateSelect()
				formHeader.populateClassificationSelect()
				formHeader.populateInvolvementSelect()
				formHeader.populateWorkrestSelect()
				formHeader.populateShiftSelect()
				formHeader.populatePreparationSelect()
				formHeader.populateTestingSelect()
				formHeader.populateKnowledgeSelect()
				formHeader.populateAuditTypeSelect()
				formHeader.populateRecordStatusSelect()
				formHeader.populateHazardTopicSelect()	
				formHeader.populateHotWorkTypeSelect()	
				formHeader.populateHotWorkHazardsSelect()	
				formHeader.populateDetermineControlsSelect()
				formHeader.populateSpecialPPEsSelect()
				formHeader.populateHighRiskPrecautionsSelect()
				formHeader.populateRetrievalEquipmentSelect()		
				formHeader.populateRetrievalSpecialPPESelect()		
				formHeader.populateHazardsPresentSelect()	
				formHeader.populateRescueTypeSelect()
				formHeader.populateCommunicationStrategySelect()
				formHeader.populateKeyContactsSelect()
				formHeader.populateAllEquipmentSelect()
				formHeader.populatePotentialHazardsSelect()
				formHeader.populateDetermineControlsEquipmentWHSelect()
				formHeader.populateWorkingAtHeightsSpecialPPESelect()
				formHeader.populateAMTaskContractSelect()
				formHeader.populateAMTaskTypeSelect()
				formHeader.populateAMSuppliesTypeSelect()
				formHeader.populateWorkCardTypeSelect()
				formHeader.populateWorkAccomplishedSelect()
				formHeader.populateRuleBreakingSelect()
				formHeader.populateSanctionTypeSelect()
				formHeader.populateServiceTypeSelect()
				formHeader.populateEquipmentStatusSelect()
				formHeader.populateInterventionTypeSelect()	
				formHeader.populateLotoEquipmentListSelect()			
				formHeader.populateDrillingTimeDelaysCodeSelect()
				formHeader.populateDrillingCodeSelect()
				formHeader.populateStatusCodeSelect()
				formHeader.populateDrillingLogCodeSelect()
				formHeader.populateDrillingBitSizeSelect()
				formHeader.populateDrillingMaterialUsedSelect()
				formHeader.populateTemperaturelistSelect()
				formFooter.populateFormSubmissionLanguage()	
                formHeader.populateLOTOStatusListSelect()
				
				// If Custom Form, no need to initilize here since Custom Forms have their own
				if(window.location.pathname != '/forms/formCustomForm.php' && !localStorage.getItem(`syncing`)) { 
					localStorage.removeItem(`noinitialize`)
					initializePickadate()
					initializeSelect2()
					initializeSignatures()
					initializeImagePickers()
					initializeI18N().then(() =>{
						if(form.formid.value=='372458'){   //daily drilling report
							dragAndSort()
						}
						draftCheck()	
						checkFormFieldVisibility()
					if(!window.localStorage.getItem('refresh')) {
						$("#footerSpinner").addClass('d-none')
					}
					})
				}
			})
		})
	},

	populateFormSubmissionLanguage: () => {
		document.getElementById('formLanguage').value = selectedLanguage
	},

	formTerminate: (theForm) => {
	//	console.log('formFooter.formTerminate() called.');
	},

	formValidate: function (theForm) {
		val = new SofvieValidation();
		err2 = val.materialRadioButtonValidationShowError();
			if(err2) {
				return true
			}
			else  {
				return false;
			}
	},

	redirectURL: function (theURL)	{
		if(document.forms[0].submissionId.value) {
		window.open(`${theURL}?submissionId=${document.forms[0].submissionId.value}`, '_blank')
		}
		else
			alert('Cannot reference subform, contact admin');
		
	},

	closeChild: function ()	{
		childHandle.close();
	}
}

	// Defunct Function  Can REmove
	function validateSelect2() {
		returnValue = true;
		// Validate the Select2 Drop Downs
		Array.from(document.getElementsByClassName(`select2-selection__rendered`)).forEach((data) => {
			if(data.id !== 'select2-draft-container')	{
				data.parentNode.style.backgroundRepeat = 'no-repeat'
				data.parentNode.style.backgroundPosition = `center right calc(2.25rem / 4)`
				data.parentNode.style.backgroundSize = `calc(2.25rem / 2) calc(2.25rem / 2)`
				if(data.innerText === '' ){
					data.parentNode.style.borderColor = '#dc3545'
					data.parentNode.style.backgroundImage = `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='%23dc3545' viewBox='-2 -2 7 7'%3e%3cpath stroke='%23d9534f' d='M0 0l3 3m0-3L0 3'/%3e%3ccircle r='.5'/%3e%3ccircle cx='3' r='.5'/%3e%3ccircle cy='3' r='.5'/%3e%3ccircle cx='3' cy='3' r='.5'/%3e%3c/svg%3E")`
					returnValue = false;
				} else {
					data.parentNode.style.borderColor = '#28a745'
					data.parentNode.style.backgroundImage = `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%2328a745' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e")`
				}
				data.parentNode.addEventListener('click', (e) => {
					data.parentNode.style.borderColor = 'inherit'
					data.parentNode.style.backgroundImage = `none`
					})
			}
		})
		// End for each
	 return returnValue
	}

	function countSubFormAttachments()	{
 		// Retrieve JSON list of saved form drafts
		//Get all matching drafts for this form name 
		dbDraft.allDocs({
			include_docs: true,
			attachments: true,
			startkey: '',
			endkey: '\ufff0'
		}).then((result) => {
			let ele = document.getElementById('pos')
			let gaele = document.getElementById('ga')
			let haele = document.getElementById('ha')
			let countp = 0 ,counth = 0 ,countg = 0
			let subid=0
			subid =  $("#submissionId").val()
			for(row of result.rows){
				let id = ''
				// Get the formID, parse from the ID.
				id = row.id.substring(0, row.id.indexOf(' '))

				if(row.doc.submissionID === subid){
					// PID
					if (id === '166071') countp ++
					// GA
					if (id === '131200') countg ++
					// HA
					if (id === '131042') counth ++
				}
			}
			if(countp>0) {ele.innerHTML = countp} else {ele.innerHTML = ''}
			if(counth>0) {haele.innerHTML = counth} else {haele.innerHTML = ''}
			if(countg>0) {gaele.innerHTML = countg} else {gaele.innerHTML = ''}
			
		}).catch((err) => {
			console.error(err)
		})
	}

	function checkFormFieldVisibility() {
		
		if(remoteData[21].FormFieldVisibility === null || remoteData[21].FormFieldVisibility === undefined)
			return

		let formId = $("#formid").val()
		let formFieldVisibilityList = remoteData[21].FormFieldVisibility[formId]

		if(!formFieldVisibilityList)
			return

		if(debug)
			console.log("formFieldVisibilityList:", formFieldVisibilityList)

		for (let f = formFieldVisibilityList.length - 1; f >= 0 ; f--) {
            let field = document.getElementById(formFieldVisibilityList[f].fieldKey)

            if(field) {
				let parent = field.parentElement

				if(field.getAttribute("type") == "radio")
					parent = parent.parentElement

				if(!formFieldVisibilityList[f].ffv_is_visible) {
					parent.remove()
					if(debug)
						console.log(`Field Removed (${formFieldVisibilityList[f].fieldKey}):`, parent)
				}
            }
		}

		let sectionTitles = document.getElementsByClassName("text-secondary")
		for (let s = sectionTitles.length - 1; s >= 0; s--) {
            // Get next previous sibling element that is not hidden
		    let nextElementSibling = sectionTitles[s].nextElementSibling
            while(nextElementSibling && (nextElementSibling.classList.contains("d-none") || nextElementSibling.style.display == "none")) {
              	nextElementSibling = nextElementSibling.nextElementSibling
            }

            if(!nextElementSibling || nextElementSibling.classList.contains("text-secondary")) {
				if(debug)
              		console.log("Section Title Removed: ", sectionTitles[s])
				sectionTitles[s].remove()
            }
		}

	}

</script>


