<?php
  $submissionID = false;
	$submissionID = filter_input(INPUT_GET, 'submissionId', FILTER_SANITIZE_STRING);							// get passed submissionid from querystring
?>
<input type="hidden" id="currentDraft" value="" />
<input type="hidden" name="submissionId" id="submissionId" value="<?php echo $submissionID ?>" />
<input type="hidden" name="startFormTimeStamp" id="startFormTimeStamp" value="" />
<input type="hidden" name="endFormTimeStamp" id="endFormTimeStamp" value="" />
<input type="hidden" name="displayReferenceValue" id="displayReferenceValue" value="" />
<input type="hidden" name="submittedby" id="submittedby" value="" />
<input type="hidden" name="submittedby_name" id="submittedby_name" value="" />
<input type="hidden" id="hapChildExists" value="false" />
<input type="hidden" id="pidChildExists" value="false" />
<input type="hidden" id="gapChildExists" value="false" />

<div class="form-check ml-3 my-3 position-absolute" style="right: 20px; top:0;">
	<input type="checkbox" class="form-check-input ml-0" name="override" id="override" value = "" onClick="overrideLineup('click')">
	<label class="form-check-label pt-1" for="override"><span class='translate' data-i18n="8630" notes="Blank Card"></span></label> 
</div>

<div class="md-form"> 
  <input tabindex="1" type="text" name="date" id="date" class="form-control datepicker" data-value = "" value="Select date" required />
  <label for="date"><span class='translate' data-i18n="124" notes="Date"></span></label>
</div>

<div class="pt-1 position-relative my-4">
  <select name="site" id="site" class="select-single select-default"  onChange="populateChildSelects(this)" required >
  </select>
  <label for="site"><span class='translate' data-i18n="828" notes="Site"></span></label>
</div>

<div class="pt-1 position-relative my-4">
  <select name="supervisor" id="supervisor" class="select-single select-default form-control mobile-supervisor_id-select" onChange="getAllLineupLevels()" required>
  </select>
  <label for="supervisor"><span class='translate' data-i18n="844" notes="Supervisor"></span></label>
</div>

<div class="pt-1 position-relative my-4">
  <select name="job_number" id="job_number" class="select-single select-default" onChange="formHeader.populateLevelSelect(this)" required >
  </select>
  <label for="job_number"><span class='translate' data-i18n="617" notes="Job Number"></span></label>
</div>

<div class="pt-1 position-relative my-4">
  <select name="level" id="level" class="select-single select-default form-control lineupheader" onChange="workplaceHandler()" required>
  </select>
  <label for="level"><span class='translate' data-i18n="621" notes="Level"></span></label>
</div>

<div class="pt-1 position-relative my-4">
  <select name="lineup_workplace" id="lineup_workplace" class="select-single select-default lineupheader form-control" onChange="selectLineupWorkplace()" required>
  <option></option>
  <option class="translate trans_input" value="688" data-i18n="688" notes="Other"></option>
  </select>
  <label for="lineup_workplace"><span class='translate' data-i18n="959" notes="Workplace"></span></label>
</div>
<div class="md-form d-none" id='input_other_workplace'>
  <input type="text" name="other_workplace" id="other_workplace" class="form-control" length="200" maxlength="200" required/>
  <label for="other_workplace"><span class='translate' data-i18n="8491" notes="Other Workplace"></span></label>
</div>

<div class="md-form d-none">
	<input name="workplace" id="workplace" type='hidden'>
</div>

<h6 class="text-secondary pt-4"><span class='translate' data-i18n="820" notes="Shift"></span></h6>
<div class="form-check custom-radio pl-0">
	<input type="radio" class="form-check-input trans_input" id="shift_days" name="shift" value="1095" notes="Days" required>
	<label class="form-check-label mr-2" for="shift_days"><span class='translate' data-i18n="1095" notes="Days"></span></label>

	<input type="radio" class="form-check-input trans_input" id="shift_nights" name="shift" value="1375" notes="Nights">
	<label class="form-check-label mr-2" for="shift_nights"><span class='translate' data-i18n="1375" notes="Nights"></span></label> 
</div>

<h6 class="text-secondary pt-4"><span class='translate' data-i18n="8492" notes="Tasks to Do"></span></h6>
<div class="md-form">
	<textarea id="safety_topic" name="safety_topic" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
	<label for="safety_topic"><span class='translate' data-i18n="815" notes="Safety Topic"></span></label>
</div>

<div class="md-form">
	<textarea id="lineup_details" name="lineup_details" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
	<label for="lineup_details"><span class='translate' data-i18n="2097" notes="Details"></span></label> 
</div>
<div class="md-form">
	<textarea id="lineup_equipment" name="lineup_equipment" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	<label for="lineup_equipment"><span class='translate' data-i18n="428" notes="Equipment"></span></label>
</div>
<div class="md-form">
	<textarea id="lineup_ppe" name="lineup_ppe" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	<label for="lineup_ppe"><span class='translate' data-i18n="834" notes="Special PPE"></span></label> 
</div>	



<!-- Generate all of the lists and place them as hidden fields in the form -->

<script type="text/javascript">

	function pad(n){return n<10 ? '0'+n : n}

	var date = new Date()
	let selectedLineup = null
	let selectedWorkplace= null
	let lineupLevels = []
	let allWorkPlaces = []
	setTimeout(function(){
		if(!userLineupData.length) {
			document.getElementById('input_other_workplace').classList.remove('d-none')
			// document.getElementById('lineup_workplace').value = i18next.t("688")
			$('#lineup_workplace').val(i18next.t("688")).trigger('change')
			// document.getElementById('lineup_workplace').value = "other"
		}
	}, 3000)

	document.getElementById('date').setAttribute('data-value', `${moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD')}`)
	const _USERSETTINGSPROFILE = 32
	var selectedSiteHolder = '';
	localStorage.setItem(`noinitialize`,'true')

	populateChildSelects = (selectedSite) => {
		formHeader.populateJobSelect(selectedSite)
		formHeader.populateSupervisorIDSelect()
		formHeader.populateAMSuppliesLocationSelect(selectedSite)
	}

	function overrideLineup(mode) {
		$('#override').val(0)
		if(mode=='click'){
			if(document.getElementById('override').checked){
				$('#override').val(1)
			}
			else {
				$('#lineup_workplace').val("").trigger('change').parent().find('label').removeClass('filled active')
				$('#input_other_workplace').addClass('d-none')
			}
			clearLineupData()
		}
	}

	function getAllLineupLevels() {
		if(!document.getElementById('override').checked) {
			selectedLineup = null 
			selectedWorkplace = null
			supervisor = document.getElementById('supervisor').value
			allLevels = selectListData.ref_level || []
			site = document.getElementById('site').value
			date = document.getElementById('date').value
			jobNumber = document.getElementById('job_number').value	
			lineupLevelList = []
			lineupLevels = []
			allWorkPlaces = []
			if(!userLineupData.length) {
				$('#lineup_workplace').trigger('change').parent().find('label').addClass('filled active')
			}
			userLineupData.forEach((line) =>{
				if (parseInt(line.site) === parseInt(site) && parseInt(supervisor) === parseInt(line.supervisor) && parseInt(line.job_number) === parseInt(jobNumber)) {
					$('#input_other_workplace').addClass('d-none')
					selectedLineup = line
					line.workplace.forEach((wp)=>{
						allWorkPlaces.push(wp)
						wp.level.split('|').forEach((l)=>{
							if(!lineupLevelList.includes(l)) {
								lineupLevelList.push(l)
								lineupLevels.push(allLevels.find(obj => obj.rld_id == l))
							}
						})
					})
					// sort the Levels and populate the level Select
					lineupLevels.sort((a,b) => (a.rld_name > b.rld_name) ? 1 : ((b.rld_name > a.rld_name) ? -1 : 0))
					let optionData = '<option></option>'
					lineupLevels.forEach((d) => {
						optionData += `<option value="${d.rld_id}">${d.rld_name}</option>`
					})
					$('#level').empty().append(optionData)

					// autofil the Level if the is only one
					if(lineupLevelList.length == 1) {
						$('#level').val(parseInt(lineupLevelList[0])).trigger('change').parent().find('label').addClass('filled')
					}
					refreshSelect2()
				}
			})
		}
	}

	function workplaceHandler(level) {
		if(!document.getElementById('override').checked) {
			let wpsel = null
			let wpcount = 0
			selectedLevel = document.getElementById('level').value
			if(userLineupData.length) {
				if(selectedLevel){
					let wpSelect = `<option></option>`
					allWorkPlaces.forEach((wp)=> {
						if(wp.level.indexOf(selectedLevel) != -1){
							wpsel = wp.workplace_id
							wpcount++
							wpSelect += `<option value="${wp.workplace_id}">${wp.workplace_name}</option>`
						}
					})
					wpSelect += `<option value="${i18next.t('688')}">${i18next.t('688')}</option>`
					$('#lineup_workplace').empty().append(wpSelect)
					refreshSelect2()
					if(wpcount == 1) {
						$('#lineup_workplace').val(wpsel).trigger('change').parent().find('label').addClass('filled active')
						$('.translate').localize()
					}
				}
			}
		}
	}

	function selectLineupWorkplace() {
		workplaceVal = document.getElementById('lineup_workplace').value
		if(workplaceVal == i18next.t('688')){
			$('#lineup_workplace').removeAttr('required')
			$('#other_workplace').prop('required',true)
			$('#input_other_workplace').removeClass('d-none')
			$('#other_workplace').on('keyup', ()=>{
				document.getElementById('workplace').value = $('#other_workplace').val()	
			})
		}
		else {
			$('#input_other_workplace').addClass('d-none')
			$('#other_workplace').val('').parent().find('label').removeClass('active filled')
			$('#other_workplace').removeAttr('required')
			allWorkPlaces.forEach((wp)=>{
			if(wp.workplace_id == workplaceVal){
				selectedWorkplace = wp
				document.getElementById('workplace').value = selectedWorkplace.workplace_name
			}
		})
		// Handle the Shift Radio Buttons
		if(selectedLineup){
			selectedLineup.shift == 1375 ? document.getElementById('shift_nights').checked = true : document.getElementById('shift_days').checked = true
			insertLineupData()
		}
		}

	}

	function insertLineupData() {
		$('#safety_topic').val(selectedLineup.safety_topic).parent().find('label').addClass('filled active')
		$('#lineup_details').val(selectedWorkplace.work_details).parent().find('label').addClass('filled active')
		$('#lineup_equipment').val(selectedWorkplace.equipment).parent().find('label').addClass('filled active')
		$('#lineup_ppe').val(selectedWorkplace.ppe).parent().find('label').addClass('filled active')
	}

	function clearLineupData() {
		document.getElementById('shift_nights').checked = false
		document.getElementById('shift_days').checked = false
		let optionData = `<option></option>
							<option value='${i18next.t('688')}'>${i18next.t("688")}</option>`
		$('#lineup_workplace').empty().append(optionData)
		$('#lineup_workplace').val(i18next.t('688')).trigger('change').parent().find('label').addClass('filled active')
		$('#input_other_workplace').removeClass('d-none')
		if($('#site').val()){
			formHeader.populateLevelSelect($('#job_number')[0])
		}
		$('#safety_topic').val("").parent().find('label').removeClass('filled active')
		$('#lineup_details').val("").parent().find('label').removeClass('filled active')
		$('#lineup_equipment').val("").parent().find('label').removeClass('filled active')
		$('#lineup_ppe').val("").parent().find('label').removeClass('filled active')
	}

	var formHeader = {
		listsData : '' ,

		formInitialize: (theForm) => {
			// Populate submissionId
			if(!theForm.submissionId.value)
			openCacheData().then((rdata)=>{
				theForm.submissionId.value = formHeader.uuidv4();
				theForm.startFormTimeStamp.value = moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD HH:mm:ss')
				theDate = new DateUtils()
				theForm.date.value = theDate.formatCurrentDate('standard')
				openSelectCacheData().then(()=>{
					formHeader.populateSiteSelect(document.getElementById('site'))
					populateDefaultValues(remoteData, userSiteData)
				})
				document.getElementById('submittedby').value = remoteData[2].Employee[0].per_id
				document.getElementById('submittedby_name').value = remoteData[2].Employee[0].per_full_name
			})
		},
		
		formTerminate: (theForm) => {
			// Populate submissionId
			 theForm.endFormTimeStamp.value = moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD HH:mm:ss')
		},
		
		//Generate a cryptographically  unique guid.
		uuidv4 : () => {
		  return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
		    (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
		  )
		},
		
		populateSiteSelect: (theSelect)	=> {
			$('#site').empty().append('<option></option>')
			var opts = userSiteData
			$.each(opts, function(i, d) {
				$('#site').append(`<option value="${d.rld_id}" site="${d.rld_id}">${d.rld_name}</option>`)
			})
		},
		

		populateJobSelect: (selectedSite) => {
			let selectSiteHolder = null
			if(selectedSite.options[selectedSite.selectedIndex]) {
				selectSiteHolder = selectedSite.options[selectedSite.selectedIndex].getAttribute('site')
			}
			$('#job_number').parent().find('label').removeClass('active filled')
			$('#job_number').empty().append('<option></option>')
			// Parse the returned json data
			var opts = userJobData

			// Use jQuery's each to iterate over the opts value
			$.each(opts, function(i, d) {
				if(parseInt(d.rld_parent_detail_rld_id) == parseInt(selectSiteHolder) && parseInt(d.rld_is_active) == 1)
					{
						$('#job_number').append(`<option value="${d.rld_id}" site="${selectSiteHolder}" >${d.rld_code} - ${d.rld_name}</option>`)						
					}
			})

			distributionSelects = document.getElementsByClassName('mobile-distribution-select')
			if($('#job_number').val() == "") {
				for(let a=0; a <distributionSelects.length; a++) {
					$(distributionSelects[a]).empty()
				}
				return
			}
		},

		populateLevelSelect: (selectedJobNumber) =>	{
			let selectJobNumber = null
			formHeader.populateEmployeeSelect('level')
			formHeader.populateSupervisorIDSelect()
			formHeader.populateSupervisorSelect()
			formHeader.populateEmployeeSelectWithOther()
			formHeader.populateEmployeeSelectSingle('level')
			formHeader.populateEmployeeSelectID()
			formHeader.populateEmployeeModalSelect()
			formHeader.populateDistributionSelect()
			if(selectedJobNumber.options[selectedJobNumber.selectedIndex]) {
				selectJobNumber = selectedJobNumber.options[selectedJobNumber.selectedIndex].getAttribute('site')
			}
			
			$('#level').parent().find('label').removeClass('active filled')
			$('#level').empty().append('<option></option>')
			$('#levelendshift').parent().find('label').removeClass('active filled')
			$('#levelendshift').empty().append('<option></option>')
			// Parse the returned json data
			var opts = selectListData.ref_level || []
			$.each(opts, function(i, d) {
				if(d.rld_parent_detail_rld_id == selectJobNumber) {
					$('#level').append(`<option value="${d.rld_id}">${d.rld_name}</option>`)					
				if(document.getElementById('levelendshift')){
					$('#levelendshift').append(`<option value="${d.rld_name}">${d.rld_name}</option>`)					
				}
				}
			})
			getAllLineupLevels()
		},

		populateModalobSelect: (selectedSite) => {
					var modalJobs =selectListData.ref_job || []
					modalJobsSelects = document.getElementsByClassName('mobile-modaljobs')
					for(let a=0; a  < modalJobsSelects.length; a++) {
						let optionData = '<option></option>'
						modalJobs.forEach((data)=>{
							if(data[2] === selectedSite.value)
							optionData += `<option value="${data[0]}">${data[0]}</option>`
						 })
						 $(modalJobsSelects[a]).empty().append(optionData)
						 $(modalJobsSelects[a]).attr('site',selectedSite.value)
					}
		},

		populateModaLevelSelect: (selectedSite) => {
					var modalLevel =selectListData.ref_level || []
					modalLevelSelects = document.getElementsByClassName('mobile-modallevel')
					for(let a=0; a  < modalLevelSelects.length; a++) {
						let optionData = '<option></option>'
						modalLevel.forEach((data)=>{
							if(data[1] === selectedSite.getAttribute('site'))
							optionData += `<option value="${data[0]}">${data[0]}</option>`
						 })
						 $(modalLevelSelects[a]).empty().append(optionData)
					}
		},

		populateAllEquipmentSelect: () =>  {
			const lists = remoteData
			retrievalEquipmentTypeSelects = document.getElementsByClassName('mobile-equipment-select')
			mach = []
			if(lists[25]['PreOpEquipmentList']){
				lists[25]['PreOpEquipmentList'].forEach((data)=>{
					if(data.equipmentIdentifier!=null){
						mach.push({
							machineNumber: data.equipmentIdentifier,
							machineType: data.PreOpEquipmentID
						})
					}
				})
				let optionData=''
				if(mach.length > 0){
					mach.forEach((rec) =>{
						let machineName = getMachineName(rec.machineType)
						optionData += `<option value='${rec.machineNumber} ${machineName}'>${rec.machineNumber?rec.machineNumber:''} ${machineName}</option>`	
						})
				}
				for(let a = 0;a<retrievalEquipmentTypeSelects.length;a++){
					$(retrievalEquipmentTypeSelects[a]).append(optionData)
				}

				function getMachineName(type) {
					let mname = ''
					lists[23]['PreOpEquipment'].forEach((data)=>{
						if(data.PreOpEquipmentID === type) 
						mname = data.EquipDesc
					})
					return mname
				}	
			}
		},

		populateEquipmentLocationSelect: (selectedSite) => {
			var equipLocationLevels = selectListData.ref_level || []
			equipLocations = document.getElementsByClassName('mobile-equipmentlocation')
			let optionData = ``
			optionData += `<option value=""></option>`
			equipLocationLevels.forEach((data)=>{
				if(data.rld_parent_detail_rld_id === selectedSite){
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				}
			})
			for(let a=0; a <equipLocations.length; a++) {
				// Clear previous options
				equipLocations[a].innerHTML = ''
				$(equipLocations[a]).append(optionData)
			}
		},


		populateEmployeeSelect: () =>  {
			var employeelist = userEmployeeSelectData
			var user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'			
			var jobIDSelected = document.getElementById('job_number').value
			employeeSelects = document.getElementsByClassName('mobile-employee-select')
			for(let a=0; a <employeeSelects.length; a++) {
				let optionData = ``
				if(user_visibility == 'all'){
					// user visbility if all
					employeelist.forEach((data)=>{
						optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
					})
					$(employeeSelects[a]).empty().append(optionData)
				}
				else{
					// user visbility if not all
					employeelist.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs!== undefined && data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
							}
						}
					})
					$(employeeSelects[a]).empty().append(optionData)
				}
			}
		},

		populateEmployeeSelectSingle: () =>  {		
			var employeelist = userEmployeeSelectData
			var user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'			
			var jobIDSelected = document.getElementById('job_number').value
			employeeSelects = document.getElementsByClassName('mobile-employee-select-single')
			for(let a=0; a <employeeSelects.length; a++) {
				let optionData = `<option value=""></option>`
				if(user_visibility == 'all'){
					// user visbility if all
					employeelist.forEach((data)=>{					
						optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
					})
					$(employeeSelects[a]).empty().append(optionData)
				}
				else{
					// user visbility if not all
					employeelist.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs!== undefined && data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
							}  
						}
					})
					$(employeeSelects[a]).empty().append(optionData)
				}				
			}
		},

		populateEmployeeSelectWithOther:() => {
			var employeelist = userEmployeeSelectData
			var user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'			
			var jobIDSelected = document.getElementById('job_number').value
			employeeSelects = document.getElementsByClassName('mobile-employee-select-other')
			for(let a=0; a <employeeSelects.length; a++) {
				let optionData = ``
				employeelist.forEach((data)=>{
					optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
				})
				$(employeeSelects[a]).empty().append(optionData)
				$(employeeSelects[a]).append(`<option value = "Other">Other</option>`)
			}
			for(let a=0; a <employeeSelects.length; a++) {
				let optionData = ``

				if(user_visibility == 'all'){
					// user visbility if all
					employeelist.forEach((data)=>{
						optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
					})
					$(employeeSelects[a]).empty().append(optionData)
					$(employeeSelects[a]).append(`<option value = "Other">Other</option>`)

				}
				else{
					// user visbility if not all
					employeelist.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs!== undefined && data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
							}  
						}
					})
					$(employeeSelects[a]).empty().append(optionData)
					$(employeeSelects[a]).append(`<option value = "Other">Other</option>`)
				}				
			}
			
		},
		populateEmployeeSelectID: () =>  {
			var employeelist = userEmployeeSelectData
			var user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'			
			var jobIDSelected = document.getElementById('job_number').value			
			employeeSelects = document.getElementsByClassName('mobile-employee-select-id')
			for(let a=0; a <employeeSelects.length; a++) {
				let optionData = ``
				if(user_visibility == 'all'){
					// user visbility if all
					employeelist.forEach((data)=>{
						optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
					})
					$(employeeSelects[a]).empty().append(optionData)
				}
				else{
					// user visbility if not all
					employeelist.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs!== undefined && data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
							}  
						}
					})
					$(employeeSelects[a]).empty().append(optionData)
				}
			}
		},

		populateEmployeeModalSelect: () =>  {
			var employeelist = userEmployeeSelectData
			var user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'			
			var jobIDSelected = document.getElementById('job_number').value						
			employeeSelects = document.getElementsByClassName('modal-employee-select')
			for(let a=0; a <employeeSelects.length; a++) {
				let optionData = ``
				if(user_visibility == 'all'){
					// user visbility if all
					employeelist.forEach((data)=>{
						optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
					})
					$(employeeSelects[a]).empty().append(optionData)
				}
				else{
					// user visbility if not all
					employeelist.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
							}
						}
					})
					$(employeeSelects[a]).empty().append(optionData)
				}
			}
		},

		populateSupervisorSelect: () =>  {
			var supervisor_list = userSupervisorSelectData
			var user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'			
			var jobIDSelected = document.getElementById('job_number').value			
			superSelects = document.getElementsByClassName('mobile-supervisors-select')
			for(let a=0; a <superSelects.length; a++) {
				let optionData = `<option></option>`
				if(user_visibility == 'all'){
					supervisor_list.forEach((data)=>{
					optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
					})
					$(superSelects[a]).parent().find('label').removeClass('active filled')
					$(superSelects[a]).empty().append(optionData)
				}
				else{
					supervisor_list.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
							}
						}
					})
					$(superSelects[a]).parent().find('label').removeClass('active filled')
					$(superSelects[a]).empty().append(optionData)
				}
			}				
		},		

		populateSupervisorIDSelect: () =>  {
			var supervisor_list = userSupervisorSelectData
			var user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'
			var jobIDSelected = document.getElementById('job_number').value
			superSelects = document.getElementsByClassName('mobile-supervisor_id-select')
			let optionData = `<option></option>`
			for(let a=0; a <superSelects.length; a++) {
				$(superSelects[a]).parent().find('label').removeClass('active filled')
				if(user_visibility == 'all'){
					supervisor_list.forEach((data)=>{
						optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`						
					})		
					$(superSelects[a]).empty().append(optionData)
				}
				else{
					supervisor_list.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`							
						}
						else{
							if(data.employee_jobs!== undefined && data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`								
							}
						}
					})
					$(superSelects[a]).empty().append(optionData)
				}
			}	
		},	

		populateRotationDaysSelect: () =>  {
			var dorlist = selectListData.ref_days_of_rotation || []
					dorSelects = document.getElementsByClassName('mobile-daysofrotation-select')
					for(let a=0; a <dorSelects.length; a++) {
						let optionData = ``
						dorlist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(dorSelects[a]).empty().append(optionData)
					}
		},
		
		populateHoursSummarySelect: () =>  {
			var hslist = selectListData.ref_hours_summary || []
			hslist.sort((a,b) => (parseInt(a.rld_name) > parseInt(b.rld_name)) ? 1 : ((parseInt(b.rld_name) > parseInt(a.rld_name)) ? -1 : 0))
			hsSelects = document.getElementsByClassName('mobile-hourssummary-select')
					for(let a=0; a <hsSelects.length; a++) {
						let optionData = ``
						hslist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(hsSelects[a]).empty().append(optionData)
					}
		},

		populateEmployeePositionSelect: () =>  {
			var eplist = selectListData.ref_position || []
			epSelects = document.getElementsByClassName('mobile-employeeposition-select')
				for(let a=0; a < epSelects.length; a++) {
					let optionData = ``
					eplist.forEach((data)=>{
						optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						})
						$(epSelects[a]).empty().append(optionData)
				}
		},		

		populateEmployeeOccupationSelect: () =>  {
			var occlist = selectListData.ref_occupation || []
			occSelects = document.getElementsByClassName('mobile-employeeoccupation-select')
				for(let a=0; a < occSelects.length; a++) {
					let optionData = ``
					occlist.forEach((data)=>{
						optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						})
						$(occSelects[a]).empty().append(optionData)
				}
		},

		populateDurationSelect: () =>  {
			var durlist = selectListData.ref_duration || []
					durSelects = document.getElementsByClassName('mobile-duration-select')
					for(let a=0; a <durSelects.length; a++) {
						let optionData = ``
					  	durlist.forEach((data)=>{
							optionData += `<option value="${data.rld_code}">${data.rld_name}</option>`
						 })
						 $(durSelects[a]).empty().append(optionData)
					}
		},	

		populateDistributionSelect: () => {
			let external_group_distribution_list = selectListData.distributionList || []
			let distribution_list = userDistributionSelectData
			let user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'
			let jobIDSelected = document.getElementById('job_number').value
			distribution_list = distribution_list.concat(external_group_distribution_list)

			distributionGroupList=[]
			distributionSelects = document.getElementsByClassName('mobile-distribution-select')

			if($('#job_number').val() == "") {
				for(let a=0; a <distributionSelects.length; a++) {
					$(distributionSelects[a]).empty()
				}
				return
			}

			let collator = new Intl.Collator('en-ca');

			distribution_list.sort(function (a, b){
				return collator.compare(a.per_full_name, b.per_full_name)
			})
			for(let a=0; a <distributionSelects.length; a++) {
				let optionData = ``
				if(user_visibility == 'all'){
					distribution_list.forEach((data)=>{
						if(data.email.includes(',')){
							distributionGroupList.push(data)
						}
						optionData += `<option value="${data.email}">${data.per_full_name}</option>`
					})
					$(distributionSelects[a]).empty().append(optionData)
				}
				else{
					distribution_list.forEach((data)=>{	
						if(data.email.includes(',')){
							distributionGroupList.push(data)
						}
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.email}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs!== undefined &&  data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.email}">${data.per_full_name}</option>`
							}  
						}
					})
					$(distributionSelects[a]).empty().append(optionData)
				}						
			}			
		},	
		populateSettings: () =>  {
			//	populateDefaultValues(remoteData)	
		},

		populateActionTypeSelect: () =>  {
			var actTypelist = selectListData.ref_action_type || []
					actTypeSelects = document.getElementsByClassName('mobile-actiontype-select')
					for(let a=0; a <actTypeSelects.length; a++) {
						let optionData = ``
						actTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(actTypeSelects[a]).empty().append(optionData)
					}
		},

		populateActionTypeScoreSelect: () =>  {
			var actTypelist = selectListData.ref_action_type || []
					actTypeSelects = document.getElementsByClassName('mobile-actiontypescore-select')
					for(let a=0; a <actTypeSelects.length; a++) {
						let optionData = ``
						actTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_id}|${data.rld_score}">${data.rld_name}</option>`
						 })
						 $(actTypeSelects[a]).empty().append(optionData)
					}
		},

		populateHazardTypeSelect: () =>  {
			var hazardTypelist = selectListData.ref_hazard_type || []
			hazardTypeSelects = document.getElementsByClassName('mobile-hazardtype-select')
					for(let a=0; a <hazardTypeSelects.length; a++) {
						let optionData = ``
						hazardTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
						 })
						 $(hazardTypeSelects[a]).empty().append(optionData)
					}
		},

		populateHazardIDSelect: () =>  {
			var hazardIDlist = selectListData.ref_hazard_identification || []
			hazardIDSelects = document.getElementsByClassName('mobile-hazardid-select')
					for(let a=0; a <hazardIDSelects.length; a++) {
						let optionData = ``
						hazardIDlist.forEach((data)=>{
							optionData += `<option value="${data.rld_id}|${data.rld_score}">${data.rld_name}</option>`
						 })
						 $(hazardIDSelects[a]).empty().append(optionData)
					}
		},

		populateHazardTopicSelect: () =>  {
			var hazardIDlist = selectListData.ref_hazard_identification || []
			hazardIDSelects = document.getElementsByClassName('mobile-hazardtopic-select')
					for(let a=0; a <hazardIDSelects.length; a++) {
						let optionData = ``
						hazardIDlist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(hazardIDSelects[a]).empty().append(optionData)
					}
		},		

		populatePotentialLossSelect: () =>  {
			let potentialLosslist = selectListData.ref_potential_loss || []
			potentialLossSelects = document.getElementsByClassName('mobile-potentialloss-select')
				for(let a=0; a <potentialLossSelects.length; a++) {
					let optionData = ``
					potentialLosslist.forEach((data)=>{
						optionData += `<option value="${data.rld_id}|${data.rld_score}">${data.rld_name}</option>`
						})
						$(potentialLossSelects[a]).empty().append(optionData)
				}

		},

		populateGeneralActionSelect: () =>  {
			let generalActionslist = selectListData.ref_general_action || []
			generalActionsSelects = document.getElementsByClassName('mobile-generalactions-select')
				for(let a=0; a <generalActionsSelects.length; a++) {
					let optionData = ``
					generalActionslist.forEach((data)=>{
						optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
						})
						$(generalActionsSelects[a]).empty().append(optionData)
				}

		},

		populateDemoReasonSelect: () =>  {
			var demoReasonlist = selectListData.ref_demonstration_reason || []
			demoReasonSelects = document.getElementsByClassName('mobile-demoreason-select')
					for(let a=0; a <demoReasonSelects.length; a++) {
						let optionData = ``
						demoReasonlist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(demoReasonSelects[a]).empty().append(optionData)
					}
		},

		populateTrainingAuditTypesSelect: () =>  {
			var trainingAuditTypeslist = selectListData.ref_training_audit_type || []
			trainingAuditTypesSelects = document.getElementsByClassName('mobile-trainingauditypes-select')
					for(let a=0; a <trainingAuditTypesSelects.length; a++) {
						let optionData = ``
						trainingAuditTypeslist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(trainingAuditTypesSelects[a]).empty().append(optionData)
					}
		},

		populateContextSelect: () =>  {
			let contextlist = selectListData.ref_context || []
			contextSelects = document.getElementsByClassName('mobile-context-select')
					for(let a=0; a <contextSelects.length; a++) {
						let optionData = ``
						contextlist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(contextSelects[a]).empty().append(optionData)
					}
		},

		populateContentSelect: () =>  {
			var contentlist = selectListData.ref_content || []
			contentSelects = document.getElementsByClassName('mobile-content-select')
					for(let a=0; a <contentSelects.length; a++) {
						let optionData = ``
						contentlist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(contentSelects[a]).empty().append(optionData)
					}
		},

		populateInspectionType: () =>  {
			var inspectionTypelist = selectListData.ref_inspection_type || []
			inspectionTypeSelects = document.getElementsByClassName('mobile-inspectiontype-select')
					for(let a=0; a < inspectionTypeSelects.length; a++) {
						let optionData = ``
						inspectionTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(inspectionTypeSelects[a]).empty().append(optionData)
					}
		},

		populateEventShiftScheduleSelect: () =>  {
			var eventShiftlist = selectListData.ref_event_shift_schedule || []
			eventShiftSelects = document.getElementsByClassName('mobile-eventshiftschedule-select')
					for(let a=0; a < eventShiftSelects.length; a++) {
						let optionData = ``
						eventShiftlist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(eventShiftSelects[a]).empty().append(optionData)
					}
		},

		populateIncidentTypesSelect: () =>  {
			var incidentTypeslist = selectListData.ref_incident_type || []
			incidentTypesSelects = document.getElementsByClassName('mobile-incidenttypes-select')
					for(let a=0; a < incidentTypesSelects.length; a++) {
						let optionData = ``
						incidentTypeslist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(incidentTypesSelects[a]).empty().append(optionData)
					}
		},		

		populateTopicTypeSelect: () =>  {
			var topicTypelist = selectListData.ref_topic_type || []
			topicTypeSelects = document.getElementsByClassName('mobile-topictype-select')
					for(let a=0; a <topicTypeSelects.length; a++) {
						let optionData = ``
						topicTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(topicTypeSelects[a]).empty().append(optionData)
					}
		},

		populatePreliminaryIncidentType: () => 	{
			var preIncTypelist = selectListData.ref_preliminary_incident_type || []
			preIncTypeSelects = document.getElementsByClassName('mobile-preliminaryincidentype-select')
			for(let a=0; a < preIncTypeSelects.length; a++) {
				let optionData = ``
				preIncTypelist.forEach((data)=>{
					optionData += `<option code="${data.rld_id}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(preIncTypeSelects[a]).empty().append(optionData)
			}
		},

		populatePreliminaryIncidentTypeCategory: (PreIncidentType) => {
			preIncTypeCatSelects = document.getElementsByClassName('mobile-preliminaryincidentypecategory-select')
			if(PreIncidentType.selectedIndex == -1) {
				$(preIncTypeCatSelects).empty()
				return
			}

			incidentTypeHolder = PreIncidentType.options[PreIncidentType.selectedIndex].getAttribute('code')
			var preIncTypeCatlist = selectListData.ref_preliminary_incident_type_category || []
			for(let a=0; a < preIncTypeCatSelects.length; a++) {
				let optionData = ``
				preIncTypeCatlist.forEach((data)=>{
					if(data.rld_parent_detail_rld_id === incidentTypeHolder) {
						optionData += `<option code="${incidentTypeHolder}" value="${data.rld_name}">${data.rld_name}</option>`
					}
				})
				$(preIncTypeCatSelects[a]).empty().append(optionData)
			}
		},

		populatePreliminaryIncidentTypeDetail: (PreIncidentCat) => {
			preIncTypeDetSelects = document.getElementsByClassName('mobile-preliminaryincidentypedetail-select')
			if(PreIncidentCat.selectedIndex == -1) {
				$(preIncTypeDetSelects).empty()
				return
			}

			incidentTypeHolder = PreIncidentCat.options[PreIncidentCat.selectedIndex].getAttribute('code')
			var preIncTypeDetlist = selectListData.ref_preliminary_incident_type_detail || []
			
			for(let a=0; a < preIncTypeDetSelects.length; a++) {
				let optionData = ``
				preIncTypeDetlist.forEach((data)=>{
					if(data.rld_parent_detail_rld_id === incidentTypeHolder) {
						optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
					}
				})
				$(preIncTypeDetSelects[a]).empty().append(optionData)
			}
		},

		populateClimateSelect: () =>  {
			var climateTypelist = selectListData.ref_climate || []
			climateTypeSelects = document.getElementsByClassName('mobile-climate-select')
					for(let a=0; a <climateTypeSelects.length; a++) {
						let optionData = ``
						climateTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(climateTypeSelects[a]).empty().append(optionData)
					}
		},

		populateClassificationSelect: () =>  {
			var classificationTypelist = selectListData.ref_classification || []
			classificationTypeSelects = document.getElementsByClassName('mobile-classification-select')
					for(let a=0; a < classificationTypeSelects.length; a++) {
						let optionData = ``
						classificationTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(classificationTypeSelects[a]).empty().append(optionData)
					}
		},

		populateInvolvementSelect: () =>  {
			var involvementTypelist = selectListData.ref_involvement || []
			involvementTypeSelects = document.getElementsByClassName('mobile-involvement-select')
					for(let a=0; a < involvementTypeSelects.length; a++) {
						let optionData = ``
						involvementTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(involvementTypeSelects[a]).empty().append(optionData)
					}
		},

		populateWorkrestSelect: () =>  {
			var workrestTypelist = selectListData.ref_work_rest_established || []
			workrestTypeSelects = document.getElementsByClassName('mobile-workrest-select')
					for(let a=0; a < workrestTypeSelects.length; a++) {
						let optionData = ``
						workrestTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(workrestTypeSelects[a]).empty().append(optionData)
					}
		},

		populatePreparationSelect: () =>  {
			var preparationTypelist = selectListData.ref_preparation || []
			preparationTypeSelects = document.getElementsByClassName('mobile-preparation-select')
					for(let a=0; a < preparationTypeSelects.length; a++) {
						let optionData = ``
						preparationTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(preparationTypeSelects[a]).empty().append(optionData)
					}
		},	

		populateTestingSelect: () =>  {
			var testingTypelist = selectListData.ref_testing || []
			testingTypeSelects = document.getElementsByClassName('mobile-testing-select')
					for(let a=0; a < testingTypeSelects.length; a++) {
						let optionData = ``
						testingTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(testingTypeSelects[a]).empty().append(optionData)
					}
		},

		populateKnowledgeSelect: () =>  {
			var knowledgeTypelist = selectListData.ref_knowledge || []
			knowledgeTypeSelects = document.getElementsByClassName('mobile-knowledge-select')
					for(let a=0; a < knowledgeTypeSelects.length; a++) {
						let optionData = ``
						knowledgeTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(knowledgeTypeSelects[a]).empty().append(optionData)
					}
		},

		populateShiftSelect: () =>  {
			var shiftTypelist = selectListData.ref_shift || []
			shiftTypeSelects = document.getElementsByClassName('mobile-shift-select')
					for(let a=0; a < shiftTypeSelects.length; a++) {
						let optionData = ``
						shiftTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(shiftTypeSelects[a]).empty().append(optionData)
					}
		},

		populateAuditTypeSelect: () =>  {
			var audittypeTypelist = selectListData.ref_audit_type || []
			audittypeTypeSelects = document.getElementsByClassName('mobile-audittype-select')
					for(let a=0; a < audittypeTypeSelects.length; a++) {
						let optionData = ``
						audittypeTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(audittypeTypeSelects[a]).empty().append(optionData)
					}
		},	

		populateRecordStatusSelect: () =>  {
			var recordstatusTypelist = selectListData.ref_record_status || []
			recordstatusTypeSelects = document.getElementsByClassName('mobile-recordstatus-select')
					for(let a=0; a < recordstatusTypeSelects.length; a++) {
						let optionData = ``
						recordstatusTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(recordstatusTypeSelects[a]).empty().append(optionData)
					}
		},		
		populateHotWorkTypeSelect: () =>  {
			var recordHotWorkTypelist = selectListData.ref_hot_work_type || []
			recordHotWorkTypeSelects = document.getElementsByClassName('mobile-hotworktype-select')
					for(let a=0; a < recordHotWorkTypeSelects.length; a++) {
						let optionData = ``
						recordHotWorkTypelist.forEach((data)=>{
							optionData += `<option class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(recordHotWorkTypeSelects[a]).empty().append(optionData)
					}
		},
		populateHotWorkHazardsSelect: () =>  {
			var recordHotWorkHazardslist = selectListData.ref_hot_work_hazards || []
			recordHotWorkHazardsSelects = document.getElementsByClassName('mobile-hotworkhazardstype-select')
					for(let a=0; a < recordHotWorkHazardsSelects.length; a++) {
						let optionData = ``
						recordHotWorkHazardslist.forEach((data)=>{
							optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(recordHotWorkHazardsSelects[a]).empty().append(optionData)
					}
		},
		populateDetermineControlsSelect: () =>  {
			var recordDetermineControlslist = selectListData.ref_determine_controls_equipment || []
			recordDetermineControlsSelects = document.getElementsByClassName('mobile-determinecontrols-select')
					for(let a=0; a < recordDetermineControlsSelects.length; a++) {
						let optionData = ``
						recordDetermineControlslist.forEach((data)=>{
							optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(recordDetermineControlsSelects[a]).empty().append(optionData)
					}
		},
		populateSpecialPPEsSelect: () =>  {
			var recordSpecialPPElist = selectListData.ref_personal_protective_equipment || []
			recordSpecialPPESelects = document.getElementsByClassName('mobile-personalprotectiveequipment-select')
					for(let a=0; a < recordSpecialPPESelects.length; a++) {
						let optionData = ``
						recordSpecialPPElist.forEach((data)=>{
							optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(recordSpecialPPESelects[a]).empty().append(optionData)
					}
		},
		populateHighRiskPrecautionsSelect: () =>  {
			var recordHighRiskPrecautionslist = selectListData.ref_high_risk_precautions || []
			recordHighRiskPrecautionsSelects = document.getElementsByClassName('mobile-highriskprecautions-select')
					for(let a=0; a < recordHighRiskPrecautionsSelects.length; a++) {
						let optionData = ``
						recordHighRiskPrecautionslist.forEach((data)=>{
							optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(recordHighRiskPrecautionsSelects[a]).empty().append(optionData)
					}
		},

		populateRetrievalEquipmentSelect: () =>  {
			var retrievalEquipmentlist = selectListData.ref_rescue_plan_Retrieval_Equipment || []
			retrievalEquipmentSelects = document.getElementsByClassName('mobile-retrievalEquipmentList-select')
					for(let a=0; a < retrievalEquipmentSelects.length; a++) {
						let optionData = ``
						retrievalEquipmentlist.forEach((data)=>{
							optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(retrievalEquipmentSelects[a]).empty().append(optionData)
					}
		},	

		populateRetrievalSpecialPPESelect: () =>  {
			var retrievalSpecialPPElist = selectListData.ref_rescue_special_ppe || []
			retrievalSpecialPPESelects = document.getElementsByClassName('mobile-retrievalSpecialPPEList-select')
					for(let a=0; a < retrievalSpecialPPESelects.length; a++) {
						let optionData = ``
						retrievalSpecialPPElist.forEach((data)=>{
							optionData += `<option  class="${(data.rld_option==1)?'other':(data.rld_option==2)?'saba':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(retrievalSpecialPPESelects[a]).empty().append(optionData)
					}					
		},	

		populateRecognitionTypeSelect: () =>  {
			var recognitionType = selectListData.ref_recognition_type || []
					recognitionSelects = document.getElementsByClassName('mobile-recognitiontype-select')
					for(let a=0; a <recognitionSelects.length; a++) {
						let optionData = ``
						recognitionType.forEach((data)=>{
							optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
						 })
						 $(recognitionSelects[a]).empty().append(optionData)
					}
		},

		populateRecognitionGivenTypeSelect: () =>  {
			var recognitionGivenType = selectListData.ref_recognition_given || []
					recognitionGivenSelects = document.getElementsByClassName('mobile-recognitiongiventype-select')
					for(let a=0; a <recognitionGivenSelects.length; a++) {
						let optionData = ``
						recognitionGivenType.forEach((data)=>{
							optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
						 })
						 $(recognitionGivenSelects[a]).empty().append(optionData)
					}
		},

		populateHazardsPresentSelect: () =>  {
			var retrievalHazardsPresentlist = selectListData.ref_hazards_present_rp || []
			retrievalHazardsPresentSelects = document.getElementsByClassName('mobile-retrievalHazardsPresentList-select')
					for(let a=0; a < retrievalSpecialPPESelects.length; a++) {
						let optionData = ``
						retrievalHazardsPresentlist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })						
						 $(retrievalHazardsPresentSelects[a]).empty().append(optionData)
					}					
		},	
		
		populateRescueTypeSelect: () =>  {
			var retrievalRescueTypelist = selectListData.ref_rescue_type || []
			retrievalRescueTypeSelects = document.getElementsByClassName('mobile-retrievalRescueTypeList-select')
					for(let a=0; a < retrievalRescueTypeSelects.length; a++) {
						let optionData = ``
						retrievalRescueTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(retrievalRescueTypeSelects[a]).empty().append(optionData)
					}					
		},	
		
		populateCommunicationStrategySelect: () =>  {
			var retrievalCommunicationStrategylist = selectListData.ref_communication_strategy || []
			retrievalCommunicationStrategySelects = document.getElementsByClassName('mobile-retrievalCommunicationStrategyList-select')
					for(let a=0; a < retrievalCommunicationStrategySelects.length; a++) {
						let optionData = ``
						retrievalCommunicationStrategylist.forEach((data)=>{
							optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(retrievalCommunicationStrategySelects[a]).empty().append(optionData)
					}					
		},	

		populateKeyContactsSelect: () =>  {
			var retrievalKeyContactslist = selectListData.ref_key_contacts_rp || []
			retrievalKeyContactsSelects = document.getElementsByClassName('mobile-retrievalKeyContactsList-select')
					for(let a=0; a < retrievalKeyContactsSelects.length; a++) {
						let optionData = ``
						retrievalKeyContactslist.forEach((data)=>{
							optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(retrievalKeyContactsSelects[a]).empty().append(optionData)
					}					
		},	



		populatePotentialHazardsSelect: () =>  {
				var potentialhazardTypelist = selectListData.ref_potential_hazards_wh || []
					potentialhazardsTypeSelects = document.getElementsByClassName('mobile-potentialhazards-select')
							for(let a=0; a < potentialhazardsTypeSelects.length; a++) {
								let optionData = ``
								potentialhazardTypelist.forEach((data)=>{
									optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
								})
								$(potentialhazardsTypeSelects[a]).empty().append(optionData)
							}
		},
	


		populateDetermineControlsEquipmentWHSelect: () =>  {
			var determinecontrolsequipmentTypelist = selectListData.ref_determine_controls_wh || []
			determinecontrolsequipmentTypeSelects = document.getElementsByClassName('mobile-determinecontrolsequipment-select')
					for(let a=0; a < determinecontrolsequipmentTypeSelects.length; a++) {
						let optionData = ``
						determinecontrolsequipmentTypelist.forEach((data)=>{
							optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(determinecontrolsequipmentTypeSelects[a]).empty().append(optionData)
					}
		},		


		populateWorkCardTypeSelect: () =>  {
			var workcardTypelist = selectListData.ref_work_card_type || []
			workcardTypeSelects = document.getElementsByClassName('mobile-workcardTtype-select')
					for(let a=0; a < workcardTypeSelects.length; a++) {
						let optionData = ``
						workcardTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(workcardTypeSelects[a]).empty().append(optionData)
					}
		},	

		populateWorkAccomplishedSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				var workAccomplishedlist = selectListData.ref_work_accomplished || []
				let optionData = `<option></option>`
				workAccomplishedlist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				if(!id){
					workAccomplishedSelects = document.getElementsByClassName('mobile-workAccomplished-select')
					for(let a=0; a < workAccomplishedSelects.length; a++) {	
						$(workAccomplishedSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},

		populateWorkingAtHeightsSpecialPPESelect: () =>  {
			var workingatheightsspecialppeTypelist = selectListData.ref_special_ppe_wh || []
			workingatheightsspecialppeTypeSelects = document.getElementsByClassName('mobile-workingatheightsspecialppe-select')
					for(let a=0; a < workingatheightsspecialppeTypeSelects.length; a++) {
						let optionData = ``
						workingatheightsspecialppeTypelist.forEach((data)=>{
							optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(workingatheightsspecialppeTypeSelects[a]).empty().append(optionData)
					}
		},		

		populateAMTaskContractSelect: () =>  {
			var amtaskcontractTypelist = selectListData.ref_am_task_contract || []
			amtaskcontractTypeSelects = document.getElementsByClassName('mobile-amtaskcontract-select')
					for(let a=0; a < amtaskcontractTypeSelects.length; a++) {
						let optionData = ``
						amtaskcontractTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(amtaskcontractTypeSelects[a]).empty().append(optionData)
					}
		},	

		populateAMTaskTypeSelect: () =>  {
			var amtasktypeTypelist = selectListData.ref_am_task_type || []
			amtasktypeTypeSelects = document.getElementsByClassName('mobile-amtasktype-select')
					for(let a=0; a < amtasktypeTypeSelects.length; a++) {
						let optionData = ``
						amtasktypeTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(amtasktypeTypeSelects[a]).empty().append(optionData)
					}
		},	

		populateAMSuppliesLocationSelect: (selectedSite,id) =>  {
			let selectSiteHolder = ""
			if(selectedSite.hasAttribute('site')) {
				selectSiteHolder = selectedSite.options[selectedSite.selectedIndex].getAttribute('site')
			}
			var amsupplieslocationTypelist = selectListData.ref_am_supplies_location || []
			let optionData = ``
			optionData += `<option></option>`
			amsupplieslocationTypelist.forEach((data)=>{
				if(data.rld_parent_detail_rld_id == selectSiteHolder){
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				} 
			})
			if(!id){
				amsupplieslocationTypeSelects = document.getElementsByClassName('mobile-amsupplieslocation-select')
				for(let a=0; a < amsupplieslocationTypeSelects.length; a++) {
						$(amsupplieslocationTypeSelects[a]).empty().append(optionData)
				}
			}
			else{
				$(`#${id}`).empty().append(optionData)
			}
		},

		populateAMSuppliesTypeSelect: () =>  {
			var amsuppliestypeTypelist = selectListData.ref_am_supplies_type || []
			amsuppliestypeTypeSelects = document.getElementsByClassName('mobile-amsuppliestype-select')
					for(let a=0; a < amsuppliestypeTypeSelects.length; a++) {
						let optionData = ``
						amsuppliestypeTypelist.forEach((data)=>{
							optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(amsuppliestypeTypeSelects[a]).empty().append(optionData)
					}
		},	

		populateRuleBreakingSelect: () =>  {
			var ruleBreakinglist = selectListData.ref_rule_breaking || []
			ruleBreakingSelects = document.getElementsByClassName('mobile-rule-breaking-select')
					for(let a=0; a <ruleBreakingSelects.length; a++) {
						let optionData = ``
						ruleBreakinglist.forEach((data)=>{
							optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(ruleBreakingSelects[a]).empty().append(optionData)
					}
		},	

		populateSanctionTypeSelect: () =>  {
			var sanctionTypelist = selectListData.ref_sanctions || []
			sanctionTypeSelects = document.getElementsByClassName('mobile-sanction-type-select')
					for(let a=0; a <sanctionTypeSelects.length; a++) {
						let optionData = ``
						sanctionTypelist.forEach((data)=>{
							optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(sanctionTypeSelects[a]).empty().append(optionData)
					}
		},	

		populateServiceTypeSelect: () =>  {
			var recordServiceTypelist = selectListData.ref_service_type || []
			recordServiceTypeSelects = document.getElementsByClassName('mobile-servicetype-select')
					for(let a=0; a < recordServiceTypeSelects.length; a++) {
						let optionData = ``
						recordServiceTypelist.forEach((data)=>{
							optionData += `<option class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(recordServiceTypeSelects[a]).empty().append(optionData)
					}
		},

		populateEquipmentStatusSelect: () =>  {
			var recordEquipmentStatuslist = selectListData.ref_equipment_status || []
			recordEquipmentStatusSelects = document.getElementsByClassName('mobile-equipment-status-select')
					for(let a=0; a < recordEquipmentStatusSelects.length; a++) {
						let optionData = ``
						recordEquipmentStatuslist.forEach((data)=>{
							optionData += `<option class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
						 })
						 $(recordEquipmentStatusSelects[a]).empty().append(optionData)
					}
		},		

		populateDrillingTimeDelaysCodeSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				var drillingtimeanddelayscodelist = selectListData.ref_drilling_time_and_delays_code || []
				let optionData =`<option></option>`
				drillingtimeanddelayscodelist.forEach((data)=>{
						optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
					})
				if(!id){
					drillingtimeanddelayscodeSelects = document.getElementsByClassName('mobile-drillingtimeanddelayscode-select')
					for(let a=0; a < drillingtimeanddelayscodeSelects.length; a++) {
						$(drillingtimeanddelayscodeSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},
		
		populateDrillingCodeSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				var drillingcodelist = selectListData.ref_drilling_code || []
				let optionData =`<option></option>`
				drillingcodelist.forEach((data)=>{
						optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
					})
				if(!id){
					drillingcodeSelects = document.getElementsByClassName('mobile-drillingcode-select')
					for(let a=0; a < drillingcodeSelects.length; a++) {
						$(drillingcodeSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},

		populateStatusCodeSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				var statuscodelist = selectListData.ref_drilling_status_code || []
				let optionData =`<option></option>`
				statuscodelist.forEach((data)=>{
						optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
					})
				if(!id){
					statuscodeSelects = document.getElementsByClassName('mobile-drillingStatuscode-select')
					for(let a=0; a < statuscodeSelects.length; a++) {
						$(statuscodeSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},

		populateDrillingLogCodeSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				var drillinglogcodelist = selectListData.ref_drilling_log_code || []
				let optionData =`<option></option>`
				drillinglogcodelist.forEach((data)=>{
						optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
					})
				if(!id){
					drillinglogcodeSelects = document.getElementsByClassName('mobile-drillinglogcode-select')
					for(let a=0; a < drillinglogcodeSelects.length; a++) {
						$(drillinglogcodeSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},

		populateDrillingBitSizeSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				var drillingbitsizelist = selectListData.ref_drilling_bit_size || []
				let optionData =`<option></option>`
				drillingbitsizelist.forEach((data)=>{
						optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
					})
				if(!id){
					drillingbitsizeSelects = document.getElementsByClassName('mobile-drillingbitsize-select')
					for(let a=0; a < drillingbitsizeSelects.length; a++) {
						$(drillingbitsizeSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},
		
		populateDrillingMaterialUsedSelect: (id) =>  {
			var drillingmaterialusedlist = selectListData.ref_drilling_material_used || []
			let optionData =`<option></option>`
			drillingmaterialusedlist.forEach((data)=>{
					optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
				})
			if(!id){
				drillingmaterialusedSelects = document.getElementsByClassName('mobile-drillingmaterialused-select')
				for(let a=0; a < drillingmaterialusedSelects.length; a++) {
					$(drillingmaterialusedSelects[a]).empty().append(optionData)
				}
			}
			else{
				$(`#${id}`).empty().append(optionData)
			}
		},

		populateInterventionTypeSelect: () =>  {
			var interventionTypelist = selectListData.ref_type_intervention || []
			interventionTypeSelects = document.getElementsByClassName('mobile-intervention-type-select')
			for(let a=0; a <interventionTypeSelects.length; a++) {
				let optionData = `<option></option>`
				interventionTypelist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_id}">${data.rld_name}</option>`
					})
					$(interventionTypeSelects[a]).empty().append(optionData)
			}
		},

		populateLotoEquipmentListSelect: () =>  {
			lotoEquipmentPicsCachePromise().then(()=>{
				lotoEquipmentlist=lotoEquipmentPics || []
				lotoEquipmentSelects = document.getElementsByClassName('mobile-loto-equipment-select')
				for(let a=0; a <lotoEquipmentSelects.length; a++) {
					let optionData = `<option></option>`
					lotoEquipmentlist.forEach((data)=>{
						optionData += `<option  value="${data.lte_id}">${data.ltr_text}</option>`
					})
					$(lotoEquipmentSelects[a]).empty().append(optionData)
				}
			})
		},		
		
		populateTemperaturelistSelect: () =>  {
			var temperaturelist = selectListData.ref_temperature || []
			temperatureSelects = document.getElementsByClassName('mobile-temperature-select')
			for(let a=0; a <temperatureSelects.length; a++) {
				let optionData = ``
				temperaturelist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
					})
					$(temperatureSelects[a]).empty().append(optionData)
			}
		},

		formValidate: (theForm,mode = 'normal')	=> {
			// Validate the contents of the common form header
			let headerValidation = ''
			let headerValidated = `<li class="list-group-item"><strong><span class='translate' data-i18n="1404" notes="Validation Message"></span></strong></li>`
			if (theForm.submissionId.value == '')	{
                headerValidation += `<li>There is an issue with the Submission ID, please contact admin</li>`
			} 

			if(!theForm.startFormTimeStamp.value instanceof Date)	{
				headerValidation += `<li>There is an issue with the start date, please contact admin.</li>`
			}

			if(!theForm.endFormTimeStamp.value instanceof Date)	{
				headerValidation += `<li>There is an issue with the end date, please contact admin.</li>`
			}

			if(theForm.site.validity.valueMissing)	{
				headerValidation += `<li class="list-group-item"><span class='translate' data-i18n="828" notes="Site"></span><i class="fa fa-times red-text fa-lg pl-3"></i></li>`
			}
			else {
				headerValidated  += `<li class="list-group-item"><span class='translate' data-i18n="828" notes="Site"></span><i class="fa fa-check green-text fa-lg pl-3"></i></li>`
			}

			if(theForm.job_number.validity.valueMissing)	{
				headerValidation += `<li class="list-group-item"><span class='translate' data-i18n="617" notes="Job Number"></span><i class="fa fa-times red-text fa-lg pl-3"></i></li>`
			}
			else {
				headerValidated  += `<li class="list-group-item"><span class='translate' data-i18n="617" notes="Job Number"></span><i class="fa fa-check green-text fa-lg pl-3"></i></li>`
			}

			if(theForm.level.validity.valueMissing)	{
				headerValidation += `<li class="list-group-item"><span class='translate' data-i18n="621" notes="Level"></span><i class="fa fa-times red-text fa-lg pl-3"></i></li>`				
			}
			else {
				headerValidated  += `<li class="list-group-item"><span class='translate' data-i18n="621" notes="Level"></span><i class="fa fa-check green-text fa-lg pl-3"></i></li>`
			}

			if(theForm.workplace.validity.valueMissing)	{
				headerValidation += `<li class="list-group-item"><span class='translate' data-i18n="959" notes="Workplace"></span><i class="fa fa-times red-text fa-lg pl-3"></i></li>`
			}
			else {
				headerValidated  += `<li class="list-group-item"><span class='translate' data-i18n="959" notes="Workplace"></span><i class="fa fa-check green-text fa-lg pl-3"></i></li>`
			}

			if(theForm.supervisor.validity.valueMissing) {
				headerValidation += `<li class="list-group-item"><span class='translate' data-i18n="844" notes="Supervisor"></span><i class="fa fa-times red-text fa-lg pl-3"></i></li>`
			}
			else {
				headerValidated  += `<li class="list-group-item"><span class='translate' data-i18n="844" notes="Supervisor"></span><i class="fa fa-check green-text fa-lg pl-3"></i></li>`
			}
			if(theForm.formid.value=="372418" && theForm.work_card_type.validity.valueMissing){
				headerValidation += `<li class="list-group-item"><span class='translate' data-i18n="8494" notes="Work Card Type"></span><i class="fa fa-times red-text fa-lg pl-3"></i></li>`
			}
			else {
				headerValidated  += `<li class="list-group-item"><span class='translate' data-i18n="8494" notes="Work Card Type"></span><i class="fa fa-check green-text fa-lg pl-3"></i></li>`
			}

			// check the key fields
			mainFields = ['site','level','job_number','workplace', 'supervisor','employee_name']
			theForm.keyField.value.split('|').forEach((data) => {
				let text = i18next.t(theForm[data].getAttribute("tag"))
				if(theForm[data].validity.valueMissing && !mainFields.includes(data)) {
					headerValidation += `<li class="list-group-item">${text}<i class="fa fa-times red-text fa-lg pl-3"></i></li>`
				}

				if (!theForm[data].validity.valueMissing && !mainFields.includes(data)) {
					headerValidated  += `<li class="list-group-item">${text}<i class="fa fa-check green-text fa-lg pl-3"></i></li>`
				}
			})
            if(headerValidation) {
				headerValidation = `<ul class="list-group list-group-flush">${headerValidated}${headerValidation}</ul>`
		  		// if autosave then do not display the modal
				if(mode === 'normal') 
					validationModal(headerValidation)
				return false
			} else {
				return true;	
			}
		}				
	};
	
	function populateDefaultValues(remoteData, userSiteData){
        let data = remoteData[_USERSETTINGSPROFILE].UserSettingsProfile[0]
		if(userSiteData.length > 0) {
			if(data.upr_site_id){
				$('#site').val(parseInt(data.upr_site_id)).trigger('change').parent().find('label').addClass('filled')
			}
			if(data.upr_job_id){
				$('#job_number').val(parseInt(data.upr_job_id)).trigger('change').parent().find('label').addClass('filled')
			}
			if(data.upr_level_id){
				$('#level').val(parseInt(data.upr_level_id)).parent().find('label').addClass('filled')
			}
			if(data.supervisor_name){
				$('#supervisor').val(data.supervisor_name).parent().find('label').addClass('filled')
			}
			if(data.email_list){
				let distribution_value = data.email_list.split(',')        
				$('#Report_Distribution1').val(distribution_value).trigger('change').parent().find('label').addClass('filled')
			}
			getAllLineupLevels()  
		}
    }

	function sortFunction(a, b) {
		if (a[0] === b[0]) {
			return 0;
		}
		else {
			return (a[0] < b[0]) ? -1 : 1;
		}
	}
	function validationModal(message) {
     valModal = new SofvieModal()
		 valModal.setModalElements('danger', `modalButtons`, `<a role="button" class="btn btn-danger")} waves-effect" data-dismiss="modal"><span class='translate' data-i18n="1405" notes="OK"></span></a>`)
		 valModal.setModalElements('danger', `modalText`, message)
		 valModal.setModalElements('danger', `modalTitle`,i18next.t("1403"))
		 valModal.handleModal('danger');
		 $('.translate').localize()
			startAutoSave()
			document.getElementById("saveDraft").disabled = false;	
		 $('.button-collapse .fa').on('click',()=> {
			return false;
      })
	}




	function refreshSelect2() {
		let select2LanguageFunction = window[`sofvie_select2_languages_${selectedLanguage}`]
		if (!(typeof select2LanguageFunction === "function"))
		{
			select2LanguageFunction = {}
			console.error("Failed to get Select2 Translations")
		}

		$('.lineupheader').select2({theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder:""})
		.on('select2:select', function(event){$(this).parent().find('label').addClass('filled');
		if (event.target.parentNode.querySelector('.mobile-distribution-select')){
			addDistributionGroup(event)
		}
		})
		.on('select2:unselect', function(event){
		if($(".select2-selection__choice")[0]){
		$(this).parent().find('label').addClass('filled');
		}else {
		$(this).parent().find('label').removeClass('filled');  
		}
		if (event.target.parentNode.querySelector('.mobile-distribution-select')){
			removeDistributionGroup()
		}
		})
		.on('select2:open', function () {
		$('.select2-search__field').attr('placeholder', i18next.t("2346"));
		$('.select2-results').css({'max-height':'260px'})
		})
		.on('select2:close', function () {
		$('.select2-search__field').attr('placeholder', i18next.t("2346"));
		});
	}

</script>