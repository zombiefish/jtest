<?php
  $submissionID = false;
	$submissionID = filter_input(INPUT_GET, 'submissionId', FILTER_SANITIZE_STRING);							// get passed submissionid from querystring
?>
<input type="hidden" id="currentDraft" value="" />
<input type="hidden" name="submissionId" id="submissionId" value="<?php echo $submissionID ?>" />
<input type="hidden" name="startFormTimeStamp" id="startFormTimeStamp" value="" />
<input type="hidden" name="endFormTimeStamp" id="endFormTimeStamp" value="" />
<input type="hidden" name="displayReferenceValue" id="displayReferenceValue" value="" />
<input type="hidden" name="submittedby" id="submittedby" value="" />
<input type="hidden" name="submittedby_name" id="submittedby_name" value="" />
<input type="hidden" id="hapChildExists" value="false" />
<input type="hidden" id="pidChildExists" value="false" />
<input type="hidden" id="gapChildExists" value="false" />

<div class="md-form"> 
  <input tabindex="1" type="text" name="date" id="date" class="form-control datepicker lock" data-value = "" value="Select date" required />
  <label for="date"><span class='translate' data-i18n="124" notes="Date"></span></label>
</div>

<div class="pt-1 position-relative my-4">
  <select name="site" id="site" class="select-single select-default lock"  onChange="populateChildSelects(this)" required >
  </select>
  <label for="site"><span class='translate' data-i18n="828" notes="Site"></span></label>
</div>

<div class="pt-1 position-relative my-4">
  <select name="job_number" id="job_number" class="select-single select-default lock" onChange="formHeader.populateLevelSelect(this)" required >
  </select>
  <label for="job_number"><span class='translate' data-i18n="617" notes="Job Number"></span></label>
</div>

<div class="pt-1 position-relative my-4">
  <select name="level" id="level" class="select-single select-default lock" required>
  </select>
  <label for="level"><span class='translate' data-i18n="621" notes="Level"></span></label>
</div>

<div class="md-form">
  <input type="text" name="workplace" id="workplace" class="form-control md-textarea lock" wrap="VIRTUAL" length="200" maxlength="200" required/>
  <label for="workplace"><span class='translate' data-i18n="959" notes="Workplace"></span></label>
</div>

<div class="pt-1 position-relative my-4">
  <select name="supervisor" id="supervisor" class="select-single select-default form-control mobile-supervisor_id-select lock" required>
  </select>
  <label for="supervisor"><span class='translate' data-i18n="844" notes="Supervisor"></span></label>
</div>


<!-- Generate all of the lists and place them as hidden fields in the form -->

<script type="text/javascript">

	// check if logged in user has permission to view the form.
	// if not, redirect to index or home page
	// check permissions from remoteData FormAccess

	let allowForm = false
	let currentForm = window.location.href.split('/')[window.location.href.split('/').length -1]
	localStorage.setItem(`noinitialize`,'true')
	
	function populateDefaultValues(remoteData, userSiteData){
        let data = remoteData[_USERSETTINGSPROFILE].UserSettingsProfile[0]
		if(userSiteData.length > 0) {
			if(data.upr_site_id){
				$('#site').val(parseInt(data.upr_site_id)).trigger('change').parent().find('label').addClass('filled')
			}
			if(data.upr_job_id){
				$('#job_number').val(parseInt(data.upr_job_id)).trigger('change').parent().find('label').addClass('filled')
			}
			if(data.upr_level_id){
				$('#level').val(parseInt(data.upr_level_id)).parent().find('label').addClass('filled')
			}
			if(data.supervisor_name){
				$('#supervisor').val(data.supervisor_name).parent().find('label').addClass('filled')
			}
			if(data.email_list){
				let distribution_value = data.email_list.split(',')        
				$('#Report_Distribution1').val(distribution_value).trigger('change').parent().find('label').addClass('filled')
			}
		}
    }

	// this function will get the values from the Draft Object and apply then to the select Value
	// this is for select lists that load after the draft has tried to apply a value and the options were not there yet
	function reselectDraftSelectValues(selectlist) {
		for(let a=0; a <selectlist.length; a++) {
			if(parsedJSON && $(`#${selectlist[a].id}`).val().length == 0){
				if(parsedJSON[selectlist[a].id]) {
					$(`#${selectlist[a].id}`).val(parsedJSON[selectlist[a].id].split('|')).trigger('change')
				}
			}
		}
	}

	openCacheData().then((rdata) => {
		let allowedForms = remoteData[9]['FormAccess']
		allowedForms.forEach(element => {	
			if (`/forms/${currentForm.split('#')[0]}` === element.FormUrl) {
				allowForm = true
			}
		})
		if(!allowForm){
			window.location.href = '/index.php'
		}
	})

	document.getElementById('date').setAttribute('data-value', `${moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD')}`)
	const _USERSETTINGSPROFILE = 32
	var selectedSiteHolder = ''

	populateChildSelects = (selectedSite) => {
		formHeader.populateJobSelect(selectedSite)
		formHeader.populateSupervisorIDSelect()
		formHeader.populateAMSuppliesLocationSelect(selectedSite)
	}
	var formHeader = {
		listsData : '',

		formInitialize: (theForm) => {
			// Populate submissionId
			openCacheData().then((rdata)=>{
			if(!theForm.submissionId.value)
			  theForm.submissionId.value = formHeader.uuidv4()
			  theForm.startFormTimeStamp.value = moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD HH:mm:ss')
			  theDate = new DateUtils()
			  theForm.date.value = theDate.formatCurrentDate('standard')
			  openSelectCacheData().then(()=>{
				formHeader.populateSiteSelect(document.getElementById('site'))
				populateDefaultValues(remoteData, userSiteData)
				// Check for another Form
				anotherForm()
			  })
			  document.getElementById('submittedby').value = remoteData[2].Employee[0].per_id
			  document.getElementById('submittedby_name').value = remoteData[2].Employee[0].per_full_name
			})
		},
		
		formTerminate: (theForm) => {
			// Populate submissionId
			 theForm.endFormTimeStamp.value = moment(new Date(), 'YYYY-MM-DD').format('YYYY-MM-DD HH:mm:ss')
		},
		
		//Generate a cryptographically  unique guid.
		uuidv4 : () => {
		  return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
		    (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
		  )
		},
		
		populateSiteSelect: (theSelect)	=> {
			$('#site').empty().append('<option></option>')
			let opts = userSiteData
			$.each(opts, function(i, d) {
				$('#site').append(`<option value="${d.rld_id}" site="${d.rld_id}">${d.rld_name}</option>`);
			})
		},
		
		populateJobSelect: (selectedSite) => {
			let selectSiteHolder = null
			if(selectedSite.options[selectedSite.selectedIndex]) {
				selectSiteHolder = selectedSite.options[selectedSite.selectedIndex].getAttribute('site')
			}
			$('#job_number').parent().find('label').removeClass('active filled')
			$('#job_number').empty().append('<option></option>')
			// Parse the returned json data
			let opts = userJobData

			// Use jQuery's each to iterate over the opts value
			$.each(opts, function(i, d) {
				if(parseInt(d.rld_parent_detail_rld_id) == parseInt(selectSiteHolder) && parseInt(d.rld_is_active) == 1)
					{
						$('#job_number').append(`<option value="${d.rld_id}" site="${selectSiteHolder}" >${d.rld_code} - ${d.rld_name}</option>`)						
					}
					
			})
			if(document.getElementsByClassName('mobile-equipmentlocation').length > 0)
			{
				formHeader.populateEquipmentLocationSelect(selectSiteHolder)
			}

			distributionSelects = document.getElementsByClassName('mobile-distribution-select')
			if($('#job_number').val() == "") {
				for(let a=0; a <distributionSelects.length; a++) {
					$(distributionSelects[a]).empty()
				}
				return
			}
		},

		populateLevelSelect: (selectedJobNumber) =>	{
			if(typeof(preop_site_job_equipment_select) ==='function'){
				 preop_site_job_equipment_select(1)
			}
			let selectJobNumber = null
			formHeader.populateEmployeeSelect('level')
			formHeader.populateSupervisorIDSelect()
			formHeader.populateSupervisorSelect()
			formHeader.populateEmployeeSelectWithOther()
			formHeader.populateEmployeeSelectSingle('level')
			formHeader.populateEmployeeSelectID()
			formHeader.populateEmployeeSelectIDSingle()
			formHeader.populateEmployeeModalSelect()
			formHeader.populateDistributionSelect()
			if(selectedJobNumber.options[selectedJobNumber.selectedIndex]) {
				selectJobNumber = selectedJobNumber.options[selectedJobNumber.selectedIndex].getAttribute('site')
			}
			
			$('#level').parent().find('label').removeClass('active filled')
			$('#level').empty().append('<option></option>')
			$('#levelendshift').parent().find('label').removeClass('active filled')
			$('#levelendshift').empty().append('<option></option>')
			// Parse the returned json data
			let opts = selectListData.ref_level || []
			$.each(opts, function(i, d) {
				if(d.rld_parent_detail_rld_id == selectJobNumber) {
					$('#level').append(`<option value="${d.rld_id}">${d.rld_name}</option>`)
				if(document.getElementById('levelendshift')){
					$('#levelendshift').append(`<option value="${d.rld_name}">${d.rld_name}</option>`)
				}
				}
			});
		},

		populateAllEquipmentSelect: (id) => {
			openCacheData().then(()=>{
				const lists = remoteData
				mach = []
				if(lists[25]['PreOpEquipmentList']){
					lists[25]['PreOpEquipmentList'].forEach((data)=>{
						if(data.pet_equipment_identifier!=null){
							mach.push({
								machineNumber: data.pet_equipment_identifier,
								machineType: data.pet_poe_id
							})
						}
					})
					let optionData= `<option></option>`
					if(mach.length > 0){
						mach.forEach((rec) =>{
							let machineName = getMachineName(rec.machineType)
							optionData += `<option value='${rec.machineNumber} ${machineName}'>${rec.machineNumber?rec.machineNumber:''} ${machineName}</option>`	
						})
					}
					if(!id){
						if(form.name=="preliminaryIncident"){
							optionData += `<option value = "Other">Other</option>`
						}
						retrievalEquipmentTypeSelects = document.getElementsByClassName('mobile-equipment-select')
						for(let a = 0;a<retrievalEquipmentTypeSelects.length;a++){
							$(retrievalEquipmentTypeSelects[a]).empty().append(optionData)
						}
					}
					else{
						$(`#${id}`).empty().append(optionData)
					}

					function getMachineName(type) {
						let mname = ''
						lists[23]['PreOpEquipment'].forEach((data)=>{
							if(data.poe_id === type) 
							mname = data.poe_equip_description
						})
						return mname
					}
				}
			})
		},

		populateEquipmentLocationSelect: (selectedSite,id) => {
			selectCachePromise().then((selectListData)=> {
				let equipLocationLevels = selectListData.ref_level || []
				let optionData = `<option></option>`
				equipLocationLevels.forEach((data)=>{
					if(parseInt(data.rld_parent_detail_rld_id) == parseInt(selectedSite)){
						optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
					}
				})
				if(!id){
					equipLocations = document.getElementsByClassName('mobile-equipmentlocation')
					for(let a=0; a <equipLocations.length; a++) {
						$(equipLocations[a]).empty().append(optionData)
					}
				}
				else{
				$(`#${id}`).empty().append(optionData)
			}
			})
		},

		populateEmployeeSelect: (id) =>  {
			userEmployeeSelectCachePromise().then((userEmployeeSelectData)=>{
				let employeelist = userEmployeeSelectData
				let user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'			
				let jobIDSelected = document.getElementById('job_number').value		
				employeeSelects = document.getElementsByClassName('mobile-employee-select')
				let optionData = ``
				if(user_visibility == 'all'){
					employeelist.forEach((data)=>{
						optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
					})
				}
				else{
					employeelist.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs!== undefined && data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
							}
						}
					})
				}				
				if(id === 'level' || !id){			
					for(let a=0; a <employeeSelects.length; a++) {
						if(id === 'level' && $(employeeSelects[a]).find(":selected").text()){
							$(employeeSelects[a]).append(optionData)
						}	
						else{
							$(employeeSelects[a]).empty().append(optionData)
						}
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
				reselectDraftSelectValues(employeeSelects)
			})

		},

		populateEmployeeSelectSingle: (id) =>  {
			userEmployeeSelectCachePromise().then((userEmployeeSelectData)=>{
				let employeelist = userEmployeeSelectData
				let user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility') : 'all'
				let jobIDSelected = document.getElementById('job_number').value					
				employeeSelects = document.getElementsByClassName('mobile-employee-select-single')
				if(id && id!='level'){					
					let idName=id.split("_")
					idName.pop()
					let idStartWith=idName.join('_')
					let employeeSelectsArray=[]
					for(employeeSelect of employeeSelects){
						if(employeeSelect.id.startsWith(idStartWith)){
							employeeSelectsArray.push(employeeSelect)
						}
					}
					employeeSelects=employeeSelectsArray
				}
				let optionData = `<option></option>`
				if(user_visibility == 'all'){
					employeelist.forEach((data)=>{
						optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
					})
				}
				else{
					employeelist.forEach((data)=>{
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs!== undefined && data.employee_jobs.split(',').includes(jobIDSelected.toString())) {
								optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
							}
						}
					})
				}
				if(id=='level' || !id){
					for(let a=0; a <employeeSelects.length; a++) {
						if(id=='level' && $(employeeSelects[a]).find(":selected").text()){
							$(employeeSelects[a]).append(optionData)
						}	
						else{
							$(employeeSelects[a]).empty().append(optionData)
						}	
					}
				}				
				else{
					$(`#${id}`).empty().append(optionData)
				}

				if(!(id && id!='level')){	
					reselectDraftSelectValues(employeeSelects)
				}

				return true
			})
		},

		populateEmployeeSelectWithOther:() => {
			let employeelist = userEmployeeSelectData
			let user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'			
			let jobIDSelected = document.getElementById('job_number').value
			employeeSelects = document.getElementsByClassName('mobile-employee-select-other')
			for(let a=0; a <employeeSelects.length; a++) {
				let optionData = ``
				employeelist.forEach((data)=>{
					optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
				})
				$(employeeSelects[a]).empty().append(optionData)
				$(employeeSelects[a]).append(`<option value = "Other">Other</option>`)
			}
			for(let a=0; a <employeeSelects.length; a++) {
				let optionData = ``
				if(user_visibility == 'all'){
					employeelist.forEach((data) => {
						optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
					})
					$(employeeSelects[a]).empty().append(optionData)
					$(employeeSelects[a]).append(`<option value = "Other">Other</option>`)
				}
				else{
					employeelist.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs!== undefined && data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
							}
						}
					})
					$(employeeSelects[a]).empty().append(optionData)
					$(employeeSelects[a]).append(`<option value = "Other">Other</option>`)
				}
			}
		},

		populateEmployeeSelectID: () =>  {
			let employeelist = userEmployeeSelectData
			let user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'			
			let jobIDSelected = document.getElementById('job_number').value	
			employeeSelects = document.getElementsByClassName('mobile-employee-select-id')
			for(let a=0; a <employeeSelects.length; a++) {
				let optionData = ``
				if(user_visibility == 'all'){
					employeelist.forEach((data)=>{
						optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
					})
					$(employeeSelects[a]).empty().append(optionData)
				}
				else{
					employeelist.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs!== undefined && data.employee_jobs.split(',').includes(jobIDSelected.toString())) {
								optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
							}
						}
					})
					$(employeeSelects[a]).empty().append(optionData)
				}
			}
		},

		populateEmployeeSelectIDSingle: () =>  {
			let employeelist = userEmployeeSelectData
			let user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'			
			let jobIDSelected = document.getElementById('job_number').value	
			employeeSelects = document.getElementsByClassName('mobile-employee-select-id-single')
			for(let a=0; a <employeeSelects.length; a++) {
				let optionData = `<option></option>`
				if(user_visibility == 'all'){
					employeelist.forEach((data)=>{
						optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
					})
					$(employeeSelects[a]).empty().append(optionData)
				}
				else{
					employeelist.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs!== undefined && data.employee_jobs.split(',').includes(jobIDSelected.toString())) {
								optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
							}
						}
					})
					$(employeeSelects[a]).empty().append(optionData)
				}
			}
		},

		populateEmployeeModalSelect: () =>  {
			let employeelist = userEmployeeSelectData
			let user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'			
			let jobIDSelected = document.getElementById('job_number').value
			employeeSelects = document.getElementsByClassName('modal-employee-select')
			for(let a=0; a <employeeSelects.length; a++) {
				let optionData = ``
				if(user_visibility == 'all'){
					employeelist.forEach((data)=>{
						optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
					})
					$(employeeSelects[a]).empty().append(optionData)
				}
				else{
					employeelist.forEach((data)=>{
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`
							}
						}
					})
					$(employeeSelects[a]).empty().append(optionData)
				}
			}
		},

		populateSupervisorSelect: () =>  {
			let supervisor_list = userSupervisorSelectData
			let user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'
			let jobIDSelected = document.getElementById('job_number').value
			superSelects = document.getElementsByClassName('mobile-supervisors-select')
			for(let a=0; a <superSelects.length; a++) {
				let optionData = `<option></option>`
				if(user_visibility == 'all'){
					supervisor_list.forEach((data) => {
					optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
					})
					$(superSelects[a]).parent().find('label').removeClass('active filled')
					$(superSelects[a]).empty().append(optionData)
				}
				else{
					supervisor_list.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
							}  
						}
					})
					$(superSelects[a]).parent().find('label').removeClass('active filled')
					$(superSelects[a]).empty().append(optionData)
				}
			}
		},

		populateSupervisorIDSelect: () =>  {
			let supervisor_list = userSupervisorSelectData
			let user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'
			let jobIDSelected = document.getElementById('job_number').value
			superSelects = document.getElementsByClassName('mobile-supervisor_id-select')
			for(let a=0; a <superSelects.length; a++) {
				$(superSelects[a]).parent().find('label').removeClass('active filled')
				let optionData = `<option></option>`
				if(user_visibility == 'all'){
					supervisor_list.forEach((data)=>{
						optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`						
					})		
					$(superSelects[a]).empty().append(optionData)
				}
				else{
					supervisor_list.forEach((data)=>{	
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`							
						}
						else{
							if(data.employee_jobs!== undefined && data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.per_id}">${data.per_full_name}</option>`								
							}
						}
					})				
					$(superSelects[a]).empty().append(optionData)
				}
			}	
		},	

		populateRotationDaysSelect: () =>  {
			let dorlist = selectListData.ref_days_of_rotation || []
			dorSelects = document.getElementsByClassName('mobile-daysofrotation-select')
			for(let a=0; a <dorSelects.length; a++) {
				let optionData = ``
				dorlist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(dorSelects[a]).empty().append(optionData)
			}
		},


		populateHoursSummarySelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				let hslist = selectListData.ref_hours_summary || []
				hslist.sort((a,b) => (parseInt(a.rld_name) > parseInt(b.rld_name)) ? 1 : ((parseInt(b.rld_name) > parseInt(a.rld_name)) ? -1 : 0))
				let optionData = `<option></option>`
					hslist.forEach((data)=>{
						optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
					})
				if(!id){
					hsSelects = document.getElementsByClassName('mobile-hourssummary-select')
					for(let a=0; a <hsSelects.length; a++) {
						$(hsSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},

		populateEmployeePositionSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				let eplist = selectListData.ref_position || []
				let optionData = `<option></option>`
					eplist.forEach((data)=>{
						optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
					})
				if(!id){
					epSelects = document.getElementsByClassName('mobile-employeeposition-select')
					for(let a=0; a < epSelects.length; a++) {
						$(epSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},

		populateEmployeeOccupationSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				let occlist = selectListData.ref_occupation || []
				let optionData = `<option></option>`
					occlist.forEach((data)=>{
						optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
					})
				if(!id){
					occSelects = document.getElementsByClassName('mobile-employeeoccupation-select')
					for(let a=0; a < occSelects.length; a++) {
						$(occSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},

		populateDurationSelect: () =>  {
			let durlist = selectListData.ref_duration || []
			durSelects = document.getElementsByClassName('mobile-duration-select')
			for(let a=0; a <durSelects.length; a++) {
				let optionData = ``
				durlist.forEach((data)=>{
					optionData += `<option value="${data.rld_code}">${data.rld_name}</option>`
				})
				$(durSelects[a]).empty().append(optionData)
			}
		},	

		populateDistributionSelect: () => {
			let external_group_distribution_list = selectListData.distributionList || []
			let distribution_list = userDistributionSelectData
			let user_visibility = localStorage.getItem('employeeVisibility')?localStorage.getItem('employeeVisibility'):'all'
			let jobIDSelected = document.getElementById('job_number').value
			distribution_list = distribution_list.concat(external_group_distribution_list)

			distributionGroupList=[]
			distributionSelects = document.getElementsByClassName('mobile-distribution-select')

			if($('#job_number').val() == "") {
				for(let a=0; a <distributionSelects.length; a++) {
					$(distributionSelects[a]).empty()
				}
				return
			}
			let collator = new Intl.Collator('en-ca');

			distribution_list.sort(function (a, b){
				return collator.compare(a.per_full_name, b.per_full_name)
			})

			for(let a=0; a <distributionSelects.length; a++) {
				let optionData = ``
				if(user_visibility == 'all'){
					distribution_list.forEach((data)=>{
						if(data.email.includes(',')){
							distributionGroupList.push(data)
						}
						optionData += `<option value="${data.email}">${data.per_full_name}</option>`
					})
					$(distributionSelects[a]).empty().append(optionData)
				}
				else{
					distribution_list.forEach((data)=>{	
						if(data.email.includes(',')){
							distributionGroupList.push(data)
						}
						if(data.emp_data_visibility === 'all'){
							optionData += `<option value="${data.email}">${data.per_full_name}</option>`
						}
						else{
							if(data.employee_jobs!== undefined &&  data.employee_jobs.split(',').includes(jobIDSelected.toString())){
								optionData += `<option value="${data.email}">${data.per_full_name}</option>`
							}  
						}
					})
					$(distributionSelects[a]).empty().append(optionData)
				}
			}
		},

		populateActionTypeSelect: () =>  {
			let actTypelist = selectListData.ref_action_type || []
			actTypeSelects = document.getElementsByClassName('mobile-actiontype-select')
			for(let a=0; a <actTypeSelects.length; a++) {
				let optionData = ``
				actTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(actTypeSelects[a]).empty().append(optionData)
			}
		},

		populateActionTypeScoreSelect: () =>  {
			let actTypelist = selectListData.ref_action_type || []
			actTypeSelects = document.getElementsByClassName('mobile-actiontypescore-select')
			for(let a=0; a <actTypeSelects.length; a++) {
				let optionData = ``
				actTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_id}|${data.rld_score}">${data.rld_name}</option>`
				})
				$(actTypeSelects[a]).empty().append(optionData)
			}
		},

		populateHazardTypeSelect: () =>  {
			let hazardTypelist = selectListData.ref_hazard_type || []
			hazardTypeSelects = document.getElementsByClassName('mobile-hazardtype-select')
			for(let a=0; a <hazardTypeSelects.length; a++) {
				let optionData = ``
				hazardTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
				})
				$(hazardTypeSelects[a]).empty().append(optionData)
			}
		},

		populateHazardIDSelect: () =>  {
			let hazardIDlist = selectListData.ref_hazard_identification || []
			hazardIDSelects = document.getElementsByClassName('mobile-hazardid-select')
			for(let a=0; a <hazardIDSelects.length; a++) {
				let optionData = ``
				hazardIDlist.forEach((data)=>{
					optionData += `<option value="${data.rld_id}|${data.rld_score}">${data.rld_name}</option>`
				})
				$(hazardIDSelects[a]).empty().append(optionData)
			}
		},

		populateHazardTopicSelect: () =>  {
			let hazardIDlist = selectListData.ref_hazard_identification || []
			hazardIDSelects = document.getElementsByClassName('mobile-hazardtopic-select')
			for(let a=0; a <hazardIDSelects.length; a++) {
				let optionData = ``
				hazardIDlist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(hazardIDSelects[a]).empty().append(optionData)
			}
		},		

		populatePotentialLossSelect: () =>  {
			let potentialLosslist = selectListData.ref_potential_loss || []
			potentialLossSelects = document.getElementsByClassName('mobile-potentialloss-select')
			for(let a=0; a <potentialLossSelects.length; a++) {
				let optionData = ``
				potentialLosslist.forEach((data)=>{
					optionData += `<option value="${data.rld_id}|${data.rld_score}">${data.rld_name}</option>`
				})
				$(potentialLossSelects[a]).empty().append(optionData)
			}

		},

		populateGeneralActionSelect: () =>  {
			let generalActionslist = selectListData.ref_general_action || []
			generalActionsSelects = document.getElementsByClassName('mobile-generalactions-select')
			for(let a=0; a <generalActionsSelects.length; a++) {
				let optionData = ``
				generalActionslist.forEach((data)=>{
					optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
				})
				$(generalActionsSelects[a]).empty().append(optionData)
			}

		},

		populateDemoReasonSelect: () =>  {
			let demoReasonlist = selectListData.ref_demonstration_reason || []
			demoReasonSelects = document.getElementsByClassName('mobile-demoreason-select')
			for(let a=0; a <demoReasonSelects.length; a++) {
				let optionData = ``
				demoReasonlist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(demoReasonSelects[a]).empty().append(optionData)
			}
		},

		populateTrainingAuditTypesSelect: () =>  {
			let trainingAuditTypeslist = selectListData.ref_training_audit_type || []
			trainingAuditTypesSelects = document.getElementsByClassName('mobile-trainingauditypes-select')
			for(let a=0; a <trainingAuditTypesSelects.length; a++) {
				let optionData = ``
				trainingAuditTypeslist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(trainingAuditTypesSelects[a]).empty().append(optionData)
			}
		},

		populateContextSelect: () =>  {
			let contextlist = selectListData.ref_context || []
			contextSelects = document.getElementsByClassName('mobile-context-select')
			for(let a=0; a <contextSelects.length; a++) {
				let optionData = ``
				contextlist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(contextSelects[a]).empty().append(optionData)
			}
		},

		populateContentSelect: () =>  {
			let contentlist = selectListData.ref_content || []
			contentSelects = document.getElementsByClassName('mobile-content-select')
			for(let a=0; a <contentSelects.length; a++) {
				let optionData = ``
				contentlist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(contentSelects[a]).empty().append(optionData)
			}
		},

		populateInspectionType: () =>  {
			let inspectionTypelist = selectListData.ref_inspection_type || []
			inspectionTypeSelects = document.getElementsByClassName('mobile-inspectiontype-select')
			for(let a=0; a < inspectionTypeSelects.length; a++) {
				let optionData = ``
				inspectionTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(inspectionTypeSelects[a]).empty().append(optionData)
			}
		},

		populateEventShiftScheduleSelect: () =>  {
			let eventShiftlist = selectListData.ref_event_shift_schedule || []
			eventShiftSelects = document.getElementsByClassName('mobile-eventshiftschedule-select')
			for(let a=0; a < eventShiftSelects.length; a++) {
				let optionData = ``
				eventShiftlist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(eventShiftSelects[a]).empty().append(optionData)
			}
		},

		populateIncidentTypesSelect: () =>  {
			let incidentTypeslist = selectListData.ref_incident_type || []
			incidentTypesSelects = document.getElementsByClassName('mobile-incidenttypes-select')
			for(let a=0; a < incidentTypesSelects.length; a++) {
				let optionData = ``
				incidentTypeslist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(incidentTypesSelects[a]).empty().append(optionData)
			}
		},		

		populateTopicTypeSelect: () =>  {
			let topicTypelist = selectListData.ref_topic_type || []
			topicTypeSelects = document.getElementsByClassName('mobile-topictype-select')
			for(let a=0; a <topicTypeSelects.length; a++) {
				let optionData = ``
				topicTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(topicTypeSelects[a]).empty().append(optionData)
			}
		},

		populatePreliminaryIncidentType: () => 	{
			let preIncTypelist = selectListData.ref_preliminary_incident_type || []
			preIncTypeSelects = document.getElementsByClassName('mobile-preliminaryincidentype-select')
			for(let a=0; a < preIncTypeSelects.length; a++) {
				let optionData = ``
				preIncTypelist.forEach((data)=>{
					optionData += `<option code="${data.rld_id}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(preIncTypeSelects[a]).empty().append(optionData)
			}
		},

		populatePreliminaryIncidentTypeCategory: (PreIncidentType) => {
			document.getElementById('formmisc').value = PreIncidentType.value
			preIncTypeCatSelects = document.getElementsByClassName('mobile-preliminaryincidentypecategory-select')
			if(PreIncidentType.selectedIndex == -1) {
				$(preIncTypeCatSelects).empty()
				return
			}

			incidentTypeHolder = PreIncidentType.options[PreIncidentType.selectedIndex].getAttribute('code')
			let preIncTypeCatlist = selectListData.ref_preliminary_incident_type_category || []
			for(let a=0; a < preIncTypeCatSelects.length; a++) {
				let optionData = ``
				preIncTypeCatlist.forEach((data)=>{
					if(parseInt(data.rld_parent_detail_rld_id) == parseInt(incidentTypeHolder)) {
						optionData += `<option code="${incidentTypeHolder}" value="${data.rld_name}">${data.rld_name}</option>`
					}
				})
				$(preIncTypeCatSelects[a]).empty().append(optionData)
			}
		},

		populatePreliminaryIncidentTypeDetail: (PreIncidentCat) => {
			preIncTypeDetSelects = document.getElementsByClassName('mobile-preliminaryincidentypedetail-select')
			if(PreIncidentCat.selectedIndex == -1) {
				$(preIncTypeDetSelects).empty()
				return
			}

			incidentTypeHolder = PreIncidentCat.options[PreIncidentCat.selectedIndex].getAttribute('code')
			let preIncTypeDetlist = selectListData.ref_preliminary_incident_type_detail || []
			
			for(let a=0; a < preIncTypeDetSelects.length; a++) {
				let optionData = ``
				preIncTypeDetlist.forEach((data)=>{
					if(parseInt(data.rld_parent_detail_rld_id) == parseInt(incidentTypeHolder)) {
						optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
					}
				})
				$(preIncTypeDetSelects[a]).empty().append(optionData)
			}
		},

		populateClimateSelect: () =>  {
			let climateTypelist = selectListData.ref_climate || []
			climateTypeSelects = document.getElementsByClassName('mobile-climate-select')
			for(let a=0; a <climateTypeSelects.length; a++) {
				let optionData = ``
				climateTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(climateTypeSelects[a]).empty().append(optionData)
			}
		},

		populateClassificationSelect: () =>  {
			let classificationTypelist = selectListData.ref_classification || []
			classificationTypeSelects = document.getElementsByClassName('mobile-classification-select')
			for(let a=0; a < classificationTypeSelects.length; a++) {
				let optionData = ``
				classificationTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(classificationTypeSelects[a]).empty().append(optionData)
			}
		},

		populateInvolvementSelect: () =>  {
			let involvementTypelist = selectListData.ref_involvement || []
			involvementTypeSelects = document.getElementsByClassName('mobile-involvement-select')
			for(let a=0; a < involvementTypeSelects.length; a++) {
				let optionData = ``
				involvementTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(involvementTypeSelects[a]).empty().append(optionData)
			}
		},

		populateWorkrestSelect: () =>  {
			let workrestTypelist = selectListData.ref_work_rest_established || []
			workrestTypeSelects = document.getElementsByClassName('mobile-workrest-select')
			for(let a=0; a < workrestTypeSelects.length; a++) {
				let optionData = ``
				workrestTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(workrestTypeSelects[a]).empty().append(optionData)
			}
		},

		populatePreparationSelect: () =>  {
			let preparationTypelist = selectListData.ref_preparation || []
			preparationTypeSelects = document.getElementsByClassName('mobile-preparation-select')
			for(let a=0; a < preparationTypeSelects.length; a++) {
				let optionData = ``
				preparationTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(preparationTypeSelects[a]).empty().append(optionData)
			}
		},

		populateTestingSelect: () =>  {
			let testingTypelist = selectListData.ref_testing || []
			testingTypeSelects = document.getElementsByClassName('mobile-testing-select')
			for(let a=0; a < testingTypeSelects.length; a++) {
				let optionData = ``
				testingTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(testingTypeSelects[a]).empty().append(optionData)
			}
		},

		populateKnowledgeSelect: () =>  {
			let knowledgeTypelist = selectListData.ref_knowledge || []
			knowledgeTypeSelects = document.getElementsByClassName('mobile-knowledge-select')
			for(let a=0; a < knowledgeTypeSelects.length; a++) {
				let optionData = ``
				knowledgeTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(knowledgeTypeSelects[a]).empty().append(optionData)
			}
		},

		populateShiftSelect: () =>  {
			let shiftTypelist = selectListData.ref_shift || []
			shiftTypeSelects = document.getElementsByClassName('mobile-shift-select')
			for(let a=0; a < shiftTypeSelects.length; a++) {
				let optionData = ``
				shiftTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(shiftTypeSelects[a]).empty().append(optionData)
			}
		},

		populateAuditTypeSelect: () =>  {
			let audittypeTypelist = selectListData.ref_audit_type || []
			audittypeTypeSelects = document.getElementsByClassName('mobile-audittype-select')
			for(let a=0; a < audittypeTypeSelects.length; a++) {
				let optionData = ``
				audittypeTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(audittypeTypeSelects[a]).empty().append(optionData)
			}
		},	

		populateRecordStatusSelect: () =>  {
			let recordstatusTypelist = selectListData.ref_record_status || []
			recordstatusTypeSelects = document.getElementsByClassName('mobile-recordstatus-select')
			for(let a=0; a < recordstatusTypeSelects.length; a++) {
				let optionData = ``
				recordstatusTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(recordstatusTypeSelects[a]).empty().append(optionData)
			}
		},

		populateHotWorkTypeSelect: () =>  {
			let recordHotWorkTypelist = selectListData.ref_hot_work_type || []
			recordHotWorkTypeSelects = document.getElementsByClassName('mobile-hotworktype-select')
			for(let a=0; a < recordHotWorkTypeSelects.length; a++) {
				let optionData = ``
				recordHotWorkTypelist.forEach((data)=>{
					optionData += `<option class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(recordHotWorkTypeSelects[a]).empty().append(optionData)
			}
		},

		populateHotWorkHazardsSelect: () =>  {
			let recordHotWorkHazardslist = selectListData.ref_hot_work_hazards || []
			recordHotWorkHazardsSelects = document.getElementsByClassName('mobile-hotworkhazardstype-select')
			for(let a=0; a < recordHotWorkHazardsSelects.length; a++) {
				let optionData = ``
				recordHotWorkHazardslist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(recordHotWorkHazardsSelects[a]).empty().append(optionData)
			}
		},

		populateDetermineControlsSelect: () =>  {
			let recordDetermineControlslist = selectListData.ref_determine_controls_equipment || []
			recordDetermineControlsSelects = document.getElementsByClassName('mobile-determinecontrols-select')
			for(let a=0; a < recordDetermineControlsSelects.length; a++) {
				let optionData = ``
				recordDetermineControlslist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(recordDetermineControlsSelects[a]).empty().append(optionData)
			}
		},

		populateSpecialPPEsSelect: () =>  {
			let recordSpecialPPElist = selectListData.ref_personal_protective_equipment || []
			recordSpecialPPESelects = document.getElementsByClassName('mobile-personalprotectiveequipment-select')
			for(let a=0; a < recordSpecialPPESelects.length; a++) {
				let optionData = ``
				recordSpecialPPElist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(recordSpecialPPESelects[a]).empty().append(optionData)
			}
		},

		populateHighRiskPrecautionsSelect: () =>  {
			let recordHighRiskPrecautionslist = selectListData.ref_high_risk_precautions || []
			recordHighRiskPrecautionsSelects = document.getElementsByClassName('mobile-highriskprecautions-select')
			for(let a=0; a < recordHighRiskPrecautionsSelects.length; a++) {
				let optionData = ``
				recordHighRiskPrecautionslist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(recordHighRiskPrecautionsSelects[a]).empty().append(optionData)
			}
		},

		populateRetrievalEquipmentSelect: () =>  {
			let retrievalEquipmentlist = selectListData.ref_rescue_plan_retrieval_equipment || []
			retrievalEquipmentSelects = document.getElementsByClassName('mobile-retrievalEquipmentList-select')
			for(let a=0; a < retrievalEquipmentSelects.length; a++) {
				let optionData = ``
				retrievalEquipmentlist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(retrievalEquipmentSelects[a]).empty().append(optionData)
			}
		},

		populateRetrievalSpecialPPESelect: () =>  {
			let retrievalSpecialPPElist = selectListData.ref_rescue_special_ppe || []
			retrievalSpecialPPESelects = document.getElementsByClassName('mobile-retrievalSpecialPPEList-select')
			for(let a=0; a < retrievalSpecialPPESelects.length; a++) {
				let optionData = ``
				retrievalSpecialPPElist.forEach((data)=>{
					optionData += `<option  class="${(data.rld_option==1)?'other':(data.rld_option==2)?'saba':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(retrievalSpecialPPESelects[a]).empty().append(optionData)
			}
		},

		populateRecognitionTypeSelect: () =>  {
			let recognitionType = selectListData.ref_recognition_type || []
			recognitionSelects = document.getElementsByClassName('mobile-recognitiontype-select')
			for(let a=0; a <recognitionSelects.length; a++) {
				let optionData = ``
				recognitionType.forEach((data)=>{
					optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
					})
				$(recognitionSelects[a]).empty().append(optionData)
			}
		},

		populateRecognitionGivenTypeSelect: () =>  {
			let recognitionGivenType = selectListData.ref_recognition_given || []
			recognitionGivenSelects = document.getElementsByClassName('mobile-recognitiongiventype-select')
			for(let a=0; a <recognitionGivenSelects.length; a++) {
				let optionData = ``
				recognitionGivenType.forEach((data)=>{
					optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
					})
				$(recognitionGivenSelects[a]).empty().append(optionData)
			}
		},

		populateHazardsPresentSelect: () =>  {
			let retrievalHazardsPresentlist = selectListData.ref_hazards_present_rp || []
			retrievalHazardsPresentSelects = document.getElementsByClassName('mobile-retrievalHazardsPresentList-select')
			for(let a=0; a < retrievalSpecialPPESelects.length; a++) {
				let optionData = ``
				retrievalHazardsPresentlist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
					})
				$(retrievalHazardsPresentSelects[a]).empty().append(optionData)
			}
		},

		populateRescueTypeSelect: () =>  {
			let retrievalRescueTypelist = selectListData.ref_rescue_type || []
			retrievalRescueTypeSelects = document.getElementsByClassName('mobile-retrievalRescueTypeList-select')
			for(let a=0; a < retrievalRescueTypeSelects.length; a++) {
				let optionData = ``
				retrievalRescueTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
					})
				$(retrievalRescueTypeSelects[a]).empty().append(optionData)
			}
		},

		populateCommunicationStrategySelect: () =>  {
			let retrievalCommunicationStrategylist = selectListData.ref_communication_strategy || []
			retrievalCommunicationStrategySelects = document.getElementsByClassName('mobile-retrievalCommunicationStrategyList-select')
			for(let a=0; a < retrievalCommunicationStrategySelects.length; a++) {
				let optionData = ``
				retrievalCommunicationStrategylist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(retrievalCommunicationStrategySelects[a]).empty().append(optionData)
			}
		},

		populateKeyContactsSelect: () =>  {
			let retrievalKeyContactslist = selectListData.ref_key_contacts_rp || []
			retrievalKeyContactsSelects = document.getElementsByClassName('mobile-retrievalKeyContactsList-select')
			for(let a=0; a < retrievalKeyContactsSelects.length; a++) {
				let optionData = ``
				retrievalKeyContactslist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(retrievalKeyContactsSelects[a]).empty().append(optionData)
			}
		},

		populatePotentialHazardsSelect: () =>  {
			let potentialhazardTypelist = selectListData.ref_potential_hazards_wh || []
			potentialhazardsTypeSelects = document.getElementsByClassName('mobile-potentialhazards-select')
			for(let a=0; a < potentialhazardsTypeSelects.length; a++) {
				let optionData = ``
				potentialhazardTypelist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(potentialhazardsTypeSelects[a]).empty().append(optionData)
			}
		},

		populateDetermineControlsEquipmentWHSelect: () =>  {
			let determinecontrolsequipmentTypelist = selectListData.ref_determine_controls_wh || []
			determinecontrolsequipmentTypeSelects = document.getElementsByClassName('mobile-determinecontrolsequipment-select')
			for(let a=0; a < determinecontrolsequipmentTypeSelects.length; a++) {
				let optionData = ``
				determinecontrolsequipmentTypelist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(determinecontrolsequipmentTypeSelects[a]).empty().append(optionData)
			}
		},

		populateWorkCardTypeSelect: () =>  {
			let workcardTypelist = selectListData.ref_work_card_type || []
			workcardTypeSelects = document.getElementsByClassName('mobile-workcardTtype-select')
			for(let a=0; a < workcardTypeSelects.length; a++) {
				let optionData = ``
				workcardTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(workcardTypeSelects[a]).empty().append(optionData)
			}
		},

		populateWorkAccomplishedSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				let workAccomplishedlist = selectListData.ref_work_accomplished || []
				let optionData = `<option></option>`
					workAccomplishedlist.forEach((data)=>{
						optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
					})
				if(!id){
					workAccomplishedSelects = document.getElementsByClassName('mobile-workAccomplished-select')
					for(let a=0; a < workAccomplishedSelects.length; a++) {			
						$(workAccomplishedSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},

		populateWorkingAtHeightsSpecialPPESelect: () =>  {
			let workingatheightsspecialppeTypelist = selectListData.ref_special_ppe_wh || []
			workingatheightsspecialppeTypeSelects = document.getElementsByClassName('mobile-workingatheightsspecialppe-select')
			for(let a=0; a < workingatheightsspecialppeTypeSelects.length; a++) {
				let optionData = ``
				workingatheightsspecialppeTypelist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(workingatheightsspecialppeTypeSelects[a]).empty().append(optionData)
			}
		},

		populateAMTaskContractSelect: (id) =>  {
			let amtaskcontractTypelist = selectListData.ref_am_task_contract || []
			let optionData =`<option></option>`
				amtaskcontractTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
			if(!id){
				amtaskcontractTypeSelects = document.getElementsByClassName('mobile-amtaskcontract-select')
				for(let a=0; a < amtaskcontractTypeSelects.length; a++) {
					$(amtaskcontractTypeSelects[a]).empty().append(optionData)
				}
			}
			else{
				$(`#${id}`).empty().append(optionData)
			}
		},

		populateAMTaskTypeSelect: (id) =>  {
			let amtasktypeTypelist = selectListData.ref_am_task_type || []
			let optionData = `<option></option>`
				amtasktypeTypelist.forEach((data)=>{
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				})
			if(!id){
				amtasktypeTypeSelects = document.getElementsByClassName('mobile-amtasktype-select')
				for(let a=0; a < amtasktypeTypeSelects.length; a++) {			
					$(amtasktypeTypeSelects[a]).empty().append(optionData)
				}
			}
			else{
				$(`#${id}`).empty().append(optionData)
			}
		},

		populateAMSuppliesLocationSelect: (selectedSite,id) =>  {
			let selectSiteHolder = ""
			if(selectedSite.selectedIndex >= 0) {
				selectSiteHolder = selectedSite.options[selectedSite.selectedIndex].getAttribute('site')
			}
			let amsupplieslocationTypelist = selectListData.ref_am_supplies_location || []
			let optionData = ``
			optionData += `<option></option>`
			amsupplieslocationTypelist.forEach((data)=>{
				if(data.rld_parent_detail_rld_id == selectSiteHolder){
					optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
				} 
			})
			if(!id){
				amsupplieslocationTypeSelects = document.getElementsByClassName('mobile-amsupplieslocation-select')
				for(let a=0; a < amsupplieslocationTypeSelects.length; a++) {
						$(amsupplieslocationTypeSelects[a]).empty().append(optionData)
				}
			}
			else{
				$(`#${id}`).empty().append(optionData)
			}
		},

		populateAMSuppliesTypeSelect: (id) =>  {
			let amsuppliestypeTypelist = selectListData.ref_am_supplies_type || []
			let optionData = `<option></option>`
			amsuppliestypeTypelist.forEach((data)=>{
				optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
			})
			if(!id){
				amsuppliestypeTypeSelects = document.getElementsByClassName('mobile-amsuppliestype-select')
				for(let a=0; a < amsuppliestypeTypeSelects.length; a++) {
					$(amsuppliestypeTypeSelects[a]).empty().append(optionData)
				}
			}
			else{			
				$(`#${id}`).empty().append(optionData)
			}
		},

		populateRuleBreakingSelect: () =>  {
			let ruleBreakinglist = selectListData.ref_rule_breaking || []
			ruleBreakingSelects = document.getElementsByClassName('mobile-rule-breaking-select')
			for(let a=0; a <ruleBreakingSelects.length; a++) {
				let optionData = ``
				ruleBreakinglist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				$(ruleBreakingSelects[a]).empty().append(optionData)
			}
		},

		populateSanctionTypeSelect: () =>  {
			let sanctionTypelist = selectListData.ref_sanctions || []
			sanctionTypeSelects = document.getElementsByClassName('mobile-sanction-type-select')
			for(let a=0; a <sanctionTypeSelects.length; a++) {
				let optionData = ``
				sanctionTypelist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
					})
					$(sanctionTypeSelects[a]).empty().append(optionData)
			}
		},

		populateServiceTypeSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				let recordServiceTypelist = selectListData.ref_service_type || []
				let optionData = `<option></option>`
				recordServiceTypelist.forEach((data)=>{
					optionData += `<option class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				if(!id){
					recordServiceTypeSelects = document.getElementsByClassName('mobile-servicetype-select')
					for(let a=0; a < recordServiceTypeSelects.length; a++) {				
						$(recordServiceTypeSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},

		populateEquipmentStatusSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				let recordEquipmentStatuslist = selectListData.ref_equipment_status || []
				let optionData = `<option></option>`
				recordEquipmentStatuslist.forEach((data)=>{
					optionData += `<option class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
				})
				if(!id){
					recordEquipmentStatusSelects = document.getElementsByClassName('mobile-equipment-status-select')
					for(let a=0; a < recordEquipmentStatusSelects.length; a++) {		
						$(recordEquipmentStatusSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},

		populateDrillingTimeDelaysCodeSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				let drillingtimeanddelayscodelist = selectListData.ref_drilling_time_and_delays_code || []
				let optionData =`<option></option>`
				drillingtimeanddelayscodelist.forEach((data)=>{
						optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
					})
				if(!id){
					drillingtimeanddelayscodeSelects = document.getElementsByClassName('mobile-drillingtimeanddelayscode-select')
					for(let a=0; a < drillingtimeanddelayscodeSelects.length; a++) {
						$(drillingtimeanddelayscodeSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},
		
		populateDrillingCodeSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				let drillingcodelist = selectListData.ref_drilling_code || []
				let optionData =`<option></option>`
				drillingcodelist.forEach((data)=>{
						optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
					})
				if(!id){
					drillingcodeSelects = document.getElementsByClassName('mobile-drillingcode-select')
					for(let a=0; a < drillingcodeSelects.length; a++) {
						$(drillingcodeSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},

		populateStatusCodeSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				let statuscodelist = selectListData.ref_drilling_status_code || []
				let optionData =`<option></option>`
				statuscodelist.forEach((data)=>{
						optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
					})
				if(!id){
					statuscodeSelects = document.getElementsByClassName('mobile-drillingStatuscode-select')
					for(let a=0; a < statuscodeSelects.length; a++) {
						$(statuscodeSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},

		populateDrillingLogCodeSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				let drillinglogcodelist = selectListData.ref_drilling_log_code || []
				let optionData =`<option></option>`
				drillinglogcodelist.forEach((data)=>{
						optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
					})
				if(!id){
					drillinglogcodeSelects = document.getElementsByClassName('mobile-drillinglogcode-select')
					for(let a=0; a < drillinglogcodeSelects.length; a++) {
						$(drillinglogcodeSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},

		populateDrillingBitSizeSelect: (id) =>  {
			selectCachePromise().then((selectListData)=> {
				let drillingbitsizelist = selectListData.ref_drilling_bit_size || []
				let optionData =`<option></option>`
				drillingbitsizelist.forEach((data)=>{
						optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
					})
				if(!id){
					drillingbitsizeSelects = document.getElementsByClassName('mobile-drillingbitsize-select')
					for(let a=0; a < drillingbitsizeSelects.length; a++) {
						$(drillingbitsizeSelects[a]).empty().append(optionData)
					}
				}
				else{
					$(`#${id}`).empty().append(optionData)
				}
			})
		},
		
		populateDrillingMaterialUsedSelect: (id) =>  {
			let drillingmaterialusedlist = selectListData.ref_drilling_material_used || []
			let optionData =`<option></option>`
			drillingmaterialusedlist.forEach((data)=>{
					optionData += `<option value="${data.rld_id}">${data.rld_name}</option>`
				})
			if(!id){
				drillingmaterialusedSelects = document.getElementsByClassName('mobile-drillingmaterialused-select')
				for(let a=0; a < drillingmaterialusedSelects.length; a++) {
					$(drillingmaterialusedSelects[a]).empty().append(optionData)
				}
			}
			else{
				$(`#${id}`).empty().append(optionData)
			}
		},

		populateInterventionTypeSelect: () =>  {
			let interventionTypelist = selectListData.ref_type_intervention || []
			interventionTypeSelects = document.getElementsByClassName('mobile-intervention-type-select')
			for(let a=0; a <interventionTypeSelects.length; a++) {
				let optionData = `<option></option>`
				interventionTypelist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_id}">${data.rld_name}</option>`
					})
					$(interventionTypeSelects[a]).empty().append(optionData)
			}
		},

		populateLotoEquipmentListSelect: () =>  {
			lotoEquipmentPicsCachePromise().then(()=>{
				lotoEquipmentlist=lotoEquipmentPics || []
				lotoEquipmentSelects = document.getElementsByClassName('mobile-loto-equipment-select')
				for(let a=0; a <lotoEquipmentSelects.length; a++) {
					let optionData = `<option></option>`
					lotoEquipmentlist.forEach((data)=>{
						optionData += `<option  value="${data.lte_id}">${data.ltr_text}</option>`				
					})
					$(lotoEquipmentSelects[a]).empty().append(optionData)
				}
			})
		},		

		populateTemperaturelistSelect: () =>  {
			let temperaturelist = selectListData.ref_temperature || []
			temperatureSelects = document.getElementsByClassName('mobile-temperature-select')
			for(let a=0; a <temperatureSelects.length; a++) {
				let optionData = ``
				temperaturelist.forEach((data)=>{
					optionData += `<option  class="${data.rld_option?'other':''}" value="${data.rld_name}">${data.rld_name}</option>`
					})
					$(temperatureSelects[a]).empty().append(optionData)
			}
		},
        populateLOTOStatusListSelect: () => {
            let statusList = selectListData.ref_loto_status || []
            statusListSelect = document.getElementsByClassName('mobile-loto-status-select')
            let len = statusList.length
            for(let a = 0;a < len; a++){
                let optionData = ``
                statusList.forEach((data) => {
                    optionData +=`<option value="${data.rld_id}">${data.rld_name}</option>`
                })
                $(statusListSelect[a]).empty().append(optionData)
            }

        },
		formValidate: (theForm,mode = 'normal')	=> {
			// Validate the contents of the common form header
			let headerValidation = ''
			let headerValidated = `<li class="list-group-item"><strong><span class='translate' data-i18n="1404" notes="Validation Message"></span></strong></li>`
			if (theForm.submissionId.value == '')	{
				headerValidation += `<li>There is an issue with the Submission ID, please contact admin</li>`
			} 

			if(!theForm.startFormTimeStamp.value instanceof Date)	{
				headerValidation += `<li>There is an issue with the start date, please contact admin.</li>`
			}

			if(!theForm.endFormTimeStamp.value instanceof Date)	{
				headerValidation += `<li>There is an issue with the end date, please contact admin.</li>`
			}

			if(theForm.site.validity.valueMissing)	{
				headerValidation += `<li class="list-group-item"><span class='translate' data-i18n="828" notes="Site"></span><i class="fa fa-times red-text fa-lg pl-3"></i></li>`
			}
			else {
				headerValidated  += `<li class="list-group-item"><span class='translate' data-i18n="828" notes="Site"></span><i class="fa fa-check green-text fa-lg pl-3"></i></li>`
			}

			if(theForm.job_number.validity.valueMissing)	{
				headerValidation += `<li class="list-group-item"><span class='translate' data-i18n="617" notes="Job Number"></span><i class="fa fa-times red-text fa-lg pl-3"></i></li>`
			}
			else {
				headerValidated  += `<li class="list-group-item"><span class='translate' data-i18n="617" notes="Job Number"></span><i class="fa fa-check green-text fa-lg pl-3"></i></li>`
			}

			if(theForm.level.validity.valueMissing)	{
				headerValidation += `<li class="list-group-item"><span class='translate' data-i18n="621" notes="Level"></span><i class="fa fa-times red-text fa-lg pl-3"></i></li>`				
			}
			else {
				headerValidated  += `<li class="list-group-item"><span class='translate' data-i18n="621" notes="Level"></span><i class="fa fa-check green-text fa-lg pl-3"></i></li>`
			}

			if(theForm.workplace.validity.valueMissing)	{
				headerValidation += `<li class="list-group-item"><span class='translate' data-i18n="959" notes="Workplace"></span><i class="fa fa-times red-text fa-lg pl-3"></i></li>`
			}
			else {
				headerValidated  += `<li class="list-group-item"><span class='translate' data-i18n="959" notes="Workplace"></span><i class="fa fa-check green-text fa-lg pl-3"></i></li>`
			}

			if(theForm.supervisor.validity.valueMissing) {
				headerValidation += `<li class="list-group-item"><span class='translate' data-i18n="844" notes="Supervisor"></span><i class="fa fa-times red-text fa-lg pl-3"></i></li>`
			}
			else {
				headerValidated  += `<li class="list-group-item"><span class='translate' data-i18n="844" notes="Supervisor"></span><i class="fa fa-check green-text fa-lg pl-3"></i></li>`
			}

			// check the key fields
			mainFields = ['site','level','job_number','workplace', 'supervisor','employee_name']
			theForm.keyField.value.split('|').forEach((data) => {
				let text = theForm[data].parentElement.getElementsByTagName('label')[0].innerText
				if(theForm[data].validity.valueMissing && !mainFields.includes(data)) {
					headerValidation += `<li class="list-group-item">${text}<i class="fa fa-times red-text fa-lg pl-3"></i></li>`
				}

				if (!theForm[data].validity.valueMissing && !mainFields.includes(data)) {
					headerValidated  += `<li class="list-group-item">${text}<i class="fa fa-check green-text fa-lg pl-3"></i></li>`
				}
			})
			if(headerValidation) {
				headerValidation = `<ul class="list-group list-group-flush">${headerValidated}${headerValidation}</ul>`
				// if autosave then do not display the modal
				if(mode === 'normal') 
					validationModal(headerValidation)
				return false
			} else {
				return true;	
			}
		}
	}

	function sortFunction(a, b) {
		if (a[0] === b[0]) {
			return 0;
		}
		else {
			return (a[0] < b[0]) ? -1 : 1
		}
	}

	function validationModal(message) {
		valModal = new SofvieModal()
		valModal.setModalElements('danger', `modalButtons`, `<a role="button" class="btn btn-danger")} waves-effect" data-dismiss="modal"><span class='translate' data-i18n="1405" notes="OK"></span></a>`)
		valModal.setModalElements('danger', `modalText`, message)
		// Validation error
		valModal.setModalElements('danger', `modalTitle`,i18next.t("1403"))
		valModal.handleModal('danger')
		$('.translate').localize()
		startAutoSave()
		document.getElementById("saveDraft").disabled = false
		$('.button-collapse .fa').on('click',()=> {
		return false
		})
	}
	
</script>