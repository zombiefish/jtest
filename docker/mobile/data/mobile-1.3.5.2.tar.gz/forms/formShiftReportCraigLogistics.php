<?php	
  $strPageTitle = 'Shift Report - Craig Logistics';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
          
          <h6 class="text-secondary"><span class='translate' data-i18n='1560' notes = 'Shift Report - Craig Logistics'></span></h6>
          <div class="pt-1 position-relative my-4">
            <select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
            </select>
            <label for="draft"><span class='translate' data-i18n='1474' notes = 'Form drafts'></span></label>
          </div>

          <form name="formCraigShiftReport" id="formCraigShiftReport" class="needs-validation" method="GET" action="#" novalidate>
                    
						<?php include 'includes/CommonFormHeader.php' ?>
          
					<div class="pt-1 position-relative my-4">
						<select name="shift" id="shift" class="select-single" required>
							<option value="1095" class='translate trans_input' data-i18n='1095' notes = 'Days'> </option>
              <!-- Days -->
              <!-- Nights -->
							<option value="1375" class='translate trans_input' data-i18n='1375' notes = 'Nights'></option>
						</select>
						<label for="shift"><span class='translate' data-i18n='820' notes = 'Shift'></span></label>
					</div>

		      <div class="md-form">
			      <input type="text" name="safety_topic" id="safety_topic" class="form-control" length="200" maxlength="200" required>
			      <label for="safety_topic"><span class='translate' data-i18n='815' notes = 'Safety Topic'></span></label>
	        </div>

          <div class="md-form">
	          <textarea name="safety_notes" id="safety_notes" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	          <label for="safety_notes"><span class='translate' data-i18n='809' notes = 'Safety Notes Log'></span></label>
          </div>

          <div class="md-form">
	          <textarea name="safety_communications" id="safety_communications" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	          <label for="safety_communications"><span class='translate' data-i18n='85' notes = 'Communications from Previous Shift'></span></label>
          </div>

          <h6 class="text-secondary pt-4"><span class='translate' data-i18n='1561' notes = 'Muck Circuit Status'></span></h6>
          <div class="mb-4">
            <label class="d-block"><span class='translate' data-i18n='833' notes = 'Skip Hoist Status'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="skip_stat_up" name="skip_stat" value="1562" required>
              <label class="form-check-label mr-2" for="skip_stat_up"><span class='translate' data-i18n='1562' notes = 'Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="skip_stat_down" name="skip_stat" value="1563">
              <label class="form-check-label mr-2" for="skip_stat_down"><span class='translate' data-i18n='1563' notes = 'Down'></span></label>
            </div>
          </div>

          <div class="mb-4">
            <label class="d-block"><span class='translate' data-i18n='7' notes = '4500 Waste Pass Rockbreaker'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="wp_4500_rb_up" name="wp_4500_rb" value="1562" required>
              <label class="form-check-label mr-2" for="wp_4500_rb_up"><span class='translate' data-i18n='1562' notes = 'Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4500_rb_down" name="wp_4500_rb" value="1563">
              <label class="form-check-label mr-2" for="wp_4500_rb_down"><span class='translate' data-i18n='1563' notes = 'Down'></span></label>
            </div>
          </div>

          <div class="mb-4">
            <label class="d-block"><span class='translate' data-i18n='5' notes = '4300 Ore Pass Rockbreaker'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="op_4300_rb_up" name="op_4300_rb" value="1562" required>
              <label class="form-check-label mr-2" for="op_4300_rb_up"><span class='translate' data-i18n='1562' notes = 'Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="op_4300_rb_down" name="op_4300_rb" value="1563">
              <label class="form-check-label mr-2" for="op_4300_rb_down"><span class='translate' data-i18n='1563' notes = 'Down'></span></label>
            </div>
          </div>

          <div class="mb-4">
            <label class="d-block"><span class='translate' data-i18n='6' notes = '4500 Crusher'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="crusher_4500_up" name="crusher_4500" value="1562" required>
              <label class="form-check-label mr-2" for="crusher_4500_up"><span class='translate' data-i18n='1562' notes = 'Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="crusher_4500_down" name="crusher_4500" value="1563">
              <label class="form-check-label mr-2" for="crusher_4500_down"><span class='translate' data-i18n='1563' notes = 'Down'></span></label>
            </div>
          </div>

          <div class="mb-4">
            <label class="d-block"><span class='translate' data-i18n='9' notes = '4700 Ore Feeder'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="ore_4500_feeder_up" name="ore_4500_feeder" value="1562" required>
              <label class="form-check-label mr-2" for="ore_4500_feeder_up"><span class='translate' data-i18n='1562' notes = 'Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="ore_4500_feeder_down" name="ore_4500_feeder" value="1563">
              <label class="form-check-label mr-2" for="ore_4500_feeder_down"><span class='translate' data-i18n='1563' notes = 'Down'></span></label>
            </div>
          </div>

          <div class="mb-4">
            <label class="d-block"><span class='translate' data-i18n='10' notes = '4700 Waste Feeder'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="waste_4700_feeder_up" name="waste_4700_feeder" value="1562" required>
              <label class="form-check-label mr-2" for="waste_4700_feeder_up"><span class='translate' data-i18n='1562' notes = 'Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="waste_4700_feeder_down" name="waste_4700_feeder" value="1563">
              <label class="form-check-label mr-2" for="waste_4700_feeder_down"><span class='translate' data-i18n='1563' notes = 'Down'></span></label>
            </div>
          </div>

         <div class="mb-4">
            <label class="d-block"><span class='translate' data-i18n='8' notes = '4700 Conveyor'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="conv_4700_up" name="conv_4700" value="1562" required>
              <label class="form-check-label mr-2" for="conv_4700_up"><span class='translate' data-i18n='1562' notes = 'Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="conv_4700_down" name="conv_4700" value="1563">
              <label class="form-check-label mr-2" for="conv_4700_down"><span class='translate' data-i18n='1563' notes = 'Down'></span></label>
            </div>
          </div>

         <div class="mb-4"><span class='translate' data-i18n='628' notes = 'Loading Pocket'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="lp_status_up" name="lp_status" value="1562" required>
              <label class="form-check-label mr-2" for="lp_status_up"><span class='translate' data-i18n='1562' notes = 'Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="lp_status_down" name="lp_status" value="1563">
              <label class="form-check-label mr-2" for="lp_status_down"><span class='translate' data-i18n='1563' notes = 'Down'></span></label>
            </div>
          </div>

         <div class="mb-4"><span class='translate' data-i18n='852' notes = 'Surface Load Out'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="surf_loadout_stat_up" name="surf_loadout_stat" value="1562" required>
              <label class="form-check-label mr-2" for="surf_loadout_stat_up"><span class='translate' data-i18n='1562' notes = 'Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="surf_loadout_stat_down" name="surf_loadout_stat" value="1563">
              <label class="form-check-label mr-2" for="surf_loadout_stat_down"><span class='translate' data-i18n='1563' notes = 'Down'></span></label>
            </div>
          </div>

		      <div class="md-form">
			      <input type="text" name="mc_notes" id="mc_notes" class="form-control" length="200" maxlength="200">
			      <label for="mc_notes"><span class='translate' data-i18n='839' notes = 'Status Notes'></span></label>
	        </div>

         <div class="mb-4"><span class='translate' data-i18n='906' notes = 'Waste Pass 4000-4300 Product'></span></label>
            <div class="form-check custom-radio pl-0">

              <input type="radio" class="form-check-input trans_input" id="wp_4000_prod_Glencore" name="wp_4000_prod" value="1571" required>
              <label class="form-check-label mr-2" for="wp_4000_prod_Glencore"><span class='translate' data-i18n='1571' notes = 'Glencore'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4000_prod_Waste" name="wp_4000_prod" value="1572">
              <label class="form-check-label mr-2" for="wp_4000_prod_Waste"><span class='translate' data-i18n='1572' notes = 'Waste'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4000_prod_Empty" name="wp_4000_prod" value="1573">
              <label class="form-check-label mr-2" for="wp_4000_prod_Empty"><span class='translate' data-i18n='1573' notes = 'Empty'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4000_prod_Unknown" name="wp_4000_prod" value="1574">
              <label class="form-check-label mr-2" for="wp_4000_prod_Unknown"><span class='translate' data-i18n='1574' notes = 'Unknown'></span></label>

            </div>
          </div>

         <div class="mb-4"><span class='translate' data-i18n='905' notes = 'Waste Pass 4000-4300 Level'></span></label>
            <div class="form-check custom-radio pl-0">
            <input type="radio" class="form-check-input trans_input" id="wp_4000_level_Empty" name="wp_4000_level" value="1573">
              <label class="form-check-label mr-2" for="wp_4000_level_Empty"><span class='translate' data-i18n='1573' notes = 'Empty'></span></label>  

              <input type="radio" class="form-check-input" id="wp_4000_level_25" name="wp_4000_level" value="25" required>
              <label class="form-check-label mr-2" for="wp_4000_level_25">25%</label>

              <input type="radio" class="form-check-input" id="wp_4000_level_50" name="wp_4000_level" value="50" required>
              <label class="form-check-label mr-2" for="wp_4000_level_50">50%</label>

              <input type="radio" class="form-check-input" id="wp_4000_level_75" name="wp_4000_level" value="75" required>
              <label class="form-check-label mr-2" for="wp_4000_level_75">75%</label>              

              <input type="radio" class="form-check-input" id="wp_4000_level_100" name="wp_4000_level" value="100">
              <label class="form-check-label mr-2" for="wp_4000_level_100">100%</label>

              <input type="radio" class="form-check-input trans_input" id="wp_4000_level_head_block" name="wp_4000_level" value="1575">
              <label class="form-check-label mr-2" for="wp_4000_level_head_block"><span class='translate' data-i18n='1575' notes = 'Head Block'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4000_level_Hung" name="wp_4000_level" value="1576">
              <label class="form-check-label mr-2" for="wp_4000_level_Hung"><span class='translate' data-i18n='1576' notes = 'Hung Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4000_level_Unknown" name="wp_4000_level" value="1574">
              <label class="form-check-label mr-2" for="wp_4000_level_Unknown"><span class='translate' data-i18n='1574' notes = 'Unknown'></span></label>

            </div>
          </div>

         <div class="mb-4"><span class='translate' data-i18n='908' notes = 'Waste Pass 4300-4500 Product'></span></label>
            <div class="form-check custom-radio pl-0">

              <input type="radio" class="form-check-input trans_input" id="wp_4300_prod_Glencore" name="wp_4300_prod" value="1571" required>
              <label class="form-check-label mr-2" for="wp_4300_prod_Glencore"><span class='translate' data-i18n='1571' notes = 'Glencore'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4300_prod_Waste" name="wp_4300_prod" value="1572">
              <label class="form-check-label mr-2" for="wp_4300_prod_Waste"><span class='translate' data-i18n='1572' notes = 'Waste'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4300_prod_Empty" name="wp_4300_prod" value="1573">
              <label class="form-check-label mr-2" for="wp_4300_prod_Empty"><span class='translate' data-i18n='1573' notes = 'Empty'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4300_prod_Unknown" name="wp_4300_prod" value="1574">
              <label class="form-check-label mr-2" for="wp_4300_prod_Unknown"><span class='translate' data-i18n='1574' notes = 'Unknown'></span></label>

            </div>
          </div>

         <div class="mb-4"><span class='translate' data-i18n='907' notes = 'Waste Pass 4300-4500 Level'></span></label>
            <div class="form-check custom-radio pl-0">

              <input type="radio" class="form-check-input trans_input" id="wp_4300_level_Empty" name="wp_4300_level" value="1573">
              <label class="form-check-label mr-2" for="wp_4300_level_Empty"><span class='translate' data-i18n='1573' notes = 'Empty'></span></label>

              <input type="radio" class="form-check-input" id="wp_4300_level_25" name="wp_4300_level" value="25" required>
              <label class="form-check-label mr-2" for="wp_4300_level_25">25%</label>
 
              <input type="radio" class="form-check-input" id="wp_4300_level_50" name="wp_4300_level" value="50" required>
              <label class="form-check-label mr-2" for="wp_4300_level_50">50%</label>

              <input type="radio" class="form-check-input" id="wp_4300_level_75" name="wp_4300_level" value="75" required>
              <label class="form-check-label mr-2" for="wp_4300_level_75">75%</label>              

              <input type="radio" class="form-check-input" id="wp_4300_level_100" name="wp_4300_level" value="100">
              <label class="form-check-label mr-2" for="wp_4300_level_100">100%</label>

              <input type="radio" class="form-check-input trans_input" id="wp_4300_head_block" name="wp_4300_level" value="1575">
              <label class="form-check-label mr-2" for="wp_4300_head_block"><span class='translate' data-i18n='1575' notes = 'Head Block'></span></label>              

              <input type="radio" class="form-check-input trans_input" id="wp_4300_level_Hung" name="wp_4300_level" value="1576">
              <label class="form-check-label mr-2" for="wp_4300_level_Hung"><span class='translate' data-i18n='1576' notes = 'Hung Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4300_level_Unknown" name="wp_4300_level" value="1574">
              <label class="form-check-label mr-2" for="wp_4300_level_Unknown"><span class='translate' data-i18n='1574' notes = 'Unknown'></span></label>



            </div>
          </div>
					
         <div class="mb-4"><span class='translate' data-i18n='910' notes = 'Waste Pass 4500-4700 Product'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="wp_4500_prod_Glencore" name="wp_4500_prod" value="1571" required>
              <label class="form-check-label mr-2" for="wp_4500_prod_Glencore"><span class='translate' data-i18n='1571' notes = 'Glencore'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4500_prod_Waste" name="wp_4500_prod" value="1572">
              <label class="form-check-label mr-2" for="wp_4500_prod_Waste"><span class='translate' data-i18n='1572' notes = 'Waste'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4500_prod_Empty" name="wp_4500_prod" value="1573">
              <label class="form-check-label mr-2" for="wp_4500_prod_Empty"><span class='translate' data-i18n='1573' notes = 'Empty'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4500_prod_Unknown" name="wp_4500_prod" value="1574">
              <label class="form-check-label mr-2" for="wp_4500_prod_Unknown"><span class='translate' data-i18n='1574' notes = 'Unknown'></span></label>

            </div>
          </div>

         <div class="mb-4"><span class='translate' data-i18n='909' notes = 'Waste Pass 4500-4700 Level'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="wp_4500_level_Empty" name="wp_4500_level" value="1573">
              <label class="form-check-label mr-2" for="wp_4500_level_Empty"><span class='translate' data-i18n='1573' notes = 'Empty'></span></label> 

              <input type="radio" class="form-check-input" id="wp_4500_level_25" name="wp_4500_level" value="25" required>
              <label class="form-check-label mr-2" for="wp_4500_level_25">25%</label>

              <input type="radio" class="form-check-input" id="wp_4500_level_50" name="wp_4500_level" value="50" required>
              <label class="form-check-label mr-2" for="wp_4500_level_50">50%</label>

              <input type="radio" class="form-check-input" id="wp_4500_level_75" name="wp_4500_level" value="75" required>
              <label class="form-check-label mr-2" for="wp_4500_level_75">75%</label>              

              <input type="radio" class="form-check-input" id="wp_4500_level_100" name="wp_4500_level" value="100">
              <label class="form-check-label mr-2" for="wp_4500_level_100">100%</label>

              <input type="radio" class="form-check-input trans_input" id="wp_4500_level_head_block" name="wp_4500_level" value="1575">
              <label class="form-check-label mr-2" for="wp_4500_level_head_block"><span class='translate' data-i18n='1575' notes = 'Head Block'></span></label>              

              <input type="radio" class="form-check-input trans_input" id="wp_4500_level_Hung" name="wp_4500_level" value="1576">
              <label class="form-check-label mr-2" for="wp_4500_level_Hung"><span class='translate' data-i18n='1576' notes = 'Hung Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="wp_4500_level_Unknown" name="wp_4500_level" value="1574">
              <label class="form-check-label mr-2" for="wp_4500_level_Unknown"><span class='translate' data-i18n='1574' notes = 'Unknown'></span></label>

             

            </div>
          </div>

         <div class="mb-4"><span class='translate' data-i18n='683' notes = 'Ore Pass 4000-4300 Product'></span></label>
            <div class="form-check custom-radio pl-0">

              <input type="radio" class="form-check-input trans_input" id="op_4000_prod_Glencore" name="op_4000_prod" value="1571" required>
              <label class="form-check-label mr-2" for="op_4000_prod_Glencore"><span class='translate' data-i18n='1571' notes = 'Glencore'></span></label>

              <input type="radio" class="form-check-input trans_input" id="op_4000_prod_Waste" name="op_4000_prod" value="1572">
              <label class="form-check-label mr-2" for="op_4000_prod_Waste"><span class='translate' data-i18n='1572' notes = 'Waste'></span></label>

              <input type="radio" class="form-check-input trans_input" id="op_4000_prod_Empty" name="op_4000_prod" value="1573">
              <label class="form-check-label mr-2" for="op_4000_prod_Empty"><span class='translate' data-i18n='1573' notes = 'Empty'></span></label>

              <input type="radio" class="form-check-input trans_input" id="op_4000_prod_Unknown" name="op_4000_prod" value="1574">
              <label class="form-check-label mr-2" for="op_4000_prod_Unknown"><span class='translate' data-i18n='1574' notes = 'Unknown'></span></label>

            </div>
          </div>

          <div class="mb-4"><span class='translate' data-i18n='682' notes = 'Ore Pass 4000-4300 Level'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="op_4000_level_Empty" name="op_4000_level" value="1573">
              <label class="form-check-label mr-2" for="op_4000_level_Empty"><span class='translate' data-i18n='1573' notes = 'Empty'></span></label>   

              <input type="radio" class="form-check-input" id="op_4000_level_25" name="op_4000_level" value="25" required>
              <label class="form-check-label mr-2" for="op_4000_level_25">25%</label>              

              <input type="radio" class="form-check-input" id="op_4000_level_50" name="op_4000_level" value="50" required>
              <label class="form-check-label mr-2" for="op_4000_level_50">50%</label>

              <input type="radio" class="form-check-input" id="op_4000_level_75" name="op_4000_level" value="75" required>
              <label class="form-check-label mr-2" for="op_4000_level_75">75%</label>               

              <input type="radio" class="form-check-input" id="op_4000_level_100" name="op_4000_level" value="100">
              <label class="form-check-label mr-2" for="op_4000_level_100">100%</label>

              <input type="radio" class="form-check-input trans_input" id="op_4000_head_block" name="op_4000_level" value="1575">
              <label class="form-check-label mr-2" for="op_4000_head_block"><span class='translate' data-i18n='1575' notes = 'Head Block'></span></label>              

              <input type="radio" class="form-check-input trans_input" id="op_4000_level_Hung" name="op_4000_level" value="1576">
              <label class="form-check-label mr-2" for="op_4000_level_Hung"><span class='translate' data-i18n='1576' notes = 'Hung Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="op_4000_level_Unknown" name="op_4000_level" value="1574">
              <label class="form-check-label mr-2" for="op_4000_level_Unknown"><span class='translate' data-i18n='1574' notes = 'Unknown'></span></label>

              

            </div>
          </div>

          <div class="mb-4"><span class='translate' data-i18n='685' notes = 'Ore Pass 4300-4500 Product'></span></label>
            <div class="form-check custom-radio pl-0">

              <input type="radio" class="form-check-input trans_input" id="op_4300_prod_Glencore" name="op_4300_prod" value="1571" required>
              <label class="form-check-label mr-2" for="op_4300_prod_Glencore"><span class='translate' data-i18n='1571' notes = 'Glencore'></span></label>

              <input type="radio" class="form-check-input trans_input" id="op_4300_prod_Waste" name="op_4300_prod" value="1572">
              <label class="form-check-label mr-2" for="op_4300_prod_Waste"><span class='translate' data-i18n='1572' notes = 'Waste'></span></label>

              <input type="radio" class="form-check-input trans_input" id="op_4300_prod_Empty" name="op_4300_prod" value="1573">
              <label class="form-check-label mr-2" for="op_4300_prod_Empty"><span class='translate' data-i18n='1573' notes = 'Empty'></span></label>

              <input type="radio" class="form-check-input trans_input" id="op_4300_prod_Unknown" name="op_4300_prod" value="1574">
              <label class="form-check-label mr-2" for="op_4300_prod_Unknown"><span class='translate' data-i18n='1574' notes = 'Unknown'></span></label>

            </div>
          </div>

         <div class="mb-4"><span class='translate' data-i18n='684' notes = 'Ore Pass 4300-4500 Level'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="op_4300_level_Empty" name="op_4300_level" value="1573">
              <label class="form-check-label mr-2" for="op_4300_level_Empty"><span class='translate' data-i18n='1573' notes = 'Empty'></span></label> 

              <input type="radio" class="form-check-input" id="op_4300_level_25" name="op_4300_level" value="25" required>
              <label class="form-check-label mr-2" for="op_4300_level_25">25%</label>              

              <input type="radio" class="form-check-input" id="op_4300_level_50" name="op_4300_level" value="50" required>
              <label class="form-check-label mr-2" for="op_4300_level_50">50%</label>

              <input type="radio" class="form-check-input" id="op_4300_level_75" name="op_4300_level" value="75" required>
              <label class="form-check-label mr-2" for="op_4300_level_75">75%</label>                   

              <input type="radio" class="form-check-input" id="op_4300_level_100" name="op_4300_level" value="100">
              <label class="form-check-label mr-2" for="op_4300_level_100">100%</label>

              <input type="radio" class="form-check-input trans_input" id="op_4300_head_block" name="op_4300_level" value="1575">
              <label class="form-check-label mr-2" for="op_4300_head_block"><span class='translate' data-i18n='1575' notes = 'Head Block'></span></label>              

              <input type="radio" class="form-check-input trans_input" id="op_4300_level_Hung" name="op_4300_level" value="1576">
              <label class="form-check-label mr-2" for="op_4300_level_Hung"><span class='translate' data-i18n='1576' notes = 'Hung Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="op_4300_level_Unknown" name="op_4300_level" value="1574">
              <label class="form-check-label mr-2" for="op_4300_level_Unknown"><span class='translate' data-i18n='1574' notes = 'Unknown'></span></label>

            </div>
          </div>

         <div class="mb-4"><span class='translate' data-i18n='687' notes = 'Ore Pass 4500-4700 Product'></span></label>
            <div class="form-check custom-radio pl-0">
 
              <input type="radio" class="form-check-input trans_input" id="op_4500_prod_Glencore" name="op_4500_prod" value="1571" required>
              <label class="form-check-label mr-2" for="op_4500_prod_Glencore"><span class='translate' data-i18n='1571' notes = 'Glencore'></span></label>

              <input type="radio" class="form-check-input trans_input" id="op_4500_prod_Waste" name="op_4500_prod" value="1572">
              <label class="form-check-label mr-2" for="op_4500_prod_Waste"><span class='translate' data-i18n='1572' notes = 'Waste'></span></label>

              <input type="radio" class="form-check-input trans_input" id="op_4500_prod_Empty" name="op_4500_prod" value="1573">
              <label class="form-check-label mr-2" for="op_4500_prod_Empty"><span class='translate' data-i18n='1573' notes = 'Empty'></span></label>

              <input type="radio" class="form-check-input trans_input" id="op_4500_prod_Unknown" name="op_4500_prod" value="1574">
              <label class="form-check-label mr-2" for="op_4500_prod_Unknown"><span class='translate' data-i18n='1574' notes = 'Unknown'></span></label>

            </div>
          </div>

         <div class="mb-4"><span class='translate' data-i18n='686' notes = 'Ore Pass 4500-4700 Level'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="op_4500_level_Empty" name="op_4500_level" value="1573">
              <label class="form-check-label mr-2" for="op_4500_level_Empty"><span class='translate' data-i18n='1573' notes = 'Empty'></span></label> 

              <input type="radio" class="form-check-input" id="op_4500_level_25" name="op_4500_level" value="25" required>
              <label class="form-check-label mr-2" for="op_4500_level_25">25%</label>

              <input type="radio" class="form-check-input" id="op_4500_level_50" name="op_4500_level" value="50" required>
              <label class="form-check-label mr-2" for="op_4500_level_50">50%</label>

              <input type="radio" class="form-check-input" id="op_4500_level_75" name="op_4500_level" value="75" required>
              <label class="form-check-label mr-2" for="op_4500_level_75">75%</label>              

              <input type="radio" class="form-check-input" id="op_4500_level_100" name="op_4500_level" value="100">
              <label class="form-check-label mr-2" for="op_4500_level_100">100%</label>

              <input type="radio" class="form-check-input trans_input" id="op_4500_head_block" name="op_4500_level" value="1575">
              <label class="form-check-label mr-2" for="op_4500_head_block"><span class='translate' data-i18n='1575' notes = 'Head Block'></span></label>              

              <input type="radio" class="form-check-input trans_input" id="op_4500_level_Hung" name="op_4500_level" value="1576">
              <label class="form-check-label mr-2" for="op_4500_level_Hung"><span class='translate' data-i18n='1576' notes = 'Hung Up'></span></label>

              <input type="radio" class="form-check-input trans_input" id="op_4500_level_Unknown" name="op_4500_level" value="1574">
              <label class="form-check-label mr-2" for="op_4500_level_Unknown"><span class='translate' data-i18n='1574' notes = 'Unknown'></span></label>


            </div>
          </div>

          <h6 class="text-secondary pt-4"><span class='translate' data-i18n='1579' notes = 'Skip Hoist Production'></span></h6>

		      <div class="md-form">
			      <input type="number" min="0" max="200" name="glencore_ore_skips" id="glencore_ore_skips" class="form-control" oninput="calcSkips()" required>
			      <label for="glencore_ore_skips"><span class='translate' data-i18n='489' notes = 'Glencore Skips Ore'></span></label>
	        </div>
					
		      <div class="md-form">
			      <input type="number" name="waste_skips" min="0" max="200" id="waste_skips" class="form-control" oninput="calcSkips()" required>
			      <label for="waste_skips"><span class='translate' data-i18n='911' notes = 'Waste Skips'></span></label>
	        </div>
					
		      <div class="md-form">
			      <input type="text" name="total_skips" id="total_skips" class="form-control" DISABLED>
			      <label for="total_skips" class='active'><span class='translate' data-i18n='873' notes = 'Total Skips'></span></label>
	        </div>

		      <div class="md-form">
			      <input type="number" name="skip_downtime_hours"  step='.01' min="0" max="12" id="skip_downtime_hours" class="form-control" oninput="calcSkips()" required>
			      <label for="skip_downtime_hours"><span class='translate' data-i18n='832' notes = 'Skip Downtime Hours'></span></label>
	        </div>

          <div class="md-form">
	          <textarea name="skip_downtime_details" id="skip_downtime_details" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	          <label for="skip_downtime_details"><span class='translate' data-i18n='831' notes = 'Skip Downtime Details'></span></label>
          </div>

		      <div class="md-form">
			      <input type="text" name="total_skips_wdt" id="total_skips_wdt" class="form-control" DISABLED>
			      <label for="total_skips_wdt"><span class='translate' data-i18n='874' notes = 'Total Skips with Downtime'></span></label>
	        </div>

          <h6 class="text-secondary pt-4"><span class='translate' data-i18n='1580' notes = 'Cage Runs'></span></h6>
         <div class="mb-4">6:00<span class='translate' data-i18n='3754' notes = 'am'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="cr_6am_status_ontime" name="cr_6am_status" value="1581" required>
              <label class="form-check-label mr-2" for="cr_6am_status_ontime"><span class='translate' data-i18n='1581' notes = 'On Time'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_6am_status_Delay" name="cr_6am_status" value="1582">
              <label class="form-check-label mr-2" for="cr_6am_status_Delay"><span class='translate' data-i18n='1582' notes = 'Delay'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_6am_status_Cancelled" name="cr_6am_status" value="1583">
              <label class="form-check-label mr-2" for="cr_6am_status_Cancelled"><span class='translate' data-i18n='1583' notes = 'Cancelled'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_6am_status_NA" name="cr_6am_status" value="1381">
              <label class="form-check-label mr-2" for="cr_6am_status_NA"><span class='translate' data-i18n='1381' notes = 'N/A'></span></label>
            </div>
          </div>

          <div class="md-form">
	          <textarea name="cr_6am_comments" id="cr_6am_comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	          <label for="cr_6am_comments"><span class='translate' data-i18n='81' notes = 'Comments'></span></label>
          </div>

         <div class="mb-4">6:30<span class='translate' data-i18n='3754' notes = 'am'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="cr_630am_status_ontime" name="cr_630am_status" value="1581" required>
              <label class="form-check-label mr-2" for="cr_630am_status_ontime"><span class='translate' data-i18n='1581' notes = 'On Time'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_630am_status_Delay" name="cr_630am_status" value="1582">
              <label class="form-check-label mr-2" for="cr_630am_status_Delay"><span class='translate' data-i18n='1582' notes = 'Delay'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_630am_status_Cancelled" name="cr_630am_status" value="1583">
              <label class="form-check-label mr-2" for="cr_630am_status_Cancelled"><span class='translate' data-i18n='1583' notes = 'Cancelled'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_630am_status_NA" name="cr_630am_status" value="1381">
              <label class="form-check-label mr-2" for="cr_630am_status_NA"><span class='translate' data-i18n='1381' notes = 'N/A'></span></label>

            </div>
          </div>

          <div class="md-form">
	          <textarea name="cr_630am_comments" id="cr_630am_comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	          <label for="cr_630am_comments"><span class='translate' data-i18n='81' notes = 'Comments'></span></label>
          </div>

         <div class="mb-4">7:30<span class='translate' data-i18n='3754' notes = 'am'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="cr_730am_status_ontime" name="cr_730am_status" value="1581" required>
              <label class="form-check-label mr-2" for="cr_730am_status_ontime"><span class='translate' data-i18n='1581' notes = 'On Time'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_730am_status_Delay" name="cr_730am_status" value="1582">
              <label class="form-check-label mr-2" for="cr_730am_status_Delay"><span class='translate' data-i18n='1582' notes = 'Delay'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_730am_status_Cancelled" name="cr_730am_status" value="1583">
              <label class="form-check-label mr-2" for="cr_730am_status_Cancelled"><span class='translate' data-i18n='1583' notes = 'Cancelled'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_730am_status_NA" name="cr_730am_status" value="1381">
              <label class="form-check-label mr-2" for="cr_730am_status_NA"><span class='translate' data-i18n='1381' notes = 'N/A'></span></label>

            </div>
          </div>

          <div class="md-form">
	          <textarea name="cr_730am_comments" id="cr_730am_comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	          <label for="cr_730am_comments"><span class='translate' data-i18n='81' notes = 'Comments'></span></label>
          </div>

         <div class="mb-4">2:00<span class='translate' data-i18n='3755' notes = 'pm'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="cr_2pm_status_ontime" name="cr_2pm_status" value="1581" required>
              <label class="form-check-label mr-2" for="cr_2pm_status_ontime"><span class='translate' data-i18n='1581' notes = 'On Time'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_2pm_status_Delay" name="cr_2pm_status" value="1582">
              <label class="form-check-label mr-2" for="cr_2pm_status_Delay"><span class='translate' data-i18n='1582' notes = 'Delay'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_2pm_status_Cancelled" name="cr_2pm_status" value="1583">
              <label class="form-check-label mr-2" for="cr_2pm_status_Cancelled"><span class='translate' data-i18n='1583' notes = 'Cancelled'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_2pm_status_NA" name="cr_2pm_status" value="1381">
              <label class="form-check-label mr-2" for="cr_2pm_status_NA"><span class='translate' data-i18n='1381' notes = 'N/A'></span></label>

            </div>
          </div>

          <div class="md-form">
	          <textarea name="cr_2pm_comments" id="cr_2pm_comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	          <label for="cr_2pm_comments"><span class='translate' data-i18n='81' notes = 'Comments'></span></label>
          </div>

         <div class="mb-4">3:30<span class='translate' data-i18n='3755' notes = 'pm'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="cr_330pm_status_ontime" name="cr_330pm_status" value="1581" required>
              <label class="form-check-label mr-2" for="cr_330pm_status_ontime"><span class='translate' data-i18n='1581' notes = 'On Time'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_330pm_status_Delay" name="cr_330pm_status" value="1582">
              <label class="form-check-label mr-2" for="cr_330pm_status_Delay"><span class='translate' data-i18n='1582' notes = 'Delay'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_330pm_status_Cancelled" name="cr_330pm_status" value="1583">
              <label class="form-check-label mr-2" for="cr_330pm_status_Cancelled"><span class='translate' data-i18n='1583' notes = 'Cancelled'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_330pm_status_NA" name="cr_330pm_status" value="1381">
              <label class="form-check-label mr-2" for="cr_330pm_status_NA"><span class='translate' data-i18n='1381' notes = 'N/A'></span></label>
            </div>
          </div>

          <div class="md-form">
	          <textarea name="cr_330pm_comments" id="cr_330pm_comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	          <label for="cr_330pm_comments"><span class='translate' data-i18n='81' notes = 'Comments'></span></label>
          </div>

         <div class="mb-4">5:00<span class='translate' data-i18n='3755' notes = 'pm'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="cr_5pm_status_ontime" name="cr_5pm_status" value="1581" required>
              <label class="form-check-label mr-2" for="cr_5pm_status_ontime"><span class='translate' data-i18n='1581' notes = 'On Time'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_5pm_status_Delay" name="cr_5pm_status" value="1582">
              <label class="form-check-label mr-2" for="cr_5pm_status_Delay"><span class='translate' data-i18n='1582' notes = 'Delay'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_5pm_status_Cancelled" name="cr_5pm_status" value="1583">
              <label class="form-check-label mr-2" for="cr_5pm_status_Cancelled"><span class='translate' data-i18n='1583' notes = 'Cancelled'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_5pm_status_NA" name="cr_5pm_status" value="1381">
              <label class="form-check-label mr-2" for="cr_5pm_status_NA"><span class='translate' data-i18n='1381' notes = 'N/A'></span></label>
            </div>
          </div>

          <div class="md-form">
	          <textarea name="cr_5pm_comments" id="cr_5pm_comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	          <label for="cr_5pm_comments"><span class='translate' data-i18n='81' notes = 'Comments'></span></label>
          </div>

         <div class="mb-4">6:00<span class='translate' data-i18n='3755' notes = 'pm'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="cr_6pm_status_ontime" name="cr_6pm_status" value="1581" required>
              <label class="form-check-label mr-2" for="cr_6pm_status_ontime"><span class='translate' data-i18n='1581' notes = 'On Time'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_6pm_status_Delay" name="cr_6pm_status" value="1582">
              <label class="form-check-label mr-2" for="cr_6pm_status_Delay"><span class='translate' data-i18n='1582' notes = 'Delay'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_6pm_status_Cancelled" name="cr_6pm_status" value="1583">
              <label class="form-check-label mr-2" for="cr_6pm_status_Cancelled"><span class='translate' data-i18n='1583' notes = 'Cancelled'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_6pm_status_NA" name="cr_6pm_status" value="1381">
              <label class="form-check-label mr-2" for="cr_6pm_status_NA"><span class='translate' data-i18n='1381' notes = 'N/A'></span></label>

            </div>
          </div>

          <div class="md-form">
	          <textarea name="cr_6pm_comments" id="cr_6pm_comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	          <label for="cr_6pm_comments"><span class='translate' data-i18n='81' notes = 'Comments'></span></label>
          </div>

         <div class="mb-4">10:00<span class='translate' data-i18n='3755' notes = 'pm'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="cr_10pm_status_ontime" name="cr_10pm_status" value="1581" required>
              <label class="form-check-label mr-2" for="cr_10pm_status_ontime"><span class='translate' data-i18n='1581' notes = 'On Time'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_10pm_status_Delay" name="cr_10pm_status" value="1582">
              <label class="form-check-label mr-2" for="cr_10pm_status_Delay"><span class='translate' data-i18n='1582' notes = 'Delay'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_10pm_status_Cancelled" name="cr_10pm_status" value="1583">
              <label class="form-check-label mr-2" for="cr_10pm_status_Cancelled"><span class='translate' data-i18n='1583' notes = 'Cancelled'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_10pm_status_NA" name="cr_10pm_status" value="1381">
              <label class="form-check-label mr-2" for="cr_10pm_status_NA"><span class='translate' data-i18n='1381' notes = 'N/A'></span></label>

            </div>
          </div>

          <div class="md-form">
	          <textarea name="cr_10pm_comments" id="cr_10pm_comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	          <label for="cr_10pm_comments"><span class='translate' data-i18n='81' notes = 'Comments'></span></label>
          </div>

         <div class="mb-4">11:30<span class='translate' data-i18n='3755' notes = 'pm'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="cr_1130pm_status_ontime" name="cr_1130pm_status" value="1581" required>
              <label class="form-check-label mr-2" for="cr_1130pm_status_ontime"><span class='translate' data-i18n='1581' notes = 'On Time'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_1130pm_status_Delay" name="cr_1130pm_status" value="1582">
              <label class="form-check-label mr-2" for="cr_1130pm_status_Delay"><span class='translate' data-i18n='1582' notes = 'Delay'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_1130pm_status_Cancelled" name="cr_1130pm_status" value="1583">
              <label class="form-check-label mr-2" for="cr_1130pm_status_Cancelled"><span class='translate' data-i18n='1583' notes = 'Cancelled'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_1130pm_status_NA" name="cr_1130pm_status" value="1381">
              <label class="form-check-label mr-2" for="cr_1130pm_status_NA"><span class='translate' data-i18n='1381' notes = 'N/A'></span></label>

            </div>
          </div>

          <div class="md-form">
	          <textarea name="cr_1130pm_comments" id="cr_1130pm_comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	          <label for="cr_1130pm_comments"><span class='translate' data-i18n='81' notes = 'Comments'></span></label>
          </div>

         <div class="mb-4">4:30<span class='translate' data-i18n='3754' notes = 'am'></span></label>
            <div class="form-check custom-radio pl-0">
              <input type="radio" class="form-check-input trans_input" id="cr_430am_status_ontime" name="cr_430am_status" value="1581" required>
              <label class="form-check-label mr-2" for="cr_430am_status_ontime"><span class='translate' data-i18n='1581' notes = 'On Time'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_430am_status_Delay" name="cr_430am_status" value="1582">
              <label class="form-check-label mr-2" for="cr_430am_status_Delay"><span class='translate' data-i18n='1582' notes = 'Delay'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_430am_status_Cancelled" name="cr_430am_status" value="1583">
              <label class="form-check-label mr-2" for="cr_430am_status_Cancelled"><span class='translate' data-i18n='1583' notes = 'Cancelled'></span></label>

              <input type="radio" class="form-check-input trans_input" id="cr_430am_status_NA" name="cr_430am_status" value="1381">
              <label class="form-check-label mr-2" for="cr_430am_status_NA"><span class='translate' data-i18n='1381' notes = 'N/A'></span></label>

            </div>
          </div>

          <div class="md-form">
	          <textarea name="cr_430am_comments" id="cr_430am_comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
	          <label for="cr_430am_comments"><span class='translate' data-i18n='81' notes = 'Comments'></span></label>
          </div>

          <h6 class="text-secondary pt-4"><span class='translate' data-i18n='1556' notes = 'Workplace Details'></span></h6>
          <canvas id="canvas" style='display:none;'></canvas>
            <div id="crews"></div>
            <!-- Buttons for adding and removing Crews -->
            <div id='addCrew' class='btn btn-sm btn-primary'><i class="fa fa-plus"></i> <span class='translate' data-i18n='1211' notes = 'Add Workplace'></span></div>
						<div id='removeCrew' class='btn btn-sm btn-outline-primary'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n='2378' notes = 'Remove Workplace'></span></div>

						<div class="md-form">
							<textarea name="extras_delays" id="extras_delays" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="extras_delays"><span class='translate' data-i18n='477' notes = 'Extras and/or Delays'></span></label>
						</div>

						<div class="md-form">
							<textarea name="end_states_summary" id="end_states_summary" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="end_states_summary"><span class='translate' data-i18n='1585' notes = 'End States Summary'></span></label>
						</div>

						<div class="md-form">
							<textarea name="next_shift_requirements" id="next_shift_requirements" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="next_shift_requirements"><span class='translate' data-i18n='661' notes = 'Next Shift Requirements'></span></label>
						</div>

						<div class="md-form">
							<textarea name="eq_down_details" id="eq_down_details" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="eq_down_details"><span class='translate' data-i18n='430' notes = 'Equipment Down Details'></span></label>
						</div>            				

						<div class="md-form">
							<textarea name="eq_end_states_summary" id="eq_end_states_summary" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="eq_end_states_summary"><span class='translate' data-i18n='1586' notes = 'Equipment End State Summary'></span></label>
						</div>
            
						<div class="md-form">
							<textarea name="eq_parts_required" id="eq_parts_required" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="eq_parts_required"><span class='translate' data-i18n='452' notes = 'Equipment Parts Required'></span></label>
						</div>            

						<h6 class="text-secondary pt-4"><span class='translate' data-i18n='81' notes = 'Comments'></span></h6>
						<div class="md-form">
							<textarea name="overall_comments" id="overall_comments" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
							<label for="overall_comments"><span class='translate' data-i18n='81' notes = 'Comments'></span></label>
            </div>


      <?php include 'includes/CommonFormFooter.php' ?>
          
		  <input type="hidden" tag='1560' name="formname" class = "trans_input" value="1560" id="formname" note="Shift Report - Craig Logistics" />
		  <input type="hidden" name="formtype" id="formtype" value="SR" />
		  <input type="hidden" name="formid" id="formid" value="333857"/>
		  <input type="hidden" name="version" id="version" value="12" />
		  <input type="hidden" name="_rev" id="_rev" value="" />
		  <input type="hidden" name="_id" id="_id" value="" />
		  <input type="hidden" name="keyField" id="keyField" value="site|workplace" />
		  <input type="hidden" name="draftField" id="draftField" value="draft" />
      <input type="hidden" name="numCrews" id="numCrews" value='1' />
      <input type="hidden" name="totalCrews" id="totalCrews" value='8' />    
		</form>

					<!-- Form -->
				</div>
			</div>
		</div>
	</div>
</main>

    <div id="sync-wrapper">
    </div>

    <div id="output">
    </div>

	<div><!--- row -->
</div> <!--- container -->

<script type="text/javascript">
	var formBody = {
		
		formInitialize: function (theForm)	{
		},
	
		formTerminate: function (theForm)	{
		},

		formValidate: function (theForm)	{
		}	
  }

  function calcSkips() {
    glencoreOreSkips = document.getElementById('glencore_ore_skips').value ? document.getElementById('glencore_ore_skips').value : 0
    wasteSkips = document.getElementById('waste_skips').value ? document.getElementById('waste_skips').value : 0
    downtimeHours = document.getElementById('skip_downtime_hours').value ? document.getElementById('skip_downtime_hours').value : 0
    document.getElementById('total_skips').value = parseInt(glencoreOreSkips) + parseInt(wasteSkips) 
    document.getElementById('total_skips').nextSibling.nextSibling.classList.add("active");
    document.getElementById('total_skips_wdt').value = parseInt(glencoreOreSkips) + parseInt(wasteSkips) + (parseInt(downtimeHours) * 10)
    document.getElementById('total_skips_wdt').nextSibling.nextSibling.classList.add("active");    
  }

  $( document ).ready(function() {
		addCrew(1)
	});
	
  function addCrew(crewNum,mode){
		const crewsModal = 
		`<div class="crewsection" value=${crewNum}>
        <h6 class="text-secondary pt-4"><span class='translate' data-i18n='959' notes = 'Workplace'></span> ${crewNum}</h6>
        <div class="pt-1 position-relative my-4">
          <select name="workplace_${crewNum}" id="workplace_${crewNum}" class="select-multiple mobile-employee-select" multiple required>
          </select>
          <label for="workplace_${crewNum}"><span class='translate' data-i18n='1557' notes = 'Workers'></span></label>
        </div>

        <div class="pt-1 position-relative my-4">
          <select name="workplace_${crewNum}_hours" id="workplace_${crewNum}_hours" class="select-single mobile-hourssummary-select"  required>
          </select>
          <label for="workplace_${crewNum}_hours"><span class='translate' data-i18n='526' notes = 'Hours'></span></label>
        </div>

        <div class="md-form">
          <textarea name="work_completed_${crewNum}" id="work_completed_${crewNum}" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
          <label for="work_completed_${crewNum}"><span class='translate' data-i18n='941' notes = 'Work Completed'></span></label>
        </div>

        <div class="form-group photoImage" id="workplace_pictures_${crewNum}"> 
          <label class="d-block"><span class='translate' data-i18n='969' notes = 'Workplace Pictures'></span></label>
          <canvas id="wpcanvas${crewNum}" style='display:none;'></canvas>
          <div class="btn-group d-flex" role="group">
            <div class="btn btn-block btn-outline-secondary file-field px-1">
              <i class="fa fa-upload"></i> <span class='translate' data-i18n='2340' notes = 'Add Images'></span>
              <input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
            </div>
          </div>

          <small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n='1389' notes = 'Please take scene pictures from all perspectives'></span></small>
          <div class="row photoGallery" id="wpgalleryid${crewNum}"></div>
        </div>

        <div class="pt-1 position-relative my-4">
          <select name="eq_group_${crewNum}" id="eq_group_${crewNum}" class="select-multiple shift-report" multiple>
          </select>
          <label for="eq_group_${crewNum}"><span class='translate' data-i18n="9559" notes="Please select Site and Department/Job to select Equipment"></span></label>
        </div>

        <div class="md-form">
          <input type="text" name="eq_group_${crewNum}_details" id="eq_group_${crewNum}_details" class="form-control" length="200" maxlength="200">
          <label for="eq_group_${crewNum}_details"><span class='translate' data-i18n='429' notes = 'Equipment Details'></span></label>
        </div>
      </div>`
		
		$("#crews").append(crewsModal);
    if(crewNum>1 && !mode){
      initializeSelect2Dynamic(`workplace_${crewNum}`)
      initializeSelect2Dynamic(`workplace_${crewNum}_hours`)
      initializeSelect2Dynamic(`eq_group_${crewNum}`)
      formHeader.populateEmployeeSelect(`workplace_${crewNum}`)	
      formHeader.populateHoursSummarySelect(`workplace_${crewNum}_hours`)
      preop_site_job_equipment_select()
			addImagePicker('workplace_pictures_' + crewNum)
      try {$('.translate').localize()} catch {}
		}	
	}

	function clearEquipmentFields(id) {
    if(id === 'job_number' || id === 'site'){
      $('.shift-report').each((rec)=>{
        all_rest = []
        let optionData = `<select name="eq_group_${rec+1}" id="eq_group_${rec+1}" class="select-multiple shift-report" multiple>`
        all_rest.forEach((data)=>{
            optionData += `<option value="${data.id}">${data.text}</option>`
        })
        optionData += `</select>`
        $(`#eq_group_${rec+1}`).html(optionData)
        if(main_current_draft_object){
          main_current_draft_object[`eq_group_${rec+1}`] = null
        }
        $(`#eq_group_${rec+1}`).parent().find('label').html(i18next.t("9559"))
        $(`#eq_group_${rec+1}`).val("").trigger("change").parent().find('label').removeClass(['filled',"active"])
      })
    }
	}

</script>
<script src="/js/groupEquipment.js"></script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>
