<?php	
	$strPageTitle = 'Custom Forms';
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");
?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
        
						<h6 class="text-secondary" id="customFormTitle"><span class='translate' data-i18n="9134" notes="customForm"></span></h6>
						<div class="pt-1 position-relative my-4">
							<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
							</select>
							<label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
						</div>

						<form name="daily_log" id="TemplateForm" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>

                        <div id='customFormPlaceholder'></div>

						<?php include 'includes/CommonFormFooter.php' ?>

						<input type='hidden' name="customForm" id="customForm" >									
						<input type='hidden' name="customForm_name" id="customForm_name">
						<input type="hidden" name="formname" id="formname" value="" />
						<input type="hidden" name="formtype" id="formtype" value="CUSTOMFORMS" />
						<input type="hidden" name="formid" id="formid" value="777777" />
						<input type="hidden" name="version" id="version" value="1" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace"/>
						<input type="hidden" name="draftField" id="draftField" value="draft" />
					</form>
				</div>
			</div>
		</div>
	</div>
</main>


<script type="text/javascript">	

localStorage.setItem(`noinitialize`, 'true')

openCacheData().then((rdata)=>{
	openSelectCacheData().then(()=>{
		let customForms = remoteData[36].CustomForms
		let selected_customForm = window.localStorage.getItem('customForm')
		if(selected_customForm) {
			document.getElementById('customForm').value = selected_customForm
				customForms.forEach((id)=>{
					if(id.fob_id == selected_customForm) {						
						document.getElementById('customFormTitle').innerHTML = `${id.fob_name}`
						document.getElementById('customForm_name').value = `${id.fob_name}`						
						document.getElementById('formname').value = `${id.fob_name}`
					}
				})
			populateCustomFormItems(selected_customForm)
		}
	})
})

function populateCustomFormItems(customFormId) {
	let customFormItems = remoteData[37].CustomFormItems
	let customFormItemList = []
	customFormItems.forEach((item)=>{
		if(item.fbi_fob_id == customFormId){
			customFormItemList.push(item)
		}
	})
	customFormItemList.sort((a,b) => (parseInt(a.fbi_sort) > parseInt(b.fbi_sort)) ? 1 : ((parseInt(b.fbi_sort) > parseInt(a.fbi_sort)) ? -1 : 0))

	createFormItemInputs(customFormItemList)

	localStorage.removeItem(`noinitialize`)
	
	initializePickadate()
	initializeSelect2()
	initializeSignatures()
	initializeImagePickers()

	draftCheck()

	initializeI18N()

	// Finished loading the form items. Now remove the spinner
	$("#footerSpinner").addClass('d-none')
}

function createFormItemInputs(items) {
	htmlData = ''
	items.forEach((item)=>{
		switch(item.fbi_fft_id) {
			case 1: htmlData += customFormCreateRadioInput(item)		// Radio Yes/No/NA
				break
			case 2: htmlData += customFormCreateTextInput(item)			// Text Input
				break
			case 3: htmlData += customFormCreateRadioYesNoInput(item)	// Radio Yes/No
				break
			case 4: htmlData += customFormCreateCheckboxInput(item)		// Checkbox
				break
			case 5: htmlData += customFormCreateTextAreaInput(item)		// Text Area Input
				break
			case 6: htmlData += customFormCreateDateInput(item)			// Date
				break
			case 7: htmlData += customFormCreateSingleSelectInput(item)	// Single Select
				break
			case 8: htmlData += customFormCreateMultiSelectInput(item)	// Multi Select
				break
			case 9: htmlData += customFormCreatePictureInput(item)		// Picture Area
				break
			case 10: htmlData += customFormCreateSignatureInput(item)	// Signature
				break
			case 11: htmlData += customFormCreateSectionTitle(item)		// Section Title
				break
			case 12: htmlData += customFormCreateSeparator(item)		// Separator
				break
			case 13: htmlData += customFormCreateContext(item)	// Context
				break
			case 14: htmlData += customFormCreateTimeInput(item)	// Time Selection
				break
			default:
				break
		}

		// Add additinal info section if required
		if(item.fbi_additional_info_required > 0)
			htmlData += customFormCreateAdditionalInfoInput(item)

	})
	document.getElementById('customFormPlaceholder').innerHTML = htmlData
	setTextInputStyle()
}

///////////
// Inputs

function customFormCreateRadioInput(details) {	
	let itemHtml = `<div class="mb-4">
						<label>${details.fbi_field_label}</label>
						<div class="form-check custom-radio pl-0">
							<input type="radio" class="form-check-input trans_input" id="item_${details.fbi_id}_yes" name="item_${details.fbi_id}" value="1379" onchange="radioChanged(0,${details.fbi_id},${details.fbi_additional_info_required},${details.fbi_required})" ${checkRequired(details.fbi_required)}>
							<label class="form-check-label mr-2" for="item_${details.fbi_id}_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

							<input type="radio" class="form-check-input trans_input" id="item_${details.fbi_id}_no" name="item_${details.fbi_id}" value="1380" onchange="radioChanged(1,${details.fbi_id},${details.fbi_additional_info_required},${details.fbi_required})">
							<label class="form-check-label mr-2" for="item_${details.fbi_id}_no"><span class='translate' data-i18n="1380" notes="No"></span></label>

							<input type="radio" class="form-check-input trans_input" id="item_${details.fbi_id}_na" name="item_${details.fbi_id}" value="1381" onchange="radioChanged(2,${details.fbi_id},${details.fbi_additional_info_required},${details.fbi_required})">
							<label class="form-check-label mr-2" for="item_${details.fbi_id}_na"><span class='translate' data-i18n="1381" notes="N/A"></span></label>
						</div>
					</div>`
	return itemHtml
}

function customFormCreateRadioYesNoInput(details) {	
	let itemHtml = `<div class="mb-4">
						<label>${details.fbi_field_label}</label>
						<div class="form-check custom-radio pl-0">
							<input type="radio" class="form-check-input trans_input" id="item_${details.fbi_id}_yes" name="item_${details.fbi_id}" value="1379" onchange="radioChanged(0,${details.fbi_id},${details.fbi_additional_info_required},${details.fbi_required})" ${checkRequired(details.fbi_required)}>
							<label class="form-check-label mr-2" for="item_${details.fbi_id}_yes"><span class='translate' data-i18n="1379" notes="Yes"></span></label>

							<input type="radio" class="form-check-input trans_input" id="item_${details.fbi_id}_no" name="item_${details.fbi_id}" value="1380" onchange="radioChanged(1,${details.fbi_id},${details.fbi_additional_info_required},${details.fbi_required})">
							<label class="form-check-label mr-2" for="item_${details.fbi_id}_no"><span class='translate' data-i18n="1380" notes="No"></span></label>
						</div>
					</div>`
	return itemHtml
}

function customFormCreateCheckboxInput(details) {
	let itemHtml = `<div class="form-check pl-0 mb-4">
					<input type="checkbox" class="form-check-input ml-0" id="item_${details.fbi_id}" name="item_${details.fbi_id}" value="0" onchange="checkboxChanged(${details.fbi_id})" ${checkRequired(details.fbi_required)}>
					<label class="form-check-label" for="item_${details.fbi_id}">${details.fbi_field_label}</span></label>
				</div>`
	return itemHtml
}

function customFormCreateTextInput(details) {
	let itemHtml = `<div class="md-form">
						<input type="text" name="item_${details.fbi_id}" id="item_${details.fbi_id}" length="200" maxlength="200" class="form-control" ${checkRequired(details.fbi_required)}>
						<label class = "md-select-overlapping-text-sm-label"   for="item_${details.fbi_id}">${details.fbi_field_label}</label>
					</div>`
	return itemHtml

}

function setTextInputStyle(){
	let inputs = document.getElementsByClassName("md-form")
	let inputsLength = inputs.length
	for(i=0;  i < inputsLength; i++) {
		let label = inputs[i].getElementsByTagName("label")		
		let labelText = label.length == 0 ? '' : label[0].childNodes[0].data
		let charLength = labelText ? labelText.length : 0
		
		if (inputs[i].getElementsByTagName("input")[0]){
			if((window.screen.width >= 700) || ((charLength >= 0) && (charLength < 50))){
				inputs[i].getElementsByTagName("input")[0].style.height = "auto"
			}
			else if ((charLength >= 50) && (charLength < 100)) {  
				inputs[i].getElementsByTagName("input")[0].style.height = "60px"
			}
			else if(charLength > 100) {
				inputs[i].getElementsByTagName("input")[0].style.height = "100px"
			}

		}
	}
}

function customFormCreateTextAreaInput(details) {
	let itemHtml = `<div class="md-form">
						<textarea type="text" name="item_${details.fbi_id}" id="item_${details.fbi_id}" class="form-control md-textarea" wrap="VIRTUAL" ${checkRequired(details.fbi_required)}></textarea>
						<label for="item_${details.fbi_id}">${details.fbi_field_label}</label>
					</div>`
	return itemHtml
}

function customFormCreateDateInput(details) {
	let itemHtml = `<div class="md-form">
						<input type="text" name="item_${details.fbi_id}" id="item_${details.fbi_id}" class="form-control datepicker" ${checkRequired(details.fbi_required)}>
						<label for="item_${details.fbi_id}">${details.fbi_field_label}</label>
					</div>`
    return itemHtml
}

function customFormCreateMultiSelectInput(details) {
	let itemHtml = `<div class="position-relative my-4">
						<select name="item_${details.fbi_id}" id="item_${details.fbi_id}" class="select-multiple" multiple ${checkRequired(details.fbi_required)}>
							${populateSelectList(details.fbi_list_type_rlh_name, details.fbi_list_type_flo_id, details.fbi_list_type_clh_id)}
						</select>
						<label for="item_${details.fbi_id}">${details.fbi_field_label}</label>
					</div>`
    return itemHtml
}

function customFormCreateSingleSelectInput(details) {
	let itemHtml = `<div class="position-relative my-4">
						<select name="item_${details.fbi_id}" id="item_${details.fbi_id}" class="select-single" ${checkRequired(details.fbi_required)}>
							${populateSelectList(details.fbi_list_type_rlh_name, details.fbi_list_type_flo_id, details.fbi_list_type_clh_id)}
						</select>
						<label for="item_${details.fbi_id}">${details.fbi_field_label}</label>
					</div>`
    return itemHtml
}

function customFormCreatePictureInput(details) {
	let itemHtml = `<div class="form-group photoImage" id="item_${details.fbi_id}" ${checkRequired(details.fbi_required)}>
						<label class="d-block">${details.fbi_field_label}</label>
						<canvas id="canvas" style='display:none;'></canvas>
						<div class="btn-group d-flex" role="group">
							<div class="btn btn-block btn-outline-secondary file-field px-1">
								<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="Add Images"></span>
								<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
							</div>
						</div>
						<div class="row photoGallery pt-2" id="galleryid_${details.fbi_id}"></div>
					</div>`
    return itemHtml
}

function customFormCreateSignatureInput(details) {
	let itemHtml = `<div class="my-4">
						<label class="text-muted">${details.fbi_field_label}</label>
						<div class="btn-group d-flex" role="group" aria-label="Action subforms">
							<div class='btn btn-outline-secondary col waves-effect p-2 m-0 sign' signaturename='item_${details.fbi_id}_signature'><i class="fa fa-pen"></i> <span class='translate' data-i18n="1396" notes="Sign"></span></div>
							<div class="btn btn-outline-secondary col waves-effect p-2 m-0 sign_comment d-none"><i class="far fa-comment"></i> <span class='translate' data-i18n="3915" notes="Comment"></span></div>
							<div class='btn btn-outline-secondary col waves-effect p-2 m-0 clear_sign d-none'><i class="fa fa-eraser"></i> <span class='translate' data-i18n="1422" notes="Clear"></span></div>
						</div>
						<img id='item_${details.fbi_id}_signature_img' src='' class='signatureImage d-block pt-2'/>
						<input type="hidden" name="item_${details.fbi_id}_signature" id="item_${details.fbi_id}_signature" class='modalSignature' value='' ${checkRequired(details.fbi_required)}>
						<input type="hidden" name="${details.fbi_id}_vector_employee" id='${details.fbi_id}_vector_employee' value=''>
						<input type="hidden" name="item_${details.fbi_id}_signature_comments" id='item_${details.fbi_id}_signature_comments' class="sig_comment" value=''>
						<small class="form-text text-muted  d-none md-form"><input class="form-control form-control-sm border-0 text-center" type="text" name="item_${details.fbi_id}_signature_img_time" id="item_${details.fbi_id}_signature_img_time" notes='item_${details.fbi_id}_signature_img_time' readonly/></small>
					</div>`
    return itemHtml
}

function customFormCreateTimeInput(details) {
	let itemHtml = `<div class="md-form">
						<input type="text" name="item_${details.fbi_id}" id="item_${details.fbi_id}" class="form-control timepicker" ${checkRequired(details.fbi_required)}>
						<label for="item_${details.fbi_id}">${details.fbi_field_label}</label>
					</div>`
    return itemHtml
}

/////////////
// Static

function customFormCreateSectionTitle(details) {
	let itemHtml = `<h6 class="text-secondary mb-2">${details.fbi_field_label}</h6>`
    return itemHtml
}

function customFormCreateSeparator(details) {
	let itemHtml = `<hr></hr>`
    return itemHtml
}

function customFormCreateContext(details) {
	let itemHtml = `<div class="mb-2">
						<small>${details.fbi_field_label}</small>
					</div>`
    return itemHtml
}

function customFormCreateAdditionalInfoInput(details) {

	let hidden = false
	if(details.fbi_fft_id == 1 || details.fbi_fft_id == 3) // Start hidden for radio fields
		hidden = true

	
	let itemHtml = ""
	if(details.fbi_additional_info_type == 1) { // Input
		itemHtml = `<div class="md-form ${hidden ? 'd-none' : ''}">
						<input type="text" name="item_${details.fbi_id}_additional_info" id="item_${details.fbi_id}_additional_info" length="200" maxlength="200" class="form-control" ${hidden ? '' : checkRequired(details.fbi_required)}>
						<label for="item_${details.fbi_id}_additional_info">${details.fbi_additional_info_label}</label>
					</div>`
		
	} else { // Textarea
		itemHtml = `<div class="md-form ${hidden ? 'd-none' : ''}">
						<textarea type="text" name="item_${details.fbi_id}_additional_info" id="item_${details.fbi_id}_additional_info" class="form-control md-textarea" wrap="VIRTUAL" ${hidden ? '' : checkRequired(details.fbi_required)}></textarea>
						<label for="item_${details.fbi_id}_additional_info">${details.fbi_additional_info_label}</label>
					</div>`
	}

	return itemHtml
}

function checkRequired(required) {
	if(required)
		return "required"
	else
		return ""
}

function radioChanged(option, fbi_id, fbi_additional_info_required, fbi_required) {

	if(fbi_additional_info_required == 0)
		return

	let infoItem = document.getElementById(`item_${fbi_id}_additional_info`)

	infoItem.parentElement.classList.add("d-none")
	infoItem.removeAttribute("required")
	infoItem.value = ""

	if((option == 0 && [1,3,5,7].includes(fbi_additional_info_required)) // Yes
	|| (option == 1 && [2,3,6,7].includes(fbi_additional_info_required)) // No
	|| (option == 2 && [4,5,6,7].includes(fbi_additional_info_required))) { // N/A
		infoItem.parentElement.classList.remove("d-none")
		if(fbi_required)
			infoItem.setAttribute("required", "")
	}
}

function checkboxChanged(fbi_id) {
	document.getElementById(`item_${fbi_id}`).value = document.getElementById(`item_${fbi_id}`).checked ? 1 : 0
}

function populateSelectList(ref_name, flo_id=null, clh_id=null) {

	if(!ref_name && flo_id) {

		switch(flo_id) {
			case 1:
				// employees.
				let optionData = ""
				userEmployeeSelectData.forEach((data)=>{
					optionData += `<option value="${data.per_full_name}">${data.per_full_name}</option>`
				})
				return optionData
				break
			default:
				return ""
				break
		}
	} else if( !ref_name && clh_id){
	 
		let optionData = ""
		let customList = selectListData.customLists.filter((item) => item.cld_clh_id == clh_id)
		if(!customList) {
			return optionData
		}
		customList.forEach((data)=>{
			optionData += `<option value="${data.cld_name}">${data.cld_name}</option>`
		})

		return optionData
	
	} else if (ref_name) {

		let selectlist = selectListData[ref_name]
		let optionData = ""
		
		if(!selectlist) {
			console.warn("Select List Data Does Not Exist");
			return optionData
		}
		
		selectlist.forEach((data)=>{
			optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
		})

		return optionData
	}

	return ""
}

let formBody = {
	formInitialize: function (theForm)	{
		if(debug) console.log('formBody.formInitialize() called.');
	},

	formTerminate: function (theForm)	{
		if(debug) console.log('formBody.formTerminate() called.');
	},

	formValidate: function (theForm)	{
		if(debug) console.log('formBody.formValidate() called.');
		return true;
	}	
}

</script>
<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>