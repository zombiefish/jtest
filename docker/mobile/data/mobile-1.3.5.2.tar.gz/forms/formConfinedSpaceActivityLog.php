<?php	
  $strPageTitle = 'Confined Space Activity Log';
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/main.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/header.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/pageHeader.php");
  include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/mainNav.php");

?>

<main class="col containter-fluid mobile-content">
	<div class="row">
		<div class="col-12 mb-4">
			<div class="card mb-4">
				<div class="card-body">
					
					<h6 class="text-secondary"><span class='translate' data-i18n="2246" notes="Confined Space Activity Log"></span></h6>
					<div class="pt-1 position-relative my-4">
						<select name="draft" id="draft" class="select-single" onChange="getFormData(this)">
						</select>

						<label for="draft"><span class='translate' data-i18n="1474" notes="Form Drafts"></span></label>
					</div>
          			
					<form name="activity_log" id="TemplateForm" class="needs-validation" method="POST" action="#" novalidate>

						<?php include 'includes/CommonFormHeader.php' ?>
						<h6 class="text-secondary pt-4"><span class='translate' data-i18n="2348" notes="Issued Confined Space Permit"></span></h6>
						<div class="md-form"> 
							<input type="text" name="permit_date" id="permit_date" class="form-control datepicker" required>
							<label for="permit_date"><span class='translate' data-i18n="736" notes="Permit Date"></span></label>
						</div>
						<div class="md-form">
							<input type="text" name="confined_space_location_name" id="confined_space_location_name" class="form-control" length="200" maxlength="200" required>
							<label for="confined_space_location_name"><span class='translate' data-i18n="95" notes="Confined Space Location Name"></span></label>
						</div>				

						<div id="requires_gas_test">

							<h6 class="text-secondary pt-4"><span class='translate' data-i18n="9543" notes="Atmospheric Testing"></span></h6>

							<div id="gasTests"></div>

							<div id='addGasTest' class='btn btn-sm btn-primary translate'><i class="fa fa-plus"></i> <span class='translate' data-i18n='9539' notes="ADD ATMOSPHERIC TESTING"></span> </div>
							<div id='removeGasTest' class='btn btn-sm btn-outline-primary'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n="9575" notes="REMOVE ATMOSPHERIC TESTING"></span></div>
						</div>

							<h6 class="text-secondary pt-4"><span class='translate' data-i18n="2353" notes="Employee Entry and Exit Log"></span></h6>
							<div id="employee">
								<div id="crews"></div>
								<br />
								<div id='addCrew' class='btn btn-sm btn-primary translate'><i class="fa fa-plus"></i> <span class='translate' data-i18n='2359' notes='ADD EMPLOYEE'></span> </div>
								<div class='btn btn-sm btn-outline-primary' id="removeCrew"><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n="2360" notes="REMOVE EMPLOYEE"></span></div>
							</div>
				
						<br />
						<div class="form-group photoImage" id="entry_confined_space"> 
							<label class="d-block"><span class='translate' data-i18n="743" notes="Pictures of Entry and Confined Space"></span></label>
							<canvas id="canvas" style='display:none;'></canvas>
							<div class="btn-group d-flex" role="group">
								<div class="btn btn-block btn-outline-secondary file-field px-1">
									<i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="Add Images"></span>
									<input type="file" class="pics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
								</div>
							</div>
							<small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
								<div class="row photoGallery" id="galleryid">
								</div>
						</div>
						<div class="md-form">
							<textarea name="comments" id="comments" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
							<label for="comments"><span class='translate' data-i18n="792" notes="Rescue Team Details"></span></label>
						</div>

						<?php include 'includes/CommonFormFooter.php' ?>
						<input type="hidden" name="formname" id="formname" tag = "2246" class = "trans_input" value="2246" />
						<input type="hidden" name="formtype" id="formtype" value="SUP" />
						<input type="hidden" name="formid" id="formid" value="372378" />
						<input type="hidden" name="version" id="version" value="1" />
						<input type="hidden" name="_rev" id="_rev" value="" />
						<input type="hidden" name="_id" id="_id" value="" />
						<input type="hidden" name="keyField" id="keyField" value="site|workplace" />
						<input type="hidden" name="draftField" id="draftField" value="draft" />
						<input type="hidden" name="numCrews" id="numCrews" value='1' />
						<input type="hidden" name="totalCrews" id="totalCrews" value='10' />
						<input type="hidden" name="numAirTest" id="numAirTest" value='1' />
						<input type="hidden" name="totalAirTest" id="totalAirTest" value='6' />
						<input type="hidden" name="employeeTimeinTimeout" id="employeeTimeinTimeout" value="1,1,1,1,1,1,1,1,1,1" />                   
					</form>
				</div>
			</div>
		</div>
	</div>
</main>

<script type="text/javascript" src="/js/formHandler2.js"></script>
<?php	include_once($_SERVER['DOCUMENT_ROOT'] . "/includes/footer.php");?>

<script type="text/javascript">

	var formBody = {
		
		formInitialize: function (theForm)	{
			if (debug) console.log('formBody.formInitialize() called.');
		},
		
 
		formTerminate: function (theForm)	{
			if(debug) console.log('formBody.formTerminate() called.');
		},

		formValidate: function (theForm)	{
			if(debug) console.log('formBody.formValidate() called.');
		},		
		
	}

	let atmosphericlist=[]	
	let atmosphericlistItems=[]
	let atmosphericlistsArray=[]
	let originalAtmosphericlistlength=null
	let airtestcount = ''
	const totalAirTest = parseInt(document.getElementById('totalAirTest').value)	

	document.getElementById('removeGasTest').classList.add('d-none')

	// add a gas test
	document.getElementById('addGasTest').addEventListener('click',(e)=>{
		airtestcount = document.getElementById('numAirTest').value
		if(airtestcount < totalAirTest) {
			airtestcount++
			addGasTest(airtestcount)
			if(airtestcount === totalAirTest)	
			document.getElementById('addGasTest').classList.add('d-none')
			document.getElementById('numAirTest').value = airtestcount
		} 
		if(airtestcount > 1 && airtestcount <= totalAirTest)
		document.getElementById('removeGasTest').classList.remove('d-none')
	})

	function addGasTest(tester,mode){			
		const gasTestsModal = 
		`<div class="gasTestSection" value=${tester}>
			<h6 class="text-secondary pt-4"><span class='translate' data-i18n="2350" notes="Test"></span> ${tester}</h6>
			<div class="md-form">
				<input type="text" class="form-control timepicker" name="time_of_test_${tester}" id="time_of_test_${tester}" required>
				<label for="time_of_test_${tester}"><span class='translate' data-i18n="864" notes="Time of Test"></span></label>
			</div>

			<div class="pt-1 position-relative my-4">
				<select name="name_of_tester_${tester}" id="name_of_tester_${tester}" class="select-single mobile-employee-select-single" single required>
				</select>
				<label for="name_of_tester_${tester}"><span class='translate' data-i18n="653" notes="Name of Tester"></span></label>
			</div>

			<div class="md-form">
				<input type="number" class="form-control" name="oxygen_${tester}" id="oxygen_${tester}" min="0.00" step="0.01" max="100.00" required> 
				<label  for="oxygen_${tester}"><span class='translate' data-i18n="2343" notes="Oxygen (19.5% - 23.0%)"></span></label>
			</div>
			
			<div class="md-form">
				<input type="number" class="form-control" name="lel_${tester}" id="lel_${tester}" min="0.00" step="0.01" max="100.00" required>
				<label  for="lel_${tester}"><span class='translate' data-i18n="9541" notes="LEL - Lower Explosive Limit (<10%)"></span></label>
			</div>

			<div class="pt-1 position-relative my-4 d-none" id="div_atmospheric_gas_${tester}">
				<select name="selectatmospheric_gas_${tester}" id="selectatmospheric_gas_${tester}" class="select-single mobile-atmospheric-gas" onchange="selectGas(this,${tester})" single>
				</select>
				<label for="selectatmospheric_gas_${tester}"><span class='translate' data-i18n="9542" notes="Select Atmospheric Gas"></span></label>
			</div>
			<div class="d-flex flex-row">
				<div id='addAtmosphericGas_${tester}' class='btn-sm translate text-primary'><i class="fa fa-plus"></i> <span class='translate' data-i18n='9540' notes="Add Atmospheric Gas"></span> </div>
				<div id='removeAtmosphericGas_${tester}' class='btn-sm ml-2 d-none'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n="9566" notes="REMOVE ATMOSPHERIC GAS"></span></div>
			</div>
			</div>
		`
		
		$("#gasTests").append(gasTestsModal);
		if(tester>1 && !mode){
			initializeSelect2Dynamic(`name_of_tester_${tester}`)
			initializeSelect2Dynamic(`selectatmospheric_gas_${tester}`)
			formHeader.populateEmployeeSelectSingle(`name_of_tester_${tester}`)
			populateAtmosphericGasSelect(tester)
			try {$('.translate').localize()} catch {}
			initializePickadate()
		}

		// add Atmospheric Gas 
		document.getElementById(`addAtmosphericGas_${tester}`).addEventListener('click',(e)=>{
			populateNewAtmosphericGasSelect(tester)
			document.getElementById(`div_atmospheric_gas_${tester}`).classList.remove('d-none')
		})		
	
		document.getElementById(`removeAtmosphericGas_${tester}`).addEventListener('click',(e)=>{
			let targetGasElement=document.getElementById(`div_atmospheric_gas_${tester}`).previousElementSibling.firstChild
			atmosphericlistsArray[tester-1].push(targetGasElement.value)
			targetGasElement.parentElement.remove()
			document.getElementById(`div_atmospheric_gas_${tester}`).classList.add('d-none')
			document.getElementById(`addAtmosphericGas_${tester}`).classList.remove('d-none')
			if(atmosphericlistsArray[tester-1].length>=originalAtmosphericlistlength){
				document.getElementById(`removeAtmosphericGas_${tester}`).classList.add('d-none')
			}
		})
	}

	function populateAtmosphericGasSelect(tester){
		let optionData = `<option></option>`
		atmosphericlist.forEach((data)=>{
			optionData += `<option value="${data.rld_name}">${data.rld_name}</option>`
		})
		$(`#selectatmospheric_gas_${tester}`).empty().append(optionData)
		atmosphericlistsArray.push(newAtmosphericlist())   //push the new added tester into array
	}

	function selectGas(ele,tester){
		if(ele.selectedIndex<=0){
			return
		}
		atmosphericlistsArray[tester-1].splice(ele.selectedIndex-1,1)
		let gasIndex=originalAtmosphericlistlength-atmosphericlistsArray[tester-1].length
		let newele=`<div class="md-form"><input type="hidden" name="test_${tester}_gas_${gasIndex}" id="test_${tester}_gas_${gasIndex}" value="${ele.options[ele.selectedIndex].value}" />
		<input type="number" class="form-control" name="test_${tester}_ppm_${gasIndex}" id="test_${tester}_ppm_${gasIndex}" min="0.00" step="0.01" max="100.00" required> 
		<label  for="test_${tester}_ppm_${gasIndex}">${ele.options[ele.selectedIndex].value}</label></div>`
		$(newele).insertBefore(ele.parentNode)
		$(`#selectatmospheric_gas_${tester}  option:selected`).remove()
		$(`#selectatmospheric_gas_${tester}`).val('').change()
		$(`#selectatmospheric_gas_${tester}`).parent().find('label').removeClass('filled')
		ele.parentNode.classList.add('d-none')
		if(gasIndex>0){
			document.getElementById(`removeAtmosphericGas_${tester}`).classList.remove('d-none')
		}
		if(gasIndex>=14){ //only allow add 14 gases
			document.getElementById(`addAtmosphericGas_${tester}`).classList.add('d-none')
		}
	}

	function newAtmosphericlist() {
		copyAtmosphericlist = atmosphericlistItems.slice(0)
		return copyAtmosphericlist
	}
	function populateNewAtmosphericGasSelect(tester){
		let optionData = `<option></option>`
		atmosphericlistsArray[tester-1].forEach((data)=>{
			optionData += `<option value="${data}">${data}</option>`
		})
		$(`#selectatmospheric_gas_${tester}`).empty().append(optionData)
	}

	// remove a gas test 
	document.getElementById('removeGasTest').addEventListener('click',(e)=>{
		let myGasTest = $(`.gasTestSection[value="${airtestcount}"]`)
		myGasTest.remove()
		airtestcount--
		document.getElementById('numAirTest').value = airtestcount
		if(airtestcount > 0 && airtestcount <= totalAirTest)
		document.getElementById('removeGasTest').classList.remove('d-none')
		document.getElementById('addGasTest').classList.remove('d-none')
		if(airtestcount >= totalAirTest)
		document.getElementById('addGasTest').classList.add('d-none')
		if(airtestcount === 1)
		document.getElementById('removeGasTest').classList.add('d-none')
		atmosphericlistsArray.pop()
	})

	// Populate the Form from a Draft by showing the sections activated in FormHandler
	function populateGasTestDynamicForm(numAirTest,totalAirTest) {
		$(`.gasTestSection`).remove()
		airtestcount = numAirTest
		if(airtestcount > 1 && airtestcount <= totalAirTest)
		document.getElementById('removeGasTest').classList.remove('d-none') 
		if(airtestcount >= totalAirTest)
		document.getElementById('addGasTest').classList.add('d-none')
		for (a = 1; a <= airtestcount; a++) {
			addGasTest(a,"loadDraft")
		}
	}

	function getSafetyCheckboxStatus(){
			var the_inputs=document.getElementsByTagName("input");
			for(var n=0;n<the_inputs.length;n++){
				if(the_inputs[n].type=="checkbox"){
				var status = the_inputs[n].checked;
						if (status) {
							the_inputs[n].value='1'
						} else {
							the_inputs[n].value='0'
						}
				}
			}
	};

	$( document ).ready(function() {
		addCrew(1)
		addGasTest(1)
		selectCachePromise().then((selectListData)=> {
			atmosphericlist=selectListData.ref_atmospheric_gases
			originalAtmosphericlistlength=selectListData.ref_atmospheric_gases.length
			atmosphericlist.forEach((data)=>{
				atmosphericlistItems.push(data.rld_name)
			})
			populateAtmosphericGasSelect(1)     //append the first tester's gas list option
		})
	});

	// reload page from Draft mode 
	function draftPostProcess(parsedJSON){
		atmosphericlistsArray=[]
		if(parsedJSON["numAirTest"]){
			for(let i=1;i<=parsedJSON["numAirTest"];i++){
				atmosphericlistsArray.push(newAtmosphericlist())
			}
		}  
		for (let [key, value] of Object.entries(parsedJSON)) {
			if(`${key}`.startsWith("test_")){
				let elemnentName=`${key}`.split("_")
				if(elemnentName[2]=="ppm"){
					let gasIndex=elemnentName.pop()
					let tester=elemnentName[1]
					$(`#addAtmosphericGas_${tester}`).click()
					let gasName=document.getElementById(`test_${tester}_gas_${gasIndex}`).value
					// remove the hidden inputs from loading draft
					document.getElementById(`test_${tester}_gas_${gasIndex}`).remove()
					document.getElementById(`test_${tester}_ppm_${gasIndex}`).remove()
					let index = atmosphericlistsArray[tester-1].indexOf(gasName)
					if (index > -1) { // only splice array when item is found
						atmosphericlistsArray[tester-1].splice(index, 1)
					}
					let newele=`<div class="md-form"><input type="hidden" name="test_${tester}_gas_${gasIndex}" id="test_${tester}_gas_${gasIndex}" value="${gasName}" />
					<input type="number" class="form-control" name="test_${tester}_ppm_${gasIndex}" id="test_${tester}_ppm_${gasIndex}" min="0.00" step="0.01" max="100.00" required> 
					<label  for="test_${tester}_ppm_${gasIndex}">${gasName}</label></div>`
					$(newele).insertBefore($(`#div_atmospheric_gas_${tester}`))
					$(`#selectatmospheric_gas_${tester}  option:selected`).remove()
					$(`#selectatmospheric_gas_${tester}`).parent().find('label')[0].classList.remove('filled')
					document.getElementById(`div_atmospheric_gas_${tester}`).classList.add('d-none')
					if(gasIndex>0){
						document.getElementById(`removeAtmosphericGas_${tester}`).classList.remove('d-none')
					}
					if(gasIndex>=14){ //only allow add 14 gases
						document.getElementById(`addAtmosphericGas_${tester}`).classList.add('d-none')
					}				
					$(`#test_${tester}_ppm_${gasIndex}`).val(value).parent().find("label").addClass("active")
				}
			}
		}
	}

	function addCrew(crewNum,mode){
		const crewsModal = 
		`<div class="crewsection" value=${crewNum}>
			<h6 class="text-secondary pt-4"><span class='translate' data-i18n="190" notes="Employee"></span> ${crewNum}</h6>
			<div class="pt-1 position-relative my-4">
				<select name="employee_name_${crewNum}" id="employee_name_${crewNum}" class="select-single mobile-employee-select-single" single required>
				</select>
				<label for="employee_name_${crewNum}"><span class='translate' data-i18n="204" notes="Employee Name"></span></label>
			</div>
			<div class="form-check pl-0">
				<input type="checkbox" class="form-check-input ml-0" name="rescue_plan_has_been_reviewed_${crewNum}" id="rescue_plan_has_been_reviewed_${crewNum}"   value = '0' onchange="getSafetyCheckboxStatus()">
				<label class="form-check-label" for="rescue_plan_has_been_reviewed_${crewNum}"><span class='translate' data-i18n="2354" notes="Rescue Plan Been Reviewed"></span></label>
			</div>
			<div class="looping_time_cycle">
				<div class="time_cycle" value='1'> 
					<div class="md-form">
						<input type="text" class="form-control timepicker" name="employee${crewNum}_time_in1" id="employee${crewNum}_time_in1" required>
						<label for="employee${crewNum}_time_in1"><span class='translate' data-i18n="2355" notes="Time In"></span></label>
					</div>
					<div class="md-form">
						<input type="text" class="form-control timepicker" name="employee${crewNum}_time_out1" id="employee${crewNum}_time_out1" required>
						<label for="employee${crewNum}_time_out1"><span class='translate' data-i18n="2356" notes="Time Out"></span></label>
					</div>
				</div>
			</div>
			<div class='btn btn-sm btn-primary addTimeCycle'><i class="fa fa-plus"></i> <span class='translate' data-i18n="2357" notes="ADD TIME CYCLE"></span></div>
			<div class='btn btn-sm btn-outline-primary removeTimeCycle d-none'><i class="fa fa-trash-alt"></i> <span class='translate' data-i18n="2358" notes="REMOVE TIME CYCLE"></span></div>
		</div>`
		
		$("#crews").append(crewsModal);
		if(crewNum>1 && !mode){
			try {$('.translate').localize()} catch {}
			initializeSelect2Dynamic(`employee_name_${crewNum}`)
			formHeader.populateEmployeeSelectSingle(`employee_name_${crewNum}`)
		}

		var timeCycleButtons = document.getElementsByClassName('addTimeCycle')
		timeCycleButtons[timeCycleButtons.length - 1].addEventListener('click', (e)=>{
			var default_addTimeCycle = `<div class="time_cycle" value='timeNumber'> 
									<div class="md-form">
										<input type="text" class="form-control timepicker" name="employeeemployeeNumber_time_intimeNumber" id="employeeemployeeNumber_time_intimeNumber"  required>
										<label for="employeeemployeeNumber_time_intimeNumber">` + i18next.t('2355') + `</label>
									</div>
									<div class="md-form">
										<input type="text" class="form-control timepicker" name="employeeemployeeNumber_time_outtimeNumber" id="employeeemployeeNumber_time_outtimeNumber" required>
										<label for="employeeemployeeNumber_time_outtimeNumber">` + i18next.t('2356') + `</label>
									</div>
								</div>
							`
			var timecycleelement = undefined
			if (e.target.classList.contains('addTimeCycle')){
				timecycleelement = e.target
			} else {
				timecycleelement = e.target.parentElement
			}
			var len_addTimeCycle = timecycleelement.previousElementSibling.children.length
			if (len_addTimeCycle + 1 <= 10) {
				var elmnt = document.createElement("div");
				elmnt.innerHTML=default_addTimeCycle.replaceAll("timeNumber", len_addTimeCycle + 1).replaceAll("employeeNumber", timecycleelement.parentElement.getAttribute("value"))
				timecycleelement.previousElementSibling.appendChild(elmnt);

				let pickadateTranslations = sofvie_pickatime_languages[`${selectedLanguage}`]
				$('.timepicker').pickatime({
					donetext: pickadateTranslations.done,
					cleartext: pickadateTranslations.clear,
					twelvehour: true, 
					'default': '24:00'
				});

				var array = document.getElementById("employeeTimeinTimeout").getAttribute("value").split(",");
				array[timecycleelement.parentElement.getAttribute("value") - 1] = (len_addTimeCycle + 1).toString()
				document.getElementById("employeeTimeinTimeout").setAttribute("value", array.toString())
				
				if(len_addTimeCycle + 1 == 10) {
					timecycleelement.classList.add('d-none')
				}

				if(len_addTimeCycle == 1) {
					timecycleelement.nextElementSibling.classList.remove('d-none')
				}
			}
		})

		timeCycleButtons = document.getElementsByClassName('removeTimeCycle')
		timeCycleButtons[timeCycleButtons.length - 1].addEventListener('click', (e)=>{
			if (e.target.classList.contains('removeTimeCycle')){
				e = e.target
			} else {
				e = e.target.parentElement
			}
			var len_removeTimeCycle = e.previousElementSibling.previousElementSibling.children.length
			if (len_removeTimeCycle > 1) {
				e.previousElementSibling.previousElementSibling.children[len_removeTimeCycle - 1].remove()

				len_addTimeCycle = e.previousElementSibling.previousElementSibling.children.length
				var array = document.getElementById("employeeTimeinTimeout").getAttribute("value").split(",");
				array[e.parentElement.getAttribute("value") - 1] = len_addTimeCycle.toString()
				document.getElementById("employeeTimeinTimeout").setAttribute("value", array.toString())

				if (len_removeTimeCycle == 2) {
					e.classList.add('d-none')
				}
				if (len_removeTimeCycle == 10) {
					e.previousElementSibling.classList.remove('d-none')
				}
			}
		})
	}

</script>