function showAlertModal(theForm, theModal, modaltype = "warning", theElements) {
  let alertModal = `
    <div class="modal" id="alertModalShow" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
       <div class="modal-dialog modal-notify modal-success" role="document">
          <div class="modal-content">
             <div class="modal-header">
                <p class="heading lead">[Add modal title here]</p>
                </button>
             </div>
             <div class="modal-body">
                <div class="text-center">
                   <i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
                   <p class='modal-body-text'>[The form has been submitted successfully.]</p>
                </div>
             </div>
          <div class="modal-footer justify-content-center flex-wrap">
       </div>
    </div>`;

  $("#alertModalComponent").append(alertModal);


  let modal = new SofvieModal("alertModalShow");
  modal.modalSettings[modaltype] = theElements;
  modal.handleModal(modaltype);
  $('.translate').localize()
  var json = toJSONString(theForm);

  $("#alertModalCancel").click(() => {
    modal.hideModal();
    let backDrops = $(".modal-backdrop");
    if(backDrops.length > 1)
    backDrops[backDrops.length - 1].remove();
  });

  $("#alertModalConfirm").click(() => {
    saveChildForm(theForm, modal, theModal)
  });
}

function saveChildForm(theForm, modal, theModal){
  if ($("#child-selected-draft").val() !== "") {
    dbDraft.get($("#child-selected-draft").val()).then(function(doc) {
    return dbDraft.remove(doc);
    });
  }
  if (formHandle(theForm, "draft")) {
    var primaryKeyField = theForm.keyField.value;
    var json = toJSONString(theForm);
    if (theModal === "posModal") {
    document.getElementById(
      "positive_identification_opportunities_identified"
    ).value = "1";
    document.getElementById("pidChildExists").value = true;
    }
  
    if (theModal === "hapModal") {
    document.getElementById("hapChildExists").value = true;
    document.getElementById("hazards_identified").value = "1";
    }

    if (theModal === "genModal") {
      document.getElementById("gapChildExists").value = true;
      document.getElementById("general_actions_identified").value = "1";
      }
  
    if (primaryKeyField) {
    key = modalDraftName(primaryKeyField, theForm);
    $("#child-selected-draft").val(key.formid)
    addFormDraft(
      json,
      key,
      theForm.submissionId.value,
      theForm.formname.value,
      "no",
      "child"
    );
    }
  }
    modal.hideModal();
    $("body").removeClass("modal-open");
    let backDrops = $(".modal-backdrop");
    backDrops[backDrops.length - 1].remove();
    $(`#${theModal}`).modal("hide");
    $(`#${theModal}`).remove();
    backDrops.remove();
    startAutoSave()
  }

function modalDraftName(primaryKeyField, modalForm) {
  // Build a unique form identifier for saved draft of 'this' form, based on the contents of the hidden keyField
  // All draft field names contain the timestamp and site.
  // INPUTS:
  //	primaryKeyField - the primaryKeyField values, can be a pipe '|' seperated array for compound id's.
  // Create a base name for this form (name + formatted timestamp)
  var draftTitle = modalForm.formname.value + " " + formatDate(new Date());
  var arrKeys = primaryKeyField.split("|"); // Split the definition on a pipe seperator
  arrKeys.forEach(function(element) {
    if(modalForm[element].options){
      draftTitle = draftTitle + ' ' + modalForm[element].options[modalForm[element].selectedIndex].innerHTML
    }
    else{
      draftTitle = draftTitle + ' ' + modalForm[element].value	
    }	
  });
  return {
    "title": draftTitle.trim(),
    "formid": `${modalForm.formid.value} - ${formatDate(new Date())}`
  }
}

