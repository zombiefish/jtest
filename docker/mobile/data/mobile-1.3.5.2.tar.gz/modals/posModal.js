$("#pos-modal-open, #improvement_action_subform_yes").click(() => {
      // stop the Autosave on the parent
  stopAutoSave()
  let posModal = `<div class="modal fade posmodal" id="posModal" tabindex="-1" role="dialog" data-backdrop="static">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
       <div class="modal-header">
          <p class="heading lead"><span class='translate' data-i18n="751" note="Positive Recognition"></span></p>
        </div>
        <div class="modal-body" id="posModalSelect">

    <!--  ---------------   This is the Start of the Body of the Modal ----------------------  -->  
           <form id="child-form" class='needs-validation'>
           <input type="hidden" name="submissionId" id="child-submissionId" value="" />
           <input type="hidden" name="startFormTimeStamp" id="child-startFormTimeStamp" value="" />
           <input type="hidden" name="endFormTimeStamp" id="child-endFormTimeStamp" value="" />
           <input type="hidden" name="displayReferenceValue" id="child-displayReferenceValue" value="" />
           <input type="hidden" name="submittedby" id="child-submittedby" value="" />
           <input type="hidden" name="displayReferenceValue" id="child-selected-draft" value="" />

    <!--  ---------------------------------   Header Fields  ---------------------------------  -->  
           <input type="hidden" name="date" id="child-date" value="" />
           <input type="hidden" name="site" id="child-site" value="" />
           <input type="hidden" name="job_number" id="child-job_number" value="" />
           <input type="hidden" name="level" id="child-level" value="" />
           <input type="hidden" name="workplace" id="child-workplace" value="" />
           <input type="hidden" name="supervisor" id="child-supervisor" value="" />

           <h6 class="text-secondary"><span class='translate' data-i18n="751" note="Positive Recognition"></span></h6>

           <div class="pt-1 position-relative my-4" id='child-draft-container'>
             <select name="child-draft" id="child-draft" class="select-single" ">
             </select>
             <label for="draft"><span class='translate' data-i18n="1474" note="Form drafts"></span></label>
           </div>

           <div class="pt-1 position-relative my-4">
             <select name="recognition_type" id="child-recognition_type" class="select-single mobile-recognitiontype-select" required>
             </select>
             <label for="recognition_type"><span class='translate' data-i18n="771" note="Recognition Type"></span></label>
           </div>

           <div class="pt-1 position-relative my-4">
             <select name="recognition_of" id="child-recognition_of" class="select-multiple modal-employee-select modalSelect2" required multiple>
             </select>
             <label for="recognition_of"><span class='translate' data-i18n="770" note="Recognition Of"></span></label>
           </div>

           <div class="md-form">
             <textarea name="event_description" id="child-event_description" class="form-control md-textarea character_counter" wrap="VIRTUAL" required></textarea>
             <label for="event_description"><span class='translate' data-i18n="467" note="Event Description"></span></label>
           </div>

           <div class="mb-4">
             <label class="d-block"><span class='translate' data-i18n="893" note="Was recognition given to employee(s)"></span></label>
             <div class="form-check custom-radio pl-0">
               <input type="radio" class="form-check-input" id="child_was_recognition_given_yes" name="was_recognition_given" value="1" required>
               <label class="form-check-label mr-2" for="child_was_recognition_given_yes">
               <span class='translate' data-i18n="1379" note="Yes"></span>
               </label>

               <input type="radio" class="form-check-input" id="child_was_recognition_given_no" name="was_recognition_given" value="0">
               <label class="form-check-label mr-2" for="child_was_recognition_given_no">
               <span class='translate' data-i18n="1380" note="No"></span>
               </label>
             </div>
           </div>

<div class='submodal-cond-form-check-area'> 	
           <div class="pt-1 position-relative my-4">
             <select name="recognition_given_type" id="child-recognition_given_type" class="select-single mobile-recognitiongiventype-select" required>
             </select>
             <label for="recognition_given_type"><span class='translate' data-i18n='5025' notes='Type of Recognition Given'></span></label>
           </div>
</div>

         <div class="form-group photoImage" id="positive_id_multiphoto_picker"> 
          <canvas id="canvaspid" style='display:none;'></canvas>
          <div class="btn-group d-flex" role="group">
          <div class="btn btn-block btn-outline-secondary file-field px-1">
            <i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" note="Add Images"></span>
            <input type="file" id="pidpics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
          </div>
        </div>
          <small id="siteHelp" class="form-text text-muted">          
          <span class='translate' data-i18n="1389" note="Please take scene pictures from all perspectives"></span>
          </small>
          <div class="row photoGallery" id="positive_id_photos"></div>
        </div>

           <div class="btn-group d-flex mt-4 mb-2" role="group" aria-label="Form Actions">
               <button type="button" name="cancelModal" id="cancelSubForm" class="btn btn-primary col px-1 flex-fill">
               <span class='translate' data-i18n="1257" note="Cancel"></span>
               </button>
               <div name="reset" id="deleteModalDraft" class="btn btn-primary col px-1 flex-fill "><span class='translate' data-i18n="1408" note="Delete"></span></div>
               <div name="saveModalDraft" id="saveModalDraft" class="btn btn-primary col saveDraft childDraft px-1 flex-fill">
               <span class='translate' data-i18n="1258" note="Save"></span>               
               </div>
           </div>

						<input type="hidden" name="formname" id="child-formname" tag= "1006" class = "trans_input" value="1006" note="POSITIVE IDENTIFICATION" />
						<input type="hidden" name="formtype" id="child-formtype" value="HR" />
						<input type="hidden" name="formid" id="child-formid" value="166071" />
						<input type="hidden" name="version" id="child-version" value="34" />
						<input type="hidden" name="_rev" id="child-_rev" value="" />
						<input type="hidden" name="_id" id="child-_id" value="" />
						<input type="hidden" name="keyField" id="child-keyField" value="endFormTimeStamp" />
            <input type="hidden" name="draftField" id="child-draftField" value="draft" />
            <div id='alertModalComponent'></div>
           </form>             
     <!--  ---------------   This is the END of the Body of the Modal ----------------------  -->      
        </div>
    </div>
  </div>
</div>`;

let response = formHeader.formValidate($("form")[0]);

if (response) {

    // save the draft //
    // document.getElementById('saveDraft').click()
    // window.sessionStorage.setItem('modalsave','1')
    ////////////////////
    $("#child-modal")
      .empty()
      .append(posModal);
    $('.translate').localize()
			// Handle the Input values
			let inputs = document.getElementsByClassName('trans_input')
			for(input in inputs){
				try {
					inputs[input].setAttribute('value', i18next.t(inputs[input].getAttribute('value')))
				} catch (error) {}
			}

      $("#deleteModalDraft").css('display','none')
       pageOrientation() 
      
    photoChangeEvent(document.getElementById('pidpics'), 'child', 'canvaspid')

    $("#alertModalComponent").append(`
    <div class="modal" id="pictureWarningModal" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
      <div class="modal-dialog modal-notify modal-success" role="document">
        <div class="modal-content">
            <div class="modal-header">
              <p class="heading lead"></p>
              </button>
            </div>
            <div class="modal-body">
              <div class="text-center">
                  <i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
                  <p class='modal-body-text'></p>
              </div>
            </div>
        <div class="modal-footer justify-content-center">
      </div>
    </div>`)

    let select2LanguageFunction = window[`sofvie_select2_languages_${selectedLanguage}`];
    if (!(typeof select2LanguageFunction === "function"))
    {
      select2LanguageFunction = {}
      console.error("Failed to get Select2 Translations")
    }

    formHeader.populateEmployeeModalSelect()
    formHeader.populateRecognitionTypeSelect()
    formHeader.populateRecognitionGivenTypeSelect()

    $("#posModalSelect select:not(.custom-select, [class^=picker_])")
      .val("")
      .removeAttr("readonly");                              // Allow validation on select inputs except the ones with the class .custom-select (in DataTable)
    
    $("#posModalSelect select:not([class^=picker_])")
      .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", dropdownParent: $("#posModalSelect")})
      .on("select2:select", function() {
        reInitializeSelect2Language()
        $(this).parent().find("label").addClass("filled");
      })
      .on('select2:unselect', function () {
        if ($(".select2-selection__choice")[0]) {
          $(this).parent().find('label').addClass('filled');
        } else {
          $(this).parent().find('label').removeClass('filled');
        }
      })
      .on('select2:open', function () {
        reInitializeSelect2Language()
        $('.select2-results').css({ 'max-height': '260px' })
      });

    $("#posModalSelect .select2-selection__arrow b").addClass("fa fa-caret-down"); // Add caret on selects

    $("#cancelSubForm").click(event => {
      const theElements = {
        modalTheme: `modal-danger`,
        modalAlert: `fa-times-circle`,
        modalTitle: i18next.t("1410"),
        modalText: i18next.t("1409"),
        modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-danger waves-effect"><span class='translate' data-i18n="1257" note="Cancel"></span></a>
        <a role="button" id='cancelDraftConfirm' class="px-1 flex-fill btn btn-danger waves-effect confirm"><span class='translate' data-i18n="1379" note="Yes"></span></a>`
      };
      // $('.translate').localize()
      showAlertModal($("#child-form")[0], "posModal", "danger", theElements);

    $("#cancelDraftConfirm").click(() => {
          $('#alertModalShow').hide();
          let backDrops = $(".modal-backdrop");
          backDrops[backDrops.length - 1].remove();
          closePOSChildModal()
          startAutoSave()
      });
    });

    function closePOSChildModal() {
      $("#posModal").modal("hide");
      $("#posModal").hide();
      $("body").removeClass("modal-open");
      $("#posModal").remove()
      let backDrops = $(".modal-backdrop");
      if( backDrops[backDrops.length - 1]) {
        backDrops[backDrops.length - 1].remove();
      }
    }

    function closeModal(modal) {
      let backDrops = $(".modal-backdrop");
      if(backDrops[backDrops.length - 1]) {
        backDrops[backDrops.length - 1].remove();
      }
      modal.hideModal()
    }

    $("#saveModalDraft").click(event => {
      const childForm = $("#child-form")[0];
      if (debug) {
        for (let a = 0; a < childForm.length; a++) {
          if (!childForm[a].validity.valid) {
            console.log(
              `${childForm[a].name}  is  ${childForm[a].validity.valid}`
            );
          }
        }
      }

      // check Validity
      let Validity = invalidContentValidation(childForm)
      if (Validity === false) {
        event.preventDefault();
        event.stopImmediatePropagation();
        $('#child-modal').after(`<div class="modal fade" id="valModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
        <div class="modal-dialog modal-notify modal-success" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <p class="heading lead"></p>
            </div>
            <div class="modal-body">
              <div class="text-center">
                <i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
                <p class='modal-body-text'></p>
              </div>
            </div>
            <div class="modal-footer justify-content-center">
            </div>
          </div>
        </div>
      </div>`)
      let formModal = new SofvieModal('valModal');// initialize the Modal 
      if(childForm.classList.contains('invalid-content'))
        formModal.handleModal(`invalidContent`)
      else 
        formModal.handleModal(`validate`)
      $('.confirmValidation').click(()=>{
        closeModal(formModal)
      })
      } else {
        const theElements = {
          modalTheme: `modal-warning`,
          modalAlert: `fa-exclamation-triangle`,
          modalTitle: i18next.t('1415'),
          modalText: i18next.t("1409"),
          modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-warning waves-effect"><span class='translate' data-i18n="1257" note="Cancel"></span></a>
          <a role="button" id='alertModalConfirm' class="px-1 flex-fill btn btn-warning waves-effect confirm"><span class='translate' data-i18n="1379" note="Yes"></span></a>`
        };
        var json = toJSONString($("#child-form")[0]);
        showAlertModal($("#child-form")[0], "posModal", "warning", theElements);
        childForm.classList.add("validated");
      }
      childForm.classList.add("was-validated");
    });

    $("#deleteModalDraft").click(event => {
      const theElements = {
        modalTheme: `modal-danger`,
        modalAlert: `fa-times-circle`,
        modalTitle: i18next.t('1408'),
        modalText: i18next.t('1409'),
        modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-danger waves-effect"><span class='translate' data-i18n="1257" note="Cancel"></span></a>
        <a role="button" id='deleteDraftConfirm' class="px-1 flex-fill btn btn-danger waves-effect confirm"><span class='translate' data-i18n="1379" note="Yes"></span></a>`
      };
      showAlertModal($("#child-form")[0], "posModal", "warning", theElements);

      $("#deleteDraftConfirm").click(() => {
        if ($("#child-selected-draft").val() !== "") {
          dbDraft.get($("#child-selected-draft").val()).then(function(doc) {
            dbDraft.remove(doc);            
            $('#alertModalShow').hide();
            let backDrops = $(".modal-backdrop");
            backDrops[backDrops.length - 1].remove();
             $(`#posModal`).modal("hide");
             $(`#posModal`).hide();
             $("body").removeClass("modal-open");
          }).then(()=>{
            checkForChildForms()
            countSubFormAttachments(true)
          }).then(() => {
            startAutoSave()
          });
        }
      });
    });

    // Load the values from the parent form into the Child
    $("#child-submissionId").val($("#submissionId").val());
    $("#child-startFormTimeStamp").val($("#startFormTimeStamp").val());
    $("#child-submittedby").val($("#submittedby").val());
    $("#child-date").val($("#date").val()).trigger("change");
    $("#child-workplace").val($("#workplace").val()).trigger("change");
    $("#child-site").val($("#site").val()).trigger("change");
    $("#child-job_number").val($("#job_number").val()).trigger("change");
    $("#child-level").val($("#level").val()).trigger("change");
    $("#child-supervisor").val($("#supervisor").val()).trigger("change");

    formRules = new FormRules(); // initialize Class FormRules from sofvie-main.js
    formRules.hideRuleFieldsSubModal(); // Hide all of the Fields needed upon form load
    formRules.activateRulesSubModal(); // Add Events for Radio Buttons to Show and Hide Thier Sibling
    getPIDModalFormDraftList("child-draft");
    document.querySelector("form").classList.remove('was-validated')
    $("#posModal").modal("show");
  }
});

      // function to remove the modal generated image. // will be removed at some point
 function getPIDModalFormDraftList(selectID) {
  // Retrieve JSON list of saved form drafts, and display in specified drop down
  document.getElementById("child-draft-container").style.display = "none";
  $('#child-draft').hide()
  if (selectID) {
    // Is draft enabled?
    dbDraft
      .allDocs({
        // Get all matching drafts for this form name
        include_docs: true,
        attachments: false,
        startkey: $("#child-form")[0].formid.value,
        endkey: $("#child-form")[0].formid.value + "\ufff0"
      })
      .then(function(result) {
        $(`#${selectID}`).empty();
        $(`#${selectID}`).append(
          $("<option>")
            .text("Select Draft")
            .attr("value", "")
        )
        result.rows.forEach(data => {
          let formdata = JSON.parse(data.doc.formdata)
          if (data.doc.submissionID === $("#submissionId").val() && formdata.formid === '166071') {
            document.getElementById("child-draft-container").style.display = "block";
            $(`#${selectID}`).append(
              $("<option>")
                .text(data.doc.formid)
                .attr("value", data.id)
            )
          }
        })

        $(`#${selectID}`)
          .parent()
          .find("label")
          .addClass("filled");

        $(`#${selectID}`).on("change", event => {
          $("#child-selected-draft").val(event.target.value);
          document.getElementById('positive_id_photos').innerHTML = ''
          dbDraft
            .get(event.target.value)
            .then(function(result) {
              // Get selected item from the db
              const formData = JSON.parse(result.formdata);
              const rec_of = formData.recognition_of.split('|')
              let fileDateStamp = ''
              $.each(formData, function(name, val){	
                  const findPhoto = name.split('.')
                  if(findPhoto.length > 1){
                    if(name.substr(-8)!="_comment"){
                      fileDateStamp = findPhoto[0].substring(0,19)
                      document.getElementById(findPhoto[1]).innerHTML += 
                      `<div class="col-md-3 col-sm-4 col-6">
                      <div name="${name}GALLERY" id="${name}GALLERY" class="sf-gallery__bg-image" src="${val}" style="background-image: url(${val})">
                      <span onclick="removeModalImg(this);" class="deleteGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-trash-alt"></i></span>
                      <span onclick="addComment(this);" class="commentGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-comment"></i></span>
                      <span onclick="expandImage(this, true);" class="displayGalleryImage btn-floating btn-sm btn-secondary"><i class="fas fa-search-plus"></i></span>
                      <span class="imageDateStamp text-center font-weight-bold">${fileDateStamp}</span>
                      </div></div>`
                    }
                  // Append the form element to the form.
                  let input = document.createElement('input');														// Create an input element to form
                  input.type = 'hidden';																									// Make it hidden
                  input.name = name;
                  input.id = input.name;																									// Copy the name into the ID
                  input.value = val;
                  $("#child-form")[0].appendChild(input);			
                }	
                if(name.substr(-8)=="_comment"){
                  if(val){
                    var $el = $('[name="' + name + '"]')
                    imgs=$el.parent().find("div")
                    imgs.each(function( index ){
                      if(name.slice(0, -8)==imgs[index].id.slice(0, -7)){
                        $(imgs[index]).parent().find(".fa-comment").removeClass('far')  //remove empty comment icon
                        $(imgs[index]).parent().find(".fa-comment").addClass("fas")   //add filled comment icon
                      }
                    });
                  }					
                }
              })	
              $("#child-recognition_type")
                .val(formData.recognition_type)
                .trigger("change");
              $("#child-recognition_type")
                .parent()
                .find("label")
                .addClass("filled");
              $("#child-recognition_of")
                .val(rec_of)
                .trigger("change");
              $("#child-recognition_of")
                .parent()
                .find("label")
                .addClass("filled");
              $("#child-event_description")
                .val(formData.event_description)
                .trigger("change");
              $("#child-event_description")
                .parent()
                .find("label")
                .addClass("filled");
                
              $("#child-recognition_given_type")
                .val(formData.recognition_given_type)
                .trigger("change");
              $("#child-recognition_given_type")
                .parent()
                .find("label")
                .addClass("filled");
                // Removed the .toLowerCase() on the was_recognition_given property, SOF-10804 - PHP upgrade to 8.1.
                if (formData.was_recognition_given === "1") {
                $("#child_was_recognition_given_yes").attr("checked", true)
                $("#child_was_recognition_given_yes")
                  .parent()
                  .parent()
                  .nextAll(`.submodal-cond-form-check-area:first`)
                  .show();
              } else {
                $("#child_was_recognition_given_no").attr("checked", true)
                $("#child-recognition_given_type").val('').trigger('change').parent().find('label').removeClass('filled')
                $("#child-further_action_required").attr("checked", false);
              }
              $("#deleteModalDraft").css('display','block')

            })
            .catch(function(err) {
              console.error(err);
            });
        });
      })
      .catch(function(err) {
        console.error(err);
      });
  }
}