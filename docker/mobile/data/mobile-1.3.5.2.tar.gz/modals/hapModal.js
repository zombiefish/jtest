$("#hap-modal-open").click(() => {
      // stop the Autosave on the parent
      stopAutoSave()

  let hapModal = `<div class="modal fade" id="hapModal" tabindex="-1" role="dialog" data-backdrop="static">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
       <div class="modal-header">
          <p class="heading lead"><span class='translate' data-i18n="996" notes="Hazard Report"></p>
        </div>
        <div class="modal-body" id="hapModalSelect">

    <!--  ---------------   This is the Start of the Body of the Modal ----------------------  -->  
    <form id="child-form" class='needs-validation'>
           <input type="hidden" name="submissionId" id="child-submissionId" value="" />
           <input type="hidden" name="startFormTimeStamp" id="child-startFormTimeStamp" value="" />
           <input type="hidden" name="endFormTimeStamp" id="child-endFormTimeStamp" value="" />
           <input type="hidden" name="displayReferenceValue" id="child-displayReferenceValue" value="" />
           <input type="hidden" name="submittedby" id="child-submittedby" value="" />
           <input type="hidden" name="selected-draft" id="child-selected-draft" value="" />           

    <!--  ---------------------------------   Header Fields  ---------------------------------  -->             
           <input type="hidden" name="date" id="child-date" value="" />
           <input type="hidden" name="site" id="child-site" value="" />
           <input type="hidden" name="job_number" id="child-job_number" value="" />
           <input type="hidden" name="level" id="child-level" value="" />
           <input type="hidden" name="workplace" id="child-workplace" value="" />
           <input type="hidden" name="supervisor" id="child-supervisor" value="" />

            <h6 class="text-secondary"><span class='translate' data-i18n="510" notes="Hazard Identification"></span></h6>

            <div class="pt-1 position-relative my-4" id='child-draft-container'>
                <select name="child-draft" id="child-draft" class="select-single" ">
                </select>
                <label for="draft"><span class='translate' data-i18n="1474" notes="Form drafts"></span></label>
            </div>

            <div class="pt-1 position-relative my-4">
                <select name="hazard_type" id="child-hazard_type" class="select-single mobile-hazardtype-select" required>
                </select>
                <label for="hazard_type"><span class='translate' data-i18n="514" notes="Hazard Type"></span></label>
            </div>

            <div class="pt-1 position-relative my-4">
                <select name="hazard_identification" id="child-hazard_identification" class="select-single mobile-hazardid-select" required>
                </select>
                <label for="hazard_identification"><span class='translate' data-i18n="510" notes="Hazard Identification"></span></label>
            </div>

			      <div class="md-form">
				        <textarea name="hazard_description" id="child-hazard_description" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
				        <label for="event_description"><span class='translate' data-i18n="509" notes="Hazard Description"></span></label>
            </div>
            
            <div class="form-group photoImage" id="hazard_attachment"> 
            <canvas id="canvashap" style='display:none;'></canvas>
            <div class="btn-group d-flex" role="group">
              <div class="btn btn-block btn-outline-secondary file-field px-1">
                <i class="fa fa-upload"></i> <span class='translate' data-i18n="2340" notes="Add Images"></span>
                <input type="file" id="hazardpics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
              </div>
            </div>
            <small id="siteHelp" class="form-text text-muted"><span class='translate' data-i18n="1389" notes="Please take scene pictures from all perspectives"></span></small>
            <div class="row photoGallery" id="hazard_attachment_photos"></div>
          </div>
          
          
            <input type="hidden" name="hazard_identification_score" id="child-hazard_identification_score" value="">

            <h6 class="text-secondary pt-4"><span class='translate' data-i18n="2177" notes="Potential Loss Identification"></span></h6>

            <div class="pt-1 position-relative my-4">
                <select name="potential_risk" id="child-potential_risk" class="select-single mobile-potentialloss-select" required>
                </select>
                <label for="potential_risk"><span class='translate' data-i18n="1144" notes="Potential Loss"></span></label>
            </div>

            <input type="hidden" name="potential_risk_score" id="child-potential_risk_score" value="">
  
            <div class="form-check pl-0">
                <input type="checkbox" class="form-check-input cond-form-check complete-on" value='' name="immediate_action_required_and_performed" id="child-immediate_action_required_and_performed">
                <label class="form-check-label" for="child-immediate_action_required_and_performed"><span class='translate' data-i18n="1417" notes="Immediate Action"></span></label>
            </div>


            <div class='submodal-cond-form-check-area'> 

                <div class="md-form">
                    <textarea name="immediate_action_taken" id="child-immediate_action_taken" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
                    <label for="immediate_action_taken"><span class='translate' data-i18n="1418" notes="Immediate Action Taken"></span></label>
                </div>

                <input type="hidden" name="immediate_action_score" id="child-immediate_action_score" value="">
                <div class="pt-1 position-relative my-4">
                    <select name="immediate_action_type" id="child-immediate_action_type" class="select-single mobile-actiontypescore-select" required>
                    </select>
                    <label for="immediate_action_type"><span class='translate' data-i18n="17" notes="Action Type"></span></label>
                </div>
 </div>

             
 <div class="form-check pl-0 mb-4">
 <input type="checkbox" class="form-check-input cond-form-check complete-off" value='' name="further_action_required" id="child-further_action_required">
 <label class="form-check-label" for="child-further_action_required"><span class='translate' data-i18n="1419" notes="Further Action"></span></label>
 </div>

<div class='submodal-cond-form-check-area'>
              <div class="pt-1 position-relative my-4">
                <select name="action_by_who" id="child-action_by_who" class="select-single modal-employee-select" required>
                </select>
                <label for="action_by_who"><span class='translate' data-i18n="1420" notes="Action By Who"></span></label>
              </div>
              
              <div class="form-check custom-radio pl-0 d-none" id="child-group_action_type">
                <input type="radio" class="form-check-input" id="child-group_action" name="is_group" tag="9513" value="1" notes="Group Action">
                <label class="form-check-label mr-2" for="child-group_action"><span class='translate' data-i18n='9513' notes='Group Action'>Group Action</span></label>

                <input type="radio" class="form-check-input" id="child-individual_action" name="is_group" tag="9514" value="0" notes="Individual Action">
                <label class="form-check-label mr-2" for="child-individual_action"><span class='translate' data-i18n='9514' notes='Individual Action'>Individual Action</span></label> 
              </div>

              <div class="pt-1 position-relative my-4">
                <select name="action_type" id="child-action_type" class="select-single mobile-actiontypescore-select" required>
                </select>
                <label for="action_type"><span class='translate' data-i18n="17" notes="Action Type"></span></label>
              </div>

              <div class="md-form mb-5"> 
                <input type="text" name="action_by_when" id="child-action_by_when" class="form-control datepicker" value="" required/>
                <label for="child-action_by_when"><span class='translate' data-i18n="70" notes="By When"></span></label>
              </div>

              <div class="md-form">
                <textarea name="recommended_action" id="child-recommended_action" class="form-control md-textarea" wrap="VIRTUAL" required></textarea>
                <label for="recommended_action"><span class='translate' data-i18n="773" notes="Recommended Action"></span></label>
              </div>
</div>  

<div style='display:none;'>       
<div class="pt-1 position-relative my-4">
    <select name="action_completed_by_who" id="child-action_completed_by_who" class="select-single modal-employee-select">
    </select>
    <label for="action_completed_by_who">Action Completed By Who</label>
</div>

<div class="md-form"> 
    <input type="text" name="action_completed_date" id="child-action_completed_date" class="form-control datepicker" value=""/>
    <label for="child-action_completed_date">Completed When</label>
</div>

<div class="md-form">
    <textarea name="completed_action_taken" id="child-completed_action_taken" class="form-control md-textarea" wrap="VIRTUAL"></textarea>
    <label for="completed_action_taken">Action Taken</label>
</div>

<div class="pt-1 position-relative my-4">
    <select name="completed_action_type" id="child-completed_action_type" class="select-single mobile-actiontypescore-select">
    </select>
    <label for="completed_action_type">Completed Action Type</label>
</div>

<input type="hidden" name="completed_action_score" id="child-completed_action_score" value="">


<div class="form-group photoImage" id="completed_action_attachment"> 
  <label class="d-block">Include Photos</label>
  <canvas id="canvashap" style='display:none;'></canvas>
  <div class="btn-group d-flex" role="group">
  <div class="btn btn-block btn-outline-secondary file-field px-1">
    <i class="fa fa-upload"></i> Add Images
    <input type="file" id="childhazardpics" name="myFile" multiple accept="image/png,image/jpeg,image/bmp,image/gif,image/webp">
  </div>
</div>
  <small id="siteHelp" class="form-text text-muted">Please take scene pictures from all perspectives</small>
  <div class="row photoGallery" id="completed_action_attachment_photos"></div>
</div>


</div>   

<div class="invalid-feedback">You must select at least one action type.</div>
           <div class="btn-group d-flex mt-5 mb-2" role="group" aria-label="Form Actions">
               <button type="button" name="cancelModal" id="cancelSubForm" class="btn btn-primary col px-1 flex-fill"><span class='translate' data-i18n="1257" notes="Cancel"></span></button>
               <div name="reset" id="deleteModalDraft" class="btn btn-primary col px-1 flex-fill"><span class='translate' data-i18n="1408" notes="Delete"></span></div>
               <div name="saveModalDraft" id="saveModalDraft" class="btn btn-primary col saveDraft childDraft px-1"><span class='translate' data-i18n="1258" notes="Save"></span></div>
           </div>
            <input type="hidden" name="action_status" id="child-action_status" value="Incomplete">           
            <input type="hidden" name="formname" id="child-formname" tag= "996" class = "trans_input" value="996" note="HAZARD REPORT" />
						<input type="hidden" name="formtype" id="child-formtype" value="hazard" />
						<input type="hidden" name="formid" id="child-formid" value="131042" />
						<input type="hidden" name="version" id="child-version" value="66" />
						<input type="hidden" name="_rev" id="child-_rev" value="" />
						<input type="hidden" name="_id" id="child-_id" value="" />
						<input type="hidden" name="keyField" id="child-keyField" value="site|hazard_type" />
            <input type="hidden" name="moduleId" id="moduleId" value="" />
            <input type="hidden" name="is_group" id="immediate_action_null" value=0 />
            <input type="hidden" name="draftField" id="child-draftField" value="draft" />
            <div id='alertModalComponent'></div>
           </form>             
     <!--  ---------------   This is the END of the Body of the Modal ----------------------  -->      
      </div>
    </div>
  </div>
</div>`;


  let response = formHeader.formValidate($("form")[0]);
  if (response) {
    $("#child-modal").empty().append(hapModal);
    $('.translate').localize()
  
    if(localStorage.getItem('assignmultiuser')=='true') {      
      $("#child-group_action").prop('checked',false)  // remove the "is_group" default selection
      $("#child-action_by_who").prop('multiple',true)
      $("#child-action_by_who").removeClass("select-single")
      $("#child-action_by_who").addClass("select-multiple")
      $('#child-action_by_who').on('change', function() {
        if($('#child-action_by_who').val().length>1){
          $("#child-individual_action").prop('checked',false);
          $("#child-group_action_type").removeClass("d-none")
          $("#child-group_action").prop('required',true)
        }
        else{
          $("#child-group_action_type").addClass("d-none")
          $("#child-group_action").prop('required',false)
          $("#child-individual_action").prop('checked',true);
        }
      });
    }

    // Handle the Input values
    let inputs = document.getElementsByClassName('trans_input')
    for(input in inputs){
      try {
        inputs[input].setAttribute('value', i18next.t(inputs[input].getAttribute('value')))
      } catch (error) {}
    }

    today = new Date()
    $(".datepicker").pickadate({format: 'yyyy-mm-dd', min: new Date(moment(today).calendar())})
    .on('mousedown', function cancelEvent(evt) { // This is a fix/hack to prevent the datepicker from flashing Link:https://github.com/amsul/pickadate.js/issues/1138#issuecomment-696911230
      evt.preventDefault();
    })

    if(mobileFrame) {
      let moduleId = window.sessionStorage.getItem('moduleId') ? window.sessionStorage.getItem('moduleId'): null
      if(moduleId && moduleId != 'null'){
        document.getElementById("moduleId").value=moduleId
      }
    }

    $("#deleteModalDraft").css('display','none')
    pageOrientation() 


  // change event for file uploads
  photoChangeEvent(document.getElementById('hazardpics'), 'child', 'canvashap')
  
  $("#alertModalComponent").append(`
    <div class="modal" id="pictureWarningModal" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
       <div class="modal-dialog modal-notify modal-success" role="document">
          <div class="modal-content">
             <div class="modal-header">
                <p class="heading lead"></p>
                </button>
             </div>
             <div class="modal-body">
                <div class="text-center">
                   <i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
                   <p class='modal-body-text'></p>
                </div>
             </div>
          <div class="modal-footer justify-content-center">
       </div>
    </div>`)
    
    formHeader.populateEmployeeModalSelect();
    formHeader.populateActionTypeSelect();
    formHeader.populateHazardTypeSelect();
    formHeader.populateHazardIDSelect();
    formHeader.populateActionTypeScoreSelect();
    formHeader.populatePotentialLossSelect();
    let further = $('#child-further_action_required').prop('checked')
    let immediate = $('#child-immediate_action_required_and_performed').prop('checked')

    let select2LanguageFunction = window[`sofvie_select2_languages_${selectedLanguage}`];
		if (!(typeof select2LanguageFunction === "function"))
		{
			select2LanguageFunction = {}
			console.error("Failed to get Select2 Translations")
		}

    $("#hapModal select:not(.custom-select, [class^=picker_])").val("").removeAttr("readonly"); // Alow validation on select inputs except the ones with the class .custom-select (in DataTable)
    $("#hapModal select:not([class^=picker_])")
      .select2({ theme: "material", language: select2LanguageFunction(), allowClear: true, placeholder: "", dropdownParent: $("#hapModalSelect")})
      .on("select2:select", function() {
        reInitializeSelect2Language()
        $(this).parent().find("label").addClass("filled");
      })
      .on('select2:unselect', function () {
        if ($(".select2-selection__choice")[0]) {
          $(this).parent().find('label').addClass('filled');
        } else {
          $(this).parent().find('label').removeClass('filled');
        }
      })
      .on('select2:open', function () {
        reInitializeSelect2Language()
        $('.select2-results').css({ 'max-height': '260px' })
      });
    $("#hapModal .select2-selection__arrow b").addClass("fa fa-caret-down"); // Add caret on selects


    $("#child-further_action_required").click((event) => { 
      further = $('#child-further_action_required').prop('checked')
      if (event.target.value) {
        $('#child-recommended_action,#child-action_by_when,#child-action_type,#child-action_by_who').val('').trigger('change').parent().find('label').removeClass('filled')
      }
      checkActionCheckboxes()
    })

    $("#child-immediate_action_required_and_performed").click((event) => { 
      immediate = $('#child-immediate_action_required_and_performed').prop('checked')
      if(event.target.value) {
        $('#child-immediate_action_taken,#child-immediate_action_type').val('').trigger('change').parent().find('label').removeClass('filled')
      }
      checkActionCheckboxes()
    })

    function checkActionCheckboxes() {
      if (!immediate && !further && document.getElementById("child-form").classList.contains('was-validated')) {
        $('.invalid-feedback').css('display', 'block')
      } else {
        $('.invalid-feedback').css('display', 'none')
      }
    }

    $("#cancelSubForm").click(event => {
      const theElements = {
        modalTheme: `modal-danger`,
        modalAlert: `fa-times-circle`,
        modalTitle: i18next.t(`1410`),
        modalText: i18next.t(`1409`),
        modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-danger waves-effect"><span class='translate' data-i18n="1257" notes="Cancel"></span></a>
        <a role="button" id='cancelDraftConfirm' class="px-1 flex-fill btn btn-danger waves-effect confirm"><span class='translate' data-i18n="1379" notes="Yes"></span></a>`
      };
      
      showAlertModal($("#child-form")[0], "posModal", "danger", theElements);

      $("#cancelDraftConfirm").click(() => {
        cancelDraftClose()
      })
    });
     
    function cancelDraftClose() {
      $('#alertModalShow').hide();
      let backDrops = $(".modal-backdrop");
      backDrops[backDrops.length - 1].remove();
      closeHAPChildModal() 
    }

    function closeHAPChildModal() {
      $("#hapModal").modal("hide");
      $("#hapModal").hide();
      $("body").removeClass("modal-open");
      $("#hapModal").remove()
      let backDrops = $(".modal-backdrop");
      if( backDrops[backDrops.length - 1]) {
        backDrops[backDrops.length - 1].remove();
      }
      startAutoSave()
    }

    function closeModal(modal) {
      let backDrops = $(".modal-backdrop");
      if(backDrops[backDrops.length - 1]) {
        backDrops[backDrops.length - 1].remove();
      }
      modal.hideModal()
    }

    $("#saveModalDraft").click(event => {
      //  remove the readonly attribute before validation
      $('.datepicker').removeAttr('readonly')
      
      const childForm = $("#child-form")[0];
   //   if (debug) {
        for (let a = 0; a < childForm.length; a++) {
          if (!childForm[a].validity.valid) {
            // console.log(
            //   `${childForm[a]}  is  ${childForm[a].validity.valid}`,childForm[a]
            // );
          }
        }
    //  }

      // check Validity
      further  = $('#child-further_action_required').prop('checked')
      immediate  = $('#child-immediate_action_required_and_performed').prop('checked')   
      if(!further){
        document.getElementById("child-action_by_who").removeAttribute("required")
        document.getElementById("child-action_type").removeAttribute("required")
        document.getElementById("child-action_by_when").removeAttribute("required")
        document.getElementById("child-recommended_action").removeAttribute("required")
      }
      $('input.select2-search__field').removeAttr("required")
      let Validity = invalidContentValidation(childForm)
      if (Validity === false) {
        if(!further && !immediate) {
          $('.invalid-feedback').css('display', 'block')
          $('.form-check-label').css('color', 'initial')
        }
        event.preventDefault();
        event.stopImmediatePropagation();
        $('#child-modal').after(`<div class="modal fade" id="valModal" tabindex="-1" data-backdrop="static" role="dialog" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
        <div class="modal-dialog modal-notify modal-success" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <p class="heading lead"></p>
            </div>
              <div class="modal-body">
                <div class="text-center">
                  <i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
                  <p class='modal-body-text'></p>
                </div>
              </div>
            <div class="modal-footer justify-content-center">
            </div>
          </div>
        </div>
      </div>`)
        let formModal = new SofvieModal('valModal');   
        if(childForm.classList.contains('invalid-content'))                                       // initialize the Modal      
          formModal.handleModal(`invalidContent`) 
        else 
          formModal.handleModal(`validate`)
        $('.confirmValidation').click(()=>{
          closeModal(formModal)
        })
      } else {
        if(further || immediate) {
      // set the action_status field
          if(further) {
            $('#child-action_status').val('Incomplete')
          } else {
            $('#child-action_status').val('Complete')
          }

          childForm.classList.add("validated");
          const theElements = {
            modalTheme: `modal-warning`,
            modalAlert: `fa-exclamation-triangle`,
            modalTitle: `Submit Form`,
            modalTitle: i18next.t(`1415`),
            modalText: i18next.t(`1409`),
            modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-warning waves-effect"><span class='translate' data-i18n="1257" notes="Cancel"></span></a>
            <a role="button" id='alertModalConfirm' class="px-1 flex-fill btn btn-warning waves-effect confirm"><span class='translate' data-i18n="1379" notes="Yes"></span></a>`
          };
  
          $(`#child-hazard_identification`).val()? $(`#child-hazard_identification_score`).val($(`#child-hazard_identification`).val().split('|')[1]): '0'
          $(`#child-potential_risk`).val()? $(`#child-potential_risk_score`).val($(`#child-potential_risk`).val().split('|')[1]): '0'
          $(`#child-immediate_action_type`).val()? $(`#child-immediate_action_score`).val($(`#child-immediate_action_type`).val().split('|')[1]): '0'
          $(`#child-completed_action_type`).val()? $(`#child-completed_action_score`).val($(`#child-completed_action_type`).val().split('|')[1]): '0'
          showAlertModal($("#child-form")[0], "hapModal", "warning", theElements);
          $('.datepicker').attr('readonly', true)
        }
        else {
          $('.invalid-feedback').css('display', 'block')
          $('.form-check-label').css('color', 'initial')
          event.preventDefault();
          event.stopImmediatePropagation();
          $('.datepicker').attr('readonly', true)
        }
      }
      childForm.classList.add("was-validated");
   
    })

    $("#deleteModalDraft").click(event => {
      const theElements = {
        modalTheme: `modal-danger`,
        modalAlert: `fa-times-circle`,
        modalTitle: i18next.t(`1408`),
        modalText: i18next.t(`1409`),
        modalButtons: `<a role="button" id='alertModalCancel' class="px-1 flex-fill btn btn-outline-danger waves-effect"><span class='translate' data-i18n="1257" notes="Cancel"></span></a>
        <a role="button" id='deleteDraftConfirm' class="px-1 flex-fill btn btn-danger waves-effect confirm"><span class='translate' data-i18n="1379" notes="Yes"></span></a>`
      };
      showAlertModal($("#child-form")[0], "hapModal", "warning", theElements);

      $("#deleteDraftConfirm").click(() => {
        if ($("#child-selected-draft").val() !== "") {
          dbDraft.get($("#child-selected-draft").val()).then(function(doc) {
            dbDraft.remove(doc);
            $("#alertModalShow").hide();
            let backDrops = $(".modal-backdrop");
            backDrops[backDrops.length - 1].remove();
            $(`#hapModal`).modal("hide");
            $(`#hapModal`).hide();
            $("body").removeClass("modal-open");
          }).then(()=>{
            checkForChildForms()
            countSubFormAttachments(true)
          }).then(()=>{
            startAutoSave()
          });
        }
      });
    })

    $("#child-submissionId").val($("#submissionId").val());
    $("#child-startFormTimeStamp").val(new Date());
    $("#child-submittedby").val($("#submittedby").val());
    $("#child-date").val($("#date").val()).trigger("change");
    $("#child-workplace").val($("#workplace").val()).trigger("change");
    $("#child-site").val($("#site").val()).trigger("change");
    $("#child-job_number").val($("#job_number").val()).trigger("change");
    $("#child-level").val($("#level").val()).trigger("change");
    $("#child-supervisor").val($("#supervisor").val()).trigger("change");

    formRules = new FormRules(); // initialize Class FormRules from sofvie-main.js
    formRules.hideRuleFieldsSubModal(); // Hide all of the Fields needed upon form load
    formRules.activateRulesSubModal(); // Add Events for Radio Buttons to Show and Hide Thier Sibling

    getHAPModalFormDraftList("child-draft");
    $("#hapModal").modal("show");
    $("#hapModal").show();
  }
});


function getHAPModalFormDraftList(selectID) {
  // Retrieve JSON list of saved form drafts, and display in specified drop down
  document.getElementById("child-draft-container").style.display = "none";
  $("#child-draft").hide();
  if (selectID) {
    // Is draft enabled?
    dbDraft
      .allDocs({
        // Get all matching drafts for this form name
        include_docs: true,
        attachments: false,
        startkey: $("#child-form")[0].formid.value,
        endkey: $("#child-form")[0].formid.value + "\ufff0"
      })
      .then(function(result) {
        $(`#${selectID}`).empty();
        $(`#${selectID}`).append(
          $("<option>")
            .text("Select Draft")
            .attr("value", "")
        );
        result.rows.forEach(data => {
          let formdata = JSON.parse(data.doc.formdata)
          if (data.doc.submissionID === $("#submissionId").val() && formdata.formid === '131042') {
            document.getElementById("child-draft-container").style.display = "block";
            $(`#${selectID}`).append(
              $("<option>")
                .text(data.doc.formid)
                .attr("value", data.id)
            );
          }
        });

        $(`#${selectID}`)
          .parent()
          .find("label")
          .addClass("filled");

        $(`#${selectID}`).on("change", event => {
          document.getElementById('hazard_attachment_photos').innerHTML = ''
          document.getElementById('completed_action_attachment_photos').innerHTML = ''
          $("#child-selected-draft").val(event.target.value);
          dbDraft
            .get(event.target.value)
            .then(function(result) {
              // Get selected item from the db
              const formData = JSON.parse(result.formdata);
              $.each(formData, function(name, val){		 
                  const findPhoto = name.split('.')
                  if(findPhoto.length > 1){
                    if(name.substr(-8)!="_comment"){
                      fileDateStamp = findPhoto[0].substring(0,19)
                      document.getElementById(findPhoto[1]).innerHTML += 
                        `<div class="col-md-3 col-sm-4 col-6">
                        <div name="${name}GALLERY" id="${name}GALLERY" class="sf-gallery__bg-image" src="${val}" style="background-image: url(${val})">
                        <span onclick="removeModalImg(this);" class="deleteGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-trash-alt"></i></span>
                        <span onclick="addComment(this);" class="commentGalleryImage btn-floating btn-sm btn-secondary"><i class="far fa-comment"></i></span>
                        <span onclick="expandImage(this,true);" class="displayGalleryImage btn-floating btn-sm btn-secondary"><i class="fas fa-search-plus"></i></span>
                        <span class="imageDateStamp text-center font-weight-bold">${fileDateStamp}</span>
                        </div></div>`
                    }
                    let input = document.createElement('input');														// Create an input element to form
                    input.type = 'hidden';																									// Make it hidden
                    input.name = name;
                    input.id = input.name;																									// Copy the name into the ID
                    input.value = val;
                    $("#child-form")[0].appendChild(input);																// Append the form element to the form.
                  }
                  if(name.substr(-8)=="_comment"){
                    if(val){
                      var $el = $('[name="' + name + '"]')
                      imgs=$el.parent().find("div")
                      imgs.each(function( index ){
                        if(name.slice(0, -8)==imgs[index].id.slice(0, -7)){
                          $(imgs[index]).parent().find(".fa-comment").removeClass('far')  //remove empty comment icon
                          $(imgs[index]).parent().find(".fa-comment").addClass("fas")   //add filled comment icon
                        }
                      });
                    }					
                  }
              })	
              $("#child-hazard_type").val(formData.hazard_type.split("|")).trigger("change");
              $("#child-hazard_type").parent().find("label").addClass("filled");
              $("#child-hazard_identification").val(fixSelects(formData.hazard_identification)).trigger("change");
              $("#child-hazard_identification_score").val(formData.hazard_identification_score);
              $("#child-hazard_identification").parent().find("label").addClass("filled");
              $("#child-hazard_description").val(formData.hazard_description).trigger("change");
              $("#child-hazard_description").parent().find("label").addClass("filled");

              $("#child-potential_risk").val(fixSelects(formData.potential_risk)).trigger("change");
              $("#child-potential_risk_score").val(formData.potential_risk_score)
              $("#child-potential_risk").parent().find("label").addClass("filled");

              $("#child-further_action_required").attr("checked", false).parent().nextAll(`.submodal-cond-form-check-area:first`).hide();
              $("#child-immediate_action_required_and_performed").attr("checked", false).parent().nextAll(`.submodal-cond-form-check-area:first`).hide();              
              $("#child-immediate_action_required_and_performed").val('')
              $("#child-immediate_action_required_and_performed").val(formData.immediate_action_required_and_performed)
             
              if (formData.immediate_action_required_and_performed === "1") {
                $("#child-immediate_action_required_and_performed")
                  .attr("checked", true)
                  .parent()
                  .nextAll(`.submodal-cond-form-check-area:first`)
                  .show();
              } else {
                $("#child-immediate_action_required_and_performed").attr(
                  "checked",
                  false
                );
              }

              $("#child-immediate_action_taken").val('')
              $("#child-immediate_action_taken").val(formData.immediate_action_taken).trigger("change");
              $("#child-immediate_action_taken").parent().find("label").addClass("filled")
              $("#child-immediate_action_type").val('')
              $("#child-immediate_action_score").val('')
              $("#child-immediate_action_type").val(fixSelects(formData.immediate_action_type)).trigger("change");
              $("#child-immediate_action_score").val(fixSelects(formData.immediate_action_score))           
              $("#child-immediate_action_type").parent().find("label").addClass("filled");
              $("#child-further_action_required").val(formData.further_action_required)      

              if (formData.further_action_required === "1") {
                $("#child-further_action_required")
                  .attr("checked", true)
                  .parent()
                  .nextAll(`.submodal-cond-form-check-area:first`)
                  .show();
              } else {
                $("#child-further_action_required").attr("checked", false);
              }
              $("#child-recommended_action").val(formData.recommended_action).trigger("change")
              $("#child-recommended_action").parent().find("label").addClass("filled")
              $("#child-action_type").val(fixSelects(formData.action_type)).trigger("change")
              $("#child-action_type").parent().find("label").addClass("filled");
              action_by_who=formData.action_by_who.split("|")
              $("#child-action_by_who").val(action_by_who).trigger("change");
              $("#child-action_by_who")
                .parent()
                .find("label")
                .addClass("filled");
              if(action_by_who.length>1){
                if(formData.is_group=="1"){
                  document.getElementById("child-group_action").click()
                }
                else if(formData.is_group=="0"){
                  document.getElementById("child-individual_action").click()
                }
              }
              $("#child-action_by_when")
                .val(formData.action_by_when)
                .trigger("change");
              $("#child-action_by_when")
                .parent()
                .find("label")
                .addClass("filled");
              $("#child-action_completed_by_who")
                .val(formData.action_completed_by_who)
                .trigger("change");
              $("#child-action_completed_by_who")
                .parent()
                .find("label")
                .addClass("filled");
              $("#child-action_completed_date")
                .val(formData.action_completed_date)
                .trigger("change");
              $("#child-action_completed_date")
                .parent()
                .find("label")
                .addClass("filled");
              $("#child-completed_action_taken")
                .val(formData.completed_action_taken)
                .trigger("change");
              $("#child-completed_action_taken")
                .parent()
                .find("label")
                .addClass("filled");
              $("#child-completed_action_type").val(fixSelects(formData.completed_action_type)).trigger("change");
              $("#child-completed_action_score").val(fixSelects(formData.completed_action_score))        
              $("#child-completed_action_type").parent().find("label").addClass("filled");
              $("#deleteModalDraft").css('display','block')
            })
            .catch(function(err) {
              console.error(err);
            });
        });
      })
      .catch(function(err) {
        console.error(err);
      });
  }
}

function fixSelects(values) {
  let arr = [];
  let score = "";
  let pick = "";
  values.split("|").forEach((data, index) => {
    !isOdd(index) ? (pick = data) : (score = data);
    if (pick != "" && score != "") {
      arr.push(`${pick}|${score}`);
      pick = "";
      score = "";
    }
  });
  return arr;
}

function isOdd(num) {
  return num % 2;
}

