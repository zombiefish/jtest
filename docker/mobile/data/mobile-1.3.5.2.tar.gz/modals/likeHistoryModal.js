function showLikeHistoryModal(secondModal=false) {

   let likeHistoryModal = `
   <div class="modal fade" id="likeHistoryModalShow" tabindex="-1" role="dialog" data-backdrop="static">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <p class="heading lead translate" data-i18n="1128" note="Likes"></p>
            </div>
            <div class="modal-body">

               <div class="like-history-list">
                  <ul id="likeHistoryContent"></ul>
               </div>

               <div class="btn-group d-flex mt-4 mb-2" role="group" aria-label="Form Actions">
                  <button type="button" name="likeHistoryModalClose" id="likeHistoryModalClose" class="btn btn-primary col px-1 flex-fill"><span class='translate' data-i18n="1314" notes="Close"></span></button>
               </div>
            </div>
         </div>
      </div>
   </div>`

   $("#likeHistoryComponent").append(likeHistoryModal)
   $('.translate').localize()
   $("#likeHistoryModalShow").modal("show")

   if(secondModal) {
      $(`#likeHistoryModalShow`).css("z-index", "1060")
      $(`.modal-backdrop`).eq(1).css("z-index", "1050") // Second backdrop
   }

   // Hack/fix to prevent second modal from removing the scrollbar for the first modal
   $(document).on('hidden.bs.modal', function () {
      if($('.modal.show').length){
         $('body').addClass('modal-open');
      }
   })

   $("#likeHistoryModalClose").unbind()
   $("#likeHistoryModalClose").click(() => {
      $("#likeHistoryModalShow").modal("hide")
   })
}

