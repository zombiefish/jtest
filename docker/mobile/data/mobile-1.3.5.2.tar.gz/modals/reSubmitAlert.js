function showReSubmitAlertModal(modaltype = "warning", theElements) {

   let alertModal = `
   <div class="modal" id="alertReSubmitModalShow" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
      <div class="modal-dialog modal-notify modal-success" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <p class="heading lead">[Add modal title here]</p>
               </button>
            </div>
            <div class="modal-body">
               <div class="text-center">
                  <i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
                  <p class='modal-body-text'>[The form has been submitted successfully.]</p>
               </div>
            </div>
         <div class="modal-footer justify-content-center">
      </div>
   </div>`;

  $("#alertReSubmitComponent").append(alertModal);


  let modal = new SofvieModal("alertReSubmitModalShow")
  modal.modalSettings[modaltype] = theElements
  modal.handleModal(modaltype)
  $('.translate').localize()

  $("#alertReSubmitModalCancel").click(() => {
    $("#alertReSubmitModalShow").remove()
    $(".modal-backdrop").remove()
  })

  $("#alertReSubmitModalConfirm").click(() => {
    $("#alertReSubmitModalShow").remove()
    $(".modal-backdrop").remove()
  })
}

