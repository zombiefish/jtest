function showCommentModal(RefID, commmentID=null, value="", secondModal=false) {

    let commentModal = `
    <div class="modal fade" id="commentModalShow" tabindex="-1" role="dialog" data-backdrop="static">
       <div class="modal-dialog" role="document">
          <div class="modal-content">
             <div class="modal-header">
                <p class="heading lead translate" data-i18n="8921" note="Add comment"></p>
             </div>
             <div class="modal-body">

                <form id="commentForm" class="needs-validation">
                    <div class="md-form mt-1">
                        <textarea name="comment" id="comment" class="form-control md-textarea" rows="6" required></textarea>
                        <label for="comment"><span class='translate' data-i18n="3915" notes="Comment"></span></label>
                    </div>
    
                    <div class="btn-group d-flex mt-4 mb-2" role="group" aria-label="Form Actions">
                        <button type="button" name="commentModalDelete" id="commentModalDelete" class="btn btn-primary col px-1 flex-fill"><span class='translate' data-i18n="3088" notes="Delete"></span></button>
                        <button type="button" name="commentModalCancel" id="commentModalCancel" class="btn btn-primary col px-1 flex-fill"><span class='translate' data-i18n="1257" notes="Cancel"></span></button>
                        <button type="button" name="commentModalSave" id="commentModalSave" class="btn btn-primary col px-1 flex-fill"><span class='translate' data-i18n="1258" notes="Save"></span></button>
                    </div>
                </form>
             </div>
          </div>
       </div>
    </div>`
 
    $("#commentComponent").append(commentModal)
    $('.translate').localize()
    
    let form = document.getElementById("commentForm")
    form.classList.remove('was-validated')
    $('#comment').val(value).trigger('change').parent().find('label').addClass('filled')

    if(value.trim() == "")
        $('#commentModalDelete').hide();
    else
        $('#commentModalDelete').show();

    $("#commentModalShow").modal("show")

    if(secondModal) {
        $(`#commentModalShow`).css("z-index", "1060")
        $(`.modal-backdrop`).eq(1).css("z-index", "1050") // Second backdrop
    }

    // Hack/fix to prevent second modal from removing the scrollbar for the first modal
    $(document).on('hidden.bs.modal', function () {
        if($('.modal.show').length){
            $('body').addClass('modal-open');
        }
    })
    
    $("#commentModalCancel").unbind()
    $("#commentModalCancel").click(() => {
        $("#commentModalShow").modal("hide")
    })

    $("#commentModalSave").unbind()
    $("#commentModalSave").click(() => {
        
        form.classList.add('was-validated')

        if(!invalidContentValidation(form)) {

            let formModal = new SofvieModal() 
            if(form.classList.contains('invalid-content'))
                formModal.handleModal(`invalidContent`, true)
            else 
                formModal.handleModal(`validate`, true)
        
            $('.confirmValidation').click(()=>{
                closeModal(formModal)
            })
            
        } else {
            $("#commentModalShow").modal("hide")

            if(commmentID == null)
                commentRecognition(RefID, $('#comment').val())
            else
                commentRecognitionUpdate(commmentID, $('#comment').val(), RefID)
        }
    })

    $("#commentModalDelete").unbind()
    $("#commentModalDelete").click(() => {
        $("#commentModalShow").modal("hide")
        commentRecognitionDelete(commmentID, RefID)
    })
 }
 
 