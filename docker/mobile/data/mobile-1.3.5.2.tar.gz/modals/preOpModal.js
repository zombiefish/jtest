$('#emr').change((event,data) =>{
    let measures = data.measures
    let values = data.values

    message ='There are some end readings that are lower than the starting value.' // 8723     //"The engine operating hours must be between 0 and 12. Please adjust the start or end time value entered to meet the condition."

    diffMessage = i18next.t('8726')   //"Operating hours entered"


    let diff = values[0].end - values[0].start
    if(diff<0){

        let engineUnitModal = `
        <div class="modal fade engineUnitModal" id="engineUnitModal" tabindex="-1" role="dialog" data-backdrop="static">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <p class="heading lead"><span class='translate' data-i18n="8722" notes="Engine Readings Error"></span></p>
                    </div>
                    <div class="modal-body" id="posModalSelect">
                    <form><div class="md-form mt-0">
                    <p class="instructions-section-color-general"><span class='translate' data-i18n="${message}" notes="">${message}</span></p>
                </div>`
                   
                    engineUnitModal += `

                    <div class="md-form">
                        <input type="number" name="engineStartOfShift1" id="engineStartOfShift1" class="form-control" value="${values[0].start}" onchange="changeStart(1)" required min="0" step="0.1" />
                        <label class="active" for="engineStartOfShift1"><strong>${measures.ltr_text}:</strong> <span class='translate' data-i18n="8724" notes="Start of shift"></label>
                    </div>
                    <div class="md-form">
                        <input type="number" name="engineEndOfShift1" id="engineEndOfShift1" class="form-control" value="${values[0].end}" onchange="changeEnd(1)" required min="0" step="0.1"/>
                        <label  class="active" for="engineEndOfShift1"><strong>${measures.ltr_text}: </strong><span class='translate' data-i18n="8725" notes="End of shift"></span></label>
                    </div>
                    <div id="totalhrs">
                        <label id="engine_units"><strong><span>${diffMessage}</span>: <span class="text-danger">${diff.toFixed(1)}</span></strong></label>
                    </div>
                    <br />
                    `


        


        engineUnitModal += `
                <div class="btn-group d-flex mt-4 mb-2" role="group" aria-label="Form Actions">
                <button type="button" name="cancelModal" id="cancelSubForm" class="btn btn-primary col px-1 flex-fill"><span class='translate' data-i18n="1257" notes="Cancel"></span></button>
                <div name="saveEngineUnits" id="saveEngineUnits" class="btn btn-primary col saveDraft childDraft px-1 flex-fill"><span class='translate' data-i18n="3708" notes="Update"></span></div>
            </div>

                            <div id='alertModalComponent'></div>
                        </form>             
                    </div>
                </div>
            </div>
        </div>
        <script>

        function changeStart(index){
            updateOperatingUnits(index)
        }
        function changeEnd(index){
            updateOperatingUnits(index)
        }
        function updateOperatingUnits(index){

            let startVal, endVal, diff
            startVal = document.getElementById("engineStartOfShift1").value
            endVal = document.getElementById("engineEndOfShift1").value
            diff = endVal - startVal
            let redStart=''
            let redEnd = ''
            if(diff < 0){
                redStart = '<span class="text-danger">'
                redEnd = '</span>'
            }
            document.getElementById("engine_units").innerHTML = "<strong><span>${diffMessage}</span>: " +  redStart + diff.toFixed(1) + redEnd + "</strong>"

        }

        </script>
        `

      
        if(!ValidateEndOfShiftUnits(event)){
            $("#engineUnitModalPH")
            .empty()
            .append(engineUnitModal);
            $("#engineUnitModal").modal("show");
            $('.translate').localize()
        //     // getEngineUnits()
        }

    }

    $("#saveEngineUnits").click(event => {
        //Apply adjusted values to the preop form.


        let startEle = document.getElementById('engineStartOfShift1')
        let endEle = document.getElementById('engineEndOfShift1')
        let measure = measures 

        if (startEle!=null && endEle != null){
            let startVal =startEle.value
            let endVal = endEle.value
            document.getElementById("measure-start-" + measure.pem_rld_measure_id).value = startVal
            document.getElementById("measure-end-" + measure.pem_rld_measure_id).value = endVal
        }

        closeGENChildModal()
    })

    $("#cancelSubForm").click(event => {
        closeGENChildModal()
    })

    function closeGENChildModal() {
        $("#engineUnitModal").modal("hide") 
        $("#engineUnitModal").hide() 
        $("body").removeClass("modal-open") 
        $("#engineUnitModal").remove()
        let backDrops = $(".modal-backdrop") 
        if( backDrops[backDrops.length - 1]) {
            backDrops[backDrops.length - 1].remove() 
        }
    }

    function ValidateEndOfShiftUnits(event){
        //Ensure that all of the items in the measures are populated and are valid.
        //Valid = start measure <= end measure.

        //determine if the end measure is greater than the start set a flag.

        let endValue = document.getElementById('measure-end-'  + measures.pem_rld_measure_id   ) 
        let startValue = document.getElementById('measure-start-'  + measures.pem_rld_measure_id) 

        if(endValue!=null && startValue!=null){
            if(endValue.value !=''){
                if(parseInt(endValue.value) >= parseInt(startValue.value)){
                    return true
                } else {
                    return false
                }
            } else {
                return false
            }
        } else {
            return false
        }

    }
})