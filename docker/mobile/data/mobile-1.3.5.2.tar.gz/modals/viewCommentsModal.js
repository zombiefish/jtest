function showViewCommentsModal(modalTitle) {
   
   let viewCommentsModal = `
   <div class="modal fade" id="viewCommentsModalShow" tabindex="-1" role="dialog" data-backdrop="static">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">`
   if(modalTitle){
      viewCommentsModal +=`<p class="heading lead translate" data-i18n="${modalTitle}" note="Positive Recognition Comments"></p>`
   }
   viewCommentsModal +=`            
            </div>
            <div class="modal-body">

               <table class="w-100 data-table widget-table table">
                  <tbody id="viewCommentsContent"></tbody>
               </table>

               <div class="btn-group d-flex mt-4 mb-2" role="group" aria-label="Form Actions">
                  <button type="button" name="viewCommentsModalClose" id="viewCommentsModalClose" class="btn btn-primary col px-1 flex-fill"><span class='translate' data-i18n="1314" notes="Close"></span></button>
               </div>
            </div>
         </div>
      </div>
   </div>`

   $("#viewCommentComponent").append(viewCommentsModal)
   $('.translate').localize()
   $("#viewCommentsModalShow").modal("show")

   $("#viewCommentsModalClose").unbind()
   $("#viewCommentsModalClose").click(() => {
      $("#viewCommentsModalShow").modal("hide")
   })
}

function updateViewCommentsContentTable(comment){
   let viewCommentsContent = document.getElementById("viewCommentsContent")
   viewCommentsContent.innerHTML += 
      (`<tr>
        <td class="action-wrapper my-3">
          <div class="d-flex justify-content-between">
            <h6 class="font-weight-bold">${comment.created_by}</h6>

            <span class="text-primary">
                <div class="btn-group show">
                    <div data-toggle="dropdown" class="pointer">
                        <i id="commentLikeIcon-${comment.com_id}" class="fa fa-thumbs-up"></i> <span id="commentLikeCount-${comment.com_id}"></span>
                    </div>
                    <div class="dropdown-menu dropdown-menu-right">
                        <button id="commentLikeButton-${comment.com_id}" class="dropdown-item pointer" type="button" notes="Like Comment"></button>
                        <button id="commentViewLikeButton-${comment.com_id}" class="dropdown-item pointer translate" type="button" data-i18n="8674" notes="View Likes"></button>
                    </div>
                </div>

                <i id="commentEditIcon-${comment.com_id}" class="fa fa-pen ml-3 pointer"></i>

                <i id="commentDeleteIcon-${comment.com_id}" class="fa fa-trash ml-3 pointer"></i>

              </span>
          </div>
          <p class="description">${comment.com_comment}</p>
          <span class="d-flex justify-content-between">
            <small><span class='translate' data-i18n="124" notes="Date"></span>: ${comment.com_created_date.substring(0,10)}</small>
          </span>
        </td>
      </tr>`)
   
   $('.translate').localize()   
}
