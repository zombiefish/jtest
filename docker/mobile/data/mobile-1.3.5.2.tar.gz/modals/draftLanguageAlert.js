function showDraftLanguageAlertModal(modaltype = "warning", theElements) {
  let alertModal = `
    <div class="modal" id="alertDraftLanguageModalShow" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
       <div class="modal-dialog modal-notify modal-success" role="document">
          <div class="modal-content">
             <div class="modal-header">
                <p class="heading lead">[Add modal title here]</p>
                </button>
             </div>
             <div class="modal-body">
                <div class="text-center">
                   <i class="fas fa-check fa-4x mb-3 animated rotateIn"></i>
                   <p class='modal-body-text'>[The form has been submitted successfully.]</p>
                </div>
             </div>
          <div class="modal-footer justify-content-center">
       </div>
    </div>`

  $("#alertDraftLanguageModalComponent").append(alertModal)


  let modal = new SofvieModal("alertDraftLanguageModalShow")
  modal.modalSettings[modaltype] = theElements
  modal.handleModal(modaltype)
  $('.translate').localize()

  $("#alertDraftLanguageModalCancel").click(() => {
    $("#alertDraftLanguageModalShow").remove()
    $(".modal-backdrop").remove()
  })

  $("#alertDraftLanguageModalConfirm").click(() => {
    $("#alertDraftLanguageModalShow").remove()
    $(".modal-backdrop").remove()
    applySettings()
  })
}

