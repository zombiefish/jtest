CREATE DATABASE keycloak;

DROP USER IF EXISTS 'sofvie_keycloak'@'%';
CREATE USER 'sofvie_keycloak'@'%' IDENTIFIED BY 'nM672sOXLXIe';
GRANT ALL PRIVILEGES ON keycloak.* TO 'sofvie_keycloak'@'%';

