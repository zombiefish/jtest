from sqlalchemy import create_engine, text
from decimal import Decimal
from flask import request
import pymysql, yaml, datetime, requests, json, urllib, random, os
# Functions originally in helper.py but are now in their own file
from get_filter_data import execute_sp, get_filter_data

### Helper Functions ###

def report_config(reportSlug):
    with open(f'config/{reportSlug}.yaml', 'r') as f:
        config = yaml.safe_load(f)        
        return config

def log_this(msg=None):
    with open('log.txt', 'a') as log_file:
        log_file.write(msg + '\n')

def get_url_param(args):
    return dict(args)

def api_config(args=None):    
    with open('credentials.yaml', 'r') as f:
        cred = yaml.safe_load(f)
        if 'testcore-' in request.base_url:
            cred = cred['test']
        elif 'devcore-' in request.base_url:
            cred = cred['dev']
        elif 'devcore2-' in request.base_url:
            cred = cred['dev2']
        elif 'testcore2-' in request.base_url:
            cred = cred['test2']
        else:
            if args and 'env' in args:
                cred = cred[args['env']]
            else:
                cred = cred[cred['active']]
        return cred
    
def get_logo():
    return execute_sp('rpt_get_logo')[0]['clo_image']

def get_client_url():
    return api_config()['client_url']

def get_domain():
    with open('credentials.yaml', 'r') as f:
        cred = yaml.safe_load(f)
        cred = cred['test_env']
    return cred

def execute_sql(query):
    cred = api_config()
    engine = create_engine(f"mysql+pymysql://{cred['db_user']}:{cred['db_password']}@{cred['db_server']}/{cred['db_name']}")
    con = engine.connect()
    result = con.execute(text(query))
    sqlResult = result.fetchall()
    if isinstance(sqlResult, tuple):
        sqlResult = list(sqlResult)

    for result in sqlResult:
        if isinstance(result, dict):
            for res in result.keys():                 
                if isinstance(result[res], datetime.datetime):
                    if 'date' in res or 'Date' in res:
                        result[res] = result[res].strftime('%Y-%m-%d')                        
                    else:
                        result[res] = result[res].strftime('%Y-%m-%d %H:%M:%S')
                if isinstance(result[res], (bytes, bytearray)):
                    result[res] = result[res].decode('utf-8')
                if isinstance(result[res], Decimal):
                    result[res] = float(result[res])
                if isinstance(result[res], datetime.date): 
                    result[res] = result[res].strftime('%Y-%m-%d')   
    con.close()
    return {'result': [dict(row) for row in sqlResult]}

def get_report_filter_values(args):
    report_filter_unique_code = None
    if "report_filter_unique_code" in args.keys():
        report_filter_unique_code = args['report_filter_unique_code']
        args = json.loads(execute_sp("rpt_get_filter_values_for_url", [report_filter_unique_code])[0]['rfu_report_filter'])
    return args, report_filter_unique_code


def get_report(url, isJSON=False, reportSlug=None, formSubmissionId=None, params=None):

    # Extract URL components
    if isJSON is False:
        reportSlug = url.split('/')[0]
        if '?' in reportSlug:
            reportSlug = reportSlug.split('?')[0]
        params = json.loads(url.split('?')[1].replace("'",'"'))
        try:
            formSubmissionId = url.split('/')[1].split('?')[0]
        except:
            formSubmissionId = 123

    # Import the report Class
    mod = __import__('api', fromlist=[reportSlug])
    ReportClass = getattr(mod, reportSlug)

    # Create a report object
    report = ReportClass.Report(params)

    # Fetch report data
    result = report.get_report(formSubmissionId)

    return result

def log_error(error_code=None):
    error_msg = {
        404: 'The requested report was not found.',
        403: 'You do not have permission to access the requested report.',
        410: 'The requested report is no longer available.',  
        500: 'An error occurred while processing your report.',
        502: 'An error occurred while processing your report.',
        504: 'The requested report timed out.',
        999: 'Unknown error occurred.'
    }
    
    error_code = error_code if error_code else 999
    error_data = {
        'id': random.randint(1000000, 9999999),
        'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'http_error_code': error_code,
        'request': {
            'url_full': request.url,
            'url_base': request.base_url,
            'url_root': request.url_root,
            'args': dict(request.args),
            'method': request.method,
            'charset': request.charset,
            'host': request.host
        },        
        'report_slug': request.path.replace('/',''),        
        'msg': error_msg[error_code] if error_code in error_msg else error_msg[999]
    }
    
    # Write error message to error log file
    with open(f'logs/errors/{error_data["id"]}.json', 'w') as f:
        f.write(json.dumps(error_data))
    
    return error_data


def file_extention_attachments(data):
    list_image = ['jpg', 'jpeg', 'png', 'bmp', 'gif', 'webp', 'x-ms-bmp', 'jfif', 'apng']
    
    for item in data:
        if item['url'] is not None: 
            file_ext = item['url'].split('.')[-1].lower()
            if file_ext not in list_image:
                item['file_flag'] = 1
                item['file_ext'] = file_ext
            else:
                item['file_flag'] = 0
                item['file_ext'] = '' 
    return data



def get_hazard_actions(data, imageUrl, args, lang):

    result = {}
    result['rpt_hap_pictures_initial'] = []
    result['rpt_hap_pictures_followup'] = []
    result['rpt_hap_complete'] = []
    
    for hap in data:
        hap['rpt_hap_pictures_initial'] = execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'INITIAL', lang], args)
        hap['rpt_hap_pictures_followup'] = execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'FOLLOWUP', lang], args)
        hap['HAP_complete'] = execute_sp('rpt_hazard_actions_list_completed', [hap['ID'],lang], args)

    return result


#General action section update to get images, comments, likes and data
def get_general_actions(data, imageUrl, args, lang):

    result = {}
    result['rpt_get_general_action_attachment_by_sga_id_initial'] = []
    result['rpt_get_general_action_attachment_by_sga_id_followup'] = []
    result['GA_complete'] = []

    for gga in data:
        gga['rpt_get_general_action_attachment_by_sga_id_initial'] = execute_sp('rpt_get_general_action_attachment_by_sga_id', [gga['sga_id'],imageUrl+'general_action/','INITIAL', lang], args)
        gga['rpt_get_general_action_attachment_by_sga_id_followup'] = execute_sp('rpt_get_general_action_attachment_by_sga_id', [gga['sga_id'],imageUrl+'general_action/','FOLLOWUP', lang], args)
        gga['GA_complete'] = execute_sp('rpt_get_general_actions_list_completed', [gga['sga_id'], lang], args)
        
    return result

        
# Positive recognition section update to get images, comments, likes and data
def get_positive_recognitions(data, imageUrl, args, lang):

    if len(data) > 0:
        for pid in data:
            pid['rpt_positive_recognition_likes'] = execute_sp('rpt_positive_recognition_likes', [pid["ID"], lang], args)
            pid['rpt_pid_pictures'] = execute_sp('rpt_pid_pictures', [pid["ID"], imageUrl, lang], args)
            pid['rpt_positive_recognition_comment'] = execute_sp('rpt_positive_recognition_comment', [pid["ID"], lang], args)

    return

### End of Functions ###