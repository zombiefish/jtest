SELECT  drr_reviewed_date, cast(drr_reviewed_date - cast( UTC_timestamp() - NOW() as time) as DATETIME) as ReviewDate,  
	CONCAT(person.per_last_name, ", ",person.per_first_name) AS `person_full_name` ,
	drr_position
	FROM document_review_management_reviewer   LEFT JOIN person ON drr_per_id = person.per_id   
	WHERE drr_drm_id = = formSubmissionId  
	and drr_is_reviewed = 1
	order by drr_reviewed_date;