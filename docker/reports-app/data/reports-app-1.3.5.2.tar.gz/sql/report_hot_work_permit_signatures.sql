SELECT
      SubmissionHeader.ID,
      IFNULL(FormFieldDescription.fieldName, '') AS fieldName,
      group_concat(IFNULL(SubmissionDetails_Explode.Value, '') SEPARATOR '; ') AS Value,
      IFNULL(SubmissionDetails_Explode.sde_image_timestamp, '') AS picStamp,
      IFNULL(FormFieldDescription.fieldType, '') AS fieldType,
      IFNULL(FormFieldDescription.SectionName, '') AS SectionName,
      IFNULL(FormFieldDescription.fieldKey, '') AS fieldKey,
      IFNULL(SubmissionDetails_Explode.Explode_Section_ID, '') AS Explode_Section_ID
   FROM SubmissionHeader
      INNER JOIN SubmissionDetails
         ON SubmissionHeader.ID = SubmissionDetails.SubmissionHeaderID
      INNER JOIN SubmissionDetails_Explode
         ON SubmissionDetails_Explode.SubmissionDetailID = SubmissionDetails.ID
      INNER JOIN FormFieldDescription
         ON SubmissionDetails_Explode.FormFieldDescriptionID = FormFieldDescription.ID
      INNER JOIN FormDescription
         ON SubmissionHeader.FormDescriptionID = FormDescription.ID
      LEFT JOIN v_employee e1
         ON e1.per_id = IFNULL(SubmissionDetails_Explode.Value, '')
      LEFT JOIN v_employee e2
         ON e2.per_full_name = IFNULL(SubmissionDetails_Explode.Value, '')
   WHERE (SubmissionHeader.ID = formSubmissionId)
   AND (FormFieldDescription.SectionName IN ('Pre-Work Signatures'))
   AND FormFieldDescription.fieldKey = 'workers_present'
   GROUP BY fieldName
   ORDER BY SubmissionDetails_Explode.Explode_Section_ID;
