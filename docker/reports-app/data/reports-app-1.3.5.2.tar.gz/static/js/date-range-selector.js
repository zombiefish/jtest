if(document.getElementById('date_range')) {   
    
    Date.prototype.getFullMonth = function() {
        const month = this.getMonth()+1
        return month < 10 ? '0'+month : month

      }

    Date.prototype.getFullDate = function() {
        const date = this.getDate()
        return date < 10 ? '0'+date : date

      }

    //Empty array to store the dates for the dropdown menu
    var dates = [];
    //add to array "the dates" for the dropdown menu (needs a single blank one for the select option)
    dates.push("");

    
    //Date Range Picker
    //Auto Date Changer for Start and End Date
    var DateToday = new Date(); 
        var DateToday = DateToday.getFullYear()+'-'+(DateToday.getFullMonth())+'-'+DateToday.getFullDate(); 
        dates.push(DateToday + " - " + DateToday);

    var Yesterday = new Date();
        Yesterday.setDate(Yesterday.getDate() - 1);
        var Yesterday = Yesterday.getFullYear()+'-'+(Yesterday.getFullMonth())+'-'+Yesterday.getFullDate();
        dates.push(Yesterday + " - " + Yesterday);

    var lastWeek = new Date();
        lastWeek.setDate(lastWeek.getDate() - 7);
        var lastWeek = lastWeek.getFullYear()+'-'+(lastWeek.getFullMonth())+'-'+lastWeek.getFullDate();
        dates.push(lastWeek + " - " + DateToday);

    var Last30 = new Date();
        Last30.setDate(Last30.getDate() - 30);
        var Last30 = Last30.getFullYear()+'-'+(Last30.getFullMonth())+'-'+Last30.getFullDate();
        dates.push(Last30 + " - " + DateToday);

    //Variable is no longer Last 90 days, it is now past 3 months which is ~91.25 days
    var Last90 = new Date();
        Last90.setMonth(Last90.getMonth() - 3);
        var Last90 = Last90.getFullYear()+'-'+(Last90.getFullMonth())+'-'+Last90.getFullDate();
        dates.push(Last90 + " - " + DateToday);

    //Variable is no longer Last 180 days, it is now past 6 months which is ~182.5 days
    var Last180 = new Date();
        Last180.setMonth(Last180.getMonth() - 6);
        var Last180 = Last180.getFullYear()+'-'+(Last180.getFullMonth())+'-'+Last180.getFullDate();
        dates.push(Last180 + " - " + DateToday);

    var Last365 = new Date();
        Last365.setDate(Last365.getDate() - 365);
        var Last365 = Last365.getFullYear()+'-'+(Last365.getFullMonth())+'-'+Last365.getFullDate();
        dates.push(Last365 + " - " + DateToday);

    var currentMonth = new Date();
        currentMonth.setDate(currentMonth.getDate());
        var currentMonth = currentMonth.getFullYear()+'-'+(currentMonth.getFullMonth())+'-'+'01';
        dates.push(currentMonth + " - " + DateToday);
    

    
    //LastCalendarMonth
    var LastCalendarMonth = new Date();
        LastCalendarMonth.setMonth(LastCalendarMonth.getMonth()-1);
        var LastCalendarMonth = LastCalendarMonth.getFullYear()+'-'+ LastCalendarMonth.getFullMonth() +'-'+'01';

    var LastCalendarMonthEnd = new Date();
        LastCalendarMonthEnd.setDate(1);
        LastCalendarMonthEnd.setHours(-1);
        var LastCalendarMonthEnd = LastCalendarMonthEnd.getFullYear()+'-'+ (LastCalendarMonthEnd.getFullMonth()) +'-'+LastCalendarMonthEnd.getFullDate();
        dates.push(LastCalendarMonth + " - " + LastCalendarMonthEnd);


    var threeMonths = new Date();
        threeMonths.setMonth(threeMonths.getMonth() - 3);
        var threeMonths = threeMonths.getFullYear()+'-'+ threeMonths.getFullMonth() +'-'+'01';

    var threeMonthsEnd = new Date();
        threeMonthsEnd.setDate(1);
        threeMonthsEnd.setHours(-1);
        var threeMonthsEnd = threeMonthsEnd.getFullYear()+'-'+ (threeMonthsEnd.getFullMonth()) +'-'+threeMonthsEnd.getFullDate();
        dates.push(threeMonths + " - " + threeMonthsEnd);

    var NextCalendarMonth = new Date();
        NextCalendarMonth.setMonth(NextCalendarMonth.getMonth() + 1);
        var NextCalendarMonth = NextCalendarMonth.getFullYear()+'-'+ NextCalendarMonth.getFullMonth() +'-'+'01';

    var NextCalendarMonthEnd  = new Date();
        NextCalendarMonthEnd.setMonth(NextCalendarMonthEnd.getMonth() + 2);
        NextCalendarMonthEnd.setDate(0);
        var NextCalendarMonthEnd = NextCalendarMonthEnd.getFullYear()+'-'+ (NextCalendarMonthEnd.getFullMonth()) +'-'+NextCalendarMonthEnd.getFullDate();
        dates.push(NextCalendarMonth + " - " + NextCalendarMonthEnd);

        // variable name Next3CalendarMonth that is the end date of the next 3 calendar months
    var Next3CalendarMonth = new Date();
        Next3CalendarMonth.setMonth(Next3CalendarMonth.getMonth() + 4);
        Next3CalendarMonth.setDate(0);
        var Next3CalendarMonth = Next3CalendarMonth.getFullYear()+'-'+ (Next3CalendarMonth.getFullMonth()) +'-'+ Next3CalendarMonth.getFullDate();
        dates.push(NextCalendarMonth + " - " + Next3CalendarMonth);

    var startYTD = new Date();
        startYTD.setFullYear(startYTD.getFullYear());
        var startYTD = startYTD.getFullYear()+'-'+ '01' +'-'+ '01';
        dates.push(startYTD + " - " + DateToday);

    var startLastYear = new Date();
        startLastYear.setFullYear(startLastYear.getFullYear() - 1);
        var startLastYear = startLastYear.getFullYear()+'-'+ '01' +'-'+ '01';

    var endLastYear = new Date();
        endLastYear.setFullYear(endLastYear.getFullYear() - 1);
        var endLastYear = endLastYear.getFullYear()+'-'+ 12 +'-'+ 31;
        dates.push(startLastYear + " - " + endLastYear);

    var SinceTheStartOfTime = new Date();
        SinceTheStartOfTime.setFullYear(SinceTheStartOfTime.getFullYear() - 22);
        var SinceTheStartOfTime = SinceTheStartOfTime.getFullYear()+'-'+ '01' +'-'+ '01';


    var rolling_date = new Date();
        var rolling_dateVariable = 0;
        rolling_date.setDate(rolling_date.getDate() + rolling_dateVariable);
        var rolling_date = rolling_date.getFullYear()+'-'+ (rolling_date.getFullMonth()) +'-'+ rolling_date.getFullDate();


    function CustomRolling() {

        var offsetDateToday = new Date();
        let offset = document.getElementById("offset_date_range").value
        var rolling_dateVariable = document.getElementById("rolling_date").value;


        var custom_rolling_option = document.getElementById("custom_rolling_option").value;

        if (custom_rolling_option === "Past") {

        var rolling_date = new Date();
            rolling_date.setDate(rolling_date.getDate() - rolling_dateVariable - offset);
            offsetDateToday.setDate(offsetDateToday.getDate() - offset);

            var offsetDateToday = offsetDateToday.getFullYear()+'-'+ (offsetDateToday.getFullMonth()) +'-'+ offsetDateToday.getFullDate();
            var rolling_date = rolling_date.getFullYear()+'-'+ (rolling_date.getFullMonth()) +'-'+ rolling_date.getFullDate();
            

            document.getElementById("start_date").value = rolling_date;
            document.getElementById("end_date").value = offsetDateToday;
        }
        else if (custom_rolling_option === "Future" && document.getElementById('date_range').value != '') {

        var rolling_date = new Date();
            rolling_date.setDate(rolling_date.getDate() - - rolling_dateVariable - - offset);
            offsetDateToday.setDate(offsetDateToday.getDate() - - offset);

            var offsetDateToday = offsetDateToday.getFullYear()+'-'+ (offsetDateToday.getFullMonth()) +'-'+ offsetDateToday.getFullDate();
            var rolling_date = rolling_date.getFullYear() +'-'+ (rolling_date.getFullMonth()) +'-'+ rolling_date.getFullDate();

            document.getElementById("start_date").value = offsetDateToday;
            document.getElementById("end_date").value = rolling_date;
        }

    }

    // This is to populate the dropdown list with the dates
    // get element by ID Date_Picker_Dropdown and assign it to a variable
    var Date_Picker_Dropdown = document.getElementById("date_range");
    var Date_Picker_Dropdown_Options = Date_Picker_Dropdown.getElementsByTagName("option");
    var end_date_filter = "";

    // Adds Select2 styling to Date Range Dropdown. 
    // Uses above function 
    $('#date_range').select2({
    placeholder: 'Select a Date Range',
    escapeMarkup: function (markup) {
        return markup;
    },
    templateResult: function (d) {
        return '<span>'+d.text+'</span>';
    },
    templateSelection: function (d) {
        return '<span>'+d.text+'</span>' + '<span id="date-selection-subtext"> ( ' + d.subText + ')</span>';
    }

    })

    //When new date is selected, this updates the title with Title + Date (ex. Today 2022-10-07)
    $('#date_range').on('select2:close', function(e) {
        var title = document.getElementById("select2-date_range-container").innerText;
        document.getElementById("select2-date_range-container").title = title;
    });





    //adds translation from jinja in footer.html to select2 dropdown placeholder
    var date_selection_placeholder = $('#date_selection_placeholder').data();
    document.getElementById("select2-date_range-container").childNodes[0].childNodes[0].innerText = date_selection_placeholder.name;

    
    
    
    //Removes the select2 default of "undefined" from the dropdown text area
    if(document.getElementById("date-selection-subtext").innerText == ' ( undefined)'){
        document.getElementById("date-selection-subtext").innerText = ' '
    }



    const selectElement = document.getElementById("select2-date_range-container");
    selectElement.addEventListener('change', (event) => {
        var title = document.getElementById("select2-date_range-container").innerText;
        document.getElementById("select2-date_range-container").title = title;
    });


}