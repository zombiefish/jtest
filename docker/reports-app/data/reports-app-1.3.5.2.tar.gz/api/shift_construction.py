#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/shift_construction.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_form_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id', 'rpt_hazard_actions','rpt_form_details_distribution','rpt_form_reviewers'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)
    
        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures
        h.get_hazard_actions(result['rpt_hazard_actions'], imageUrl, self.args, self.lang) 
        h.get_general_actions(result['rpt_get_general_action_by_id'], imageUrl, self.args, self.lang)
        h.get_positive_recognitions(result['rpt_positive_recognition'], imageUrl, self.args, self.lang)

        for wc in result['rpt_form_details']:
            if wc['value'] is not None:
                if ('.jpg' or '.png') in wc['value']:
                    wc['value'] = imageUrl + wc['value']

        #Updating this section to be able to key on original section name 
        rpt_form_details = {}
        for row in result['rpt_form_details']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)

        result['rpt_form_details'] = rpt_form_details

        #Modifying the data structure as per the equipments as keys
        equipment1 = ['equipment_group_1','equipment_location_group_1','equipment_details_1']
        equipment2 = ['equipment_group_2','equipment_location_group_2','equipment_details_2']
        equipment3 = ['equipment_group_3','equipment_location_group_3','equipment_details_3']
        equipment4 = ['equipment_group_4','equipment_location_group_4','equipment_details_4']
        equipment5 = ['equipment_group_5','equipment_location_group_5','equipment_details_5']
        equipment6 = ['equipment_group_6','equipment_location_group_6','equipment_details_6']
        equipment7 = ['equipment_group_7','equipment_location_group_7','equipment_details_7']
        equipment8 = ['equipment_group_8','equipment_location_group_8','equipment_details_8']
        equipment9 = ['equipment_group_9','equipment_location_group_9','equipment_details_9']
        equipment10 = ['equipment_group_10','equipment_location_group_10','equipment_details_10']
        equipment11 = ['equipment_group_11','equipment_location_group_11','equipment_details_11']
        equipment12 = ['equipment_group_12','equipment_location_group_12','equipment_details_12']
        equipment13 = ['equipment_group_13','equipment_location_group_13','equipment_details_13']
        equipment14 = ['equipment_group_14','equipment_location_group_14','equipment_details_14']
        equipment15 = ['equipment_group_15','equipment_location_group_15','equipment_details_15']

        equipment_details=['next_shift_requirements','extras_delays','end_states']

        result['equipment_state_details'] = []
        result['work_equipments1'] = []
        result['work_equipments2'] = []
        result['work_equipments3'] = []
        result['work_equipments4'] = []
        result['work_equipments5'] = []
        result['work_equipments6'] = []
        result['work_equipments7'] = []
        result['work_equipments8'] = []
        result['work_equipments9'] = []
        result['work_equipments10'] = []
        result['work_equipments11'] = []
        result['work_equipments12'] = []
        result['work_equipments13'] = []
        result['work_equipments14'] = []
        result['work_equipments15'] = []



        if 'Shift Report' in rpt_form_details:
            for shift in rpt_form_details['Shift Report']:

                if shift['field_type'] == 'MultiPhotoPicker':
                    if ('.jpg' or '.png') in shift['value']:
                        shift['value'] = imageUrl + shift['value']
                
                if shift['field_key'] in equipment_details:
                    result['equipment_state_details'].append(shift)

                if shift['field_key'] in equipment1:
                    result['work_equipments1'].append(shift)

                if shift['field_key'] in equipment2:
                    result['work_equipments2'].append(shift)

                if shift['field_key'] in equipment3:
                    result['work_equipments3'].append(shift)

                if shift['field_key'] in equipment4:
                    result['work_equipments4'].append(shift)

                if shift['field_key'] in equipment5:
                    result['work_equipments5'].append(shift)

                if shift['field_key'] in equipment6:
                    result['work_equipments6'].append(shift)

                if shift['field_key'] in equipment7:
                    result['work_equipments7'].append(shift)

                if shift['field_key'] in equipment8:
                    result['work_equipments8'].append(shift)

                if shift['field_key'] in equipment9:
                    result['work_equipments9'].append(shift)

                if shift['field_key'] in equipment10:
                    result['work_equipments10'].append(shift)

                if shift['field_key'] in equipment11:
                    result['work_equipments11'].append(shift)

                if shift['field_key'] in equipment12:
                    result['work_equipments12'].append(shift)

                if shift['field_key'] in equipment13:
                    result['work_equipments13'].append(shift)

                if shift['field_key'] in equipment14:
                    result['work_equipments14'].append(shift)

                if shift['field_key'] in equipment15:
                    result['work_equipments15'].append(shift)
      
      
        return result
    