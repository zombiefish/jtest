#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/cap_and_mag_powder.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_form_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id','rpt_hazard_actions','rpt_form_details_distribution','rpt_form_reviewers'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)
    
    

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures

        h.get_hazard_actions(result['rpt_hazard_actions'], imageUrl, self.args, self.lang)
        h.get_general_actions(result['rpt_get_general_action_by_id'], imageUrl, self.args, self.lang)
        h.get_positive_recognitions(result['rpt_positive_recognition'], imageUrl, self.args, self.lang)



        #Updating this section to be able to key on original section name 
        rpt_form_details = {}
        for row in result['rpt_form_details']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)

        #Updating the boolean values to Yes/No/NA 
        if 'Powder Magazine' in rpt_form_details:
            for wc in rpt_form_details['Powder Magazine'] :
                if (wc['field_key'] not in ['pow_quantity_explosives_kg','pow_damaged_explosives_kg']):
                    if wc['value'] == '1':
                        wc['value'] = wc['yes_value']
                    else :
                        if wc['value'] == '0':
                            wc['value'] = wc['no_value'] 
                        elif wc['value'] == '-1':
                            wc['value'] = 'N/A'
                        else:
                            wc['value'] = wc['value']

        if 'Cap Magazine' in rpt_form_details:
            for wc in rpt_form_details['Cap Magazine'] :
                if (wc['field_key'] not in ['cap_quantity_detonators_units']):
                    if wc['value'] == '1':
                        wc['value'] = wc['yes_value']
                    else :
                        if wc['value'] == '0':
                            wc['value'] = wc['no_value'] 
                        elif wc['value'] == '-1':
                            wc['value'] = 'N/A'
                        else:
                            wc['value'] = wc['value']
        
        result['rpt_form_details'] = rpt_form_details

        #Fetching the report specific images from the rpt_form_pictures SP
        result['rpt_form_pictures'] = h.execute_sp('rpt_form_pictures', [formSubmissionId, imageUrl, 'multiphoto_picker_1'], self.args)
        result['rpt_form_signature'] = h.execute_sp('rpt_form_pictures', [formSubmissionId, imageUrl, 'signature_auditor'], self.args)

        return result
    