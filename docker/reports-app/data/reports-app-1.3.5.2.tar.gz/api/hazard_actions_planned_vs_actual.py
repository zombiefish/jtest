#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId):
        result = {}

        ## Load report-specific configuration
        with open('config/hazard_actions_planned_vs_actual.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        if formSubmissionId != None:
            result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['optional_args'] = config['optional_args'] if config['optional_args'] is not None else []
        result['required_args'] = config['required_args'] if config['required_args'] is not None else []
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'optional_args':config['optional_args'], 'lang': self.lang})    
        result['args'] = dict(self.args)

        # place the report title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [3458,self.lang,1], self.args)[0]['ltr_text']

        # Check if user entered all the required parameters and executing the main SP line 46
        required_args = config['required_args']
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            start_date=self.args['start_date']      
            end_date=self.args['end_date'] 
            site_ids = self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            from_who = self.args['from_who'] if 'from_who' in self.args and self.args['from_who'] != '' else None
            by_who = self.args['by_who'] if 'by_who' in self.args and self.args['by_who'] != '' else None
          
            #site_ids 
            site_ids=self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            site_ids_list = site_ids.split(',') if site_ids is not None else []
            site_data_name = {}            
            user_site_data = result['filter_data']['optionalArgs']['site_ids']['field_values']
            if site_ids_list:
                site_data_name = {each['value'] for each in user_site_data if str(each['value']) in site_ids_list}
            else:
                site_data_name = {each['value'] for each in user_site_data}
            
            site_ids = ','.join(map(str, site_data_name))


            #by_who 
            by_who=self.args['by_who'] if 'by_who' in self.args and self.args['by_who'] != '' else None
            by_who_list = by_who.split(',') if by_who is not None else []
            by_who_data_name = {}            
            user_by_who_data = result['filter_data']['optionalArgs']['by_who']['field_values']
            if by_who_list:
                by_who_data_name = {each['value'] for each in user_by_who_data if str(each['value']) in by_who_list}
            else:
                by_who_data_name = {each['value'] for each in user_by_who_data}
            
            by_who = ','.join(map(str, by_who_data_name))

            #from_who 
            from_who=self.args['from_who'] if 'from_who' in self.args and self.args['from_who'] != '' else None
            from_who_list = from_who.split(',') if from_who is not None else []
            from_who_data_name = {}            
            user_from_who_data = result['filter_data']['optionalArgs']['from_who']['field_values']
            if from_who_list:
                from_who_data_name = {each['value'] for each in user_from_who_data if str(each['value']) in from_who_list}
            else:
                from_who_data_name = {each['value'] for each in user_from_who_data}
            
            from_who = ','.join(map(str, from_who_data_name))


            # Removing the status filter from the report
            #status = self.args['status']
            #cStatus = status.replace('1','complete')
            #iStatus = cStatus.replace('0','incomplete')
            iStatus = ''

            sp_inputs = [start_date, end_date, site_ids, from_who, by_who, iStatus, self.lang]

            # Executing the main SP with all the filter conditions
            result['rpt_hazard_actions_planned_vs_actual'] = h.execute_sp('rpt_hazard_actions_planned_vs_actual', sp_inputs, self.args)  
            
            # result['rpt_hazard_actions_planned_vs_actual'] = h.execute_sp('rpt_hazard_actions_planned_vs_actual', [start_month, end_month, site_ids, from_who, by_who, iStatus, year, self.lang], self.args)
        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result
    