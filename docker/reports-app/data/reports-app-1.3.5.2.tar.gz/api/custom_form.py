#Import important libraries for the report to load
import yaml
import helper as h
import pandas as pd


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/custom_form.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_custom_form_header','rpt_form_details', 'rpt_positive_recognition','rpt_get_general_action_by_id','rpt_hazard_actions','rpt_form_details_distribution','rpt_form_reviewers'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            elif sp == 'rpt_custom_form_items':
                result[sp] = h.execute_sp(sp, [formSubmissionId, imageUrl, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args) 

        section_title_fob_id = result['rpt_custom_form_items'][0]['cfm_fob_id']


        section_title = h.execute_sql(
            """
                    SELECT 
                '' as additional_info_item,
                null as additional_info_value,
                '' as additional_information_label,
                '' as additional_response_label,
                null as cfa_id,
                null as cfd_cfm_id,
                null as cfd_id,
                null as cfm_fob_id,
                null as cfm_id,
                null as fbi_fft_id,
                language_translation.ltr_text as fbi_field_label,
                null as fbi_id,
                form_builder_item.fbi_sort as fbi_sort,
                null as fbi_tag_type,
                null as images,
                null as img_comments,
                null as img_timestamp,
                null as items_label,
                null as no_label,
                null as response_item,
                null as response_label,
                null as response_value,
                1 as section_title,
                null as yes_label 
        FROM form_builder_item 
        INNER JOIN language_translation
        on form_builder_item.fbi_field_label = language_translation.ltr_tag
        wHERE form_builder_item.fbi_tag_type = language_translation.ltr_tag_type
        AND language_translation.ltr_lng_id = """+str(self.lang)+"""
        AND fbi_fob_id ="""+str(section_title_fob_id)+""" AND fbi_fft_id = 11;
            """
        )
        
        for val in section_title['result']:
            result['rpt_custom_form_items'].append(val)

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures
        
        h.get_hazard_actions(result['rpt_hazard_actions'], imageUrl, self.args, self.lang)
        h.get_general_actions(result['rpt_get_general_action_by_id'], imageUrl, self.args, self.lang)
        h.get_positive_recognitions(result['rpt_positive_recognition'], imageUrl, self.args, self.lang)


        #Updating this section to be able to key on original section name 
        rpt_form_details = {}
        for row in result['rpt_form_details']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)
    
        result['rpt_form_details'] = rpt_form_details

        df = pd.DataFrame(result['rpt_custom_form_items'])
        df = df.fillna('')
        sorted = df.sort_values('fbi_sort')

        result['rpt_custom_form_items'] = sorted.to_dict("records")

        for data in result['rpt_custom_form_items']:
            imgs = []
            time_stamps = []
            imgs_comments = []
        
            if data['images']:
                imgs = data['images'].split(',')
                data['images'] = imgs

            if data['img_timestamp']:
                time_stamps = data['img_timestamp'].split(',')
                data['img_timestamp'] = time_stamps

            if data['img_comments']:
                imgs_comments = data['img_comments'].split(',')
                data['img_comments'] = imgs_comments

        
        result['rpt_custom_form_items_data'] = []
        counter = 0
        result['list'] = []
        result['list'].append([])
        for data in result['rpt_custom_form_items']:
            if data['section_title'] is None:
                result['rpt_custom_form_items_data'].append(data)
                result['list'][counter].append(data)
            else:
                result['list'].append([])
                counter=counter+1
                result['rpt_custom_form_items_data'].append(data)
                result['list'][counter].append(data)

        
        #Fetching the report specific images from the rpt_form_pictures SP
        result['rpt_custom_form_pictures'] = h.execute_sp('rpt_custom_form_pictures', [formSubmissionId, imageUrl, self.lang], self.args)
  
        return result
     