#Import important libraries for the report to load
import yaml
import helper as h
import plotly.express as px
import pandas as pd
import plotly
import json

def get_report(self, formSubmissionId):
        result = {}

        ## Load report-specific configuration
        with open('config/document_review_summary_by_user.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['required_args'] = config['required_args']
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang})    
        result['args'] = dict(self.args)

        # place the Title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [90,self.lang,1], self.args)[0]['ltr_text']
        # Check if user entered all the required parameters
        
        # Grab all of the Lables
        result['report_labels'] = []
        result['report_labels'] = {
            "document_type" : h.execute_sp('get_translation_by_tag', [1347, self.lang, 1], self.args)[0]['ltr_text'],
            "description_label" : h.execute_sp('get_translation_by_tag', [143, self.lang, 1], self.args)[0]['ltr_text'],
            "total" : h.execute_sp('get_translation_by_tag', [1044, self.lang, 1], self.args)[0]['ltr_text'],
            "complete" : h.execute_sp('get_translation_by_tag', [2045, self.lang, 1], self.args)[0]['ltr_text'],
            "due" : h.execute_sp('get_translation_by_tag', [1047, self.lang, 1], self.args)[0]['ltr_text'],
            "overdue" : h.execute_sp('get_translation_by_tag', [1048, self.lang, 1], self.args)[0]['ltr_text'],
            "reviewed" : h.execute_sp('get_translation_by_tag', [2443, self.lang, 1], self.args)[0]['ltr_text'],
            "completion" : h.execute_sp('get_translation_by_tag', [1043, self.lang, 1], self.args)[0]['ltr_text'],
            "nochart" : h.execute_sp('get_translation_by_tag', [8870, self.lang, 1], self.args)[0]['ltr_text'],


            "document_status" : h.execute_sp('get_translation_by_tag', [2807, self.lang, 1], self.args)[0]['ltr_text'],
            "reviewer_status" : h.execute_sp('get_translation_by_tag', [2809, self.lang, 1], self.args)[0]['ltr_text'],
            "reviews_required" : h.execute_sp('get_translation_by_tag', [2808, self.lang, 1], self.args)[0]['ltr_text'],
            "document_completion" : h.execute_sp('get_translation_by_tag', [2806, self.lang, 1], self.args)[0]['ltr_text'],

            }

        ## Getting all the filter conditions and creating a variable for the same
        required_args = config['required_args']
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            date1=self.args['start_date']     
            date2=self.args['end_date'] 
            user_ids = self.args['user_ids'] 
            doc_ids = self.args['doc_ids']
            allRecs=[]
            
            # Format the output for the report and executing the main SP at line 75
            for user in user_ids.split(","):
                docsOverdueTotal=0
                dueTotal=0
                overdueTotal=0
                requiredTotal=0
                reviewedTotal=0
                totalTotal=0
                completeTotal=0
                allUserRecs=[]
                allVals=[]
                allLabels=[]
                out = h.execute_sp('rpt_document_review_summary_by_user', [date1, date2, doc_ids, user, self.lang], self.args)
            

                #Dataframe to get sum of documents as per docType
                df = pd.DataFrame(out)
                if 'DocType' in df:
                    
                    df2 = df.groupby(['DocType']).agg({'Total':'sum'}).reset_index()                
                    df.drop('Total', inplace=True, axis=1)
                    df3 = pd.merge(df, df2, how='left', on='DocType')
                    df3['complete_percent'] = df3[['reviewed_by_user', 'total_required_reviewers']].apply(lambda rec: format(rec['reviewed_by_user'] / rec['total_required_reviewers'] * 100, "^-2.1f") , axis=1)
                    doctype_table = json.loads(df3.to_json(orient='records'))
                
                    dfDoctype = pd.DataFrame(doctype_table)
                    docType_group = dfDoctype.groupby(['DocType','Total'])

                    final_dict = {}

                    for doc, data in docType_group:
                        key=','.join(map(str,list(doc)))

                        final_dict[key] = data.to_dict(orient="records")


                    graphDoc = []
                    graphDocType = []

                    for doc, data in docType_group:
                        graphDoc.append(doc[0])
                        graphDoc.append(doc[1])
                    graphDocType.append(graphDoc)

                    for rec in out:

                        docsOverdueTotal+=int(rec['doc_overdue'])
                        dueTotal+=int(rec['doc_due'])
                        overdueTotal+=rec['overdue_for_user']
                        requiredTotal+=rec['total_required_reviewers']
                        reviewedTotal+=rec['reviewed_by_user']
                        totalTotal+=rec['Total']
                        completeTotal=rec['Complete']
                        perComplete = format(rec['reviewed_by_user'] / rec['total_required_reviewers'] * 100, "^-2.1f")
                        rec['complete_percent'] = perComplete


                        # Fix note - i and the DocType for lineup are never matching. i only finds admin. This is the issue to fix on monday
                        loopIndex = 0
                        for i in graphDocType[0]:

                            perComplete = float(perComplete)
                            if perComplete == 100 and graphDocType[0][loopIndex] == rec['DocType']:
                                allVals.append(perComplete/graphDocType[0][loopIndex+1])
                                allLabels.append(rec['DocType'])
                                allUserRecs.append(rec)
                                loopIndex += 1 
                                break
                                
                            elif (loopIndex == (len(graphDocType[0])-1)):
                                allVals.append(0)
                                allLabels.append(rec['DocType'])
                                allUserRecs.append(rec)
                                loopIndex += 1
                                break

                            else:
                                loopIndex += 1


                    newLabels = []
                    for i in allLabels:
                        if i not in newLabels:
                            newLabels.append(i)

                    newVals = []
                    loopIndex2 = 0
                    for i in newLabels:
                        sum = 0
                        for j in allLabels:
                            if i == j:
                                sum += allVals[loopIndex2]
                                loopIndex2 += 1
                        newVals.append(sum)

                    # Creating graph data         
                    lineGraphJSON=[]
                    if out:
                        lineGraphJSON = [
                            {
                            "y": newVals,
                            "x": newLabels,
                            "type": 'bar',
                            }
                        ]
                        lineGraphLayout = {
                            "automargin": True,
                            "title": {
                                    "text": allUserRecs[0]['per_full_name'],
                                    "font": {
                                        "family":"Arial Black",
                                        "size": 14,
                                    #   color: "Black"
                                    }
                            },
                            "autosize":True,
                            "showlegend": False,
                            "width": 750,
                            "height": 400,
                            "legend": {
                                "orientation": "h", 
                                    "font":{
                                    "family":"Arial", 
                                    "size":18
                                    },
                                    "yanchor": "bottom",
                                    "y": -1,
                                    "xanchor": "center",
                                    "x": 0.5,
                                    "automargin": True,
                                    
                                },
                            "xaxis": {
                                "title": {
                                    "text": result['report_labels']['document_type'],
                                    "font": {
                                        "family":"Arial",
                                        "size": 14,
                                    #  "color": "Black"
                                    },  
                                    "standoff": 40
                                },
                                "showgrid": False,
                                "automargin": True,
                                #  pad: 50
                                #  dtick: 1
                            },
                            "yaxis": {
                                "title": {
                                    "text": result['report_labels']['document_completion'],
                                    "font": {
                                        "family": "Arial",
                                        "size": 14,
                                    #   "color": 'black'
                                    },
                                },
                                "zeroline": False,
                                "automargin": True
                                #  ticks: 'outside',
                            },
                            "barmode":'group',
                            "displayModeBar": False, 
                            #  automargin:true
                            "margin": {
                                "l": 50,
                                "r": 50,
                                "b": 50,
                                "t": 100,
                                "pad": 15
                            },
                        }


                # insert the Grand Totals
                if allUserRecs:
                    allRecs.append({"records":doctype_table,
                    "docutype_groups":final_dict,
                    "graphData":lineGraphJSON,
                    "graphLayout" : lineGraphLayout,
                    "Totals": 
                        {
                        "docsOverdueTotal":docsOverdueTotal,
                        "dueTotal":dueTotal,
                        "overdueTotal":overdueTotal,
                        "requiredTotal":requiredTotal,
                        "reviewedTotal":reviewedTotal,
                        "totalTotal":totalTotal,
                        "completeTotal":completeTotal,
                        "completionPercent": format(reviewedTotal/requiredTotal * 100, "^-2.1f")
                        }
                    })

                result['rpt_document_review_summary_by_user'] = allRecs

        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result