#Import important libraries for the report to load
import yaml
import helper as h

class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/incident_report.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['formSubmissionId'] = formSubmissionId
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['review'] = config['review']
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures

        ## Preliminary Incident
        result['PrelimIncident']=[]
        result['rpt_form_header_incident_report'] = h.execute_sp('rpt_form_header_incident_report', [formSubmissionId,'Preliminary Incident' ,self.lang])
        result['rpt_incident_signoffs'] = h.execute_sp('rpt_incident_signoffs', [formSubmissionId, self.lang])
        result['rpt_incident_header'] = h.execute_sp('rpt_incident_header', [formSubmissionId, self.lang])
        for pi in result['rpt_form_header_incident_report']:
            PI = {}
            PI[pi['ID']]={}
            PI[pi['ID']]['rpt_form_header_incident_report'] = pi
            for sp in config['stored_procedures']:  
                if sp in ('rpt_form_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id', 'rpt_form_details_distribution', 'rpt_form_reviewers', 'rpt_hazard_actions'):
                    PI[pi['ID']][sp] = h.execute_sp(sp, [pi['ID'], self.lang], self.args)
                else:
                    PI[pi['ID']][sp] = h.execute_sp(sp, [pi['ID']], self.args)
            
            ## Load parameterized Stored Procedures
            PI[pi['ID']]['rpt_hap_pictures_initial'] = []
            PI[pi['ID']]['rpt_hap_pictures_followup'] = []

            ## Load parameterized Stored Procedures
            for hap in PI[pi['ID']]['rpt_hazard_actions']:
                hap['rpt_hap_pictures_initial'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'INITIAL', self.lang], self.args)
                hap['rpt_hap_pictures_followup'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'FOLLOWUP', self.lang], self.args)
                hap['HAP_complete'] = h.execute_sp('rpt_hazard_actions_list_completed', [hap['ID'], self.lang], self.args)
                    
            PI[pi['ID']]['rpt_pid_pictures'] = []
            if len(PI[pi['ID']]['rpt_positive_recognition']) > 0:
                for pid in PI[pi['ID']]['rpt_positive_recognition']:
                    pid['rpt_positive_recognition_likes'] = h.execute_sp('rpt_positive_recognition_likes', [pid["ID"], self.lang], self.args)
                    pid['rpt_pid_pictures'] = h.execute_sp('rpt_pid_pictures', [pid["ID"], imageUrl, self.lang], self.args)
                    pid['rpt_positive_recognition_comment'] = h.execute_sp('rpt_positive_recognition_comment', [pid["ID"], self.lang], self.args)

                
            PI[pi['ID']]['rpt_get_general_action_attachment_by_sga_id_initial'] = []
            PI[pi['ID']]['rpt_get_general_action_attachment_by_sga_id_followup'] = []        
            for gga in PI[pi['ID']]['rpt_get_general_action_by_id']:
                gga['rpt_get_general_action_attachment_by_sga_id_initial'] = h.execute_sp('rpt_get_general_action_attachment_by_sga_id', [gga['sga_id'],imageUrl+'general_action/','INITIAL', self.lang], self.args)
                gga['rpt_get_general_action_attachment_by_sga_id_followup'] = h.execute_sp('rpt_get_general_action_attachment_by_sga_id', [gga['sga_id'],imageUrl+'general_action/','FOLLOWUP', self.lang], self.args)
                gga['GA_complete'] = h.execute_sp('rpt_get_general_actions_list_completed', [gga['sga_id'], self.lang], self.args)


            rpt_form_details = {}
            for row in PI[pi['ID']]['rpt_form_details']:
                if row['original_section_name'] not in rpt_form_details:
                    rpt_form_details[row['original_section_name']] = []
                rpt_form_details[row['original_section_name']].append(row)

            if 'Other(s) Involved' in rpt_form_details:
                for wc in rpt_form_details['Other(s) Involved'] :
                    if wc['value'] == '1':
                        wc['value'] = wc['yes_value']
                    else :
                        if wc['value'] == '0':
                            wc['value'] = wc['no_value'] 
                        elif wc['value'] == '-1':
                            wc['value'] = 'N/A'
                        else:
                            wc['value'] = wc['value']

            if 'Preliminary Report Checklist' in rpt_form_details:
                for wc in rpt_form_details['Preliminary Report Checklist'] :
                    if wc['value'] == '1':
                        wc['value'] = wc['yes_value']
                    else :
                        if wc['value'] == '0':
                            wc['value'] = wc['no_value'] 
                        elif wc['value'] == '-1':
                            wc['value'] = 'N/A'
                        else:
                            wc['value'] = wc['value']
                
            PI[pi['ID']]['rpt_incident_attachments'] = h.execute_sp('rpt_incident_attachments', [pi['ID'], imageUrl, self.lang], self.args)

            PI[pi['ID']]['rpt_form_details'] = rpt_form_details

            result['PrelimIncident'].append(PI)



        ## Preliminary Investigation
        result['PrelimInvestigation']=[]
        result['rpt_form_header_incident_report'] = h.execute_sp('rpt_form_header_incident_report', [formSubmissionId,'Preliminary Investigation' ,self.lang])
        
        for pi in result['rpt_form_header_incident_report']:
            PI = {}
            PI[pi['ID']]={}
            PI[pi['ID']]['rpt_form_header_incident_report'] = pi
            for sp in config['stored_procedures']:  
                if sp in ('rpt_form_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id', 'rpt_form_details_distribution', 'rpt_form_reviewers', 'rpt_hazard_actions'):
                    #result[sp] = h.execute_sp(sp, [pi['ID'], self.lang], self.args)
                    PI[pi['ID']][sp] = h.execute_sp(sp, [pi['ID'], self.lang], self.args)
                else:
                    PI[pi['ID']][sp] = h.execute_sp(sp, [pi['ID']], self.args)
            
            ## Load parameterized Stored Procedures
            PI[pi['ID']]['rpt_hap_pictures_initial'] = []
            PI[pi['ID']]['rpt_hap_pictures_followup'] = []

            ## Load parameterized Stored Procedures
            for hap in PI[pi['ID']]['rpt_hazard_actions']:
                hap['rpt_hap_pictures_initial'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'INITIAL', self.lang], self.args)
                hap['rpt_hap_pictures_followup'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'FOLLOWUP', self.lang], self.args)
                hap['HAP_complete'] = h.execute_sp('rpt_hazard_actions_list_completed', [hap['ID'], self.lang], self.args)

                    
            PI[pi['ID']]['rpt_pid_pictures'] = []
            if len(PI[pi['ID']]['rpt_positive_recognition']) > 0:
                for pid in PI[pi['ID']]['rpt_positive_recognition']:
                    pid['rpt_positive_recognition_likes'] = h.execute_sp('rpt_positive_recognition_likes', [pid["ID"], self.lang], self.args)
                    pid['rpt_pid_pictures'] = h.execute_sp('rpt_pid_pictures', [pid["ID"], imageUrl, self.lang], self.args)
                    pid['rpt_positive_recognition_comment'] = h.execute_sp('rpt_positive_recognition_comment', [pid["ID"], self.lang], self.args)

            PI[pi['ID']]['rpt_get_general_action_attachment_by_sga_id_initial'] = []
            PI[pi['ID']]['rpt_get_general_action_attachment_by_sga_id_followup'] = []        
            for gga in PI[pi['ID']]['rpt_get_general_action_by_id']:
                gga['rpt_get_general_action_attachment_by_sga_id_initial'] = h.execute_sp('rpt_get_general_action_attachment_by_sga_id', [gga['sga_id'],imageUrl+'general_action/','INITIAL', self.lang], self.args)
                gga['rpt_get_general_action_attachment_by_sga_id_followup'] = h.execute_sp('rpt_get_general_action_attachment_by_sga_id', [gga['sga_id'],imageUrl+'general_action/','FOLLOWUP', self.lang], self.args)
                gga['GA_complete'] = h.execute_sp('rpt_get_general_actions_list_completed', [gga['sga_id'], self.lang], self.args)
        

        

            rpt_form_details = {}
            for row in PI[pi['ID']]['rpt_form_details']:
                if row['original_section_name'] not in rpt_form_details:
                    rpt_form_details[row['original_section_name']] = []
                rpt_form_details[row['original_section_name']].append(row)

            # convert the boolean to yes/no per section
            if 'Investigation Summary - Who was directly involved?' in rpt_form_details:
                for wc in rpt_form_details['Investigation Summary - Who was directly involved?']:
                    if (wc['field_key'] in ['was_5pt_card_gathered','was_5pt_card_completed','was_statement_gathered','was_task_routine', 'was_involved_qualified','was_statement_gathered_from_witness']):
                        if wc['value'] == '1':
                            wc['value'] = wc['yes_value']
                        else :
                            if wc['value'] == '0':
                                wc['value'] = wc['no_value'] 
                            else:
                                wc['value'] = 'N/A'
            
            if 'Investigation Summary - What happened?' in rpt_form_details:
                for wc in rpt_form_details['Investigation Summary - What happened?']:
                    if (wc['field_key'] in ['scene_secured']):
                        if wc['value'] == '1':
                            wc['value'] = wc['yes_value']
                        else :
                            if wc['value'] == '0':
                                wc['value'] = wc['no_value'] 
                            else:
                                wc['value'] = 'N/A'
            
            # Add the image URL to the photo filenames
            if 'Investigation Summary - Workplace Conditions' in rpt_form_details:
                for wc in rpt_form_details['Investigation Summary - Workplace Conditions']:
                    if wc['value'] is not None:
                        if  wc['field_key'] == 'workplace_conditions_photos':
                            wc['value'] = imageUrl + wc['value']
            
            PI[pi['ID']]['rpt_form_details'] = rpt_form_details

            result['PrelimInvestigation'].append(PI)


        ## Root Cause Analysis
        result['RCA']=[]
        result['rpt_root_cause_analysis_by_id'] = h.execute_sp('rpt_root_cause_analysis_by_id', [formSubmissionId, self.lang])
        
        for pi in result['rpt_root_cause_analysis_by_id']:
            PI = {}
            PI[pi['ID']]={}
            PI[pi['ID']]['rpt_root_cause_analysis_by_id'] = pi
            for sp in config['stored_procedures_rca']:  
                if sp in ('rpt_root_cause_analysis_immed_causes','rpt_root_cause_analysis_basic_causes','rpt_incident_analysis_reviewers'):
                    PI[pi['ID']][sp] = h.execute_sp(sp, [pi['ID'], self.lang], self.args)

            result['RCA'].append(PI)

        ## Corrective Actions
        result['CA']=[]
        result['rpt_get_submissions_by_incident_number'] = h.execute_sp('rpt_get_submissions_by_incident_number', [formSubmissionId])
        for pi in result['rpt_get_submissions_by_incident_number']:
            PI = {}
            PI[pi['ID']]={}
            
            for sp in config['stored_procedures']:  
                if sp in ('rpt_form_header', 'rpt_get_general_action_by_id', 'rpt_hazard_actions'):
                    #result[sp] = h.execute_sp(sp, [pi['ID'], self.lang], self.args)
                    PI[pi['ID']][sp] = h.execute_sp(sp, [pi['ID'], self.lang], self.args)
            
            ## Load parameterized Stored Procedures
            PI[pi['ID']]['rpt_hap_pictures_initial'] = []
            PI[pi['ID']]['rpt_hap_pictures_followup'] = []

            ## Load parameterized Stored Procedures
            for hap in PI[pi['ID']]['rpt_hazard_actions']:
                hap['rpt_hap_pictures_initial'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'INITIAL', self.lang], self.args)
                hap['rpt_hap_pictures_followup'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'FOLLOWUP', self.lang], self.args)
                hap['HAP_complete'] = h.execute_sp('rpt_hazard_actions_list_completed', [hap['ID'], self.lang], self.args)

                
            PI[pi['ID']]['rpt_get_general_action_attachment_by_sga_id_initial'] = []
            PI[pi['ID']]['rpt_get_general_action_attachment_by_sga_id_followup'] = []        
            for gga in PI[pi['ID']]['rpt_get_general_action_by_id']:
                gga['rpt_get_general_action_attachment_by_sga_id_initial'] = h.execute_sp('rpt_get_general_action_attachment_by_sga_id', [gga['sga_id'],imageUrl+'general_action/','INITIAL', self.lang], self.args)
                gga['rpt_get_general_action_attachment_by_sga_id_followup'] = h.execute_sp('rpt_get_general_action_attachment_by_sga_id', [gga['sga_id'],imageUrl+'general_action/','FOLLOWUP', self.lang], self.args)
                gga['GA_complete'] = h.execute_sp('rpt_get_general_actions_list_completed', [gga['sga_id'], self.lang], self.args)


            result['CA'].append(PI)

        return result
    