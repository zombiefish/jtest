#Import important libraries for the report to load
from datetime import datetime, date, timedelta
import yaml
import helper as h
import pandas as pd

class Report:

    def __init__(self, args):

        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId = None):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/employee_training_records.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['filter'] = config['filter']
        result['optional_args'] = config['optional_args'] if config['optional_args'] is not None else []
        result['required_args'] = config['required_args'] if config['required_args'] is not None else []
        result['filter_data'] = h.get_filter_data({'required_args': result['required_args'] , 'lang': self.lang, 'optional_args':config['optional_args'],'report_slug':config['header']['slug']})          
        result['args'] = dict(self.args)
        # get the report Title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [9417,self.lang,1], self.args)[0]['ltr_text']
        # adding this exclusively to display 'about to expire' in status column
        result['about_to_expire_label'] = h.execute_sp('get_translation_by_tag', [8865,self.lang,1], self.args)[0]['ltr_text']

        #Handling the optional filter functionality
        optional_args = config['optional_args']
        required_args = config['required_args']
        sites = self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None

        #per_ids 
        per_ids=self.args['per_ids'] if 'per_ids' in self.args and self.args['per_ids'] != '' else None
        per_ids_list = per_ids.split(',') if per_ids is not None else []
        per_ids_data_name = {}            
        user_per_ids_data = result['filter_data']['optionalArgs']['per_ids']['field_values']
        if per_ids_list:
            per_ids_data_name = {each['value'] for each in user_per_ids_data if str(each['value']) in per_ids_list}
        else:
            per_ids_data_name = {each['value'] for each in user_per_ids_data}
        per_ids = ','.join(map(str, per_ids_data_name))
        
        if 'apply' in result['args']:
            allRecs = h.execute_sp('rpt_employee_training_records', [per_ids,sites,self.lang], self.args)
            # group by using form nameimport pandas as
            if len(allRecs) > 0:
                df = pd.DataFrame(allRecs)
                allTemp = {}
                allRecs = df.groupby(['Site','per_id'])                

                for emp,data in allRecs:
                    temp = []
                    for a,user in allRecs:
                        if a[0] == emp[0]:
                            temp.append(user.to_dict('records'))
                    
                    for user in temp:
                        for rec in user:
                            rec['is_expired'] = False
                            rec['30day_expired'] = False
                            if rec['expiry_date']:
                                theDate = datetime.strptime(rec['expiry_date'], '%Y-%m-%d').date()
                                if theDate < date.today():
                                    rec['is_expired'] = True
                                if theDate > date.today() and theDate < date.today() + timedelta(days=30):
                                    rec['30day_expired'] = True                      
                            
                    allTemp.update({ emp[0]:temp })
                result['rpt_employee_training_records'] = allTemp

            else:
                result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result
