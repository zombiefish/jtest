#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/vale_flha.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_form_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id', 'rpt_hazard_actions','rpt_form_details_distribution','rpt_form_reviewers', 'rpt_vale_flha_tasks', 'rpt_vale_flha_critical_activity_requirements'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args) 

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
         ## Load parameterized Stored Procedures
        h.get_hazard_actions(result['rpt_hazard_actions'], imageUrl, self.args, self.lang) 
        h.get_general_actions(result['rpt_get_general_action_by_id'], imageUrl, self.args, self.lang)
        h.get_positive_recognitions(result['rpt_positive_recognition'], imageUrl, self.args, self.lang)

        #Updating this section to be able to key on original section name        
        rpt_form_details = {}
        for row in result['rpt_form_details']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)

        #Creating the image URL as per the report specific section
        if 'State Details' in rpt_form_details:
            for wc in rpt_form_details['State Details']:
                if wc['value'] is not None:
                    if ('.jpg' or '.png') in wc['value']:
                        wc['value'] = imageUrl + wc['value']

        if 'Signature' in rpt_form_details:
            for wc in rpt_form_details['Signature']:
                if wc['value'] is not None:
                    if ('.jpg' in wc['value']) or ('.png' in wc['value']) or ('.jpeg' in wc['value']):
                        wc['value'] = imageUrl + wc['value']

        if 'Review' in rpt_form_details:
            for wc in rpt_form_details['Review']:
                if wc['value'] is not None:
                    if ('.jpg' in wc['value']) or ('.png' in wc['value']) or ('.jpeg' in wc['value']):
                        wc['value'] = imageUrl + wc['value']
                    if wc['field_key'] == 'signature_end_of_shift_review':
                        wc['field_order'] = wc['field_order'] + 1
                    elif wc['field_key'] == 'signature_end_of_shift_review_img_time':
                        wc['field_order'] = wc['field_order'] - 1
            newList = sorted(rpt_form_details['Review'], key=lambda  d: d['field_order']) 
            rpt_form_details['Review'] = newList

        #Modifying the boolean values to yes or no
        if 'Equipped for work' in rpt_form_details:
            for wc in rpt_form_details['Equipped for work'] :
                if wc['value'] == '1':
                    wc['value'] = wc['yes_value']
                else :
                    if wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '-1':
                        wc['value'] = 'N/A'
                    else:
                        wc['value'] = wc['value']

        for wc in result['rpt_vale_flha_critical_activity_requirements']:
            if wc['Value'] == '1':
                wc['Value'] = wc['yes_value']
            else :
                if wc['Value'] == '0':
                    wc['Value'] = wc['no_value'] 
                elif wc['Value'] == '-1':
                    wc['Value'] = 'N/A'
                else:
                    wc['Value'] = wc['Value']

        rpt_form_tasks = {}
        for row in result['rpt_vale_flha_tasks']:
            if row['original_section_name'] not in rpt_form_tasks:
                rpt_form_tasks[row['original_section_name']] = []
            rpt_form_tasks[row['original_section_name']].append(row)

        result['rpt_form_tasks'] = rpt_form_tasks

        rpt_critical_activity_req = {}
        for row in result['rpt_vale_flha_critical_activity_requirements']:
            if row['sub_section'] not in rpt_critical_activity_req:
                rpt_critical_activity_req[row['sub_section']] = []
            rpt_critical_activity_req[row['sub_section']].append(row)   
        result['rpt_critical_activity_req'] = rpt_critical_activity_req
        
        ignore_field_name = []
        if ('Ignore' or 'Ignorer' or 'Ignorar') in rpt_critical_activity_req:
            for name in rpt_critical_activity_req['Ignore']:
                if name['field_name'] not in rpt_critical_activity_req:
                    ignore_field_name.append(name['field_name'])
            del rpt_critical_activity_req['Ignore']

        for val in ignore_field_name:
            rpt_critical_activity_req[val] = []

        
        result['rpt_form_details'] = rpt_form_details
        
        return result
    