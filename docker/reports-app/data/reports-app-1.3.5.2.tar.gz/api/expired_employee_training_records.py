#Import important libraries for the report to load
from datetime import datetime, date, timedelta
import yaml
import helper as h
import pandas as pd

class Report:
	
    def __init__(self, args):

        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/expired_employee_training_records.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['filter'] = config['filter']
        result['required_args'] = config['required_args'] if config['required_args'] is not None else []        
        result['optional_args'] = config['optional_args'] if config['optional_args'] is not None else []
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args']})    
        result['args'] = dict(self.args)
        job_ids = self.args['job_ids'] if 'job_ids' in self.args and self.args['job_ids'] != '' else None
        display_inactive_per_ids=str(self.args['display_inactive_per_ids']) if 'display_inactive_per_ids' in self.args else 'False'
        display_inactive_job_ids=str(self.args['display_inactive_job_ids']) if 'display_inactive_job_ids' in self.args else 'False'


        #per_ids 
        per_ids=self.args['per_ids'] if 'per_ids' in self.args and self.args['per_ids'] != '' else None
        per_ids_list = per_ids.split(',') if per_ids is not None else []
        per_ids_data_name = {}            
        user_per_ids_data = result['filter_data']['optionalArgs']['per_ids']['field_values']
        if per_ids_list:
            per_ids_data_name = {each['value'] for each in user_per_ids_data if str(each['value']) in per_ids_list}
        else:
            if display_inactive_per_ids == 'False':
                per_ids_data_name = {each['value'] for each in user_per_ids_data if each['status_flag'] == 1}
            else:
                per_ids_data_name = {each['value'] for each in user_per_ids_data}
        
        per_ids = ','.join(map(str, per_ids_data_name))

        #job_ids 
        job_ids=self.args['job_ids'] if 'job_ids' in self.args and self.args['job_ids'] != '' else None

        ## Get the Report Title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [2033,self.lang,1], self.args)[0]['ltr_text']
        
        # get the Lables
        result['report_labels'] = {
                "employee_name_label" : h.execute_sp('get_translation_by_tag', [204, self.lang, 1], self.args)[0]['ltr_text'],
                "employee_number_label" : h.execute_sp('get_translation_by_tag', [190, self.lang, 1], self.args)[0]['ltr_text'],
                "training_code_label" : h.execute_sp('get_translation_by_tag', [2587, self.lang, 1], self.args)[0]['ltr_text'],
                "training_institution_label" : h.execute_sp('get_translation_by_tag', [2588, self.lang, 1], self.args)[0]['ltr_text'],
                "description_label" : h.execute_sp('get_translation_by_tag', [143, self.lang, 1], self.args)[0]['ltr_text'],
                "certification_date_label" : h.execute_sp('get_translation_by_tag', [1294, self.lang, 1], self.args)[0]['ltr_text'],
                "expiration_date_label" : h.execute_sp('get_translation_by_tag', [1295, self.lang, 1], self.args)[0]['ltr_text'],
                "no_expired_records_label" : h.execute_sp('get_translation_by_tag', [8872, self.lang, 1], self.args)[0]['ltr_text'],
                "value_label" : h.execute_sp('get_translation_by_tag', [1243, self.lang, 1], self.args)[0]['ltr_text']
                }
                
        #Checking if all the filter conditions are provided and handling the optional filter functionality
        optional_args = config['optional_args']
        required_args = config['required_args']
        sites = self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
        
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            if sites is not None:               
                allRecs=[]   
                if job_ids is not None:
                    allRecs = h.execute_sp('rpt_expired_employee_training_records', [per_ids, sites,job_ids, self.lang], self.args)
                else:
                    allRecs = h.execute_sp('rpt_expired_employee_training_records_no_job', [per_ids, sites, self.lang], self.args)
                if len(allRecs) > 0:
                    df = pd.DataFrame(allRecs)
                    temp =[]
                    allRecs = df.groupby('per_id')
                    for emp, data in allRecs:
                        temp.append(data.to_dict('records'))
                    allRecs = temp
                    result['rpt_expired_employee_training_records'] = temp

                for user in allRecs:
                    for rec in user:
                        rec['is_expired'] = False
                        rec['30day_expired'] = False
                        if rec['expiry_date']:
                            theDate = datetime.strptime(rec['expiry_date'], '%Y-%m-%d').date()
                            if theDate <= date.today():
                                rec['is_expired'] = True
                            if theDate > date.today() and theDate < date.today() + timedelta(days=30):
                                rec['30day_expired'] = True
                    
        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))
        
        return result
    