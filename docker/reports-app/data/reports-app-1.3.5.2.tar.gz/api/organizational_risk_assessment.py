#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/organizational_risk_assessment.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_ora_header','rpt_ora_hap','rpt_ora_general_actions','rpt_ora_reviewers','rpt_ora_event_category','rpt_ora_approved_by'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)
    
        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures
        #HAP section updates as per initial and follow up images
        result['rpt_hap_pictures_initial']=[]
        result['rpt_hap_pictures_followup']=[]

        for hap in result['rpt_ora_hap']:            
            hap['rpt_hap_pictures_initial'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'INITIAL', self.lang], self.args)
            hap['rpt_hap_pictures_followup'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'FOLLOWUP', self.lang], self.args)
            hap['HAP_complete'] = h.execute_sp('rpt_hazard_actions_list_completed', [hap['ID'], self.lang], self.args)

        #GA section updates as per initial and follow up images
        result['rpt_ora_general_action_attachment_by_id_initial'] = []
        result['rpt_ora_general_action_attachment_by_id_followup'] = []

        for gga in result['rpt_ora_general_actions']:
            result['rpt_ora_general_action_attachment_by_id_initial'].append(h.execute_sp('rpt_ora_general_action_attachment_by_id', [gga['sga_id'],imageUrl+'general_action/','INITIAL', self.lang], self.args))
            result['rpt_ora_general_action_attachment_by_id_followup'].append(h.execute_sp('rpt_ora_general_action_attachment_by_id', [gga['sga_id'],imageUrl+'general_action/','FOLLOWUP', self.lang], self.args))
            gga['GA_complete'] = h.execute_sp('rpt_get_general_actions_list_completed', [gga['sga_id'], self.lang], self.args)


        #Modifying the data structure to add the threats
        threats = {}
        rpt_ora_threats = result['rpt_ora_event_category']
        for step in rpt_ora_threats:
            if step['category_name'] not in threats:
                threats[step['category_name']] = []
            cm = h.execute_sp('rpt_ora_control_measures', [step['rmm_oev_id'], 'control_measures'], self.args)
            acm = h.execute_sp('rpt_ora_control_measures', [step['rmm_oev_id'], 'additional_control_measures'], self.args)
            step['control_measures'] = cm[0]['ControlMeasures']
            step['additional_control_measures'] = acm[0]['ControlMeasures']
            threats[step['category_name']].append(step)

        result['steps'] = threats

        result['rpt_ora_pra_bowtie_header']=h.execute_sp('rpt_ora_pra_bowtie_header', [formSubmissionId, 'ORA',self.lang], self.args)
        if len(result['rpt_ora_pra_bowtie_header']) > 0:
            result['rpt_bowtie_approvers']=h.execute_sp('rpt_bowtie_approvers', [result['rpt_ora_pra_bowtie_header'][0]["rmm_bow_id"], self.lang], self.args)
            result['rpt_bowtie_participants']=h.execute_sp('rpt_bowtie_participants', [result['rpt_ora_pra_bowtie_header'][0]["rmm_bow_id"]], self.args)
        
        result['rpt_get_ora_attachment_ora_id'] = h.execute_sp('rpt_get_ora_attachment_ora_id', [formSubmissionId, imageUrl, self.lang], self.args)

        result['rpt_get_ora_attachment_ora_id']  = h.file_extention_attachments(result['rpt_get_ora_attachment_ora_id'])
       
        return result
    