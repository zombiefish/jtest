#Import important libraries for the report to load
import yaml
import helper as h
import pandas as pd


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId):
        result = {}

        ## Load report-specific configuration
        with open('config/employees_by_site.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['header'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['filter'] = config['filter']
        result['required_args'] = config['required_args'] if config['required_args'] is not None else []
        result['optional_args'] = config['optional_args']
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args': config['optional_args']})
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [3462,self.lang,1], self.args)[0]['ltr_text']

        result['args'] = dict(self.args)
        lang=self.lang

        # Check if user entered all the required parameters
        site_ids = str(self.args['site_ids']) if 'site_ids' in self.args and self.args['site_ids'] != '' else None
        optional_args = config['optional_args']
        display_inactive_site_ids=str(self.args['display_inactive_site_ids']) if 'display_inactive_site_ids' in self.args else 'False'

        #site_ids 
        site_ids=self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None

        result['rpt_employees_by_site_labels']={
            "Site_label": h.execute_sp('get_translation_by_tag', [828,self.lang,1], self.args)[0]['ltr_text'],
            "Role_label": h.execute_sp('get_translation_by_tag', [1245,self.lang,1], self.args)[0]['ltr_text'],
            "Name_label": h.execute_sp('get_translation_by_tag', [649,self.lang,1], self.args)[0]['ltr_text'],
            "Position_label": h.execute_sp('get_translation_by_tag', [1277,self.lang,1], self.args)[0]['ltr_text'],
            "Job_label": h.execute_sp('get_translation_by_tag', [617,self.lang,1], self.args)[0]['ltr_text'],
        }

        if 'apply' in result['args']:
        # Fetching data by employees and by site
            result['final_data'] = {}
            if site_ids is not None:
                result['rpt_employees_by_site'] = h.execute_sp('rpt_employees_by_site', [site_ids, self.lang], self.args)

                result['rpt_employees_by_site_all'] = h.execute_sp('rpt_employees_by_site_all', [self.lang], self.args)

            else:
                result['rpt_employees_by_site_all'] = h.execute_sp('rpt_employees_by_site_all', [self.lang], self.args)
            
                result['rpt_employees_by_site'] = result['rpt_employees_by_site_all']

            inactive_label = h.execute_sp('get_translation_by_tag', [9169,self.lang,1], self.args)[0]['ltr_text']

            # Creating an object for employees by site data
            if result['rpt_employees_by_site']:

                for data in result['rpt_employees_by_site']:
                    if data['site_enable_status'] == 0 and inactive_label not in data['Site']:
                        data['Site'] = data['Site'] + ' ' + inactive_label

                for data in result['rpt_employees_by_site_all']:
                    if data['site_enable_status'] == 0 and inactive_label not in data['Site']:
                        data['Site'] = data['Site'] + ' ' + inactive_label


                df_sites = pd.DataFrame(result['rpt_employees_by_site'])
                df_sites = df_sites.fillna('')
                sites_group = df_sites.groupby('Site')
                df_sites_all = pd.DataFrame(result['rpt_employees_by_site_all'])
                df_sites_all = df_sites_all.fillna('')
                persons_group = df_sites_all.groupby('per_id')

                for site_name, site_group in sites_group:
                    pers_group = site_group.groupby('per_id')
                    site_obj = {}
                    for per_name, per_group in pers_group:
                        per_obj = {"Roles":None,"Position": None,"data":None}
                        per_obj['data'] = persons_group.get_group(per_name).to_dict('records')
                        per_obj['Roles'] = persons_group.get_group(per_name)['Roles'].unique()[0]
                        per_obj['Position'] = persons_group.get_group(per_name)['Position_Name'].unique()[0]
                        site_obj[per_group['per_full_name'].unique()[0]] = per_obj
                    result['final_data'][site_name] = site_obj
                

        else:
            result['args']['missing_args'] = list(set(optional_args) - set(result['args']))
            result['final_data'] = None
            result['rpt_employees_by_site_labels'] = None

        return result
    