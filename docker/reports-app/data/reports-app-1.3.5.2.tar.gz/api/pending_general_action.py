#Import important libraries for the report to load
from datetime import datetime, date, timedelta
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId):
        result = {}

        ## Load report-specific configuration
        with open('config/pending_general_action.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata        
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['filter'] = config['filter']
        result['required_args'] = config['required_args']
        result['optional_args'] = config['optional_args']    
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args']})
        result['args'] = dict(self.args)

        # place the report title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [2094,self.lang,1], self.args)[0]['ltr_text']

        # Check if user entered all the required parameters and executing the main SP for data in line 42
        required_args = config['required_args']
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            start_date=self.args['start_date']      
            end_date=self.args['end_date']
            site_ids = self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None          
            by_who = self.args['by_who'] if 'by_who' in self.args and self.args['by_who'] != '' else None
            
            #site_ids 
            site_ids=self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            site_ids_list = site_ids.split(',') if site_ids is not None else []
            site_data_name = {}            
            user_site_data = result['filter_data']['optionalArgs']['site_ids']['field_values']
            if site_ids_list:
                site_data_name = {each['value'] for each in user_site_data if str(each['value']) in site_ids_list}
            else:
                site_data_name = {each['value'] for each in user_site_data}
            
            site_ids = ','.join(map(str, site_data_name))

            
            #by_who 
            by_who=self.args['by_who'] if 'by_who' in self.args and self.args['by_who'] != '' else None
            by_who_list = by_who.split(',') if by_who is not None else []
            by_who_data_name = {}            
            user_by_who_data = result['filter_data']['optionalArgs']['by_who']['field_values']
            if by_who_list:
                by_who_data_name = {each['value'] for each in user_by_who_data if str(each['value']) in by_who_list}
            else:
                by_who_data_name = {each['value'] for each in user_by_who_data}
            
            by_who = ','.join(map(str, by_who_data_name))


            result['rpt_pending_general_action'] = h.execute_sp('rpt_pending_general_action', [site_ids, start_date, end_date, by_who,  self.lang], self.args)

            inactive_label = h.execute_sp('get_translation_by_tag', [9169,self.lang,1], self.args)[0]['ltr_text']

            PGA = result['rpt_pending_general_action']
            for data in PGA:

                if data['status_flag'] == 0:
                    data['ID2___Action_By_Who'] = (data['ID2___Action_By_Who'] + ' ' + inactive_label)


            result['todays_date'] = datetime.today().strftime('%Y-%m-%d')

        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result
    