#Import important libraries for the report to load

import yaml
import helper as h
import pandas
import flask
import json

from api.training_matrix_by_employee import Report as employee_report
from api.training_matrix_by_job import Report as job_report

class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId = None):
        result = {}
        imageUrl = self.config['image_url']


        if 'report_selection' in self.args and (self.args['report_selection'] == '110'):
            return employee_report.get_report(self,formSubmissionId)

        elif 'report_selection' in self.args and (self.args['report_selection'] == '111'):
            return job_report.get_report(self,formSubmissionId)

         ## Load report-specific configuration
        
        with open('config/training_matrix_summary.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['required_args'] = config['required_args']
        result['optional_args'] = config['optional_args'] if config['optional_args'] is not None else []
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args'], 'report_slug':config['header']['slug']})        
        result['args'] = dict(self.args)
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [1187,self.lang,1], self.args)[0]['ltr_text']
       
        report_selection = result['args']['report_selection'] if 'report_selection' in result['args'] else ''
        
        ## Training Matrix by Employee
        result['filtered_report_title_by_emp'] = h.execute_sp('get_translation_by_tag', [9482,self.lang,1], self.args)[0]['ltr_text']
        ## Training Matrix by job
        result['filtered_report_title_by_role'] = h.execute_sp('get_translation_by_tag', [9483,self.lang,1], self.args)[0]['ltr_text']
        
        required_args = config['required_args']
        return result
        

   