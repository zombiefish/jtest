#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}

        ## Load report-specific configuration
        with open('config/lineup_draft.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_lineup_header_draft_by_id'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)
        
        external_distribution = h.execute_sp('rpt_lineup_external_distribution', [str(result['rpt_lineup_header_draft_by_id'][0]['ID'])], self.args)
        
        external_list = ''
        for person in external_distribution:
            if person['distributors'] is not None:
                external_list += person['distributors']
        
        result['distributors'] = external_list

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)

        
        ## Load parameterized Stored Procedures
        if len(result['rpt_lineup_header_draft_by_id']) > 0:            
            result['rpt_lineup_details'] = []
            result['rpt_lineup_jra_details'] = []
            
            for l in result['rpt_lineup_header_draft_by_id']:        
                # convert levels
                result['rpt_level_hazards_for_lineup'] = []
                wpl_list= l['WorkplaceLevel'].split(',') if l['WorkplaceLevel'] else l['WorkplaceLevel']
                levels_list =[]
                
                if wpl_list is not None:
                    for level in wpl_list:                        
                        levels_list.append(h.execute_sp('rpt_lineup_levels', [level, self.lang], self.args))
                        haz = (h.execute_sp('rpt_level_hazards_for_lineup', [l['Site'], level.strip(), l['CreatedDate'], self.lang], self.args))
                        if(len(haz) > 0 ):
                            result['rpt_level_hazards_for_lineup'].append(haz)

                
                workLevel = l['WorkplaceLevel']      
                result['rpt_lineup_details'].append(h.execute_sp('rpt_lineup_draft_detail', [formSubmissionId, l['per_id'], l['WorkplaceName'], l['WorkerId'], l['WorkplaceID'], self.lang], self.args))
                result['rpt_lineup_jra_details'].append(h.execute_sp('rpt_lineup_jra_details', [l['ID'], l['WorkplaceID'], self.lang], self.args))
                
                # Build lineup equipments object
                equipments = {}
                rpt_lineup_details = [item for sublist in result['rpt_lineup_details'] for item in sublist]
                for lineup in rpt_lineup_details:
                    full_name = lineup['per_last_name'] + ', ' + lineup['WorkerName'] + ', ' + str(lineup['WorkplaceID']) + ', ' + str(lineup['WorkerID'])
                    if full_name not in equipments:
                        equipments[full_name] = []
                    equipments[full_name].append({
                        'EquipmentDescription': lineup['EquipmentDescription'],
                        'equipment_type': lineup['equipment_type'],
                        'EquipmentLocation': lineup['EquipmentLocation'],
                        'EquipmentNumber': lineup['EquipmentNumber'],
                        'EquipmentType': lineup['EquipmentType'],
                        'WorkerName': full_name
                    })

                #Building hazads objects
                l['hazards'] = []
                hazards={}
                workLevel = l['WorkplaceLevel']
                hazards[workLevel] = []
                rpt_level_hazards_for_lineup = [item for sublist in result['rpt_level_hazards_for_lineup'] for item in sublist]
                for hap in rpt_level_hazards_for_lineup:
                    hazards[workLevel].append({
                        'lineup_details_label': hap['lineup_details_label'],
                        'hazard_description_label': hap['reference_JRA_label'],
                        'hapDescription': hap['hapDescription'],
                        'Workplace': hap['Workplace']
                    })
                l['hazards'] = hazards[workLevel]

        if 'rpt_lineup_jra_details' in result:
            rpt_lineup_jra_details = result['rpt_lineup_jra_details']
            rpt_lineup_header_draft_by_id = result['rpt_lineup_header_draft_by_id']
            lineups = {}
            lineups['lineups'] = []
            for i, lineup in enumerate(rpt_lineup_jra_details):
                
                # Add Steps
                steps = {}
                for step in lineup:
                    if step['rmm_jsc_step'] not in steps:
                        steps[step['rmm_jsc_step']] = []
                    steps[step['rmm_jsc_step']].append({
                        'Threat': step['rmm_jth_threat'],
                        'Controls': step['Controls'],
                        'Step': step['rmm_jsc_step']
                    })

                # Add the lineup metadata to the steps obj
                header = rpt_lineup_header_draft_by_id[i]
                if header['WorkerName'] is not None:
                    full_name = header['WorkerName'] + ', ' + str(header['WorkplaceID'])
                    
                    if full_name in equipments:
                        header['Equipments'] = equipments[full_name]

                    # Build the lineups object            
                    lineups['lineups'].append({
                        'steps': steps,
                        'header': header
                    })
                else:
                    header['WorkerName'] = ''
                    full_name = header['WorkerName'] + ', ' + str(header['WorkplaceID'])
                    
                    if full_name in equipments:
                        header['Equipments'] = equipments[full_name]

                    # Build the lineups object            
                    lineups['lineups'].append({
                        'steps': steps,
                        'header': header
                    })

            if len(lineups['lineups']) > 0:
                result['lineups_header'] = lineups['lineups'][0]['header']


            counter = 0
            counter2 = 0
            result['threats'] = []
            result['threats'].append([])

            workplaces2 = {}
            for item in lineups['lineups']:
                if item['header']['WorkplaceID'] not in workplaces2:
                    workplaces2[item['header']['WorkplaceID']] = {}   
                    item_keys = list(item.keys())
                    if 'steps' in item_keys:
                        for key in item['steps']:
                            previous_threat = ""
                            for line in item['steps'][key]:
                                if previous_threat != line['Threat']:
                                    previous_threat = line['Threat']
                                    result['threats'].append([])
                                    counter2 = counter2 + 1
                                    result['threats'][counter2].append(line)

                                    # increment counter to target new list
                                else:

                                    # append data to the currently targeted list
                                    result['threats'][counter2].append(line)

                counter = counter + 1

            if len(result['threats'][0]) == 0:
                del(result['threats'][0])


            result['equipments_list'] = []
            for item in equipments.keys():
                result['equipments_list'].append(equipments[item])




            workplaces = {}
            for lineup in lineups['lineups']:
                if lineup['header']['WorkplaceID'] not in workplaces:
                    workplaces[lineup['header']['WorkplaceID']] = {}   
                    workplaces[lineup['header']['WorkplaceID']]['steps'] = lineup['steps']
                    workplaces[lineup['header']['WorkplaceID']]['header'] = []            
                workplaces[lineup['header']['WorkplaceID']]['header'].append(lineup['header'])

            result['workplaces'] = workplaces

        return result
    