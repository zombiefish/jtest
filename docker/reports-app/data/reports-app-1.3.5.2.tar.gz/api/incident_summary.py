#Import important libraries for the report to load
import yaml
import helper as h
import pandas as pd
import datetime

class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId):

        def daterange(date1, date2):
            for n in range(int ((date2 - date1).days)+1):
                yield date1 + datetime.timedelta(n)

        def breakupHours(work_hour_log_df):
            newHours = []
            finalHours = pd.DataFrame()
            if work_hour_log_df.empty:
                finalHours = pd.DataFrame()
            else:
                for index, row in work_hour_log_df.iterrows():
                    start_dt = datetime.datetime.strptime(str(row['whl_start_date']), '%Y-%m-%d %H:%M:%S').date()
                    end_dt = datetime.datetime.strptime(str(row['whl_end_date']), '%Y-%m-%d %H:%M:%S').date()
                    numDays = (end_dt - start_dt).days
                    dayHours = row['whl_hours_worked'] / numDays
                    for dt in daterange(start_dt, end_dt):
                        newHours.append({
                            "whl_hours_worked": dayHours,
                            "whl_start_date": dt.strftime("%Y-%m-%d"),
                            "whl_end_date": dt.strftime("%Y-%m-%d")
                        })
                finalHours = pd.DataFrame(newHours).groupby(['whl_start_date','whl_end_date'])['whl_hours_worked'].sum().reset_index()
            return finalHours

        result = {}

        ## Load report-specific configuration
        with open('config/incident_summary.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata        
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['filter'] = config['filter']
        result['required_args'] = config['required_args']        
        result['optional_args'] = config['optional_args']
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang,'optional_args':config['optional_args']})
        result['args'] = dict(self.args)

        # place the report title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [2034,self.lang,1], self.args)[0]['ltr_text']
        result['filtered_report_title'] = result['filtered_report_title'].replace('Report', '')
        result['filtered_report_title'] = result['filtered_report_title'].replace('Rapport ', '').capitalize()


        # Check if user entered all the required parameters and executing the main SP at line 44
        required_args = config['required_args']
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            start_date=self.args['start_date']       
            end_date=self.args['end_date']
            site_ids = self.args['site_ids']  if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            job_ids=self.args['job_ids'] if 'job_ids' in self.args and self.args['job_ids'] != '' else None
            
            #job_ids 
            job_ids=self.args['job_ids'] if 'job_ids' in self.args and self.args['job_ids'] != '' else None
            job_ids_list = job_ids.split(',') if job_ids is not None else []
            job_data_name = {}            
            user_job_data = result['filter_data']['optionalArgs']['job_ids']['field_values']
            if job_ids_list:
                job_data_name = {each['value'] for each in user_job_data if str(each['value']) in job_ids_list}
            else:
                job_data_name = {each['value'] for each in user_job_data}
            
            job_ids = ','.join(map(str, job_data_name))

            

            result['rpt_incident_summary'] = h.execute_sp('rpt_incident_summary', [site_ids, start_date, end_date, self.lang, job_ids], self.args)

            if result['rpt_incident_summary']:
                # labels
                result['charts'] = True
                result['labels'] = {key:value for key, value in result['rpt_incident_summary'][0].items() if key.endswith('_label')}
                result['labels']['stmt_label'] = h.execute_sp('get_translation_by_tag', [1004,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['ha_label'] = h.execute_sp('get_translation_by_tag', [1999,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['ga_label'] = h.execute_sp('get_translation_by_tag', [1039,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['days_open_label'] = h.execute_sp('get_translation_by_tag', [8912,self.lang,1], self.args)[0]['ltr_text']
                
                result['labels']['IA_label'] = h.execute_sp('get_translation_by_tag', [2767,self.lang,1], self.args)[0]['ltr_text']
                
                result['labels']['type_label'] = h.execute_sp('get_translation_by_tag', [1054,self.lang,1], self.args)[0]['ltr_text']

                #TRIFR and TRIR Labels
                result['labels']['date_range_label'] = h.execute_sp('get_translation_by_tag', [1133,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['recordable_injuries_label'] = h.execute_sp('get_translation_by_tag', [2738,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['recordable_incidents_label'] = h.execute_sp('get_translation_by_tag', [2739,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['past_twelve_months_label'] = h.execute_sp('get_translation_by_tag', [2737,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['year_to_date_label'] = h.execute_sp('get_translation_by_tag', [2735,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['incident_analysis_type_label'] = h.execute_sp('get_translation_by_tag', [9136,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['incident_type_label'] = h.execute_sp('get_translation_by_tag', [566,self.lang,1], self.args)[0]['ltr_text']
            else:   
                result['charts'] = False        
                result['labels'] = {}               
                result['labels']['stmt_label'] = h.execute_sp('get_translation_by_tag', [1004,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['ha_label'] = h.execute_sp('get_translation_by_tag', [1999,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['ga_label'] = h.execute_sp('get_translation_by_tag', [1039,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['days_open_label'] = h.execute_sp('get_translation_by_tag', [8912,self.lang,1], self.args)[0]['ltr_text']

                #TRIFR and TRIR Labels
                result['labels']['date_range_label'] = h.execute_sp('get_translation_by_tag', [1133,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['recordable_injuries_label'] = h.execute_sp('get_translation_by_tag', [2738,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['recordable_incidents_label'] = h.execute_sp('get_translation_by_tag', [2739,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['past_twelve_months_label'] = h.execute_sp('get_translation_by_tag', [2737,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['year_to_date_label'] = h.execute_sp('get_translation_by_tag', [2735,self.lang,1], self.args)[0]['ltr_text']
                
                result['labels']['IA_label'] = h.execute_sp('get_translation_by_tag', [2767,self.lang,1], self.args)[0]['ltr_text']
                
                result['labels']['type_label'] = h.execute_sp('get_translation_by_tag', [1054,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['incident_analysis_type_label'] = h.execute_sp('get_translation_by_tag', [9136,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['incident_type_label'] = h.execute_sp('get_translation_by_tag', [566,self.lang,1], self.args)[0]['ltr_text']
                result['labels']['level_of_detail'] = h.execute_sp('get_translation_by_tag', [2805,self.lang,1], self.args)[0]['ltr_text']
           
            pd.set_option('display.max_rows', None)
            # Getting TRIFR details
            # ----------------------------------------------------------------------------------------------
            trir_incident_track_type = 'inc_type'
            rii_type = 2

            # Get Track option for TRIFR and TRIR charts
            
            track_options = h.execute_sql("""
                        select sys_setting_name, sys_setting_value from system_settings where sys_setting_type = 7 and sys_enable = 1;
                """)
            track_options = {item['sys_setting_name'] : bool(item['sys_setting_value']) for item in track_options['result']}
            if track_options['TRACK TRIFR'] and track_options['TRACK TRIR']:
                result['labels']['level_of_detail'] = h.execute_sp('get_translation_by_tag', [2803,self.lang,1], self.args)[0]['ltr_text']
            elif  track_options['TRACK TRIFR'] and not track_options['TRACK TRIR']:
                result['labels']['level_of_detail'] = h.execute_sp('get_translation_by_tag', [2804,self.lang,1], self.args)[0]['ltr_text']
            elif not track_options['TRACK TRIFR'] and track_options['TRACK TRIR']:
                result['labels']['level_of_detail'] = h.execute_sp('get_translation_by_tag', [2805,self.lang,1], self.args)[0]['ltr_text']
            else:
                result['charts'] = False

            # Raw query to get the incident data
            last_injury_procedure = 'get_trifr_trir_analytics_data'

            # Get the metric for trifr
            trifr_system_setting = h.execute_sql("""
                                    select sys_setting_value from system_settings where sys_setting_type = 1 and sys_enable = 1;
                            """)
            trifr_system_setting = trifr_system_setting['result'][0]
           
            # Get the metric for trir
            trir_system_setting = h.execute_sql("""
                                select sys_setting_value from system_settings where sys_setting_type = 2 and sys_enable = 1;
                        """)
            trir_system_setting = trir_system_setting['result'][0]
            
            # Get the TRIR Incident Option
            trir_incident_option = h.execute_sql("""
                    select sys_setting_value from system_settings where sys_setting_type = 6 and sys_enable = 1;
            """)
            trir_incident_option = trir_incident_option['result'][0]

            if trir_incident_option['sys_setting_value'] == 2:
                trir_incident_track_type = 'inc_type'
                rii_type = 2
            elif trir_incident_option['sys_setting_value']  == 3:
                trir_incident_track_type = 'inc_class'
                rii_type = 3

            # Execute the raw query for dataframe
            rows = h.execute_sql(f"call {last_injury_procedure}")
            df = pd.DataFrame(rows['result']).fillna(0)

            if len(rows['result']) > 0:
                df['rca_type_and_class_ids'] = df['rca_type_and_class_ids'].astype(int)
                df['incident_type_and_class_ids'] = df['incident_type_and_class_ids'].astype(int)

                # Get the rld_id for trifr
                recordable_incident_injury = h.execute_sql("""
                        select rii_rld_id from recordable_incident_injury where rii_type = 1 and rii_enable = 1;
                """)
                recordable_incident_injury = [d['rii_rld_id'] for d in recordable_incident_injury['result']]

                # Get the rld_id for trir
                recordable_incident = h.execute_sql(f"""
                        select rii_rld_id from recordable_incident_injury where rii_type = {rii_type} and rii_enable = 1;
                """)
                recordable_incident = [d['rii_rld_id'] for d in recordable_incident['result']]
                
                # Get the data work hours log
                hours_date = datetime.datetime.now() - datetime.timedelta(days=365)

                get_work_hours_log = h.execute_sql(f"""
                        select whl_hours_worked, whl_start_date, whl_end_date from work_hours_log where whl_start_date > '{hours_date}' and whl_enable = 1;
                """)

                # Creating dataframe for work hours log
                work_hour_log_df = pd.DataFrame(get_work_hours_log['result'])
                
                work_hour_log_df = breakupHours(work_hour_log_df)
                
                # Create the object for chart points
                now1 = str(datetime.datetime.now().year) + '-01-01'

                past_year_date = datetime.datetime.now() - datetime.timedelta(days=365)
                past_year_date = str(past_year_date)[:10]

                today = datetime.datetime.now()
                today = str(today)[:10]
                aDate = datetime.datetime.strptime(now1, "%Y-%m-%d")
                today1 = datetime.datetime.strptime(str(today), "%Y-%m-%d")
                threeWeeks = datetime.timedelta(weeks=1)
                final_weeks = abs(today1 - aDate).days // 7
                final_weeks_past_year = 52

                trifr_ytd = []
                trifr_past_year = []

                for w in range(1, final_weeks + 1):
                    one_week = datetime.timedelta(weeks=w)
                    trifr_ytd.append(
                        {
                            "start_date": now1,
                            "end_date": str(aDate + one_week)[:10],
                            "trifr": 5.5,
                            "trir": 3.5
                        }
                    )

                # Adding today's date when the last end date in the list is not today
                try:
                    if trifr_ytd[-1]['end_date'] != today:
                        trifr_ytd.append(
                            {
                                "start_date": now1,
                                "end_date": today,
                                "trifr": 5.5,
                                "trir": 3.5
                            }
                        )
                except:
                    trifr_ytd.append(
                        {
                            "start_date": now1,
                            "end_date": today,
                            "trifr": 5.5,
                            "trir": 3.5
                        }
                    )

                for w in range(1, final_weeks_past_year + 1):
                    one_week = datetime.timedelta(weeks=w)
                    trifr_past_year.append(
                        {
                            "start_date": past_year_date,
                            "end_date": str(hours_date + one_week)[:10],
                            "trifr": 5.5,
                            "trir": 3.5
                        }
                    )

                # Adding today's date when the last end date in the list is not today
                if trifr_past_year[-1]['end_date'] != today:
                    trifr_past_year.append(
                        {
                            "start_date": past_year_date,
                            "end_date": today,
                            "trifr": 5.5,
                            "trir": 3.5
                        }
                    )

            def calculate_trifr_trir(start_date, end_date, metric=None, incident_value=None, incident_track_type = 'inc_type'):
                trifr_trir_rca_query = df.query('rca_type_and_class_ids in @incident_value and incident_date >=@start_date and incident_date <= @end_date and incident_track_type == @incident_track_type', inplace=False)
                trifr_trir_total = len(trifr_trir_rca_query)
                trifr_trir_without_rca_query = df.query('rca_type_and_class_ids == 0 and incident_date >=@start_date and incident_date <= @end_date and incident_track_type == @incident_track_type', inplace=False)
                
                if not trifr_trir_without_rca_query.empty:
                    trifr_trir_preliminary_query = trifr_trir_without_rca_query.query('incident_type_and_class_ids in @incident_value and incident_date >=@start_date and incident_date <= @end_date and incident_track_type == @incident_track_type', inplace=False)
                    trifr_trir_total += len(trifr_trir_preliminary_query)

                trifr_trir_final_number = 0
                total_hours = 0
                if not work_hour_log_df.empty:
                    # Included whl_end_date in the condition to get the number of hours worked between the date range
                    work_hours = work_hour_log_df.query('whl_start_date >= @start_date and whl_end_date<=@end_date')
                    total_hours = work_hours['whl_hours_worked'].sum()
                # Added the below condition to avoid Division by zero error
                if total_hours>0:
                    trifr_trir_final_number = round(trifr_trir_total * metric['sys_setting_value'] / total_hours, 2)
                return trifr_trir_final_number
            

            
            
            # Create the dataframe for charts point trifr_ytd
            date_range_df = pd.DataFrame(trifr_ytd)
            date_range_df['trifr'] = date_range_df.apply(lambda x: calculate_trifr_trir(x.start_date, x.end_date, trifr_system_setting, recordable_incident_injury, 'inc_type'), axis=1)
            date_range_df['trir'] = date_range_df.apply(lambda x: calculate_trifr_trir(x.start_date, x.end_date, trir_system_setting, recordable_incident, trir_incident_track_type), axis=1)

            # Create the dataframe for charts point past year
            date_range_past_year = pd.DataFrame(trifr_past_year)

            date_range_past_year['trifr'] = date_range_past_year.apply(lambda x: calculate_trifr_trir(x.start_date, x.end_date, trifr_system_setting, recordable_incident_injury, 'inc_type'), axis=1)
            date_range_past_year['trir'] = date_range_past_year.apply(lambda x: calculate_trifr_trir(x.start_date, x.end_date, trir_system_setting, recordable_incident, trir_incident_track_type), axis=1)

            response_plotly_json = []
            response_plotly_json_past_year = []
            response_plotly_json.append({
                "dates": date_range_df['end_date'].to_list(),
                "y_axis_trifr": date_range_df['trifr'].astype(str).to_list() if track_options['TRACK TRIFR'] else [],
                "y_axis_trir": date_range_df['trir'].astype(str).to_list() if track_options['TRACK TRIR'] else [],

            })

            response_plotly_json_past_year.append({
                "dates": date_range_past_year['end_date'].to_list(),
                "y_axis_trifr": date_range_past_year['trifr'].astype(str).to_list() if track_options['TRACK TRIFR'] else [],
                "y_axis_trir": date_range_past_year['trir'].astype(str).to_list() if track_options['TRACK TRIR'] else [],
            })

            result['response_plotly_json'] = response_plotly_json
            result['response_plotly_json_past_year'] = response_plotly_json_past_year

        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result
    