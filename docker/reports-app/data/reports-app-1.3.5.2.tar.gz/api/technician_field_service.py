#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/technician_field_service.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_form_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id', 'rpt_hazard_actions','rpt_form_details_distribution','rpt_form_reviewers','rpt_technician_field_service_services','rpt_technician_field_service_totals'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)
    
        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures
        h.get_hazard_actions(result['rpt_hazard_actions'], imageUrl, self.args, self.lang) 
        h.get_general_actions(result['rpt_get_general_action_by_id'], imageUrl, self.args, self.lang)
        h.get_positive_recognitions(result['rpt_positive_recognition'], imageUrl, self.args, self.lang)

        for wc in result['rpt_form_details']:
            if wc['value'] is not None:
                if ('.jpg' or '.png') in wc['value']:
                    wc['value'] = imageUrl + wc['value']
            if wc['original_field_name'] == 'Position Details':
                wc['value'] = wc['translated_value2']

        #Updating this section to be able to key on original section name         
        rpt_form_details = {}
        for row in result['rpt_form_details']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)

        for service in result['rpt_technician_field_service_services']:
            picLoc = service['images_field_key']
            service['Images'] = []
            for wc in rpt_form_details['Service Summary']:
                if wc['field_type'] == 'MultiPhotoPicker' and picLoc == wc['field_key']:
                        service['Images'].append(wc)

        result['rpt_form_details'] = rpt_form_details
        return result
    