
#%%
# Using this file for getting Client Status Dashboard data. Do not use this file for any other purpose.
from sqlalchemy import create_engine, text
from decimal import Decimal
import pymysql, yaml, datetime, requests, json, urllib, random, os

# Connect to the database
def execute_sql(query):
    with open('credentials.yaml', 'r') as f:
        cred = yaml.safe_load(f)        
        cred = cred[cred['active']]

    engine = create_engine(f"mysql+pymysql://{cred['db_user']}:{cred['db_password']}@{cred['db_server']}/{cred['db_name']}")
    con = engine.connect()
    result = con.execute(text(query))
    sqlResult = result.fetchall()
    if isinstance(sqlResult, tuple):
        sqlResult = list(sqlResult)

    for result in sqlResult:
        if isinstance(result, dict):
            for res in result.keys():                 
                if isinstance(result[res], datetime.datetime):
                    if 'date' in res or 'Date' in res:
                        result[res] = result[res].strftime('%Y-%m-%d')                        
                    else:
                        result[res] = result[res].strftime('%Y-%m-%d %H:%M:%S')
                if isinstance(result[res], (bytes, bytearray)):
                    result[res] = result[res].decode('utf-8')
                if isinstance(result[res], Decimal):
                    result[res] = float(result[res])
                if isinstance(result[res], datetime.date): 
                    result[res] = result[res].strftime('%Y-%m-%d')   
    con.close()
    return {'result': [dict(row) for row in sqlResult]}

# Run the csd_query
def get_csd_data(args=None):    
    # Check token    
    if args and ('token' in args):
        token = args['token']
        if token == 'VF.OFv7;HQuf1R*w:6]=FZg*F{i*6w':
            csd_query = '''
                WITH t1 AS (
                SELECT
                `auth_user_sofvie`.`is_staff` AS `is_staff`,
                `employee`.`emp_id` AS `emp_id`,  
                `auth_user_sofvie`.`email` AS `email`,
                CONCAT(`person`.`per_last_name`, ', ', `person`.`per_first_name`) AS `per_full_name`,
                `auth_user_sofvie`.`is_active` AS `is_active`
                FROM ((`person`
                LEFT JOIN `employee`
                    ON (`person`.`per_id` = `employee`.`emp_per_id`))
                LEFT JOIN `auth_user_sofvie`
                    ON (`person`.`per_id` = `auth_user_sofvie`.`user_per_id`))
                )
                SELECT 
                    '$CLIENT_NAME' as client_name,
                    '$CLIENT_DB' as client_db,
                    emp_id,    
                    per_full_name,
                    is_active,
                    email
                FROM t1
                WHERE is_staff = 0 AND email NOT IN ('support@sofvie.com', 'master@sofvie.com')
                '''
            csd_data = None    
            if 'client_meta' in args:
                args['client_meta'] = args['client_meta']
                csd_query = csd_query.replace('$CLIENT_NAME', args['client_meta']['client_name'])
                csd_query = csd_query.replace('$CLIENT_DB', args['client_meta']['client_db'])        
            csd_data = execute_sql(csd_query)
        else:
            csd_data = {'error': 'Invalid token'}
    else:
        csd_data = {'error': 'No token provided'}
    
    # Return the result in JSON
    return {
        'data': csd_data
    }
