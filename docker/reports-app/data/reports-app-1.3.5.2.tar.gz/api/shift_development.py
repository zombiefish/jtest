#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/shift_development.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_form_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id', 'rpt_hazard_actions','rpt_form_details_distribution','rpt_form_reviewers'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)
    
        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures
        h.get_hazard_actions(result['rpt_hazard_actions'], imageUrl, self.args, self.lang) 
        h.get_general_actions(result['rpt_get_general_action_by_id'], imageUrl, self.args, self.lang)
        h.get_positive_recognitions(result['rpt_positive_recognition'], imageUrl, self.args, self.lang)

        for wc in result['rpt_form_details']:
            if wc['value'] is not None:
                if ('.jpg' or '.png') in wc['value']:
                    wc['value'] = imageUrl + wc['value']
            if wc['original_field_name'] == 'Position Details':
                wc['value'] = wc['translated_value2']

        #Updating this section to be able to key on original section name         
        rpt_form_details = {}
        for row in result['rpt_form_details']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)

        if 'Sub Header' in rpt_form_details:
            for wc in rpt_form_details['Sub Header']:
                if wc['field_key'] == 'shift':
                    wc['value'] = wc['translated_value']

        result['rpt_form_details'] = rpt_form_details

        #Modifying the data structure as per the equipments as keys
        equipment1 = ['equipment_group_a','equipment_group_a_location','equipment_group_a_details']
        equipment2 = ['equipment_group_b','equipment_group_b_location','equipment_group_b_details']
        equipment3 = ['equipment_group_c','equipment_group_c_location','equipment_group_c_details']
        equipment4 = ['equipment_group_d','equipment_group_d_location','equipment_group_d_details']
        equipment5 = ['equipment_group_e','equipment_group_e_location','equipment_group_e_details']
        equipment6 = ['equipment_group_f','equipment_group_f_location','equipment_group_f_details']
        equipment7 = ['equipment_group_g','equipment_group_g_location','equipment_group_g_details']
        equipment8 = ['equipment_group_h','equipment_group_h_location','equipment_group_h_details']
        equipment9 = ['equipment_group_i','equipment_group_i_location','equipment_group_i_details']
        equipment10 = ['equipment_group_j','equipment_group_j_location','equipment_group_j_details']
        equipment11 = ['equipment_group_k','equipment_group_k_location','equipment_group_k_details']
        equipment12 = ['equipment_group_l','equipment_group_l_location','equipment_group_l_details']
        equipment13 = ['equipment_group_m','equipment_group_m_location','equipment_group_m_details']
        equipment14 = ['equipment_group_n','equipment_group_n_location','equipment_group_n_details']
        equipment15 = ['equipment_group_o','equipment_group_o_location','equipment_group_o_details']
        result['work_equipments1'] = []
        result['work_equipments2'] = []
        result['work_equipments3'] = []
        result['work_equipments4'] = []
        result['work_equipments5'] = []
        result['work_equipments6'] = []
        result['work_equipments7'] = []
        result['work_equipments8'] = []
        result['work_equipments9'] = []
        result['work_equipments10'] = []
        result['work_equipments11'] = []
        result['work_equipments12'] = []
        result['work_equipments13'] = []
        result['work_equipments14'] = []
        result['work_equipments15'] = []

        if 'Equipment Summary' in rpt_form_details:
            for equip in rpt_form_details['Equipment Summary']:

                if equip['original_field_name'] == 'Location':
                    equip['value'] = equip['translated_value2']            
                if equip['field_key'] in equipment1:
                    result['work_equipments1'].append(equip)
                if equip['field_key'] in equipment2:
                    result['work_equipments2'].append(equip)
                if equip['field_key'] in equipment3:
                    result['work_equipments3'].append(equip)
                if equip['field_key'] in equipment4:
                    result['work_equipments4'].append(equip)
                if equip['field_key'] in equipment5:
                    result['work_equipments5'].append(equip)
                if equip['field_key'] in equipment6:
                    result['work_equipments6'].append(equip)
                if equip['field_key'] in equipment7:
                    result['work_equipments7'].append(equip)
                if equip['field_key'] in equipment8:
                    result['work_equipments8'].append(equip)
                if equip['field_key'] in equipment9:
                    result['work_equipments9'].append(equip)
                if equip['field_key'] in equipment10:
                    result['work_equipments10'].append(equip)
                if equip['field_key'] in equipment11:
                    result['work_equipments11'].append(equip)
                if equip['field_key'] in equipment12:
                    result['work_equipments12'].append(equip)
                if equip['field_key'] in equipment13:
                    result['work_equipments13'].append(equip)
                if equip['field_key'] in equipment14:
                    result['work_equipments14'].append(equip)
                if equip['field_key'] in equipment15:
                    result['work_equipments15'].append(equip)
                

        return result
    