#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/job_risk_assessment.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_jra_header','rpt_jra_hap','rpt_jra_general_actions','rpt_jra_reviewers','rpt_jra_threats','rpt_jra_approved_by'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures
        #HAP section updates as per initial and follow up images
        result['rpt_hap_pictures_initial']=[]
        result['rpt_hap_pictures_followup']=[]
        
        for hap in result['rpt_jra_hap']:            
            hap['rpt_hap_pictures_initial'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'INITIAL', self.lang], self.args)
            hap['rpt_hap_pictures_followup'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'FOLLOWUP', self.lang], self.args)
            hap['HAP_complete'] = h.execute_sp('rpt_hazard_actions_list_completed', [hap['ID'], self.lang], self.args)

        #GA section updates as per initial and follow up images
        result['rpt_jra_general_action_attachment_by_id_initial'] = []
        result['rpt_jra_general_action_attachment_by_id_followup'] = []

        for gga in result['rpt_jra_general_actions']:
            result['rpt_jra_general_action_attachment_by_id_initial'].append(h.execute_sp('rpt_ora_general_action_attachment_by_id', [gga['sga_id'],imageUrl+'general_action/','INITIAL', self.lang], self.args))
            result['rpt_jra_general_action_attachment_by_id_followup'].append(h.execute_sp('rpt_ora_general_action_attachment_by_id', [gga['sga_id'],imageUrl+'general_action/','FOLLOWUP', self.lang], self.args))
            gga['GA_complete'] = h.execute_sp('rpt_get_general_actions_list_completed', [gga['sga_id'], self.lang], self.args)
 
 
        threats = {}
        rpt_jra_threats = result['rpt_jra_threats']
        for step in rpt_jra_threats:
            if step['rmm_jsc_step'] not in threats:
                threats[step['rmm_jsc_step']] = []
            cm = h.execute_sp('rpt_jra_control_measures', [step['rmm_jth_id'], 'control_measures'], self.args)
            acm = h.execute_sp('rpt_jra_control_measures', [step['rmm_jth_id'], 'additional_control_measures'], self.args)
            step['control_measures'] = cm[0]['ControlMeasures']
            step['additional_control_measures'] = acm[0]['ControlMeasures']
            threats[step['rmm_jsc_step']].append(step)

        #Fetching attachment details
        result['rpt_get_jra_attachment_jra_id'] = h.execute_sp('rpt_get_jra_attachment_jra_id', [formSubmissionId, imageUrl, self.lang], self.args)
        result['rpt_get_jra_attachment_jra_id'] = h.file_extention_attachments(result['rpt_get_jra_attachment_jra_id'])
       

        result['steps'] = threats
         
        return result
    