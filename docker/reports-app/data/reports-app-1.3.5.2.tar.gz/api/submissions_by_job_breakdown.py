#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId = None):
        result = {}

        ## Load report-specific configuration
        with open('config/submissions_breakdown_summary.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        
        result['header'] = config['header']
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['logo'] = h.get_logo()
        result['required_args'] = config['required_args'] #required args from yaml file    
        result['optional_args'] = config['optional_args']
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args'], 'report_slug':config['header']['slug']})
        result['args'] = dict(self.args)
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [1962,self.lang, 1], self.args)[0]['ltr_text']
        result['labels'] = []
      

        # Check if user entered all the required parameters and execute the SP at line 47.
        required_args = config['required_args']
        result['rpt_submissions_by_breakdown_date'] = []
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            start_date=self.args['start_date']        
            end_date=self.args['end_date']
            
            #job_ids 
            job_ids=self.args['job_ids'] if 'job_ids' in self.args and self.args['job_ids'] != '' else None

            result['chart_labels'] = {
                "jobs": h.execute_sp('get_translation_by_tag', [1760,self.lang,1], self.args)[0]['ltr_text'],
                "forms": h.execute_sp('get_translation_by_tag', [8852,self.lang,1], self.args)[0]['ltr_text'],
                "submissions": h.execute_sp('get_translation_by_tag', [1110, self.lang,1], self.args)[0]['ltr_text'],
                "nochart" : h.execute_sp('get_translation_by_tag', [8870, self.lang, 1],self.args)[0]['ltr_text']
            }

            result['report_labels'] = {
            "count_label" : h.execute_sp('get_translation_by_tag', [2047, self.lang, 1], self.args)[0]['ltr_text'],
            "daily_label" : h.execute_sp('get_translation_by_tag', [2888, self.lang, 1], self.args)[0]['ltr_text'],
            "weekly_label" : h.execute_sp('get_translation_by_tag', [2889, self.lang, 1], self.args)[0]['ltr_text'],
            "monthly_label" : h.execute_sp('get_translation_by_tag', [2890, self.lang, 1], self.args)[0]['ltr_text'],
            "year_label" : h.execute_sp('get_translation_by_tag', [2061, self.lang, 1], self.args)[0]['ltr_text'],
            "month_label" : h.execute_sp('get_translation_by_tag', [2050, self.lang, 1], self.args)[0]['ltr_text'],
            "form_submission_insight_label" : h.execute_sp('get_translation_by_tag', [8765, self.lang, 1], self.args)[0]['ltr_text'],
            "total_forms_submitted_label" : h.execute_sp('get_translation_by_tag', [8817, self.lang, 1], self.args)[0]['ltr_text'],
            "form_submission_sparklines_label" : h.execute_sp('get_translation_by_tag', [9098, self.lang, 1], self.args)[0]['ltr_text'],
            "form_submission_insight_label" : h.execute_sp('get_translation_by_tag', [8765, self.lang, 1], self.args)[0]['ltr_text'],
            "most_used_forms_label" : h.execute_sp('get_translation_by_tag', [8802, self.lang, 1], self.args)[0]['ltr_text'],
            "least_used_forms_label" : h.execute_sp('get_translation_by_tag', [8772, self.lang, 1], self.args)[0]['ltr_text'],
            "form_submission_summary_label" : h.execute_sp('get_translation_by_tag', [9102, self.lang, 1], self.args)[0]['ltr_text'],
            "months_label" : h.execute_sp('get_translation_by_tag', [9101, self.lang, 1], self.args)[0]['ltr_text'],
            "yearly_label" : h.execute_sp('get_translation_by_tag', [9105, self.lang, 1], self.args)[0]['ltr_text'],
            "form_submission_summary_label" : h.execute_sp('get_translation_by_tag', [9102, self.lang, 1], self.args)[0]['ltr_text'],
            "months_with_most_submissions_label" : h.execute_sp('get_translation_by_tag', [9100, self.lang, 1], self.args)[0]['ltr_text'],
            "most_submitted_forms_label" : h.execute_sp('get_translation_by_tag', [9104, self.lang, 1], self.args)[0]['ltr_text'],
            "most_submitted_forms_by_job_label" : h.execute_sp('get_translation_by_tag', [9103, self.lang, 1], self.args)[0]['ltr_text'],                   
            "form_submission_frequency_label" : h.execute_sp('get_translation_by_tag', [9097, self.lang, 1], self.args)[0]['ltr_text'],
            "form_name_label" : h.execute_sp('get_translation_by_tag', [1903, self.lang, 1], self.args)[0]['ltr_text'],
            "form_count_label" : h.execute_sp('get_translation_by_tag', [2099, self.lang, 1], self.args)[0]['ltr_text'],
            "total_label" : h.execute_sp('get_translation_by_tag', [1044, self.lang, 1], self.args)[0]['ltr_text'],
            "forms_under1_label" : h.execute_sp('get_translation_by_tag', [9117, self.lang, 1], self.args)[0]['ltr_text'],
            "quarterly_label" : h.execute_sp('get_translation_by_tag', [2891, self.lang, 1], self.args)[0]['ltr_text'],
            "biannually_label" : h.execute_sp('get_translation_by_tag', [2892, self.lang, 1], self.args)[0]['ltr_text'],
            "top_label" : h.execute_sp('get_translation_by_tag', [3750, self.lang, 1], self.args)[0]['ltr_text'],
            }

            result['rpt_submissions_by_job_breakdown'] = h.execute_sp('rpt_submissions_by_job_breakdown', [start_date, end_date, job_ids, self.lang ], self.args)
            result['rpt_submissions_by_breakdown_date'] = h.execute_sp('rpt_submissions_by_breakdown_date', [start_date, end_date, self.lang], self.args)
            result['rpt_submissions_by_breakdown_date_job'] = h.execute_sp('rpt_submissions_by_breakdown_date_job', [start_date, end_date,job_ids, self.lang], self.args)
            if result['rpt_submissions_by_job_breakdown']:
                result['labels'] = {key:value for key, value in result['rpt_submissions_by_job_breakdown'][0].items() if key.endswith('_label')}

                for each in result['rpt_submissions_by_job_breakdown']:
                    if each['job_rld_name'] == None:
                        each['job_rld_name'] = ''
                    each['job_title'] = f"{each['job_rld_name']} ({each['rld_code']}) - {each['site_rld_name']}"

            if result['rpt_submissions_by_breakdown_date_job']:
                result['labels'] = {key:value for key, value in result['rpt_submissions_by_breakdown_date_job'][0].items() if key.endswith('_label')}

                for each in result['rpt_submissions_by_breakdown_date_job']:
                    if each['job_rld_name'] == None:
                        each['job_rld_name'] = ''
                    each['job_title'] = f"{each['job_rld_name']} ({each['rld_code']}) - {each['site_rld_name']}"
            
        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))
            
            result['chart_labels'] = []
        
        return result
    