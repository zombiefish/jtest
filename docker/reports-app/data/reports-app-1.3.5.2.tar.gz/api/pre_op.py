#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']        

        ## Load report-specific configuration
        with open('config/pre_op.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_machine_info_by_submission', 'rpt_form_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id','rpt_hazard_actions','rpt_form_details_distribution','rpt_form_reviewers','rpt_pre_op_questions_by_submission','rpt_pre_op_details','rpt_post_op_details', 'rpt_pre_op_start_time', 'rpt_pre_op_end_time'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        h.get_hazard_actions(result['rpt_hazard_actions'], imageUrl, self.args, self.lang) 
        h.get_general_actions(result['rpt_get_general_action_by_id'], imageUrl, self.args, self.lang)
        h.get_positive_recognitions(result['rpt_positive_recognition'], imageUrl, self.args, self.lang)

        #Executing the below SPs to get the section specific images
        result['rpt_pre_op_photos'] = h.execute_sp('rpt_pre_op_photos', [formSubmissionId, imageUrl, self.lang], self.args)
        result['rpt_post_op_photos'] = h.execute_sp('rpt_post_op_photos', [formSubmissionId, imageUrl, self.lang], self.args)

        for row in result['rpt_pre_op_signature_by_id']:
            if row['Value'] is not None:
                if ('.jpg' or '.png') in row['Value']:
                    row['Value'] = imageUrl + row['Value']

        #Modifying the boolean values
        if len(result['rpt_pre_op_questions_by_submission']) > 0:
            for wc in result['rpt_pre_op_questions_by_submission'] :
                if wc['Answer'] == '1':
                    wc['Answer'] = wc['yes_value']
                else :
                    if wc['Answer'] == '0':
                        wc['Answer'] = wc['no_value'] 
                    elif wc['Answer'] == '-1':
                        wc['Answer'] = 'N/A'
                    else:
                        wc['Answer'] = wc['Answer']

        #Updating this section to be able to key on original section name  
        rpt_form_details = {}
        for row in result['rpt_form_details']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)
        
        result['rpt_form_details'] = rpt_form_details 


        supervisorReview = result['rpt_pre_op_signature_by_id'] if 'rpt_pre_op_signature_by_id' in result and len(result['rpt_pre_op_signature_by_id']) > 0 else []
        if len(supervisorReview) == 1:
            for key in supervisorReview:
                if key['poa_element_name'] != 'signature_supervisor_photo':
                    supervisorReview.append({ 
                "poa_element_name":'signature_supervisor_photo',
                "Value":''})
            
        return result
