#Import important libraries for the report to load
import pandas as pd
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId):
        result = {}

        ## Load report-specific configuration
        with open('config/positive_id_summary.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['logo'] = h.get_logo()
        result['required_args'] = config['required_args'] 
        result['optional_args'] = config['optional_args']     
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args']})      
        result['args'] = dict(self.args)

        # place the report title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [3451,self.lang,1], self.args)[0]['ltr_text']

        # Check if user entered all the required parameters and executing the main data SP at line 44
        required_args = config['required_args']
        if len(list(set(required_args) & set(result['args']))) == len(required_args):            
            start_date=self.args['start_date']      
            end_date=self.args['end_date']
            
            #site_ids 
            site_ids=self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            site_ids_list = site_ids.split(',') if site_ids is not None else []
            site_data_name = {}            
            user_site_data = result['filter_data']['optionalArgs']['site_ids']['field_values']
            if site_ids_list:
                site_data_name = {each['value'] for each in user_site_data if str(each['value']) in site_ids_list}
            else:
                site_data_name = {each['value'] for each in user_site_data}
            
            site_id = ','.join(map(str, site_data_name))

            #by_who 
            by_who=self.args['by_who'] if 'by_who' in self.args and self.args['by_who'] != '' else None
            by_who_list = by_who.split(',') if by_who is not None else []
            by_who_data_name = {}            
            user_by_who_data = result['filter_data']['optionalArgs']['by_who']['field_values']
            if by_who_list:
                by_who_data_name = {each['value'] for each in user_by_who_data if str(each['value']) in by_who_list}
            else:
                by_who_data_name = {each['value'] for each in user_by_who_data}
            
            recognition_by = ','.join(map(str, by_who_data_name))


            rpt_positive_id_summary = h.execute_sp('rpt_positive_id_summary', [site_id, start_date, end_date, recognition_by, self.lang], self.args)

            if rpt_positive_id_summary:
                result['labels'] = {key:value for key, value in rpt_positive_id_summary[0].items() if key.endswith('_label')}

                # create a dataframe of sp - result data using pandas
                df_positive_id_summary = pd.DataFrame(rpt_positive_id_summary)                
                # create site_groups using group_by for each site_name
                site_groups = df_positive_id_summary.groupby(['site_name', 'site_enable_status'])
                positive_id_data = {}
                # loop through site groups
                for site_name, job_data in site_groups:
                    positive_id_data[site_name] = {}
                    # create groups for each JobNumber 
                    job_groups = job_data.groupby('JobNumber')
                    for jobnumber, positive_data in job_groups:
                        positive_id_data[site_name][jobnumber] = positive_data.to_dict(orient='records')
                
                result['positive_id_data'] = positive_id_data

        

        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result 