#Import important libraries for the report to load
import yaml
import helper as h
import pandas


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/daily_drilling.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_daily_drilling_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id', 
            'rpt_hazard_actions','rpt_form_details_distribution','rpt_form_reviewers'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)
    
        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)

        
        rlh_names = ['ref_drilling_time_and_delays_code','ref_drilling_code','ref_drilling_status_code','ref_drilling_log_code']
        result['rpt_daily_drilling_legend'] = {}
        for rlh_name in rlh_names:
            result['rpt_daily_drilling_legend'][rlh_name]=h.execute_sp('rpt_ref_list_code_value',[self.lang,rlh_name], self.args)
           
        ## Load parameterized Stored Procedures
        h.get_hazard_actions(result['rpt_hazard_actions'], imageUrl, self.args, self.lang) 
        h.get_general_actions(result['rpt_get_general_action_by_id'], imageUrl, self.args, self.lang)
        h.get_positive_recognitions(result['rpt_positive_recognition'], imageUrl, self.args, self.lang)

        for wc in result['rpt_daily_drilling_details']:
            if wc['value'] is not None:
                if ('.jpg' or '.png') in wc['value']:
                    wc['value'] = imageUrl + wc['value']
        

        #Updating this section to be able to key on original section name 
        rpt_daily_drilling_details = {}
        for row in result['rpt_daily_drilling_details']:
            if row['original_section_name'] not in rpt_daily_drilling_details:
                rpt_daily_drilling_details[row['original_section_name']] = []
            rpt_daily_drilling_details[row['original_section_name']].append(row)
        
        result['rpt_daily_drilling_details'] = rpt_daily_drilling_details

        df_materials_used = pandas.DataFrame(result['rpt_daily_drilling_details']['Material Used'])
        df_materials_used = df_materials_used.apply(lambda row: self.add_index(row), axis=1)

        piv_materials_used = df_materials_used.pivot(index = 'index', columns= 'original_field_name')['value']
        
        result['materials_used'] = piv_materials_used.reset_index().drop('index', axis=1).to_dict(orient='records')
        

        #Adding the metric value for the Planned length, Drill length and Redrill
        metric_value=list(result['rpt_daily_drilling_details']['Equipment'])
        result['unit'] =self.get_metric_unit(list(result['rpt_daily_drilling_details']['Equipment']))
        
        df_time_entry = pandas.DataFrame(result['rpt_daily_drilling_details']['Time Entry'])
        df_time_entry = df_time_entry.fillna('')
        df_time_entry = df_time_entry.apply(lambda row: self.add_index(row), axis=1)

        piv_time_entry = df_time_entry.pivot(index = 'index', columns= 'original_field_name')['value']
        result['time_entry'] = piv_time_entry.reset_index().fillna('').drop('index', axis=1).to_dict(orient='records')

        return result

    def add_index(self, row):
        row['index'] = row['field_key'].split('_')[-1]
        return row
    
    def get_metric_unit(self, data):
        unit_value = ''
        for each in data:
            if each['field_key'] == 'unit':
                # get ltr_tag for each['value'] using a sql query 
                tag = h.execute_sql(f"SELECT ltr_tag from language_translation WHERE ltr_text = '{each['value']}' AND ltr_enable = 1 LIMIT 1")['result']
               
                # get ltr_text  for ltr_tag for users language using
                if len(tag) > 0:
                    metric_val = h.execute_sp('get_translation_by_tag', [tag[0]['ltr_tag'],1,1], self.args)[0]['ltr_text']
                    if metric_val == 'Metric':
                        unit_value = 'm'
                    elif metric_val == 'Imperial':
                        unit_value = 'ft'
        return unit_value