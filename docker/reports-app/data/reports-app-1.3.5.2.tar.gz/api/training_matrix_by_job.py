from datetime import datetime, date, timedelta
import pandas as pd
import yaml
import helper as h
import re

class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId):
        result = {}

        ## Load report-specific configuration
        with open('config/training_matrix_summary.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['required_args'] = config['required_args'] if config['required_args'] is not None else []
        result['optional_args'] = config['optional_args']
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args'], 'report_slug':config['header']['slug']})        
        result['args'] = dict(self.args)
        inactive_emp_checkbox_flag = result['args']['include_inactive_employees_check']

        # place the Report Title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [9483,self.lang,1], self.args)[0]['ltr_text']
        
        report_Selection = result['args']['report_selection']
                
        # Check if user entered all the required parameters
        required_args = config['required_args']

        if report_Selection == '110':
            required_args.remove('per_ids')
         
        per_ids = self.args['per_ids'] if 'per_ids' in self.args and self.args['per_ids'] != '' else None
        site_ids = self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
        job_ids = self.args['job_ids'] if 'job_ids' in self.args and self.args['job_ids'] != '' else None
        display_inactive_training_codes=str(self.args['display_inactive_training_codes']) if 'display_inactive_training_codes' in self.args else 'False'
        training_code=self.args['training_codes'] if 'training_codes' in self.args and self.args['training_codes'] != '' else None

        # if 'apply' in result['args']:
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            result['legend'] = {
                "ok_label_1": h.execute_sp('get_translation_by_tag', [1462,self.lang,1], self.args)[0]['ltr_text'],
                "ok_matrix_label": (h.execute_sp('get_translation_by_tag', [1462,self.lang,1], self.args)[0]['ltr_text']).split('- '),
                "prog_label_2": h.execute_sp('get_translation_by_tag', [1461,self.lang,1], self.args)[0]['ltr_text'],
                "prog_matrix_label": (h.execute_sp('get_translation_by_tag', [1461,self.lang,1], self.args)[0]['ltr_text']).split('- '),
                "schedule_label_3": h.execute_sp('get_translation_by_tag', [1460,self.lang,1], self.args)[0]['ltr_text'],
                "schedule_matrix_label": (h.execute_sp('get_translation_by_tag', [1460,self.lang,1], self.args)[0]['ltr_text']).split('- '),
                "need_label_4": h.execute_sp('get_translation_by_tag', [1459,self.lang,1], self.args)[0]['ltr_text'],
                "need_matrix_label": (h.execute_sp('get_translation_by_tag', [1459,self.lang,1], self.args)[0]['ltr_text']).split('- '),
                "exp_label_5": h.execute_sp('get_translation_by_tag', [9236,self.lang,1], self.args)[0]['ltr_text'],
                "exp_matrix_label": (h.execute_sp('get_translation_by_tag', [9236,self.lang,1], self.args)[0]['ltr_text']).split('- ')
            }

            list_employees_id=[]
            if per_ids is None and site_ids is None:
                emp_id1 =  h.execute_sql("""
                            select per_id from v_employee WHERE emp_enable = 1 AND per_id <> 1 ORDER BY LOWER(per_full_name);
                            """)
                e_list = []
                for e in emp_id1['result']:
                    e_list.append(int(e['per_id']))
                list_employees_id = e_list
            elif per_ids is None and site_ids:
                per_id1_sql = """select b.per_id from employee_site a inner join v_employee b on a.esi_emp_id = b.emp_id where a.esi_sit_id in (""" + site_ids + """) AND a.esi_enable = 1;"""
                print('per_id1_sql____',per_id1_sql)
                per_id1 =  h.execute_sql(per_id1_sql)
                if job_ids is not None:
                    per_id2_sql = """select b.per_id from employee_job a inner join v_employee b on a.ejo_emp_id = b.emp_id where a.ejo_job_id in (""" + job_ids + """) AND a.ejo_enable = 1;"""
                    print('per_id2_sql____',per_id2_sql)
                    per_id1 =  h.execute_sql(per_id2_sql)
                per_list = []
                for e in per_id1['result']:
                    per_list.append(int(e['per_id']))
                per_list1 = ','.join(str(e) for e in per_list)
                per_ids = per_list1
                list_employees_id = per_list
            else:
                list_emp = list(per_ids.split(','))
                for e in list_emp:
                    list_employees_id.append(int(e.strip()))

            list_training_code=[]
            if training_code is None:
                codes1 = h.execute_sql("""
                            SELECT DISTINCT etr_training_code_id FROM employee_training;
                            """)
                for c in codes1['result']:
                    list_training_code.append(int(c['etr_training_code_id']))
            else:
                list_codes = list(training_code.split(','))
                for e in list_codes:
                    list_training_code.append(int(e.strip()))   
            
            if inactive_emp_checkbox_flag == '1':
                
                result['rpt_training_matrix'] = h.execute_sp('rpt_training_matrix_by_job_inactive_emp', [training_code,site_ids,job_ids,self.lang], self.args)
            else:
                
                result['rpt_training_matrix'] = h.execute_sp('rpt_training_matrix_by_job', [training_code,site_ids,job_ids,self.lang], self.args)
               
          
            
            inactive_label = h.execute_sp('get_translation_by_tag', [9169,self.lang,1], self.args)[0]['ltr_text']

            training_code_data = result['rpt_training_matrix']
            
            for data in training_code_data:

                if display_inactive_training_codes == "True" and data['training_code_enable_status'] == 0:
                    data['training_code'] = (data['training_code'] + ' ' + inactive_label)
              
                if data['status_flag'] == 0:
                    data['emp_name'] = (data['emp_name'] + ' ' + inactive_label)


            employee_training_data = result['rpt_training_matrix']
            #Checking for records expiring in the next 30 days
            #Set value of expiry date to -1, if the record is expiring in the next 30 days, else set it to 0
            #Set value to -1, if it's a null record
            for rec in employee_training_data:
                rec['30day_expired'] = 0
                if rec['etr_expiry_date'] is not None:
                    theDate = datetime.strptime(rec['etr_expiry_date'], '%Y-%m-%d').date()
                    if theDate > date.today() and theDate < date.today() + timedelta(days=30):
                        rec['is_expired'] = int(rec['is_expired'] or 0) * -1
                    elif theDate < date.today():
                        rec['is_expired'] = 5
                        
                
            lst_tc = []
            lst_emp = []
            lst_sites = []
            for each in employee_training_data:
                if each['etr_training_code_id'] not in lst_tc:
                    lst_tc.append(each['etr_training_code_id'])
                if each['etr_emp_id'] not in lst_emp:
                    lst_emp.append(each['etr_emp_id'])
                if each['Site'] not in lst_sites:
                    lst_sites.append(each['Site'])

            
            lst_emp_null = sorted(list(set(list_employees_id).difference(lst_emp)))
            lst_tc_null = sorted(list(set(list_training_code).difference(lst_tc)))
            # lst_sites_null = sorted(list(set(list_site_ids).difference(lst_tc)))

            s1=','.join(str(x) for x in lst_emp_null)
            s2=','.join(str(y) for y in lst_tc_null)
            # s3=','.join(str(z) for z in lst_sites_null)

            #Getting the full names and training codes for those which are missing from the data set
            if len(s1) > 0:
                lst_emp_null_names = h.execute_sql("""
                        select per_full_name as full_name from v_employee where per_id in ("""+s1+""") order by per_full_name
                        """)
            else:
                lst_emp_null_names = {}
                lst_emp_null_names['result'] = []

            if len(s2) > 0:
                lst_tc_null_names = h.execute_sql("""
                                SELECT `employee_training`.`etr_training_code_id`, `ref_list_detail`.`rld_code` AS `training_code` 
            FROM `employee_training` INNER JOIN `ref_list_detail` ON (`employee_training`.`etr_training_code_id` = `ref_list_detail`.`rld_id`) 
            WHERE `employee_training`.`etr_training_code_id` in ("""+s2+""") ORDER BY `employee_training`.`etr_training_code_id` ASC
                        """)
            else:
                lst_tc_null_names = {}
                lst_tc_null_names['result'] = []

            null_matrix = []
            # If there are no employees in the null list
            if len(s1) == 0 and len(employee_training_data) > 0:
                for training in lst_tc_null_names['result']:
                    temp_rec = {}
                    temp_rec['employee_id'] = 0
                    temp_rec['emp_name'] = employee_training_data[0]['emp_name']
                    temp_rec['training_code'] = training['training_code']
                    temp_rec['is_expired'] = ''
                    temp_rec['etr_training_code_id'] = training['etr_training_code_id']    
                    temp_rec['etr_emp_id'] = 0  
                    temp_rec['etr_expiry_date'] = ''  
                    temp_rec['30day_expired'] = -1
                    if temp_rec not in null_matrix:             
                        null_matrix.append(temp_rec.copy()) 
            
            # If there are no training codes in the null list

            elif len(s2) == 0 and len(employee_training_data) > 0 :
                for person in lst_emp_null_names['result']:
                    temp_rec = {}
                    temp_rec['employee_id'] = 0
                    temp_rec['emp_name'] = person['full_name']
                    temp_rec['training_code'] = employee_training_data[0]['training_code']
                    temp_rec['is_expired'] = ''
                    temp_rec['etr_training_code_id'] = employee_training_data[0]['etr_training_code_id']    
                    temp_rec['etr_emp_id'] = 0     
                    temp_rec['etr_expiry_date'] = ''
                    temp_rec['30day_expired'] = -1
                    if temp_rec not in null_matrix:             
                        null_matrix.append(temp_rec.copy()) 
            else:
                for person in lst_emp_null_names['result']:
                    for training in lst_tc_null_names['result']:
                        temp_rec = {}
                        temp_rec['employee_id'] = 0
                        temp_rec['emp_name'] = person['full_name']
                        temp_rec['training_code'] = training['training_code']
                        temp_rec['is_expired'] = ''
                        temp_rec['etr_training_code_id'] = training['etr_training_code_id']    
                        temp_rec['etr_emp_id'] = 0     
                        temp_rec['etr_expiry_date'] = ''
                        temp_rec['30day_expired'] = -1
                        if temp_rec not in null_matrix:             
                            null_matrix.append(temp_rec.copy()) 
            
            for each in null_matrix:
                employee_training_data.append(each)
            flag = list(training_code_data)

            #Get the translated valur for 'OK'
            ok_value = h.execute_sp('get_translation_by_tag', [1405,self.lang,1], self.args)[0]['ltr_text']

            training_code_names = []
            person_records = []
            code_value=[]
            if employee_training_data:
                df = pd.DataFrame(employee_training_data) 
                pivot_data = df.pivot_table(index='emp_name', columns = 'training_code', values = 'is_expired',aggfunc=lambda x: ', '.join(str(v) 
                for v in x))          
                pivot_data = pivot_data.fillna('')
                
                training_code_names = [col for col in pivot_data.columns.values] 
                for idx, row in pivot_data.iterrows():
                    row_data = []
                    for each in row:
                        row_data.append(each.split(','))
                    per_name = re.sub('[0-9]*-', '', row.name) #replacing user id in person full name with empty space.           
                    row_data.insert(0, per_name)
                    person_records.append(row_data)
            
            person_records = sorted(person_records, key=lambda x: x[0])
            
            result['context'] = {
                'training_codes' : list(training_code_names),
                'person_records' : person_records,
                'colspan' : len(training_code_names)+1,
                'date': datetime.today().strftime('%Y-%m-%d'),
                'language': self.lang,
                'ok' : ok_value,
                'flag':flag
            }

        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))
        
        return result

    