#Import important libraries for the report to load
import yaml
import helper as h
import pandas as pd


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, per_id):
        result = {}
        def get_frequency_name(freq_id):
            if freq_id == 30:
                return result['rpt_targets_change_log_labels']['Monthly']
            
            elif freq_id == 90:
                return result['rpt_targets_change_log_labels']['Quarterly']
            
            elif freq_id == 365:
                return result['rpt_targets_change_log_labels']['Annually']
            
            else:
                return result['rpt_targets_change_log_labels']['Bi-Annually']

        ## Load report-specific configuration
        with open('config/targets_change_log.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['per_id'] = int(per_id)
        result['header'] = config['header']
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['logo'] = h.get_logo()
        result['required_args'] = config['required_args']        
        result['optional_args'] = config['optional_args'] if 'optional_args' in config and config['optional_args'] is not None else []
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args': config['optional_args']})
        result['args'] = dict(self.args)
        # place the Title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [2445,self.lang,1], self.args)[0]['ltr_text']
        # Check if user entered all the required parameters and executing main SP in line 51
        required_args = config['required_args']
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            start_date=self.args['start_date']     
            end_date=self.args['end_date']

            # Fetching all the required labels
            result['rpt_targets_change_log_labels']={
                "Context_label": h.execute_sp('get_translation_by_tag', [1342,self.lang,1], self.args)[0]['ltr_text'],
                "Target_label": h.execute_sp('get_translation_by_tag', [1107,self.lang,1], self.args)[0]['ltr_text'],
                "Frequency_label": h.execute_sp('get_translation_by_tag', [1106,self.lang,1], self.args)[0]['ltr_text'],
                "Effective_label": h.execute_sp('get_translation_by_tag', [2448,self.lang,1], self.args)[0]['ltr_text'],
                "Archived_label": h.execute_sp('get_translation_by_tag', [2399,self.lang,1], self.args)[0]['ltr_text'],
                "Date_label": h.execute_sp('get_translation_by_tag', [124,self.lang,1], self.args)[0]['ltr_text'],
                "Modified_By_label": h.execute_sp('get_translation_by_tag', [1288,self.lang,1], self.args)[0]['ltr_text'],
                "Type_label": h.execute_sp('get_translation_by_tag', [1054,self.lang,1], self.args)[0]['ltr_text'],
                "Change_label": h.execute_sp('get_translation_by_tag', [2451,self.lang,1], self.args)[0]['ltr_text'],
                "Change_log_label": h.execute_sp('get_translation_by_tag', [2450,self.lang,1], self.args)[0]['ltr_text'],
                "Monthly": h.execute_sp('get_translation_by_tag', [2890,self.lang,1], self.args)[0]['ltr_text'],
                "Quarterly": h.execute_sp('get_translation_by_tag', [2891,self.lang,1], self.args)[0]['ltr_text'],
                "Annually": h.execute_sp('get_translation_by_tag', [2893,self.lang,1], self.args)[0]['ltr_text'],
                "Bi-Annually": h.execute_sp('get_translation_by_tag', [2892,self.lang,1], self.args)[0]['ltr_text'],

                "summary_label": h.execute_sp('get_translation_by_tag', [1311,self.lang,1], self.args)[0]['ltr_text'],
                "employee_name_label": h.execute_sp('get_translation_by_tag', [204,self.lang,1], self.args)[0]['ltr_text'],
                "number_of_forms_with_targets_label": h.execute_sp('get_translation_by_tag', [2446,self.lang,1], self.args)[0]['ltr_text'],
                "role_label": h.execute_sp('get_translation_by_tag', [1245,self.lang,1], self.args)[0]['ltr_text'],
                "changed_within_time_frame_selected_label": h.execute_sp('get_translation_by_tag', [2447,self.lang,1], self.args)[0]['ltr_text']
                
            }
            result['target_comment_data'] = {}
            change_log_header = h.execute_sp('rpt_targets_change_log_header', [int(per_id), self.lang,start_date, end_date], self.args)[0]
            if change_log_header['per_full_name'] or change_log_header['role']:
                result['target_comment_data']['employee_name'] = change_log_header['per_full_name']
                result['target_comment_data']['role'] = change_log_header['role']
            else:
                result['target_comment_data']['employee_name'] = ''
                result['target_cotarget_comment_datamment_data']['role'] = ''
            
            detail_targets =  h.execute_sp('rpt_all_targets_change_details', [start_date, end_date,str(per_id), self.lang], self.args)
            number_of_targets = 0
            number_of_forms = 0
            result['target_comment_data']['form_data'] = []
            
            if detail_targets:
                for target in detail_targets:
                    number_of_targets = number_of_targets + target['Target']
                    number_of_forms = number_of_forms + 1
                    if(target['FDFormID']):
                        form_id = target['FDFormID']
                        detail_data = h.execute_sp('rpt_all_targets_change_details_data', [start_date, end_date,str(per_id),form_id,self.lang], self.args)
                        for rec in detail_data:
                            if rec['comment'] is None:
                                rec['comment'] = rec['stc_comment']
                        effective_date = h.execute_sql("""select EffectiveEnd from SupervisorTargets t where SupervisorID = """+ str(per_id) + """ and t.FDFormID = """+ str(target['FDFormID']) + """ order by t.ID DESC limit 1;""")
                        result['target_comment_data']['form_data'].append({"formname": target['formname'],
                                                                        "context":target['sta_context'],
                                                                        "target":target['Target'],
                                                                        "frequency":get_frequency_name(target['FrequencyID']),
                                                                        "effective_on":target['EffectiveOn'],
                                                                        "archived_date": effective_date['result'][0]['EffectiveEnd'],
                                                                        "details":detail_data})
                    else:
                        custom_form_id = target['sta_fob_id']
                        detail_data = h.execute_sp('rpt_all_targets_change_details_data_custom_form', [start_date, end_date,str(per_id),custom_form_id,self.lang], self.args)
                        for rec in detail_data:
                            if rec['comment'] is None:
                                rec['comment'] = rec['stc_comment']
                        effective_date = h.execute_sql("""select EffectiveEnd from SupervisorTargets t where SupervisorID = """+ str(per_id) + """ and t.sta_fob_id = """+ str(target['sta_fob_id']) + """ order by t.ID DESC limit 1;""")
                        result['target_comment_data']['form_data'].append({"formname": target['customformname'],
                                                                        "context":target['sta_context'],
                                                                        "target":target['Target'],
                                                                        "frequency":get_frequency_name(target['FrequencyID']),
                                                                        "effective_on":target['EffectiveOn'],
                                                                        "archived_date": effective_date['result'][0]['EffectiveEnd'],
                                                                        "details":detail_data})

                result['target_comment_data']['total_targets'] = number_of_targets
                result['target_comment_data']['total_forms'] = number_of_forms
            else:
                result['target_comment_data']['total_targets'] = 0
                result['target_comment_data']['total_forms'] = 0
        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))
        
        return result
    
