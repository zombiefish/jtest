#Import important libraries for the report to load
import yaml
import helper as h
import pandas


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/hot_work_permit.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_form_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id','rpt_hazard_actions','rpt_form_details_distribution','rpt_form_reviewers', 'rpt_hot_work_permit_air_quality_test', 'rpt_hot_work_permit_fire_watch'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)   

        # Get the fire watch data
        result['rpt_hot_work_permit_fire_watch'] = []
        result['rpt_hot_work_permit_fire_watch'].append(h.execute_sp('rpt_hot_work_permit_fire_watch', [formSubmissionId, self.lang], self.args))

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures
        result['rpt_hap_pictures_initial'] = []
        result['rpt_hap_pictures_followup'] = []


        h.get_hazard_actions(result['rpt_hazard_actions'], imageUrl, self.args, self.lang) 
        h.get_general_actions(result['rpt_get_general_action_by_id'], imageUrl, self.args, self.lang)
        h.get_positive_recognitions(result['rpt_positive_recognition'], imageUrl, self.args, self.lang)

       
        # Here we give our dictionaries English section names so we can key on them       
        rpt_form_details = {}
       

        for row in result['rpt_form_details']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)
        
        # the following sections add the Image URL per client to the picture filenames
        if 'Pre-Work Signatures' in rpt_form_details:
            if 'Pre-Work Signatures' in rpt_form_details:
                for wc in rpt_form_details['Pre-Work Signatures']:
                    if wc['value'] is not None:
                        if ('.jpg' or '.png') in wc['value']:
                            wc['value'] = imageUrl + wc['value']
                        else:
                            wc['value'] = wc['value'].replace('\\','')

        if 'Completion of Hot Work' in rpt_form_details:
            if 'Completion of Hot Work' in rpt_form_details:
                for wc in rpt_form_details['Completion of Hot Work']:
                    if wc['value'] is not None:
                        if ('.jpg' or '.png') in wc['value']:
                            wc['value'] = imageUrl + wc['value']
                        else:
                            wc['value'] = wc['value'].replace('\\','')
        
        if 'Fire Watch' in rpt_form_details:
            if 'Fire Watch' in rpt_form_details:
                for wc in rpt_form_details['Fire Watch']:
                    if wc['value'] is not None:
                        if ('.jpg' or '.png') in wc['value']:
                            wc['value'] = imageUrl + wc['value']
                        else:
                            wc['value'] = wc['value'].replace('\\','')
                        

        #Accept the numerical value, then populate the string needed for the report
        if 'Details' in rpt_form_details:
            for wc in rpt_form_details['Details']:
                if wc['field_key'] == 'evaluate_risk':
                    if wc['value'] == '1': 
                        wc['value'] = 'High Risk'
                    elif wc['value'] == '0':
                        wc['value'] = 'Low Risk'                

        #Accept the numerical value, then populate the string needed for the report
        if 'Why is this high Risk Hot Work' in rpt_form_details:
            for wc in rpt_form_details['Why is this high Risk Hot Work']:
                if wc['field_key'] == 'gas_test':
                    if wc['value'] == '1': 
                        wc['value'] = wc['yes_value']
                    elif wc['value'] == '0':
                        wc['value'] = wc['no_value']       
                if wc['field_key'] == 'location':
                    if wc['value'] == '1': 
                        wc['value'] = wc['yes_value']
                    elif wc['value'] == '0':
                        wc['value'] = wc['no_value']  

           
        # Add the image URL to the signatures in the fire watch data
        for wc in result['rpt_hot_work_permit_fire_watch']:
            for wc2 in wc:
                if wc2 is not None:
                    if ('.jpg' or '.png') in wc2['WatcherSign']:
                        wc2['WatcherSign'] = imageUrl + wc2['WatcherSign']

        

        result['rpt_form_details'] = rpt_form_details

        field_keys = h.execute_sp('rpt_form_field_keys', [1407, self.lang], self.args)

        df_keys = pandas.DataFrame(field_keys)
        section_df =  df_keys.groupby('original_section_name').apply(lambda x: x.to_dict('records')).to_dict() #DB 
       

        for section,data in result['rpt_form_details'].items(): 
            if section == 'Details':
                field_keys_list = {each['fieldKey']:{'fieldName':each['fieldName'],'FieldOrder': each['FieldOrder']} for each in section_df[section]} #field_key from DB
               
                data_key_list = [each['field_key'] for each in data] #field_key from rpt_form_details

                for field_key in field_keys_list:                
                    if field_key not in data_key_list :
                        data.append(
                            {
                                "field_key":field_key,
                                "field_name":field_keys_list[field_key]['fieldName'],
                                "value":' ',
                                "field_order":field_keys_list[field_key]['FieldOrder']
                            }
                        )
        result['rpt_form_details']['Details'] = sorted(result['rpt_form_details']['Details'], key=lambda d:d['field_order'])
        
        return result
    