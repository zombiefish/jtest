#Import important libraries for the report to load
import yaml
import helper as h
from flask.json import jsonify
import json
import pandas as pd

class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/equipment_status.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        #result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['filter'] = config['filter']
        result['required_args'] = config['required_args']  
        result['optional_args'] = config['optional_args']
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args']})        
        result['args'] = dict(self.args)
        
        # get the report Title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [3457,self.lang,1], self.args)[0]['ltr_text']

        measures_query ="""
            SELECT 
                ltr_text,
                rld_id
            FROM ref_list_detail 
            INNER JOIN language_translation
            ON language_translation.ltr_tag = ref_list_detail.rld_name
            AND language_translation.ltr_tag_type = ref_list_detail.rld_tag_type
            AND language_translation.ltr_lng_id = """+str(self.lang)+"""
            WHERE rld_rlh_id = 89;
        """
        measures_query_p = h.execute_sql(measures_query)
        measures_dict = {}
        for measure in measures_query_p['result']:
            measures_dict.update({measure['rld_id']: measure['ltr_text']})    

        required_args = config['required_args']
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            allRecs=[]
            start_date=self.args['start_date']       
            end_date=self.args['end_date']
            equipment_ids = self.args['equipment_ids'] if 'equipment_ids' in self.args and self.args['equipment_ids'] != '' else None
            sites = self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            display_inactive_site_ids=str(self.args['display_inactive_site_ids']) if 'display_inactive_site_ids' in self.args else 'False'
            display_inactive_equipment_ids=str(self.args['display_inactive_equipment_ids']) if 'display_inactive_equipment_ids' in self.args else 'False'
            
            result['rpt_equipment_status'] = h.execute_sp('rpt_equipment_status', [start_date, end_date, sites, equipment_ids, self.lang], self.args)
            all_ids = []
            allSites = [] 
            for id in result['rpt_equipment_status']:
                all_ids.append(str(id['psh_submissionheader_id']))
            all_ids_list = ','.join(all_ids) 
            if all_ids_list:
                start_end_time_query = """
                    SELECT
                        psh_submissionheader_id,
                        psv_value,
                        psv_preop_question_identifier
                        FROM preop_submission_header
                            INNER JOIN preop_submission_value
                                ON preop_submission_header.psh_id = preop_submission_value.psv_psh_id
                        WHERE (preop_submission_value.psv_preop_question_identifier LIKE 'measure-start-%' 
                            OR preop_submission_value.psv_preop_question_identifier LIKE 'measure-end-%'  
                            OR preop_submission_value.psv_preop_question_identifier LIKE 'comments%'   
                            OR preop_submission_value.psv_preop_question_identifier LIKE 'othercomments'
                            OR preop_submission_value.psv_preop_question_identifier LIKE 'workplaceendshift')
                            AND psh_submissionheader_id IN ("""+all_ids_list+""")
                            AND preop_submission_value.psv_enable = 1
                        GROUP BY psh_submissionheader_id, psv_preop_question_identifier;
                """   
                start_end_time_query_p = h.execute_sql(start_end_time_query)
                start_end_df = pd.DataFrame(start_end_time_query_p['result'])
                start_end_df.pivot(index='psh_submissionheader_id', columns='psv_preop_question_identifier', values = 'psv_value')
                start_end_data = start_end_df.reset_index().fillna('').drop('index', axis=1).to_dict(orient='records')
                equip_status_data = {}
                for rec in start_end_data:
                    equip_status_data.update({rec['psh_submissionheader_id']:{}})
                for val in start_end_data:
                    if val['psv_preop_question_identifier'][:-4] == 'measure-start-':
                        if 'enginestart' in equip_status_data[val['psh_submissionheader_id']]:
                            equip_status_data[val['psh_submissionheader_id']]['enginestart'] += '<hr>' + measures_dict[int(val['psv_preop_question_identifier'][-4:])] + ': ' + val['psv_value']
                        else:                        
                            equip_status_data[val['psh_submissionheader_id']]['enginestart'] = measures_dict[int(val['psv_preop_question_identifier'][-4:])] + ': ' + val['psv_value']
                    elif val['psv_preop_question_identifier'][:-4] == 'measure-end-':
                        if 'engineend' in equip_status_data[val['psh_submissionheader_id']]:
                            equip_status_data[val['psh_submissionheader_id']]['engineend'] += '<hr>' + measures_dict[int(val['psv_preop_question_identifier'][-4:])] + ': ' + val['psv_value']
                        else:                        
                            equip_status_data[val['psh_submissionheader_id']]['engineend'] = measures_dict[int(val['psv_preop_question_identifier'][-4:])] + ': ' + val['psv_value']
                    else:
                        equip_status_data[val['psh_submissionheader_id']].update({val['psv_preop_question_identifier']:val['psv_value']})  

                #Creating the data set for the equipment status
                if 'rpt_equipment_status' in result:
                    for rec in result['rpt_equipment_status']:
                        try:
                            rec['workplaceendshift'] = equip_status_data[rec['psh_submissionheader_id']]['workplaceendshift'] if 'workplaceendshift' in equip_status_data[rec['psh_submissionheader_id']] else ''
                            rec['comments'] = equip_status_data[rec['psh_submissionheader_id']]['comments'] if 'comments' in equip_status_data[rec['psh_submissionheader_id']] else ''
                            rec['othercomments'] = equip_status_data[rec['psh_submissionheader_id']]['othercomments'] if 'othercomments' in equip_status_data[rec['psh_submissionheader_id']] else ''
                            rec['enginestart'] = equip_status_data[rec['psh_submissionheader_id']]['enginestart'] if 'enginestart' in equip_status_data[rec['psh_submissionheader_id']] else ''
                            rec['engineend'] = equip_status_data[rec['psh_submissionheader_id']]['engineend'] if 'engineend' in equip_status_data[rec['psh_submissionheader_id']] else ''
                        except:
                            pass
                        # Make list of all sites in data    
                        if len(allSites):
                            if any(x for x in allSites if x['site'] == rec['Site']):
                                pass
                            else:
                                allSites.append({"site": rec['Site'],"equipment":[],"site_label":'site'})
                        else:
                            allSites.append({"site": rec['Site'],"equipment":[],"site_label":'site'})

                    for site in allSites:
                        for rec in result['rpt_equipment_status']:
                            if(rec['Site'] == site['site']):
                                if len(site['equipment']):
                                    if any(x for x in site['equipment'] if x['equip_id'] == rec['pet_equipment_identifier']):
                                        pass
                                    else:
                                        site['equipment'].append({"equip_id": rec['pet_equipment_identifier'],"equip_type": rec['equipment_name'],"data":[]})
                                else:
                                    site['equipment'].append({"equip_id": rec['pet_equipment_identifier'],"equip_type": rec['equipment_name'],"data":[]})

                    for site in allSites:
                        for equip in site['equipment']:
                            for record in result['rpt_equipment_status']:
                                if(record['Site'] == site['site'] and record['pet_equipment_identifier'] == equip['equip_id']):
                                    equip['data'].append(record)

            result['rpt_equipment_status'] = allSites
   
        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result
