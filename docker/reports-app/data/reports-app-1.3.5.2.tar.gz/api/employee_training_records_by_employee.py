#Import important libraries for the report to load
from datetime import datetime, date, timedelta
import yaml
import helper as h
import pandas as pd

class Report:

    def __init__(self, args):

        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId = None):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/employee_training_records.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['filter'] = config['filter']
        result['optional_args'] = config['optional_args'] if config['optional_args'] is not None else []
        result['required_args'] = config['required_args'] if config['required_args'] is not None else []
        result['filter_data'] = h.get_filter_data({'required_args': result['required_args'] , 'lang': self.lang, 'optional_args':config['optional_args'],'report_slug':config['header']['slug']})          
        result['args'] = dict(self.args)
        # get the report Title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [9418,self.lang,1], self.args)[0]['ltr_text']
        # adding this exclusively to display 'about to expire' in status column
        result['about_to_expire_label'] = h.execute_sp('get_translation_by_tag', [8865,self.lang,1], self.args)[0]['ltr_text']

        #Handling the optional filter functionality
        optional_args = config['optional_args']
        required_args = config['required_args']
        display_inactive_per_ids=str(self.args['display_inactive_per_ids']) if 'display_inactive_per_ids' in self.args else 'False'
        #per_ids 
        per_ids=self.args['per_ids'] if 'per_ids' in self.args and self.args['per_ids'] != '' else None
        per_ids_list = per_ids.split(',') if per_ids is not None else []
        per_ids_data_name = {}            
        user_per_ids_data = result['filter_data']['optionalArgs']['per_ids']['field_values']
        if per_ids_list:
            per_ids_data_name = {each['value'] for each in user_per_ids_data if str(each['value']) in per_ids_list}
        else:
            per_ids_data_name = {each['value'] for each in user_per_ids_data}
        
        per_ids = ','.join(map(str, per_ids_data_name))
        
        rpt_employee_training_records_by_employee = h.execute_sp('rpt_employee_training_records_by_employees', [per_ids, self.lang], self.args)            

        inactive_label = h.execute_sp('get_translation_by_tag', [9169,self.lang,1], self.args)[0]['ltr_text']


        temp_data = rpt_employee_training_records_by_employee
        for data in temp_data:
            if data['status_flag'] == 0:
                data['employee_name'] = (data['employee_name'] + ' ' + inactive_label)
        rpt_employee_training_records_by_employee = temp_data

        if rpt_employee_training_records_by_employee:
            result['labels'] = {key:value for key, value in rpt_employee_training_records_by_employee[0].items() if key.endswith('_label')}
            result['labels']['about_to_expire_label'] = h.execute_sp('get_translation_by_tag', [8865,self.lang,1], self.args)[0]['ltr_text']
            employees = {}
            yes_label = h.execute_sp('get_translation_by_tag', [3494,self.lang,1], self.args)[0]['ltr_text']
            no_label = h.execute_sp('get_translation_by_tag', [1380,self.lang,1], self.args)[0]['ltr_text']
            
            df = pd.DataFrame(rpt_employee_training_records_by_employee)
            df = df[['employee_name','emp_employee_number','training_code','training_description','etr_completion_date','etr_expiry_date','is_expired', 'status_flag']]                
            df.fillna('', inplace=True)
            df['is_expired_label'] = df['is_expired']
            df['is_expired_label'].replace({'1':yes_label, '0':no_label}, inplace=True)  

            training_record_groups = df.groupby(['employee_name','emp_employee_number'])
            for name, group in training_record_groups:
                training_data = group.to_dict(orient='records')
                
                for each in training_data:
                    each['etr_expiry_date'] = datetime.strptime(each['etr_expiry_date'], '%Y-%m-%d').date() if each['etr_expiry_date'] else ''                                     
                    each['expires_in_30'] = True if each['etr_expiry_date'] and (each['etr_expiry_date'] - date.today()).days < 30 and (each['etr_expiry_date'] - date.today()).days>0 else False

                employees[f'{name[0]} - {name[1]}'] = training_data
            result['training_records'] = employees
        else:
            result['args']['missing_args'] = list(set(optional_args) - set(result['args']))

        return result