#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/training_assessment_audit.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_form_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id','rpt_hazard_actions_list','rpt_form_details_distribution','rpt_form_reviewers'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures
        #HAP section updates as per initial and follow up images
        result['rpt_hap_pictures_initial'] = []
        result['rpt_hap_pictures_followup'] = []

        for hap in result['rpt_hazard_actions_list']:
            result['rpt_hap_pictures_initial'].append(h.execute_sp('rpt_hap_pictures', [hap['ID0a___Submission_HAP_ID'], imageUrl, 'INITIAL', self.lang], self.args))
            result['rpt_hap_pictures_followup'].append(h.execute_sp('rpt_hap_pictures', [hap['ID0a___Submission_HAP_ID'], imageUrl, 'FOLLOWUP', self.lang], self.args))
    
        #Positive recognition section update to get images and data
        result['rpt_pid_pictures'] = []
        if len(result['rpt_positive_recognition']) > 0:
            for pid in result['rpt_positive_recognition']:
                result['rpt_pid_pictures'].append(h.execute_sp('rpt_pid_pictures', [pid["ID"], imageUrl, self.lang], self.args))

        #Positive recognition section update to get PID likes
        result['rpt_positive_recognition_likes'] = []
        if len(result['rpt_positive_recognition']) > 0:
            for pid in result['rpt_positive_recognition']:
                result['rpt_positive_recognition_likes'].append(h.execute_sp('rpt_positive_recognition_likes', [pid["ID"], self.lang], self.args))

        #Positive recognition section update to get PID comments
        result['rpt_positive_recognition_comment'] = []
        if len(result['rpt_positive_recognition']) > 0:
            for pid in result['rpt_positive_recognition']:
                result['rpt_positive_recognition_comment'].append(h.execute_sp('rpt_positive_recognition_comment', [pid["ID"], self.lang], self.args))

        #GA section updates as per initial and follow up images    
        result['rpt_get_general_action_attachment_by_sga_id_initial'] = []
        result['rpt_get_general_action_attachment_by_sga_id_followup'] = []
        for gga in result['rpt_get_general_action_by_id']:
            result['rpt_get_general_action_attachment_by_sga_id_initial'].append(h.execute_sp('rpt_get_general_action_attachment_by_sga_id', [gga['sga_id'],imageUrl+'general_action/','INITIAL', self.lang], self.args))
            result['rpt_get_general_action_attachment_by_sga_id_followup'].append(h.execute_sp('rpt_get_general_action_attachment_by_sga_id', [gga['sga_id'],imageUrl+'general_action/','FOLLOWUP', self.lang], self.args))

        #Updating this section to be able to key on original section name    
        rpt_form_details = {}
        for row in result['rpt_form_details']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)

        #Modifying the boolean values to yes or no
        if 'Audit' in rpt_form_details:
            for wc in rpt_form_details['Audit']:
                if (wc['field_key'] == 'info'):
                    if wc['value'] is not None:
                        if ('.jpg' or '.png') in wc['value']:
                            wc['value'] = imageUrl + wc['value']
                if wc['value'] == '1':
                    wc['value'] = wc['yes_value']
                else :
                    if wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '-1':
                        wc['value'] = 'N/A'
                    else:
                        wc['value'] = wc['value']

        if 'Correction & Action Requirements' in rpt_form_details:
            for wc in rpt_form_details['Correction & Action Requirements'] :
                if wc['value'] == '1':
                    wc['value'] = wc['yes_value']
                else :
                    if wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '-1':
                        wc['value'] = 'N/A'
                    else:
                        wc['value'] = wc['value']
        
        result['rpt_form_details'] = rpt_form_details

        return result
    