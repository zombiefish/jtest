#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, id):
        result = {}

        ## Load report-specific configuration
        with open('config/hazard_action_turn_around_time.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['required_args'] = config['required_args']
        result['optional_args'] = config['optional_args'] 
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args']})
        result['args'] = dict(self.args)

        # place the Report Title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [2023,self.lang,1], self.args)[0]['ltr_text']

        # Check if user entered all the required parameters and executing the main SP at line 43
        required_args = config['required_args']
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            start_date=self.args['start_date']     
            end_date=self.args['end_date']
            site_ids = self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            user_ids = self.args['user_ids'] if 'user_ids' in self.args and self.args['user_ids'] != '' else None           
            
            #site_ids 
            site_ids=self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            site_ids_list = site_ids.split(',') if site_ids is not None else []
            site_data_name = {}            
            user_site_data = result['filter_data']['optionalArgs']['site_ids']['field_values']
            if site_ids_list:
                site_data_name = {each['value'] for each in user_site_data if str(each['value']) in site_ids_list}
            else:
                site_data_name = {each['value'] for each in user_site_data}
            
            site_ids = ','.join(map(str, site_data_name))


            #user_ids 
            user_ids=self.args['user_ids'] if 'user_ids' in self.args and self.args['user_ids'] != '' else None
            user_ids_list = user_ids.split(',') if user_ids is not None else []
            user_ids_data_name = {}            
            user_user_ids_data = result['filter_data']['optionalArgs']['user_ids']['field_values']
            if user_ids_list:
                user_ids_data_name = {each['value'] for each in user_user_ids_data if str(each['value']) in user_ids_list}
            else:
                user_ids_data_name = {each['value'] for each in user_user_ids_data}
            
            user_ids = ','.join(map(str, user_ids_data_name))


            sp_inputs = [start_date, end_date, user_ids, site_ids, self.lang]

        # Executing the main SP with all the filter conditions
            result['rpt_hazard_action_turn_around_time'] = h.execute_sp('rpt_hazard_action_turn_around_time', sp_inputs, self.args)  
        
            # result['rpt_hazard_action_turn_around_time'] = h.execute_sp('rpt_hazard_action_turn_around_time', [start_month, end_month, user_ids, site_ids, year, self.lang], self.args)

            if result['rpt_hazard_action_turn_around_time']:
                result['labels'] = {key:value for key, value in result['rpt_hazard_action_turn_around_time'][0].items() if key.endswith('_label')}
                result['overall_stats'], result['action_completion_stats']=  self.edit_data(result['rpt_hazard_action_turn_around_time'], result['labels'])
                result['filtered_report_title'] = result['rpt_hazard_action_turn_around_time'][0]['report_title']
        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result
    
    def edit_data(self, turnaround_data, labels):
        
        overall_stats = dict()        
        action_completion_stats = dict()
        
        
        total_actions_completed = []
        completed_late = []
        completed_on_time = []
        incomplete = []

        for each in turnaround_data:
            # prepare initail table
            if each['action_completed_date'] is not None:
                total_actions_completed.append(each)
            if each['completed_status'] is None:
                incomplete.append(each)
            elif  each['completed_status'] < 0:
                completed_late.append(each)
            elif each['completed_status'] == 0 or each['completed_status'] > 0:                
                completed_on_time.append(each)

        overall_stats['total_actions_assigned'] = len(turnaround_data)         
        overall_stats['total_actions_compelted'] = len(total_actions_completed)

        action_completion_stats[labels['completed_late_label'].capitalize()] = len(completed_late)
        action_completion_stats[labels['completed_on_time_label'].capitalize()] = len(completed_on_time)
        action_completion_stats[labels['incomplete_label'].capitalize()] = len(incomplete)
        
                
        return overall_stats, action_completion_stats


        
            

            
''