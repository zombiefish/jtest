#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/project_risk_assessment.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_pra_header', 'rpt_pra_approved_by', 'rpt_pra_reviewers', 'rpt_pra_threats', 'rpt_pra_general_actions', 'rpt_pra_hap'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)
    
        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures
        #HAP section updates as per initial and follow up images
        result['rpt_hap_pictures_initial']=[]
        result['rpt_hap_pictures_followup']=[]
        
        for hap in result['rpt_pra_hap']:            
            hap['rpt_hap_pictures_initial'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'INITIAL', self.lang], self.args)
            hap['rpt_hap_pictures_followup'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'FOLLOWUP', self.lang], self.args)
            hap['HAP_complete'] = h.execute_sp('rpt_hazard_actions_list_completed', [hap['ID'], self.lang], self.args)

        #GA section updates as per initial and follow up images
        result['rpt_pra_general_action_attachment_by_id_initial'] = []
        result['rpt_pra_general_action_attachment_by_id_followup'] = []
        
        for gga in result['rpt_pra_general_actions']:
            result['rpt_pra_general_action_attachment_by_id_initial'].append(h.execute_sp('rpt_ora_general_action_attachment_by_id', [gga['sga_id'],imageUrl+'general_action/','INITIAL', self.lang], self.args))
            result['rpt_pra_general_action_attachment_by_id_followup'].append(h.execute_sp('rpt_ora_general_action_attachment_by_id', [gga['sga_id'],imageUrl+'general_action/','FOLLOWUP', self.lang], self.args))
            gga['GA_complete'] = h.execute_sp('rpt_get_general_actions_list_completed', [gga['sga_id'], self.lang], self.args)

        #Modifying the data structure as per the threats
        threats = {}
        rpt_pra_threats = result['rpt_pra_threats']
        for step in rpt_pra_threats:
            if step['rmm_pec_element'] not in threats:
                threats[step['rmm_pec_element']] = []
            cm = h.execute_sp('rpt_pra_control_measures', [step['rmm_pth_id'], 'control_measures'], self.args)
            acm = h.execute_sp('rpt_pra_control_measures', [step['rmm_pth_id'], 'additional_control_measures'], self.args)
            step['control_measures'] = cm[0]['ControlMeasures']
            step['additional_control_measures'] = acm[0]['ControlMeasures']
            threats[step['rmm_pec_element']].append(step)

        result['steps'] = threats        

        #Fetching the bowtie details
        result['rpt_ora_pra_bowtie_header']=h.execute_sp('rpt_ora_pra_bowtie_header', [formSubmissionId, 'PRA', self.lang], self.args)
        if len(result['rpt_ora_pra_bowtie_header']) > 0:
            result['rpt_bowtie_approvers']=h.execute_sp('rpt_bowtie_approvers', [result['rpt_ora_pra_bowtie_header'][0]["rmm_bow_id"], self.lang], self.args)
            result['rpt_bowtie_participants']=h.execute_sp('rpt_bowtie_participants', [result['rpt_ora_pra_bowtie_header'][0]["rmm_bow_id"]], self.args)

        
        result['rpt_get_pra_attachment_pra_id'] = h.execute_sp('rpt_get_pra_attachment_pra_id', [formSubmissionId, imageUrl, self.lang], self.args)

        result['rpt_get_pra_attachment_pra_id'] = h.file_extention_attachments(result['rpt_get_pra_attachment_pra_id'])
        
        return result
    