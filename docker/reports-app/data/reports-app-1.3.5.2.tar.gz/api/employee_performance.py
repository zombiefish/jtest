#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/employee_performance.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:
            if sp == 'rpt_employee_performance_legend':
                result[sp] = h.execute_sp(sp, [self.lang])
            else :
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
    
        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures
        result['rpt_form_pictures_employee'] = h.execute_sp('rpt_form_pictures', [formSubmissionId, imageUrl, 'signature_employee'], self.args)
        result['rpt_form_pictures_reviewer'] = h.execute_sp('rpt_form_pictures', [formSubmissionId, imageUrl, 'signature_reviewer'], self.args)

        result['labels'] = {
            "evaluation_period_label" : h.execute_sp('get_translation_by_tag', [2188, self.lang, 1], self.args)[0]['ltr_text'],
        }

        rpt_form_details = {}
        for row in result['rpt_form_details_performance']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)
        
        if 'Signatures' in rpt_form_details:
            for wc in rpt_form_details['Signatures']:
                if ('.jpg' in wc['value']) or ('.png' in wc['value']) or ('.jpeg' in wc['value']):
                    wc['value'] = imageUrl + wc['value']

        result['rpt_form_details'] = rpt_form_details

        return result
    