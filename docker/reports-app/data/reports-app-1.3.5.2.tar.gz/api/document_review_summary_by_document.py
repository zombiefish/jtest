import yaml
import helper as h
import pandas as pd
import json
class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId = None):
        result = {}

        ## Load report-specific configuration
        with open('config/document_review_summary.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['required_args'] = config['required_args']
        result['optional_args'] = config['optional_args'] if 'optional_args' in config and config['optional_args'] is not None else []
        result['filter_data'] = h.get_filter_data({'required_args': result['required_args'], 'lang': self.lang, 'optional_args': result['optional_args'], 'report_slug':config['header']['slug']})        
        result['args'] = dict(self.args)
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [9070,self.lang, 1], self.args)[0]['ltr_text']
       
        # Check if user entered all the required parameters
        required_args = config['required_args']

        
        report_Selection = result['args']['report_selection']

        if report_Selection == '99':
            required_args.remove('user_ids')

        ## Getting all the filters to populate data in the reports
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            date1=self.args['start_date']     
            date2=self.args['end_date']
            site_ids = self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            doc_names = self.args['doc_names'] if 'doc_names' in self.args and self.args['doc_names'] != '' else None
            allRecs=[]
            
            #Doc_ids 
            doc_ids=self.args['doc_ids'] if 'doc_ids' in self.args and self.args['doc_ids'] != '' else None
            
            ## Adding labels with translations
            result['labels'] = {
                "signing_name_label": h.execute_sp('get_translation_by_tag', [649,self.lang,1], self.args)[0]['ltr_text'],
                "position_label": h.execute_sp('get_translation_by_tag', [1277,self.lang,1], self.args)[0]['ltr_text'],
                "date_label": h.execute_sp('get_translation_by_tag', [124,self.lang,1], self.args)[0]['ltr_text'],
                "reviewers_label": h.execute_sp('get_translation_by_tag', [1348,self.lang,1], self.args)[0]['ltr_text'],
                "document_type_label": h.execute_sp('get_translation_by_tag', [1347,self.lang,1], self.args)[0]['ltr_text'],
                "created_date_label": h.execute_sp('get_translation_by_tag', [1305,self.lang,1], self.args)[0]['ltr_text'],
                "to_be_reviewed_by_label": h.execute_sp('get_translation_by_tag', [2098,self.lang,1], self.args)[0]['ltr_text'],
                "due_date_label": h.execute_sp('get_translation_by_tag', [1323,self.lang,1], self.args)[0]['ltr_text'],
                "expiry_date_label": h.execute_sp('get_translation_by_tag', [1262,self.lang,1], self.args)[0]['ltr_text'],
                "reviewed_label": h.execute_sp('get_translation_by_tag', [2443,self.lang,1], self.args)[0]['ltr_text'],
                "review_overdue_label" : h.execute_sp('get_translation_by_tag', [9045, self.lang, 1],self.args)[0]['ltr_text'],
                "review_due_label" : h.execute_sp('get_translation_by_tag', [9044, self.lang, 1], self.args)[0]['ltr_text'],
                "non_expiring_document_label" : h.execute_sp('get_translation_by_tag', [1350, self.lang, 1], self.args)[0]['ltr_text']

        }

            ## Executing the main SP by passing all the filters
            rpt_document_review_summary_by_document = h.execute_sp('rpt_document_review_summary_by_document', [date1, date2, doc_ids, site_ids, self.lang,doc_names], self.args)
            result['rpt_document_review_summary_by_document'] = rpt_document_review_summary_by_document                   
            

            rpt_document_review_summary_by_document = {}      
            for row in result['rpt_document_review_summary_by_document']:
                if row['drm_id'] not in rpt_document_review_summary_by_document:
                    rpt_document_review_summary_by_document[row['drm_id']] = []
                rpt_document_review_summary_by_document[row['drm_id']].append(row)            

            result['rpt_document_review_summary_by_document'] = rpt_document_review_summary_by_document

            rpt_document_review_summary_by_document = {}
            for key,values in result['rpt_document_review_summary_by_document'].items():
                rpt_document_review_reviewers = {}
                for value in values:
                    if value['ReviewStatus'] not in rpt_document_review_reviewers:
                        rpt_document_review_reviewers[value['ReviewStatus']] = []
                    rpt_document_review_reviewers[value['ReviewStatus']].append(value)
                rpt_document_review_summary_by_document[key] = rpt_document_review_reviewers
            
            result['rpt_document_review_summary_by_document'] = rpt_document_review_summary_by_document

                    
                    
        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result
    