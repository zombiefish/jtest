import yaml
import helper as h
import pandas as pd
import json
class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId=None):
        result = {}

        ## Load report-specific configuration
        with open('config/document_review_summary.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['required_args'] = config['required_args']
        result['optional_args'] = config['optional_args'] 
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args'], 'report_slug':config['header']['slug']})        
        result['args'] = dict(self.args)
       
        report_Selection = result['args']['report_selection']
        

        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [2444,self.lang, 1], self.args)[0]['ltr_text']
       
        # Check if user entered all the required parameters
        required_args = list(config['required_args'])
        
        if report_Selection == '89':
            required_args.remove('user_ids')

            
        result['summary_table'] = {}

        ## Getting all the filters to populate data in the reports
        
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            date1=self.args['start_date']        
            date2=self.args['end_date']
            site_ids = self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            allRecs=[]
            
            #Doc_ids 
            doc_ids=self.args['doc_ids'] if 'doc_ids' in self.args and self.args['doc_ids'] != '' else None
            
            ## Adding labels with translations
            result['labels'] = {
                "document_type": h.execute_sp('get_translation_by_tag', [1347,self.lang,1], self.args)[0]['ltr_text'],
                "document_count": h.execute_sp('get_translation_by_tag', [2440,self.lang,1], self.args)[0]['ltr_text'],
                "document_reviewers": h.execute_sp('get_translation_by_tag', [1348,self.lang,1], self.args)[0]['ltr_text'],
                "document_total": h.execute_sp('get_translation_by_tag', [1044,self.lang,1], self.args)[0]['ltr_text'],
                "document_complete": h.execute_sp('get_translation_by_tag', [2045,self.lang,1], self.args)[0]['ltr_text'],
                "document_due": h.execute_sp('get_translation_by_tag', [1047,self.lang,1], self.args)[0]['ltr_text'],
                "document_overdue": h.execute_sp('get_translation_by_tag', [1048,self.lang,1], self.args)[0]['ltr_text'],
                "document_required": h.execute_sp('get_translation_by_tag', [2441,self.lang,1], self.args)[0]['ltr_text'],
                "document_reviewed": h.execute_sp('get_translation_by_tag', [2443,self.lang,1], self.args)[0]['ltr_text'],
                "document_completion": h.execute_sp('get_translation_by_tag', [1043,self.lang,1], self.args)[0]['ltr_text'],
                "nochart" : h.execute_sp('get_translation_by_tag', [8870, self.lang, 1],self.args)[0]['ltr_text'],
                "description_label" : h.execute_sp('get_translation_by_tag', [143, self.lang, 1], self.args)[0]['ltr_text']

        }

            ## Executing the main SP by passing all the filters
            rpt_document_review_summary_by_site = h.execute_sp('rpt_document_review_summary_by_site', [date1, date2, doc_ids, site_ids, self.lang], self.args)
            result['rpt_document_review_summary_by_site'] = rpt_document_review_summary_by_site

            inactive_label = h.execute_sp('get_translation_by_tag', [9169,self.lang,1], self.args)[0]['ltr_text']

            for data in result['rpt_document_review_summary_by_site']:
                if data['site_enable_status'] == 0:
                    data['Site'] = data['Site'] + ' ' + inactive_label
                if data['doc_type_status'] == 0:
                    data['DocType'] = data['DocType'] + ' ' + inactive_label


            df = pd.DataFrame(rpt_document_review_summary_by_site)
            
            ## Creating a new dataframe to create a data structure grouped by site, document type and total number of documents)
            if ('DocType' in df) and ('Site' in df):   
                df_final = df.copy()        
                summary_table = {}
                summary_table['sites'] = {}
                summary_table['totals'] = {}
                for i, row in df_final.iterrows():                              
                    if row['Site'] not in summary_table['sites']:
                        summary_table['sites'][row['Site']] = {}                        
                        summary_table['totals'][row['Site']] = []
                    if row['DocType'] not in summary_table['sites'][row['Site']]:
                        summary_table['sites'][row['Site']][row['DocType']] = []
                    summary_table['sites'][row['Site']][row['DocType']].append({
                        'DocType': row['DocType'],
                        'Total': row['Total'],
                        'Complete': row['Complete'],
                        'Due': row['Due'],
                        'DocsOverdue': row['DocsOverdue'],
                        'Required': row['Required'],
                        'Overdue': row['Overdue'],
                        'Reviewed': row['Reviewed'],
                        'percentvalue': row['percentvalue'],
                        'drm_description': row['drm_description']                        
                    })
                    summary_table['totals'][row['Site']].append(row['Total'])
                
                df_summary = df_final.groupby(['Site']).agg({
                    'Total':'sum',
                    'Complete':'sum',
                    'Due': 'sum',
                    'DocsOverdue': 'sum',
                    'Required': 'sum',
                    'Overdue': 'sum',
                    'Reviewed': 'sum'
                })                
                summary_table['grand_total'] = json.loads(df_summary.to_json(orient='index'))

                for site in summary_table['totals'].keys():
                    summary_table['totals'][site] = sum(summary_table['totals'][site])
                
                for site in summary_table['sites'].keys():                    
                    for doc_type in summary_table['sites'][site].keys():      
                        summary_table['sites'][site][doc_type][0]['doc_type_total'] = len(summary_table['sites'][site][doc_type])                        
                
                result['summary_table'] = summary_table

        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result