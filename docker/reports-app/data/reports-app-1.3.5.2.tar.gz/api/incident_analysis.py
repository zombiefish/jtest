#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/incident_analysis.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_header_root_cause_analysis_by_rca_id','rpt_root_cause_analysis_immed_causes','rpt_root_cause_analysis_basic_causes','rpt_root_cause_analysis_by_id','rpt_incident_analysis_reviewers'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
    

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['args'] = dict(self.args)
               
        return result
    