#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/confined_space_activity_log.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_form_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id','rpt_hazard_actions','rpt_form_details_distribution','rpt_form_reviewers','rpt_hot_work_permit_air_quality_test', 'rpt_confined_space_employee_log'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)  

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures
        h.get_hazard_actions(result['rpt_hazard_actions'], imageUrl, self.args, self.lang)
        h.get_general_actions(result['rpt_get_general_action_by_id'], imageUrl, self.args, self.lang)
        h.get_positive_recognitions(result['rpt_positive_recognition'], imageUrl, self.args, self.lang)


        #Updating this section to be able to key on original section name     
        rpt_form_details = {}
        gas = None
        for row in result['rpt_form_details']:
            #print(row)
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)
            
            if 'test_' in row['field_key'] and '_gas_' in row['field_key']: 
                row['field_name'] = row['value']
        
        templist1 = []
        
        if '1' in rpt_form_details:
            for gasRow in rpt_form_details['1']:
                if 'test_' in gasRow['field_key'] and '_ppm_' in gasRow['field_key']:
                    gasdata = gasRow['field_key'].split("_")
                    gas = "test_" + str(gasdata[1]) + "_gas_" + str(gasdata[3])
                    ppm = gasRow['value']
                    for gasValue in result['rpt_form_details']:
                        if gasValue['field_key'] == gas:
                            gasValue['value'] =  ppm
                else:
                    templist1.append(gasRow)
                    
            rpt_form_details['1'] = templist1

        templist2 = []
        if '2' in rpt_form_details:
            for gasRow in rpt_form_details['2']:
                if 'test_' in gasRow['field_key'] and '_ppm_' in gasRow['field_key']:
                    gasdata = gasRow['field_key'].split("_")
                    gas = "test_" + str(gasdata[1]) + "_gas_" + str(gasdata[3])
                    ppm = gasRow['value']
                    for gasValue in result['rpt_form_details']:
                        if gasValue['field_key'] == gas:
                            gasValue['value'] =  ppm
                else:
                    templist2.append(gasRow)
                    
            rpt_form_details['2'] = templist2

        templist3 = []
        if '3' in rpt_form_details:
            for gasRow in rpt_form_details['3']:
                if 'test_' in gasRow['field_key'] and '_ppm_' in gasRow['field_key']:
                    gasdata = gasRow['field_key'].split("_")
                    gas = "test_" + str(gasdata[1]) + "_gas_" + str(gasdata[3])
                    ppm = gasRow['value']
                    for gasValue in result['rpt_form_details']:
                        if gasValue['field_key'] == gas:
                            gasValue['value'] =  ppm
                else:
                    templist3.append(gasRow)
                    
            rpt_form_details['3'] = templist3
        
        templist4 = []
        if '4' in rpt_form_details:
            for gasRow in rpt_form_details['4']:
                if 'test_' in gasRow['field_key'] and '_ppm_' in gasRow['field_key']:
                    gasdata = gasRow['field_key'].split("_")
                    gas = "test_" + str(gasdata[1]) + "_gas_" + str(gasdata[3])
                    ppm = gasRow['value']
                    for gasValue in result['rpt_form_details']:
                        if gasValue['field_key'] == gas:
                            gasValue['value'] =  ppm
                else:
                    templist4.append(gasRow)
                    
            rpt_form_details['4'] = templist4

        templist5 = []
        if '5' in rpt_form_details:
            for gasRow in rpt_form_details['5']:
                if 'test_' in gasRow['field_key'] and '_ppm_' in gasRow['field_key']:
                    gasdata = gasRow['field_key'].split("_")
                    gas = "test_" + str(gasdata[1]) + "_gas_" + str(gasdata[3])
                    ppm = gasRow['value']
                    for gasValue in result['rpt_form_details']:
                        if gasValue['field_key'] == gas:
                            gasValue['value'] =  ppm
                else:
                    templist5.append(gasRow)
                    
            rpt_form_details['5'] = templist5

        templist6 = []
        if '6' in rpt_form_details:
            for gasRow in rpt_form_details['6']:
                if 'test_' in gasRow['field_key'] and '_ppm_' in gasRow['field_key']:
                    gasdata = gasRow['field_key'].split("_")
                    gas = "test_" + str(gasdata[1]) + "_gas_" + str(gasdata[3])
                    ppm = gasRow['value']
                    for gasValue in result['rpt_form_details']:
                        if gasValue['field_key'] == gas:
                            gasValue['value'] =  ppm
                else:
                    templist6.append(gasRow)
                    
            rpt_form_details['6'] = templist6

        result['rpt_form_details'] = rpt_form_details

        #Fetching the report specific images from the rpt_form_pictures SP
        result['rpt_form_pictures'] = h.execute_sp('rpt_form_pictures', [formSubmissionId, imageUrl, 'entry_confined_space'], self.args)
    
        return result
     
