#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/loto.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_form_header','rpt_loto_details','rpt_loto_additional_details','rpt_form_details', 'rpt_form_header','rpt_form_reviewers','rpt_form_details_distribution','rpt_get_general_action_by_id','rpt_hazard_actions','rpt_loto_mechanisms'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            elif sp in ('rpt_positive_recognition'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang, False], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)
    

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        h.get_hazard_actions(result['rpt_hazard_actions'], imageUrl, self.args, self.lang) 
        h.get_general_actions(result['rpt_get_general_action_by_id'], imageUrl, self.args, self.lang)
        h.get_positive_recognitions(result['rpt_positive_recognition'], imageUrl, self.args, self.lang)
                


        #Updating this section to be able to key on original section name  
        rpt_form_details = {}
        for row in result['rpt_form_details']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)

        # Mechanisms table
        accessories_list = []
        ppe_list = []
        accessories=[]
        ppe = []
        existing_accessories = dict()
        existing_ppe = dict()
        for row in result['rpt_loto_mechanisms']:
            if row['accessories']:
                accessories = row['accessories'].split(',')
            for a in accessories:
                if a in existing_accessories:
                    ItemNumber = existing_accessories[a]
                else:
                    ItemNumber = existing_accessories[a] = len(accessories_list)
                    accessories_list.append(a)

            if row['ppe']:
                ppe = row['ppe'].split(',')
            for a in ppe:
                if a in existing_ppe:
                    ItemNumber = existing_ppe[a]
                else:
                    ItemNumber = existing_ppe[a] = len(ppe_list)
                    ppe_list.append(a)
        
        lockout_devices = result['rpt_loto_mechanisms'][0]['lockout_devices'].split(',')
        mech_list = []
        my_dict = {i:lockout_devices.count(i) for i in lockout_devices}
        for key,value in my_dict.items():
            if value == 1:
                mech_list.append(key)
            else:
                mech_list.append(str(value) + ' ' + key)
        
        result['rpt_loto_mechanisms'] = {
            'lockout_devices': ', '.join(mech_list),
            'accessories': ', '.join(accessories_list),
            'ppe': ', '.join(ppe_list),
            'mechanisms_section_title':result['rpt_loto_mechanisms'][0]['mechanisms_section_title'],
            'lockout_devices_label':result['rpt_loto_mechanisms'][0]['lockout_devices_label'],
            'special_ppe_label':result['rpt_loto_mechanisms'][0]['special_ppe_label'],
            'accessories_label':result['rpt_loto_mechanisms'][0]['accessories_label']
        }

        if 'equipment_picture' in result['rpt_loto_additional_details'][0]:
            if result['rpt_loto_additional_details'][0]['equipment_picture'] is not None:
                result['rpt_loto_additional_details'][0]['equipment_picture'] = imageUrl + 'loto_equipment_attachments/' + result['rpt_loto_additional_details'][0]['equipment_picture']

        for step in result['rpt_loto_details']:
            if step['step_picture'] is not None:
                step['step_picture'] = imageUrl + 'loto_equipment_attachments/' + step['step_picture']

        result['rpt_form_details'] = rpt_form_details
        
        return result
    