#Import important libraries for the report to load
import yaml
import helper as h
import pandas as pd
import json


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId):
        result = {}

        ## Load report-specific configuration
        with open('config/emergency_contact.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['filter'] = config['filter']
        result['required_args'] = config['required_args']       
        result['optional_args'] = config['optional_args']
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args': config['optional_args']})    
        result['args'] = dict(self.args)

        ## Get the Report Title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [3438,self.lang,1], self.args)[0]['ltr_text']
        
        # get the Lables
        result['report_labels'] = {
                "employee_name_label" : h.execute_sp('get_translation_by_tag', [204, self.lang, 1], self.args)[0]['ltr_text'],
                "employee_number_label" : h.execute_sp('get_translation_by_tag', [190, self.lang, 1], self.args)[0]['ltr_text'],
                "training_code_label" : h.execute_sp('get_translation_by_tag', [2587, self.lang, 1], self.args)[0]['ltr_text'],
                "training_institution_label" : h.execute_sp('get_translation_by_tag', [2588, self.lang, 1], self.args)[0]['ltr_text'],
                "description_label" : h.execute_sp('get_translation_by_tag', [143, self.lang, 1], self.args)[0]['ltr_text'],
                "certification_date_label" : h.execute_sp('get_translation_by_tag', [1294, self.lang, 1], self.args)[0]['ltr_text'],
                "expiration_date_label" : h.execute_sp('get_translation_by_tag', [1295, self.lang, 1], self.args)[0]['ltr_text'],
                "no_expired_records_label" : h.execute_sp('get_translation_by_tag', [8872, self.lang, 1], self.args)[0]['ltr_text'],
                "value_label" : h.execute_sp('get_translation_by_tag', [1243, self.lang, 1], self.args)[0]['ltr_text'],
                "address_label" : h.execute_sp('get_translation_by_tag', [1271, self.lang, 1], self.args)[0]['ltr_text'],
                "employee_id_label" : h.execute_sp('get_translation_by_tag', [1265, self.lang, 1], self.args)[0]['ltr_text'],
                "email_label" : h.execute_sp('get_translation_by_tag', [1270, self.lang, 1], self.args)[0]['ltr_text'],
                "role_label" : h.execute_sp('get_translation_by_tag', [1245, self.lang, 1], self.args)[0]['ltr_text'],
                "phone_label" : h.execute_sp('get_translation_by_tag', [1757, self.lang, 1], self.args)[0]['ltr_text'],
                "emergency_contact_label" : h.execute_sp('get_translation_by_tag', [3438, self.lang, 1], self.args)[0]['ltr_text'],
                "name_label" : h.execute_sp('get_translation_by_tag', [649, self.lang, 1], self.args)[0]['ltr_text'],
                "relationship_label" : h.execute_sp('get_translation_by_tag', [2845, self.lang, 1], self.args)[0]['ltr_text'],
                "mobile_phone_label" : h.execute_sp('get_translation_by_tag', [3290, self.lang, 1], self.args)[0]['ltr_text'],
                "work_phone_label" : h.execute_sp('get_translation_by_tag', [3291, self.lang, 1], self.args)[0]['ltr_text'],
                "home_phone_label" : h.execute_sp('get_translation_by_tag', [3292, self.lang, 1], self.args)[0]['ltr_text'],
                "employee_information_label" : h.execute_sp('get_translation_by_tag', [1629, self.lang, 1], self.args)[0]['ltr_text']
                }

        #Checking if all the filter conditions are provided
        # Check if user entered all the required parameters
        required_args = config['required_args']
        optional_args = config['optional_args']
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            
            per_ids = self.args['per_ids'] 
            job_ids = self.args['job_ids'] if 'job_ids' in self.args and self.args['job_ids'] != '' else None
            site_ids = self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            site_ids=self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            job_ids=self.args['job_ids'] if 'job_ids' in self.args and self.args['job_ids'] != '' else None

            
            sp_inputs = [site_ids,job_ids,per_ids,self.lang]
           
            result['rpt_emergency_contact'] = h.execute_sp('rpt_emergency_contact', sp_inputs, self.args)
        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result
