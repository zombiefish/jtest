#Import important libraries for the report to load
import yaml
import helper as h
import pandas


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/work_card.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_form_details', 'rpt_form_header', 'rpt_form_details_distribution','rpt_form_reviewers','rpt_work_card_workarea','rpt_work_card_ground_support','rpt_positive_recognition','rpt_get_general_action_by_id', 'rpt_hazard_actions_list'  ):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args) 

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)

        ##Calling SP to generate report labels
        result['report_labels'] = {
            "details_label" : h.execute_sp('get_translation_by_tag', [2097, self.lang, 1], self.args)[0]['ltr_text'],
            "inspection_label" : h.execute_sp('get_translation_by_tag', [1665, self.lang, 1], self.args)[0]['ltr_text'],
            "surface_type_label" : h.execute_sp('get_translation_by_tag', [9182, self.lang, 1], self.args)[0]['ltr_text'],
            "review_of_work_label" : h.execute_sp('get_translation_by_tag', [8531, self.lang, 1], self.args)[0]['ltr_text'],
            "materials_req_label" : h.execute_sp('get_translation_by_tag', [8619, self.lang, 1], self.args)[0]['ltr_text'],
            "work_card_type_label" : h.execute_sp('get_translation_by_tag', [8494, self.lang, 1], self.args)[0]['ltr_text'],
        }

        ## Load parameterized Stored Procedures
        #HAP section updates as per initial and follow up images
        result['rpt_hap_pictures_initial'] = []
        result['rpt_hap_pictures_followup'] = []

        for hap in result['rpt_hazard_actions_list']:
            result['rpt_hap_pictures_initial'].append(h.execute_sp('rpt_hap_pictures', [hap['ID0a___Submission_HAP_ID'], imageUrl, 'INITIAL', self.lang], self.args))
            result['rpt_hap_pictures_followup'].append(h.execute_sp('rpt_hap_pictures', [hap['ID0a___Submission_HAP_ID'], imageUrl, 'FOLLOWUP', self.lang], self.args))
    
        #Positive recognition section update to get images and data
        result['rpt_pid_pictures'] = []
        if len(result['rpt_positive_recognition']) > 0:
            for pid in result['rpt_positive_recognition']:
                result['rpt_pid_pictures'].append(h.execute_sp('rpt_pid_pictures', [pid["ID"], imageUrl, self.lang], self.args))

        #Positive recognition section update to get PID likes
        result['rpt_positive_recognition_likes'] = []
        if len(result['rpt_positive_recognition']) > 0:
            for pid in result['rpt_positive_recognition']:
                result['rpt_positive_recognition_likes'].append(h.execute_sp('rpt_positive_recognition_likes', [pid["ID"], self.lang], self.args))

        #Positive recognition section update to get PID comments
        result['rpt_positive_recognition_comment'] = []
        if len(result['rpt_positive_recognition']) > 0:
            for pid in result['rpt_positive_recognition']:
                result['rpt_positive_recognition_comment'].append(h.execute_sp('rpt_positive_recognition_comment', [pid["ID"], self.lang], self.args))

        #GA section updates as per initial and follow up images    
        result['rpt_get_general_action_attachment_by_sga_id_initial'] = []
        result['rpt_get_general_action_attachment_by_sga_id_followup'] = []
        for gga in result['rpt_get_general_action_by_id']:
            result['rpt_get_general_action_attachment_by_sga_id_initial'].append(h.execute_sp('rpt_get_general_action_attachment_by_sga_id', [gga['sga_id'],imageUrl+'general_action/','INITIAL', self.lang], self.args))
            result['rpt_get_general_action_attachment_by_sga_id_followup'].append(h.execute_sp('rpt_get_general_action_attachment_by_sga_id', [gga['sga_id'],imageUrl+'general_action/','FOLLOWUP', self.lang], self.args))

        #Updating this section to be able to key on original section name       
        rpt_form_details = {}
        for row in result['rpt_form_details']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)

        if 'Shift' in rpt_form_details:
            for wc in rpt_form_details['Shift']:
                if (wc['field_key'] in ['shift']):
                    wc['value'] = wc['translated_value']

        if 'Access to Worksite' in rpt_form_details:
            for wc in rpt_form_details['Access to Worksite']:
                if (wc['field_key'] in ['personal_safety_equipment','blasting_box','scaling','ventilation_work_site','open_holes','cleanliness_work_site','visibility']):
                    wc['value'] = wc['translated_value3']
        
        #Creating the image URL as per the report specific section
        if 'Shift Start Workplace Conditions' in rpt_form_details:
            for wc in rpt_form_details['Shift Start Workplace Conditions']:
                if wc['value'] is not None:
                    if ('.jpg' or '.png') in wc['value']:
                        wc['value'] = imageUrl + wc['value']

        if 'Shift End Workplace Conditions' in rpt_form_details:
            for wc in rpt_form_details['Shift End Workplace Conditions']:
                if wc['value'] is not None:
                    if ('.jpg' or '.png') in wc['value']:
                        wc['value'] = imageUrl + wc['value']

        if 'Signature' in rpt_form_details:
            for wc in rpt_form_details['Signature']:
                if wc['value'] is not None:
                    wc['value'] = imageUrl + wc['value']

        #Modifying the boolean values to yes or no
        if 'Supervisor Visit' in rpt_form_details:
            for wc in rpt_form_details['Supervisor Visit'] :
                if wc['value'] == '1':
                    wc['value'] = wc['yes_value']
                else :
                    if wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '-1':
                        wc['value'] = 'N/A'
                    else:
                        wc['value'] = wc['value']

        if 'Planning' in rpt_form_details:
            for wc in rpt_form_details['Planning'] :
                if wc['value'] == '1':
                    wc['value'] = wc['yes_value']
                else :
                    if wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '-1':
                        wc['value'] = 'N/A'
                    else:
                        wc['value'] = wc['value']

        if 'Decision' in rpt_form_details:
            for wc in rpt_form_details['Decision'] :
                if wc['value'] == '1':
                    wc['value'] = wc['yes_value']
                else :
                    if wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '-1':
                        wc['value'] = 'N/A'
                    else:
                        wc['value'] = wc['value']

        if 'Decision' in rpt_form_details:
            for wc in rpt_form_details['Decision']:
                if wc['value'] is not None:
                    if ('.jpg' or '.png') in wc['value']:
                        wc['value'] = imageUrl + wc['value']

        if 'Execution' in rpt_form_details:
            for wc in rpt_form_details['Execution'] :
                if wc['value'] == '1':
                    wc['value'] = wc['yes_value']
                else :
                    if wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '-1':
                        wc['value'] = 'N/A'
                    else:
                        wc['value'] = wc['value']

        if 'Execution' in rpt_form_details:
            for wc in rpt_form_details['Execution']:
                if wc['value'] is not None:
                    if ('.jpg' or '.png') in wc['value']:
                        wc['value'] = imageUrl + wc['value']

        if 'Drilling and Loading' in rpt_form_details:
            for wc in rpt_form_details['Drilling and Loading'] :
                if wc['value'] == '1':
                    wc['value'] = wc['yes_value']
                else :
                    if wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '-1':
                        wc['value'] = 'N/A'
                    else:
                        wc['value'] = wc['value']
        
        if 'Access to Worksite' in rpt_form_details:
            for wc in rpt_form_details['Access to Worksite']:
                tvalue = ()
                if wc['value'] == '8503':
                    wc['value'] = tvalue
                elif wc['value'] is None:
                    if wc['translated_value'] is not None:
                        wc['value'] = wc['translated_value']
                    elif wc['translated_value2'] is not None:
                        wc['value'] = wc['translated_value2']
                    elif wc['translated_value3'] is not None:
                        wc['value'] = wc['translated_value3']
                else :
                    if wc['value'] == '8502':
                        wc['value'] = tvalue 
                    elif wc['value'] == '8504':
                        wc['value'] = tvalue 
                    elif wc['value'] == '3914':
                        wc['value'] = tvalue
                    elif wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '1':
                        wc['value'] = wc['yes_value'] 
                    else:
                        wc['value'] = wc['value']
        
        if 'Access to the workplace' in rpt_form_details:
            for wc in rpt_form_details['Access to the workplace'] :
                if wc['value'] == '8503':
                    wc['value'] = wc['translated_value3']
                else :
                    if wc['value'] == '8502':
                        wc['value'] = wc['translated_value3'] 
                    elif wc['value'] == '8504':
                        wc['value'] = wc['translated_value3'] 
                    elif wc['value'] == '3914':
                        wc['value'] = wc['translated_value3']
                    elif wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '1':
                        wc['value'] = wc['yes_value'] 
                    else:
                        wc['value'] = wc['value']

        if 'Method of work' in rpt_form_details:
            for wc in rpt_form_details['Method of work'] :
                if wc['value'] == '8503':
                    wc['value'] = wc['translated_value3']
                else :
                    if wc['value'] == '8502':
                        wc['value'] = wc['translated_value3'] 
                    elif wc['value'] == '8504':
                        wc['value'] = wc['translated_value3'] 
                    elif wc['value'] == '3914':
                        wc['value'] = wc['translated_value3']
                    elif wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '1':
                        wc['value'] = wc['yes_value'] 
                    else:
                        wc['value'] = wc['value']
        
        if 'Workplace' in rpt_form_details:
            for wc in rpt_form_details['Workplace'] :
                if wc['value'] == '8503':
                    wc['value'] = wc['translated_value3']
                else :
                    if wc['value'] == '8502':
                        wc['value'] = wc['translated_value3'] 
                    elif wc['value'] == '8504':
                        wc['value'] = wc['translated_value3'] 
                    elif wc['value'] == '3914':
                        wc['value'] = wc['translated_value3']
                    elif wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '1':
                        wc['value'] = wc['yes_value'] 
                    else:
                        wc['value'] = wc['value']

        if 'Work Area' in rpt_form_details:
            for wc in rpt_form_details['Work Area'] :
                if wc['value'] == '8503':
                    wc['value'] = wc['translated_value3']
                else :
                    if wc['value'] == '8502':
                        wc['value'] = wc['translated_value3'] 
                    elif wc['value'] == '8504':
                        wc['value'] = wc['translated_value3'] 
                    elif wc['value'] == '3914':
                        wc['value'] = wc['translated_value3']
                    elif wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '1':
                        wc['value'] = wc['yes_value'] 
                    else:
                        wc['value'] = wc['value']

        if 'Tasks to do' in rpt_form_details:
            for wc in rpt_form_details['Tasks to do'] :
                if wc['value'] == '1':
                    wc['value'] = wc['yes_value']
                else :
                    if wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '-1':
                        wc['value'] = 'N/A'
                    else:
                        wc['value'] = wc['value']
        
        result['rpt_form_details'] = rpt_form_details

        field_keys = h.execute_sp('rpt_form_field_keys', [1412, self.lang], self.args)

        df_keys = pandas.DataFrame(field_keys)
        section_df =  df_keys.groupby('original_section_name').apply(lambda x: x.to_dict('records')).to_dict() #DB 

        underground_planning_keys = ['first_visit','second_visit','biggest_risk_today','to_control','plan_number','specification_type','plans_correspond',
        'plans_understood','biggest_risk_today','to_control']
        surface_planning_keys = ['new_guideline','daily_safety_act','future_specific_risk','corrective_action','exchange_work','specific_work_procedure_planning']

    
        report_type = ''
        if 'Access to the workplace' in result['rpt_form_details']:
            report_type = 'surface'
        elif 'Access to Worksite' in result['rpt_form_details']:
            report_type = 'underground'

        result['report_type'] = report_type
         
        drilling_loading_data = []
        for section,data in result['rpt_form_details'].items(): 
            
            if section == 'Drilling and Loading':
                for val in data:
                    if val['field_key'] in ['placement_of_holes', 'station_number','station_distance', 'anfo','stick_powder','emulsion']:
                        drilling_loading_data.append(val)
                    if val['field_key'] == 'anfo' and val['original_value']:
                        drilling_loading_data.append(next(key for key in data if key['field_key'] == 'quantity_and_type_anfo'))

                    if val['field_key'] == 'stick_powder' and val['original_value']:
                        drilling_loading_data.append(next(key for key in data if key['field_key'] == 'quantity_and_type_powder'))

                    if val['field_key'] == 'emulsion' and val['original_value']:
                        drilling_loading_data.append(next(key for key in data if key['field_key'] == 'quantity_and_type_emulsion'))
                    

            if section == 'Planning':
                for val in data:
                    '''
                    if work_card_type = surface and field_key in surface_planning_keys
                    '''
                    data_key_list = [each['field_key'] for each in data] #field_key from rpt_form_details

                    if report_type == 'underground':
                        field_keys_list = {each['fieldKey']:{'fieldName':each['fieldName'],'FieldOrder': each['FieldOrder']} for each in section_df[section] if each['fieldKey'] not in surface_planning_keys} #field_key from DB

                    elif report_type == 'surface':
                        field_keys_list = {each['fieldKey']:{'fieldName':each['fieldName'],'FieldOrder': each['FieldOrder']} for each in section_df[section] if each['fieldKey'] not in underground_planning_keys} #field_key from DB

                    for field_key in field_keys_list:      

                        if field_key not in data_key_list  :
                            data.append(
                                {
                                    "field_key":field_key,
                                    "field_name":field_keys_list[field_key]['fieldName'],
                                    "value":' ',
                                    "field_order":field_keys_list[field_key]['FieldOrder']
                                }
                            )                       
        result['rpt_form_details']['Planning'] = sorted(result['rpt_form_details']['Planning'], key=lambda d:d['field_order'])
        result['rpt_form_details']['Drilling and Loading'] = sorted(drilling_loading_data, key=lambda d:d['field_order'])


        return result
    
   