import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/decision_log.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_get_decision_log_by_dlm_id','rpt_get_decision_log_general_actions_by_id','rpt_get_decision_log_hazard_actions', 'rpt_get_decision_log_reviewers_by_dlm_id'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures
        #HAP section updates as per initial and follow up images
        result['rpt_hap_pictures_initial'] = []
        result['rpt_hap_pictures_followup'] = []      
        for hap in result['rpt_get_decision_log_hazard_actions']:
            hap['rpt_hap_pictures_initial'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'INITIAL', self.lang], self.args)
            hap['rpt_hap_pictures_followup'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'FOLLOWUP', self.lang], self.args)
            hap['HAP_complete'] = h.execute_sp('rpt_hazard_actions_list_completed', [hap['ID'], self.lang], self.args)


        #GA section updates as per initial and follow up images
        result['rpt_get_decision_log_general_action_attachment_by_id_initial'] = []
        result['rpt_get_decision_log_general_action_attachment_by_id_followup'] = []
        for gga in result['rpt_get_decision_log_general_actions_by_id']:
            result['rpt_get_decision_log_general_action_attachment_by_id_initial'].append(h.execute_sp('rpt_get_decision_log_general_action_attachment_by_id', [gga['sga_id'],imageUrl+'general_action/','INITIAL', self.lang], self.args))
            result['rpt_get_decision_log_general_action_attachment_by_id_followup'].append(h.execute_sp('rpt_get_decision_log_general_action_attachment_by_id', [gga['sga_id'],imageUrl+'general_action/','FOLLOWUP', self.lang], self.args))
            gga['GA_complete'] = h.execute_sp('rpt_get_general_actions_list_completed', [gga['sga_id'], self.lang], self.args)


        result['rpt_decision_log_attachment_by_dlm_id'] = h.execute_sp('rpt_decision_log_attachment_by_dlm_id', [formSubmissionId, imageUrl+'decision_log/', self.lang],self.args)
          
        result['rpt_decision_log_attachment_by_dlm_id'] = h.file_extention_attachments(result['rpt_decision_log_attachment_by_dlm_id'])
       
        return result