#Import important libraries for the report to load
import site
import yaml
import helper as h
import pandas as pd
pd.options.mode.chained_assignment = None 
import json
from api import target_status_by_employee as target

class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId):
        result = {}

        # Load report-specific configuration
        with open('config/targets_detail_planned_vs_actual.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['header'] = config['header']
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['logo'] = h.get_logo()
        result['required_args'] = config['required_args']        
        result['optional_args'] = config['optional_args']
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args']})
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [2120,self.lang,1], self.args)[0]['ltr_text']

        result['args'] = dict(self.args)
        lang=self.lang

        # Check if user entered all the required parameters 
        required_args = config['required_args']
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            start_date=str(self.args['start_date'])        
            end_date=str(self.args['end_date'])
            display_inactive_per_ids=str(self.args['display_inactive_per_ids']) if 'display_inactive_per_ids' in self.args else 'False'
            
            display_inactive_role_ids=str(self.args['display_inactive_role_ids']) if 'display_inactive_role_ids' in self.args else 'False'
            
            display_inactive_site_ids=str(self.args['display_inactive_role_ids']) if 'display_inactive_role_ids' in self.args else 'False'
            
            
            #Site 
            site_ids = self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            site_ids_list = site_ids.split(',') if site_ids is not None else []
            site_data_name = {}            
            user_site_data = result['filter_data']['optionalArgs']['site_ids']['field_values']
            if site_ids_list:
                site_data_name = {each['value']:{'name':each['label'], 'status':each['status_flag']} for each in user_site_data if str(each['value']) in site_ids_list}
            else:
               
                site_data_name = {each['value']:{'name':each['label'], 'status':each['status_flag']} for each in user_site_data}  
            
            site_ids = ','.join(map(str, site_data_name))
            
            #Role
            role_ids = self.args['role_ids'] if 'role_ids' in self.args and self.args['role_ids'] != '' else None
            role_ids_list = role_ids.split(',') if role_ids is not None else []

            role_data = {}            
            user_role_data = result['filter_data']['optionalArgs']['role_ids']['field_values']
            if role_ids_list:
                role_data = {each['value']:{'name':each['label'], 'status':each['aro_enable']} for each in user_role_data if str(each['value']) in role_ids_list}
            else:
               
                role_data = {each['value']:{'name':each['label'], 'status':each['aro_enable']} for each in user_role_data} 

            role_ids = ','.join(map(str, role_data))

            #Employee
            sup_ids = self.args['per_ids'] if 'per_ids' in self.args and self.args['per_ids'] != '' else None
            sup_ids_list = sup_ids.split(',') if sup_ids is not None else []
            supervisor_data = {}            
            user_data = result['filter_data']['optionalArgs']['per_ids']['field_values']  
            if sup_ids_list:
                supervisor_data = {each['value']:{'name':each['label'], 'status':each['is_active']} for each in user_data if str(each['value']) in sup_ids_list}
            else:
              
                supervisor_data = {each['value']:{'name':each['label'], 'status':each['is_active']} for each in user_data}
            sup_ids = ','.join(map(str, supervisor_data))

                    
            result['rpt_targets_planned_vs_actual_labels']={
                "Site_label": h.execute_sp('get_translation_by_tag', [828,self.lang,1], self.args)[0]['ltr_text'],
                "Role_label": h.execute_sp('get_translation_by_tag', [1245,self.lang,1], self.args)[0]['ltr_text'],
                "Total_Targets_label": h.execute_sp('get_translation_by_tag', [2121,self.lang,1], self.args)[0]['ltr_text'],
                "Total_Actuals_label": h.execute_sp('get_translation_by_tag', [2122,self.lang,1], self.args)[0]['ltr_text'],
                "Total_Complete_label": h.execute_sp('get_translation_by_tag', [2123,self.lang,1], self.args)[0]['ltr_text'],
                "Date_label": h.execute_sp('get_translation_by_tag', [124,self.lang,1], self.args)[0]['ltr_text'],
                "Comment_By_label": h.execute_sp('get_translation_by_tag', [8860,self.lang,1], self.args)[0]['ltr_text'],
                "Complete_label": h.execute_sp('get_translation_by_tag', [2125,self.lang,1], self.args)[0]['ltr_text'],
                "Frequency_label": h.execute_sp('get_translation_by_tag', [1106,self.lang,1], self.args)[0]['ltr_text'],
                "Form_Name_label": h.execute_sp('get_translation_by_tag', [1903,self.lang,1], self.args)[0]['ltr_text'],
                "Total_Targets_selected_label": h.execute_sp('get_translation_by_tag', [8861,self.lang,1], self.args)[0]['ltr_text'],
                "Actual_label": h.execute_sp('get_translation_by_tag', [2124,self.lang,1], self.args)[0]['ltr_text'],
                "Comment_label": h.execute_sp('get_translation_by_tag', [3915,self.lang,1], self.args)[0]['ltr_text'],
                "Comments_log_label": h.execute_sp('get_translation_by_tag', [8862,self.lang,1], self.args)[0]['ltr_text'],
                "Summary_label": h.execute_sp('get_translation_by_tag', [1311,self.lang,1], self.args)[0]['ltr_text'],
                "grand_total_label": h.execute_sp('get_translation_by_tag', [2126,self.lang,1], self.args)[0]['ltr_text'],
            }
           
            result['rpt_targets_planned_vs_actual'] = h.execute_sp('rpt_all_targets_detail_planned_vs_actual',[start_date,end_date,sup_ids,role_ids,site_ids,self.lang], self.args)
            frequency_pd = target.getFrequencies(start_date,end_date)
            result['rpt_targets_get_monthly_names'] = h.execute_sp('rpt_targets_get_months', [start_date, end_date,self.lang], self.args)

            df_form_data = pd.DataFrame(list(result['rpt_targets_planned_vs_actual']))
            result['targets_planned_vs_actual_data']  = None
            result['summary_total'] = None
            if not df_form_data.empty:
                #Grouping df_form_data output by FDformID to get the list of forms
                df_targets_form = df_form_data.groupby('form_type')['FDFormID'].apply(list).reset_index(name='form_id_list')
                custom_form_ids = df_targets_form.loc[df_targets_form['form_type'] == 'custom_form']['form_id_list'].to_list()
                predefined_form_ids = df_targets_form.loc[df_targets_form['form_type'] == 'pre_defined_form']['form_id_list'].to_list()
                custom_form_ids =  ",".join([str(i) for i in custom_form_ids[0]]) if custom_form_ids else None
                predefined_form_ids =  ",".join([str(i) for i in predefined_form_ids[0]]) if predefined_form_ids else None
                #Grouping df_form_data output by per_id to get the list of sup_ids
                df_targets_sup_ids = df_form_data.groupby('per_id',sort = False)
                all_forms_sup_ids = list(df_targets_sup_ids.groups.keys())
                sup_ids = ",".join([str(i) for i in all_forms_sup_ids])
                
                result['rpt_all_targets_supervisor'] = h.execute_sp('rpt_all_targets_supervisor_employee', [start_date, end_date,sup_ids,predefined_form_ids, custom_form_ids], self.args)  
                result['rpt_targets_get_quarterly_names'] = frequency_pd['Quarters'].to_dict(orient='records')
                result['rpt_targets_get_bi_annual_names'] = frequency_pd['Bi-Annual'].to_dict(orient='records')
                result['rpt_targets_get_years_names'] = frequency_pd['Years'].to_dict(orient='records')
                result = build_report(self, result,start_date, end_date, supervisor_data,site_data_name, role_data)
        
        else:
            result['targets_planned_vs_actual_data']  = None
            result['summary_total'] = None
            result['rpt_targets_planned_vs_actual_labels'] = None

        return result


def build_report(self, result,start_date, end_date, supervisor_data, site_data_name, role_data):
    '''
    - result['rpt_targets_planned_vs_actual'] - group by this data on site and then group by each group with user per_id
    - loop thruogh each user group - calculate targest data based on frq and get totals for each user and for each site
    - get commenst for each user - make use of exisying function in tragets_functions.py
    '''
    self.df_all_data_planned_vs_actuals = pd.DataFrame(result['rpt_targets_planned_vs_actual'])
    self.df_all_data_supervisor = pd.DataFrame(result['rpt_all_targets_supervisor'])
    self.df_monthly_names = pd.DataFrame(result['rpt_targets_get_monthly_names'])
    self.df_quarterly_names = pd.DataFrame(result['rpt_targets_get_quarterly_names'])
    self.df_biannual_names = pd.DataFrame(result['rpt_targets_get_bi_annual_names'])
    self.df_year_names = pd.DataFrame(result['rpt_targets_get_years_names'])

   
    
    df_targets_group_site = self.df_all_data_planned_vs_actuals.groupby(['esi_sit_id','site'],sort = False)
    targets_sites_data = []
    for site_id, site_group in df_targets_group_site:        
        site_data = pd.DataFrame(site_group)
        user_groups = site_data.groupby(['per_id','per_full_name'],sort = False)
        targets_user_data = []
        
        for user_id, user_group in user_groups:
            user_data = pd.DataFrame(user_group)
            targets_form_data = build_form_data(self,user_data, user_id[0])
            if targets_form_data is None:
                continue
            result = target.get_comments(self, result, start_date, end_date, user_id[0] )
            #calculate user total
            user_totals = {
                "target_total": 0,
                "actual_target_total":0,
                "actual_compliance_total":0,
                "compliance_total":0
            }

            for each in targets_form_data:
                user_totals['target_total'] += each['target'] 
                user_totals['actual_target_total'] += each['actual']
            compliance_total = round((user_totals['actual_target_total']/user_totals['target_total']) * 100) if user_totals['target_total'] > 0 else 0
            user_totals['actual_compliance_total'] = compliance_total if compliance_total < 100 else 100
            user_totals['compliance_total'] = compliance_total
            
            #Adding inactive labels in the HTML.
            inactive_label = h.execute_sp('get_translation_by_tag', [3793,self.lang,1], self.args)[0]['ltr_text']
            status_user = f" ({inactive_label})" if supervisor_data[user_id[0]]['status'] == 0 else ''
            
            role_names = get_role_name(user_data['roles'].iloc[0], role_data, inactive_label)
            targets_user_data.append({
                "user_name": user_data['per_full_name'].iloc[0] + status_user,
                "form_data": targets_form_data,
                "role_names": role_names, #user_data['role_names'].iloc[0],
                "comments": result['rpt_all_targets_comments'],
                "user_totals" : user_totals
            })
        
        # calcluate totals __ 
        site_totals = {
                "target_total": 0,
                "actual_target_total":0,
                "actual_compliance_total":0,
                "compliance_total":0
            }
        
        for each in targets_user_data:
            for key, value in each['user_totals'].items():
                site_totals['target_total'] += value if key =='target_total' else 0
                site_totals['actual_target_total'] += value if key =='actual_target_total' else 0 
        compliance_total = round((site_totals['actual_target_total']/site_totals['target_total']) * 100) if site_totals['target_total'] > 0 else 0
        site_totals['actual_compliance_total'] = compliance_total if compliance_total < 100 else 100
        site_totals['compliance_total'] = compliance_total

        status_site = f" ({inactive_label})" if site_data_name[site_id[0]]['status'] == 0 else ''

        targets_sites_data.append({
            "site_name": site_id[1]+ status_site,
            "users_data": targets_user_data,
            "site_totals": site_totals
        })


    result['targets_planned_vs_actual_data'] = targets_sites_data

    summary_total = {
        "site_names": [],
        "role_names": [],
        "target_total": 0,
        "actual_target_total": 0,
        "compliance_total": 0,
    }

    for site in targets_sites_data:
        if site['site_name'] not in summary_total['site_names']:
            summary_total['site_names'].append(site['site_name'])
        for key,value in site['site_totals'].items():
            
            summary_total['target_total']  += value if key =='target_total' else 0
            summary_total['actual_target_total'] += value if key =='actual_target_total' else 0 
        
        for user in site['users_data']:
            user['role_names_list'] = user['role_names'].split(',')
            for each in user['role_names_list']:
                if each not in summary_total['role_names']:
                    summary_total['role_names'].append(each)
 
    compliance_total = round((summary_total['actual_target_total']/summary_total['target_total']) * 100) if summary_total['target_total'] > 0 else 0
    summary_total['actual_compliance_total'] = compliance_total if compliance_total < 100 else 100
    summary_total['compliance_total'] = compliance_total

    summary_total['site_names'] = ';'.join(summary_total['site_names'])
    summary_total['role_names'] = ';'.join(summary_total['role_names'])
    result['summary_total'] = summary_total
    return result

def get_role_name(roles, role_data, inactive_label):
    role_names = ''
    role_list = roles.split(',') #8,2 
    for role in role_list:
        if int(role) in role_data:
            status_role = f" ({inactive_label})" if role_data[int(role)]['status'] == 0 else ''
            role_name = role_data[int(role)]['name'] + status_role
            role_names = role_names + ', ' + role_name
        
    return role_names[1:]
def build_form_data(self, user_data, user_id):
    form_groups = user_data.groupby(['FDFormID','Form_Name'],sort = False)
    targets_form_data = []
    for form_id, form_group in form_groups:
        temp_object = {}
        

        form_data = pd.DataFrame(form_group)
        monthly_form_data = form_data.query(f'30 == FrequencyID', inplace = False)
        quaterly_form_data = form_data.query(f'90 == FrequencyID', inplace = False)
        bi_annually_form_data = form_data.query(f'182 == FrequencyID', inplace = False)
        annually_form_data = form_data.query(f'365 == FrequencyID', inplace = False)

        if not monthly_form_data.empty:  #Validate empty df
            temp_object = calculate_targets(self, monthly_form_data, user_id, self.df_monthly_names, freq=30)
            if temp_object is not None:
                temp_object['freqency'] = h.execute_sp('get_translation_by_tag', [2890,self.lang,1], self.args)[0]['ltr_text']#30 
        elif not quaterly_form_data.empty:
            temp_object=calculate_targets(self, quaterly_form_data, user_id, self.df_quarterly_names, freq = 90)
            if temp_object is not None:
                temp_object['freqency'] = h.execute_sp('get_translation_by_tag', [2891,self.lang,1], self.args)[0]['ltr_text'] #90
        elif not bi_annually_form_data.empty:
            temp_object=calculate_targets(self, bi_annually_form_data, user_id, self.df_biannual_names, freq = 182)
            if temp_object is not None:
                temp_object['freqency'] = h.execute_sp('get_translation_by_tag', [2892,self.lang,1], self.args)[0]['ltr_text'] #182
        elif not annually_form_data.empty:
            temp_object=calculate_targets(self, annually_form_data, user_id, self.df_year_names, freq = 365)
            if temp_object is not None:
                temp_object['freqency'] = h.execute_sp('get_translation_by_tag', [2893,self.lang,1], self.args)[0]['ltr_text']  #365
        
        if temp_object:
            temp_object['form_name'] = form_id[1]
            targets_form_data.append(temp_object)
        
    

    return targets_form_data 

def calculate_targets(self, form_data, user_id, freq_names_df, freq):
    f_target_all = pd.DataFrame()
    frequency_data = {
                        "target" : 0,
                        "actual" : 0,
                        "actual_compliance" : 0,
                        "total_compliance" : 0
                    }  
    if not self.df_all_data_supervisor.empty:
        df_all_form_sup_user = self.df_all_data_supervisor.query(f'{user_id} == SubmittedBy_SupervisorID', inplace = False)
    
        for rec, val in freq_names_df.iterrows():        
            filter_end = val['yearmonth'] if 'yearmonth' in val else None
            filter_end = val['End'] if 'End' in val else filter_end

            filter_start = val['start'] if 'start' in val else None
            filter_year = val['year'] if 'year' in val else None
            f_target_value = form_data.query(f'"{filter_end}" >= EffectiveOn', inplace=False)
            if freq == 30:  #Monthly setting variable to go in 
                freq_name = 'month'
                f_target_value['month'] = filter_end 
            elif freq == 90:
                freq_name = 'Quarter'
                f_target_value['quarter_start_date'] = filter_start
                f_target_value['quarter_end_date'] = filter_end
            elif freq == 182:
                freq_name = 'Bi-Annual'
                f_target_value['biannual_start_date'] = filter_start
                f_target_value['biannual_end_date'] = filter_end
            elif freq == 365:
                freq_name = 'Year'
                f_target_value['annual_year'] = filter_year
            
            if f_target_value.empty == False:
                f_target_value = f_target_value.sort_values(by=['ID'], ascending = [False]).iloc[:1]
                f_target_value['Actual_target'] = f_target_value.apply(lambda row: target.find_targets(freq_name,row, df_all_form_sup_user), axis = 1)            
                f_target_all = pd.concat([f_target_all,f_target_value],ignore_index=True)
        
        if not f_target_all.empty:      
            frequency_data['target'] = f_target_all['Target_Monthly'].sum()
            frequency_data['actual'] = f_target_all['Actual_target'].sum()
            compliance = round(frequency_data['actual']/frequency_data['target'] * 100) if frequency_data['target'] > 0 else 0
        
            frequency_data['actual_compliance'] = compliance if compliance < 100 else 100
            frequency_data['total_compliance'] = compliance

        return frequency_data    
    else:
        for rec, val in freq_names_df.iterrows():   
            filter_end = val['yearmonth'] if 'yearmonth' in val else None
            filter_end = val['End'] if 'End' in val else filter_end
            filter_start = val['start'] if 'start' in val else None
            filter_year = val['year'] if 'year' in val else None
            f_target_value = form_data.query(f'"{filter_end}" >= EffectiveOn', inplace=False)
            if f_target_value.empty == False:
                f_target_value = f_target_value.sort_values(by=['ID'], ascending = [False]).iloc[:1] 
                f_target_all = pd.concat([f_target_all,f_target_value],ignore_index=True)
        if f_target_all.empty == False:
            frequency_data['target'] = f_target_all['Target_Monthly'].sum()
        return frequency_data
    