#Import important libraries for the report to load
from optparse import Option
import yaml
import helper as h
import pandas


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/employee_departure.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_form_details', 'rpt_form_header','rpt_form_details_distribution','rpt_form_reviewers'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        

        
        # set the section names to english only for referencing
        rpt_form_details = {}
        for row in result['rpt_form_details']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)



                # convert the boolean to yes/no
        if 'Employee' in rpt_form_details:
            for wc in rpt_form_details['Employee']:
                if (wc['field_key'] in ['provide_notice','pay_mining_bonus','pay_zero_harm']):
                    if wc['value'] in ['1','True']:
                        wc['value'] = wc['yes_value']
                    else :
                        if wc['value'] in ['0','False']:
                            wc['value'] = wc['no_value'] 
                        else:
                            wc['value'] = 'N/A'
                if wc['field_key'] == 'employee_name':
                    wc['value'] = get_per_full_name(wc['value'])
                    
                    
                    

        if 'Performance' in rpt_form_details:
            for wc in rpt_form_details['Performance']:
                if (wc['field_key'] in ['recommended_rehire']):
                    if wc['value'] in ['1','True']:
                        wc['value'] = wc['yes_value']
                    else :
                        if wc['value'] in ['0','False']:
                            wc['value'] = wc['no_value'] 
                        else:
                            wc['value'] = 'N/A'

        if 'Assets' in rpt_form_details:
            for wc in rpt_form_details['Assets']:
                if (wc['field_key'] in ['arrangement_assets']):
                    if wc['value'] in ['1','True']:
                        wc['value'] = wc['yes_value']
                    else :
                        if wc['value'] in ['0','False']:
                            wc['value'] = wc['no_value'] 
                        else:
                            wc['value'] = 'N/A'
        


        result['report_labels'] = {
            "departure_date_label" : h.execute_sp('get_translation_by_tag', [129, self.lang, 1], self.args)[0]['ltr_text']
        }

        result['rpt_form_details'] = rpt_form_details

        field_keys = h.execute_sp('rpt_form_field_keys', [1402, self.lang], self.args)
      

        df_keys = pandas.DataFrame(field_keys)
        section_df =  df_keys.groupby('original_section_name').apply(lambda x: x.to_dict('records')).to_dict()
       
        for section,data in result['rpt_form_details'].items():            
            '''
            WHEN SECTION IS EMPLOYEE -> add list of keys which are depenedn on value of other key,
            add the keys to exclude_key_list to not to check/compare keys from database -line 109
            '''
            exclude_key_list = special_case_employee(section, data) if section == 'Employee' else []
            field_keys_list = {each['fieldKey']:each['fieldName'] for each in section_df[section]} #field_key from DB
            data_key_list = [each['field_key'] for each in data] + exclude_key_list #field_key from rpt_form_details

            for field_key in field_keys_list:                
                if field_key not in data_key_list :
                    data.append(
                        {
                            "field_key":field_key,
                            "field_name":field_keys_list[field_key],
                            "value":' '
                        }
                    )
        
        return result

def special_case_employee(section, data):
    exclude_keys = ['provide_notice','pay_mining_bonus','pay_zero_harm', 'other_reasons', 'departure_code']    
    for each in data:
        if each['field_key'] =='reason_departure':
            option = get_text(each['value'])
            if option == 1: #code-e - quit
                exclude_keys.remove('provide_notice')
                '''
                check noticie period value- yes/no key - provide_notice
                if no --> get other field keys - [pay_mining_bonus, pay_zero_harm]
                '''
                provide_notice_value = next(key['original_value'] for key in data if key['field_key'] == 'provide_notice')
                if provide_notice_value == 0:
                    exclude_keys.remove('pay_mining_bonus')
                    exclude_keys.remove('pay_zero_harm')
                
            elif option ==  2: #code -m dismissal
                '''
                get two other field keys []
                '''
                exclude_keys.remove('pay_mining_bonus')
                exclude_keys.remove('pay_zero_harm')
            elif option == 3: #code k - other
                exclude_keys.remove('other_reasons')        
    return exclude_keys

def get_text(value):
    option = f'''
        SELECT
            rld_option
        FROM ref_list_detail
        WHERE rld_rlh_id = 63
        AND rld_name = (SELECT
            MAX(ltr_tag)
        FROM language_translation
        WHERE ltr_text = {value}
        AND ltr_enable = 1);
    '''
    return option

def get_per_full_name(value):
    val_type = value.isdigit()
    per_full_name = ''
    if val_type == False:
        per_full_name = value
    else:
        value = h.execute_sql(f"""
                             SELECT per_full_name FROM v_employee WHERE per_id =  {int(value)};""")
        per_full_name = value['result'][0]['per_full_name']
    return per_full_name