#Import important libraries for the report to load
#Import important libraries for the report to load
import yaml
import helper as h
import pandas as pd
import plotly
import json
from api.document_review_summary_by_site import Report as site_report
from api.document_review_summary_by_user import Report as user_report
from api.document_review_summary_by_document import Report as document_report

class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId = None):
        result = {}
        imageUrl = self.config['image_url']


        if 'report_selection' in self.args and (self.args['report_selection'] == '89'):
            return site_report.get_report(self)

        elif 'report_selection' in self.args and (self.args['report_selection'] == '90'):
            return user_report.get_report(self)

        elif 'report_selection' in self.args and (self.args['report_selection'] == '99'):
            return document_report.get_report(self)
        

        ## Load report-specific configuration
        
        with open('config/document_review_summary.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['required_args'] = config['required_args']
        result['optional_args'] = config['optional_args'] if config['optional_args'] is not None else []
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args'], 'report_slug':config['header']['slug']})        
        result['args'] = dict(self.args)
        
        report_Selection = result['args']['report_selection'] if 'report_selection' in result['args'] else ''
        
        
        
        ###Use this as per the group by user or site
    ##Get report label for by site 89
        result['filtered_report_title_by_site'] = h.execute_sp('get_translation_by_tag', [89,self.lang,1], self.args)[0]['ltr_text']
    ##Get report label for by user 90
        result['filtered_report_title_by_user'] = h.execute_sp('get_translation_by_tag', [90,self.lang,1], self.args)[0]['ltr_text']
    ##Get report label for by document 99
        result['filtered_report_title_by_user'] = h.execute_sp('get_translation_by_tag', [99,self.lang,1], self.args)[0]['ltr_text']
    ##Get report label for by Document review Summary 99
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [9165,self.lang,1], self.args)[0]['ltr_text']



        required_args = config['required_args']
        #result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result