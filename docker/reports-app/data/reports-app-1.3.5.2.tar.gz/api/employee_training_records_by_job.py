#Import important libraries for the report to load
from datetime import datetime, date
import pandas as pd
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId = None):
        result = {}

        ## Load report-specific configuration
        with open('config/employee_training_records.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['required_args'] = config['required_args']        
        result['optional_args'] = config['optional_args'] 
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args'],'report_slug':config['header']['slug']})        
        result['args'] = dict(self.args)

        # place the Report Title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [2029,self.lang,1], self.args)[0]['ltr_text']
        
        # Check if user entered all the required parameters
        required_args = config['required_args']

        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            sites = self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None #3320
            job_id = self.args['job_ids'] if 'job_ids' in self.args and self.args['job_ids'] != '' else None#4248
            display_inactive_job_ids=str(self.args['display_inactive_job_ids']) if 'display_inactive_job_ids' in self.args else 'False'

            #jobs_ids 
            job_ids=self.args['job_ids'] if 'job_ids' in self.args and self.args['job_ids'] != '' else None
            job_ids_list = job_ids.split(',') if job_ids is not None else []
            job_data_name = {}            
            user_job_data = result['filter_data']['requiredArgs']['job_ids']['field_values']
            if job_ids_list:
                job_data_name = {each['value'] for each in user_job_data if str(each['value']) in job_ids_list}
            else:
                job_data_name = {each['value'] for each in user_job_data}
            
            job_id = ','.join(map(str, job_data_name))
                

            rpt_employee_training_records_by_job = h.execute_sp('rpt_employee_training_records_by_job', [sites, job_id, self.lang], self.args)            

            inactive_label = h.execute_sp('get_translation_by_tag', [9169,self.lang,1], self.args)[0]['ltr_text']


            temp_data = rpt_employee_training_records_by_job
            for data in temp_data:
                if data['status_flag'] == 0:
                    data['job_name'] = (data['job_name'] + ' ' + inactive_label)
            rpt_employee_training_records_by_job = temp_data

            # use pandas to groupby
            if rpt_employee_training_records_by_job:
                result['labels'] = {key:value for key, value in rpt_employee_training_records_by_job[0].items() if key.endswith('_label')}
                result['labels']['about_to_expire_label'] = h.execute_sp('get_translation_by_tag', [8865,self.lang,1], self.args)[0]['ltr_text']
                jobs = {}
                yes_label = h.execute_sp('get_translation_by_tag', [3494,self.lang,1], self.args)[0]['ltr_text']
                no_label = h.execute_sp('get_translation_by_tag', [1380,self.lang,1], self.args)[0]['ltr_text']
                
                df = pd.DataFrame(rpt_employee_training_records_by_job)
                df = df[['employee_name','employee_id','job_name','training_code','training_description','etr_completion_date','etr_expiry_date','is_expired', 'status_flag']]                
                df.fillna('', inplace=True)
                df['is_expired_label'] = df['is_expired']
                df['is_expired_label'].replace({'1':yes_label, '0':no_label}, inplace=True)                          

                training_record_groups = df.groupby(['job_name','employee_name','employee_id'])
            
                employees = {}                
                for name, group in training_record_groups:                   
                    jobs[name[0]] = []
                    training_data = group.to_dict(orient='records')
                    for each in training_data:
                        each['etr_expiry_date'] = datetime.strptime(each['etr_expiry_date'], '%Y-%m-%d').date() if each['etr_expiry_date'] else ''                                     
                        each['expires_in_30'] = True if each['etr_expiry_date'] and (each['etr_expiry_date'] - date.today()).days < 30 and (each['etr_expiry_date'] - date.today()).days>0 else False

                    employees[f'{name[1]} - {name[2]}'] = training_data
                    jobs[name[0]].append(employees)                
                result['training_records'] = jobs
            
        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result 