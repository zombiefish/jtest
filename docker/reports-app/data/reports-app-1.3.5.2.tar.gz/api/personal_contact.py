#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/personal_contact.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_form_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id', 'rpt_hazard_actions','rpt_personal_contact_topic', 'rpt_form_details_distribution', 'rpt_form_reviewers'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['args'] = dict(self.args)
        
        h.get_hazard_actions(result['rpt_hazard_actions'], imageUrl, self.args, self.lang) 
        h.get_general_actions(result['rpt_get_general_action_by_id'], imageUrl, self.args, self.lang)
        h.get_positive_recognitions(result['rpt_positive_recognition'], imageUrl, self.args, self.lang)
            
        for row in result['rpt_personal_contact_topic']:
            if row['value'] is not None:
                if ('.jpg' or '.png') in row['value']:
                    row['value'] = imageUrl + row['value']
        
        for row in result['rpt_form_details']:
            if row['value'] is not None:
                if ('.jpg' or '.png') in row['value']:
                    row['value'] = imageUrl + row['value']

        #Modifying the boolean values to yes or no
        for wc in result['rpt_personal_contact_topic']:
            if (wc['field_key'] in ['topic_type']):
                wc['value'] = wc['translated_value']
            if (wc['field_key'] in ['hazards_identified']):
                if wc['value'] == '1':
                    wc['value'] = wc['yes_value']
                else :
                    if wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '-1':
                        wc['value'] = 'N/A'
                    else:
                        wc['value'] = wc['value']

        return result