#Import important libraries for the report to load
from pymysql import NULL
from sqlalchemy import null
# from sympy import Not
import yaml
import helper as h

class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/archived_submissions.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata        
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['filter'] = config['filter']
        result['required_args'] = config['required_args']
        result['optional_args'] = config['optional_args']
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args']})
        for form in result['filter_data']['optionalArgs']['form_ids']['field_values']:
            if form['custom_form'] == 1:
                form['value'] = 'c-' + str(form['value'])
            else:
                form['value'] = str(form['value'])
        result['args'] = dict(self.args)

        ##Calling SP to generate report labels
        result['report_labels'] = {
            "site_label" : h.execute_sp('get_translation_by_tag', [828, self.lang, 1], self.args)[0]['ltr_text'],
            "date_label" : h.execute_sp('get_translation_by_tag', [124, self.lang, 1], self.args)[0]['ltr_text'],
            "submission_id_label" : h.execute_sp('get_translation_by_tag', [2398, self.lang, 1], self.args)[0]['ltr_text'],
            "JobNumber_label" : h.execute_sp('get_translation_by_tag', [617, self.lang, 1], self.args)[0]['ltr_text'],
            "SiteLevel_label" : h.execute_sp('get_translation_by_tag', [621, self.lang, 1], self.args)[0]['ltr_text'],
            "workplace_label" : h.execute_sp('get_translation_by_tag', [959, self.lang, 1], self.args)[0]['ltr_text'],
            "submitted_by_label" : h.execute_sp('get_translation_by_tag', [1168, self.lang, 1], self.args)[0]['ltr_text'],
            "date_created_label" : h.execute_sp('get_translation_by_tag', [2400, self.lang, 1], self.args)[0]['ltr_text'],
            "date_archived_label" : h.execute_sp('get_translation_by_tag', [2399, self.lang, 1], self.args)[0]['ltr_text'],
            "archived_by_label" : h.execute_sp('get_translation_by_tag', [2744, self.lang, 1], self.args)[0]['ltr_text']
        }
            
        # place the Title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [2397,self.lang,1], self.args)[0]['ltr_text']

        required_args = config['required_args']

        ##Condition to check if the user has selected all the mandatory filters to run the report.
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            allRecs=[]
            start_date=self.args['start_date']
            end_date=self.args['end_date']
            display_inactive_form_ids=str(self.args['display_inactive_form_ids']) if 'display_inactive_form_ids' in self.args else 'False'

            #Form_ids 
            form_ids=self.args['form_ids'] if 'form_ids' in self.args and self.args['form_ids'] != '' else None
            form_ids_list = form_ids.split(',') if form_ids is not None else []
            form_ids_temp = []
            form_ids_temp_custom = []
            for form in form_ids_list:
                if form.isnumeric():
                    form_ids_temp.append(form)
                else:
                    form_ids_temp_custom.append(form)

            form_data_name = {}        
            form_data_name_custom = {}       
            user_form_data = result['filter_data']['optionalArgs']['form_ids']['field_values']
            if len(form_ids_temp) > 0:
                form_data_name = {each['value']:{'name':each['label'], 'status':each['mfo_enable']} for each in user_form_data if str(each['value']) in form_ids_temp}
                if len(form_ids_temp_custom) > 0:
                    form_data_name_custom = {each['value'].replace('c-', ''):{'name':each['label'], 'status':each['mfo_enable']} for each in user_form_data if str(each['value']) in form_ids_temp_custom}
            else:
                if len(form_ids_temp_custom) == 0:
                    for form in user_form_data:
                        if form['value'].isnumeric():
                            form_data_name.update({form['value']:{'name':form['label'], 'status':form['mfo_enable']}})        
                        else:
                            form_data_name_custom.update({form['value'].replace('c-',''):{'name':form['label'], 'status':form['mfo_enable']}})  
                else:
                    if len(form_ids_temp_custom) == 0:
                        for form in user_form_data:
                            if form['value'].isnumeric():
                                form_data_name.update({form['value']:{'name':form['label'], 'status':form['mfo_enable']}})        
                            else:
                                form_data_name_custom.update({form['value'].replace('c-',''):{'name':form['label'], 'status':form['mfo_enable']}})  
                    else: 
                        form_data_name_custom = {each['value'].replace('c-', ''):{'name':each['label'], 'status':each['mfo_enable']} for each in user_form_data if str(each['value']) in form_ids_temp_custom}
                    
            form_ids = form_data_name
            form_ids_custom = form_data_name_custom
            
            result['rpt_archived_submissions'] = [] 
            for form in form_ids:
                formData = h.execute_sp('rpt_archived_submissions', [start_date, end_date, form, self.lang], self.args)
                if formData:
                    result['rpt_archived_submissions'].append(formData)
            
            for custom_form in form_ids_custom:
                formData = h.execute_sp('rpt_archived_submissions_custom', [start_date, end_date, custom_form, self.lang], self.args)
                if formData:
                    result['rpt_archived_submissions'].append(formData)

            form_names_list = []
            if result['rpt_archived_submissions']:
                for form in result['rpt_archived_submissions']:
                    form_names_list.append(form[0]['lbl_form_name'])
                form_names_list.sort()
            
            final_form_list = []
            for form_name in form_names_list:
                for form in result['rpt_archived_submissions']:
                    if form[0]['lbl_form_name'] == form_name:
                        final_form_list.append(form)
            result['rpt_archived_submissions'] = final_form_list

        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result
    