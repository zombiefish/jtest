
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/bowtie.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_bowtie_header','rpt_bowtie_hap','rpt_bowtie_general_actions_by_sga_id','rpt_bowtie_reviewers','rpt_bowtie_approved_by','rpt_bowtie_approvers', 'rpt_bowtie_risk_assessment','rpt_bowtie_consequences','rpt_bowtie_root_causes'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)  
        
        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures

        result['rpt_hap_pictures_initial']=[]
        result['rpt_hap_pictures_followup']=[]
        
        for hap in result['rpt_bowtie_hap']:            
            hap['rpt_hap_pictures_initial'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'INITIAL', self.lang], self.args)
            hap['rpt_hap_pictures_followup'] = h.execute_sp('rpt_hap_pictures', [hap['ID'], imageUrl, 'FOLLOWUP', self.lang], self.args)
            hap['HAP_complete'] = h.execute_sp('rpt_hazard_actions_list_completed', [hap['ID'], self.lang], self.args)


        result['rpt_bowtie_general_action_attachment_by_id_initial'] = []
        result['rpt_bowtie_general_action_attachment_by_id_followup'] = []

        for gga in result['rpt_bowtie_general_actions_by_sga_id']:
            result['rpt_bowtie_general_action_attachment_by_id_initial'].append(h.execute_sp('rpt_ora_general_action_attachment_by_id', [gga['sga_id'],imageUrl+'general_action/','INITIAL', self.lang], self.args))
            result['rpt_bowtie_general_action_attachment_by_id_followup'].append(h.execute_sp('rpt_ora_general_action_attachment_by_id', [gga['sga_id'],imageUrl+'general_action/','FOLLOWUP', self.lang], self.args))
            gga['GA_complete'] = h.execute_sp('rpt_get_general_actions_list_completed', [gga['sga_id'], self.lang], self.args)


        rootCause_Consequence = []
        rowspan = []
        rootCause = h.execute_sp('rpt_bowtie_root_causes', [formSubmissionId, self.lang], self.args)
        consequence = h.execute_sp('rpt_bowtie_consequences', [formSubmissionId, self.lang], self.args)
        rc_length = len(rootCause)
        consq_length = len(consequence)

        length = rc_length if rc_length > consq_length else consq_length
        
        for i in range(length):
            data = {}
            rowspan = {}
            if i<rc_length:
                data['root_cause'] = rootCause[i]['rmm_brc_root_cause']
                data['event_mitigation'] = rootCause[i]['rmm_bem_event']
            else:
                data['root_cause'] = None
                data['event_mitigation'] = None
            if i<consq_length:
                data['consequence'] = consequence[i]['rmm_bco_consequence']
                data['consequnece_mitigation'] = consequence[i]['rmm_bcm_consequence']
            else:
                data['consequence'] = None
                data['consequnece_mitigation'] = None
            
            rootCause_Consequence.append(data)
        rowspan['rowspan'] = len(rootCause_Consequence) + 1
    
        result['rootCause_Consequence'] = rootCause_Consequence 
        result['rowspan'] = rowspan  
        result['rpt_get_bowtie_attachment_bowtie_id'] = h.execute_sp('rpt_get_bowtie_attachment_bowtie_id', [formSubmissionId, imageUrl, self.lang], self.args)

        result['rpt_get_bowtie_attachment_bowtie_id'] = h.file_extention_attachments(result['rpt_get_bowtie_attachment_bowtie_id'])
        
        return result
    