#Import important libraries for the report to load
from operator import index
from typing import final
import yaml
import helper as h
from flask.json import jsonify
import json
import pandas as pd
import datetime

class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/equipment_history.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        result['header'] = config['header']
        result['formHeader'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['filter'] = config['filter']
        result['required_args'] = config['required_args'] if config['required_args'] is not None else []        
        result['optional_args'] = config['optional_args'] if config['optional_args'] is not None else []
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args']})    
        result['args'] = dict(self.args)
        
        # get the report Title
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [9511,self.lang,1], self.args)[0]['ltr_text']
        
        required_args = config['required_args']
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            start_date=self.args['start_date']       
            end_date=self.args['end_date']
            equipment_ids = self.args['full_equipment_ids'] if 'full_equipment_ids' in self.args and self.args['full_equipment_ids'] != '' else ''
            sites = self.args['site_ids'] if 'site_ids' in self.args and self.args['site_ids'] != '' else None
            service_type = self.args['service_type'] if 'service_type' in self.args and self.args['service_type'] != '' else ''
            display_inactive_site_ids=str(self.args['display_inactive_site_ids']) if 'display_inactive_site_ids' in self.args else 'False'
            display_inactive_full_equipment_ids=str(self.args['display_inactive_full_equipment_ids']) if 'display_inactive_full_equipment_ids' in self.args else 'False'            
            display_inactive_service_type=str(self.args['display_inactive_service_type']) if 'display_inactive_service_type' in self.args else 'False'

            # Get all the service types from ref_list_details. This will have the values from the pull down list which the user can select            
            service_type_list_ref = h.execute_sp('rpt_equipment_history_service_type_list', [service_type], self.args)

            #Find all submission ids with selected service types 
            service_types = service_type_list_ref[0]['service_types'] if service_type_list_ref[0]['service_types'] else 'None'
            sites_list = sites if sites else 'None'
            service_type_sub_ids = h.execute_sp('rpt_equipment_history_service_type', [start_date, end_date, sites_list, service_types], self.args)
            all_ids =[]
            all_records = []
            all_detail_recs = {}
            for id in service_type_sub_ids:
                all_ids.append(str(id['sub_ids']))
            all_ids_list = ','.join(all_ids) 
            all_submission_data = h.execute_sp('rpt_equipment_history_sub_ids', [all_ids_list, self.lang], self.args)
            
            for rec in all_submission_data:  
                if rec['SubmissionHeaderID'] in all_detail_recs:
                    all_detail_recs[rec['SubmissionHeaderID']]['SubmissionHeaderID'] = rec['SubmissionHeaderID']
                    all_detail_recs[rec['SubmissionHeaderID']]['FormSubmissionDate'] = rec['FormSubmissionDt']
                    all_detail_recs[rec['SubmissionHeaderID']]['Site'] = rec['Site']
                    if rec['fieldKey'] in all_detail_recs[rec['SubmissionHeaderID']]:
                        all_detail_recs[rec['SubmissionHeaderID']][rec['fieldKey']] += '|' + str(rec['Value'])
                    else:                        
                        all_detail_recs[rec['SubmissionHeaderID']][rec['fieldKey']] = str(rec['Value'])
                else:                    
                    all_detail_recs[rec['SubmissionHeaderID']] = {}
                    all_detail_recs[rec['SubmissionHeaderID']]['SubmissionHeaderID'] = rec['SubmissionHeaderID']
                    all_detail_recs[rec['SubmissionHeaderID']]['FormSubmissionDate'] = rec['FormSubmissionDt']
                    all_detail_recs[rec['SubmissionHeaderID']]['Site'] = rec['Site']
                    all_detail_recs[rec['SubmissionHeaderID']][rec['fieldKey']] = rec['Value']

            for id in service_type_sub_ids:
                full_record = {} 
                all_images = {'images_1': [],
                            'images_2': [],
                            'images_3': [],
                            'images_4': [],
                            'images_5': [],
                            'images_6': [],
                            'images_7': [],
                            'images_8': [],
                            'images_9': [],
                            'images_10': [],                
                }
                full_record = all_detail_recs[id['sub_ids']]
                if 'images_1' in full_record:
                    for image_1 in full_record['images_1'].split('|'):
                        all_images['images_1'].append(imageUrl + image_1)
                if 'images_2' in full_record:
                    for image_2 in full_record['images_2'].split('|'):
                        all_images['images_2'].append(imageUrl + image_2)
                if 'images_3' in full_record:
                    for image_3 in full_record['images_3'].split('|'):
                        all_images['images_3'].append(imageUrl + image_3)                        
                if 'images_4' in full_record:
                    for image_4 in full_record['images_4'].split('|'):
                        all_images['images_4'].append(imageUrl + image_4)
                if 'images_5' in full_record:
                    for image_5 in full_record['images_5'].split('|'):
                        all_images['images_5'].append(imageUrl + image_5)
                if 'images_6' in full_record:
                    for image_6 in full_record['images_6'].split('|'):
                        all_images['images_6'].append(imageUrl + image_6)
                if 'images_7' in full_record:
                    for image_7 in full_record['images_7'].split('|'):
                        all_images['images_7'].append(imageUrl + image_7)
                if 'images_8' in full_record:
                    for image_8 in full_record['images_8'].split('|'):
                        all_images['images_8'].append(imageUrl + image_8)
                if 'images_9' in full_record:
                    for image_9 in full_record['images_9'].split('|'):
                        all_images['images_9'].append(imageUrl + image_9)
                if 'images_10' in full_record:
                    for image_10 in full_record['images_10'].split('|'):
                        all_images['images_10'].append(imageUrl + image_10)
                    
                full_record['images'] = all_images
                all_records.append(full_record)
            tfsr_equipment_ids = h.execute_sp('rpt_equipment_history_tfsr_equipment', [equipment_ids, self.lang], self.args)
            
            # Grabbing needed fields from each TFSR report (checking all sections - TFSR has up to 10)
            equipment_list = []            
            for key in all_records:
                for i in range(1,11):
                    equipment_status = key['equipment_status_' + str(i)] if 'equipment_status_' + str(i) in key else ''
                    other_unit_make = key['other_unit_make_' + str(i)] if 'other_unit_make_' + str(i) in key else ''
                    service = key['service_' + str(i)] if 'service_' + str(i) in key else ''
                    service_type = key['service_type_' + str(i)] if 'service_type_' + str(i) in key else ''
                    travel = key['travel_' + str(i)] if 'travel_' + str(i) in key else ''
                    unit_hours = key['unit_hours_' + str(i)] if 'unit_hours_' + str(i) in key else ''
                    unit_id = key['unit_id_' + str(i)] if 'unit_id_' + str(i) in key else ''
                    images = key['images']['images_' + str(i)] if  key['images']['images_' + str(i)] else ''
                    delay = key['delay_' + str(i)] if 'delay_' + str(i) in key else ''
                    e_id = key['unit_make_' + str(i)] if 'unit_make_' + str(i) in key else ''
                    work_completed = key['work_completed_' + str(i)] if 'work_completed_' + str(i) in key else ''
                    work_order = key['work_order_' + str(i)] if 'work_order_' + str(i) in key else ''
                    work_order_item = key['work_order_item_' + str(i)] if 'work_order_item_' + str(i) in key else ''
                    service_type_list = service_type_list_ref[0]['service_types'] if service_type_list_ref[0]['service_types'] else ''
                    shift = key['shift'] if 'shift' in key else ''
                    site = key['Site'] if 'Site' in key else ''
                    technician_name = key['technician_name'] if 'technician_name'in key else ''
                    if service_type and ((service_type in service_type_list) or (service_type_list == '')):
                        equipment_list.append({
                            "SubmissionHeaderID": key['SubmissionHeaderID'],
                            "FormSubmissionDate" : key['FormSubmissionDate'][0:10],
                            "FormSubmissionDateDatetime" : key['FormSubmissionDate'],
                            "site" : site,
                            "shift" :shift,
                            "technician_name": technician_name,
                            "delay" : delay,
                            "equipment_status" : equipment_status,
                            "images" : images,
                            "other_unit_make" : other_unit_make,
                            "service" : service,
                            "service_type" : service_type,
                            "travel" : travel,
                            "unit_hours" : unit_hours,
                            "unit_make" : e_id,
                            "unit_id" : unit_id,
                            "work_completed" : work_completed,
                            "work_order" : work_order,
                            "work_order_item" : work_order_item,
                        })
            
            # Applying the equipment filtering
            final_equip_list = []
            for id in equipment_list:
                for equip in tfsr_equipment_ids:
                    if str(id['unit_make']) == str(equip['pet_poe_id']) and str(id['unit_id']) == str(equip['pet_equipment_identifier']):
                        id['full_equip_name'] = equip['pet_equipment_identifier'] + ' - ' + equip['equip_name']
                        final_equip_list.append(id)
                    if str(id['unit_id']).upper() == 'OTHER' or id['unit_id'] == 'None':
                        id['full_equip_name'] = 'other'
                        final_equip_list.append(id)
            
            # Applying the site to each piece of equipment
            site_equip_list = {}
            for site in final_equip_list:
                if site['site'] in site_equip_list:
                    site_equip_list[site['site']]['equip'].append(site)
                else:                    
                    site_equip_list[site['site']] = {}
                    site_equip_list[site['site']]['equip'] = []
                    site_equip_list[site['site']]['equip'].append(site)

            # Building data structure: Site -> Equipment -> Report ID -> Service Type -> Data
            # Adding in needed components to build the chart and grids (delay, travel and service)
            for key,site in site_equip_list.items():
                for equip in site['equip']:              
                    if equip['full_equip_name'] in site_equip_list[key]:
                        if str(equip['SubmissionHeaderID']) in site_equip_list[key][equip['full_equip_name']]:
                            site_equip_list[key][equip['full_equip_name']]['service_hours'] = float(site_equip_list[key][equip['full_equip_name']]['service_hours']) + float(equip['service']) if equip['service'] and equip['service'] != 'None' else 0
                            site_equip_list[key][equip['full_equip_name']]['delay_hours'] = float(site_equip_list[key][equip['full_equip_name']]['delay_hours']) + float(equip['delay']) if equip['delay'] and equip['delay'] != 'None' else 0
                            site_equip_list[key][equip['full_equip_name']]['travel_hours'] = float(site_equip_list[key][equip['full_equip_name']]['travel_hours']) + float(equip['travel']) if equip['travel'] and equip['travel'] != 'None' else 0
                            site_equip_list[key][equip['full_equip_name']]['records'][str(equip['SubmissionHeaderID'])].append(equip)
                        else:
                            site_equip_list[key][equip['full_equip_name']]['service_hours'] = float(site_equip_list[key][equip['full_equip_name']]['service_hours']) + float(equip['service']) if equip['service'] and equip['service'] != 'None'  else 0
                            site_equip_list[key][equip['full_equip_name']]['delay_hours'] = float(site_equip_list[key][equip['full_equip_name']]['delay_hours']) + float(equip['delay']) if equip['delay'] and equip['delay'] != 'None' else 0
                            site_equip_list[key][equip['full_equip_name']]['travel_hours'] = float(site_equip_list[key][equip['full_equip_name']]['travel_hours']) + float(equip['travel']) if equip['travel'] and equip['travel'] != 'None' else 0
                            site_equip_list[key][equip['full_equip_name']]['records'][str(equip['SubmissionHeaderID'])] = []
                            site_equip_list[key][equip['full_equip_name']]['records'][str(equip['SubmissionHeaderID'])].append(equip)

                    else:
                        site_equip_list[key][equip['full_equip_name']] = {}
                        site_equip_list[key][equip['full_equip_name']]['delay_hours'] = float(equip['delay']) if equip['delay'] and equip['delay'] != 'None' else 0
                        site_equip_list[key][equip['full_equip_name']]['service_hours'] = float(equip['service']) if equip['service'] and equip['service'] != 'None' else 0
                        site_equip_list[key][equip['full_equip_name']]['travel_hours'] = float(equip['travel']) if equip['travel'] and equip['travel'] != 'None' else 0
                        site_equip_list[key][equip['full_equip_name']]['records'] = {}
                        site_equip_list[key][equip['full_equip_name']]['records'][str(equip['SubmissionHeaderID'])] = []                        
                        site_equip_list[key][equip['full_equip_name']]['records'][str(equip['SubmissionHeaderID'])].append(equip)
                del site['equip']

            # Going through data strucutre to add in the chart and grid data (summing values)
            for key,site in site_equip_list.items():
                for equip in site:
                    service_data = {} 
                    service_data_tech = {}
                    for key_sub, rec in site_equip_list[key][equip]['records'].items():
                        for equip_rec in site_equip_list[key][equip]['records'][key_sub]:
                            if equip_rec['service_type'] in service_data:
                                service_data[equip_rec['service_type']] += float(equip_rec['service']) if equip_rec['service'] and equip_rec['service'] != 'None' else 0
                                service_data[equip_rec['service_type']] += float(equip_rec['delay']) if equip_rec['delay'] and equip_rec['delay'] != 'None' else 0
                                service_data[equip_rec['service_type']] += float(equip_rec['travel']) if equip_rec['travel'] and equip_rec['travel'] != 'None' else 0
                            else:
                                service_data[equip_rec['service_type']] = 0
                                service_data[equip_rec['service_type']] += float(equip_rec['service']) if equip_rec['service'] and equip_rec['service'] != 'None' else 0
                                service_data[equip_rec['service_type']] += float(equip_rec['delay']) if equip_rec['delay'] and equip_rec['delay'] != 'None' else 0
                                service_data[equip_rec['service_type']] += float(equip_rec['travel']) if equip_rec['travel'] and equip_rec['travel'] != 'None' else 0

                        for equip_rec_tech in site_equip_list[key][equip]['records'][key_sub]:
                            if equip_rec_tech['technician_name'] in service_data_tech:
                                service_data_tech[equip_rec_tech['technician_name']] += float(equip_rec_tech['service']) if equip_rec_tech['service'] and equip_rec_tech['service'] != 'None' else 0
                                service_data_tech[equip_rec_tech['technician_name']] += float(equip_rec_tech['delay']) if equip_rec_tech['delay'] and equip_rec_tech['delay'] != 'None' else 0
                                service_data_tech[equip_rec_tech['technician_name']] += float(equip_rec_tech['travel']) if equip_rec_tech['travel'] and equip_rec_tech['travel'] != 'None' else 0
                            else:
                                service_data_tech[equip_rec_tech['technician_name']] = 0
                                service_data_tech[equip_rec_tech['technician_name']] += float(equip_rec_tech['service']) if equip_rec_tech['service'] and equip_rec_tech['service'] != 'None' else 0
                                service_data_tech[equip_rec_tech['technician_name']] += float(equip_rec_tech['delay']) if equip_rec_tech['delay'] and equip_rec_tech['delay'] != 'None' else 0
                                service_data_tech[equip_rec_tech['technician_name']] += float(equip_rec_tech['travel']) if equip_rec_tech['travel'] and equip_rec_tech['travel'] != 'None' else 0
                    
                    # Appending chart and grid data to the data object
                    final_service_data_service_type = []
                    final_service_data_service_hours = []
                    service_summary = []
                    for s_key, s_rec in service_data.items():
                        final_service_data_service_type.append(s_key)
                        final_service_data_service_hours.append(s_rec)
                        service_summary.append({
                            'service_type' : s_key,
                            'hours' : s_rec
                        })
                    site_equip_list[key][equip]['service_summary'] = service_summary
                    site_equip_list[key][equip]['service_chart_service_type'] = final_service_data_service_type
                    site_equip_list[key][equip]['service_chart_service_hours'] = final_service_data_service_hours
                    
                    final_service_data_tech_name = []
                    final_service_data_tech_hours = []
                    tech_summary = []
                    for s_key, s_rec in service_data_tech.items():
                        final_service_data_tech_name.append(s_key.replace('\\', ''))
                        final_service_data_tech_hours.append(s_rec)
                        tech_summary.append({
                            'tech_name' : s_key,
                            'hours' : s_rec
                        })
                    site_equip_list[key][equip]['tech_summary'] = tech_summary
                    site_equip_list[key][equip]['service_chart_tech_name'] = final_service_data_tech_name
                    site_equip_list[key][equip]['service_chart_tech_hours'] = final_service_data_tech_hours           
                
            result['site_equip_list'] = site_equip_list

        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))

        return result
        