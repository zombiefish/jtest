#Import important libraries for the report to load
import pandas as pd
import yaml
import helper as h

from api import target_status_by_employee as target


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args, self.report_filter_unique_code = h.get_report_filter_values(args)
        self.lang = self.args['lang'] if self.args and 'lang' in self.args.keys() else 1
    
    def get_report(self, formSubmissionId):
        result = {}

        ## Load report-specific configuration
        with open('config/target_status_summary.yaml', 'r') as f:
                config = yaml.safe_load(f)

        # Build Report metadata
        # result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['footer'] = config['footer']
        result['logo'] = h.get_logo()
        result['filter'] = config['filter']
        result['required_args'] = config['required_args']
        result['optional_args'] = config['optional_args']
        result['filter_data'] = h.get_filter_data({'required_args': config['required_args'], 'lang': self.lang, 'optional_args':config['optional_args'], 'report_slug':config['header']['slug']})
        result['args'] = dict(self.args)
        result['filtered_report_title'] = h.execute_sp('get_translation_by_tag', [9360,self.lang,1], self.args)[0]['ltr_text']

        # Fetching all the required labels
        result['report_labels']=target.target_report_labels(self)

        # Check if user entered all the required parameters
        required_args = config['required_args']
        if len(list(set(required_args) & set(result['args']))) == len(required_args):
            start_date=self.args['start_date']       
            end_date=self.args['end_date']

            display_inactive_job_ids=str(self.args['display_inactive_job_ids']) if 'display_inactive_job_ids' in self.args else 'False'
            
            frequency_pd = target.getFrequencies(start_date,end_date)
            job_ids = self.args['job_ids'] if 'job_ids' in self.args and self.args['job_ids'] != '' else None
            job_ids_list = job_ids.split(',') if job_ids is not None else []
            job_data = {}            
            user_job_data = result['filter_data']['optionalArgs']['job_ids']['field_values']
            if job_ids_list:
                job_data = {each['value']:{'name':each['label'], 'status':each['status_flag']} for each in user_job_data if str(each['value']) in job_ids_list}
            else:
                job_data = {each['value']:{'name':each['label'], 'status':each['status_flag']} for each in user_job_data}                
            job_ids = ','.join(map(str, job_data))

            result['rpt_target_status_by_employee'] = []

            ####### Getting targets for all the frequencies assigned in the mode parameter ######
            result =target.targets_data(self, start_date, end_date, job_ids, result, frequency_pd, mode= 'monthly', mode_value=30, report_category='job')
            result =target.targets_data(self, start_date, end_date, job_ids, result, frequency_pd, mode= 'quarterly', mode_value=90, report_category='job')
            result =target.targets_data(self, start_date, end_date, job_ids, result, frequency_pd, mode= 'bi-annual', mode_value=182, report_category='job')
            result =target.targets_data(self, start_date, end_date, job_ids, result, frequency_pd, mode= 'annually', mode_value=365, report_category='job')           
            
            ####### Building targets as per the report types [Employee, Roles and Sites] ######
            result = target.build_targets_data(self, result, job_data, start_date, end_date, frequency_pd, "job")
            
        else:
            result['args']['missing_args'] = list(set(required_args) - set(result['args']))
        
        return result

   