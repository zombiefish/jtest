#Import important libraries for the report to load
import yaml
import helper as h


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/document_review.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_document_review_external_reviewers', 'rpt_document_review_reviewers', 'rpt_document_review_management_header'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)

        toReview = []
        hasReviewed = []
        hasNotReviewed = []
        externalReviewers = []

        # Get the list of names that must review the document
        for item in result['rpt_document_review_management_header']:
            if item['drm_review_by_person'] is not None:
                toReview = (item['drm_review_by_person'].split('; '))
            
            if item['drm_filename'] is not None:
               item['url']  = imageUrl + 'documents_attachments/' + item['drm_filename'] 

        # Get the list of names that has reviewed the document
        for item in result['rpt_document_review_reviewers']:
            hasReviewed.append(item['person_full_name'])

        # Get the list of external names that has reviewed the document
        for item in result['rpt_document_review_external_reviewers']:
            externalReviewers.append(item['ExternalReviewer'])

        # Get the list of names that has not reviewed the document
        # hasNotReviewed = toReview - hasReviewed - externalReviewers
        hasNotReviewed = list(set(toReview)-set(hasReviewed)-set(externalReviewers))

        result['missing_reviewers'] = []
        result['missing_reviewers'] = {'person' : hasNotReviewed} 

        # add Image URL to signature filename
        for wc in result['rpt_document_review_external_reviewers']:
            if wc['Signature'] is not None:
                if  '.png' or '.jpg' or '.jpeg' in wc['Signature']:
                    wc['Signature'] = imageUrl + wc['Signature']

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        result['rpt_document_review_attachment'] = h.file_extention_attachments(result['rpt_document_review_management_header'])
        
        return result
    