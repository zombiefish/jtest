#Import important libraries for the report to load
import yaml
import helper as h
import pandas


class Report:

    def __init__(self, args):
        self.config = h.api_config(args)
        self.args = args
        self.lang = args['lang'] if args and 'lang' in args else 1
    
    def get_report(self, formSubmissionId):
        result = {}
        imageUrl = self.config['image_url']

        ## Load report-specific configuration
        with open('config/safety_jhs_board_audit.yaml', 'r') as f:
                config = yaml.safe_load(f)
        
        ## Load data from Stored Procedures
        for sp in config['stored_procedures']:  
            if sp in ('rpt_form_details', 'rpt_form_header', 'rpt_positive_recognition','rpt_get_general_action_by_id','rpt_hazard_actions','rpt_form_details_distribution','rpt_form_reviewers'):
                result[sp] = h.execute_sp(sp, [formSubmissionId, self.lang], self.args)
            else:
                result[sp] = h.execute_sp(sp, [formSubmissionId], self.args)

        # Build Report metadata
        result['formSubmissionId'] = int(formSubmissionId)
        result['header'] = config['header']
        result['logo'] = h.get_logo()
        result['footer'] = config['footer']
        result['args'] = dict(self.args)
        
        ## Load parameterized Stored Procedures
        h.get_hazard_actions(result['rpt_hazard_actions'], imageUrl, self.args, self.lang) 
        h.get_general_actions(result['rpt_get_general_action_by_id'], imageUrl, self.args, self.lang)
        h.get_positive_recognitions(result['rpt_positive_recognition'], imageUrl, self.args, self.lang)

        #Updating this section to be able to key on original section name     
        rpt_form_details = {}
        for row in result['rpt_form_details']:
            if row['original_section_name'] not in rpt_form_details:
                rpt_form_details[row['original_section_name']] = []
            rpt_form_details[row['original_section_name']].append(row)

        #Modifying the boolean values to Yes or No
        if 'Safety/JHS Board' in rpt_form_details:
            for wc in rpt_form_details['Safety/JHS Board']:
                if (wc['field_key'] == 'board_picture'):
                    if wc['value'] is not None:
                        if ('.jpg' or '.png') in wc['value']:
                            wc['value'] = imageUrl + wc['value']
                if wc['value'] == '1':
                    wc['value'] = wc['yes_value']
                else :
                    if wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '-1':
                        wc['value'] = 'N/A'
                    else:
                        wc['value'] = wc['value']

        if 'Correction & Action Requirements' in rpt_form_details:
            for wc in rpt_form_details['Correction & Action Requirements'] :
                if wc['value'] == '1':
                    wc['value'] = wc['yes_value']
                else :
                    if wc['value'] == '0':
                        wc['value'] = wc['no_value'] 
                    elif wc['value'] == '-1':
                        wc['value'] = 'N/A'
                    else:
                        wc['value'] = wc['value']
        
        result['rpt_form_details'] = rpt_form_details

        field_keys = h.execute_sp('rpt_form_field_keys', [1284, self.lang], self.args)

        df_keys = pandas.DataFrame(field_keys)
        section_df =  df_keys.groupby('original_section_name').apply(lambda x: x.to_dict('records')).to_dict() #DB 
       
       # missing_keys = ['updated_jhsc_member_list_and_contact_Info','first_aid_regulation_101_poster','should_know_oesa_poster', 'wsib_in_case_of_Injury_at_work_poster', 'technica_10_fundamental_rules_poster','work_refusal_flow_chart','health_safety_at_work_poster'] 

        for section,data in result['rpt_form_details'].items(): 
            if section == 'Safety/JHS Board':
                field_keys_list = {each['fieldKey']:{'fieldName':each['fieldName'],'FieldOrder': each['FieldOrder']} for each in section_df[section]} #field_key from DB
               
                data_key_list = [each['field_key'] for each in data] #field_key from rpt_form_details

                for field_key in field_keys_list:                
                    if field_key not in data_key_list :
                        data.append(
                            {
                                "field_key":field_key,
                                "field_name":field_keys_list[field_key]['fieldName'],
                                "value":' ',
                                "field_order":field_keys_list[field_key]['FieldOrder']
                            }
                        )
        
        result['rpt_form_details']['Safety/JHS Board'] = sorted(result['rpt_form_details']['Safety/JHS Board'], key=lambda d:d['field_order'])
        return result
    