#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('loto')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.   
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions']    
        generalAction=apiData['rpt_get_general_action_by_id']
        reviewers=apiData['rpt_form_reviewers']
        additionalDetails = apiData['rpt_loto_additional_details']
        lotoDetails = apiData['rpt_loto_details']
        mechanisms = apiData['rpt_loto_mechanisms']
        positiveRecognition = apiData['rpt_positive_recognition']
        reportDistributors=apiData['rpt_form_details_distribution']

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'data': apiData,
            'generalAction':generalAction,
            'reviewers':reviewers,
            'additionalDetails':additionalDetails,
            'lotoDetails':lotoDetails,
            'mechanisms':mechanisms,
            'positiveRecognition':positiveRecognition,
            'reportDistributors':reportDistributors
        }

        return report
    