#Import required modules
import yaml
import helper as h

from reports.target_status_by_employee import Report as emp_report
from reports.target_status_by_role import Report as role_report
from reports.target_status_by_site import Report as site_report
from reports.target_status_by_job import Report as job_report

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('target_status_summary')
        self.args = args
        self.params = h.get_url_param(args)
        self.lang = args['lang'] if args and 'lang' in args else 1   

#Function to get data from the API as per the report section requirement.    
    def get_report(self, filters=None):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')
       
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        meta['language_code'] = h.execute_sql("select lng_name from language where lng_id = " + str(self.lang))['result'][0]['lng_name']
        self.args = meta['args']
      

       #Employee
        if 'report_selection' in self.args and (self.args['report_selection'] == '9'):
            return emp_report.get_report(self)
        #Role
        elif 'report_selection' in self.args and (self.args['report_selection'] == '76'):
            return role_report.get_report(self)   
        #Site
        elif 'report_selection' in self.args and (self.args['report_selection'] == '75'):
            return site_report.get_report(self) 
        #job
        elif 'report_selection' in self.args and (self.args['report_selection'] == '105'): 
            return job_report.get_report(self) 
        else:   
            report = {            
                'meta': meta,
                'data': apiData
            }
            return report
    