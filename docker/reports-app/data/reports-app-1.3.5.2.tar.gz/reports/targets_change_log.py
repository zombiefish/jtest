#Import required modules
import yaml
import helper as h
import plotly
import json
import plotly.express as px
import pandas as pd

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('targets_change_log')
        self.args = args
        self.params = h.get_url_param(args)
        
#Function to get data from the API as per the report section requirement.     
    def get_report(self, per_id):
        c = self.config
        apiData = h.get_report(f'{c["api"]}/{per_id}?{self.params}')

        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        meta['filter_data'] = apiData['filter_data']

        if 'target_comment_data' in apiData: 
            targetCommentdata=apiData['target_comment_data'] if 'target_comment_data' in apiData and len(apiData['target_comment_data']) > 0 else []
            targetFormData=apiData['target_comment_data']['form_data'] if 'form_data' in apiData['target_comment_data'] and len(apiData['target_comment_data']['form_data']) > 0 else []
            targetFormDataDetails=apiData['target_comment_data']['form_data']['details'] if 'details' in apiData['target_comment_data']['form_data'] and len(apiData['target_comment_data']['form_data']) > 0 else []
        else:
            targetCommentdata = []
            targetFormData = []
        
        report = {            
            'meta': meta,
            'data': apiData,
            'targetCommentdata':targetCommentdata,
            'targetFormData':targetFormData
        }

        return report
    