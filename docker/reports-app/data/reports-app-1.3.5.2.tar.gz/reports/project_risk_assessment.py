#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('project_risk_assessment')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_pra_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_pra_hap']
        hazardsInitial=apiData['rpt_hap_pictures_initial']
        hazardsFollowup=apiData['rpt_hap_pictures_followup']
        generalAction=apiData['rpt_pra_general_actions']
        generalActionInitial=apiData['rpt_pra_general_action_attachment_by_id_initial']
        generalActionFollowup=apiData['rpt_pra_general_action_attachment_by_id_followup']
        reviewers=apiData['rpt_pra_reviewers']
        praParticipants=apiData['rpt_pra_participants'][0]
        praApprovers=apiData['rpt_pra_approvers'][0] 
        praThreats=apiData['rpt_pra_threats']
        oraLineItems=apiData['rpt_pra_ora_items'][0]
        oraPraBowtieHeader=apiData['rpt_ora_pra_bowtie_header']
        bowtieApprovers=apiData['rpt_bowtie_approvers'][0] if 'rpt_bowtie_approvers' in apiData and len(apiData['rpt_bowtie_approvers']) > 0 else []
        bowtieParticipants=apiData['rpt_bowtie_participants'][0] if 'rpt_bowtie_participants' in apiData and len(apiData['rpt_bowtie_participants']) > 0 else []
        praApprovedBy =apiData['rpt_pra_approved_by'] if 'rpt_pra_approved_by' in apiData and len(apiData['rpt_pra_approved_by']) > 0 else []
        steps=apiData['steps']
        attachments=apiData['rpt_get_pra_attachment_pra_id']

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'hazardsInitial':hazardsInitial,
            'hazardsFollowup':hazardsFollowup,
            'data': apiData,
            'generalAction':generalAction,
            'generalActionInitial':generalActionInitial,
            'generalActionFollowup':generalActionFollowup,
            'reviewers':reviewers,
            'praParticipants':praParticipants,
            'praApprovers':praApprovers,
            'praThreats':praThreats,
            'praApprovedBy':praApprovedBy,
            'oraLineItems':oraLineItems ,
            'oraPraBowtieHeader':oraPraBowtieHeader,
            'bowtieApprovers':bowtieApprovers,
            'bowtieParticipants':bowtieParticipants,
            'steps':steps,
            'attachments':attachments
        }

        return report
    