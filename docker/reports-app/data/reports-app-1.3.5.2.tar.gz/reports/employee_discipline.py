#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('employee_discipline')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.        
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        formDetails=apiData['rpt_form_details']
        disciplineLegend=apiData['rpt_employee_discipline_type_legend']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        hazardsList = apiData['rpt_hazard_actions']
        generalAction=apiData['rpt_get_general_action_by_id']
        positiveRecognition=apiData['rpt_positive_recognition']
        signatures=apiData['rpt_form_details']['Signatures'] if 'Signatures' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Signatures']) > 0 else []

        employeeTimeStamp=[]
        supervisorTimeStamp=[]
        managerTimeStamp=[]

#Adding new list to the data structure to get the timestamps on the signatures
        for s in signatures:
            if s['field_key'] == 'signature_employee_img_time':
                employeeTimeStamp.append(s)
            if s['field_key'] == 'signature_superintendent_img_time':
                supervisorTimeStamp.append(s)
            if s['field_key'] == 'signature_manager_img_time':
                managerTimeStamp.append(s)

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'formDetails': formDetails,
            'disciplineLegend': disciplineLegend,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'employeeTimeStamp': employeeTimeStamp,
            'supervisorTimeStamp': supervisorTimeStamp,
            'managerTimeStamp': managerTimeStamp,
            'signatures': signatures,

            'generalAction':generalAction,
            'positiveRecognition':positiveRecognition,
            'hazardsList': hazardsList,



        }

        return report
    