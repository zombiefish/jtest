#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('employee_performance')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.        
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        formDetails = apiData['rpt_form_details']        
        meta['labels'] = apiData['labels']

        evaluation=apiData['rpt_form_details']['Evaluation Information'] if 'Evaluation Information' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Evaluation Information']) > 0 else []
        ratings=apiData['rpt_form_details']['Rating'] if 'Rating' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Rating']) > 0 else []
        signatures=apiData['rpt_form_details']['Signatures'] if 'Signatures' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Signatures']) > 0 else []
        employeeSignature=apiData['rpt_form_pictures_employee']
        reviewerSignature=apiData['rpt_form_pictures_reviewer']

#Adding new list to the data structure to get the timestamps on the signatures
        employeeTimeStamp=[]
        reviewerTimeStamp=[]

        for s in signatures:
            if s['field_key'] == 'signature_employee_img_time':
                employeeTimeStamp.append(s)
            if s['field_key'] == 'signature_reviewer_img_time':
                reviewerTimeStamp.append(s)

        comments=apiData['rpt_form_details']['Comments'] if 'Comments' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Comments']) > 0 else []
        legend = apiData['rpt_employee_performance_legend']
        reportDistributors=apiData['rpt_form_details_distribution'] 
        reviewers=apiData['rpt_form_reviewers']
   

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'formDetails':formDetails,
            'evaluation':evaluation,
            'signatures':signatures,
            'reportDistributors':reportDistributors,
            'ratings':ratings,
            'comments':comments,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'legend':legend,
            'employeeTimeStamp': employeeTimeStamp,
            'reviewerTimeStamp': reviewerTimeStamp,
            'employeeSignature':employeeSignature,
            'reviewerSignature':reviewerSignature,
            'labels': meta['labels'],

        }

        return report
    