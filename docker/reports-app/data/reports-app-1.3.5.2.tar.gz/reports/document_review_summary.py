#Import required modules
import yaml
import helper as h
from reports.document_review_summary_by_site import Report as site_report
from reports.document_review_summary_by_user import Report as user_report
from reports.document_review_summary_by_document import Report as document_report

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('document_review_summary')
        self.args = args
        self.params = h.get_url_param(args)
        self.lang = args['lang'] if args and 'lang' in args else 1   

#Function to get data from the API as per the report section requirement.    
    def get_report(self, filters=None):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        self.args = meta['args']

        #Document Review Summary by Site
        if 'report_selection' in self.args and (self.args['report_selection'] == '89'):
            return site_report.site_functionlity(self=self, meta=meta, apiData=apiData)

        #Document Review Summary by User
        elif 'report_selection' in self.args and (self.args['report_selection'] == '90'):
            return user_report.get_report(self)   
        
        #Document Review Summary by Document
        elif 'report_selection' in self.args and (self.args['report_selection'] == '99'):
            return document_report.get_report(self) 
                
        report = {            
            'meta': meta,
            'data': apiData,
            #'user_select':user_select
            #'tableData': tableData,

        }
        return report
    