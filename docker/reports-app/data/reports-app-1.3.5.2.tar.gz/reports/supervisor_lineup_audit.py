#Import required modules
import yaml
import helper as h


#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('supervisor_lineup_audit')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.   
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions_list']
        hazardsInitial = apiData['rpt_hap_pictures_initial']
        hazardsFollowup = apiData['rpt_hap_pictures_followup']
        positiveRecognition = apiData['rpt_positive_recognition']
        positiveRecognitionImages=apiData['rpt_pid_pictures']
        generalAction=apiData['rpt_get_general_action_by_id']
        generalActionInitial=apiData['rpt_get_general_action_attachment_by_sga_id_initial']
        generalActionFollowup=apiData['rpt_get_general_action_attachment_by_sga_id_followup']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        lineup=apiData['rpt_form_details']['Lineup'] if 'Lineup' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Lineup']) > 0 else []
        comments=apiData['rpt_form_details']['Comments'] if 'Comments' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Comments']) > 0 else []
        correctionActionRequirements=apiData['rpt_form_details']['Correction & Action Requirements'] if 'Correction & Action Requirements' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Correction & Action Requirements']) > 0 else []
        pidLikes=apiData['rpt_positive_recognition_likes']
        pidComments=apiData['rpt_positive_recognition_comment']

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'hazardsFollowup':hazardsFollowup,
            'hazardsInitial':hazardsInitial,
            'data': apiData,
            'positiveRecognition': positiveRecognition,
            'apiData': apiData,
            'positiveRecognitionImages':positiveRecognitionImages,
            'generalAction':generalAction,
            'generalActionInitial':generalActionInitial,
            'generalActionFollowup':generalActionFollowup,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'lineup':lineup,
            'comments':comments,
            'correctionActionRequirements':correctionActionRequirements,
            'pidLikes':pidLikes,
            'pidComments':pidComments
        }

        return report
    