#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('vale_flha')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.       
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions']
        positiveRecognition = apiData['rpt_positive_recognition']
        generalAction=apiData['rpt_get_general_action_by_id']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        equipedForWork=apiData['rpt_form_details']['Equipped for work'] if 'Equipped for work' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Equipped for work']) > 0 else []
        headerDetails=apiData['rpt_form_details']['Header Details'] if 'Header Details' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Header Details']) > 0 else []
        criticalInformation=apiData['rpt_form_details']['Critical Communication Information'] if 'Critical Communication Information' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Critical Communication Information']) > 0 else []
        tasks=apiData['rpt_form_tasks'] 
        criticalActivity=apiData['rpt_critical_activity_req']
        workplaceConditions=apiData['rpt_vale_flha_tasks']
        stateDetails=apiData['rpt_form_details']['State Details'] if 'State Details' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['State Details']) > 0 else []
        signature=apiData['rpt_form_details']['Signature'] if 'Signature' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Signature']) > 0 else []
        endShiftReview=apiData['rpt_form_details']['Review'] if 'Review' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Review']) > 0 else []

        #Adding new list to the data structure to get the timestamps on the signatures
        supervisorTimeStamp=[]
        managerTimeStamp=[]
        otherTimeStamp=[]

        for s in signature:
            if s['field_key'] == 'signature_supervisor_img_time':
                supervisorTimeStamp.append(s)
            if s['field_key'] == 'signature_manager_img_time':
                managerTimeStamp.append(s)
            if s['field_key'] == 'signature_other_img_time':
                otherTimeStamp.append(s)
        criticalLabel=apiData['rpt_vale_flha_critical_activity_requirements']

        multiphotosStart = []
        startDetailsInfo=[]
        supervisorComments=[]
        for wd in stateDetails:
            if 'start_state_pictures' in wd['field_key']:
                multiphotosStart.append(wd)
            elif 'start_state_details' in wd['field_key']:
                startDetailsInfo.append(wd)
            elif 'supervisor_comments' in wd['field_key']:
                supervisorComments.append(wd)     
        #Adding new list to the report specific images
        multiphotosEnd = []
        endDetailsInfo=[]
        for wd in stateDetails:
            if 'end_state_pictures' in wd['field_key']:
                multiphotosEnd.append(wd)
            elif 'end_state_details' in wd['field_key']:
                endDetailsInfo.append(wd)

        report = {
           'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'data': apiData,
            'positiveRecognition': positiveRecognition,
            'apiData': apiData,
            'generalAction':generalAction,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'equipedForWork':equipedForWork,
            'headerDetails':headerDetails,
            'criticalInformation':criticalInformation,
            'tasks':tasks,
            'workplaceConditions':workplaceConditions,
            'stateDetails':stateDetails,
            'multiphotosStart':multiphotosStart,
            'multiphotosEnd':multiphotosEnd,
            'signature':signature,
            'criticalActivity':criticalActivity,
            'startDetailsInfo':startDetailsInfo,
            'endDetailsInfo':endDetailsInfo,
            'criticalLabel':criticalLabel,
            'supervisorTimeStamp':supervisorTimeStamp,
            'managerTimeStamp': managerTimeStamp,
            'otherTimeStamp': otherTimeStamp,
            'supervisorComments':supervisorComments,
            'endShiftReview':endShiftReview
        }

        return report
    