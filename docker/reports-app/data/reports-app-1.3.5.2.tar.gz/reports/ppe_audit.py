#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('ppe_audit')
        self.args = args
        self.params = h.get_url_param(args)
 
#Function to get data from the API as per the report section requirement.    
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        formDetails = apiData['rpt_form_details']
        hazardsList = apiData['rpt_hazard_actions']
        generalAction=apiData['rpt_get_general_action_by_id']
        positiveRecognition=apiData['rpt_positive_recognition']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        comment=apiData['rpt_form_details']['General Comment'] if 'General Comment' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['General Comment']) > 0 else []
        ppeAudit=apiData['rpt_form_details']['PPE Audit'] if 'PPE Audit' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['PPE Audit']) > 0 else []
        ppeStandards=apiData['rpt_form_details']['PPE Standard'] if 'PPE Standard' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['PPE Standard']) > 0 else []
        ppeSpecialty =apiData['rpt_form_details']['PPE Specialty'] if 'PPE Specialty' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['PPE Specialty']) > 0 else []
        ppePhotos =apiData['rpt_form_details']['PPE Photos'] if 'PPE Photos' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['PPE Photos']) > 0 else []


#Adding new list to the report specific images
        multiphotos = []
        for wd in ppeSpecialty:
            if 'ppe_pictures' in wd['field_key']:
                multiphotos.append(wd)
                del wd

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'formDetails':formDetails,
            'hazardsList':hazardsList,
            'generalAction':generalAction,
            'positiveRecognition':positiveRecognition,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'comment':comment,
            'ppeAudit':ppeAudit,
            'ppeStandards':ppeStandards,
            'ppeSpecialty':ppeSpecialty,
            'ppePhotos': ppePhotos,
            'multiphotos':multiphotos,
        }

        return report
    