#Import required modules
from requests import api
import yaml
import helper as h

#Defining a class as report
class Report:
#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('hot_work_permit')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.    
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')

        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions']
        positiveRecognition = apiData['rpt_positive_recognition']
        generalAction=apiData['rpt_get_general_action_by_id']
        reportDistributors = apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']

        details = apiData['rpt_form_details']['Details'] if 'Details' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Details']) > 0 else []
        preworkSignatures = apiData['rpt_form_details']['Pre-Work Signatures'] if 'Pre-Work Signatures' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Pre-Work Signatures']) > 0 else []
        hotWorkCompletion = apiData['rpt_form_details']['Completion of Hot Work'] if 'Completion of Hot Work' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Completion of Hot Work']) > 0 else []
        highRiskLocation=apiData['rpt_form_details']['High Risk Location'] if 'High Risk Location' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['High Risk Location']) > 0 else []
        whyHighRisk = apiData['rpt_form_details']['Why is this high Risk Hot Work'] if 'Why is this high Risk Hot Work' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Why is this high Risk Hot Work']) > 0 else []
        airQualityTest=apiData['rpt_form_details']['Air Quality Test'] if 'Air Quality Test' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Air Quality Test']) > 0 else []
        fireWatch = apiData['rpt_form_details']['Fire Watch'] if 'Fire Watch' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Fire Watch']) > 0 else []
        airQualityTestData = apiData['rpt_hot_work_permit_air_quality_test'] if 'rpt_hot_work_permit_air_quality_test' in apiData and len(apiData) > 0 else []
        fireWatchData = apiData['rpt_hot_work_permit_fire_watch'][0]
        fireWatchData[0]['WatcherName'] = fireWatchData[0]['WatcherName'].replace('\\','')


        
        for risk in whyHighRisk:
            if risk['field_key'] == 'location':
                flag_whyHighRisk = risk['original_value']
        

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'hazardsList':hazardsList,
            'positiveRecognition':positiveRecognition,
            'generalAction':generalAction,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'details':details,
            'preworkSignatures':preworkSignatures,
            'hotWorkCompletion':hotWorkCompletion,
            'highRiskLocation':highRiskLocation,
            'whyHighRisk':whyHighRisk,
            'airQualityTest':airQualityTest,
            'fireWatch':fireWatch,
            'airQualityTestData':airQualityTestData,
            'fireWatchData':fireWatchData,
            'flag_whyHighRisk':flag_whyHighRisk
        }

        return report
    