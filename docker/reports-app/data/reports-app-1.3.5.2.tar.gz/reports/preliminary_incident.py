#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('preliminary_incident')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.         
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions']
        positiveRecognition = apiData['rpt_positive_recognition']
        generalAction=apiData['rpt_get_general_action_by_id']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        incidents=apiData['rpt_form_details']['Incident Report'] if 'Incident Report' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Incident Report']) > 0 else []
        incidentsInformation=apiData['rpt_form_details']['Incident Information'] if 'Incident Information' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Incident Information']) > 0 else []
        personnelInvolved=apiData['rpt_form_details']['Personnel Involved'] if 'Personnel Involved' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Personnel Involved']) > 0 else []
        otherInvolved=apiData['rpt_form_details']['Other(s) Involved'] if 'Other(s) Involved' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Other(s) Involved']) > 0 else []
        incidentsDescription=apiData['rpt_form_details']['Incident Description'] if 'Incident Description' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Incident Description']) > 0 else []
        preliminaryChecklist=apiData['rpt_form_details']['Preliminary Report Checklist'] if 'Preliminary Report Checklist' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Preliminary Report Checklist']) > 0 else []
        equipmentInvolved=apiData['rpt_form_details']['Equipment Involved'] if 'Equipment Involved' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Equipment Involved']) > 0 else []
        incidentAttachments= apiData['rpt_incident_attachments']
        updateSummary=apiData['rpt_submission_change_log']
        
        
        #Converting boolean values to yes/no
        if len(positiveRecognition) > 0:
            for pid in positiveRecognition:
                pid['Was_Recognition_Given'] = 'Yes' if  pid['Was_Recognition_Given'] == '\u0001' else 'No'


        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'hazardsList': hazardsList,
            'data': apiData,
            'positiveRecognition': positiveRecognition,
            'apiData': apiData,
            'generalAction':generalAction,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'incidents':incidents,
            'incidentsInformation':incidentsInformation,
            'personnelInvolved':personnelInvolved,
            'otherInvolved':otherInvolved,
            'incidentsDescription':incidentsDescription,
            'preliminaryChecklist':preliminaryChecklist,
            'incidentAttachments':incidentAttachments,
            'updateSummary':updateSummary,
            'equipmentInvolved': equipmentInvolved,
        }

        return report
    