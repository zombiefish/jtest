#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('technician_field_service')
        self.args = args
        self.params = h.get_url_param(args)
 
#Function to get data from the API as per the report section requirement.    
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions']
        positiveRecognition = apiData['rpt_positive_recognition']
        generalAction=apiData['rpt_get_general_action_by_id']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        additionalHeaderInfo = apiData['rpt_form_details']['Additional information'] if 'Additional information' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Additional information']) > 0 else []
        serviceSummary=apiData['rpt_technician_field_service_services'] if 'rpt_technician_field_service_services' in apiData and len(apiData['rpt_technician_field_service_services']) > 0 else []
        comments = apiData['rpt_form_details']['Comments'] if 'Comments' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Comments']) > 0 else []
        signatures = apiData['rpt_form_details']['Signatures'] if 'Signatures' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Signatures']) > 0 else []
        totalValues = apiData['rpt_technician_field_service_totals'] if 'rpt_technician_field_service_totals' in apiData and len(apiData['rpt_technician_field_service_totals']) > 0 else []

        #Adding new list to the data structure to get the timestamps on the signatures
        supervisorTimeStamp=[]
        customerTimeStamp=[]

        for s in signatures:
            if s['field_key'] == 'signature_supervisor_img_time':
                supervisorTimeStamp.append(s)
            if s['field_key'] == 'signature_customer_img_time':
                customerTimeStamp.append(s)

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'data': apiData,
            'positiveRecognition': positiveRecognition,
            'apiData': apiData,
            'generalAction':generalAction,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'additionalHeaderInfo':additionalHeaderInfo,
            'serviceSummary':serviceSummary,
            'comments':comments,
            'signatures':signatures,
            'supervisorTimeStamp':supervisorTimeStamp,
            'customerTimeStamp':customerTimeStamp,
            'totalValues':totalValues,
        }

        return report   
    