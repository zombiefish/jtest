#Import required modules
import pandas as pd
import yaml
import helper as h
import plotly
import json
import plotly.express as px

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('incident_summary')
        self.args = args
        self.params = h.get_url_param(args)
        self.lang = args['lang'] if args and 'lang' in args else 1        


#Function to get data from the API as per the report section requirement.   
    def get_report(self):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')
        
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        meta['filter_data'] = apiData['filter_data']
        meta['language_code'] = h.execute_sql("select lng_name from language where lng_id = " + str(self.lang))['result'][0]['lng_name']

        colors = ['#0072ce', '#66aae2', '#00447c', '#6e94ba', '#7272ad', '#d8bd87', '#447259',
                            '#474747', '#b3bccf', '#99bcac', '#a9ddff', '#96a9aa', '#001e60', '#777777', '#005ba5',
                            '#0087b3', '#002e52', '#99c7eb', '#a4a1d5', '#00445a', '#378ddc', '#424686', '#fcecb3',
                            '#9c6492', '#16492d', '#d193ae', '#eacfce', '#8a7fd0', '#616699', '#006586', '#ddab00',
                            '#c292cd', '#d6d3ff', '#5f3c79', '#00a9e0', '#ffb359', '#58cad3']

        response_plotly_json = apiData['response_plotly_json'] if 'response_plotly_json' in apiData and len(apiData['response_plotly_json']) > 0 else []
        response_plotly_json_past_year = apiData['response_plotly_json_past_year'] if 'response_plotly_json_past_year' in apiData and len(apiData['response_plotly_json_past_year']) > 0 else []
        labels =apiData['labels'] if 'labels' in apiData and len(apiData['labels']) > 0 else []
        
        
        data={
            "rec_inc_inj_ytd": [],
            "rec_inc_inj_past_12_months": [],
            }
        if 'response_plotly_json' in apiData:
            data['rec_inc_inj_ytd'].append({
            'type': 'line',
            'x': response_plotly_json[0]['dates'],
            'y': list(map(float,response_plotly_json[0]['y_axis_trifr'])),
            'yaxis': 'y',
            'name': labels['recordable_injuries_label'],
            })

            data['rec_inc_inj_ytd'].append({
            'type': 'line',
            'x': response_plotly_json[0]['dates'],
            'y': list(map(float,response_plotly_json[0]['y_axis_trir'])),
            'name': labels['recordable_incidents_label'],
            'yaxis': 'y2',
            })

        
        if 'response_plotly_json_past_year' in apiData:
            data['rec_inc_inj_past_12_months'].append({
                'type': 'line',
                'x': response_plotly_json_past_year[0]['dates'],
                #'x': ['2020-12-02', '2020-12-09', '2020-12-16', '2020-12-23', '2020-12-30'],
                'y': list(map(float,response_plotly_json_past_year[0]['y_axis_trifr'])),
                #'y': [2,5,7,10,9],
                'yaxis': 'y',
                'name': labels['recordable_injuries_label'],
                })
            
            data['rec_inc_inj_past_12_months'].append({
                'type': 'line',
                'x': response_plotly_json_past_year[0]['dates'],
                'y': list(map(float,response_plotly_json_past_year[0]['y_axis_trir'])),
                #'x': ['2020-12-02', '2020-12-09', '2020-12-16', '2020-12-23', '2020-12-30'],
                #'y': [1000,8000,5000,2000,6000],
                'name': labels['recordable_incidents_label'],
                'yaxis': 'y2',
            })

       
        # # labels
        labels = []
        inc_type = []
        df_incident_summary = None
        df_incident_type = []
        incidentJSON = []
        rca_type = []
        rcaJSON = []

        #Modified the data structure to plot the graph
        if 'rpt_incident_summary' in apiData:
            if apiData['rpt_incident_summary']:
                labels = apiData['labels']
                # incident summary table data into dataframe
                df_incident_summary = pd.DataFrame(apiData['rpt_incident_summary'])
                df_incident_summary.fillna('None', inplace=True)
                df_incident_summary['hazardreports'] = df_incident_summary['hazardreports'].replace('None',0)

                # incident type plotly graph
                df_incident_type = df_incident_summary.groupby('incidenttype').agg('count').reset_index()

                incidentJSON = [{
                    "labels" : df_incident_type['incidenttype'].values.tolist(),
                    "values" : df_incident_type['count_label'].values.tolist(),
                    "type" : "pie",
                    "marker" : {
                        "colors" : colors
                    },
                }]

                # rca type plotly graph
                df_rca_type = df_incident_summary.groupby('RCATYPE').agg('count').reset_index()              

                rcaJSON = [{
                    "labels" : df_rca_type['RCATYPE'].values.tolist(),
                    "values" : df_rca_type['count_label'].values.tolist(),
                    "type" : "pie",    
                    "marker" : {
                        "colors" : colors
                    },     
                }]

                inc_type = df_incident_type[['incidenttype', 'count_label']]
                rca_type = df_rca_type[['RCATYPE', 'count_label']]
            else:
                labels = apiData['labels']



        report = {            
            'meta': meta,
            'data': apiData,
            'labels': labels,
            'incident_summary': df_incident_summary,
            'incident_count' :  inc_type,
            'incidentJSON': incidentJSON,
            'rca_count': rca_type, 
            'rcaJSON':rcaJSON,
            'response_plotly_json': response_plotly_json,
            'response_plotly_json_past_year': response_plotly_json_past_year,
            'graphData':data
        }
        return report
    