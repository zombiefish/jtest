#Import required modules
import yaml
import helper as h


#Defining a class as report
class Report:
#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('job_risk_assessment')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.    
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_jra_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_jra_hap']
        hazardsInitial=apiData['rpt_hap_pictures_initial']
        hazardsFollowup=apiData['rpt_hap_pictures_followup']
        generalAction=apiData['rpt_jra_general_actions']
        #generalActionInitial=apiData['rpt_jra_general_actions']
        generalActionInitial=apiData['rpt_jra_general_action_attachment_by_id_initial']
        generalActionFollowup=apiData['rpt_jra_general_action_attachment_by_id_followup']
        reportApproved =apiData['rpt_jra_approved_by']
        reviewers=apiData['rpt_jra_reviewers']
        jraPraItems=apiData['rpt_jra_pra_items']
        jraParticipants=apiData['rpt_jra_participants']
        jraApprovers=apiData['rpt_jra_approvers']
        jraThreats=apiData['rpt_jra_threats']
        jraApprovedBy =apiData['rpt_jra_approved_by'] if 'rpt_jra_approved_by' in apiData and len(apiData['rpt_jra_approved_by']) > 0 else []
        steps = apiData['steps']
        attachments=apiData['rpt_get_jra_attachment_jra_id']
        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'hazardsInitial':hazardsInitial,
            'hazardsFollowup':hazardsFollowup,
            'data': apiData,
            'generalAction':generalAction,
            'generalActionInitial':generalActionInitial,
            'generalActionFollowup':generalActionFollowup,
            'reportApproved':reportApproved,
            'reviewers':reviewers,
            'jraPraItems':jraPraItems,
            'jraParticipants':jraParticipants,
            'jraApprovers':jraApprovers,
            'jraThreats':jraThreats,
            'jraApprovedBy':jraApprovedBy,
            'steps':steps,
            'attachments':attachments
        }

        return report
    