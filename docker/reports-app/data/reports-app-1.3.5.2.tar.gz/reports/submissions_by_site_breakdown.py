#Import required modules
from time import strftime
import yaml
import helper as h
import json
import pandas as pd
import datetime

import reports._submission_dates as _submission_dates

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('submissions_by_site_breakdown')
        self.args = args
        self.params = h.get_url_param(args)
        self.lang = args['lang'] if args and 'lang' in args else 1

#Function to get data from the API as per the report section requirement. 
    def get_report(self):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')

        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        meta['filter_data'] = apiData['filter_data']
        meta['labels'] = apiData['labels']
        meta['chart_labels'] = apiData['chart_labels']
        meta['language_code'] = h.execute_sql("select lng_name from language where lng_id = " + str(self.lang))['result'][0]['lng_name']

        inactive_label = h.execute_sp('get_translation_by_tag', [9169,self.lang,1], self.args)[0]['ltr_text']


        #Modifying the data structure to group by site
        if 'rpt_submissions_by_site_breakdown' in apiData and apiData['rpt_submissions_by_site_breakdown']:

           
            df_rpt_submissions_by_date_site = pd.DataFrame(apiData['rpt_submissions_by_breakdown_date_site'])
            df_rpt_submissions_by_date_site.fillna('')
            df_rpt_submissions_by_site_breakdown = pd.DataFrame(apiData['rpt_submissions_by_site_breakdown'])
            df_rpt_submissions_by_site_breakdown.fillna('')
            df_rpt_submissions_by_date = pd.DataFrame(apiData['rpt_submissions_by_breakdown_date'])
            df_rpt_submissions_by_date.fillna('')

            site_groups = df_rpt_submissions_by_site_breakdown.groupby('site_name')
            form_groups = df_rpt_submissions_by_site_breakdown.groupby('form_name')

            total_by_sites = {}
            for sitename, sitedata in site_groups:
                total_by_sites[sitedata['site_name'].unique()[0]] = sitedata['site_name'].sum()

            top_10_forms = df_rpt_submissions_by_site_breakdown.groupby('site_name')['form_count'].sum().reset_index().sort_values('form_count', ascending=False).head(10).to_dict(orient='records')     

            allSites = [form['site_name'] for form in top_10_forms]    
            allFormCounts = [form['form_count'] for form in top_10_forms]
            
            newdata = [                
                    {
                        "y": allSites,
                        "x": allFormCounts,
                        "type": 'bar',
                        "orientation": 'h',                        
                    }
                ]

            # # Months With the Most Submissions Dataframes
            df_rpt_submissions_by_site_breakdown['submission_date'] = pd.to_datetime(df_rpt_submissions_by_site_breakdown['submission_date'], format='%Y-%m-%d')
            df_rpt_submissions_by_site_breakdown['year'] = df_rpt_submissions_by_site_breakdown['submission_date'].dt.year
            df_rpt_submissions_by_site_breakdown['month'] = df_rpt_submissions_by_site_breakdown['submission_date'].dt.month
            
            # Adding in the Month, Date to the Data set
            df_rpt_submissions_by_site_breakdown['Month_text'] = df_rpt_submissions_by_site_breakdown['submission_date'].dt.strftime("%B")

            # pie graph for showing Form Totals
            pieAllForms = []
            pieAllValues = []
            grandTotal = 0
            for rec in apiData['rpt_submissions_by_site_breakdown']:
                pieAllForms.insert(0,rec['form_name_label'])
                pieAllValues.insert(0,rec['form_count'])
                grandTotal += rec['form_count']

            # Grouping the data by job for the months with the most submissions table
            site_groups_Data = []
            monthly_count = df_rpt_submissions_by_site_breakdown.groupby('site_name')
            for groupname, data in monthly_count:               
                site_group = {}
                site_group['site_enable_status'] = groupname
                site_group['status'] = list(data['site_enable_status'])
                site_group['site_name']  = groupname    
                data =pd.DataFrame(data[['year', 'Month_text', 'form_count', 'site_enable_status']])
                # Returns the sums by month with the year
                month_groups = data.groupby(['year','Month_text']).agg({'form_count': 'sum'}).reset_index()[:5]
                month_groups = pd.DataFrame(month_groups)
                month_groups = month_groups.sort_values('form_count', ascending=False)
                site_group['month_group_count'] = month_groups.to_dict(orient='records')
                site_group['total_form_count'] = data['form_count'].sum()
                site_groups_Data.append(site_group)

            # All data for pie chart per site
            site_groups_Data_Pie_Chart = []
            forms_per_site_list = []
            monthly_count = df_rpt_submissions_by_site_breakdown.groupby('site_name')
            for groupname, data in monthly_count:
                job_group = {}
                job_group['site_name']  = groupname
                data =pd.DataFrame(data[['form_name', 'form_count', 'submission_date']])
                job_group['site_data'] = data.groupby('form_name')['form_count'].sum().reset_index().sort_values('form_count', ascending=False).head(10).to_dict(orient='records')                
                site_groups_Data_Pie_Chart.append(job_group)
                form_count_per_site = {}
                for e in job_group['site_data']:
                    for i,j in e.items():
                        form_count_per_site.setdefault(i, []).append(j)
                forms_per_site_list.append(form_count_per_site)

            # Getting the top and bottom 10 values for form submissions
            top10_list = {}
            bottom10_list = {}
            for site in site_groups_Data_Pie_Chart:
                top10Values=[]
                bottom10Values =[]
                top10Values = sorted(site['site_data'], key=lambda k: k['form_count'])[-10:]            
                top10Values = sorted(top10Values, key=lambda top10Values: (-top10Values['form_count']))
                top10_list[site['site_name']]=top10Values            
                bottom10Values = sorted(site['site_data'], key=lambda k: k['form_count'])[:10]
                bottom10_list[site['site_name']] = bottom10Values

            # Grouping the data by user for the form count per user table
            site_forms_Data = []
            monthly_count = df_rpt_submissions_by_site_breakdown.groupby('site_name')
            for groupname, data in monthly_count:               
                form_group = {}
                form_group['full_name']  = groupname    
                data =pd.DataFrame(data[['year', 'Month_text', 'form_count', 'form_name']])
                form_group['total_form_count'] = data['form_count'].sum()
                form_group['job_data'] = data.to_dict(orient='records')
                site_forms_Data.append(form_group)

            top_10_forms = df_rpt_submissions_by_site_breakdown.groupby('form_name')['form_count'].sum().reset_index().sort_values('form_count', ascending=False).head(10).to_dict(orient='records')     

            allForms = [form['form_name'] for form in top_10_forms]    
            allFormCounts = [form['form_count'] for form in top_10_forms]      

            newdata2 = [{
                        "y": allForms,
                        "x": allFormCounts,
                        "type": 'bar',
                        "orientation": 'h',
                        "xaxis" : allForms,
                        "name": allForms,
                    }]

            # Grouping the data by user for the months with the most submissions table
            linegraph_Data = []
            monthly_count = df_rpt_submissions_by_date_site.groupby('submission_date')
            for groupname, data in monthly_count:               
                user_group = {}
                user_group['submission_date']  = groupname    
                data =pd.DataFrame(data[['submission_date', 'form_count']])
                user_group['total_form_count'] = data['form_count'].sum()
                data = data.sort_values('form_count', ascending=False).head(5)
                linegraph_Data.append(user_group)

            lineAllDates2 =[]
            lineAllValues2 = []
            for rec in linegraph_Data:
                lineAllDates2.append(rec['submission_date'])
                lineAllValues2.append(rec['total_form_count'])

            lineGraphData = []
            if apiData['rpt_submissions_by_site_breakdown']:
                lineGraphData = [
                    {
                        "y": lineAllValues2,
                        "x": lineAllDates2,
                        "type": 'line',
                    }
                ]

            # Line graph attribute definition
            lineLayout = {
                "title": {
                    "text": h.execute_sp('get_translation_by_tag', [9099,self.lang,1], self.args)[0]['ltr_text'],
                    "font": {
                        "family": "Arial black",
                        "size": 14,
                    }
                },
                "height": 500,
                "width": 750,
                "yaxis": {
                    "title": {
                        "text": h.execute_sp('get_translation_by_tag', [8852,self.lang,1], self.args)[0]['ltr_text'],
                        "font": {
                            "family": "Arial",
                            "size": 14,
                        },
                    },
                    "zeroline": False,
                    "automargin": True
                },
                "xaxis": {
                    "title": {
                        "text": h.execute_sp('get_translation_by_tag', [1190,self.lang,1], self.args)[0]['ltr_text'],
                        "font": {
                            "family":"Arial",
                            "size": 14,
                        },  
                        "standoff": 40
                    },
                    "showgrid": False,
                    "automargin": True,
                },
            }


            start_date = apiData['args']['start_date']
            end_date = apiData['args']['end_date']
            selected_dates_info = _submission_dates.get_data_for_selected_dates(start_date, end_date)

            data_df = _submission_dates.get_data_for_submissions(apiData['rpt_submissions_by_site_breakdown'])
            form_submission_summary = _submission_dates.get_form_submission_summary(data_df, selected_dates_info)
            
            # Data for the form submission summary tables per job
            site_submission_dates = []
            submission_dates = df_rpt_submissions_by_date_site.groupby('site_rld_name')
            for site, data in submission_dates:
                site_group = {}
                site_group['site_name']  = site    
                data =pd.DataFrame(data[['form_count','submission_date','form_name']])
                site_group['job_data'] = data.to_dict(orient='records')
                data_df = _submission_dates.get_data_for_submissions(data)
                site_group['form_submission_summary'] = _submission_dates.get_form_submission_summary(data_df, selected_dates_info)
                site_submission_dates.append(site_group)
            
            # Getting trendline data per usre and per form
            trendline_dates = df_rpt_submissions_by_date_site.groupby('site_rld_name')
            trendline_data = []
            for site, data in trendline_dates:
                site_group = {}
                site_group['site_name']  = site    
                data =pd.DataFrame(data[['form_count','submission_date','form_name']])
                site_group['job_data'] = data.to_dict(orient='records')
                user_form_groups = data.groupby(['form_name'])
                site_group['form_trendline_data'] = []
                for form_name, form_data in user_form_groups:
                    user_form_dict = {}
                    user_form_dict[form_name] = {}
                    user_form_dict[form_name]['form_counts'] = form_data['form_count'].to_list()
                    user_form_dict[form_name]['submission_dates'] = form_data['submission_date'].to_list()
                    site_group['form_trendline_data'].append(user_form_dict)
                trendline_data.append(site_group)
            
            trendlineTotalsPerSite = []
            for value in trendline_data:
                site_name = value['site_name']
                totalTrendlineDates = []
                totalTrendlineCounts = []
                for data in value['job_data']:
                    trendlineTotals = {}
                    totalTrendlineDates.append(data['submission_date'])
                    totalTrendlineCounts.append(data['form_count'])
                trendlineTotals['site_name'] = site_name
                trendlineTotals['dates'] = totalTrendlineDates
                trendlineTotals['form_counts'] = totalTrendlineCounts
                trendlineTotalsPerSite.append(trendlineTotals)


            report = {            
                'meta': meta,
                'data': apiData,
                'labels': meta['labels'],
                'chart_labels': meta['chart_labels'],
                'site_groups': site_groups,
                'total_by_sites': total_by_sites,
                'yearGraphJSON': newdata,
                'lineGraphJSON': lineGraphData,
                'layout': json.dumps(lineLayout),
                'grandTotal':grandTotal,
                'newdata2':newdata2,
                'site_groups_Data':site_groups_Data,
                'forms_per_site_list':forms_per_site_list,
                'top10_list':top10_list,
                'bottom10_list':bottom10_list,
                'site_forms_Data':site_forms_Data,
                'site_submission_dates':site_submission_dates,
                'form_submission_summary':form_submission_summary, 
                'trendline_data':trendline_data,
                'trendlineTotalsPerSite':trendlineTotalsPerSite
            }
        else:
            report = {            
                'meta': meta,
                'data': apiData,
                'labels': meta['labels'],
                'chart_labels': meta['chart_labels'],
                'site_groups': [],
                'total_by_sites': [],
                'yearGraphJSON': [],
                'lineGraphJSON':[],
                'layout':[],
                'grandTotal':0,
                'newdata2':[],
                'site_groups_Data':[],
                'forms_per_site_list':[],
                'top10_list':[],
                'bottom10_list':[],
                'site_forms_Data':[],
                'daily_froms_list':[],
                'site_submission_dates':[],
                'form_submission_summary':[],
                'trendline_data':[],
                'trendlineTotalsPerSite':[]
            }

        return report
    