#Import required modules
import yaml
import helper as h


#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('lineup_draft')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.      
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_lineup_header_draft_by_id'][0] if len(apiData['rpt_lineup_header_draft_by_id']) > 0 else []
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        reportLineup = apiData['rpt_level_hazards_for_lineup'] if 'rpt_level_hazards_for_lineup' in apiData and len(apiData) > 0 else []
        lineups_header = apiData['lineups_header'] if 'lineups_header' in apiData and len(apiData) > 0 else []
        workplaces = apiData['workplaces'] if 'workplaces' in apiData and len(apiData) > 0 else []
        formSubmissionId = apiData['formSubmissionId']
        lineupDetails = apiData['rpt_lineup_details'] if 'rpt_lineup_details' in apiData and len(apiData) > 0 else []
        threats = apiData['threats'] if 'threats' in apiData and len(apiData) > 0 else []
        equipments_list = apiData['equipments_list'] if 'equipments_list' in apiData and len(apiData) > 0 else []

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'reportLineup': reportLineup,
            'lineups_header': lineups_header,
            'formSubmissionId': formSubmissionId,
            'lineupDetails': lineupDetails,
            'workplaces': workplaces,
            'threats':threats,
            'equipments_list':equipments_list,
        }

        return report