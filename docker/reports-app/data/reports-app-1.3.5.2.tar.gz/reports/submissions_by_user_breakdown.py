#Import required modules
from pandas.core.indexes import api
import yaml
import helper as h
import pandas as pd
import json
from datetime import datetime
import reports._submission_dates as _submission_dates
#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('submissions_by_user_breakdown')
        self.args = args
        self.params = h.get_url_param(args)
        self.lang = args['lang'] if args and 'lang' in args else 1

#Function to get data from the API as per the report section requirement.    
    def get_report(self):
        c = self.config
        apiData = h.get_report(f'{c["api"]}?{self.params}')

        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        meta['filter_data'] = apiData['filter_data']
        meta['language_code'] = h.execute_sql("select lng_name from language where lng_id = " + str(self.lang))['result'][0]['lng_name']

        newdata = []        
        df_rpt_submissions_by_user_breakdown = pd.DataFrame(apiData['rpt_submissions_by_user_breakdown'])
        if len(df_rpt_submissions_by_user_breakdown) > 0:  
            start_date = apiData['args']['start_date']
            end_date = apiData['args']['end_date']          
    
            df_rpt_submissions_by_breakdown_date_user = pd.DataFrame(apiData['rpt_submissions_by_breakdown_date_user'])
            df_rpt_submissions_by_breakdown_date_user.fillna('')


            user_groups_df = df_rpt_submissions_by_user_breakdown.groupby('per_full_name')        

            df_rpt_submissions_by_user_breakdown['submission_date'] = pd.to_datetime(df_rpt_submissions_by_user_breakdown['submission_date'], format='%Y-%m-%d')
            df_rpt_submissions_by_user_breakdown['year'] = df_rpt_submissions_by_user_breakdown['submission_date'].dt.year
            df_rpt_submissions_by_user_breakdown['month'] = df_rpt_submissions_by_user_breakdown['submission_date'].dt.month
            
            # Adding in the Month, Date to the Data set
            df_rpt_submissions_by_user_breakdown['Month_text'] = df_rpt_submissions_by_user_breakdown['submission_date'].dt.strftime("%B")
            df_rpt_submissions_by_user_breakdown['weekday_int'] = df_rpt_submissions_by_user_breakdown['submission_date'].dt.strftime("%W")

            # Grouping the data by user for the months with the most submissions table
            user_groups_Data = []
            monthly_count = df_rpt_submissions_by_user_breakdown.groupby('per_full_name')
            for groupname, data in monthly_count:               
                user_group = {}
                user_group['status_flag'] = groupname
                user_group['status'] = list(data['status_flag'])
                user_group['full_name']  = groupname    
                data =pd.DataFrame(data[['year', 'Month_text', 'total']])
                # Returns the sums by month with the year
                month_groups = data.groupby(['year','Month_text']).agg({'total': 'sum'}).reset_index()[:5]
                month_groups = pd.DataFrame(month_groups)
                month_groups = month_groups.sort_values('total', ascending=False)
                user_group['month_group_count'] = month_groups.to_dict(orient='records')
                user_group['total_form_count'] = data['total'].sum()
                user_groups_Data.append(user_group)

            # All data for pie chart per user
            user_groups_Data_Pie_Chart = []
            forms_per_user_list = []
            monthly_count = df_rpt_submissions_by_user_breakdown.groupby('per_full_name')
            for groupname, data in monthly_count:               
                user_group = {}
                user_group['full_name']  = groupname    
                data =pd.DataFrame(data[['FormNameLabel','total']])
                user_group['job_data'] = data.groupby('FormNameLabel')['total'].sum().reset_index().sort_values('total', ascending=False).head(10).to_dict(orient='records')
                user_groups_Data_Pie_Chart.append(user_group)
                form_count_per_user = {}
                for e in user_group['job_data']:
                    for i,j in e.items():
                        form_count_per_user.setdefault(i, []).append(j)
                forms_per_user_list.append(form_count_per_user)

            # Getting the top and bottom 10 values for form submissions
            top10_list = {}
            bottom10_list = {}
            for user in user_groups_Data_Pie_Chart:
                top10Values=[]
                bottom10Values =[]
                top10Values = sorted(user['job_data'], key=lambda k: k['total'])[-10:]            
                top10Values = sorted(top10Values, key=lambda top10Values: (-top10Values['total']))
                top10_list[user['full_name']]=top10Values#{job['job_name']:top10Values})            
                bottom10Values = sorted(user['job_data'], key=lambda k: k['total'])[:10]
                bottom10_list[user['full_name']] = bottom10Values#({job['job_name']:bottom10Values})

            # Grouping the data by user for the form count per user table
            user_forms_Data = []
            monthly_count = df_rpt_submissions_by_user_breakdown.groupby('per_full_name')
            for groupname, data in monthly_count:               
                form_group = {}
                grouped_data_set ={}
                form_group['full_name']  = groupname    
                data =pd.DataFrame(data[['year', 'Month_text', 'total', 'FormNameLabel','submission_date']])
                grouped_data_set['total_count'] = data.groupby(['year','Month_text']).sum().to_dict(orient='records')
                form_group['total_form_count'] = data['total'].sum()
                form_group['job_data'] = data.to_dict(orient='records')
                user_forms_Data.append(form_group)

            # Getting trendline data per usre and per form
            trendline_dates = df_rpt_submissions_by_breakdown_date_user.groupby('per_full_name')
            trendline_data = []
            for user, data in trendline_dates:
                user_group = {}
                user_group['user_name']  = user    
                data =pd.DataFrame(data[['form_count','submission_date','form_name']])
                user_group['job_data'] = data.to_dict(orient='records')
                user_form_groups = data.groupby(['form_name'])
                user_group['form_trendline_data'] = []
                for form_name, form_data in user_form_groups:
                    user_form_dict = {}
                    user_form_dict[form_name] = {}
                    user_form_dict[form_name]['form_counts'] = form_data['form_count'].to_list()
                    user_form_dict[form_name]['submission_dates'] = form_data['submission_date'].to_list()
                    user_group['form_trendline_data'].append(user_form_dict)
                trendline_data.append(user_group)
        
            trendlineTotalsPerUser = []
            for value in trendline_data:
                user_name = value['user_name']
                totalTrendlineDates = []
                totalTrendlineCounts = []
                for data in value['job_data']:
                    trendlineTotals = {}
                    totalTrendlineDates.append(data['submission_date'])
                    totalTrendlineCounts.append(data['form_count'])
                trendlineTotals['user_name'] = user_name
                trendlineTotals['dates'] = totalTrendlineDates
                trendlineTotals['form_counts'] = totalTrendlineCounts
                trendlineTotalsPerUser.append(trendlineTotals)

            total_by_user = {}
            for name, group in user_groups_df:
                total_by_user[group['per_full_name'].unique()[0]] = group['total'].sum()

            # pie graph for showing Form Totals
            pieAllForms = []
            pieAllValues = []
            grandTotal = 0
            for rec in apiData['rpt_submissions_by_user_breakdown']:
                pieAllForms.insert(0,rec['FormNameLabel'])
                pieAllValues.insert(0,rec['total'])
                grandTotal += rec['total']
            
            #Modifying the data structure to group by user
            total_by_users = {}
            graph_data = []
            user_groups = []
            form_user_data = apiData['rpt_submissions_by_user_breakdown']
            if form_user_data:
                df = pd.DataFrame(form_user_data)
                form_groups = df.groupby('FormNameLabel')
                user_groups = df.groupby('per_full_name')
                for name, group in user_groups:
                    total_by_users[group['per_full_name'].unique()[0]] = group['total'].sum()

                allUsers = []
                allFormCounts = []
                for jobname, jobdata in user_groups:
                    allUsers.append(jobname)
                    allFormCounts.append(jobdata['total'].sum()) 

                top_10_forms = df.groupby('FormNameLabel')['total'].sum().reset_index().sort_values('total', ascending=False).head(10).to_dict(orient='records')     

                allForms = [form['FormNameLabel'] for form in top_10_forms]    
                allFormCounts = [form['total'] for form in top_10_forms]        

                newdata = [{
                            "y": allUsers,
                            "x": allFormCounts,
                            "type": 'bar',
                            "orientation": 'h',
                            "xaxis" : allUsers,
                            "name": allUsers,
                        }]

                top_10_forms = df.groupby('FormNameLabel')['total'].sum().reset_index().sort_values('total', ascending=False).head(10).to_dict(orient='records')     

                allForms = [form['FormNameLabel'] for form in top_10_forms]    
                allFormCounts = [form['total'] for form in top_10_forms]       

                newdata2 = [{
                            "y": allForms,
                            "x": allFormCounts,
                            "type": 'bar',
                            "orientation": 'h',
                            "xaxis" : allForms,
                            "name": allForms,
                        }]

                # Line graph for showing # of forms by date
                lineAllDates = []
                lineAllValues = []
                grandTotal2 = 0
                for rec in apiData['rpt_submissions_by_breakdown_date']:
                    lineAllDates.append(rec['submission_date'])
                    lineAllValues.append(rec['amount'])
                    grandTotal2 += rec['amount']

                # Grouping the data by user for the months with the most submissions table
                linegraph_Data = []
                monthly_count = df_rpt_submissions_by_breakdown_date_user.groupby('submission_date')
                for groupname, data in monthly_count:               
                    user_group = {}
                    user_group['submission_date']  = groupname    
                    data =pd.DataFrame(data[['submission_date', 'form_count']])
                    user_group['total_form_count'] = data['form_count'].sum()
                    data = data.sort_values('form_count', ascending=False).head(5)
                    linegraph_Data.append(user_group)

                lineAllDates2 =[]
                lineAllValues2 = []
                for rec in linegraph_Data:
                    lineAllDates2.append(rec['submission_date'])
                    lineAllValues2.append(rec['total_form_count'])

                lineGraphData = []
                if apiData['rpt_submissions_by_user_breakdown']:
                    lineGraphData = [
                        {
                            "y": lineAllValues2,
                            "x": lineAllDates2,
                            "type": 'line',
                        }
                    ]

                # Line graph attribute definition
                lineLayout = {
                    "title": {
                        "text": h.execute_sp('get_translation_by_tag', [9099,self.lang,1], self.args)[0]['ltr_text'],
                        "font": {
                            "family": "Arial black",
                            "size": 14,
                        }
                    },
                    "height": 500,
                    "width": 750,
                    "yaxis": {
                        "title": {
                            "text": h.execute_sp('get_translation_by_tag', [8852,self.lang,1], self.args)[0]['ltr_text'],
                            "font": {
                                "family": "Arial",
                                "size": 14,
                            },
                        },
                        "zeroline": False,
                        "automargin": True
                    },
                    "xaxis": {
                        "title": {
                            "text": h.execute_sp('get_translation_by_tag', [1190,self.lang,1], self.args)[0]['ltr_text'],
                            "font": {
                                "family":"Arial",
                                "size": 14,
                            },  
                            "standoff": 40
                        },
                        "showgrid": False,
                        "automargin": True,
                    },
                }

                start_date = apiData['args']['start_date']
                end_date = apiData['args']['end_date']
                selected_dates_info = _submission_dates.get_data_for_selected_dates(start_date, end_date)

                data_df = _submission_dates.get_data_for_submissions(apiData['rpt_submissions_by_breakdown_date_user'])
                form_submission_summary = _submission_dates.get_form_submission_summary(data_df, selected_dates_info)
                
                # Data for the form submission summary tables per job
                user_submission_dates = []
                submission_dates = df_rpt_submissions_by_breakdown_date_user.groupby(['per_full_name'])
                for user, data in submission_dates:
                    user_group = {}
                    user_group['user_name']  = user    
                    data =pd.DataFrame(data[['form_count','submission_date','form_name']])
                    user_group['job_data'] = data.to_dict(orient='records')
                    data_df = _submission_dates.get_data_for_submissions(data)
                    user_group['form_submission_summary'] = _submission_dates.get_form_submission_summary(data_df, selected_dates_info)
                    user_submission_dates.append(user_group)

            report = {
                'meta': meta,
                'data': apiData,
                'allData': graph_data,
                'user_groups':user_groups,
                'total_by_users' :total_by_users,
                'grandTotal':grandTotal,
                'total_by_user':total_by_user,
                'lineGraphJSON': lineGraphData,
                'linelayout': json.dumps(lineLayout),
                'newdata2':newdata2,
                'user_groups_Data':user_groups_Data,
                'form_count_per_user':form_count_per_user,
                'user_forms_Data':user_forms_Data,
                'newdata':newdata,
                'user_groups_Data_Pie_Chart':user_groups_Data_Pie_Chart,
                'forms_per_user_list':forms_per_user_list,
                'top10_list':top10_list,
                'bottom10_list':bottom10_list,
                'user_submission_dates':user_submission_dates,
                'form_submission_summary':form_submission_summary,
                'trendline_data':trendline_data,
                'trendlineTotals':trendlineTotals,
                'trendlineTotalsPerUser':trendlineTotalsPerUser
            }
        else:
            report = {            
                'meta': meta,
                'data': apiData,
                'allData': [],
                'user_groups':[],
                'total_by_users' :[],
                'grandTotal':0,
                'total_by_user':[],
                'lineGraphJSON': [],
                'linelayout': [],
                'newdata2':[],
                'user_groups_Data':[],
                'form_count_per_user':[],
                'user_forms_Data':[],
                'newdata':[],
                'user_groups_Data_Pie_Chart':[],
                'forms_per_user_list':[],
                'top10_list':[],
                'bottom10_list':[],
                'user_submission_dates':[],
                'form_submission_summary':[],
                'trendline_data':[],
                'trendlineTotals':[],
                'trendlineTotalsPerUser':[]
            }

        return report
    