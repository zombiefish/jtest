#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('pre_task')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.       
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        preTaskAssesment=apiData['rpt_form_details']['Pre Task Assessment'] if 'Pre Task Assessment' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Pre Task Assessment']) > 0 else []
        worstCaseScenario=apiData['rpt_form_details']['Worst Case Scenario'] if 'Worst Case Scenario' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Worst Case Scenario']) > 0 else []
        workplaceConditions=apiData['rpt_form_details']['Workplace Conditions'] if 'Workplace Conditions' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace Conditions']) > 0 else []
        signatures=apiData['rpt_form_details']['Signatures'] if 'Signatures' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Signatures']) > 0 else []
        supervisorReview=apiData['rpt_form_details']['Review'] if 'Review' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Review']) > 0 else []
        
        supervisorReviewTimestamp=[]
        for s in supervisorReview:
            if s['field_key'] == 'signature_end_of_shift_review_img_time':
                supervisorReviewTimestamp.append(s)

        #Adding new list to the data structure to get the timestamps on the signatures
        supervisorTimeStamp=[]
        managerTimeStamp=[]
        otherTimeStamp=[]

        for s in signatures:
            if s['field_key'] == 'signature_supervisor_img_time':
                supervisorTimeStamp.append(s)
            if s['field_key'] == 'signature_manager_img_time':
                managerTimeStamp.append(s)
            if s['field_key'] == 'signature_other_img_time':
                otherTimeStamp.append(s)

        safetyChecks=apiData['rpt_form_details']['Safety Checks'] if 'Safety Checks' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Safety Checks']) > 0 else []
        shift=apiData['rpt_form_details']['Shift'] if 'Shift' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Shift']) > 0 else []
        preTaskAssesment = apiData['rpt_form_details']['Pre Task Assessment']
        worstCaseScenario = apiData['rpt_form_details']['Worst Case Scenario']
        workplaceConditions = apiData['rpt_form_details']['Workplace Conditions'] if 'Workplace Conditions' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace Conditions']) > 0 else []
        shiftStart = apiData['rpt_form_details']['Workplace Conditions'] if 'Workplace Conditions' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace Conditions']) > 0 else []

        #Adding new list to the report specific images
        multiphotosStart = []
        startStateDetails = []
    
        multiphotosEnd = []
        endStateDetails = []
        for wd in shiftStart:
            if 'start_state_pictures' in wd['field_key']:
                multiphotosStart.append(wd)
            elif 'start_state_details' in wd['field_key']:
                startStateDetails.append(wd)
            if 'end_state_pictures' in wd['field_key']:
                multiphotosEnd.append(wd)
            elif 'end_state_details' in wd['field_key']:
                endStateDetails.append(wd)

        safetyChecks = [] 
        if 'rpt_form_details' in apiData:
            safetyChecks = apiData['rpt_form_details']['Safety Checks']
        
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        hazardsList = apiData['rpt_hazard_actions']
        positiveRecognition = apiData['rpt_positive_recognition']
        generalAction=apiData['rpt_get_general_action_by_id']

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'safetyChecks':safetyChecks,
            'shift':shift,
            'preTaskAssesment':preTaskAssesment,
            'worstCaseScenario':worstCaseScenario,
            'workplaceConditions':workplaceConditions,
            'multiphotosStart':multiphotosStart,
            'multiphotosEnd':multiphotosEnd,
            'startStateDetails': startStateDetails,
            'endStateDetails': endStateDetails,
            'signatures':signatures,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'hazardsList': hazardsList,
            'data': apiData,
            'positiveRecognition': positiveRecognition,
            'apiData': apiData,
            'generalAction':generalAction,
            'supervisorTimeStamp':supervisorTimeStamp,
            'managerTimeStamp': managerTimeStamp,
            'otherTimeStamp': otherTimeStamp,
            'supervisorReview':supervisorReview,
            'supervisorReviewTimestamp':supervisorReviewTimestamp,
        }

        return report