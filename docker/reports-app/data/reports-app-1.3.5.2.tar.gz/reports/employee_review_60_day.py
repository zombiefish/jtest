#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('employee_review_60_day')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.        
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        formDetails=apiData['rpt_form_details']
        legendDetails=apiData['rpt_employee_annual_review_legend']
        hazardsList = apiData['rpt_hazard_actions']
        positiveRecognition = apiData['rpt_positive_recognition']
        generalAction=apiData['rpt_get_general_action_by_id']

        signatures=apiData['rpt_form_details']['Signatures'] if 'Signatures' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Signatures']) > 0 else []

        #Adding new list to the data structure to get the timestamps on the signatures
        employeeTimeStamp=[]
        evaluatorTimeStamp=[]
        managerTimeStamp=[]

        for s in signatures:
            if s['field_key'] == 'employee_signature_img_time':
                employeeTimeStamp.append(s)
            if s['field_key'] == 'evaluator_signature_img_time':
                evaluatorTimeStamp.append(s)
            if s['field_key'] == 'manager_signature_img_time':
                managerTimeStamp.append(s)

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'formDetails': formDetails,
            'legendDetails': legendDetails,
            'employeeTimeStamp': employeeTimeStamp,
            'evaluatorTimeStamp': evaluatorTimeStamp,
            'managerTimeStamp': managerTimeStamp,
            'signatures': signatures,
            'hazardsList': hazardsList,
            'positiveRecognition': positiveRecognition,
            'generalAction':generalAction
            
        }

        return report
    