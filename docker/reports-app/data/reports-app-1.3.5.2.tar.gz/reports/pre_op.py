#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('pre_op')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.        
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        
        formHeader = apiData['rpt_form_header'][0]
        
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        formHeader = apiData['rpt_form_header'][0]

        machineInfo = apiData['rpt_machine_info_by_submission']
        preopDetails = apiData['rpt_pre_op_details']
        preopQuestions = apiData['rpt_pre_op_questions_by_submission']
        reportPreopImages = apiData['rpt_pre_op_photos']
        reportPostopImages = apiData['rpt_post_op_photos']
        postopDetails = apiData['rpt_post_op_details']
        signature = apiData['rpt_pre_op_signature_by_id']
        hazardsList = apiData['rpt_hazard_actions']
        generalAction=apiData['rpt_get_general_action_by_id']
        positiveRecognition=apiData['rpt_positive_recognition']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        startTime = apiData['rpt_pre_op_start_time']
        endTime = apiData['rpt_pre_op_end_time']
        signatures=apiData['rpt_form_details']['Signatures'] if 'Signatures' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Signatures']) > 0 else []  
        supervisorReviewTimeStampData = apiData['rpt_form_details']['Review'] if 'Review' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Review']) > 0 else []  
        supervisorReviewData = apiData['rpt_pre_op_signature_by_id'] if 'rpt_pre_op_signature_by_id' in apiData and len(apiData['rpt_pre_op_signature_by_id']) > 0 else []  
        
        endShift = []
        for data in supervisorReviewData:
            if data['poa_element_name'] == 'signature_end_of_shift_review':
                    endShift.append({ 
                "elementName":data['poa_element_name'],
                "Value":data['Value'],
                "image_comment":data['image_comment'] })
       

        #Adding new list to the data structure to get the timestamps on the signatures
        supervisorTimeStamp=[]
        for s in signatures:
            if s['field_key'] == 'signature_supervisor_photo_img_time':
                supervisorTimeStamp.append(s)

        supervisorReview=[]
        for s in signatures:
            if s['field_key'] == 'signature_end_of_shift_review':
                supervisorReview.append(s)
            else:
                supervisorReview=[] 


        supervisorReviewTimeStamp=[]
        for s in supervisorReviewTimeStampData:
            if s['field_key'] == 'signature_end_of_shift_review_img_time':
                supervisorReviewTimeStamp.append(s)

        foundFlag = 0
        preOpComment={"fieldvalue": "", "preopField": "Comments or Defects"}
        dict_copy = preOpComment.copy()


        for detail in preopDetails:
            if "Comments or Defects" in detail['preopField']:
                foundFlag = 1

        if foundFlag == 0:
            apiData['rpt_pre_op_details'].append(dict_copy)
            
        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'hazardsList': hazardsList,
            'formHeader':formHeader,
            'machineInfo':machineInfo,
            'preopDetails':preopDetails,
            'generalAction':generalAction,
            'positiveRecognition':positiveRecognition,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'reportPreopImages':reportPreopImages,
            'reportPostopImages':reportPostopImages,
            'postopDetails':postopDetails,
            'signature':signature,
            'preopQuestions':preopQuestions,
            'supervisorTimeStamp': supervisorTimeStamp,
            'startTime': startTime,
            'endTime':endTime,
            'supervisorReviewTimeStamp':supervisorReviewTimeStamp,
            'supervisorReview':supervisorReview,
            'supervisorReviewData':supervisorReviewData,
            'endShift':endShift
        }

        return report
