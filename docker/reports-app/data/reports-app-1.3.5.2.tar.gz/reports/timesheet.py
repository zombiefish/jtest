#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('timesheet')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.      
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions']
        positiveRecognition = apiData['rpt_positive_recognition']
        generalAction=apiData['rpt_get_general_action_by_id']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        workDetails=apiData['rpt_form_details']['Work Details'] if 'Work Details' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Work Details']) > 0 and len(apiData['rpt_form_details']) > 0 else []
        equipments=apiData['rpt_form_details']['Equipment and Materials'] if 'Equipment and Materials' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Equipment and Materials']) > 0 and len(apiData['rpt_form_details']) > 0 else []
        head=apiData['rpt_form_details']['Head'] if 'Head' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Head']) > 0 else []
        employees=apiData['rpt_timesheet_employee'] if 'rpt_timesheet_employee' in apiData and len(apiData['rpt_timesheet_employee']) > 0 else []
        workAcceptance=apiData['rpt_form_details']['Work Acceptance'] if 'Work Acceptance' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Work Acceptance']) > 0 else []

        #Adding new list to the data structure to get the timestamps on the signatures
        signTimeStamp = []
        for wd in workAcceptance:
            if 'signature_acceptance_img_time' in wd['field_key']:
                signTimeStamp.append(wd)

        #Adding new list to the report specific images
        multiphotos = []
        for wd in workDetails:
            if 'multiphoto' in wd['field_key']:
                multiphotos.append(wd)
                del wd
        
        grand_total = 0
        for hour in employees:
            grand_total = grand_total + float(hour['Total_Hours'])

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'data': apiData,
            'positiveRecognition': positiveRecognition,
            'apiData': apiData,
            'generalAction':generalAction,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'workDetails':workDetails,
            'employees':employees,
            'equipments':equipments,
            'head':head,
            'multiphotos': multiphotos,
            'grand_total':grand_total,
            'workAcceptance':workAcceptance,
            'signTimeStamp' :signTimeStamp,
        }

        return report
    