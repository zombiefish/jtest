import pandas as pd
def get_data_for_submissions(data):
    data_df = pd.DataFrame(data)
    data_df['submission_date']=pd.to_datetime(data_df['submission_date'])
    data_df['week_number'] = data_df['submission_date'].dt.isocalendar().week
    data_df['month'] = data_df['submission_date'].dt.month
    data_df['quarter'] = data_df['submission_date'].dt.to_period('Q')
    data_df.loc[data_df['month'] <= 6, 'Bi-Annual'] = '1'
    data_df.loc[data_df['month'] >= 6, 'Bi-Annual'] = '2'
    data_df['year'] = data_df['submission_date'].dt.year


    data_df['month_period'] = data_df["month"].astype(str) + '-' + data_df["year"].astype(str)
    data_df['quarter_period'] = data_df["quarter"].astype(str) +'-' + data_df["year"].astype(str)
    data_df['Bi_annual_period'] = data_df["Bi-Annual"].astype(str) +'-' + data_df["year"].astype(str)
    data_df['week_number_period'] = data_df['week_number'].astype(str) + '-'+  data_df['year'].astype(str)

    return data_df

# data_df = get_data_for_submissions(data)

# get data to compare with dates based on the selected date range
from datetime import datetime

def get_data_for_selected_dates(start_date, end_date):

    date_df = pd.DataFrame({
        'selected_date_range' :pd.date_range(start_date, end_date)
    })
    date_df['week_number'] = date_df['selected_date_range'].dt.isocalendar().week
    date_df['month'] = date_df['selected_date_range'].dt.month
    date_df['quarter'] = date_df['selected_date_range'].dt.to_period('Q')
    date_df.loc[date_df['month'] <= 6, 'Bi-Annual'] = '1'
    date_df.loc[date_df['month'] >= 6, 'Bi-Annual'] = '2'
    date_df['year'] = date_df['selected_date_range'].dt.year
    date_df["week_number_period"] = date_df["week_number"].astype(str) + '-'+ date_df["year"].astype(str)
    date_df['month_period'] = date_df["month"].astype(str)  +'-' + date_df["year"].astype(str)
    date_df['quarter_period'] = date_df["quarter"].astype(str) + '-'  + date_df["year"].astype(str)
    date_df['Bi_annual_period'] = date_df["Bi-Annual"].astype(str) +'-' + date_df["year"].astype(str)

    selected_dates_info = {}

    selected_dates_info['dates'] = date_df['selected_date_range'].unique().tolist()
    selected_dates_info['weeks'] = date_df['week_number_period'].unique().tolist()
    selected_dates_info['months'] = date_df['month_period'].unique().tolist()
    selected_dates_info['quarter'] = date_df['quarter_period'].unique().tolist()
    selected_dates_info['bi_annual'] = date_df['Bi_annual_period'].unique().tolist()
    selected_dates_info['annual'] = date_df['year'].unique().tolist()
    return selected_dates_info

# selected_dates_info = get_data_for_selected_dates('2022-01-01', '2022-03-10')

def get_form_submission_summary(data_df, selected_dates_info):
    data_group_by_form_name = data_df.groupby('form_name')    

    daily_froms_list, weekly_forms_list, monthly_forms_list, quarter_forms_list,  biannual_forms_list, annual_forms_list = [], [], [], [], [], []

    total_forms = len([name for name in data_group_by_form_name])

    for name, group in data_group_by_form_name:
        if selected_dates_info['dates'] == group['submission_date'].unique().tolist():
            daily_froms_list.append(name)
        elif selected_dates_info['weeks'] == group['week_number_period'].unique().tolist():
            weekly_forms_list.append(name)
        elif selected_dates_info['months'] == group['month_period'].unique().tolist():
            monthly_forms_list.append(name)
        elif selected_dates_info['quarter'] == group['quarter_period'].unique().tolist():
            quarter_forms_list.append(name)        
        elif selected_dates_info['bi_annual']== group['Bi_annual_period'].unique().tolist():
            biannual_forms_list.append(name)
        else:
            annual_forms_list.append(name)
    
    form_submission_summary = {
        'total_forms' : total_forms,
        'daily_forms_list' : daily_froms_list,
        'weekly_forms_list':weekly_forms_list,
        'monthly_forms_list':monthly_forms_list,
        'quarter_forms_list':quarter_forms_list,
        'biannual_forms_list':biannual_forms_list,
        'annual_forms_list':annual_forms_list
    }
    
    return form_submission_summary
