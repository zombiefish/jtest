#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('pre_op_field_audit')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.        
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions_list']
        hazardsInitial = apiData['rpt_hap_pictures_initial']
        hazardsFollowup = apiData['rpt_hap_pictures_followup']
        positiveRecognition = apiData['rpt_positive_recognition']
        positiveRecognitionImages=apiData['rpt_pid_pictures']
        generalAction=apiData['rpt_get_general_action_by_id']
        generalActionInitial=apiData['rpt_get_general_action_attachment_by_sga_id_initial']
        generalActionFollowup=apiData['rpt_get_general_action_attachment_by_sga_id_followup']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        auditPictures= apiData['rpt_form_details']['Audit Pictures'] if 'Audit Pictures' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Audit Pictures']) > 0 else []
        comments= apiData['rpt_form_details']['Comments'] if 'Comments' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Comments']) > 0 else []
        equipmentPreOp= apiData['rpt_form_details']['Equipment Pre-Op'] if 'Equipment Pre-Op' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Equipment Pre-Op']) > 0 else []
        correctionAction= apiData['rpt_form_details']['Correction & Action Requirements'] if 'Correction & Action Requirements' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Correction & Action Requirements']) > 0 else []
        pidLikes=apiData['rpt_positive_recognition_likes']
        pidComments=apiData['rpt_positive_recognition_comment']

        #Adding new lists to the data structure to get the timestamps on the signatures
        supervisorTimeStamp=[]
        supervisorComments=[]
        workerTimeStamp=[] 
        workerComments=[]      

        multiphotosWorker = []
        for wd in equipmentPreOp:
            if 'worker_signature' in wd['field_key']:
                multiphotosWorker.append(wd)
            if 'worker_signature_img_time' in wd['field_key']:
                workerTimeStamp.append(wd)
            if 'image_comment' in wd['field_key']:
                workerComments.append(wd)
                del wd

        multiphotosSupervisor = []
        for wd in equipmentPreOp:
            if 'supervisor_signature' in wd['field_key']:
                multiphotosSupervisor.append(wd)
            if 'supervisor_signature_img_time' in wd['field_key']:
                supervisorTimeStamp.append(wd)
            if 'image_comment' in wd['field_key']:
                supervisorComments.append(wd)
                del wd
            else:
                []

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'data': apiData,
             'hazardsFollowup':hazardsFollowup,
            'hazardsInitial':hazardsInitial,
            'positiveRecognition': positiveRecognition,
            'apiData': apiData,
            'positiveRecognitionImages':positiveRecognitionImages,
            'generalAction':generalAction,
            'generalActionInitial':generalActionInitial,
            'generalActionFollowup':generalActionFollowup,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'auditPictures':auditPictures,
            'comments':comments,
            'equipmentPreOp':equipmentPreOp,
            'multiphotosWorker':multiphotosWorker,
            'multiphotosSupervisor':multiphotosSupervisor,
            'correctionAction':correctionAction,
            'supervisorTimeStamp': supervisorTimeStamp,
            'workerTimeStamp': workerTimeStamp,
            'supervisorComments':supervisorComments,
            'workerComments':workerComments,
            'pidLikes':pidLikes,
            'pidComments':pidComments
        }

        return report   
    