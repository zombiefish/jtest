#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('incident_report')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.      
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_incident_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        correctiveActions = apiData['CA']
        signoffs = apiData['rpt_incident_signoffs']    

        # Get Preliminary Incident Data
        from reports import preliminary_incident as PrelimIncident        
        prelim_inc_report = PrelimIncident.Report(self.args)

        incident = []
        for prelim_inc in apiData['PrelimIncident']:
            prelim_inc_id = list(prelim_inc.keys())[0]            
            incident.append(prelim_inc_report.get_report(prelim_inc_id))      


        # Get Preliminary Investigation Data
        from reports import preliminary_investigation as PrelimInvestigation        
        prelim_inv_report = PrelimInvestigation.Report(self.args)

        investigation = []
        for prelim_inv in apiData['PrelimInvestigation']:
            prelim_inv_id = list(prelim_inv.keys())[0]            
            investigation.append(prelim_inv_report.get_report(prelim_inv_id))   


        # Get Root Cause Analysis Data
        from reports import incident_analysis as rootCauseAnalysis        
        root_cause_report = rootCauseAnalysis.Report(self.args)        

        rootCause = []
        for root_casue in apiData['RCA']:
            root_cause_id = list(root_casue.keys())[0]            
            rootCause.append(root_cause_report.get_report(root_cause_id))  



        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'incident': incident,
            'investigation':investigation,
            'rootCause':rootCause,
            'correctiveActions':correctiveActions,
            'signoffs':signoffs,
        }

        return report


        
    