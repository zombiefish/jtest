#Import required modules
from requests import api
import yaml
import helper as h

#Defining a class as report
class Report:
#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('job_observation')
        self.args = args
        self.params = h.get_url_param(args)


#Function to get data from the API as per the report section requirement. 
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')

        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions']
        positiveRecognition = apiData['rpt_positive_recognition']
        generalAction=apiData['rpt_get_general_action_by_id']
        reportDistributors = apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        employeeObserved = apiData['rpt_form_details']['Job Observation'] if 'Job Observation' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Comments']) > 0 else []
      
        comments = apiData['rpt_form_header_dynamic_job_observation']


        multiphotos = []
        for wd in comments:
            if 'info_multiphoto' in wd['Field_Key']:
                multiphotos.append(wd)
                del wd

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'data': apiData,
            'positiveRecognition':positiveRecognition,
            'generalAction':generalAction,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'comments':comments,
            'multiphotos':multiphotos,
            'employeeObserved':employeeObserved
        }

        return report
    