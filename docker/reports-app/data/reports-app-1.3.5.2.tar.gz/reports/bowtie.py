import yaml
import helper as h

class Report:

    def __init__(self, args):
        self.config = h.report_config('bowtie')
        self.args = args
        self.params = h.get_url_param(args)
    
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_bowtie_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        bowParticipants = apiData['rpt_bowtie_participants']
        bowApprovers = apiData['rpt_bowtie_approvers']
        hazardsList = apiData['rpt_bowtie_hap']
        generalAction=apiData['rpt_bowtie_general_actions_by_sga_id']
        generalActionInitial=apiData['rpt_bowtie_general_action_attachment_by_id_initial']
        generalActionFollowup=apiData['rpt_bowtie_general_action_attachment_by_id_followup']
        reviewers=apiData['rpt_bowtie_reviewers']
        bowApprovedBy =apiData['rpt_bowtie_approved_by'] if 'rpt_bowtie_approved_by' in apiData and len(apiData['rpt_bowtie_approved_by']) > 0 else []
        bowRisk = apiData['rpt_bowtie_risk_assessment'][0] if 'rpt_bowtie_risk_assessment' in apiData and len(apiData['rpt_bowtie_risk_assessment']) > 0 else []
        rootCause = apiData['rpt_bowtie_root_causes'][0] if 'rpt_bowtie_root_causes' in apiData and len(apiData['rpt_bowtie_root_causes']) > 0 else []
        consequence = apiData['rpt_bowtie_consequences'][0] if 'rpt_bowtie_consequences' in apiData and len(apiData['rpt_bowtie_consequences']) > 0 else []
        rootCause_Consequence = apiData['rootCause_Consequence'] if 'rootCause_Consequence' in apiData and len(apiData['rootCause_Consequence']) > 0 else []
        rowspan= apiData['rowspan']
        attachments=apiData['rpt_get_bowtie_attachment_bowtie_id']

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'bowParticipants':bowParticipants,
            'bowApprovers':bowApprovers,
            'hazardsList':hazardsList,
            'generalAction':generalAction,
            'generalActionInitial':generalActionInitial,
            'generalActionFollowup':generalActionFollowup,
            'reviewers':reviewers,
            'bowApprovedBy':bowApprovedBy,
            'bowRisk':bowRisk,
            'rootCause_Consequence':rootCause_Consequence,
            'rowspan':rowspan,
            'rootCause':rootCause,
            'consequence':consequence,
            'attachments':attachments

        }

        return report

    