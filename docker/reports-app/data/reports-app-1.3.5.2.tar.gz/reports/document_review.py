#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('document_review')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.   
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader=apiData['rpt_document_review_management_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        reviewers=apiData['rpt_document_review_reviewers']
        externalReviewers=apiData['rpt_document_review_external_reviewers']
        missingReviewer=apiData['missing_reviewers']
        attachments = apiData['rpt_document_review_attachment']

        report = {
            'formHeader':formHeader,
            'meta': meta,
            'data': apiData,
            'reviewers':reviewers,
            'externalReviewers':externalReviewers,
            'missingReviewer': missingReviewer,
            'attachments':attachments
        }

        return report
    