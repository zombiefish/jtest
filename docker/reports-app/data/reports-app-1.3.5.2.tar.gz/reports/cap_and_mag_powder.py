#Import the required modules
from requests import api
import yaml
import helper as h


#Defining a class as report
class Report:


#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('cap_and_mag_powder')
        self.args = args
        self.params = h.get_url_param(args)
    

#Function to get data from the API as per the report section requirement.  
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')


        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']

        powderMagazine=apiData['rpt_form_details']['Powder Magazine'] if 'Powder Magazine' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Powder Magazine']) > 0 else []
        capMagazine=apiData['rpt_form_details']['Cap Magazine'] if 'Cap Magazine' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Cap Magazine']) > 0 else []
        comments=apiData['rpt_form_details']['Comments'] if 'Comments' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Comments']) > 0 else []
        signature=apiData['rpt_form_details']['Signature'] if 'Signature' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Signature']) > 0 else []
        signaturePic = apiData['rpt_form_signature']
        pictures=apiData['rpt_form_details']['Pictures'] if 'Pictures' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Pictures']) > 0 else []
        picturesPic = apiData['rpt_form_pictures']
        hazardsList = apiData['rpt_hazard_actions']
        positiveRecognition = apiData['rpt_positive_recognition']
        generalAction=apiData['rpt_get_general_action_by_id']
        reportDistributors = apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'powderMagazine':powderMagazine,
            'capMagazine':capMagazine,
            'comments':comments,
            'signature':signature,
            'pictures':pictures,
            'hazardsList':hazardsList,
            'positiveRecognition':positiveRecognition,
            'generalAction':generalAction,
            'reportDistributors':reportDistributors,
            'picturesPic':picturesPic,
            'signaturePic':signaturePic,
            'reviewers':reviewers
        }

        return report
    