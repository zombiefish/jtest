#Import required modules
import helper as h
from reports.training_matrix_by_employee import Report as employee_report
from reports.training_matrix_by_job import Report as job_report

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('training_matrix_summary')
        self.args = args
        self.params = h.get_url_param(args)
        self.lang = args['lang'] if args and 'lang' in args else 1   

#Function to get data from the API as per the report section requirement.    
    def get_report(self, filters=None):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        self.args = meta['args']

        if 'report_selection' in self.args and self.args['report_selection'] == '110':
            return employee_report.get_report(self)

        elif 'report_selection' in self.args and self.args['report_selection'] == '111':
            return job_report.get_report(self) 
                
        else:   
            report = {            
                'meta': meta,
                'data': apiData
            }
    
        return report