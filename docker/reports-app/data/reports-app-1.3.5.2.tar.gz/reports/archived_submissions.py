#Import the required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('archived_submissions')
        self.args = args
        self.params = h.get_url_param(args)

 
#Function to get data from the API as per the report section requirement.   
    def get_report(self):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')

        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']


        report = {            
            'meta': meta,
            'data': apiData
        }

        return report
    