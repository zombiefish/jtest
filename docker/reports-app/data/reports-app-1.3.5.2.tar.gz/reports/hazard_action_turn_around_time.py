#Import required modules
import yaml
import helper as h
import plotly
import json
import plotly.express as px
import pandas as pd

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('hazard_action_turn_around_time')
        self.args = args
        self.params = h.get_url_param(args)
        self.lang = args['lang'] if args and 'lang' in args else 1

#Function to get data from the API as per the report section requirement. 
    def get_report(self):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')
        
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        meta['filter_data'] = apiData['filter_data']
        meta['language_code'] = h.execute_sql("select lng_name from language where lng_id = " + str(self.lang))['result'][0]['lng_name']

        #labels
        labels = {}
        hazard_action_completion_json = []
        hazard_turn_around = []
        df_hazard_action = None

        #Fetching graph data 
        if 'rpt_hazard_action_turn_around_time' in apiData:
            if apiData['rpt_hazard_action_turn_around_time']:

                labels = {key:value for key, value in apiData['rpt_hazard_action_turn_around_time'][0].items() if key.endswith('_label')}
                labels['hazard_actions_label'] = h.execute_sp('get_translation_by_tag', [1218,self.lang,1], self.args)[0]['ltr_text']                

                df_pie_chart = pd.DataFrame.from_dict(apiData['action_completion_stats'], orient='index', columns=['count']).reset_index()                
                

                colors = ['#0072ce', '#66aae2', '#00447c', '#6e94ba', '#7272ad', '#d8bd87', '#447259',
                            '#474747', '#b3bccf', '#99bcac', '#a9ddff', '#96a9aa', '#001e60', '#777777', '#005ba5',
                            '#0087b3', '#002e52', '#99c7eb', '#a4a1d5', '#00445a', '#378ddc', '#424686', '#fcecb3',
                            '#9c6492', '#16492d', '#d193ae', '#eacfce', '#8a7fd0', '#616699', '#006586', '#ddab00',
                            '#c292cd', '#d6d3ff', '#5f3c79', '#00a9e0', '#ffb359', '#58cad3']

                hazard_action_completion_json = [{
                    "labels" : df_pie_chart['index'].values.tolist(),
                    "values" : df_pie_chart['count'].values.tolist(),
                    "type" : "pie",
                    "marker": {
                                "colors": colors
                            },
                }]

                # for line graph - get submission header id and turnaround days
                submission_header_ids = []
                days = []

                for each in apiData['rpt_hazard_action_turn_around_time']:
                    submission_header_ids.append(each['SubmissionHeaderID'])
                    days.append(each['turnaround'])
                
                df_line = pd.DataFrame({
                    labels['submission_id_label']: submission_header_ids,
                    labels['days_label'] : days
                })       
                df_line.fillna(0, inplace=True)                      
                
                hazard_turn_around = [{
                        "y": df_line[labels['days_label']].values.tolist(),
                        "x": df_line[labels['submission_id_label']].values.tolist(),
                        "type": 'scatter',
                        "mode":"markers"        
                }]                

                df_hazard_action = pd.DataFrame(apiData['rpt_hazard_action_turn_around_time'])
                df_hazard_action = df_hazard_action[
                    ['SubmissionHeaderID', 
                    'hazard_description', 
                    'FormSubmissionDate', 
                    'action_by_when', 
                    'action_completed_date', 
                    'turnaround', 
                    'action_by_who', 
                    'action_complete_by_who' ]]   
                df_hazard_action.fillna('', inplace=True)       

        report = {            
            'meta': meta,
            'data': apiData,
            'labels': labels,
            'pieJSON': hazard_action_completion_json,
            'lineGraphJSON' :hazard_turn_around,
            'df_hazard_action': df_hazard_action
        }

        return report
    