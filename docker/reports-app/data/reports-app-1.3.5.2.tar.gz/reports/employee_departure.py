#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('employee_departure')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.    
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')

        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        performance=apiData['rpt_form_details']['Performance'] if 'Performance' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Performance']) > 0 else []
        assets=apiData['rpt_form_details']['Assets'] if 'Assets' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Assets']) > 0 else []
        additionalHeaderInfo=apiData['rpt_form_details']['Employee'] if 'Employee' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Employee']) > 0 else []
        reviewers=apiData['rpt_form_reviewers']
        reportDistributors = apiData['rpt_form_details_distribution']
        duration=apiData['rpt_form_details']['Duration'] if 'Duration' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Duration']) > 0 else []
        labels=apiData['report_labels']

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'performance':performance,
            'assets':assets,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'additionalHeaderInfo':additionalHeaderInfo,
            'duration': duration,
            'labels': labels
        }

        return report
    