#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('lessons_learned')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.     
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_get_lesson_learned_hazard_actions_by_id']
        hazardsInitial=apiData['rpt_hap_pictures_initial']
        hazardsFollowup=apiData['rpt_hap_pictures_followup']
        generalAction=apiData['rpt_get_lesson_learned_general_actions_by_id']
        generalActionInitial=apiData['rpt_get_general_action_attachment_by_sga_id_initial']
        generalActionFollowup=apiData['rpt_get_general_action_attachment_by_sga_id_followup']
        reviewers=apiData['rpt_get_lesson_learned_reviewers_by_id']
        lessonsLearned = apiData['rpt_get_lesson_learned_by_id'][0]
        formHeader=apiData['rpt_get_lesson_learned_by_id'][0]
        attachments=apiData['rpt_get_lesson_learned_attachment_llm_id']
        participants=apiData['rpt_get_lesson_learned_participants_by_id']

        report = {
            'meta': meta,
            'hazardsList': hazardsList,
            'data': apiData,
            'hazardsInitial':hazardsInitial,
            'hazardsFollowup':hazardsFollowup,
            'generalAction':generalAction,
            'generalActionInitial':generalActionInitial,
            'generalActionFollowup':generalActionFollowup,
            'reviewers':reviewers,
            'lessonsLearned':lessonsLearned,
            'attachments': attachments,
            'participants': participants,
            'formHeader': formHeader
        }

        return report
    