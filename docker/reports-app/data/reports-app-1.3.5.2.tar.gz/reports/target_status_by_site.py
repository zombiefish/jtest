#Import required modules
from os import terminal_size
from typing import final
import yaml
import helper as h
import plotly
import json
import plotly.express as px
import pandas as pd

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('target_status_by_site')
        self.args = args
        self.params = h.get_url_param(args)
        self.lang = args['lang'] if args and 'lang' in args else 1        

#Function to get data from the API as per the report section requirement.  
    def get_report(self):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')

        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        meta['filter_data'] = apiData['filter_data']
        meta['language_code'] = h.execute_sql("select lng_name from language where lng_id = " + str(self.lang))['result'][0]['lng_name']      
        
        report = {            
            'meta': meta,
            'data': apiData,
        }

        return report
    