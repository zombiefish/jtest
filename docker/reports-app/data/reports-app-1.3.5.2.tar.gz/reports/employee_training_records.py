#Import required modules
import yaml
import helper as h
from reports.employee_training_records_by_site import Report as site_report
from reports.employee_training_records_by_employee import Report as user_report
from reports.employee_training_records_by_job import Report as job_report

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('employee_training_records')
        self.args = args
        self.params = h.get_url_param(args)
        self.lang = args['lang'] if args and 'lang' in args else 1   

#Function to get data from the API as per the report section requirement.    
    def get_report(self, filters=None):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        self.args = meta['args']

        #Document Review Summary by Site
        if 'report_selection' in self.args and (self.args['report_selection'] == '108'):
            return site_report.get_report(self)

        #Document Review Summary by User
        elif 'report_selection' in self.args and (self.args['report_selection'] == '107'):
            return user_report.get_report(self)   
        
        #Document Review Summary by Document
        elif 'report_selection' in self.args and (self.args['report_selection'] == '30'):
            return job_report.get_report(self) 
                
        report = {            
            'meta': meta,
            'data': apiData
        }
        return report
    