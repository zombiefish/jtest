#Import required modules
from requests import api
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('daily_drilling')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.   
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')

        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions']
        positiveRecognition = apiData['rpt_positive_recognition']
        generalAction=apiData['rpt_get_general_action_by_id']
        reportDistributors = apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        equipment=apiData['rpt_daily_drilling_details']['Equipment'] if 'Equipment' in apiData['rpt_daily_drilling_details'] and len(apiData['rpt_daily_drilling_details']['Equipment']) > 0 else []
        materialUsed=apiData['materials_used']
        signatures=apiData['rpt_daily_drilling_details']['Signatures'] if 'Signatures' in apiData['rpt_daily_drilling_details'] and len(apiData['rpt_daily_drilling_details']['Signatures']) > 0 else []
        timeEntry=apiData['time_entry'] 
        comments=apiData['rpt_daily_drilling_details']['Comment'] if 'Comment' in apiData['rpt_daily_drilling_details'] and len(apiData['rpt_daily_drilling_details']['Comment']) > 0 else []
        totals=apiData['get_drilling_calculation_by_subid'][0] if 'get_drilling_calculation_by_subid' in apiData and len(apiData) > 0 else []
        legends=apiData['rpt_daily_drilling_legend'] if 'rpt_daily_drilling_legend' in apiData and len(apiData['rpt_daily_drilling_legend']) > 0 else []
        unit=apiData['unit'] if 'unit' in apiData else []
       
    #Adding new lists to the report specific images      

        supervisorTimeStamp=[]
        for s in signatures:
            if s['field_key'] == 'signature_supervisor_img_time':
                supervisorTimeStamp.append(s)

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'data': apiData,
            'equipment':equipment,
            'materialUsed':materialUsed,
            'signatures':signatures,
            'timeEntry':timeEntry,
            'positiveRecognition':positiveRecognition,
            'generalAction':generalAction,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'comments':comments,
            'supervisorTimeStamp':supervisorTimeStamp,
            'totals':totals,
            'legends':legends,
            'unit':unit

        }

        return report
    