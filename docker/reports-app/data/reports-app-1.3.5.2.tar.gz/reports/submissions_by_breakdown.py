#Import required modules
import yaml
import helper as h
import json
import pandas as pd
from datetime import datetime

import reports._submission_dates as _submission_dates

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('submissions_by_breakdown')
        self.args = args
        self.params = h.get_url_param(args)
        self.lang = args['lang'] if args and 'lang' in args else 1


#Function to get data from the API as per the report section requirement.  
    def get_report(self):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')

        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        meta['filter_data'] = apiData['filter_data']
        meta['language_code'] = h.execute_sql("select lng_name from language where lng_id = " + str(self.lang))['result'][0]['lng_name']

        df_rpt_submissions_by_breakdown = pd.DataFrame(apiData['rpt_submissions_by_breakdown'])
        if len(df_rpt_submissions_by_breakdown) > 0:
            df_rpt_submissions_by_breakdown.fillna('')
            # Dataframe with submission_date, form_name, and amount
            df_rpt_submissions_by_date = pd.DataFrame(apiData['rpt_submissions_by_breakdown_date'])
            df_rpt_submissions_by_date.fillna('')
            df_rpt_submissions_by_date2 = pd.DataFrame(apiData['rpt_submissions_by_breakdown_date'])
            df_rpt_submissions_by_date2.fillna('')

            report_groups = df_rpt_submissions_by_breakdown.groupby('FormNameLabel')

            # Months With the Most Submissions Dataframes
            df_rpt_submissions_by_date['submission_date'] = pd.to_datetime(df_rpt_submissions_by_date['submission_date'], format='%Y-%m-%d')
            df_rpt_submissions_by_date['year'] = df_rpt_submissions_by_date['submission_date'].dt.year
            df_rpt_submissions_by_date['month'] = df_rpt_submissions_by_date['submission_date'].dt.month
            
            # Adding in the Month, Date to the Data set
            df_rpt_submissions_by_date['Month_text'] = df_rpt_submissions_by_date['submission_date'].dt.strftime("%B")
            df_rpt_submissions_by_date['Date'] = df_rpt_submissions_by_date['submission_date'].dt.strftime("%d")
            df_rpt_submissions_by_date['Week'] = df_rpt_submissions_by_date['submission_date'].dt.strftime("%U")

            # Returns the sums by month with the year
            month_groups = df_rpt_submissions_by_date.groupby(['year','Month_text']).agg({'amount': 'sum'}).reset_index()[:5]
            month_groups = pd.DataFrame(month_groups)
            month_groups = month_groups.sort_values('amount', ascending=False)

            # pie graph for showing Form Totals
            pieAllForms = []
            pieAllValues = []
            grandTotal = 0

            for rec in apiData['rpt_submissions_by_breakdown']:
                pieAllForms.insert(0,rec['FormNameLabel'])
                pieAllValues.insert(0,rec['total'])
                grandTotal += rec['total']

            #Defining the graph attributes
            GraphData = []
            if apiData['rpt_submissions_by_breakdown']:
                GraphData = [
                    {
                        "y": pieAllForms,
                        "x": pieAllValues,
                        "type": 'bar',
                        "orientation": 'h'
                    }
                ]

            # Line graph for showing # of forms by date
            lineAllDates = []
            lineAllValues = []
            lineAllForms = []
            for rec in apiData['rpt_submissions_by_breakdown_date']:
                lineAllDates.append(rec['submission_date'])
                lineAllValues.append(rec['amount'])
                lineAllForms.append(rec['form_name'])

            # Grouping the data by user for the months with the most submissions table
            linegraph_Data = []
            monthly_count = df_rpt_submissions_by_date2.groupby('submission_date')
            for groupname, data in monthly_count:               
                user_group = {}
                user_group['submission_date']  = groupname    
                data =pd.DataFrame(data[['submission_date', 'amount']])
                user_group['total_form_count'] = data['amount'].sum()
                data = data.sort_values('amount', ascending=False).head(5)
                linegraph_Data.append(user_group)

            lineAllDates2 =[]
            lineAllValues2 = []
            for rec in linegraph_Data:
                lineAllDates2.append(rec['submission_date'])
                lineAllValues2.append(rec['total_form_count'])

            lineGraphData = []
            if apiData['rpt_submissions_by_breakdown']:
                lineGraphData = [
                    {
                        "y": lineAllValues2,
                        "x": lineAllDates2,
                        "type": 'line',
                        'forms':lineAllForms
                    }
                ]

            top10Values=[]
            bottom10Values =[]
            top10Values = sorted(apiData['rpt_submissions_by_breakdown'], key=lambda k: k['total'])[-10:]            
            top10Values = sorted(top10Values, key=lambda top10Values: (-top10Values['total']))            
            bottom10Values = sorted(apiData['rpt_submissions_by_breakdown'], key=lambda k: k['total'])[:10]

            # allForms = []
            # allFormCounts = []
            # for form_name, jobdata in report_groups:
            #     allForms.append(form_name)
            #     allFormCounts.append(jobdata['total'].sum())
            
            top_10_forms = df_rpt_submissions_by_breakdown.groupby('FormNameLabel')['total'].sum().reset_index().sort_values('total', ascending=False).head(10).to_dict(orient='records')     

            allForms = [form['FormNameLabel'] for form in top_10_forms]    
            allFormCounts = [form['total'] for form in top_10_forms] 

            newdata2 = [{
                        "y": allForms,
                        "x": allFormCounts,
                        "type": 'bar',
                        "orientation": 'h',
                    }]

            # Data manipulation for form submission sparklines        
            form_group_Data = []
            forms_list =[]
            sparklines_data = df_rpt_submissions_by_date.groupby('form_name')
            for form, data in sparklines_data:
                form_group = {}
                form_group['form_name'] = form
                data['submission_date'] = data['submission_date'].dt.strftime('%Y-%m-%d')
                data = pd.DataFrame(data[['submission_date','amount','form_name']])            
                form_group['form_data'] = data.to_dict(orient='records')
                form_group_Data.append(form_group)
                form_count_per_form = {}
                for e in form_group['form_data']:
                    for i,j in e.items():
                        form_count_per_form.setdefault(i, []).append(j)
                forms_list.append(form_count_per_form)

            
            # Grouping data for total sparkline
            temp = df_rpt_submissions_by_date.groupby('submission_date')['amount'].agg('sum').reset_index()
            trendlines_total = {}
            trendlines_total['s_dates_list'] = temp['submission_date'].dt.strftime('%Y-%m-%d').to_list()
            trendlines_total['count_list'] = temp['amount'].to_list()

            # Using a component holding functions to calculate the form submission summary and frequency tables
            start_date = apiData['args']['start_date']
            end_date = apiData['args']['end_date']
            selected_dates_info = _submission_dates.get_data_for_selected_dates(start_date, end_date)

            data_df = _submission_dates.get_data_for_submissions(apiData['rpt_submissions_by_breakdown_date'])
            form_submission_summary = _submission_dates.get_form_submission_summary(data_df, selected_dates_info)

            # Line graph attribute definition
            lineLayout = {
                "title": {
                    "text":h.execute_sp('get_translation_by_tag', [9099,self.lang,1], self.args)[0]['ltr_text'],
                    "font": {
                        "family": "Arial black",
                        "size": 14,
                    }
                },
                "height": 500,
                "width": 750,
                "yaxis": {
                    "title": {
                        "text": h.execute_sp('get_translation_by_tag', [8852,self.lang,1], self.args)[0]['ltr_text'],
                        "font": {
                            "family": "Arial",
                            "size": 14,
                        },
                    },
                    "zeroline": False,
                    "automargin": True
                },
                "xaxis": {
                    "title": {
                        "text": h.execute_sp('get_translation_by_tag', [1190,self.lang,1], self.args)[0]['ltr_text'],
                        "font": {
                            "family":"Arial",
                            "size": 14,
                        },  
                        "standoff": 40
                    },
                    "showgrid": False,
                    "automargin": True,
                },
            }


            report = {            
                'meta': meta,
                'data': apiData,
                'layout': json.dumps(lineLayout),
                'graphJSON' : GraphData,
                'lineGraphJSON': lineGraphData,
                'grandTotal': grandTotal,
                'top10Values':top10Values,
                'bottom10Values':bottom10Values,
                'newdata2':newdata2,
                'month_groups':month_groups,
                'forms_list':forms_list,
                'form_submission_summary': form_submission_summary,
                'trendlines_total':trendlines_total
            }
        
        else:
            report = {            
                'meta': meta,
                'data': apiData,                
                'layout': [],
                'graphJSON' : [],
                'lineGraphJSON': [],
                'grandTotal': 0,
                'top10Values':[],
                'bottom10Values':[],
                'newdata2':[],
                'month_groups':[],
                'forms_list':[],
                'form_submission_summary': [],
                'trendlines_total':[]
            }

        return report
    