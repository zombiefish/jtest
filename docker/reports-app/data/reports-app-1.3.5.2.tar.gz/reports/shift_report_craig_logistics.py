#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('shift_report_craig_logistics')
        self.args = args
        self.params = h.get_url_param(args)
 
#Function to get data from the API as per the report section requirement.    
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions_list']
        hazardsInitial = apiData['rpt_hap_pictures_initial']
        hazardsFollowup = apiData['rpt_hap_pictures_followup']
        positiveRecognition = apiData['rpt_positive_recognition']
        positiveRecognitionImages=apiData['rpt_pid_pictures']
        generalAction=apiData['rpt_get_general_action_by_id']
        generalActionInitial=apiData['rpt_get_general_action_attachment_by_sga_id_initial']
        generalActionFollowup=apiData['rpt_get_general_action_attachment_by_sga_id_followup']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        safety=apiData['rpt_form_details']['Sub Header'] if 'Sub Header' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Sub Header']) > 0 else []
        muckCircuitStatus=apiData['rpt_form_details']['Muck Circuit Status'] if 'Muck Circuit Status' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Muck Circuit Status']) > 0 else []
        skipHoistProduction=apiData['rpt_form_details']['Skip Hoist Production'] if 'Skip Hoist Production' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Skip Hoist Production']) > 0 else []
        cageRuns=apiData['rpt_form_details']['Cage Runs'] if 'Cage Runs' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Cage Runs']) > 0 else []
        workplace1=apiData['rpt_form_details']['Workplace 1'] if 'Workplace 1' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 1']) > 0 else []
        workplace2=apiData['rpt_form_details']['Workplace 2'] if 'Workplace 2' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 2']) > 0 else []
        workplace3=apiData['rpt_form_details']['Workplace 3'] if 'Workplace 3' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 3']) > 0 else []
        workplace4=apiData['rpt_form_details']['Workplace 4'] if 'Workplace 4' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 4']) > 0 else []
        workplace5=apiData['rpt_form_details']['Workplace 5'] if 'Workplace 5' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 5']) > 0 else []
        workplace6=apiData['rpt_form_details']['Workplace 6'] if 'Workplace 6' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 6']) > 0 else []
        workplace7=apiData['rpt_form_details']['Workplace 7'] if 'Workplace 7' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 7']) > 0 else []
        workplace8=apiData['rpt_form_details']['Workplace 8'] if 'Workplace 8' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 8']) > 0 else []
        comments=apiData['rpt_form_details']['Comments'] if 'Comments' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Comments']) > 0 else []
        workplaceDetails=apiData['rpt_form_details']['Workplace Details'] if 'Workplace Details' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace Details']) > 0 else []
        pidLikes=apiData['rpt_positive_recognition_likes']
        pidComments=apiData['rpt_positive_recognition_comment']

        #Adding new lists to the report specific images 
        multiphotos1 = []
        for wd in workplace1:
            if 'workplace_pictures_1' in wd['field_key']:
                multiphotos1.append(wd)
                del wd
        
        multiphotos2 = []
        for wd in workplace2:
            if 'workplace_pictures_2' in wd['field_key']:
                multiphotos2.append(wd)
                del wd
        
        multiphotos3 = []
        for wd in workplace3:
            if 'workplace_pictures_3' in wd['field_key']:
                multiphotos3.append(wd)
                del wd

        multiphotos4 = []
        for wd in workplace4:
            if 'workplace_pictures_4' in wd['field_key']:
                multiphotos4.append(wd)
                del wd

        multiphotos5 = []
        for wd in workplace5:
            if 'workplace_pictures_5' in wd['field_key']:
                multiphotos5.append(wd)
                del wd
     
        multiphotos6 = []
        for wd in workplace6:
            if 'workplace_pictures_6' in wd['field_key']:
                multiphotos6.append(wd)
                del wd

        multiphotos7 = []
        for wd in workplace7:
            if 'workplace_pictures_7' in wd['field_key']:
                multiphotos7.append(wd)
                del wd

        multiphotos8 = []
        for wd in workplace8:
            if 'workplace_pictures_8' in wd['field_key']:
                multiphotos8.append(wd)
                del wd
        
        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'hazardsFollowup':hazardsFollowup,
            'hazardsInitial':hazardsInitial,
            'data': apiData,
            'positiveRecognition': positiveRecognition,
            'apiData': apiData,
            'positiveRecognitionImages':positiveRecognitionImages,
            'generalAction':generalAction,
            'generalActionInitial':generalActionInitial,
            'generalActionFollowup':generalActionFollowup,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'safety':safety,
            'muckCircuitStatus':muckCircuitStatus,
            'skipHoistProduction':skipHoistProduction,
            'cageRuns':cageRuns,
            'workplace1':workplace1,
            'multiphotos1':multiphotos1,
            'workplace2':workplace2,
            'multiphotos2':multiphotos2,
            'workplace3':workplace3,
            'multiphotos3':multiphotos3,
            'workplace4':workplace4,
            'multiphotos4':multiphotos4,
            'workplace5':workplace5,
            'multiphotos5':multiphotos5,
            'workplace6':workplace6,
            'multiphotos6':multiphotos6,
            'workplace7':workplace7,
            'multiphotos7':multiphotos7,
            'workplace8':workplace8,
            'multiphotos8':multiphotos8,
            'comments':comments,
            'workplaceDetails':workplaceDetails,
            'pidLikes':pidLikes,
            'pidComments':pidComments
        }

        return report   
    