#Import required modules
from datetime import date
import yaml
import helper as h
import json
import pandas as pd

import reports._submission_dates as _submission_dates

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('submissions_by_job_breakdown')
        self.args = args
        self.params = h.get_url_param(args)
        self.lang = args['lang'] if args and 'lang' in args else 1 


#Function to get data from the API as per the report section requirement. 
    def get_report(self):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')

        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        meta['filter_data'] = apiData['filter_data']
        meta['labels'] = apiData['labels']
        meta['chart_labels'] = apiData['chart_labels']

        meta['language_code'] = h.execute_sql("select lng_name from language where lng_id = " + str(self.lang))['result'][0]['lng_name'] 

        

        #Modifying the data structure to group by job
        if 'rpt_submissions_by_job_breakdown' in apiData and apiData['rpt_submissions_by_job_breakdown']:
            
            start_date = apiData['args']['start_date']
            end_date = apiData['args']['end_date']
                   
            df_rpt_submissions_by_job_breakdown_date = pd.DataFrame(apiData['rpt_submissions_by_breakdown_date_job'])
            df_rpt_submissions_by_job_breakdown_date.fillna('')
            df_rpt_submissions_by_job_breakdown = pd.DataFrame(apiData['rpt_submissions_by_job_breakdown'])
            df_rpt_submissions_by_job_breakdown.fillna('')
            # Dataframe with submission_date, form_name, and amount
            df_rpt_submissions_by_date = pd.DataFrame(apiData['rpt_submissions_by_breakdown_date'])
            df_rpt_submissions_by_date.fillna('')

            job_groups = df_rpt_submissions_by_job_breakdown.groupby('job_title')
            form_groups = df_rpt_submissions_by_job_breakdown.groupby('form_name')

            month_groups= []            
            df_rpt_submissions_by_job_breakdown['submission_date'] = pd.to_datetime(df_rpt_submissions_by_job_breakdown['submission_date'], format='%Y-%m-%d')
            df_rpt_submissions_by_job_breakdown['year'] = df_rpt_submissions_by_job_breakdown['submission_date'].dt.year
            df_rpt_submissions_by_job_breakdown['month'] = df_rpt_submissions_by_job_breakdown['submission_date'].dt.month
            
            # Adding in the Month, Date to the Data set
            df_rpt_submissions_by_job_breakdown['Month_text'] = df_rpt_submissions_by_job_breakdown['submission_date'].dt.strftime("%B")

            
            selected_dates_info = _submission_dates.get_data_for_selected_dates(start_date, end_date)

            data_df = _submission_dates.get_data_for_submissions(apiData['rpt_submissions_by_job_breakdown'])
            form_submission_summary = _submission_dates.get_form_submission_summary(data_df, selected_dates_info)
            
            # pie graph for showing Form Totals
            pieAllForms = []
            pieAllValues = []
            grandTotal = 0

            for rec in apiData['rpt_submissions_by_job_breakdown']:
                pieAllForms.insert(0,rec['form_name'])
                pieAllValues.insert(0,rec['form_count'])
                grandTotal += rec['form_count']

            # Grouping the data by job for the months with the most submissions table
            job_groups_Data = []
            monthly_count = df_rpt_submissions_by_job_breakdown.groupby('job_title')
            for groupname, data in monthly_count:               
                job_group = {}
                job_group['job_tile']  = groupname
                job_group['status'] = list(data['job_status'])
                data =pd.DataFrame(data[['year', 'Month_text', 'form_count','submission_date','form_name']])
                # Returns the sums by month with the year
                month_groups = data.groupby(['year','Month_text']).agg({'form_count': 'sum'}).reset_index()[:5]
                month_groups = pd.DataFrame(month_groups)
                month_groups = month_groups.sort_values('form_count', ascending=False)
                job_group['month_group_count'] = month_groups.to_dict(orient='records')
                job_group['total_form_count'] = data['form_count'].sum()
                job_groups_Data.append(job_group)

            # Data for the form submission summary tables per job
            job_submission_dates = []
            submission_dates = df_rpt_submissions_by_job_breakdown_date.groupby('job_title')
            for job, data in submission_dates:
                job_group = {}
                job_group['job_name']  = job    
                data =pd.DataFrame(data[['form_count','submission_date','form_name']])
                job_group['job_data'] = data.to_dict(orient='records')
                data_df = _submission_dates.get_data_for_submissions(data)
                job_group['form_submission_summary'] = _submission_dates.get_form_submission_summary(data_df, selected_dates_info)
                job_submission_dates.append(job_group)

            # All data for pie chart per user
            site_groups_Data_Pie_Chart = []
            forms_per_job_list = []
            monthly_count = df_rpt_submissions_by_job_breakdown.groupby('job_title')
            for groupname, data in monthly_count:               
                site_group = {}
                site_group['job_name']  = groupname    
                data =pd.DataFrame(data[['form_name','form_count']])
                site_group['job_data'] = data.groupby('form_name')['form_count'].sum().reset_index().sort_values('form_count', ascending=False).head(10).to_dict(orient='records')
                site_groups_Data_Pie_Chart.append(site_group)
                form_count_per_site = {}
                for e in site_group['job_data']:
                    for i,j in e.items():
                        form_count_per_site.setdefault(i, []).append(j)
                forms_per_job_list.append(form_count_per_site)

            # Getting the top and bottom 10 values for form submissions
            top10_list = {}
            bottom10_list = {}
            for job in site_groups_Data_Pie_Chart:
                top10Values=[]
                bottom10Values =[]
                top10Values = sorted(job['job_data'], key=lambda k: k['form_count'])[-10:]            
                top10Values = sorted(top10Values, key=lambda top10Values: (-top10Values['form_count']))
                top10_list[job['job_name']]=top10Values#{job['job_name']:top10Values})            
                bottom10Values = sorted(job['job_data'], key=lambda k: k['form_count'])[:10]
                bottom10_list[job['job_name']] = bottom10Values#({job['job_name']:bottom10Values})

            # Grouping the data by user for the form count per user table
            site_forms_Data = []
            monthly_count = df_rpt_submissions_by_job_breakdown.groupby('job_title')
            for groupname, data in monthly_count:               
                site_group = {}
                site_group['job_name']  = groupname 
                data['submission_date'] = data['submission_date'].dt.strftime('%Y-%m-%d')   
                data =pd.DataFrame(data[['year', 'Month_text', 'form_count', 'form_name','submission_date']])
                site_group['total_form_count'] = data['form_count'].sum()
                site_group['job_data'] = data.to_dict(orient='records')
                site_forms_Data.append(site_group)

            total_by_form = {}
            for form, group in form_groups:
                total_by_form[group['form_name'].unique()[0]] = group['form_count'].sum()

            top_10_forms = df_rpt_submissions_by_job_breakdown.groupby('form_name')['form_count'].sum().reset_index().sort_values('form_count', ascending=False).head(10).to_dict(orient='records')     

            allForms = [form['form_name'] for form in top_10_forms]    
            allFormCounts = [form['form_count'] for form in top_10_forms]    

            newdata2 = [{
                        "y": allForms,
                        "x": allFormCounts,
                        "type": 'bar',
                        "orientation": 'h',
                        "xaxis" : allForms,
                        "name": allForms,

                    }]

            total_by_jobs = {}
            for jobname, jobdata in job_groups:
                total_by_form[jobdata['job_rld_name'].unique()[0]] = jobdata['job_rld_name'].sum()

            top_10_forms = df_rpt_submissions_by_job_breakdown.groupby('job_rld_name')['form_count'].sum().reset_index().sort_values('form_count', ascending=False).head(10).to_dict(orient='records')     

            allJobs = [form['job_rld_name'] for form in top_10_forms]    
            allFormCounts = [form['form_count'] for form in top_10_forms]       

            newdata = [{
                        "y": allJobs,
                        "x": allFormCounts,
                        "type": 'bar',
                        "orientation": 'h',
                        "xaxis" : allJobs,
                        "name": allJobs,
                    }]

            # Line graph for showing # of forms by date
            lineAllDates = []
            lineAllValues = []
            for rec in apiData['rpt_submissions_by_breakdown_date']:
                lineAllDates.append(rec['submission_date'])
                lineAllValues.append(rec['amount'])

            # Getting grandtotal form count (total forms submitted)
            grandTotal2 = 0
            for rec in apiData['rpt_submissions_by_job_breakdown']:
                grandTotal2 += rec['form_count']

            # Grouping the data by user for the months with the most submissions table
            linegraph_Data = []
            monthly_count = df_rpt_submissions_by_job_breakdown_date.groupby('submission_date')
            for groupname, data in monthly_count:               
                user_group = {}
                user_group['submission_date']  = groupname    
                data =pd.DataFrame(data[['submission_date', 'form_count']])
                user_group['total_form_count'] = data['form_count'].sum()
                data = data.sort_values('form_count', ascending=False).head(5)
                linegraph_Data.append(user_group)

            lineAllDates2 =[]
            lineAllValues2 = []
            for rec in linegraph_Data:
                lineAllDates2.append(rec['submission_date'])
                lineAllValues2.append(rec['total_form_count'])

            lineGraphData = []
            if apiData['rpt_submissions_by_job_breakdown']:
                lineGraphData = [
                    {
                        "y": lineAllValues2,
                        "x": lineAllDates2,
                        "type": 'line',
                    }
                ]

            # Getting trendline data per job and per form
            trendline_dates = df_rpt_submissions_by_job_breakdown_date.groupby('job_title')
            trendline_data = []
            for job, data in trendline_dates:
                job_group = {}
                job_group['job_name']  = job    
                data =pd.DataFrame(data[['form_count','submission_date','form_name']])
                job_group['job_data'] = data.to_dict(orient='records')
                user_form_groups = data.groupby(['form_name'])
                job_group['form_trendline_data'] = []
                for form_name, form_data in user_form_groups:
                    user_form_dict = {}
                    user_form_dict[form_name] = {}
                    user_form_dict[form_name]['form_counts'] = form_data['form_count'].to_list()
                    user_form_dict[form_name]['submission_dates'] = form_data['submission_date'].to_list()
                    job_group['form_trendline_data'].append(user_form_dict)
                trendline_data.append(job_group)
            
            trendlineTotalsPerJob = []
            for value in trendline_data:
                job_name = value['job_name']
                totalTrendlineDates = []
                totalTrendlineCounts = []
                for data in value['job_data']:
                    trendlineTotals = {}
                    totalTrendlineDates.append(data['submission_date'])
                    totalTrendlineCounts.append(data['form_count'])
                trendlineTotals['job_name'] = job_name
                trendlineTotals['dates'] = totalTrendlineDates
                trendlineTotals['form_counts'] = totalTrendlineCounts
                trendlineTotalsPerJob.append(trendlineTotals)

            # Line graph attribute definition
            lineLayout = {
                "title": {
                    "text": h.execute_sp('get_translation_by_tag', [9099,self.lang,1], self.args)[0]['ltr_text'],
                    "font": {
                        "family": "Arial black",
                        "size": 14,
                    }
                },
                "height": 500,
                "width": 750,
                "yaxis": {
                    "title": {
                        "text": h.execute_sp('get_translation_by_tag', [8852,self.lang,1], self.args)[0]['ltr_text'],
                        "font": {
                            "family": "Arial",
                            "size": 14,
                        },
                    },
                    "zeroline": False,
                    "automargin": True
                },
                "xaxis": {
                    "title": {
                        "text": h.execute_sp('get_translation_by_tag', [1190,self.lang,1], self.args)[0]['ltr_text'],
                        "font": {
                            "family":"Arial",
                            "size": 14,
                        },  
                        "standoff": 40
                    },
                    "showgrid": False,
                    "automargin": True,
                },
            }
           

            report = {            
                'meta': meta,
                'data': apiData,
                'labels': meta['labels'],
                'chart_labels': meta['chart_labels'],
                'job_groups': job_groups,
                'total_by_jobs': total_by_jobs,
                'yearGraphJSON': newdata,
                'layout': json.dumps(lineLayout),
                'lineGraphJSON': lineGraphData,
                'grandTotal': grandTotal,
                'grandTotal2':grandTotal2,
                'form_groups':form_groups,
                'total_by_form':total_by_form,
                'newdata2':newdata2,
                'month_groups':month_groups,
                'job_groups_Data':job_groups_Data,
                'forms_per_job_list':forms_per_job_list,
                'site_forms_Data':site_forms_Data,
                'top10_list':top10_list,
                'bottom10_list':bottom10_list,
                'job_submission_dates':job_submission_dates,
                'form_submission_summary':form_submission_summary,
                'trendline_data':trendline_data,
                'trendlineTotalsPerJob':trendlineTotalsPerJob
            }
        else:
            report = {            
                'meta': meta,
                'data': apiData,
                'labels': meta['labels'],
                'chart_labels': meta['chart_labels'],
                'job_groups': [],
                'total_by_jobs': [],
                'yearGraphJSON': [],
                'layout': [],
                'lineGraphJSON': [],
                'grandTotal': 0,
                'grandTotal2':0,
                'form_groups':[],
                'total_by_form':[],
                'newdata2':[],
                'month_groups':[],
                'job_groups_Data':[],
                'forms_per_job_list':[],
                'site_forms_Data':[],
                'top10_list':[],
                'bottom10_list':[],
                'job_submission_dates':[],
                'form_submission_summary':[],
                'trendline_data':[],
                'trendlineTotalsPerJob':[]
            }
        return report
     