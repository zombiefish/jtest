#Import required modules
import yaml
import helper as h


#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('positive_recognition')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement. 
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions'] if 'rpt_hazard_actions' in apiData else []
        positiveRecognition = apiData['rpt_positive_recognition'] if 'rpt_positive_recognition' in apiData else []
        generalAction=apiData['rpt_get_general_action_by_id'] if 'rpt_get_general_action_by_id' in apiData else []
        reportDistributors=apiData['rpt_form_details_distribution'] if 'rpt_form_details_distribution' in apiData else []
        reviewers=apiData['rpt_form_reviewers'] if 'rpt_form_reviewers' in apiData else []

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'data': apiData,
            'positiveRecognition': positiveRecognition,
            'apiData': apiData,
            'generalAction':generalAction,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
        }

        return report
    