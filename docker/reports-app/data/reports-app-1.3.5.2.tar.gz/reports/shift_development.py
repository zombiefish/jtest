#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('shift_development')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.  
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions']
        positiveRecognition = apiData['rpt_positive_recognition']
        generalAction=apiData['rpt_get_general_action_by_id']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        shifts=apiData['rpt_form_details']['Sub Header'] if 'Sub Header' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Sub Header']) > 0 else []
        comments=apiData['rpt_form_details']['Comments'] if 'Comments' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Comments']) > 0 else []
        equipmentState=apiData['rpt_form_details']['Workplace Details'] if 'Workplace Details' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace Details']) > 0 else []
        workplace1=apiData['rpt_form_details']['Workplace 1'] if 'Workplace 1' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 1']) > 0 else []
        workplace2=apiData['rpt_form_details']['Workplace 2'] if 'Workplace 2' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 2']) > 0 else []
        workplace3=apiData['rpt_form_details']['Workplace 3'] if 'Workplace 3' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 3']) > 0 else []
        workplace4=apiData['rpt_form_details']['Workplace 4'] if 'Workplace 4' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 4']) > 0 else []
        workplace5=apiData['rpt_form_details']['Workplace 5'] if 'Workplace 5' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 5']) > 0 else []
        workplace6=apiData['rpt_form_details']['Workplace 6'] if 'Workplace 6' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 6']) > 0 else []
        workplace7=apiData['rpt_form_details']['Workplace 7'] if 'Workplace 7' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 7']) > 0 else []
        workplace8=apiData['rpt_form_details']['Workplace 8'] if 'Workplace 8' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 8']) > 0 else []
        workplace9=apiData['rpt_form_details']['Workplace 9'] if 'Workplace 9' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 9']) > 0 else []
        workplace10=apiData['rpt_form_details']['Workplace 10'] if 'Workplace 10' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 10']) > 0 else []
        workplace11=apiData['rpt_form_details']['Workplace 11'] if 'Workplace 11' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 11']) > 0 else []
        workplace12=apiData['rpt_form_details']['Workplace 12'] if 'Workplace 12' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 12']) > 0 else []
        workplace13=apiData['rpt_form_details']['Workplace 13'] if 'Workplace 13' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 13']) > 0 else []
        workplace14=apiData['rpt_form_details']['Workplace 14'] if 'Workplace 14' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 14']) > 0 else []
        workplace15=apiData['rpt_form_details']['Workplace 15'] if 'Workplace 15' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace 15']) > 0 else []
        workEquipments1=apiData['work_equipments1']
        workEquipments2=apiData['work_equipments2']
        workEquipments3=apiData['work_equipments3']
        workEquipments4=apiData['work_equipments4']
        workEquipments5=apiData['work_equipments5']
        workEquipments6=apiData['work_equipments6']
        workEquipments7=apiData['work_equipments7']
        workEquipments8=apiData['work_equipments8']
        workEquipments9=apiData['work_equipments9']
        workEquipments10=apiData['work_equipments10']
        workEquipments11=apiData['work_equipments11']
        workEquipments12=apiData['work_equipments12']
        workEquipments13=apiData['work_equipments13']
        workEquipments14=apiData['work_equipments14']
        workEquipments15=apiData['work_equipments15']
        equipmentSummary=apiData['rpt_form_details']['Equipment Summary']

        #Adding new lists to the report specific images  
        multiphotos1 = []
        for wd in workplace1:
            if 'workplace_pictures_1' in wd['field_key']:
                multiphotos1.append(wd)
                del wd

        multiphotos2 = []
        for wd in workplace2:
            if 'workplace_pictures_2' in wd['field_key']:
                multiphotos2.append(wd)
                del wd
        
        multiphotos3 = []
        for wd in workplace3:
            if 'workplace_pictures_3' in wd['field_key']:
                multiphotos3.append(wd)
                del wd

        multiphotos4 = []
        for wd in workplace4:
            if 'workplace_pictures_4' in wd['field_key']:
                multiphotos4.append(wd)
                del wd

        multiphotos5 = []
        for wd in workplace5:
            if 'workplace_pictures_5' in wd['field_key']:
                multiphotos5.append(wd)
                del wd

        multiphotos6 = []
        for wd in workplace6:
            if 'workplace_pictures_6' in wd['field_key']:
                multiphotos6.append(wd)
                del wd

        multiphotos7 = []
        for wd in workplace7:
            if 'workplace_pictures_7' in wd['field_key']:
                multiphotos7.append(wd)
                del wd

        multiphotos8 = []
        for wd in workplace8:
            if 'workplace_pictures_8' in wd['field_key']:
                multiphotos8.append(wd)
                del wd

        multiphotos9 = []
        for wd in workplace9:
            if 'workplace_pictures_9' in wd['field_key']:
                multiphotos9.append(wd)
                del wd
        
        multiphotos10 = []
        for wd in workplace10:
            if 'workplace_pictures_10' in wd['field_key']:
                multiphotos10.append(wd)
                del wd

        multiphotos11 = []
        for wd in workplace11:
            if 'workplace_pictures_11' in wd['field_key']:
                multiphotos11.append(wd)
                del wd

        multiphotos12 = []
        for wd in workplace12:
            if 'workplace_pictures_12' in wd['field_key']:
                multiphotos12.append(wd)
                del wd
        
        multiphotos13 = []
        for wd in workplace13:
            if 'workplace_pictures_13' in wd['field_key']:
                multiphotos13.append(wd)
                del wd

        multiphotos14 = []
        for wd in workplace14:
            if 'workplace_pictures_14' in wd['field_key']:
                multiphotos14.append(wd)
                del wd

        multiphotos15 = []
        for wd in workplace15:
            if 'workplace_pictures_15' in wd['field_key']:
                multiphotos15.append(wd)
                del wd

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'data': apiData,
            'positiveRecognition': positiveRecognition,
            'apiData': apiData,
            'generalAction':generalAction,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'shifts':shifts,
            'comments':comments,
            'workplace1':workplace1,
            'multiphotos1':multiphotos1,
            'workplace2':workplace2,
            'multiphotos2':multiphotos2,
            'workplace3':workplace3,
            'multiphotos3':multiphotos3,
            'workplace4':workplace4,
            'multiphotos4':multiphotos4,
            'workplace5':workplace5,
            'multiphotos5':multiphotos5,
            'workplace6':workplace6,
            'multiphotos6':multiphotos6,
            'workplace7':workplace7,
            'multiphotos7':multiphotos7,
            'workplace8':workplace8,
            'multiphotos8':multiphotos8,
            'workplace9':workplace9,
            'multiphotos9':multiphotos9,
            'workplace10':workplace10,
            'multiphotos10':multiphotos10,
            'workplace11':workplace11,
            'multiphotos11':multiphotos11,
            'workplace12':workplace12,
            'multiphotos12':multiphotos12,
            'workplace13':workplace13,
            'multiphotos13':multiphotos13,
            'workplace14':workplace14,
            'multiphotos14':multiphotos14,
            'workplace15':workplace15,
            'multiphotos15':multiphotos15,
            'equipmentState':equipmentState,
            'workEquipments1':workEquipments1,
            'workEquipments2':workEquipments2,
            'workEquipments3':workEquipments3,
            'workEquipments4':workEquipments4,
            'workEquipments5':workEquipments5,
            'workEquipments6':workEquipments6,
            'workEquipments7':workEquipments7,
            'workEquipments8':workEquipments8,
            'workEquipments9':workEquipments9,
            'workEquipments10':workEquipments10,
            'workEquipments11':workEquipments11,
            'workEquipments12':workEquipments12,
            'workEquipments13':workEquipments13,
            'workEquipments14':workEquipments14,
            'workEquipments15':workEquipments15,
            'equipmentSummary':equipmentSummary,
        }

        return report   
    