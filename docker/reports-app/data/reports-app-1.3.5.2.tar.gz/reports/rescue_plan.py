#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('rescue_plan')   
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.   
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions']
        positiveRecognition=apiData['rpt_positive_recognition']
        generalAction=apiData['rpt_get_general_action_by_id']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        formDetails=apiData['rpt_form_details']
        planApprover=apiData['rpt_form_details']['Plan Approver'] if 'Plan Approver' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Plan Approver']) > 0 else []

        #Adding new list to the data structure to get the timestamps on the signatures
        planApproverTimeStamp = []
        for wd in planApprover:
            if 'plan_approver_img_time' in wd['field_key']:
                planApproverTimeStamp.append(wd)

        rescueSketch=apiData['rpt_form_details']['Rescue Sketch Drawing'] if 'Rescue Sketch Drawing' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Rescue Sketch Drawing']) > 0 else []


        #Adding new list to the data structure to get the timestamps on the signatures
        sketchTimeStamp = []
        for wd in rescueSketch:
            if 'rescue_sketch_draw_img_time' in wd['field_key']:
                sketchTimeStamp.append(wd)

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'hazardsList': hazardsList,
            'generalAction':generalAction,
            'positiveRecognition':positiveRecognition,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'formDetails': formDetails,
            'planApproverTimeStamp': planApproverTimeStamp,
            'sketchTimeStamp': sketchTimeStamp,
        }

        return report
    