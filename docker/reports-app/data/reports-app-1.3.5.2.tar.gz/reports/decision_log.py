#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('decision_log')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.        
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_get_decision_log_by_dlm_id'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_get_decision_log_hazard_actions']
        hazardsInitial = apiData['rpt_hap_pictures_initial']
        hazardsFollowup = apiData['rpt_hap_pictures_followup']
        reviewers = apiData['rpt_get_decision_log_reviewers_by_dlm_id']
        generalAction=apiData['rpt_get_decision_log_general_actions_by_id']
        generalActionInitial=apiData['rpt_get_decision_log_general_action_attachment_by_id_initial']
        generalActionFollowup=apiData['rpt_get_decision_log_general_action_attachment_by_id_followup']
        attachments=apiData['rpt_decision_log_attachment_by_dlm_id']
        participants=apiData['rpt_get_decision_log_participants_by_dlm_id']


        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'hazardsInitial': hazardsInitial,
            'hazardsFollowup': hazardsFollowup,
            'data': apiData,
            'reviewers': reviewers,
            'generalAction': generalAction,
            'generalActionInitial': generalActionInitial,
            'generalActionFollowup': generalActionFollowup,
            'attachments': attachments,
            'participants': participants,
        }

        return report
    