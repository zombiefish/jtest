#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('organizational_risk_assessment')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.   
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_ora_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_ora_hap']
        hazardsInitial=apiData['rpt_hap_pictures_initial']
        hazardsFollowup=apiData['rpt_hap_pictures_followup']
        generalActionInitial=apiData['rpt_ora_general_action_attachment_by_id_initial']
        generalActionFollowup=apiData['rpt_ora_general_action_attachment_by_id_followup']
        oraParticipants=apiData['rpt_ora_participants'][0]
        oraApprovers=apiData['rpt_ora_approvers'][0]        
        generalAction=apiData['rpt_ora_general_actions']
        reviewers=apiData['rpt_ora_reviewers']
        oraPraBowtieHeader=apiData['rpt_ora_pra_bowtie_header']
        steps=apiData['steps']
        bowtieApprovers= apiData['rpt_bowtie_approvers'][0] if 'rpt_bowtie_approvers' in apiData and len(apiData['rpt_bowtie_approvers']) > 0 else []
        bowtieParticipants=apiData['rpt_bowtie_participants'][0] if 'rpt_bowtie_participants' in apiData and len(apiData['rpt_bowtie_participants']) > 0 else []
        oraApprovedBy=apiData['rpt_ora_approved_by'] if 'rpt_ora_approved_by' in apiData and len(apiData['rpt_ora_approved_by']) > 0 else []
        attachments=apiData['rpt_get_ora_attachment_ora_id']

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'hazardsInitial':hazardsInitial,
            'hazardsFollowup':hazardsFollowup,
            'data': apiData,
            'oraParticipants':oraParticipants,
            'oraApprovers':oraApprovers,
            'oraApprovedBy':oraApprovedBy,
            'generalAction':generalAction,
            'generalActionInitial':generalActionInitial,
            'generalActionFollowup':generalActionFollowup,
            'reviewers':reviewers,
            'oraPraBowtieHeader':oraPraBowtieHeader,
            'bowtieApprovers':bowtieApprovers,
            'bowtieParticipants':bowtieParticipants,
            'steps':steps,
            'attachments':attachments


        }

        return report
    