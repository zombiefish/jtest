#Import required modules
import pandas as pd
import yaml
import helper as h


#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('positive_id_summary')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement. 
    def get_report(self):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')
        
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        meta['filter_data'] = apiData['filter_data']


#Modifying the data structure to get the labels and positive id summary data 
        labels = []
        df_positive_id_summary = None
        if 'rpt_positive_id_summary' in apiData:
            if apiData['rpt_positive_id_summary']:
                labels = {key:value for key, value in apiData['rpt_positive_id_summary'][0].items() if key.endswith('_label')}

                df_positive_id_summary = pd.DataFrame(apiData['rpt_positive_id_summary'])
                df_positive_id_summary.fillna('', inplace=True)
        
        report = {            
            'meta': meta,
            'data': apiData,
            'labels': labels,
            'positive_id_summary': df_positive_id_summary
        }

        return report
    