#Import required modules
import pandas as pd
#from pandas.io.formats.style import no_mpl_message
import yaml
import helper as h
from datetime import date

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('training_matrix_by_employee')
        self.args = args
        self.params = h.get_url_param(args)
        self.lang = args['lang'] if args and 'lang' in args else 1        

#Function to get data from the API as per the report section requirement.         
    def get_report(self):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')
        df = False
        labels = {}
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        meta['filter_data'] = apiData['filter_data']
        
        report = {            
            'meta': meta,
            'data': apiData            
        }

        return report
    