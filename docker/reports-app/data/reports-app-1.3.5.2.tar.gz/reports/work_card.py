#Import required modules
import yaml
import helper as h


#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('work_card')
        self.args = args
        self.params = h.get_url_param(args)

#Function to get data from the API as per the report section requirement.      
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        tasksToDo = apiData['rpt_form_details']['Tasks to do'] if 'Tasks to do' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Tasks to do']) > 0 else []
        workArea = apiData['rpt_work_card_workarea']
        shifts = apiData['rpt_form_details']['Shift']  if 'Shift' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Shift']) > 0 else []
        accessToWorksite = apiData['rpt_form_details']['Access to Worksite'] if 'Access to Worksite' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Access to Worksite']) > 0 else []
        shiftStart = apiData['rpt_form_details']['Shift Start Workplace Conditions'] if 'Shift Start Workplace Conditions' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Shift Start Workplace Conditions']) > 0 else []
        pidLikes=apiData['rpt_positive_recognition_likes']
        pidComments=apiData['rpt_positive_recognition_comment']
        accessToWorksiteSurface = apiData['rpt_form_details']['Access to the workplace'] if 'Access to the workplace' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Access to the workplace']) > 0 else []
        methodOfWork = apiData['rpt_form_details']['Method of work'] if 'Method of work' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Method of work']) > 0 else []
        workplace = apiData['rpt_form_details']['Workplace'] if 'Workplace' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Workplace']) > 0 else []
        underground_workarea = apiData['rpt_form_details']['Work Area'] if 'Work Area' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Work Area']) > 0 else []
        locationOfRefuge = apiData['rpt_form_details']['Location of the closest refuge'] if 'Location of the closest refuge' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Location of the closest refuge']) > 0 else []
        
        #Adding new list to the report specific images
        multiphotosStart = []
        startStateDetails = []
        for wd in shiftStart:
            if 'start_state_pictures' in wd['field_key']:
                multiphotosStart.append(wd)
            elif 'start_state_details' in wd['field_key']:
                startStateDetails.append(wd)

        supervisorVisit = apiData['rpt_form_details']['Supervisor Visit'] if 'Supervisor Visit' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Supervisor Visit']) > 0 else []
        planning = apiData['rpt_form_details']['Planning'] if 'Planning' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Planning']) > 0 else []
        decision = apiData['rpt_form_details']['Decision'] if 'Decision' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Decision']) > 0 else []


        #Adding new list to the data structure to get the timestamps on the signatures
        decision_emp_signatures = []
        decision_super_signatures = []
        emp_sign_timestamp = []
        super_sign_timestamp = []
        for wd in decision:
            if ('signature_employee' in wd['field_key']):
                decision_emp_signatures.append(wd)
            if ('signature_supervisor' in wd['field_key']):
                decision_super_signatures.append(wd)
            if ('supervisor_signature_img_time' in wd['field_key']):
                super_sign_timestamp.append(wd)
            if ('employee_signature_img_time' in wd['field_key']):
                emp_sign_timestamp.append(wd)
        

        execution = apiData['rpt_form_details']['Execution'] if 'Execution' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Execution']) > 0 else []

        #Adding new list to the data structure to get the timestamps on the signatures
        execution_sign_timestamp = []
        for wd in execution:
            if ('supervisor_signature_execution_img_time' in wd['field_key']):
                execution_sign_timestamp.append(wd)
            elif ('employee_signature_execution_img_time' in wd['field_key']):
                execution_sign_timestamp.append(wd)

        shiftEnd = apiData['rpt_form_details']['Shift End Workplace Conditions'] if 'Shift End Workplace Conditions' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Shift End Workplace Conditions']) > 0 else []

        #Adding new list to the report specific images
        multiphotosEnd = []
        endStateDetails = []
        for wd in shiftEnd:
            if 'end_state_pictures' in wd['field_key']:
                multiphotosEnd.append(wd)
            elif 'end_state_details' in wd['field_key']:
                endStateDetails.append(wd)

        drillingLoading = apiData['rpt_form_details']['Drilling and Loading'] if 'Drilling and Loading' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Drilling and Loading']) > 0 else []
        groundSupport = apiData['rpt_work_card_ground_support'] 
        materialsNextShift = apiData['rpt_form_details']['Materials Required for Next Shift'] if 'Materials Required for Next Shift' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['Materials Required for Next Shift']) > 0 else []
        hazardsList = apiData['rpt_hazard_actions_list']
        hazardsInitial = apiData['rpt_hap_pictures_initial']
        hazardsFollowup = apiData['rpt_hap_pictures_followup']
        positiveRecognition = apiData['rpt_positive_recognition']
        positiveRecognitionImages=apiData['rpt_pid_pictures']
        generalAction=apiData['rpt_get_general_action_by_id']
        generalActionInitial=apiData['rpt_get_general_action_attachment_by_sga_id_initial']
        generalActionFollowup=apiData['rpt_get_general_action_attachment_by_sga_id_followup']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        reportType=apiData['report_type']
        

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'data': apiData,
            'apiData': apiData,
            'tasksToDo': tasksToDo,
            'workArea': workArea,
            'shifts': shifts,
            'accessToWorksite': accessToWorksite,
            'shiftStart': shiftStart,
            'supervisorVisit': supervisorVisit,
            'planning': planning,
            'decision': decision,
            'execution': execution,
            'execution_sign_timestamp': execution_sign_timestamp,
            'shiftEnd': shiftEnd,
            'drillingLoading': drillingLoading,
            'groundSupport': groundSupport,
            'materialsNextShift': materialsNextShift,
            'multiphotosStart':multiphotosStart,
            'multiphotosEnd':multiphotosEnd,
            'startStateDetails': startStateDetails,
            'endStateDetails': endStateDetails,
            'decision_emp_signatures': decision_emp_signatures,
            'decision_super_signatures': decision_super_signatures,
            'emp_sign_timestamp': emp_sign_timestamp,
            'super_sign_timestamp': super_sign_timestamp,
            'hazardsList': hazardsList,
            'hazardsFollowup':hazardsFollowup,
            'hazardsInitial':hazardsInitial,
            'positiveRecognition': positiveRecognition,
            'positiveRecognitionImages':positiveRecognitionImages,
            'generalAction':generalAction,
            'generalActionInitial':generalActionInitial,
            'generalActionFollowup':generalActionFollowup,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'pidLikes':pidLikes,
            'pidComments':pidComments,
            'accessToWorksiteSurface':accessToWorksiteSurface,
            'methodOfWork':methodOfWork,
            'workplace':workplace,
            'underground_workarea':underground_workarea,
            'locationOfRefuge':locationOfRefuge,
            'reportType':reportType
        }

        return report
    