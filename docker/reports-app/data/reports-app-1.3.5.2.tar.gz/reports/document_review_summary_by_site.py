#Import required modules
import yaml
import helper as h
import pandas as pd

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('document_review_summary_by_site')
        self.args = args
        self.params = h.get_url_param(args)
        self.lang = args['lang'] if args and 'lang' in args else 1   

#Function to get data from the API as per the report section requirement.    
    def get_report(self, filters=None):
        c = self.config

        apiData = h.get_report(f'{c["api"]}?{self.params}')

        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        meta['filter'] = apiData['filter']
        meta['args'] = apiData['args']
        meta['filter_data'] = apiData['filter_data']

        return self.site_functionlity(self, meta, apiData)

    def site_functionlity(self, meta, apiData):
        
        meta['language_code'] = h.execute_sql("select lng_name from language where lng_id = " + str(self.lang))['result'][0]['lng_name'] 

        ## Getting the data to populate the graphs per site
        if 'rpt_document_review_summary_by_site' in apiData and apiData['rpt_document_review_summary_by_site']:
            df_rpt_document_review_summary_by_site = pd.DataFrame(apiData['rpt_document_review_summary_by_site'])
            df_rpt_document_review_summary_by_site.fillna('')
        
        ## Modifying data structure as per the document names in the table            
            site_groups = df_rpt_document_review_summary_by_site.groupby('Site')
            total_by_total = {}
            description = {}
            total_of_complete = {}
            total_of_due = {}
            total_of_overdue = {}
            total_of_required = {}
            total_of_reviewed = {}
            total_of_reviewers_overdue = {}
            total_of_completion = {}
            graph_by_site = {}

            for name, group in site_groups:
                total_by_total[name] = group['Total'].sum() 
                description[name] = group['drm_description']               
                total_of_complete[name] = group['Complete'].sum()
                total_of_due[name] = group['Due'].sum()
                total_of_overdue[name] = group['DocsOverdue'].sum()
                total_of_required[name] = group['Required'].sum()
                total_of_reviewed[name] = group['Reviewed'].sum()
                total_of_reviewers_overdue[name] = group['Overdue'].sum()
                total_of_completion[name] = round((total_of_complete[name] / total_by_total[name]) * 100)
                doc_types = []
                doc_completion = []

                doc_type_groups = group.groupby('DocType')
                for doc_type, doc_type_group in doc_type_groups:
                    doc_types.append(doc_type)
                    doc_completion.append(round((doc_type_group['Complete'].sum() / doc_type_group['Total'].sum()) * 100))
                        

                graph_by_site[name] = [{
                            "x": doc_types,
                            "y": doc_completion,
                            "type": 'bar',
                            "orientation": 'v',
                            "name": doc_types,
                            "xaxis": doc_types
                        }]
               
            report = {            
                'meta': meta,
                'data': apiData,
                'site_groups': site_groups,
                'total_by_total': total_by_total,              
                'total_of_complete':total_of_complete,
                'total_of_due':total_of_due,
                'total_of_overdue':total_of_overdue,
                'total_of_required':total_of_required,
                'total_of_reviewed':total_of_reviewed,
                'total_of_reviewers_overdue':total_of_reviewers_overdue,
                'total_of_completion':total_of_completion,
                'graph_by_site': graph_by_site,
                'summary_table': apiData['summary_table']
            }
            
        else:
            report = {            
                'meta': meta,
                'data': apiData,
                'site_groups': [],
                'total_by_total':[],
                'total_of_complete':[],
                'total_of_due':[],
                'total_of_overdue':[],
                'total_of_required':[],
                'total_of_reviewed':[],
                'total_of_completion':[],
                'total_of_reviewers_overdue':[],
                'graph_by_site': {},
                'summary_table': None
            }
        return report

        
    
