#Import required modules
import yaml
import helper as h

#Defining a class as report
class Report:

#Function to access the yaml file
    def __init__(self, args):
        self.config = h.report_config('confined_space_activity_log')
        self.args = args
        self.params = h.get_url_param(args)


#Function to get data from the API as per the report section requirement.     
    def get_report(self, formSubmissionId):
        formSubmissionId = str(formSubmissionId)
        c = self.config

        apiData = h.get_report(f'{c["api"]}/{formSubmissionId}?{self.params}')
        formHeader = apiData['rpt_form_header'][0]
        meta = {}
        meta['header'] = apiData['header']
        meta['footer'] = apiData['footer']
        hazardsList = apiData['rpt_hazard_actions']
        positiveRecognition=apiData['rpt_positive_recognition']
        generalAction=apiData['rpt_get_general_action_by_id']
        reportDistributors=apiData['rpt_form_details_distribution']
        reviewers=apiData['rpt_form_reviewers']
        formDetails=apiData['rpt_form_details']
        airQuality1=apiData['rpt_form_details']['1'] if '1' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['1']) > 0 else []
        airQuality2=apiData['rpt_form_details']['2'] if '2' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['2']) > 0 else []
        airQuality3=apiData['rpt_form_details']['3'] if '3' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['3']) > 0 else []
        airQuality4=apiData['rpt_form_details']['4'] if '4' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['4']) > 0 else []
        airQuality5=apiData['rpt_form_details']['5'] if '5' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['5']) > 0 else []
        airQuality6=apiData['rpt_form_details']['6'] if '6' in apiData['rpt_form_details'] and len(apiData['rpt_form_details']['6']) > 0 else []
  
        #airQuality=apiData['rpt_hot_work_permit_air_quality_test']
        confinedSpaceLog=apiData['rpt_confined_space_employee_log']
        entryPictures=apiData['rpt_form_pictures']

#Converting boolean values to yes/no
        if len(positiveRecognition) > 0:
            for pid in positiveRecognition:
                pid['Was_Recognition_Given'] = 'Yes' if  pid['Was_Recognition_Given'] == '\u0001' else 'No'

        for space in confinedSpaceLog:
            space['RescuePlan'] = 'Yes' if  space['RescuePlan'] == '1' else 'No'

        report = {
            'formHeader': formHeader,
            'meta': meta,
            'hazardsList': hazardsList,
            'data': apiData,
            'generalAction':generalAction,
            'positiveRecognition':positiveRecognition,
            'reportDistributors':reportDistributors,
            'reviewers':reviewers,
            'formDetails': formDetails,
            'airQuality1': airQuality1,
            'airQuality2': airQuality2,
            'airQuality3': airQuality3,
            'airQuality4': airQuality4,
            'airQuality5': airQuality5,
            'airQuality6': airQuality6,
            'confinedSpaceLog': confinedSpaceLog,
            'entryPictures': entryPictures,
        }

        return report

    