## Python libraries
from itertools import zip_longest
from flask import Flask, jsonify, render_template, request
import yaml, json, os
import decimal
import numpy as np

## Sofvie BI libraries
import helper as h
#######

# Create the Flask app instance
app = Flask(__name__, static_url_path='/static')
app.jinja_env.filters['zip'] = zip
app.jinja_env.filters['zip_longest'] = zip_longest

# get_logo from helper file
def get_logo():
    return h.get_logo()
app.jinja_env.globals.update(get_logo=get_logo)

# get client url from helper file
def get_client_url():
    return h.get_client_url()
app.jinja_env.globals.update(get_client_url=get_client_url)

def get_translation(tags, lang):
    # conver list of tags to comma separated string        
    str_tags = ','.join(str(e) for e in tags)

    language_query = """
        SELECT ltr_text , ltr_tag
        FROM language_translation
        WHERE ltr_tag in ("""+ str_tags +""")
        AND ltr_lng_id = '""" + lang + """' 
        AND ltr_tag_type = 1
    """
    # execute query     
    get_trans = h.execute_sql(language_query)['result']
         
    finalTranslations = {}
    for tr in get_trans:
        finalTranslations[tr['ltr_tag']] = tr['ltr_text']
    return finalTranslations
    
app.jinja_env.globals.update(get_translation=get_translation)

## Get reports
def get_reports(lang):
    Reports_query = """
    call get_report_list_by_language(""" + lang + """)
    """
    # execute query     
    get_reports = h.execute_sql(Reports_query)['result']
    
    activeReports = {}
    for report in get_reports:
        activeReports[report['ID']] = [report['ID'], report['ReportName'], report['ReportDescription'], report['ReportURL']]
    return activeReports

app.jinja_env.globals.update(get_reports=get_reports)

def get_report_info_url(lang):
    Reports_query = """
    call get_report_list_by_language(""" + lang + """)
    """

    # execute query     
    get_reports = h.execute_sql(Reports_query)['result']

    activeReports = {}
    for report in get_reports:
        if request.path.replace('/','') == report['ReportURL']:
            activeReports = report['ReportDescription']
    return activeReports

    # execute query     
    get_reports = h.execute_sql(Reports_query)['result']

app.jinja_env.globals.update(get_report_info_url=get_report_info_url)

#get_date_range is used for the date range filter in BI
def get_date_range(lang, report_slug, mode):
    date_range_data = h.execute_sp('get_date_range', [int(lang)])
    allow_future_dates = h.execute_sql("SELECT rpt_allow_future_dates FROM Reports where ReportURL = '"+report_slug+"';")
    
    if (allow_future_dates["result"]):
        allow_future_dates["result"][0]['rpt_allow_future_dates']
        
    if allow_future_dates["result"][0]['rpt_allow_future_dates'] == 0:
        # filter out date ranges from list of dict with rld_score > 0
        date_range_data = [each for each in date_range_data if each['rld_score'] == None or each['rld_score'] <= 0]

    if report_slug == 'pending_hazard_action' or report_slug == 'pending_general_action':        
        RLD_OPTIONS = [2,3]
        temp = []
        for each in date_range_data:
            if each['rld_option'] in RLD_OPTIONS:
                temp.append(each)
        return temp

    if mode == 'date_range':
        return date_range_data
    groups = date_range_groups(date_range_data)
    return groups

app.jinja_env.globals.update(get_date_range=get_date_range)


def date_range_groups(date_range_data):
    final_object = []
    temp = {}
    for each in date_range_data:
        if each['category_name'] not in temp.keys():
            temp[each['category_name']] = []
        temp[each['category_name']].append(
            {
                'id': each['rld_id'],
                'name': each['rld_name']
            }
        )

    temp_keys  = temp.keys()
    for each in temp_keys:
        final_object.append(
            {
                'id': '',
                'text': each,
                'childern' : temp[each]
            }
        )
    

    return final_object

def get_domain():
    return h.get_domain()

app.jinja_env.globals.update(get_domain=get_domain)

# default function to convert all numpy int64 type values to int values before jsonify
def serialize_json(obj):
    if isinstance(obj, np.int64):
        return int(obj)
    raise TypeError ("Type %s is not serializable" % type(obj))
    
# Client Status Dashboard
@app.route('/api/v1/_csd', methods=['POST'])
def csd_view():
    # Import the report Class
    from api import _csd as csd

    request_data = request.json    
    report = csd.get_csd_data(args=request_data)

    # Generate HTML report with API data
    return report

#### API VIEW ####
@app.route('/api/v1/<reportSlug>')
def api_vie1w(reportSlug):

    # Fetch report data
    result = h.get_report(url=request.url, isJSON=True, reportSlug=reportSlug, formSubmissionId=None, params=request.args)
    
    # Return JSON data 
    #We need the below line of code to get readable API output for Targets report
    result = json.dumps(result, default=serialize_json)
    return jsonify(result)
    

@app.route('/api/v1/<reportSlug>/<formSubmissionId>')
def api_view(reportSlug, formSubmissionId):

    # Fetch report data
    result = h.get_report(url=request.url, isJSON=True, reportSlug=reportSlug, formSubmissionId=formSubmissionId, params=request.args)
    
    # Return JSON data
    return jsonify(result)

###################



#### FILTERED REPORT VIEWS ####

# archived_submissions
@app.route('/archived_submissions')
def archived_submissions_view():
    # Import the report Class
    from reports import archived_submissions

    # Create a report object
    report = archived_submissions.Report(request.args)

    # Get form data from filter pane
    # filters = request.form

    # Fetch report data
    r = report.get_report()

    # Generate HTML report with API data
    return render_template('archived_submissions.html', data = r['data'], meta=r['meta'])


# document_review_summary
@app.route('/document_review_summary')
def document_review_summary_view():
    # Import the report Class
    from reports import document_review_summary

    # Create a report object
    report = document_review_summary.Report(request.args)

    # Get form data from filter pane
    filters = request.form

    # Fetch report data
    r = report.get_report(filters=filters)

    if 'report_selection' in r['meta']['args'] and (r['meta']['args']['report_selection'] == '89'):
        return render_template('document_review_summary.html', data = r['data'],
                            meta=r['meta'],
                            site_groups=r['site_groups'],
                            graph_by_site=r['graph_by_site'],
                            total_by_total=r['total_by_total'],
                            total_of_complete=r['total_of_complete'],
                            total_of_due=r['total_of_due'],
                            total_of_overdue=r['total_of_overdue'],
                            total_of_required=r['total_of_required'],
                            total_of_reviewed=r['total_of_reviewed'],
                            total_of_reviewers_overdue=r['total_of_reviewers_overdue'], 
                            total_of_completion=r['total_of_completion'],
                            summary_table=r['summary_table'])

    elif 'report_selection' in r['meta']['args'] and (r['meta']['args']['report_selection'] == '90'):
         return render_template('document_review_summary.html', data = r['data'], meta=r['meta'])

    elif 'report_selection' in r['meta']['args'] and (r['meta']['args']['report_selection'] == '99'):
         return render_template('document_review_summary_by_document.html',
                            data = r['data'],
                            meta=r['meta'],
                            drm_by_document = r['drm_by_document'],
                            labels=r['labels']
                            )
    else:
        # Generate HTML report with API data
        return render_template('document_review_summary.html', data = r['data'], meta=r['meta'])


# document_review_summary_by_site
@app.route('/document_review_summary_by_site')
def document_review_summary_by_site_view():
    # Import the report Class
    from reports import document_review_summary_by_site

    # Create a report object
    report = document_review_summary_by_site.Report(request.args)

    # Get form data from filter pane
    filters = request.form

    # Fetch report data
    r = report.get_report(filters=filters)

    # Generate HTML report with API data
    return render_template('document_review_summary_by_site.html',
                            data = r['data'],
                            meta=r['meta'],
                            site_groups=r['site_groups'],
                            graph_by_site=r['graph_by_site'],
                            total_by_total=r['total_by_total'],
                            total_of_complete=r['total_of_complete'],
                            total_of_due=r['total_of_due'],
                            total_of_overdue=r['total_of_overdue'],
                            total_of_required=r['total_of_required'],
                            total_of_reviewed=r['total_of_reviewed'],
                            total_of_reviewers_overdue=r['total_of_reviewers_overdue'], 
                            total_of_completion=r['total_of_completion'],
                            summary_table=r['summary_table']
                            )

# document_review_summary_by_user
@app.route('/document_review_summary_by_user')
def document_review_summary_by_user_view():
    # Import the report Class
    from reports import document_review_summary_by_user

    # Create a report object
    report = document_review_summary_by_user.Report(request.args)

    # Get form data from filter pane
    filters = request.form

    # Fetch report data
    r = report.get_report(filters=filters)

    # Generate HTML report with API data
    return render_template('document_review_summary_by_user.html', data = r['data'], meta=r['meta'])

# document_review_summary_by_document
@app.route('/document_review_summary_by_document')
def document_review_summary_by_document_view():
    # Import the report Class
    from reports import document_review_summary_by_document

    # Create a report object
    report = document_review_summary_by_document.Report(request.args)

    # Get form data from filter pane
    filters = request.form

    # Fetch report data
    r = report.get_report(filters=filters)

    # Generate HTML report with API data
    return render_template('document_review_summary_by_document.html',
                            data = r['data'],
                            meta=r['meta'],
                            drm_by_document = r['drm_by_document'],
                            labels=r['labels']
                            )

# emergency contact
@app.route('/emergency_contact')
def emergency_contact_view():
    # Import the report Class
    from reports import emergency_contact

    # Create a report object
    report = emergency_contact.Report(request.args)

    # Get form data from filter pane
    # filters = request.form

    # Fetch report data
    r = report.get_report()

    # Generate HTML report with API data
    return render_template('emergency_contact.html', data = r['data'], meta=r['meta'], emergencyContact=r['emergencyContact'], labels = r['labels'])

# equipment_status
@app.route('/equipment_status')
def equipment_status_view():
    # Import the report Class
    from reports import equipment_status

    # Create a report object
    report = equipment_status.Report(request.args)

    # Get form data from filter pane
    # filters = request.form

    # Fetch report data
    r = report.get_report()

    # Generate HTML report with API data
    return render_template('equipment_status.html', data = r['data'], meta=r['meta'])

# equipment_history
@app.route('/equipment_history')
def equipment_history():
    # Import the report Class
    from reports import equipment_history

    # Create a report object
    report = equipment_history.Report(request.args)

    # Get form data from filter pane
    # filters = request.form

    # Fetch report data
    r = report.get_report()

    # Generate HTML report with API data
    return render_template('equipment_history.html', data = r['data'], meta=r['meta'], site_equip_list=r['site_equip_list'])

# general_action_planned_vs_actual
@app.route('/general_action_planned_vs_actual')
def general_action_planned_vs_actual_view():
    # Import the report Class
    from reports import general_action_planned_vs_actual

    # Create a report object
    report = general_action_planned_vs_actual.Report(request.args)

    # Fetch report data
    r = report.get_report()

    # Generate HTML report with API data
    return render_template('general_action_planned_vs_actual.html', data = r['data'], meta=r['meta'])

# hazard_actions_planned_vs_actual
@app.route('/hazard_actions_planned_vs_actual')
def hazard_actions_planned_vs_actual_view():
    # Import the report Class
    from reports import hazard_actions_planned_vs_actual

    # Create a report object
    report = hazard_actions_planned_vs_actual.Report(request.args)

    # Fetch report data
    r = report.get_report()

    # Generate HTML report with API data
    return render_template('hazard_actions_planned_vs_actual.html', data = r['data'], meta=r['meta'])

# hazard_action_turn_around_time
@app.route('/hazard_action_turn_around_time')
def hazard_action_turn_around_time_view():
    # Import the report Class
    from reports import hazard_action_turn_around_time

    # Create a report object
    report = hazard_action_turn_around_time.Report(request.args)

    # Fetch report data
    r = report.get_report()

    # Generate HTML report with API data
    return render_template('hazard_action_turn_around_time.html', 
                            data = r['data'], 
                            meta=r['meta'], 
                            labels= r['labels'], 
                            pieJSON=r['pieJSON'], 
                            lineGraphJSON=r['lineGraphJSON'],
                            df_hazard_action = r['df_hazard_action'])

# submissions_breakdown_summary
@app.route('/training_matrix_summary')
def training_matrix_summary_view():
    # Import the report Class
    from reports import training_matrix_summary

    # Create a report object
    report = training_matrix_summary.Report(request.args)

    # Get form data from filter pane
    filters = request.form

    # Fetch report data
    r = report.get_report(filters=filters)

    if 'report_selection' in r['meta']['args'] and r['meta']['args']['report_selection'] == '111':
        # Training Matrix by Job
        return render_template('training_matrix_summary.html',          
                            template = 'trainingMatrixByJob', 
                            data = r['data'], 
                            meta=r['meta'])
    
    elif 'report_selection' in r['meta']['args'] and r['meta']['args']['report_selection'] == '110':
        # Training Matrix by Employee
        return render_template('training_matrix_summary.html',  
                            template = 'trainingMatrixByEmployee', 
                            data = r['data'], 
                            meta=r['meta'])

    else:
        # "Catch all"
        return render_template('training_matrix_summary.html',data = r['data'], 
                meta = r['meta'])

# incident_summary
@app.route('/incident_summary')
def incident_summary_view():
    # Import the report Class
    from reports import incident_summary

    # Create a report object
    report = incident_summary.Report(request.args)

    # Fetch report data
    r = report.get_report()

    # Generate HTML report with API data
    return render_template('incident_summary.html', 
                            data = r['data'], 
                            meta=r['meta'],
                            labels= r['labels'],
                            incident_summary=r['incident_summary'],
                            incidentJSON = r['incidentJSON'],
                            rcaJSON = r['rcaJSON'],
                            incident_count = r['incident_count'],
                            rca_count = r['rca_count'],
                            response_plotly_json=r['response_plotly_json'],
                            response_plotly_json_past_year = r['response_plotly_json_past_year'],
                            graphData = r['graphData']
                            )

# pending_general_action
@app.route('/pending_general_action')
def pending_general_action_view():
    # Import the report Class
    from reports import pending_general_action
    # Create a report object
    report = pending_general_action.Report(request.args)
    # Fetch report data
    r = report.get_report()
    # Generate HTML report with API data
    return render_template('pending_general_action.html', 
                            data = r['data'], 
                            meta=r['meta'],
                            labels= r['labels'],
                            pending_general_action = r['pending_general_action'],
                            todays_date=r['todays_date'])

# pending_hazard_actions
@app.route('/pending_hazard_action')
def pending_hazard_action_view():
    # Import the report Class
    from reports import pending_hazard_action
    # Create a report object
    report = pending_hazard_action.Report(request.args)
    # Fetch report data
    r = report.get_report()
    # Generate HTML report with API data
    return render_template('pending_hazard_action.html', 
                            data = r['data'], 
                            meta=r['meta'],
                            labels= r['labels'],
                            pending_hazard_action = r['pending_hazard_action'],
                            todays_date=r['todays_date'])

# targets_change_log
@app.route('/targets_change_log/<per_id>')
def targets_change_log_view(per_id):
    # Import the report Class
    from reports import targets_change_log

    # Create a report object
    report = targets_change_log.Report(request.args)

    # Fetch report data
    r = report.get_report(per_id)

    # Generate HTML report with API data
    return render_template('targets_change_log.html', data = r['data'], meta=r['meta'], targetCommentdata=r['targetCommentdata'],targetFormData=r['targetFormData'])
    
# target_status_by_employee
@app.route('/target_status_by_employee')
def target_status_by_employee_view():
    # Import the report Class
    from reports import target_status_by_employee

    # Create a report object
    report = target_status_by_employee.Report(request.args)

    # Fetch report data
    r = report.get_report()

    # Generate HTML report with API data
    return render_template('target_status_summary.html', data = r['data'], meta=r['meta'])

# targets_detail_planned_vs_actual
@app.route('/targets_detail_planned_vs_actual')
def targets_detail_planned_vs_actual():
    # Import the report Class
    from reports import targets_detail_planned_vs_actual

    # Create a report object
    report = targets_detail_planned_vs_actual.Report(request.args)

    # Fetch report data
    r = report.get_report()

    # Generate HTML report with API data
    return render_template('targets_detail_planned_vs_actual.html', data = r['data'], labels=r['labels'], meta=r['meta'],targets_planned_vs_actual_data=r['targets_planned_vs_actual_data']
    ,summary_total=r['summary_total'])

# employees_by_site
@app.route('/employees_by_site')
def employees_by_site():
    # Import the report Class
    from reports import employees_by_site

    # Create a report object
    report = employees_by_site.Report(request.args)

    # Fetch report data
    r = report.get_report()

    # Generate HTML report with API data
    return render_template('employees_by_site.html', context=r['context'], data = r['data'], labels=r['labels'], meta=r['meta'])

# submissions_breakdown_summary
@app.route('/submissions_breakdown_summary')
def submissions_breakdown_summary_view():
    # Import the report Class
    from reports import submissions_breakdown_summary

    # Create a report object
    report = submissions_breakdown_summary.Report(request.args)

    # Get form data from filter pane
    filters = request.form

    # Fetch report data
    r = report.get_report(filters=filters)

    if 'report_selection' in r['meta']['args'] and r['meta']['args']['report_selection'] == '63':
        #Submissions Breakdown
        return render_template('submissions_breakdown_summary.html', data = r['data'], 
                            meta=r['meta'], 
                            graphJSON=r['graphJSON'], 
                            grandTotal=r['grandTotal'], 
                            layout = r['layout'], 
                            lineGraphJSON = r['lineGraphJSON'], 
                            template = 'submissionsBreakdown', 
                            top10Values=r['top10Values'], 
                            bottom10Values=r['bottom10Values'], 
                            newdata2=r['newdata2'],
                            month_groups=r['month_groups'],
                            forms_list=r['forms_list'],
                            form_submission_summary=r['form_submission_summary'],
                            trendlines_total=r['trendlines_total'])
    
    elif 'report_selection' in r['meta']['args'] and r['meta']['args']['report_selection'] == '64':
        #Submissions Breakdown by Job
        return render_template('submissions_breakdown_summary.html',data=r['data'], 
                            meta=r['meta'],
                            labels=r['labels'],
                            chart_labels=r['chart_labels'],
                            job_groups=r['job_groups'],
                            total_by_jobs=r['total_by_jobs'],
                            yearGraphJSON=r['yearGraphJSON'],
                            template = 'submissionsBreakdownByJob',
                            layout=r['layout'],
                            lineGraphJSON=r['lineGraphJSON'],
                            grandTotal2=r['grandTotal2'],
                            total_by_form=r['total_by_form'],
                            newdata2=r['newdata2'],
                            month_groups=r['month_groups'],
                            job_groups_Data=r['job_groups_Data'],
                            forms_per_job_list=r['forms_per_job_list'],
                            site_forms_Data=r['site_forms_Data'],
                            top10_list=r['top10_list'],
                            bottom10_list=r['bottom10_list'],
                            job_submission_dates=r['job_submission_dates'],
                            form_submission_summary=r['form_submission_summary'],
                            trendline_data=r['trendline_data'],
                            trendlineTotalsPerJob=r['trendlineTotalsPerJob'])
    
    elif 'report_selection' in r['meta']['args'] and r['meta']['args']['report_selection'] == '65':
        #Submissions Breakdown by Site
        return render_template('submissions_breakdown_summary.html',data=r['data'], 
                            meta=r['meta'],
                            labels=r['labels'],
                            chart_labels=r['chart_labels'],
                            site_groups=r['site_groups'],
                            total_by_sites=r['total_by_sites'],
                            yearGraphJSON=r['yearGraphJSON'],
                            template = 'submissionsBreakdownBySite',
                            lineGraphJSON=r['lineGraphJSON'],
                            layout=r['layout'],
                            grandTotal=r['grandTotal'],
                            newdata2=r['newdata2'],
                            site_groups_Data=r['site_groups_Data'],
                            forms_per_site_list=r['forms_per_site_list'],
                            top10_list=r['top10_list'],
                            bottom10_list=r['bottom10_list'],
                            site_forms_Data=r['site_forms_Data'],
                            site_submission_dates=r['site_submission_dates'],
                            form_submission_summary=r['form_submission_summary'],
                            trendline_data=r['trendline_data'],
                            trendlineTotalsPerSite=r['trendlineTotalsPerSite'])

    elif 'report_selection' in r['meta']['args'] and r['meta']['args']['report_selection'] == '8':
        #Submissions Breakdown by User
        return render_template('submissions_breakdown_summary.html',data = r['data'], 
                meta = r['meta'],
                graphData = r['allData'],
                user_groups = r['user_groups'],
                total_by_users = r['total_by_users'],
                template = 'submissionsBreakdownByUser',
                grandTotal=r['grandTotal'],
                total_by_user=r['total_by_user'],
                lineGraphJSON=r['lineGraphJSON'],
                linelayout=r['linelayout'],
                newdata2=r['newdata2'],
                user_groups_Data=r['user_groups_Data'],
                form_count_per_user=r['form_count_per_user'],
                user_forms_Data=r['user_forms_Data'],
                newdata=r['newdata'],
                user_groups_Data_Pie_Chart=r['user_groups_Data_Pie_Chart'],
                forms_per_user_list=r['forms_per_user_list'],
                top10_list=r['top10_list'],
                bottom10_list=r['bottom10_list'],
                user_submission_dates=r['user_submission_dates'],
                form_submission_summary=r['form_submission_summary'],
                trendline_data=r['trendline_data'],
                trendlineTotals=r['trendlineTotals'],
                trendlineTotalsPerUser=r['trendlineTotalsPerUser'])

    else:
        # "Catch all"
        return render_template('submissions_breakdown_summary.html',data = r['data'], 
                meta = r['meta'])

# submissions_by_breakdown
@app.route('/submissions_by_breakdown')
def submissions_by_breakdown_view():
    # Import the report Class
    from reports import submissions_by_breakdown

    # Create a report object
    report = submissions_by_breakdown.Report(request.args)

    # Fetch report data
    r = report.get_report()

    # Generate HTML report with API data
    return render_template('submissions_by_breakdown.html', 
                data = r['data'], 
                meta=r['meta'], 
                graphJSON=r['graphJSON'], 
                grandTotal=r['grandTotal'],
                layout = r['layout'],
                barLayout = r['barLayout'],
                lineGraphJSON = r['lineGraphJSON'])

# submissions_by_job_breakdown
@app.route('/submissions_by_job_breakdown')
def submissions_by_job_breakdown_view():
    # Import the report Class
    from reports import submissions_by_job_breakdown
    # Create a report object
    report = submissions_by_job_breakdown.Report(request.args)
    # Fetch report data
    r = report.get_report()
    # Generate HTML report with API data
    return render_template('submissions_by_job_breakdown.html', 
                            data=r['data'], 
                            meta=r['meta'],
                            labels=r['labels'],
                            chart_labels=r['chart_labels'],
                            job_groups=r['job_groups'],
                            total_by_jobs=r['total_by_jobs'],
                            yearGraphJSON=r['yearGraphJSON']
                          
                            # layout=r["layout"]
                            
                           )

# submissions_by_site_breakdown
@app.route('/submissions_by_site_breakdown')
def submissions_by_site_breakdown_view():
    # Import the report Class
    from reports import submissions_by_site_breakdown
    # Create a report object
    report = submissions_by_site_breakdown.Report(request.args)
    # Fetch report data
    r = report.get_report()
    # Generate HTML report with API data
   
    return render_template('submissions_by_site_breakdown.html', 
                            data=r['data'], 
                            meta=r['meta'],
                            labels=r['labels'],
                            chart_labels=r['chart_labels'],
                            site_groups=r['site_groups'],
                            total_by_sites=r['total_by_sites'],
                            yearGraphJSON=r['yearGraphJSON'],
                            # total_site= r['total_site']
                            # layout=r["layout"]
                            
                           )

# submissions_by_user_breakdown
@app.route('/submissions_by_user_breakdown')
def submissions_by_user_breakdown_view():
    # Import the report Class
    from reports import submissions_by_user_breakdown

    # Create a report object
    report = submissions_by_user_breakdown.Report(request.args)

    # Fetch report data
    r = report.get_report()

    return render_template('submissions_by_user_breakdown.html', 
                data = r['data'], 
                meta = r['meta'],
                graphData = r['allData'],
                # yearGraphJSON = r['yearGraphJSON'],
                layout = r['layout'],
                user_groups = r['user_groups'],
                total_by_users = r['total_by_users']

                # grandTotal=r['grandTotal'],
                # layout2 = r['layout2']
                )

# positive_id_summary
@app.route('/positive_id_summary')
def positive_id_summary_view():
    # Import the report Class
    from reports import positive_id_summary
    # Create a report object
    report = positive_id_summary.Report(request.args)
    # Fetch report data
    r = report.get_report()
    # Generate HTML report with API data
    return render_template('positive_id_summary.html', 
                            data = r['data'], 
                            meta=r['meta'],
                            labels= r['labels'],
                            positive_id_summary = r['positive_id_summary'])

# target_status_summary
@app.route('/target_status_summary')
def target_status_summary_view():
    # Import the report Class
    from reports import target_status_summary
    # Create a report object
    report = target_status_summary.Report(request.args)
    # Fetch report data
    r = report.get_report()
    # Generate HTML report with API data
    return render_template('target_status_summary.html', data = r['data'], meta=r['meta'])  

# target_status_by_role
@app.route('/target_status_by_role')
def target_status_by_role_view():
    # Import the report Class
    from reports import target_status_by_role
    # Create a report object
    report = target_status_by_role.Report(request.args)
    # Fetch report data
    r = report.get_report()
    # Generate HTML report with API data
    return render_template('target_status_summary.html', data = r['data'], meta=r['meta'])  

# target_status_by_site
@app.route('/target_status_by_site')
def target_status_by_site_view():
    # Import the report Class
    from reports import target_status_by_site
    # Create a report object
    report = target_status_by_site.Report(request.args)
    # Fetch report data
    r = report.get_report()
    # Generate HTML report with API data
    return render_template('target_status_summary.html', data = r['data'], meta=r['meta'])

# employee_training_records_summary
@app.route('/employee_training_records')
def employee_training_records_view():
    # Import the report Class
    from reports import employee_training_records

    # Create a report object
    report = employee_training_records.Report(request.args)

    # Get form data from filter pane
    filters = request.form

    # Fetch report data
    r = report.get_report(filters=filters)

    if 'report_selection' in r['meta']['args'] and (r['meta']['args']['report_selection'] == '30'):
        return render_template('employee_training_records.html', data = r['data'],
                            meta=r['meta'], 
                            template = 'employeeTrainingRecordsByJob',)

    elif 'report_selection' in r['meta']['args'] and (r['meta']['args']['report_selection'] == '108'):
         return render_template('employee_training_records.html', data = r['data'], meta=r['meta'], template = 'employeeTrainingRecordsBySite',)

    elif 'report_selection' in r['meta']['args'] and (r['meta']['args']['report_selection'] == '107'):
         return render_template('employee_training_records.html',training_records=r['training_records'],
                            data = r['data'],
                            meta=r['meta'],
                            template = 'employeeTrainingRecordsByEmployee',)
    else:
        # Generate HTML report with API data
        return render_template('employee_training_records.html', data = r['data'], meta=r['meta'])  
###############################

#### REPORT VIEWS ####
# am_shift
@app.route('/am_shift/<formSubmissionId>')
def am_shift_view(formSubmissionId):
    # Import the report Class
    from reports import am_shift

    # Create a report object
    report = am_shift.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('am_shift.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], positiveRecognition = r['positiveRecognition'], generalAction = r['generalAction'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], tasks = r['tasks'], inputOutput = r['inputOutput'], comments = r['comments'], delaysAndDetails = r['delaysAndDetails'], additionalHeaderInfo = r['additionalHeaderInfo'], totalDeliveries = r['totalDeliveries'], client_sign_picstamp=r['client_sign_picstamp'])

# bowtie
@app.route('/bowtie/<formSubmissionId>')
def bowtie_view(formSubmissionId):
    # Import the report Class
    from reports import bowtie

    # Create a report object
    report = bowtie.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('bowtie.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], bowParticipants=r['bowParticipants'],
    bowApprovers=r['bowApprovers'], hazardsList=r['hazardsList'], 
    generalAction=r['generalAction'],generalActionInitial=r['generalActionInitial'], generalActionFollowup=r['generalActionFollowup'], 
    bowApprovedBy=r['bowApprovedBy'], bowRisk=r['bowRisk'], rootCause_Consequence=r['rootCause_Consequence'], rowspan=r['rowspan'], rootCause=r['rootCause'], consequence=r['consequence'], attachments=r['attachments'], reviewers = r['reviewers'])


# cap_and_mag_powder
@app.route('/cap_and_mag_powder/<formSubmissionId>')
def cap_and_mag_powder_view(formSubmissionId):
    # Import the report Class
    from reports import cap_and_mag_powder

    # Create a report object
    report = cap_and_mag_powder.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('cap_and_mag_powder.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], 
    powderMagazine= r['powderMagazine'], capMagazine = r['capMagazine'], comments = r['comments'], signature= r['signature'], pictures= r['pictures'], hazardsList= r['hazardsList'], positiveRecognition = r['positiveRecognition'], generalAction = r['generalAction'], reportDistributors = r['reportDistributors'], signaturePic = r['signaturePic'], picturesPic = r['picturesPic'], reviewers=r['reviewers'])

    

# custom_form
@app.route('/custom_form/<formSubmissionId>')
def custom_form_view(formSubmissionId):
    # Import the report Class
    from reports import custom_form

    # Create a report object
    report = custom_form.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('custom_form.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], 
    hazardsList=r['hazardsList'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], generalAction=r['generalAction'],  
    reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], customFormItems=r['customFormItems'], comments=r['comments'], customFormPictures=r['customFormPictures'], 
    list=r['list'])

    

# confined_space_activity_log
@app.route('/confined_space_activity_log/<formSubmissionId>')
def confined_space_activity_log_view(formSubmissionId):
    # Import the report Class
    from reports import confined_space_activity_log

    # Create a report object
    report = confined_space_activity_log.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('confined_space_activity_log.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'],generalAction=r['generalAction'], positiveRecognition=r['positiveRecognition'],reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], formDetails=r['formDetails'], airQuality1=r['airQuality1'], airQuality2=r['airQuality2'], airQuality3=r['airQuality3'], airQuality4=r['airQuality4'], airQuality5=r['airQuality5'], airQuality6=r['airQuality6'], confinedSpaceLog=r['confinedSpaceLog'], entryPictures=r['entryPictures'],)
    
# daily_drilling
@app.route('/daily_drilling/<formSubmissionId>')
def daily_drilling_view(formSubmissionId):
    # Import the report Class
    from reports import daily_drilling

    # Create a report object
    report = daily_drilling.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('daily_drilling.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], generalAction=r['generalAction'], positiveRecognition=r['positiveRecognition'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], equipment=r['equipment'], materialUsed=r['materialUsed'], timeEntry=r['timeEntry'], comments=r['comments'], signatures=r['signatures'], supervisorTimeStamp=r['supervisorTimeStamp'], totals=r['totals'], legends=r['legends'], unit=r['unit'])





# daily_log
@app.route('/daily_log/<formSubmissionId>')
def daily_log_view(formSubmissionId):
    # Import the report Class
    from reports import daily_log

    # Create a report object
    report = daily_log.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('daily_log.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], generalAction=r['generalAction'], positiveRecognition=r['positiveRecognition'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], notes=r['notes'], formDetails=r['formDetails'])

    

# decision_log
@app.route('/decision_log/<formSubmissionId>')
def decision_log_view(formSubmissionId):
    # Import the report Class
    from reports import decision_log

    # Create a report object
    report = decision_log.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('decision_log.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], hazardsInitial=r['hazardsInitial'], hazardsFollowup=r['hazardsFollowup'], generalAction=r['generalAction'], generalActionInitial=r['generalActionInitial'], generalActionFollowup=r['generalActionFollowup'], reviewers=r['reviewers'], attachments=r['attachments'], participants=r['participants'])

    

# document_review
@app.route('/document_review/<formSubmissionId>')
def document_review_view(formSubmissionId):
    # Import the report Class
    from reports import document_review

    # Create a report object
    report = document_review.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('document_review.html', data = r['data'], meta=r['meta'], formHeader=r['formHeader'], reviewers=r['reviewers'], 
    externalReviewers=r['externalReviewers'], missingReviewer=r['missingReviewer'], attachments=r['attachments'])

    

# employee_review_60_day
@app.route('/employee_review_60_day/<formSubmissionId>')
def employee_review_60_day_view(formSubmissionId):
    # Import the report Class
    from reports import employee_review_60_day

    # Create a report object
    report = employee_review_60_day.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('employee_review_60_day.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], formDetails=r['formDetails'], legendDetails=r['legendDetails'], employeeTimeStamp=r['employeeTimeStamp'], evaluatorTimeStamp=r['evaluatorTimeStamp'], managerTimeStamp=r['managerTimeStamp'], signatures=r['signatures'], hazardsList=r['hazardsList'], positiveRecognition=r['positiveRecognition'], generalAction=r['generalAction'])

    

# employee_annual_review
@app.route('/employee_annual_review/<formSubmissionId>')
def employee_annual_review_view(formSubmissionId):
    # Import the report Class
    from reports import employee_annual_review

    # Create a report object
    report = employee_annual_review.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('employee_annual_review.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], formDetails=r['formDetails'], legendDetails=r['legendDetails'], employeeTimeStamp=r['employeeTimeStamp'], evaluatorTimeStamp=r['evaluatorTimeStamp'], managerTimeStamp=r['managerTimeStamp'], signatures=r['signatures'], performaceSummary=r['performaceSummary'], yes_flag=r['yes_flag'], hazardsList=r['hazardsList'], generalAction=r['generalAction'], positiveRecognition=r['positiveRecognition'])


    

# employee_departure
@app.route('/employee_departure/<formSubmissionId>')
def employee_departure_view(formSubmissionId):
    # Import the report Class
    from reports import employee_departure

    # Create a report object
    report = employee_departure.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('employee_departure.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], performance = r['performance'], assets = r['assets'], reportDistributors=r['reportDistributors'], reviewers = r['reviewers'], additionalHeaderInfo = r['additionalHeaderInfo'], duration = r['duration'], labels = r['labels'])

    

# employee_discipline
@app.route('/employee_discipline/<formSubmissionId>')
def employee_discipline_view(formSubmissionId):
    # Import the report Class
    from reports import employee_discipline

    # Create a report object
    report = employee_discipline.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('employee_discipline.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], formDetails=r['formDetails'], disciplineLegend=r['disciplineLegend'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'],employeeTimeStamp=r['employeeTimeStamp'], supervisorTimeStamp=r['supervisorTimeStamp'], managerTimeStamp=r['managerTimeStamp'], signatures=r['signatures'],hazardsList=r['hazardsList'], positiveRecognition=r['positiveRecognition'],
    generalAction=r['generalAction'])

    

# employee_performance
@app.route('/employee_performance/<formSubmissionId>')
def employee_performance_view(formSubmissionId):
    # Import the report Class
    from reports import employee_performance

    # Create a report object
    report = employee_performance.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('employee_performance.html', formHeader = r['formHeader'], meta = r['meta'], data = r['data'], formDetails = r['formDetails'],evaluation = r['evaluation'], signatures =r['signatures'], ratings = r['ratings'], comments = r['comments'], reportDistributors = r['reportDistributors'], reviewers=r['reviewers'], legend = r['legend'], employeeTimeStamp=r['employeeTimeStamp'], reviewerTimeStamp=r['reviewerTimeStamp'], employeeSignature=r['employeeSignature'], reviewerSignature=r['reviewerSignature'], labels=r['labels']) 
  
# expired employee training records
@app.route('/expired_employee_training_records')
def expired_employee_training_records():
    # Import the report Class
    from reports import expired_employee_training_records

    # Create a report object
    report = expired_employee_training_records.Report(request.args)

    # Fetch report data
    r = report.get_report()

    return render_template('expired_employee_training_records.html', 
                data = r['data'], 
                meta = r['meta']) 

# general_actions
@app.route('/general_actions/<formSubmissionId>')
def general_actions_view(formSubmissionId):
    # Import the report Class
    from reports import general_actions

    # Create a report object
    report = general_actions.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('general_actions.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'])

    

# general_actions_parent
@app.route('/general_actions_parent/<formSubmissionId>')
def general_actions_parent_view(formSubmissionId):
    # Import the report Class
    from reports import general_actions_parent

    # Create a report object
    report = general_actions_parent.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('general_actions_parent.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], generalAction=r['generalAction'], positiveRecognition=r['positiveRecognition'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'])

    

# general_statement
@app.route('/general_statement/<formSubmissionId>')
def general_statement_view(formSubmissionId):
    # Import the report Class
    from reports import general_statement

    # Create a report object
    report = general_statement.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('general_statement.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], statementInformation = r['statementInformation'], statementPhotos = r['statementPhotos'], statementSummary = r['statementSummary'], signatures = r['signatures'], hazardsList = r['hazardsList'], positiveRecognition = r['positiveRecognition'], generalAction = r['generalAction'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], workerTimeStamp=r['workerTimeStamp'])

    

# hazard_report
@app.route('/hazard_report/<formSubmissionId>')
def hazard_report_view(formSubmissionId):
    # Import the report Class
    from reports import hazard_report

    # Create a report object
    report = hazard_report.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('hazard_report.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], 
    hazardsList=r['hazardsList'], positiveRecognition=r['positiveRecognition'],
    generalAction=r['generalAction'],  
    reportDistributors=r['reportDistributors'], reviewers=r['reviewers'])

 



# hot_cold_evaluation
@app.route('/hot_cold_evaluation/<formSubmissionId>')
def hot_cold_evaluation_view(formSubmissionId):
    # Import the report Class
    from reports import hot_cold_evaluation

    # Create a report object
    report = hot_cold_evaluation.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('hot_cold_evaluation.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'],
    positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], 
    generalAction=r['generalAction'], 
    reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], inspections=r['inspections'], measurements=r['measurements'],
    personConducting=r['personConducting'])

    

# hot_work_permit
@app.route('/hot_work_permit/<formSubmissionId>')
def hot_work_permit_view(formSubmissionId):
    # Import the report Class
    from reports import hot_work_permit

    # Create a report object
    report = hot_work_permit.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('hot_work_permit.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], positiveRecognition = r['positiveRecognition'], generalAction = r['generalAction'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], details = r['details'], preworkSignatures = r['preworkSignatures'], hotWorkCompletion = r['hotWorkCompletion'], highRiskLocation = r['highRiskLocation'], whyHighRisk = r['whyHighRisk'], airQualityTest = r['airQualityTest'], fireWatch = r['fireWatch'], airQualityTestData = r['airQualityTestData'], fireWatchData = r['fireWatchData'], flag_whyHighRisk=r['flag_whyHighRisk'])

    

# incident_actions
@app.route('/incident_actions/<formSubmissionId>')
def incident_actions_view(formSubmissionId):
    # Import the report Class
    from reports import incident_actions

    # Create a report object
    report = incident_actions.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('incident_actions.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'])

    

# incident_report
@app.route('/incident_report/<formSubmissionId>')
def incident_report_view(formSubmissionId):
    # Import the report Class
    from reports import incident_report

    # Create a report object
    report = incident_report.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('incident_report.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], incident=r['incident'], investigation=r['investigation'], rootCause=r['rootCause'], correctiveActions=r['correctiveActions'], signoffs=r['signoffs'])

    

# incident_statement
@app.route('/incident_statement/<formSubmissionId>')
def incident_statement_view(formSubmissionId):
    # Import the report Class
    from reports import incident_statement

    # Create a report object
    report = incident_statement.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('incident_statement.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], positiveRecognition = r['positiveRecognition'], generalAction = r['generalAction'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], statementInfo = r['statementInfo'], statementPhotos = r['statementPhotos'], statementSummary = r['statementSummary'], signatureTimeStamp=r['signatureTimeStamp'])

    

# job_demonstration
@app.route('/job_demonstration/<formSubmissionId>')
def job_demonstration_view(formSubmissionId):
    # Import the report Class
    from reports import job_demonstration

    # Create a report object
    report = job_demonstration.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('job_demonstration.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], positiveRecognition = r['positiveRecognition'], generalAction = r['generalAction'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], comments = r['comments'], commentsLabel = r['commentsLabel'], multiphotos = r['multiphotos'])

    

# job_observation
@app.route('/job_observation/<formSubmissionId>')
def job_observation_view(formSubmissionId):
    # Import the report Class
    from reports import job_observation

    # Create a report object
    report = job_observation.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('job_observation.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], positiveRecognition = r['positiveRecognition'], generalAction = r['generalAction'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], comments = r['comments'], multiphotos=r['multiphotos'], employeeObserved=r['employeeObserved'])

    

# job_risk_assessment
@app.route('/job_risk_assessment/<formSubmissionId>')
def job_risk_assessment_view(formSubmissionId):
    # Import the report Class
    from reports import job_risk_assessment

    # Create a report object
    report = job_risk_assessment.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('job_risk_assessment.html', data = r['data'], formHeader=r['formHeader'], 
    meta=r['meta'], hazardsList=r['hazardsList'], hazardsInitial=r['hazardsInitial'], hazardsFollowup=r['hazardsFollowup'], generalAction=r['generalAction'], 
    generalActionInitial=r['generalActionInitial'],generalActionFollowup=r['generalActionFollowup'],
    reportApproved=r['reportApproved'], reviewers=r['reviewers'], jraPraItems=r['jraPraItems'], jraParticipants=r['jraParticipants'], 
    jraApprovers=r['jraApprovers'], jraThreats=r['jraThreats'], 
    jraApprovedBy=r['jraApprovedBy'], steps=r['steps'], attachments=r['attachments'])


    

# lessons_learned
@app.route('/lessons_learned/<formSubmissionId>')
def lessons_learned_view(formSubmissionId):
    # Import the report Class
    from reports import lessons_learned

    # Create a report object
    report = lessons_learned.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('lessons_learned.html', data = r['data'], meta=r['meta'], hazardsList=r['hazardsList'], hazardsInitial = r['hazardsInitial'], hazardsFollowup = r['hazardsFollowup'], generalAction = r['generalAction'], reviewers = r['reviewers'], lessonsLearned = r['lessonsLearned'], generalActionInitial = r['generalActionInitial'], generalActionFollowup = r['generalActionFollowup'],attachments=r['attachments'],participants=r['participants'], formHeader=r['formHeader'])

# life_saving_rules
@app.route('/life_saving_rules/<formSubmissionId>')
def life_saving_rules_view(formSubmissionId):
    # Import the report Class
    from reports import life_saving_rules

    # Create a report object
    report = life_saving_rules.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('life_saving_rules.html', data = r['data'], meta=r['meta'], hazardsList=r['hazardsList'], generalAction = r['generalAction'], reviewers = r['reviewers'], formHeader=r['formHeader'],reportDistributors = r['reportDistributors'],positiveRecognition = r['positiveRecognition'], signatures=r['signatures'], details=r['details'], employeeTimeStamp=r['employeeTimeStamp'], supervisorTimeStamp=r['supervisorTimeStamp'], managerTimeStamp=r['managerTimeStamp'], multiphotos=r['multiphotos'], instructions=r['instructions'], employeeName=r['employeeName'], rules=r['rules'], sanctions=r['sanctions'])

    

# lineup
@app.route('/lineup/<formSubmissionId>')
def lineup_view(formSubmissionId):
    # Import the report Class
    from reports import lineup

    # Create a report object
    report = lineup.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('lineup.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], reportLineup=r['reportLineup'], reviewers=r['reviewers'], formSubmissionId=r['formSubmissionId'], lineupDetails=r['lineupDetails'], workplaces = r['workplaces'], lineups_header=r['lineups_header'], threats=r['threats'], equipments_list=r['equipments_list'])

    

# lineup_draft
@app.route('/lineup_draft/<formSubmissionId>')
def lineup_draft_view(formSubmissionId):
    # Import the report Class
    from reports import lineup_draft

    # Create a report object
    report = lineup_draft.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('lineup_draft.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], reportLineup=r['reportLineup'], formSubmissionId=r['formSubmissionId'], lineupDetails=r['lineupDetails'], workplaces = r['workplaces'], lineups_header=r['lineups_header'], threats=r['threats'], equipments_list=r['equipments_list'])


# loto
@app.route('/loto/<formSubmissionId>')
def loto_view(formSubmissionId):
    # Import the report Class
    from reports import loto

    # Create a report object
    report = loto.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('loto.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], generalAction=r['generalAction'], reviewers=r['reviewers'], additionalDetails=r['additionalDetails'], lotoDetails=r['lotoDetails'], mechanisms=r['mechanisms'], positiveRecognition=r['positiveRecognition'], reportDistributors=r['reportDistributors'])

# meeting_minutes
@app.route('/meeting_minutes/<formSubmissionId>')
def meeting_minutes_view(formSubmissionId):
    # Import the report Class
    from reports import meeting_minutes

    # Create a report object
    report = meeting_minutes.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('meeting_minutes.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], positiveRecognition = r['positiveRecognition'], generalAction = r['generalAction'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], details = r['details'], pictures = r['pictures'], discussion = r['discussion'])

    

# monthly_safety_meeting
@app.route('/monthly_safety_meeting/<formSubmissionId>')
def monthly_safety_meeting_view(formSubmissionId):
    # Import the report Class
    from reports import monthly_safety_meeting

    # Create a report object
    report = monthly_safety_meeting.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('monthly_safety_meeting.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], positiveRecognition = r['positiveRecognition'], generalAction = r['generalAction'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], minutes=r['minutes'],
    multiphotos1=r['multiphotos1'], comments=r['comments'])

    

# organizational_risk_assessment
@app.route('/organizational_risk_assessment/<formSubmissionId>')
def organizational_risk_assessment_view(formSubmissionId):
    # Import the report Class
    from reports import organizational_risk_assessment

    # Create a report object
    report = organizational_risk_assessment.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('organizational_risk_assessment.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], 
    hazardsList=r['hazardsList'],hazardsInitial=r['hazardsInitial'],hazardsFollowup=r['hazardsFollowup'], oraParticipants=r['oraParticipants'], oraApprovers=r['oraApprovers'], oraApprovedBy=r['oraApprovedBy'], 
    generalAction=r['generalAction'],generalActionInitial=r['generalActionInitial'], generalActionFollowup=r['generalActionFollowup'], reviewers=r['reviewers'], attachments=r['attachments'],
    oraPraBowtieHeader=r['oraPraBowtieHeader'], bowtieParticipants=r['bowtieParticipants'], bowtieApprovers=r['bowtieApprovers'], steps=r['steps'])

    

# personal_contact
@app.route('/personal_contact/<formSubmissionId>')
def personal_contact_view(formSubmissionId):
    # Import the report Class
    from reports import personal_contact

    # Create a report object
    report = personal_contact.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('personal_contact.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], formDetails = r['formDetails'], hazardsList = r['hazardsList'], positiveRecognition= r['positiveRecognition'], generalAction= r['generalAction'], reportDistributors= r['reportDistributors'], reviewers = r['reviewers'], multiphotos = r['multiphotos'])


    

# positive_recognition
@app.route('/positive_recognition/<formSubmissionId>')
def positive_recognition_view(formSubmissionId):
    # Import the report Class
    from reports import positive_recognition

    # Create a report object
    report = positive_recognition.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('positive_recognition.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], 
    hazardsList=r['hazardsList'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], 
    generalAction=r['generalAction'],  
    reportDistributors=r['reportDistributors'], reviewers=r['reviewers'])

    

# ppe_audit
@app.route('/ppe_audit/<formSubmissionId>')
def ppe_audit_view(formSubmissionId):
    # Import the report Class
    from reports import ppe_audit

    # Create a report object
    report = ppe_audit.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('ppe_audit.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], formDetails =r['formDetails'], hazardsList = r['hazardsList'], generalAction= r['generalAction'], positiveRecognition = r['positiveRecognition'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], comment = r['comment'], ppeAudit = r['ppeAudit'], ppeStandards = r['ppeStandards'], ppeSpecialty = r['ppeSpecialty'], ppePhotos=r['ppePhotos'], multiphotos = r['multiphotos'])


    

# preliminary_incident
@app.route('/preliminary_incident/<formSubmissionId>')
def preliminary_incident_view(formSubmissionId):
    # Import the report Class
    from reports import preliminary_incident

    # Create a report object
    report = preliminary_incident.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('preliminary_incident.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'],
    hazardsList=r['hazardsList'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], generalAction=r['generalAction'],  
    reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], incidents=r['incidents'], incidentsInformation=r['incidentsInformation'],
    personnelInvolved=r['personnelInvolved'], otherInvolved=r['otherInvolved'], incidentsDescription=r['incidentsDescription'],
    preliminaryChecklist=r['preliminaryChecklist'], incidentAttachments=r['incidentAttachments'], updateSummary=r['updateSummary'], equipmentInvolved=r['equipmentInvolved'])

    

# preliminary_investigation
@app.route('/preliminary_investigation/<formSubmissionId>')
def preliminary_investigation_view(formSubmissionId):
    # Import the report Class
    from reports import preliminary_investigation

    # Create a report object
    report = preliminary_investigation.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('preliminary_investigation.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], generalAction=r['generalAction'], positiveRecognition=r['positiveRecognition'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], formDetails=r['formDetails'], updateSummary=r['updateSummary'],investigationAttachments=r['investigationAttachments'])

    

# pre_op
@app.route('/pre_op/<formSubmissionId>')
def pre_op_view(formSubmissionId):
    # Import the report Class
    from reports import pre_op

    # Create a report object
    report = pre_op.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('pre_op.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], machineInfo = r['machineInfo'], preopDetails = r['preopDetails'], generalAction=r['generalAction'], positiveRecognition=r['positiveRecognition'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], reportPreopImages = r['reportPreopImages'], reportPostopImages = r['reportPostopImages'], postopDetails = r['postopDetails'], signature = r['signature'], preopQuestions = r['preopQuestions'], supervisorTimeStamp=r['supervisorTimeStamp'], startTime= r['startTime'], endTime = r['endTime'], supervisorReviewTimeStamp=r['supervisorReviewTimeStamp'], supervisorReview=r['supervisorReview'], supervisorReviewData=r['supervisorReviewData'], endShift=r['endShift'])

# pre_op_field_audit
@app.route('/pre_op_field_audit/<formSubmissionId>')
def pre_op_field_audit_view(formSubmissionId):
    # Import the report Class
    from reports import pre_op_field_audit

    # Create a report object
    report = pre_op_field_audit.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('pre_op_field_audit.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'],
    hazardsList=r['hazardsList'], hazardsInitial=r['hazardsInitial'], hazardsFollowup=r['hazardsFollowup'],apiData=r['apiData'], positiveRecognitionImages=r['positiveRecognitionImages'], positiveRecognition = r['positiveRecognition'], generalAction=r['generalAction'], generalActionInitial=r['generalActionInitial'], generalActionFollowup=r['generalActionFollowup'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], auditPictures=r['auditPictures'], comments=r['comments'], equipmentPreOp=r['equipmentPreOp'], multiphotosWorker=r['multiphotosWorker'], multiphotosSupervisor=r['multiphotosSupervisor'], supervisorTimeStamp = r['supervisorTimeStamp'], workerTimeStamp=r['workerTimeStamp'], supervisorComments=r['supervisorComments'], workerComments=r['workerComments'], pidLikes= r['pidLikes'], pidComments = r['pidComments'])

    

# pre_task
@app.route('/pre_task/<formSubmissionId>')
def pre_task_view(formSubmissionId):
    # Import the report Class
    from reports import pre_task

    # Create a report object
    report = pre_task.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('pre_task.html', formHeader = r['formHeader'], meta = r['meta'], data = r['data'], safetyChecks = r['safetyChecks'], shift = r['shift'], preTaskAssesment= r['preTaskAssesment'], worstCaseScenario= r['worstCaseScenario'], signatures =r['signatures'], reportDistributors=r['reportDistributors'], reviewers = r['reviewers'],hazardsList=r['hazardsList'], apiData=r['apiData'], generalAction=r['generalAction'], multiphotosStart=r['multiphotosStart'], multiphotosEnd=r['multiphotosEnd'], startStateDetails=r['startStateDetails'], endStateDetails=r['endStateDetails'],workplaceConditions=r['workplaceConditions'], positiveRecognition=r['positiveRecognition'], supervisorTimeStamp=r['supervisorTimeStamp'], managerTimeStamp=r['managerTimeStamp'], otherTimeStamp=r['otherTimeStamp'], supervisorReviewTimestamp=r['supervisorReviewTimestamp'], supervisorReview=r['supervisorReview'])
    


# procedure_phr_audit
@app.route('/procedure_phr_audit/<formSubmissionId>')
def procedure_phr_audit_view(formSubmissionId):
    # Import the report Class
    from reports import procedure_phr_audit

    # Create a report object
    report = procedure_phr_audit.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('procedure_phr_audit.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], 
    hazardsList=r['hazardsList'], hazardsInitial=r['hazardsInitial'], hazardsFollowup=r['hazardsFollowup'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], positiveRecognitionImages=r['positiveRecognitionImages'],
    generalAction=r['generalAction'], generalActionInitial=r['generalActionInitial'], generalActionFollowup=r['generalActionFollowup'], 
    reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], formDetails=r['formDetails'], pidLikes= r['pidLikes'], pidComments = r['pidComments'])
    

# project_risk_assessment
@app.route('/project_risk_assessment/<formSubmissionId>')
def project_risk_assessment_view(formSubmissionId):
    # Import the report Class
    from reports import project_risk_assessment

    # Create a report object
    report = project_risk_assessment.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('project_risk_assessment.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], 
    hazardsInitial =r['hazardsInitial'], hazardsFollowup=r['hazardsFollowup'], generalAction=r['generalAction'], generalActionInitial=r['generalActionInitial'], generalActionFollowup=r['generalActionFollowup'], reviewers=r['reviewers'], oraLineItems=r['oraLineItems'],
    praParticipants=r['praParticipants'], praApprovers=r['praApprovers'], praThreats=r['praThreats'], praApprovedBy=r['praApprovedBy'], 
    oraPraBowtieHeader=r['oraPraBowtieHeader'], bowtieApprovers=r['bowtieApprovers'], bowtieParticipants=r['bowtieParticipants'], steps=r['steps'],
    attachments=r['attachments'])

    

# rescue_plan
@app.route('/rescue_plan/<formSubmissionId>')
def rescue_plan_view(formSubmissionId):
    # Import the report Class
    from reports import rescue_plan

    # Create a report object
    report = rescue_plan.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('rescue_plan.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], generalAction=r['generalAction'], positiveRecognition=r['positiveRecognition'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], formDetails=r['formDetails'], planApproverTimeStamp = r['planApproverTimeStamp'], sketchTimeStamp = r['sketchTimeStamp'])

    

# incident_analysis
@app.route('/incident_analysis/<formSubmissionId>')
def incident_analysis_view(formSubmissionId):
    # Import the report Class
    from reports import incident_analysis

    # Create a report object
    report = incident_analysis.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('incident_analysis.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], immediateCauses=r['immediateCauses'],
    basicCauses=r['basicCauses'], reviewers=r['reviewers'])

    

# safety_card_audit
@app.route('/safety_card_audit/<formSubmissionId>')
def safety_card_audit_view(formSubmissionId):
    # Import the report Class
    from reports import safety_card_audit

    # Create a report object
    report = safety_card_audit.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('safety_card_audit.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], 
    hazardsList=r['hazardsList'], hazardsInitial=r['hazardsInitial'], hazardsFollowup=r['hazardsFollowup'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], positiveRecognitionImages=r['positiveRecognitionImages'],
    generalAction=r['generalAction'], generalActionInitial=r['generalActionInitial'], generalActionFollowup=r['generalActionFollowup'], 
    reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], formDetails=r['formDetails'], safetyPhotos=r['safetyPhotos'], pidLikes= r['pidLikes'], pidComments = r['pidComments'])

    

# safety_jhs_board_audit
@app.route('/safety_jhs_board_audit/<formSubmissionId>')
def safety_jhs_board_audit_view(formSubmissionId):
    # Import the report Class
    from reports import safety_jhs_board_audit

    # Create a report object
    report = safety_jhs_board_audit.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('safety_jhs_board_audit.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], positiveRecognition = r['positiveRecognition'], generalAction = r['generalAction'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], jhsboard=r['jhsboard'], comments=r['comments'], multiphotos=r['multiphotos'], correctionActionRequirements=r['correctionActionRequirements'])

    

# shift_construction
@app.route('/shift_construction/<formSubmissionId>')
def shift_construction_view(formSubmissionId):
    # Import the report Class
    from reports import shift_construction

    # Create a report object
    report = shift_construction.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('shift_construction.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], positiveRecognition = r['positiveRecognition'], generalAction = r['generalAction'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], workplace1 = r['workplace1'], workplace2 = r['workplace2'], workplace3 = r['workplace3'], workplace4 = r['workplace4'], workplace5 = r['workplace5'], workplace6 = r['workplace6'], workplace7 = r['workplace7'], workplace8 = r['workplace8'], workplace9 = r['workplace9'], workplace10 = r['workplace10'], workplace11 = r['workplace11'], workplace12 = r['workplace12'], workplace13 = r['workplace13'], workplace14 = r['workplace14'], workplace15 = r['workplace15'], comments = r['comments'], workplaceDetails = r['workplaceDetails'], workEquipments1=r['workEquipments1'], workEquipments2=r['workEquipments2'], workEquipments3=r['workEquipments3'], workEquipments4=r['workEquipments4'], workEquipments5=r['workEquipments5'], workEquipments6=r['workEquipments6'], workEquipments7=r['workEquipments7'],workEquipments8=r['workEquipments8'], workEquipments9=r['workEquipments9'], workEquipments10=r['workEquipments10'], workEquipments11=r['workEquipments11'], workEquipments12=r['workEquipments12'], workEquipments13=r['workEquipments13'], workEquipments14=r['workEquipments14'], workEquipments15=r['workEquipments15'], multiphotos1=r['multiphotos1'], multiphotos2=r['multiphotos2'], multiphotos3=r['multiphotos3'], multiphotos4=r['multiphotos4'], multiphotos5=r['multiphotos5'], multiphotos6=r['multiphotos6'], multiphotos7=r['multiphotos7'], multiphotos8=r['multiphotos8'], multiphotos9=r['multiphotos9'], multiphotos10=r['multiphotos10'], multiphotos11=r['multiphotos11'], multiphotos12=r['multiphotos12'], multiphotos13=r['multiphotos13'], multiphotos14=r['multiphotos14'], multiphotos15=r['multiphotos15'], shift = r['shift'])

    

# shift_development
@app.route('/shift_development/<formSubmissionId>')
def shift_development_view(formSubmissionId):
    # Import the report Class
    from reports import shift_development

    # Create a report object
    report = shift_development.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('shift_development.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'],  positiveRecognition = r['positiveRecognition'], generalAction = r['generalAction'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], shifts=r['shifts'], comments=r['comments'], workplace1=r['workplace1'], multiphotos1=r['multiphotos1'], workplace2=r['workplace2'], multiphotos2=r['multiphotos2'], workplace3=r['workplace3'], multiphotos3=r['multiphotos3'], workplace4=r['workplace4'], workplace5=r['workplace5'], workplace6=r['workplace6'], workplace7=r['workplace7'],workplace8=r['workplace8'], multiphotos4=r['multiphotos4'], multiphotos5=r['multiphotos5'], multiphotos6=r['multiphotos6'], multiphotos7=r['multiphotos7'], multiphotos8=r['multiphotos8'], workplace9=r['workplace9'], multiphotos9=r['multiphotos9'], workplace10=r['workplace10'], multiphotos10=r['multiphotos10'], workplace11=r['workplace11'], multiphotos11=r['multiphotos11'], workplace12=r['workplace12'], multiphotos12=r['multiphotos12'], workplace13=r['workplace13'], multiphotos13=r['multiphotos13'], workplace14=r['workplace14'], multiphotos14=r['multiphotos14'], workplace15=r['workplace15'], multiphotos15=r['multiphotos15'], equipmentState=r['equipmentState'], workEquipments1=r['workEquipments1'], workEquipments2=r['workEquipments2'], workEquipments3=r['workEquipments3'], workEquipments4=r['workEquipments4'], workEquipments5=r['workEquipments5'], workEquipments6=r['workEquipments6'], workEquipments7=r['workEquipments7'], workEquipments8=r['workEquipments8'], workEquipments9=r['workEquipments9'], workEquipments10=r['workEquipments10'], workEquipments11=r['workEquipments11'], workEquipments12=r['workEquipments12'], workEquipments13=r['workEquipments13'], workEquipments14=r['workEquipments14'], workEquipments15=r['workEquipments15'], equipmentSummary=r['equipmentSummary'])

# shift_report_craig_logistics
@app.route('/shift_report_craig_logistics/<formSubmissionId>')
def shift_report_craig_logistics_view(formSubmissionId):
    # Import the report Class
    from reports import shift_report_craig_logistics

    # Create a report object
    report = shift_report_craig_logistics.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('shift_report_craig_logistics.html',formHeader=r['formHeader'], meta=r['meta'], data = r['data'],
    hazardsList=r['hazardsList'], hazardsInitial=r['hazardsInitial'], hazardsFollowup=r['hazardsFollowup'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], positiveRecognitionImages=r['positiveRecognitionImages'],
    generalAction=r['generalAction'], generalActionInitial=r['generalActionInitial'], generalActionFollowup=r['generalActionFollowup'], 
    reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], safety=r['safety'], muckCircuitStatus=r['muckCircuitStatus'], skipHoistProduction=r['skipHoistProduction'], cageRuns=r['cageRuns'],
    workplace1=r['workplace1'], multiphotos1=r['multiphotos1'], workplace2=r['workplace2'], multiphotos2=r['multiphotos2'], workplace3=r['workplace3'], multiphotos3=r['multiphotos3'], workplace4=r['workplace4'], workplace5=r['workplace5'], workplace6=r['workplace6'],
    workplace7=r['workplace7'],workplace8=r['workplace8'], multiphotos4=r['multiphotos4'], multiphotos5=r['multiphotos5'],
    multiphotos6=r['multiphotos6'],multiphotos7=r['multiphotos7'], multiphotos8=r['multiphotos8'], comments=r['comments'], workplaceDetails=r['workplaceDetails'], pidLikes= r['pidLikes'], pidComments = r['pidComments'])


# supervisor_lineup_audit
@app.route('/supervisor_lineup_audit/<formSubmissionId>')
def supervisor_lineup_audit_view(formSubmissionId):
    # Import the report Class
    from reports import supervisor_lineup_audit

    # Create a report object
    report = supervisor_lineup_audit.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('supervisor_lineup_audit.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], 
    hazardsList=r['hazardsList'], hazardsInitial=r['hazardsInitial'], hazardsFollowup=r['hazardsFollowup'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], positiveRecognitionImages=r['positiveRecognitionImages'],
    generalAction=r['generalAction'], generalActionInitial=r['generalActionInitial'], generalActionFollowup=r['generalActionFollowup'], 
    reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], lineup=r['lineup'], comments=r['comments'], correctionActionRequirements=r['correctionActionRequirements'], pidLikes= r['pidLikes'], pidComments = r['pidComments'])

    

# supervisor_training_audit
@app.route('/supervisor_training_audit/<formSubmissionId>')
def supervisor_training_audit_view(formSubmissionId):
    # Import the report Class
    from reports import supervisor_training_audit

    # Create a report object
    report = supervisor_training_audit.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('supervisor_training_audit.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], 
    hazardsList=r['hazardsList'], hazardsInitial=r['hazardsInitial'], hazardsFollowup=r['hazardsFollowup'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], positiveRecognitionImages=r['positiveRecognitionImages'],
    generalAction=r['generalAction'], generalActionInitial=r['generalActionInitial'], generalActionFollowup=r['generalActionFollowup'], 
    reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], audits=r['audits'], comments=r['comments'], multiphotos1=r['multiphotos1'], 
    correctionAction=r['correctionAction'], pidLikes= r['pidLikes'], pidComments = r['pidComments'])
    

# tag_board_audit
@app.route('/tag_board_audit/<formSubmissionId>')
def tag_board_audit_view(formSubmissionId):
    # Import the report Class
    from reports import tag_board_audit

    # Create a report object
    report = tag_board_audit.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('tag_board_audit.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], 
    hazardsList=r['hazardsList'], hazardsInitial=r['hazardsInitial'], hazardsFollowup=r['hazardsFollowup'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], positiveRecognitionImages=r['positiveRecognitionImages'],
    generalAction=r['generalAction'], generalActionInitial=r['generalActionInitial'], generalActionFollowup=r['generalActionFollowup'], 
    reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], tagboard=r['tagboard'], comments=r['comments'],
    multiphotos=r['multiphotos'], correctionActionRequirements=r['correctionActionRequirements'], pidLikes= r['pidLikes'], pidComments = r['pidComments'])

    

# task_vs_mtcu_training_audit
@app.route('/task_vs_mtcu_training_audit/<formSubmissionId>')
def task_vs_mtcu_training_audit_view(formSubmissionId):
    # Import the report Class
    from reports import task_vs_mtcu_training_audit

    # Create a report object
    report = task_vs_mtcu_training_audit.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('task_vs_mtcu_training_audit.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], 
    hazardsList=r['hazardsList'], hazardsInitial=r['hazardsInitial'], hazardsFollowup=r['hazardsFollowup'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], positiveRecognitionImages=r['positiveRecognitionImages'],
    generalAction=r['generalAction'], generalActionInitial=r['generalActionInitial'], generalActionFollowup=r['generalActionFollowup'], 
    reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], audit=r['audit'], comments=r['comments'],
    multiphotos=r['multiphotos'], correctionActionRequirements=r['correctionActionRequirements'], pidLikes= r['pidLikes'], pidComments = r['pidComments'])

# technician_field_service
@app.route('/technician_field_service/<formSubmissionId>')
def technician_field_service_view(formSubmissionId):
    # Import the report Class
    from reports import technician_field_service

    # Create a report object
    report = technician_field_service.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('technician_field_service.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], 
    hazardsList=r['hazardsList'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], generalAction=r['generalAction'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], additionalHeaderInfo=r['additionalHeaderInfo'], serviceSummary=r['serviceSummary'], comments=r['comments'], signatures=r['signatures'], supervisorTimeStamp=r['supervisorTimeStamp'], customerTimeStamp=r['customerTimeStamp'], totalValues=r['totalValues'])   


# timesheet
@app.route('/timesheet/<formSubmissionId>')
def timesheet_view(formSubmissionId):
    # Import the report Class
    from reports import timesheet

    # Create a report object
    report = timesheet.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('timesheet.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'],  positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], generalAction=r['generalAction'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], workDetails=r['workDetails'], employees=r['employees'], equipments=r['equipments'],head=r['head'], multiphotos=r['multiphotos'], grand_total=r['grand_total'], workAcceptance=r['workAcceptance'], signTimeStamp=r['signTimeStamp'])
    

# training_assessment_audit
@app.route('/training_assessment_audit/<formSubmissionId>')
def training_assessment_audit_view(formSubmissionId):
    # Import the report Class
    from reports import training_assessment_audit

    # Create a report object
    report = training_assessment_audit.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('training_assessment_audit.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], positiveRecognition = r['positiveRecognition'], positiveRecognitionImages = r['positiveRecognitionImages'], hazardsInitial = r['hazardsInitial'], hazardsFollowup = r['hazardsFollowup'], generalAction = r['generalAction'], generalActionInitial = r['generalActionInitial'], generalActionFollowup = r['generalActionFollowup'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], formDetails = r['formDetails'], audit = r['audit'], multiphotos = r['multiphotos'], pidLikes= r['pidLikes'], pidComments = r['pidComments'])
    

# vale_flha
@app.route('/vale_flha/<formSubmissionId>')
def vale_flha_view(formSubmissionId):
    # Import the report Class
    from reports import vale_flha

    # Create a report object
    report = vale_flha.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('vale_flha.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], generalAction=r['generalAction'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'],equipedForWork=r['equipedForWork'], headerDetails=r['headerDetails'], criticalInformation=r['criticalInformation'], tasks=r['tasks'], workplaceConditions=r['workplaceConditions'], stateDetails=r['stateDetails'], multiphotosStart=r['multiphotosStart'], multiphotosEnd=r['multiphotosEnd'], signature=r['signature'], criticalActivity=r['criticalActivity'], startDetailsInfo=r['startDetailsInfo'], endDetailsInfo=r['endDetailsInfo'], criticalLabel=r['criticalLabel'], supervisorTimeStamp=r['supervisorTimeStamp'], managerTimeStamp=r['managerTimeStamp'], otherTimeStamp=r['otherTimeStamp'], supervisorComments=r['supervisorComments'], endShiftReview=r['endShiftReview'], hazardsList=r['hazardsList'])

    

# vfl_audit
@app.route('/vfl_audit/<formSubmissionId>')
def vfl_audit_view(formSubmissionId):
    # Import the report Class
    from reports import vfl_audit

    # Create a report object
    report = vfl_audit.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('vfl_audit.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], generalAction=r['generalAction'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], jobDemonstration=r['jobDemonstration'])

    

# viewpoint_audit
@app.route('/viewpoint_audit/<formSubmissionId>')
def viewpoint_audit_view(formSubmissionId):
    # Import the report Class
    from reports import viewpoint_audit

    # Create a report object
    report = viewpoint_audit.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('viewpoint_audit.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], reportDistributors = r['reportDistributors'], reviewers = r['reviewers'], hazardsInitial = r['hazardsInitial'], hazardsFollowup = r['hazardsFollowup'], audit = r['audit'], comments = r['comments'], correctionActionRequirements = r['correctionActionRequirements'], generalAction = r['generalAction'], generalActionInitial = r['generalActionInitial'], generalActionFollowup = r['generalActionFollowup'], positiveRecognition = r['positiveRecognition'], positiveRecognitionImages = r['positiveRecognitionImages'], multiphotos = r['multiphotos'], pidLikes= r['pidLikes'], pidComments = r['pidComments'])

    
# work_card
@app.route('/work_card/<formSubmissionId>')
def work_card_view(formSubmissionId):
    # Import the report Class
    from reports import work_card

    # Create a report object
    report = work_card.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('work_card.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], tasksToDo=r['tasksToDo'], workArea=r['workArea'],shifts=r['shifts'], accessToWorksite=r['accessToWorksite'], shiftStart=r['shiftStart'], supervisorVisit=r['supervisorVisit'], planning=r['planning'], decision=r['decision'], execution=r['execution'], execution_sign_timestamp=r['execution_sign_timestamp'], shiftEnd=r['shiftEnd'], drillingLoading=r['drillingLoading'], groundSupport=r['groundSupport'], materialsNextShift=r['materialsNextShift'], multiphotosStart=r['multiphotosStart'], multiphotosEnd=r['multiphotosEnd'], startStateDetails=r['startStateDetails'], endStateDetails=r['endStateDetails'], decision_emp_signatures=r['decision_emp_signatures'], decision_super_signatures=r['decision_super_signatures'],emp_sign_timestamp=r['emp_sign_timestamp'],super_sign_timestamp=r['super_sign_timestamp'],hazardsList=r['hazardsList'], hazardsInitial=r['hazardsInitial'], hazardsFollowup=r['hazardsFollowup'], positiveRecognition=r['positiveRecognition'], positiveRecognitionImages=r['positiveRecognitionImages'], generalAction=r['generalAction'], generalActionInitial=r['generalActionInitial'], generalActionFollowup=r['generalActionFollowup'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], pidLikes= r['pidLikes'], pidComments = r['pidComments'], accessToWorksiteSurface = r['accessToWorksiteSurface'], methodOfWork =r['methodOfWork'], workplace=r['workplace'], underground_workarea=r['underground_workarea'], locationOfRefuge=r['locationOfRefuge'], reportType=r['reportType'])


# working_at_heights
@app.route('/working_at_heights/<formSubmissionId>')
def working_at_heights_view(formSubmissionId):
    # Import the report Class
    from reports import working_at_heights

    # Create a report object
    report = working_at_heights.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('working_at_heights.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'], hazardsList=r['hazardsList'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], generalAction=r['generalAction'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], details=r['details'], initialAirQualityTest=r['initialAirQualityTest'],confinedSpaceSupervisor=r['confinedSpaceSupervisor'], pictureConfinedSpace=r['pictureConfinedSpace'],confinedSpacepicStamp=r['confinedSpacepicStamp'],shifts=r['shifts'], timeEntry=r['timeEntry'])
    

# workplace_inspection
@app.route('/workplace_inspection/<formSubmissionId>')
def workplace_inspection_view(formSubmissionId):
    # Import the report Class
    from reports import workplace_inspection

    # Create a report object
    report = workplace_inspection.Report(request.args)

    # Fetch report data
    r = report.get_report(formSubmissionId)

    # Generate HTML report with API data
    return render_template('workplace_inspection.html', data = r['data'], formHeader=r['formHeader'], meta=r['meta'],inspections=r['inspections'], hazardsList=r['hazardsList'], positiveRecognition=r['positiveRecognition'], apiData=r['apiData'], generalAction=r['generalAction'], reportDistributors=r['reportDistributors'], reviewers=r['reviewers'], multiphotos=r['multiphotos'], comments=r['comments'])


# Loading report spinner animation
@app.route('/report/<reportSlug>')
@app.route('/report/<reportSlug>/<formSubmissionId>')
def initial_view(reportSlug, formSubmissionId=None):
    return render_template('_initial.html', reportSlug=reportSlug, url=request.url, formSubmissionId=formSubmissionId, request=request)


@app.route('/silent-sso')
def sso_view():
    return render_template('silent-check-sso.html')


# Error pages
@app.errorhandler(404)
def page_not_found_view(e):
    error_data = h.log_error(404)
    return render_template('_error.html', error_data=error_data), 404

@app.errorhandler(403)
def forbidden_view(e):
    error_data = h.log_error(403)
    return render_template('_error.html', error_data=error_data), 403

@app.errorhandler(410)
def gone_view(e):
    error_data = h.log_error(410)
    return render_template('_error.html', error_data=error_data), 410

@app.errorhandler(500)
def internal_server_error_view(e):
    error_data = h.log_error(500)
    return render_template('_error.html', error_data=error_data), 500



# Logs
@app.route('/logs/errors/<id>')
def error_view(id):
    error_log = {"id": -99, "code": -999, "msg": "The requested error ID was not found."}
    try:
        with open(f'logs/errors/{id}.json') as f:
            error_log = json.loads(f.read())
    except:
        return error_log    
    return jsonify(error_log)

# Root
@app.route('/')
def home_view():
    return render_template('home.html')

#######################
if __name__ == "__main__":

    with open('credentials.yaml', 'r') as f:
        cred = yaml.safe_load(f)          
    port = cred['port']
    debug = cred['debug']
    host = cred['host']

    if not os.path.exists('logs'):
        os.mkdir('logs')
    if not os.path.exists('logs/analytics'):
        os.mkdir('logs/analytics')
    if not os.path.exists('logs/errors'):
        os.mkdir('logs/errors')

    
        
    app.run(host=host, debug=debug, port=port, ssl_context=('static/ssl/star_sofvie_com.crt', 'static/ssl/star_sofvie_com.key'))