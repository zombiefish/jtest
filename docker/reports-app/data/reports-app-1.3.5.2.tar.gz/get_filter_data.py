from sqlalchemy import create_engine, text
from decimal import Decimal
from flask import request
import pymysql, yaml, datetime, requests, json, urllib, random, os

def execute_sp(sp, params=None, args=None):
    with open('credentials.yaml', 'r') as f:
        cred = yaml.safe_load(f)
        if 'testcore' in request.base_url:
            cred = cred['test']
        elif 'devcore' in request.base_url:
            cred = cred['dev']
        else:
            if args and 'env' in args:
                cred = cred[args['env']]
            else:
                cred = cred[cred['active']]

    engine = pymysql.connect(host=cred['db_server'], user=cred['db_user'], password=cred['db_password'], db=cred['db_name'], cursorclass=pymysql.cursors.DictCursor)
    cur = engine.cursor()
    if params:
        if sp == 'rpt_positive_recognition' and len(params) == 2:
            # False indicates that SP is filtering data based on submissionheader_id but not with pid
            params.append(False)
        cur.callproc(sp, params)
    else:
        cur.callproc(sp)
    sqlResult = cur.fetchall()
    if isinstance(sqlResult, tuple):
        sqlResult = list(sqlResult)

    for result in sqlResult:
        if isinstance(result, dict):
            for res in result.keys():                 
                if isinstance(result[res], datetime.datetime):
                    if 'date' in res or 'Date' in res:
                        result[res] = result[res].strftime('%Y-%m-%d')                        
                    else:
                        result[res] = result[res].strftime('%Y-%m-%d %H:%M:%S')
                if isinstance(result[res], (bytes, bytearray)):
                    result[res] = result[res].decode('utf-8')
                if isinstance(result[res], Decimal):
                    result[res] = float(result[res])
                if isinstance(result[res], datetime.date): 
                    result[res] = result[res].strftime('%Y-%m-%d')   
                
    engine.close()
    return sqlResult

def get_filter_data(args=None):

    allFilterData = {}
    mainFilterData = {}

    # User inputs
    if args and 'required_args' in args:
        report_slug = args['report_slug'] if 'report_slug' in args and args['report_slug'] is not None else None
        requiredArgs = args['required_args']
        optionalArgs = args['optional_args']
        allFilterData['requiredArgs'] ={}
        allFilterData['optionalArgs'] ={}

        with open('filters.yaml', 'r') as f:
            filters = yaml.safe_load(f)

        if requiredArgs is not None:
            for requiredArg in requiredArgs:
                filterData = filters[requiredArg]
                allFilterData['requiredArgs'][requiredArg] = {}

                if requiredArg not in ['start_date', 'end_date', 'year']:                
                    requiredParams = filterData['params'].split(',') if filterData['params'] != 0 else None

                    if requiredParams:
                        # If lang id is in args, else default to English
                        langId = args['lang'] if (args and 'lang' in args) else 1
                        if 'lang' in filterData['params']:
                            if 'lang' in requiredParams:
                                requiredParams = [langId] + requiredParams[1:]
                            else:
                                requiredParams = [langId] + requiredParams
                    if requiredArg == 'report_selection' and report_slug is not None:
                        requiredParams.append(report_slug)
                        
                    if requiredArg == 'doc_names':
                        result = []
                    else:
                        result = execute_sp(filterData['stored_procedure'], requiredParams)
                    
                    # Rename key inside list of dictionaries
                    for d in result:                    
                        d['value'] = d.pop(filterData['select_value_field'])
                        d['label'] = d.pop(filterData['select_label_field'])
                    
                    # Sort the result by text
                    if requiredArg in ['start_month', 'end_month']:
                        result = sorted(result, key=lambda k: int(k['value']))
                    else:
                        result = sorted(result, key=lambda k: str(k['label']).lower())

                    # Delete objects with no text
                    result = [x for x in result if x['label']]
                    
                    # Append to filter_data
                    allFilterData['requiredArgs'][requiredArg]['field_values'] = result
                # Get tag value
                
                tag = filterData['tags']
                if tag != 0:
                    tagValue = None
                    if args and 'lang' in args:
                        tagValue = execute_sp('get_translation_by_tag', [tag, args['lang'], 1])
                    else:
                        tagValue = execute_sp('get_translation_by_tag', [tag, 1, 1])
                    tagValue = tagValue[0]['ltr_text'] if tagValue else ''
                else:
                    tagValue = 'Tag to be translated'
                
                # Add input field type and tag value to field label  
                allFilterData['requiredArgs'][requiredArg]['field_label'] = tagValue
                allFilterData['requiredArgs'][requiredArg]['field_type'] = filterData['field_type']
        
        if optionalArgs is not None:
            for requiredArg in optionalArgs:
                filterData = filters[requiredArg]
                allFilterData['optionalArgs'][requiredArg] = {}

                if requiredArg not in ['start_date', 'end_date', 'year']:                
                    requiredParams = filterData['params'].split(',') if filterData['params'] != 0 else None

                    if requiredParams:
                        # If lang id is in args, else default to English
                        langId = args['lang'] if (args and 'lang' in args) else 1
                        if 'lang' in filterData['params']:
                            if 'lang' in requiredParams:
                                requiredParams = [langId] + requiredParams[1:]
                            else:
                                requiredParams = [langId] + requiredParams
                    if requiredArg == 'doc_names':
                        result = []
                    else:
                        result = execute_sp(filterData['stored_procedure'], requiredParams)

                    # Rename key inside list of dictionaries
                    for d in result:                    
                        d['value'] = d.pop(filterData['select_value_field'])
                        d['label'] = d.pop(filterData['select_label_field'])
                    
                    # Sort the result by text
                    if requiredArg in ['start_month', 'end_month']:
                        result = sorted(result, key=lambda k: int(k['value']))
                    else:
                        result = sorted(result, key=lambda k: str(k['label']).lower())

                    # Delete objects with no text
                    result = [x for x in result if x['label']]
                    
                    # Append to filter_data
                    allFilterData['optionalArgs'][requiredArg]['field_values'] = result               

                # Get tag value
                tag = filterData['tags']
                if tag != 0:
                    tagValue = None
                    if args and 'lang' in args:
                        tagValue = execute_sp('get_translation_by_tag', [tag, args['lang'], 1])
                    else:
                        tagValue = execute_sp('get_translation_by_tag', [tag, 1, 1])
                    tagValue = tagValue[0]['ltr_text'] if tagValue else ''
                else:
                    tagValue = 'Tag to be translated'
                
                # Add input field type and tag value to field label  
                allFilterData['optionalArgs'][requiredArg]['field_label'] = tagValue
                allFilterData['optionalArgs'][requiredArg]['field_type'] = filterData['field_type']

    return allFilterData