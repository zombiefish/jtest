Submission Reports - 
A visual representation of the submitted form's data. No filters / user interaction provided.

Parameterized Reports - 
A visual representation of the aggregated data. User interaction / filters on dimensions may be present.


## Common Report Structure
1. Report Header (Title & Logo)
2. Report Footer (Page #, Report Version)
3. Report Slug (eg. lineup, pretask)
4. Language (en, fr, es)
5. (Backend logic) Limit visible data based on user id


## Submission Reports - Structure
1. Form Header (Header Table)
2. Form Submission ID
3. Images
4. Stored Procedures


## Parameterized Reports - Structure
1. Report Filter Paramters
2. Charts
3. In-line SQLs






## Summary of the walkthrough session
1. Develop the SQL calling part
2. Find a way to call SPs with paramaters more than the form submission id
3. 